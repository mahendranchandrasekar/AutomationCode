package com.uk.dlgds.fusionvalidation.resources.datasource;

import com.uk.dlgds.fusionvalidation.Utils.Staging;
import com.uk.dlgds.fusionvalidation.service.ApplicationDetails;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class StgValidations {

    private final ApplicationDetails applicationDetails = new ApplicationDetails();

     List<Staging> dbToJavaObject(ResultSet resultSet) throws SQLException {

        List<Staging> stagingToList=new ArrayList<>();
        while(resultSet.next()){

            Staging staging = new Staging();

            staging.setTrxNumber(objectToString(resultSet.getString("Invoice1")));
            staging.setInvoiceCurrencyCode(objectToString(resultSet.getString("Currency_Code")));
            staging.setAccountNumber(objectToString(resultSet.getString("ACCOUNT_NUMBER")));
            staging.setLocation(objectToString(resultSet.getString("Location")));
            staging.setReceiptNumber(objectToString(resultSet.getString("RECEIPT_NUMBER")));
            staging.setAmount(objectToString(resultSet.getString("AMOUNT")));
            staging.setReceiptMethod(objectToString(resultSet.getString("NAME")));
            staging.setFileName(objectToString(resultSet.getString("file_name")));
           // staging.setReceiptStatus(resultSet.getString("Status"));
            stagingToList.add(staging);

        }
        System.out.println("Staging validation is"+ stagingToList);
        return stagingToList;
    }
    public List<String> sourceFilename(List<Staging> listStaging){

        return listStaging.stream()
                .map(staging -> "\'"+staging.getFileName()+"\'")
                .distinct()
                .collect(Collectors.toList());

    }

    public String sourceEmptyFilename() throws IOException {
        String emptyFileList=  applicationDetails.readProperties("com.uk.dlgds.proxy.ip.emptyFileList").trim();
        return emptyFileList;
    }

    private String objectToString(Object  obj) {
        if ( obj==null)
            return  "";
        else
            return  obj.toString();
    }
}
