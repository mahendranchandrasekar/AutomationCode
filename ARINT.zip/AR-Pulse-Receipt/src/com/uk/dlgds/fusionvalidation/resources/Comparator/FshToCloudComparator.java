package com.uk.dlgds.fusionvalidation.resources.Comparator;
import com.uk.dlgds.fusionvalidation.Utils.Output;
import com.uk.dlgds.fusionvalidation.Utils.Staging;
import com.uk.dlgds.fusionvalidation.Utils.ValuesWrapper;
import org.testng.collections.Sets;

import java.util.*;
import java.util.stream.Collectors;

public class FshToCloudComparator {

    private final FieldComparison fieldComparison = new FieldComparison();


    public ArrayList<ArrayList<String>> compareMatchValues(List<Staging> listStaging, List<Output> listOutput) {

        List<ValuesWrapper> resultSet = listStaging.stream()
                .map(p -> listOutput.stream()
                        .filter(sr -> p.getReceiptNumber().equalsIgnoreCase(sr.getReceiptNumber()))
                        .findFirst()
                        .map(q -> new ValuesWrapper(p, q))
                        .orElse(null))
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
        System.out.println("Resultset value is"+resultSet);

        return validateElements(resultSet);

    }
    public ArrayList<ArrayList<String>> compareMatchValues1(List<Staging> listStaging, List<Output> listOutput) {

        List<ValuesWrapper> resultSet = listStaging.stream()
                .map(p -> listOutput.stream()
                        .filter(sr ->  p.getReceiptNumber().equalsIgnoreCase(sr.getReceiptNumber()))
                        .findFirst()
                        .map(q -> new ValuesWrapper(p, q))
                        .orElse(null))
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
        System.out.println("Resultset value is"+resultSet);

        return validateElements1(resultSet);

    }

    public String compareNotMatchValues(List<Staging> listStaging, List<Output> listOutput) {

        List<ValuesWrapper> resultSet = listStaging.stream()
                .map(p -> listOutput.stream()
                        .filter(sr ->  p.getReceiptNumber().equalsIgnoreCase(sr.getReceiptNumber()))
                        .findFirst()
                        .map(q -> new ValuesWrapper(p, q))
                        .orElse(null))
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
        System.out.println("Resultset value is"+resultSet);


        Set<String> transactionPresentSet = Sets.newHashSet();
        for(ValuesWrapper model : resultSet) {
            transactionPresentSet.add(model.getStaging().getReceiptNumber());
        }

        Set<String> allTransactions = Sets.newHashSet();
        for(Staging transaction : listStaging) {
            allTransactions.add(transaction.getReceiptNumber());
        }

        allTransactions.removeAll(transactionPresentSet);

        List<String> aList = new ArrayList<>(allTransactions);

        for (String anAList : aList) {
            System.out.println(anAList);
        }

        return aList.stream()
                .map(strings -> "\'"+strings.trim()+"\'")
                .collect(Collectors.joining(","));


    }

    public String compareNotMatchValues1(List<Staging> listStaging, List<Output> listOutput) {

        List<ValuesWrapper> resultSet = listStaging.stream()
                .map(p -> listOutput.stream()
                        .filter(sr ->  p.getReceiptNumber().equalsIgnoreCase(sr.getReceiptNumber()))
                        .findFirst()
                        .map(q -> new ValuesWrapper(p, q))
                        .orElse(null))
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
        System.out.println("Resultset value is"+resultSet);


        Set<String> transactionPresentSet = Sets.newHashSet();
        for(ValuesWrapper model : resultSet) {
            transactionPresentSet.add(model.getStaging().getReceiptNumber());
        }

        Set<String> allTransactions = Sets.newHashSet();
        for(Staging transaction : listStaging) {
            allTransactions.add(transaction.getReceiptNumber());
        }

        allTransactions.removeAll(transactionPresentSet);

        List<String> aList = new ArrayList<>(allTransactions);

        for (String anAList : aList) {
            System.out.println(anAList);
        }

        return aList.stream()
                .map(strings -> "\'"+strings.trim()+"\'")
                .collect(Collectors.joining(","));


    }

    public String concatenateFSHValues(List<Staging> listStaging){


        return listStaging.stream()
                .map(staging -> "\'"+staging.getReceiptNumber()+"\'")
                .collect(Collectors.joining(","));
    }


    public List<String> receiptsLost(String[] missingRec, String[] missingRec1){
        List receiptsmissing=new ArrayList<>(Arrays.asList(missingRec));
        System.out.println("ReceiptsApplied Missing:"+receiptsmissing);
        List receiptsmissing1=new ArrayList<>(Arrays.asList(missingRec1));
        System.out.println("ReceiptsUnApplied Missing:"+receiptsmissing1);
        List<String> receiptsmissingfin=new ArrayList<String>(receiptsmissing);
        System.out.println("Receipts:" + receiptsmissingfin);
        receiptsmissingfin.retainAll(receiptsmissing1);
        System.out.println("Receiptslost:" + receiptsmissingfin);
         return(receiptsmissingfin);

          }





   private   ArrayList<ArrayList<String>> validateElements(List<ValuesWrapper> resultSet){
         ArrayList<ArrayList<String>> compareListResults = new ArrayList<>();


        for(ValuesWrapper stagingValues : resultSet ){


                if (stagingValues.getStaging().getReceiptNumber().equalsIgnoreCase(stagingValues.getOutput().getReceiptNumber()) )
                    compareListResults.add(fieldComparison.compareElements(stagingValues.getStaging(), stagingValues.getOutput()));
             }

        return compareListResults;
    }

     private ArrayList<ArrayList<String>> validateElements1(List<ValuesWrapper> resultSet){

        ArrayList<ArrayList<String>> compareListResults1 = new ArrayList<>();
        for(ValuesWrapper stagingValues : resultSet ){

            if(stagingValues.getStaging().getReceiptNumber().equalsIgnoreCase( stagingValues.getOutput().getReceiptNumber()) )
                 compareListResults1.add(fieldComparison.compareElements(stagingValues.getStaging(),stagingValues.getOutput()));

        }

        return compareListResults1;
    }

}