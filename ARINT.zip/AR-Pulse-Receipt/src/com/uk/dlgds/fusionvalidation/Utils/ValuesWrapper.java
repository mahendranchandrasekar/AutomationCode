package com.uk.dlgds.fusionvalidation.Utils;

import lombok.Data;

@Data
public class ValuesWrapper {

    public Output getOutput() {
        return output;
    }

    public void setOutput(Output output) {
        this.output = output;
    }

    public Staging getStaging() {
        return staging;
    }

    public void setStaging(Staging staging) {
        this.staging = staging;
    }

    private Output output;
    private Staging staging;

    public ValuesWrapper(Staging staging, Output output) {

        this.output =output;
        this.staging=staging;
    }
}
