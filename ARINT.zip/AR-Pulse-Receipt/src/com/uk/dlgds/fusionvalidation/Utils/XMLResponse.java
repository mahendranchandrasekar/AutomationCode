package com.uk.dlgds.fusionvalidation.Utils;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@RequiredArgsConstructor(staticName = "of")
@JacksonXmlRootElement(localName = "ROWSET")
public class XMLResponse {

    public String getpQuery() {
        return pQuery;
    }

    public void setpQuery(String pQuery) {
        this.pQuery = pQuery;
    }

    public List<com.uk.dlgds.fusionvalidation.Utils.Output> getOutput() {
        return Output;
    }

    public void setOutput(List<com.uk.dlgds.fusionvalidation.Utils.Output> output) {
        Output = output;
    }

    @JacksonXmlProperty(localName = "P_QUERY")
    private  String pQuery;

    @JacksonXmlProperty(localName = "Output")
    @JacksonXmlElementWrapper(useWrapping = false)
    private List<Output> Output = new ArrayList<>();

}
