package com.uk.dlgds.fusionvalidation.Utils;


import lombok.Data;

@Data
public class Staging {

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getTrxNumber() {
        return trxNumber;
    }

    public void setTrxNumber(String trxNumber) {
        this.trxNumber = trxNumber;
    }

    public String getAccountNumber() {
        return AccountNumber;
    }

    public void setAccountNumber(String AccountNumber) {
        this.AccountNumber = AccountNumber;
    }

    public String getLocation() {
        return Location;
    }

    public void setLocation(String Location) {
        this.Location = Location;
    }

    public String getInvoiceCurrencyCode() {
        return invoiceCurrencyCode;
    }

    public void setInvoiceCurrencyCode(String invoiceCurrencyCode) {
        this.invoiceCurrencyCode = invoiceCurrencyCode;
    }

    public String getReceiptNumber() {
        return ReceiptNumber;
    }

    public void setReceiptNumber(String ReceiptNumber) {
        this.ReceiptNumber = ReceiptNumber;
    }

    public String getAmount() {
        return Amount;
    }

    public void setAmount(String Amount) {
        this.Amount = Amount;
    }

    public String getReceiptMethod() {
        return ReceiptMethod;
    }

    public void setReceiptMethod(String ReceiptMethod) {
        this.ReceiptMethod = ReceiptMethod;
    }


    private String fileName;
    private String trxNumber;
    private String AccountNumber;
    private String Location;
    private String invoiceCurrencyCode;
    private String ReceiptNumber;
    private String Amount;
    private String ReceiptMethod;




}
