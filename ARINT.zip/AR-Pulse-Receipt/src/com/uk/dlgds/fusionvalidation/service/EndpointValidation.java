package com.uk.dlgds.fusionvalidation.service;


import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.uk.dlgds.fusionvalidation.Utils.Output;
import com.uk.dlgds.fusionvalidation.Utils.XMLResponse;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.net.HttpURLConnection;
import java.net.Proxy;
import java.net.URL;
import java.util.*;
import static javax.xml.parsers.DocumentBuilderFactory.*;

public class EndpointValidation {

    private final ApplicationDetails applicationDetails = new ApplicationDetails();

    public List<Output> triggerEndPoint(String query) throws IOException, ParserConfigurationException, SAXException, TransformerException {
        String runner = "JENKINS";
        String ip;

        if(System.getProperty("runner.name").equals(runner))
            ip = applicationDetails.readProperties("com.uk.dlgds.proxy.ip.jenkins").trim();
        else
            ip = applicationDetails.readProperties("com.uk.dlgds.proxy.ip").trim();

        Proxy proxy = new Proxy(Proxy.Type.HTTP,new InetSocketAddress(ip,8080));
        URL obj = new URL(applicationDetails.readProperties("com.uk.dlgds.endpoint.url"));
        HttpURLConnection con = (HttpURLConnection) obj.openConnection(proxy);
        con.setRequestMethod("POST");
        con.setRequestProperty("Content-Type", "application/soap+xml; charset=utf-8");
        con.setRequestProperty("Authorization", "Basic "+ encodeCredentials());
        con.setDoOutput(true);
        DataOutputStream wr = new DataOutputStream(con.getOutputStream());
        wr.writeBytes(updateQuery(readInputXML(),query));
        wr.flush();
        wr.close();
        org.w3c.dom.Document document = convertStringToXMLDocument(readResponse(con).toString());
        String nodes = document.getElementsByTagName("ns2:runReportResponse").item(0).getTextContent();
        byte[] byteArray = Base64.getDecoder().decode(nodes.substring(0,nodes.length()-8));
        String output = new String(byteArray);
        System.out.println("output value is"+output);
        return unMarshallXML(output);
    }

    private org.w3c.dom.Document readInputXML() throws IOException, ParserConfigurationException, SAXException {
        org.w3c.dom.Document document ;
        try(InputStream stream = getClass().getClassLoader().getResourceAsStream("com/uk/dlgds/fusionvalidation/resources/samples/SampleRequest.xml")) {
            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
            document = docBuilder.parse(Objects.requireNonNull(stream));
        }
        return document;

    }

    private String encodeCredentials() throws IOException {

          return  Base64.getEncoder().encodeToString((applicationDetails.readProperties("com.uk.dlgds.username")+":"+
                  applicationDetails.readProperties("com.uk.dlgds.password")).getBytes(StandardCharsets.UTF_8));
    }

    private String updateQuery(org.w3c.dom.Document inputXML, String values) throws TransformerException {

        inputXML.getElementsByTagName("pub:item").item(1).setTextContent(values);
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();
        transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
        DOMSource source = new DOMSource(inputXML);
        StringWriter strWriter = new StringWriter();
        StreamResult result = new StreamResult(strWriter);
        transformer.transform(source, result);
        String output = strWriter.getBuffer().toString();
        output = output.replaceAll("[\\r\\n]", "");
        return output;

    }

    private StringBuffer readResponse(HttpURLConnection con) throws IOException {

        BufferedReader in ;
        if(con.getResponseCode() == 200)
        {
            System.out.println("Response code is "+ con.getResponseCode());
            in = new BufferedReader(new
                    InputStreamReader(con.getInputStream()));
        }
        else
        {
            System.out.println("Response code is not 200");
            System.out.println("Response code is "+ con.getResponseCode());
            in = new BufferedReader(new
                    InputStreamReader(con.getErrorStream()));
            System.exit(0);
        }
        String inputLine;
        StringBuffer response = new StringBuffer();
        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();
        return response;
    }

    private org.w3c.dom.Document  convertStringToXMLDocument(String xmlString) throws ParserConfigurationException, IOException, SAXException {

        DocumentBuilderFactory docBuilderFactory = newInstance();
        DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
        return docBuilder.parse(new InputSource(new StringReader(xmlString)));
    }

    private List<Output> unMarshallXML(String output){
        XmlMapper mapper = new XmlMapper();
        XMLResponse xmlResponse = null;
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        try {
            xmlResponse = mapper.readValue(output, XMLResponse.class);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return xmlResponse.getOutput();
    }
}
