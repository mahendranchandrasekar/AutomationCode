package com.uk.dlgds.fusionvalidation.Utils;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;


@Data
@RequiredArgsConstructor(staticName = "of")
@AllArgsConstructor(access = AccessLevel.PROTECTED)
public class Output {

    public String getTrxNumber() {
        return trxNumber;
    }

    public void setTrxNumber(String trxNumber) {
        this.trxNumber = objectToString(trxNumber);
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = objectToString(currencyCode);
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = objectToString(amount);
    }

    public String getAccountNumber() {
        return AccountNumber;
    }

    public void setAccountNumber(String AccountNumber) {
        this.AccountNumber = objectToString(AccountNumber);
    }

    public String getReceiptNumber() {
        return ReceiptNumber;
    }

    public void setReceiptNumber(String ReceiptNumber) {
        this.ReceiptNumber = objectToString(ReceiptNumber);
    }
    public String getLocation() {
        return Location;
    }

    public void setLocation(String Location) {
        this.Location = objectToString(Location);
    }
    public String getReceiptMethod() {
        return ReceiptMethod;
    }

    public void setReceiptMethod(String ReceiptMethod) {
        this.ReceiptMethod = objectToString(ReceiptMethod);
    }


    @JacksonXmlProperty(localName ="TRX_NUMBER")
    private String trxNumber;
    @JacksonXmlProperty(localName ="ACCOUNT_NUMBER")
    private String AccountNumber;
    @JacksonXmlProperty(localName ="LOCATION")
    private String Location;
    @JacksonXmlProperty(localName ="RECEIPT_NUMBER")
    private String ReceiptNumber;
    @JacksonXmlProperty(localName ="NAME")
    private String ReceiptMethod;
    @JacksonXmlProperty(localName ="CURRENCY_CODE")
    private String currencyCode;
    @JacksonXmlProperty(localName ="AMOUNT")
    private String amount;


    private String objectToString(Object  obj) {
        if ( obj==null)
            return  "";
        else
            return  obj.toString();
    }

}
