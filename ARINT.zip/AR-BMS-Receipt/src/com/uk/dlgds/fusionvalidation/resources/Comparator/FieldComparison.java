package com.uk.dlgds.fusionvalidation.resources.Comparator;

import com.uk.dlgds.fusionvalidation.Utils.Output;
import com.uk.dlgds.fusionvalidation.Utils.Staging;

import java.util.ArrayList;


class FieldComparison {



     ArrayList<String> compareElements(Staging stagingValues, Output outputValues){
        ArrayList<String> validatedResults = new ArrayList<>();

          if (stagingValues.getTrxNumber().equalsIgnoreCase(outputValues.getTrxNumber()))
              validatedResults.add("1~" + "TRX_NUMBER~" + stagingValues.getTrxNumber() + "~" + outputValues.getTrxNumber() + "~" + "Pass");
          else
              validatedResults.add("1~" + "TRX_NUMBER~" + stagingValues.getTrxNumber() + "~" + outputValues.getTrxNumber() + "~" + "Fail");


        if(stagingValues.getInvoiceCurrencyCode().equalsIgnoreCase(outputValues.getCurrencyCode()))
            validatedResults.add("2~"+"INVOICE_CURRENCY_CODE~"+stagingValues.getInvoiceCurrencyCode()+"~"+ outputValues.getCurrencyCode()+"~"+"Pass");
        else
            validatedResults.add("2~"+"INVOICE_CURRENCY_CODE~"+stagingValues.getInvoiceCurrencyCode()+"~"+ outputValues.getCurrencyCode()+"~"+"Fail");

        if(stagingValues.getAccountNumber().equalsIgnoreCase(outputValues.getAccountNumber()))
            validatedResults.add("3~"+"ACCOUNT_NUMBER~"+stagingValues.getAccountNumber()+"~"+ outputValues.getAccountNumber()+"~"+"Pass");
        else
            validatedResults.add("3~"+"ACCOUNT_NUMBER~"+stagingValues.getAccountNumber()+"~"+ outputValues.getAccountNumber()+"~"+"Fail");

        if(stagingValues.getLocation().equalsIgnoreCase(outputValues.getLocation()))
            validatedResults.add("4~"+"Location~"+stagingValues.getLocation()+"~"+ outputValues.getLocation()+"~"+"Pass");
        else
            validatedResults.add("4~"+"Location~"+stagingValues.getLocation()+"~"+ outputValues.getLocation()+"~"+"Fail");

        if(stagingValues.getReceiptNumber().equalsIgnoreCase(outputValues.getReceiptNumber()))
            validatedResults.add("5~"+"RECEIPT_NUMBER~"+stagingValues.getReceiptNumber()+"~"+ outputValues.getReceiptNumber()+"~"+"Pass");
        else
            validatedResults.add("5~"+"RECEIPT_NUMBER~"+stagingValues.getReceiptNumber()+"~"+ outputValues.getReceiptNumber()+"~"+"Fail");

        if(stagingValues.getAmount().equalsIgnoreCase(outputValues.getAmount()))
            validatedResults.add("6~"+"AMOUNT~"+stagingValues.getAmount()+"~"+ outputValues.getAmount()+"~"+"Pass");
        else
            validatedResults.add("6~"+"AMOUNT~"+stagingValues.getAmount()+"~"+ outputValues.getAmount()+"~"+"Fail");

        if(stagingValues.getReceiptMethod().equalsIgnoreCase(outputValues.getReceiptMethod()))
            validatedResults.add("7~"+"NAME~"+stagingValues.getReceiptMethod()+"~"+ outputValues.getReceiptMethod()+"~"+"Pass");
        else
            validatedResults.add("7~"+"NAME~"+stagingValues.getReceiptMethod()+"~"+ outputValues.getReceiptMethod()+"~"+"Fail");

        System.out.println(validatedResults.size());
        return validatedResults;

    }
}
