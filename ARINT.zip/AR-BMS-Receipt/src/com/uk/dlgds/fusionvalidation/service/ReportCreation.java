package com.uk.dlgds.fusionvalidation.service;


import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

public class ReportCreation {
    private int passCount = 0;
    private int failCount = 0;
    private String dateFormatReportName = "yyyy_MM_dd_HH_mm_ss";
    private static String fileNameTestReport;
    private static String fileNameTestReportDate;
    BufferedWriter bufferedWriter;

    public ReportCreation() throws IOException {
        String runner = "JENKINS";
        cleanReport();

        DateFormat dateFormat = new SimpleDateFormat(dateFormatReportName);
        Date date = new Date();
        if(System.getProperty("runner.name").equals(runner))
            fileNameTestReport = "./AR-BMS-Receipt.html";
         else
             fileNameTestReport = "AR-BMS-Receipt_" + dateFormat.format(date) + ".html";
        File file =  new File(fileNameTestReport);
        DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("yyyy_MM_dd HH:mm:ss");
        LocalDateTime now1 = LocalDateTime.now();
        String currentSystemDate = dtf1.format(now1);
        bufferedWriter = new BufferedWriter(new FileWriter(file,true));
        bufferedWriter.append("<!DOCTYPE html>" + "<html>" + "<head> <meta charset='UTF-8'>" + "<title>ORACLE APPLICATIONS CLOUD - AR_BMS_Receipts Automation Execution Results</title>" + "<body style ='background-color: #CBE1BB;margin-top: 30px'>" + "<table id='header' align='center' style ='background-color: #A9D0F5'>" + "<thead>" + "<tr class='heading' style ='width:400px; background-color: #A9D0F5; align:center'>" + "<th colspan='4' style='font-family:Copperplate Gothic; font-size:1.4em;'>" + "ORACLE APPLICATIONS CLOUD - AR_BMS_Receipts Automation Execution Results" + "</th>" + "</tr>" + "<tr class='subheading' style ='width:300px; font-family:Copperplate Gothic; background-color: #E0E6F8; color: #34495E; font-weight: bold; font-size: 1em;text-align: justify;'>" + "<th>&nbsp;Date&nbsp;&&nbsp;Time</th>" + "<th>&nbsp;:&nbsp;").append(currentSystemDate).append("&nbsp;PM</th>").append("</tr>").append("<tr class='subheading' style ='width:300px;font-family:Copperplate Gothic;background-color: #E0E6F8; color: #34495E; font-weight: bold; font-size: 1em; text-align: justify'>").append("<th>&nbsp;Interface&nbsp;</th>").append("<th>&nbsp;:&nbsp;ARReceipts&nbsp;</th>").append("</tr>").append("<tr class='subheading' style ='width:300px;font-family:Copperplate Gothic;background-color: #E0E6F8; color: #34495E; font-weight: bold; font-size: 1em; text-align: justify'>").append("<th>&nbsp;Environment&nbsp;</th>").append("<th>&nbsp;:&nbsp;BVT&nbsp;</th>").append("</tr>").append("</thead></table>");
        bufferedWriter.append("</table> </body> </html>");
        bufferedWriter.append("<br><br><br>");
        bufferedWriter.append("</table> </body> </html>");
        bufferedWriter.close();

    }

    public void cleanReport()  {
        File file =  new File( "AR-BMS-Receipt.html");
        file.delete();
    }

    public void createCompareSection(ArrayList<ArrayList<String>> results, String section, String fileName, String eventID, String reportName, String header_name) throws IOException {
        File file = new File(fileNameTestReport);
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(file, true));
        if (section.equals("Section1")) {
            for(ArrayList list : results){

         //   bufferedWriter.append("<table class='heading' style ='background-color: #A9D0F5; align:center;border:2px solid #A9D0F5'>" + " <thead>" + " <tr class='heading'  style ='width:400px; background-color: #A9D0F5; align:center;border:2px solid #A9D0F5'>" + "<table id='sub' align='center' border=\"2\" cellspacing=\"0\" cellpadding=\"4\" style='width:90%;background-color: #A9D0F5;align:center;border: 2px solid #A9D0F5'>" + "<tr>" + "<td colspan=\"3\" style = 'background-color: #E0E6F8;width:300px;font-family:Copperplate Gothic;font-weight: bold; font-size: 1.0em;text-align: center;border: 2px solid #A9D0F5;'>File Name:\t ").append(fileName).append("<td colspan=\"3\" style = 'background-color: #E0E6F8;width:300px;font-family:Copperplate Gothic;font-weight: bold; font-size: 1.0em;text-align: center;border: 2px solid #A9D0F5;'>Transaction Number:\t").append(eventID).append("</td><td</td>").append("</tr>").append("<tr>").append("<th width=\"10%\" border=\"2\" style = 'background-color: #A9D0F5;font-family:Copperplate Gothic;font-weight: bold; font-size: 1em;text-align: center;border: 2px solid #A9D0F5;'>S.No</th>").append("<th width=\"25%\" border=\"2\" style = 'background-color: #A9D0F5;font-family:Copperplate Gothic;font-weight: bold; font-size: 1em;text-align: center;border: 2px solid #A9D0F5;'>Field Name</th>").append("<th width=\"25%\" border=\"2\" style = 'background-color: #A9D0F5;font-family:Copperplate Gothic;font-weight: bold; font-size: 1em;text-align: center;border: 2px solid #A9D0F5;'>Expected Value</th>").append("<th width=\"20%\" border=\"2\" style = 'background-color: #A9D0F5;font-family:Copperplate Gothic;font-weight: bold; font-size: 1em;text-align: center;border: 2px solid #A9D0F5;'>Actual Value</th>").append("<th width=\"15%\" border=\"2\" style = 'background-color: #A9D0F5;font-family:Copperplate Gothic;font-weight: bold; font-size: 1em;text-align: center;border: 2px solid #A9D0F5;'>Test Status</th>").append("</tr>").append(" </thead>");

                bufferedWriter.append("<table class='heading' style ='background-color: #A9D0F5; align:center;border:2px solid #A9D0F5'>" + " <thead>" + " <tr class='heading'  style ='width:400px; background-color: #A9D0F5; align:center;border:2px solid #A9D0F5'>" + "<table id='sub' align='center' border=\"2\" cellspacing=\"0\" cellpadding=\"4\" style='width:90%;background-color: #A9D0F5;align:center;border: 2px solid #A9D0F5'>" + "<tr>" + "<td colspan=\"3\" style = 'background-color: #E0E6F8;width:300px;font-family:Copperplate Gothic;font-weight: bold; font-size: 1.0em;text-align: center;border: 2px solid #A9D0F5;'>\t ").append(fileName).append("<td colspan=\"3\" style = 'background-color: #E0E6F8;width:300px;font-family:Copperplate Gothic;font-weight: bold; font-size: 1.0em;text-align: center;border: 2px solid #A9D0F5;'>\t").append(eventID).append("</td><td</td>").append("</tr>").append("<tr>").append("<th width=\"10%\" border=\"2\" style = 'background-color: #A9D0F5;font-family:Copperplate Gothic;font-weight: bold; font-size: 1em;text-align: center;border: 2px solid #A9D0F5;'>S.No</th>").append("<th width=\"25%\" border=\"2\" style = 'background-color: #A9D0F5;font-family:Copperplate Gothic;font-weight: bold; font-size: 1em;text-align: center;border: 2px solid #A9D0F5;'>Field Name</th>").append("<th width=\"25%\" border=\"2\" style = 'background-color: #A9D0F5;font-family:Copperplate Gothic;font-weight: bold; font-size: 1em;text-align: center;border: 2px solid #A9D0F5;'>Expected Value</th>").append("<th width=\"20%\" border=\"2\" style = 'background-color: #A9D0F5;font-family:Copperplate Gothic;font-weight: bold; font-size: 1em;text-align: center;border: 2px solid #A9D0F5;'>Actual Value</th>").append("<th width=\"15%\" border=\"2\" style = 'background-color: #A9D0F5;font-family:Copperplate Gothic;font-weight: bold; font-size: 1em;text-align: center;border: 2px solid #A9D0F5;'>Test Status</th>").append("</tr>").append(" </thead>");

                for (Object object : list) {
                String expResult = (String) object;
                String[] expValues = expResult.split("~");
                bufferedWriter.append("<tr>");
                for (int j = 0; j < expValues.length; j++) {
                    if (expValues[j].equals("Pass")) {
                        passCount++;
                    } else if (expValues[j].equals("Fail")) {
                        failCount++;
                    }
                    if ((j == expValues.length - 1) && expValues[j].equals("Fail")) {
                        bufferedWriter.append("<td align=\"center\" style = 'background-color: #EDEEF0;font-family:Copperplate Gothic text-align: center;border: 2px solid #A9D0F5;color: red; font-weight: bold'>").append(expValues[j]).append("</td> ");
                    } else if (((j == expValues.length - 1) && expValues[j].equals("Pass"))) {
                        bufferedWriter.append("<td align=\"center\" style = 'background-color: #EDEEF0;font-family:Copperplate Gothic text-align: center;border: 2px solid #A9D0F5;color: green;font-weight: bold'>").append(expValues[j]).append("</td> ");
                    } else if ((j == expValues.length - 1) && ((!expValues[j].equals("Fail")) || (!expValues[j].equals("Pass")))) {
                        bufferedWriter.append("<td width=\"20%\" align=\"left\" style = 'background-color: #EDEEF0;font-family:Copperplate Gothic text-align: center;border: 2px solid #A9D0F5;color: red';font-weight: bold>").append(expValues[j]).append("</td> ");
                    } else {
                        bufferedWriter.append("<td align=\"center\"  style = 'background-color: #EDEEF0;font-family:Copperplate Gothic text-align: center;border: 2px solid #A9D0F5;'>").append(expValues[j]).append("</td> ");
                    }
                }
                bufferedWriter.append("</tr>");

            }
            }
           // bufferedWriter.append("</tr><td colspan=\"3\" style = 'background-color: #A9D0F5;width:300px;font-family:Copperplate Gothic;font-weight: bold; font-size: 1.0em;text-align: left;border: 2px solid #A9D0F5;'>Total Verification:").append(String.valueOf(list.size())).append("</td><td</td><td</td><td style = 'background-color: #A9D0F5;font-family:Copperplate Gothic;font-weight: bold;width:300px;font-size: 1.0em;text-align: center;border: 2px solid #A9D0F5;'> Total Pass :").append(String.valueOf(passCount)).append("</td><td style = 'background-color: #A9D0F5;font-family:Copperplate Gothic;width:300px;font-weight: bold; font-size: 1.0em;text-align: center;border: 2px solid #A9D0F5;'> Total Fail: ").append(String.valueOf(failCount)).append("</td>");
            bufferedWriter.append("</table> </body> </html>");
            bufferedWriter.append("<br><br><br>");
            passCount = 0;
            failCount = 0;
        }
        bufferedWriter.append("</table> </body> </html>");
        bufferedWriter.close();
    }

    public void createDisplaySection(List list, String section, String fileName, String eventID, String reportName, String header_name) throws IOException {


        File file = new File(fileNameTestReport);
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(file, true));
        if (section.equals("Section1")) {
            bufferedWriter.append("<table class='heading' style ='background-color: #A9D0F5; align:center;border:2px solid #A9D0F5'>" + " <thead>" + " <tr class='heading'  style ='width:400px; background-color: #A9D0F5; align:center;border:2px solid #A9D0F5'>" + "<table id='sub' align='center' border=\"2\" cellspacing=\"0\" cellpadding=\"4\" style='width:90%;background-color: #A9D0F5;align:center;border: 2px solid #A9D0F5'>" + "<tr>" + "<td colspan=\"3\" style = 'background-color: #E0E6F8;width:300px;font-family:Copperplate Gothic;font-weight: bold; font-size: 1.0em;text-align: center;border: 2px solid #A9D0F5;'> \t ").append(fileName).append("</td><td</td>").append("</tr>").append("<tr>").append("<th width=\"50%\" border=\"2\" style = 'background-color: #A9D0F5;font-family:Copperplate Gothic;font-weight: bold; font-size: 1em;text-align: center;border: 2px solid #A9D0F5;'>Field Name</th>").append("<th width=\"50%\" border=\"2\" style = 'background-color: #A9D0F5;font-family:Copperplate Gothic;font-weight: bold; font-size: 1em;text-align: center;border: 2px solid #A9D0F5;'>Values</th>").append("</tr>").append(" </thead>");
            if (!(list == null)){
                for (Object object : list) {
                    String expResult = (String) object;
                    String[] expValues = expResult.split(":");
                    bufferedWriter.append("<tr>");
                    for (String expValue : expValues) {
                        bufferedWriter.append("<td align=\"center\"  style = 'background-color: #EDEEF0;font-family:Copperplate Gothic text-align: center;border: 2px solid #A9D0F5;'>").append(expValue).append("</td> ");
                    }
                    bufferedWriter.append("</tr>");
                }
        }


            bufferedWriter.append("</table> </body> </html>");
            bufferedWriter.append("<br><br><br>");
        }

        bufferedWriter.append("</table> </body> </html>");
        bufferedWriter.close();
    }

    public void createDisplayTransactionLost(Set<String> transactionLost, String section, String fileName, String eventID, String reportName, String header_name) throws IOException {


        File file = new File(fileNameTestReport);
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(file, true));
        if (section.equals("Section1")) {
            bufferedWriter.append("<table class='heading' style ='background-color: #A9D0F5; align:center;border:2px solid #A9D0F5'>" + " <thead>" + " <tr class='heading'  style ='width:400px; background-color: #A9D0F5; align:center;border:2px solid #A9D0F5'>" + "<table id='sub' align='center' border=\"2\" cellspacing=\"0\" cellpadding=\"4\" style='width:90%;background-color: #A9D0F5;align:center;border: 2px solid #A9D0F5'>" + "<tr>" + "<td colspan=\"3\" style = 'background-color: #E0E6F8;width:300px;font-family:Copperplate Gothic;font-weight: bold; font-size: 1.0em;text-align: center;border: 2px solid #A9D0F5;'> \t ").append(fileName).append("</td><td</td>").append("</tr>").append("<tr>").append("<th width=\"50%\" border=\"2\" style = 'background-color: #A9D0F5;font-family:Copperplate Gothic;font-weight: bold; font-size: 1em;text-align: center;border: 2px solid #A9D0F5;'>Field Name</th>").append("<th width=\"50%\" border=\"2\" style = 'background-color: #A9D0F5;font-family:Copperplate Gothic;font-weight: bold; font-size: 1em;text-align: center;border: 2px solid #A9D0F5;'>Values</th>").append("</tr>").append(" </thead>");
            bufferedWriter.append("<tr>");
            if (!(transactionLost==null)){
                for (String aTransactionLost : transactionLost) {
                    bufferedWriter.append("<td align=\"center\"  style = 'background-color: #EDEEF0;font-family:Copperplate Gothic text-align: center;border: 2px solid #A9D0F5;'>").append("Receipt Number").append("</td> ");
                    bufferedWriter.append("<td align=\"center\"  style = 'background-color: #EDEEF0;font-family:Copperplate Gothic text-align: center;border: 2px solid #A9D0F5;'>").append(aTransactionLost).append("</td> ");
                    bufferedWriter.append("</tr>");
                }
            bufferedWriter.append("</tr>");

            bufferedWriter.append("</table> </body> </html>");
            bufferedWriter.append("<br><br><br>");
        }
    }
        bufferedWriter.append("</table> </body> </html>");
        bufferedWriter.close();
    }
    public void createDisplayReceiptsLost( List<String> receiptsLost, String section, String fileName, String eventID, String reportName, String header_name) throws IOException {

        File file = new File(fileNameTestReport);
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(file, true));
        if (section.equals("Section1")) {
            bufferedWriter.append("<table class='heading' style ='background-color: #A9D0F5; align:center;border:2px solid #A9D0F5'>" + " <thead>" + " <tr class='heading'  style ='width:400px; background-color: #A9D0F5; align:center;border:2px solid #A9D0F5'>" + "<table id='sub' align='center' border=\"2\" cellspacing=\"0\" cellpadding=\"4\" style='width:90%;background-color: #A9D0F5;align:center;border: 2px solid #A9D0F5'>" + "<tr>" + "<td colspan=\"3\" style = 'background-color: #E0E6F8;width:300px;font-family:Copperplate Gothic;font-weight: bold; font-size: 1.0em;text-align: center;border: 2px solid #A9D0F5;'> \t ").append(fileName).append("</td><td</td>").append("</tr>").append("<tr>").append("<th width=\"50%\" border=\"2\" style = 'background-color: #A9D0F5;font-family:Copperplate Gothic;font-weight: bold; font-size: 1em;text-align: center;border: 2px solid #A9D0F5;'>Field Name</th>").append("<th width=\"50%\" border=\"2\" style = 'background-color: #A9D0F5;font-family:Copperplate Gothic;font-weight: bold; font-size: 1em;text-align: center;border: 2px solid #A9D0F5;'>Values</th>").append("</tr>").append(" </thead>");
            bufferedWriter.append("<tr>");
            if (!(receiptsLost==null)){
                for (String aReceiptsLost : receiptsLost) {
                    bufferedWriter.append("<td align=\"center\"  style = 'background-color: #EDEEF0;font-family:Copperplate Gothic text-align: center;border: 2px solid #A9D0F5;'>").append("Receipt Number").append("</td> ");
                    bufferedWriter.append("<td align=\"center\"  style = 'background-color: #EDEEF0;font-family:Copperplate Gothic text-align: center;border: 2px solid #A9D0F5;'>").append(aReceiptsLost).append("</td> ");
                    bufferedWriter.append("</tr>");
                }
                bufferedWriter.append("</tr>");

                bufferedWriter.append("</table> </body> </html>");
                bufferedWriter.append("<br><br><br>");
            }
        }
        bufferedWriter.append("</table> </body> </html>");
        bufferedWriter.close();
    }
    public void createDisplayFileName( List<String> FileName, String section, String fileName, String eventID, String reportName, String header_name) throws IOException {


        File file = new File(fileNameTestReport);
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(file, true));
        if (section.equals("Section1")) {
            bufferedWriter.append("<table class='heading' style ='background-color: #A9D0F5; align:center;border:2px solid #A9D0F5'>" + " <thead>" + " <tr class='heading'  style ='width:400px; background-color: #A9D0F5; align:center;border:2px solid #A9D0F5'>" + "<table id='sub' align='center' border=\"2\" cellspacing=\"0\" cellpadding=\"4\" style='width:90%;background-color: #A9D0F5;align:center;border: 2px solid #A9D0F5'>" + "<tr>" + "<td colspan=\"3\" style = 'background-color: #E0E6F8;width:300px;font-family:Copperplate Gothic;font-weight: bold; font-size: 1.0em;text-align: center;border: 2px solid #A9D0F5;'> \t ").append(fileName).append("</td><td</td>").append("</tr>").append("<tr>").append("<th width=\"50%\" border=\"2\" style = 'background-color: #A9D0F5;font-family:Copperplate Gothic;font-weight: bold; font-size: 1em;text-align: center;border: 2px solid #A9D0F5;'>Field Name</th>").append("<th width=\"50%\" border=\"2\" style = 'background-color: #A9D0F5;font-family:Copperplate Gothic;font-weight: bold; font-size: 1em;text-align: center;border: 2px solid #A9D0F5;'>Values</th>").append("</tr>").append(" </thead>");
            bufferedWriter.append("<tr>");
            if (!(FileName==null)){
                for (String aFileName : FileName) {
                    bufferedWriter.append("<td align=\"center\"  style = 'background-color: #EDEEF0;font-family:Copperplate Gothic text-align: center;border: 2px solid #A9D0F5;'>").append("File Name").append("</td> ");
                    bufferedWriter.append("<td align=\"center\"  style = 'background-color: #EDEEF0;font-family:Copperplate Gothic text-align: center;border: 2px solid #A9D0F5;'>").append(aFileName).append("</td> ");
                    bufferedWriter.append("</tr>");
                }
                bufferedWriter.append("</tr>");

                bufferedWriter.append("</table> </body> </html>");
                bufferedWriter.append("<br><br><br>");
            }
        }
        bufferedWriter.append("</table> </body> </html>");
        bufferedWriter.close();
    }

    public void createDisplayEmptyFileName(String FileName, String section, String fileName, String eventID, String reportName, String header_name) throws IOException {


        File file = new File(fileNameTestReport);
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(file, true));
        if (section.equals("Section1")) {
            bufferedWriter.append("<table class='heading' style ='background-color: #A9D0F5; align:center;border:2px solid #A9D0F5'>" + " <thead>" + " <tr class='heading'  style ='width:400px; background-color: #A9D0F5; align:center;border:2px solid #A9D0F5'>" + "<table id='sub' align='center' border=\"2\" cellspacing=\"0\" cellpadding=\"4\" style='width:90%;background-color: #A9D0F5;align:center;border: 2px solid #A9D0F5'>" + "<tr>" + "<td colspan=\"3\" style = 'background-color: #E0E6F8;width:300px;font-family:Copperplate Gothic;font-weight: bold; font-size: 1.0em;text-align: center;border: 2px solid #A9D0F5;'> \t ").append(fileName).append("</td><td</td>").append("</tr>").append("<tr>").append("<th width=\"50%\" border=\"2\" style = 'background-color: #A9D0F5;font-family:Copperplate Gothic;font-weight: bold; font-size: 1em;text-align: center;border: 2px solid #A9D0F5;'>Field Name</th>").append("<th width=\"50%\" border=\"2\" style = 'background-color: #A9D0F5;font-family:Copperplate Gothic;font-weight: bold; font-size: 1em;text-align: center;border: 2px solid #A9D0F5;'>Values</th>").append("</tr>").append(" </thead>");
            bufferedWriter.append("<tr>");

            bufferedWriter.append("<td align=\"center\"  style = 'background-color: #EDEEF0;font-family:Copperplate Gothic text-align: center;border: 2px solid #A9D0F5;'>").append("File Name").append("</td> ");
            bufferedWriter.append("<td align=\"center\"  style = 'background-color: #EDEEF0;font-family:Copperplate Gothic text-align: center;border: 2px solid #A9D0F5;'>").append(FileName).append("</td> ");
            bufferedWriter.append("</tr>");

            bufferedWriter.append("</tr>");

            bufferedWriter.append("</table> </body> </html>");
            bufferedWriter.append("<br><br><br>");

        }
        bufferedWriter.append("</table> </body> </html>");
        bufferedWriter.close();
    }
}
