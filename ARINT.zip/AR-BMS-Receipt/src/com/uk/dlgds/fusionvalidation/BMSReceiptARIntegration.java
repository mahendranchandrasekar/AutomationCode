package com.uk.dlgds.fusionvalidation;

import com.uk.dlgds.fusionvalidation.Utils.Output;
import com.uk.dlgds.fusionvalidation.Utils.Staging;
import com.uk.dlgds.fusionvalidation.resources.Comparator.FshToCloudComparator;
import com.uk.dlgds.fusionvalidation.resources.datasource.DatabaseConnect;
import com.uk.dlgds.fusionvalidation.resources.datasource.StgValidations;
import com.uk.dlgds.fusionvalidation.service.ApplicationDetails;
import com.uk.dlgds.fusionvalidation.service.EndpointValidation;
import com.uk.dlgds.fusionvalidation.service.ReportCreation;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.*;


public class BMSReceiptARIntegration {

private final ApplicationDetails applicationDetails = new ApplicationDetails();
private final EndpointValidation endpointValidation = new EndpointValidation();
private final DatabaseConnect databaseConnect = new DatabaseConnect();
private final StgValidations stgValidations = new StgValidations();
private final FshToCloudComparator fshToCloudComparator = new FshToCloudComparator();

private ReportCreation reportCreation;

    {
        try {
            reportCreation = new ReportCreation();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


@Test
public void accountReceivables() throws IOException,  ParserConfigurationException, SAXException, TransformerException, SQLException, ClassNotFoundException {
    final String journalPath = "com/uk/dlgds/fusionvalidation/resources/queries/Account-Receipts.json";
    List<String> receiptsLost = null;


        if(applicationDetails.readProperties("com.uk.dlgds.fshValidation").equalsIgnoreCase("yes")) {

            List<Staging> stagingToList = databaseConnect.createConnection(applicationDetails.readJournalFile(journalPath),
                    "fsh-customer-query");


            List<String> FileName = stgValidations.sourceFilename(stagingToList);

            if (FileName.isEmpty()) {
                String emptyFileName = stgValidations.sourceEmptyFilename();
                System.out.println("Empty files : " + emptyFileName);
                reportCreation.createDisplayEmptyFileName(emptyFileName, "Section1", "Source FSH FileName", "EVENT_ID", "Report_Name", "Header_Name");
            } else {

                List<Output> oracleWebservice = endpointValidation.triggerEndPoint(applicationDetails.readJournalFile(journalPath)
                        .getJSONObject("Query")
                        .getString("cloud-fsh-ra-customer-trx-all-query")
                        .replace("concatenatetrxnumber", fshToCloudComparator
                                .concatenateFSHValues(stagingToList)));


                // Validating match records
                ArrayList<ArrayList<String>> compareResults = fshToCloudComparator.compareMatchValues(stagingToList, oracleWebservice);
                String missingUnapplyReceipts = fshToCloudComparator.compareNotMatchValues(stagingToList, oracleWebservice);
                System.out.println("missingUnapplyReceipts:" + missingUnapplyReceipts);

                List<Output> oracleWebservice1 = endpointValidation.triggerEndPoint(applicationDetails.readJournalFile(journalPath)
                        .getJSONObject("Query")
                        .getString("cloud-unapplied-receipts-query")
                        .replace("unapply Receipts", missingUnapplyReceipts));
                // Validating match records
                ArrayList<ArrayList<String>> compareResults1 = fshToCloudComparator.compareMatchValues1(stagingToList, oracleWebservice1);

                String missingTxn1 = fshToCloudComparator.compareNotMatchValues1(stagingToList, oracleWebservice1);//Second Query
                String missingTxn = fshToCloudComparator.compareNotMatchValues(stagingToList, oracleWebservice);//First Query

                if (!missingTxn1.equals("") && !missingTxn.equals("")) {
                    String missingRec1[] = missingTxn1.split(",");
                    String missingRec[] = missingTxn.split(",");
                    receiptsLost = fshToCloudComparator.receiptsLost(missingRec, missingRec1);

                }
                reportCreation.createDisplayFileName(FileName, "Section1", "Source FSH File Name", "EVENT_ID", "Report_Name", "Header_Name");
                reportCreation.createCompareSection(compareResults, "Section1", "Applied Receipts successfully processed from FSH to Cloud", "Reporting ", "Report_Name", "Header_Name");
                reportCreation.createCompareSection(compareResults1, "Section1", "UnApplied Receipts successfully processed from FSH to Cloud", "Reporting ", "Report_Name", "Header_Name");
                reportCreation.createDisplayReceiptsLost(receiptsLost, "Section1", "Receipts lost between FSH and Cloud", "EVENT_ID", "Report_Name", "Header_Name");

            }
        }
    }



}