package com.uk.dlgds.fusionvalidation.resources.datasource;

import com.uk.dlgds.fusionvalidation.Utils.Staging;
import com.uk.dlgds.fusionvalidation.service.ApplicationDetails;
import org.json.JSONObject;

import java.io.IOException;
import java.sql.*;
import java.util.List;

public class DatabaseConnect {

    private final ApplicationDetails applicationDetails = new ApplicationDetails();
    private final StgValidations stgValidations = new StgValidations();

    public List<Staging> createConnection(JSONObject queryJson, String query) throws  SQLException, IOException {


        ResultSet resultSet;

        try(Connection connection =
                    DriverManager.getConnection(applicationDetails.readProperties("com.uk.dlgds.dbServer"),
                            applicationDetails.readProperties("com.uk.dlgds.dbUserName"),
                            applicationDetails.readProperties("com.uk.dlgds.dbPassword"))){
            Statement stmt=connection.createStatement();
            resultSet=stmt.executeQuery(queryJson.getJSONObject("Query").getString(query));
         return stgValidations.dbToJavaObject(resultSet);


        }


    }



}
