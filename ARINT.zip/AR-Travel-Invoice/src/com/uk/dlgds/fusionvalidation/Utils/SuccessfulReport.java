package com.uk.dlgds.fusionvalidation.Utils;

import java.util.HashMap;
import java.util.Map;

public class SuccessfulReport {

    protected Map<String, String> replaceValueMap = new HashMap<>();
    private String trxNumberFshValue;
    private String invoiceCurrencyCodeFshValue;
    private String attributeCategoryFshValue;
    private String attribute1FshValue;
    private String attribute2FshValue;
    private String attribute3FshValue;
    private String attribute4FshValue;
    private String attribute5FshValue;
    private String attribute6FshValue;
    private String attribute7FshValue;
    private String attribute8FshValue;
    private String attribute9FshValue;
    private String attribute10FshValue;
    private String attribute11FshValue;
    private String attribute12FshValue;
    private String attribute13FshValue;
    private String attribute14FshValue;
    private String attribute15FshValue;
    private String interfaceHeaderAttribute1FshValue;
    private String interfaceHeaderAttribute2FshValue;
    private String interfaceHeaderAttribute3FshValue;
    private String interfaceHeaderAttribute4FshValue;
    private String trxClassFshValue;



    private String trxNumberErpValue;
    private String invoiceCurrencyCodeErpValue;
    private String attributeCategoryErpValue;
    private String attribute1ErpValue;
    private String attribute2ErpValue;
    private String attribute3ErpValue;
    private String attribute4ErpValue;
    private String attribute5ErpValue;
    private String attribute6ErpValue;
    private String attribute7ErpValue;
    private String attribute8ErpValue;
    private String attribute9ErpValue;
    private String attribute10ErpValue;
    private String attribute11ErpValue;
    private String attribute12ErpValue;
    private String attribute13ErpValue;
    private String attribute14ErpValue;
    private String attribute15ErpValue;
    private String interfaceHeaderAttribute1ErpValue;
    private String interfaceHeaderAttribute2ErpValue;
    private String interfaceHeaderAttribute3ErpValue;
    private String interfaceHeaderAttribute4ErpValue;
    private String trxClassErpValue;


    private String trxNumberResultValue;
    private String invoiceCurrencyCodeResultValue;
    private String attribute1ResultValue;
    private String attribute2ResultValue;
    private String attribute3ResultValue;
    private String attribute4ResultValue;
    private String attribute5ResultValue;
    private String attribute6ResultValue;
    private String attribute7ResultValue;
    private String attribute8ResultValue;
    private String attribute9ResultValue;
    private String attribute10ResultValue;
    private String attribute11ResultValue;
    private String attribute12ResultValue;
    private String attribute13ResultValue;
    private String attribute14ResultValue;
    private String attribute15ResultValue;
    private String interfaceHeaderAttribute1ResultValue;
    private String interfaceHeaderAttribute2ResultValue;
    private String interfaceHeaderAttribute3ResultValue;
    private String interfaceHeaderAttribute4ResultValue;
    private String trxClassResultValue;


    public void setTrxNumberFshValue(String trxNumberFshValue) {
        this.trxNumberFshValue = trxNumberFshValue;
        replaceValueMap.put("##SUCCESSFUL_TRX_NUMBER_FSH_VALUE##", this.trxNumberFshValue);
    }

    public void setInvoiceCurrencyCodeFshValue(String invoiceCurrencyCodeFshValue) {
        this.invoiceCurrencyCodeFshValue = invoiceCurrencyCodeFshValue;
        replaceValueMap.put("##SUCCESSFUL_INVOICE_CURRENCY_CODE_FSH_VALUE##", this.invoiceCurrencyCodeFshValue);
    }

    public void setAttributeCategoryFshValue(String attributeCategoryFshValue) {
        this.attributeCategoryFshValue = attributeCategoryFshValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE_CATEGORY_FSH_VALUE##", this.attributeCategoryFshValue);
    }

    public void setAttribute1FshValue(String attribute1FshValue) {
        this.attribute1FshValue = attribute1FshValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE1_FSH_VALUE##", this.attribute1FshValue);
    }

    public void setAttribute2FshValue(String attribute2FshValue) {
        this.attribute2FshValue = attribute2FshValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE2_FSH_VALUE##", this.attribute2FshValue);
    }

    public void setAttribute3FshValue(String attribute3FshValue) {
        this.attribute3FshValue = attribute3FshValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE3_FSH_VALUE##", this.attribute3FshValue);
    }

    public void setAttribute4FshValue(String attribute4FshValue) {
        this.attribute4FshValue = attribute4FshValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE4_FSH_VALUE##", this.attribute4FshValue);
    }

    public void setAttribute5FshValue(String attribute5FshValue) {
        this.attribute5FshValue = attribute5FshValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE5_FSH_VALUE##", this.attribute5FshValue);
    }


    public void setAttribute6FshValue(String attribute6FshValue) {
        this.attribute6FshValue = attribute6FshValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE6_FSH_VALUE##", this.attribute6FshValue);
    }

    public void setAttribute7FshValue(String attribute7FshValue) {
        this.attribute7FshValue = attribute7FshValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE7_FSH_VALUE##", this.attribute7FshValue);
    }

    public void setAttribute8FshValue(String attribute8FshValue) {
        this.attribute8FshValue = attribute8FshValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE8_FSH_VALUE##", this.attribute8FshValue);
    }

    public void setAttribute9FshValue(String attribute9FshValue) {
        this.attribute9FshValue = attribute9FshValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE9_FSH_VALUE##", this.attribute9FshValue);
    }

    public void setAttribute10FshValue(String attribute10FshValue) {
        this.attribute10FshValue = attribute10FshValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE10_FSH_VALUE##", this.attribute10FshValue);
    }

    public void setAttribute11FshValue(String attribute11FshValue) {
        this.attribute11FshValue = attribute11FshValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE11_FSH_VALUE##", this.attribute11FshValue);
    }

    public void setAttribute12FshValue(String attribute12FshValue) {
        this.attribute12FshValue = attribute12FshValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE12_FSH_VALUE##", this.attribute12FshValue);
    }

    public void setAttribute13FshValue(String attribute13FshValue) {
        this.attribute13FshValue = attribute13FshValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE13_FSH_VALUE##", this.attribute13FshValue);
    }

    public void setAttribute14FshValue(String attribute14FshValue) {
        this.attribute14FshValue = attribute14FshValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE14_FSH_VALUE##", this.attribute14FshValue);
    }

    public void setAttribute15FshValue(String attribute15FshValue) {
        this.attribute15FshValue = attribute15FshValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE15_FSH_VALUE##", this.attribute15FshValue);
    }

    public void setInterfaceHeaderAttribute1FshValue(String interfaceHeaderAttribute1FshValue) {
        this.interfaceHeaderAttribute1FshValue = interfaceHeaderAttribute1FshValue;
        replaceValueMap.put("##SUCCESSFUL_INTERFACE_HEADER_ATTRIBUTE1_FSH_VALUE##", this.interfaceHeaderAttribute1FshValue);
    }

    public void setInterfaceHeaderAttribute2FshValue(String interfaceHeaderAttribute2FshValue) {
        this.interfaceHeaderAttribute2FshValue = interfaceHeaderAttribute2FshValue;
        replaceValueMap.put("##SUCCESSFUL_INTERFACE_HEADER_ATTRIBUTE2_FSH_VALUE##", this.interfaceHeaderAttribute2FshValue);
    }

    public void setInterfaceHeaderAttribute3FshValue(String interfaceHeaderAttribute3FshValue) {
        this.interfaceHeaderAttribute3FshValue = interfaceHeaderAttribute3FshValue;
        replaceValueMap.put("##SUCCESSFUL_INTERFACE_HEADER_ATTRIBUTE3_FSH_VALUE##", this.interfaceHeaderAttribute3FshValue);
    }

    public void setInterfaceHeaderAttribute4FshValue(String interfaceHeaderAttribute4FshValue) {
        this.interfaceHeaderAttribute4FshValue = interfaceHeaderAttribute4FshValue;
        replaceValueMap.put("##SUCCESSFUL_INTERFACE_HEADER_ATTRIBUTE4_FSH_VALUE##", this.interfaceHeaderAttribute4FshValue);
    }


    public void setTrxClassFshValue(String trxClassFshValue) {
        this.trxClassFshValue = trxClassFshValue;
        replaceValueMap.put("##SUCCESSFUL_TRX_CLASS_FSH_VALUE##", this.trxClassFshValue);
    }



    public void setTrxNumberErpValue(String trxNumberErpValue) {
        this.trxNumberErpValue = trxNumberErpValue;
        replaceValueMap.put("##SUCCESSFUL_TRX_NUMBER_ERP_VALUE##", this.trxNumberErpValue);
    }

    public void setInvoiceCurrencyCodeErpValue(String invoiceCurrencyCodeErpValue) {
        this.invoiceCurrencyCodeErpValue = invoiceCurrencyCodeErpValue;
        replaceValueMap.put("##SUCCESSFUL_INVOICE_CURRENCY_CODE_ERP_VALUE##", this.invoiceCurrencyCodeErpValue);
    }

    public void setAttributeCategoryErpValue(String attributeCategoryErpValue) {
        this.attributeCategoryErpValue = attributeCategoryErpValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE_CATEGORY_ERP_VALUE##", this.attributeCategoryErpValue);
    }

    public void setAttribute1ErpValue(String attribute1ErpValue) {
        this.attribute1ErpValue = attribute1ErpValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE1_ERP_VALUE##", this.attribute1ErpValue);
    }

    public void setAttribute2ErpValue(String attribute2ErpValue) {
        this.attribute2ErpValue = attribute2ErpValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE2_ERP_VALUE##", this.attribute2ErpValue);
    }

    public void setAttribute3ErpValue(String attribute3ErpValue) {
        this.attribute3ErpValue = attribute3ErpValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE3_ERP_VALUE##", this.attribute3ErpValue);
    }

    public void setAttribute4ErpValue(String attribute4ErpValue) {
        this.attribute4ErpValue = attribute4ErpValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE4_ERP_VALUE##", this.attribute4ErpValue);
    }

    public void setAttribute5ErpValue(String attribute5ErpValue) {
        this.attribute5ErpValue = attribute5ErpValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE5_ERP_VALUE##", this.attribute5ErpValue);
    }

    public void setAttribute6ErpValue(String attribute6ErpValue) {
        this.attribute6ErpValue = attribute6ErpValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE6_ERP_VALUE##", this.attribute6ErpValue);
    }

    public void setAttribute7ErpValue(String attribute7ErpValue) {
        this.attribute7ErpValue = attribute7ErpValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE7_ERP_VALUE##", this.attribute7ErpValue);
    }

    public void setAttribute8ErpValue(String attribute8ErpValue) {
        this.attribute8ErpValue = attribute8ErpValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE8_ERP_VALUE##", this.attribute8ErpValue);
    }

    public void setAttribute9ErpValue(String attribute9ErpValue) {
        this.attribute9ErpValue = attribute9ErpValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE9_ERP_VALUE##", this.attribute9ErpValue);
    }

    public void setAttribute10ErpValue(String attribute10ErpValue) {
        this.attribute10ErpValue = attribute10ErpValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE10_ERP_VALUE##", this.attribute10ErpValue);
    }

    public void setAttribute11ErpValue(String attribute11ErpValue) {
        this.attribute11ErpValue = attribute11ErpValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE11_ERP_VALUE##", this.attribute11ErpValue);
    }

    public void setAttribute12ErpValue(String attribute12ErpValue) {
        this.attribute12ErpValue = attribute12ErpValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE12_ERP_VALUE##", this.attribute12ErpValue);
    }

    public void setAttribute13ErpValue(String attribute13ErpValue) {
        this.attribute13ErpValue = attribute13ErpValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE13_ERP_VALUE##", this.attribute13ErpValue);
    }

    public void setAttribute14ErpValue(String attribute14ErpValue) {
        this.attribute14ErpValue = attribute14ErpValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE14_ERP_VALUE##", this.attribute14ErpValue);
    }

    public void setAttribute15ErpValue(String attribute15ErpValue) {
        this.attribute15ErpValue = attribute15ErpValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE15_ERP_VALUE##", this.attribute15ErpValue);
    }

    public void setInterfaceHeaderAttribute1ErpValue(String interfaceHeaderAttribute1ErpValue) {
        this.interfaceHeaderAttribute1ErpValue = interfaceHeaderAttribute1ErpValue;
        replaceValueMap.put("##SUCCESSFUL_INTERFACE_HEADER_ATTRIBUTE1_ERP_VALUE##", this.interfaceHeaderAttribute1ErpValue);
    }

    public void setInterfaceHeaderAttribute2ErpValue(String interfaceHeaderAttribute2ErpValue) {
        this.interfaceHeaderAttribute2ErpValue = interfaceHeaderAttribute2ErpValue;
        replaceValueMap.put("##SUCCESSFUL_INTERFACE_HEADER_ATTRIBUTE2_ERP_VALUE##", this.interfaceHeaderAttribute2ErpValue);
    }

    public void setInterfaceHeaderAttribute3ErpValue(String interfaceHeaderAttribute3ErpValue) {
        this.interfaceHeaderAttribute3ErpValue = interfaceHeaderAttribute3ErpValue;
        replaceValueMap.put("##SUCCESSFUL_INTERFACE_HEADER_ATTRIBUTE3_ERP_VALUE##", this.interfaceHeaderAttribute3ErpValue);
    }

    public void setInterfaceHeaderAttribute4ErpValue(String interfaceHeaderAttribute4ErpValue) {
        this.interfaceHeaderAttribute4ErpValue = interfaceHeaderAttribute4ErpValue;
        replaceValueMap.put("##SUCCESSFUL_INTERFACE_HEADER_ATTRIBUTE4_ERP_VALUE##", this.interfaceHeaderAttribute4ErpValue);
    }

    public void setTrxClassErpValue(String trxClassErpValue) {
        this.trxClassErpValue = trxClassErpValue;
        replaceValueMap.put("##SUCCESSFUL_TRX_CLASS_ERP_VALUE##", this.trxClassErpValue);
    }


    public void setTrxNumberResultValue(String trxNumberResultValue) {
        this.trxNumberResultValue = trxNumberResultValue;
        replaceValueMap.put("##RESULT_TRX_NUMBER_RESULT##", this.trxNumberResultValue);
    }

    public void setInvoiceCurrencyCodeResultValue(String invoiceCurrencyCodeResultValue) {
        this.invoiceCurrencyCodeResultValue = invoiceCurrencyCodeResultValue;
        replaceValueMap.put("##RESULT_INVOICE_CURRENCY_CODE_RESULT##", this.invoiceCurrencyCodeResultValue);
    }

    public void setAttribute1ResultValue(String attribute1ResultValue) {
        this.attribute1ResultValue = attribute1ResultValue;
        replaceValueMap.put("##RESULT_ATTRIBUTE1_RESULT##", this.attribute1ResultValue);
    }

    public void setAttribute2ResultValue(String attribute2ResultValue) {
        this.attribute2ResultValue = attribute2ResultValue;
        replaceValueMap.put("##RESULT_ATTRIBUTE2_RESULT##", this.attribute2ResultValue);
    }

    public void setAttribute3ResultValue(String attribute3ResultValue) {
        this.attribute3ResultValue = attribute3ResultValue;
        replaceValueMap.put("##RESULT_ATTRIBUTE3_RESULT##", this.attribute3ResultValue);
    }

    public void setAttribute4ResultValue(String attribute4ResultValue) {
        this.attribute4ResultValue = attribute4ResultValue;
        replaceValueMap.put("##RESULT_ATTRIBUTE4_RESULT##", this.attribute4ResultValue);
    }

    public void setAttribute5ResultValue(String attribute5ResultValue) {
        this.attribute5ResultValue = attribute5ResultValue;
        replaceValueMap.put("##RESULT_ATTRIBUTE5_RESULT##", this.attribute5ResultValue);
    }

    public void setAttribute6ResultValue(String attribute6ResultValue) {
        this.attribute6ResultValue = attribute6ResultValue;
        replaceValueMap.put("##RESULT_ATTRIBUTE6_RESULT##", this.attribute6ResultValue);
    }

    public void setAttribute7ResultValue(String attribute7ResultValue) {
        this.attribute7ResultValue = attribute7ResultValue;
        replaceValueMap.put("##RESULT_ATTRIBUTE7_RESULT##", this.attribute7ResultValue);
    }

    public void setAttribute8ResultValue(String attribute8ResultValue) {
        this.attribute8ResultValue = attribute8ResultValue;
        replaceValueMap.put("##RESULT_ATTRIBUTE8_RESULT##", this.attribute8ResultValue);
    }

    public void setAttribute9ResultValue(String attribute9ResultValue) {
        this.attribute9ResultValue = attribute9ResultValue;
        replaceValueMap.put("##RESULT_ATTRIBUTE9_RESULT##", this.attribute9ResultValue);
    }

    public void setAttribute10ResultValue(String attribute10ResultValue) {
        this.attribute10ResultValue = attribute10ResultValue;
        replaceValueMap.put("##RESULT_ATTRIBUTE10_RESULT##", this.attribute10ResultValue);
    }

    public void setAttribute11ResultValue(String attribute11ResultValue) {
        this.attribute11ResultValue = attribute11ResultValue;
        replaceValueMap.put("##RESULT_ATTRIBUTE11_RESULT##", this.attribute11ResultValue);
    }

    public void setAttribute12ResultValue(String attribute12ResultValue) {
        this.attribute12ResultValue = attribute12ResultValue;
        replaceValueMap.put("##RESULT_ATTRIBUTE12_RESULT##", this.attribute12ResultValue);
    }

    public void setAttribute13ResultValue(String attribute13ResultValue) {
        this.attribute13ResultValue = attribute13ResultValue;
        replaceValueMap.put("##RESULT_ATTRIBUTE13_RESULT##", this.attribute13ResultValue);
    }

    public void setAttribute14ResultValue(String attribute14ResultValue) {
        this.attribute14ResultValue = attribute14ResultValue;
        replaceValueMap.put("##RESULT_ATTRIBUTE14_RESULT##", this.attribute14ResultValue);
    }

    public void setAttribute15ResultValue(String attribute15ResultValue) {
        this.attribute15ResultValue = attribute15ResultValue;
        replaceValueMap.put("##RESULT_ATTRIBUTE15_RESULT##", this.attribute15ResultValue);
    }

    public void setInterfaceHeaderAttribute1ResultValue(String interfaceHeaderAttribute1ResultValue) {
        this.interfaceHeaderAttribute1ResultValue = interfaceHeaderAttribute1ResultValue;
        replaceValueMap.put("##RESULT_INTERFACE_HEADER_ATTRIBUTE1_RESULT##", this.interfaceHeaderAttribute1ResultValue);
    }

    public void setInterfaceHeaderAttribute2ResultValue(String interfaceHeaderAttribute2ResultValue) {
        this.interfaceHeaderAttribute2ResultValue = interfaceHeaderAttribute2ResultValue;
        replaceValueMap.put("##RESULT_INTERFACE_HEADER_ATTRIBUTE2_RESULT##", this.interfaceHeaderAttribute2ResultValue);
    }

    public void setInterfaceHeaderAttribute3ResultValue(String interfaceHeaderAttribute3ResultValue) {
        this.interfaceHeaderAttribute3ResultValue = interfaceHeaderAttribute3ResultValue;
        replaceValueMap.put("##RESULT_INTERFACE_HEADER_ATTRIBUTE3_RESULT##", this.interfaceHeaderAttribute3ResultValue);
    }

    public void setInterfaceHeaderAttribute4ResultValue(String interfaceHeaderAttribute4ResultValue) {
        this.interfaceHeaderAttribute4ResultValue = interfaceHeaderAttribute4ResultValue;
        replaceValueMap.put("##RESULT_INTERFACE_HEADER_ATTRIBUTE4_RESULT##", this.interfaceHeaderAttribute4ResultValue);
    }

    public void setTrxClassResultValue(String trxClassResultValue) {
        this.trxClassResultValue = trxClassResultValue;
        replaceValueMap.put("##RESULT_TRX_CLASS_RESULT##", this.trxClassResultValue);
    }

}
