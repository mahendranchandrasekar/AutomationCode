package com.uk.dlgds.fusionvalidation.resources.Comparator;

import com.uk.dlgds.fusionvalidation.Utils.Output;
import com.uk.dlgds.fusionvalidation.Utils.Staging;
import java.util.ArrayList;

public class FieldComparison {



     ArrayList<String> compareElements(Staging stagingValues, Output outputValues) {
        ArrayList<String> validatedResults = new ArrayList<>();

        if (stagingValues.getTrxNumber().equalsIgnoreCase(outputValues.getTrxNumber()))
            validatedResults.add("1~" + "TRX_NUMBER~" + stagingValues.getTrxNumber() + "~" + outputValues.getTrxNumber() + "~" + "Pass");
        else
            validatedResults.add("1~" + "TRX_NUMBER~" + stagingValues.getTrxNumber() + "~" + outputValues.getTrxNumber() + "~" + "Fail");

        if (stagingValues.getInvoiceCurrencyCode().equalsIgnoreCase(outputValues.getInvoiceCurrencyCode()))
            validatedResults.add("2~" + "INVOICE_CURRENCY_CODE~" + stagingValues.getInvoiceCurrencyCode() + "~" + outputValues.getInvoiceCurrencyCode() + "~" + "Pass");
        else
            validatedResults.add("2~" + "INVOICE_CURRENCY_CODE~" + stagingValues.getInvoiceCurrencyCode() + "~" + outputValues.getInvoiceCurrencyCode() + "~" + "Fail");

        if (stagingValues.getAttributeCategory().equalsIgnoreCase(outputValues.getAttributeCategory()))
            validatedResults.add("3~" + "ATTRIBUTE_CATEGORY~" + stagingValues.getAttributeCategory() + "~" + outputValues.getAttributeCategory() + "~" + "Pass");
        else
            validatedResults.add("3~" + "ATTRIBUTE_CATEGORY~" + stagingValues.getAttributeCategory() + "~" + outputValues.getAttributeCategory() + "~" + "Fail");

        if (stagingValues.getAttribute1().equalsIgnoreCase(outputValues.getAttribute1()))
            validatedResults.add("4~" + "ATTRIBUTE1~" + stagingValues.getAttribute1() + "~" + outputValues.getAttribute1() + "~" + "Pass");
        else
            validatedResults.add("4~" + "ATTRIBUTE1~" + stagingValues.getAttribute1() + "~" + outputValues.getAttribute1() + "~" + "Fail");

            if (stagingValues.getAttribute2().equalsIgnoreCase(outputValues.getAttribute2()))
                validatedResults.add("5~" + "ATTRIBUTE2~" + stagingValues.getAttribute2() + "~" + outputValues.getAttribute2() + "~" + "Pass");
            else
                validatedResults.add("5~" + "ATTRIBUTE2~" + stagingValues.getAttribute2() + "~" + outputValues.getAttribute2() + "~" + "Fail");


             if (stagingValues.getAttribute3().equalsIgnoreCase(outputValues.getAttribute3()))
                 validatedResults.add("6~" + "ATTRIBUTE3~" + stagingValues.getAttribute3() + "~" + outputValues.getAttribute3() + "~" + "Pass");
             else
                 validatedResults.add("6~" + "ATTRIBUTE3~" + stagingValues.getAttribute3() + "~" + outputValues.getAttribute3() + "~" + "Fail");


             if (stagingValues.getAttribute4().equalsIgnoreCase(outputValues.getAttribute4()))
                 validatedResults.add("7~" + "ATTRIBUTE4~" + stagingValues.getAttribute4() + "~" + outputValues.getAttribute4() + "~" + "Pass");
             else
                 validatedResults.add("7~" + "ATTRIBUTE4~" + stagingValues.getAttribute4() + "~" + outputValues.getAttribute4() + "~" + "Fail");


            if (stagingValues.getAttribute5().equalsIgnoreCase(outputValues.getAttribute5()))
                validatedResults.add("8~" + "ATTRIBUTE5~" + stagingValues.getAttribute5() + "~" + outputValues.getAttribute5() + "~" + "Pass");
            else
                validatedResults.add("8~" + "ATTRIBUTE5~" + stagingValues.getAttribute5() + "~" + outputValues.getAttribute5() + "~" + "Fail");

            if (stagingValues.getAttribute6().equalsIgnoreCase(outputValues.getAttribute6()))
                validatedResults.add("9~" + "ATTRIBUTE6~" + stagingValues.getAttribute6() + "~" + outputValues.getAttribute6() + "~" + "Pass");
            else
                validatedResults.add("9~" + "ATTRIBUTE6~" + stagingValues.getAttribute6() + "~" + outputValues.getAttribute6() + "~" + "Fail");

            if (stagingValues.getAttribute7().equalsIgnoreCase(outputValues.getAttribute7()))
                validatedResults.add("10~" + "ATTRIBUTE7~" + stagingValues.getAttribute7() + "~" + outputValues.getAttribute7() + "~" + "Pass");
            else
                validatedResults.add("10~" + "ATTRIBUTE7~" + stagingValues.getAttribute7() + "~" + outputValues.getAttribute7() + "~" + "Fail");

            if (stagingValues.getAttribute8().equalsIgnoreCase(outputValues.getAttribute8()))
                validatedResults.add("11~" + "ATTRIBUTE8~" + stagingValues.getAttribute8() + "~" + outputValues.getAttribute8() + "~" + "Pass");
            else
                validatedResults.add("11~" + "ATTRIBUTE8~" + stagingValues.getAttribute8() + "~" + outputValues.getAttribute8() + "~" + "Fail");


            if (stagingValues.getAttribute9().equalsIgnoreCase(outputValues.getAttribute9()))
                validatedResults.add("12~" + "ATTRIBUTE9~" + stagingValues.getAttribute9() + "~" + outputValues.getAttribute9() + "~" + "Pass");
            else
                validatedResults.add("12~" + "ATTRIBUTE9~" + stagingValues.getAttribute9() + "~" + outputValues.getAttribute9() + "~" + "Fail");

            if (stagingValues.getAttribute10().equalsIgnoreCase(outputValues.getAttribute10()))
                validatedResults.add("13~" + "ATTRIBUTE10~" + stagingValues.getAttribute10() + "~" + outputValues.getAttribute10() + "~" + "Pass");
            else
                validatedResults.add("13~" + "ATTRIBUTE10~" + stagingValues.getAttribute10() + "~" + outputValues.getAttribute10() + "~" + "Fail");

            if (stagingValues.getAttribute11().equalsIgnoreCase(outputValues.getAttribute11()))
                validatedResults.add("14~" + "ATTRIBUTE11~" + stagingValues.getAttribute11() + "~" + outputValues.getAttribute11() + "~" + "Pass");
            else
                validatedResults.add("14~" + "ATTRIBUTE11~" + stagingValues.getAttribute11() + "~" + outputValues.getAttribute11() + "~" + "Fail");

            if (stagingValues.getAttribute12().equalsIgnoreCase(outputValues.getAttribute12()))
                validatedResults.add("15~" + "ATTRIBUTE12~" + stagingValues.getAttribute12() + "~" + outputValues.getAttribute12() + "~" + "Pass");
            else
                validatedResults.add("15~" + "ATTRIBUTE12~" + stagingValues.getAttribute12() + "~" + outputValues.getAttribute12() + "~" + "Fail");

            if (stagingValues.getAttribute13().equalsIgnoreCase(outputValues.getAttribute13()))
                validatedResults.add("16~" + "ATTRIBUTE13~" + stagingValues.getAttribute13() + "~" + outputValues.getAttribute13() + "~" + "Pass");
            else
                validatedResults.add("16~" + "ATTRIBUTE13~" + stagingValues.getAttribute13() + "~" + outputValues.getAttribute13() + "~" + "Fail");


             if (stagingValues.getAttribute14().equalsIgnoreCase(outputValues.getAttribute14()))
                 validatedResults.add("17~" + "ATTRIBUTE14~" + stagingValues.getAttribute14() + "~" + outputValues.getAttribute14() + "~" + "Pass");
             else
                 validatedResults.add("17~" + "ATTRIBUTE14~" + stagingValues.getAttribute14() + "~" + outputValues.getAttribute14() + "~" + "Fail");

             if (stagingValues.getAttribute15().equalsIgnoreCase(outputValues.getAttribute15()))
                 validatedResults.add("18~" + "ATTRIBUTE15~" + stagingValues.getAttribute15() + "~" + outputValues.getAttribute15() + "~" + "Pass");
             else
                 validatedResults.add("18~" + "ATTRIBUTE15~" + stagingValues.getAttribute15() + "~" + outputValues.getAttribute15() + "~" + "Fail");

        if(stagingValues.getLineNumber().equalsIgnoreCase(outputValues.getLineNumber()))
            validatedResults.add("19~"+"Interface_Header_Attribute1~"+stagingValues.getLineNumber()+"~"+ outputValues.getLineNumber()+"~"+"Pass");
        else
            validatedResults.add("19~"+"Interface_Header_Attribute1~"+stagingValues.getLineNumber()+"~"+ outputValues.getLineNumber()+"~"+"Fail");

        if(stagingValues.getTrxNumber().equalsIgnoreCase(outputValues.getInterfaceHeaderAttribute2()))
            validatedResults.add("20~"+"Interface_Header_Attribute2~"+stagingValues.getTrxNumber()+"~"+ outputValues.getInterfaceHeaderAttribute2()+"~"+"Pass");
        else
            validatedResults.add("20~"+"Interface_Header_Attribute2~"+stagingValues.getTrxNumber()+"~"+ outputValues.getInterfaceHeaderAttribute2()+"~"+"Fail");

        if(stagingValues.getCustomerAccountNumber().equalsIgnoreCase(outputValues.getInterfaceHeaderAttribute3()))
            validatedResults.add("21~"+"Interface_Header_Attribute3~"+stagingValues.getCustomerAccountNumber()+"~"+ outputValues.getInterfaceHeaderAttribute3()+"~"+"Pass");
        else
            validatedResults.add("21~"+"Interface_Header_Attribute3~"+stagingValues.getCustomerAccountNumber()+"~"+ outputValues.getInterfaceHeaderAttribute3()+"~"+"Fail");

        if(stagingValues.getCustomerSiteNumber().equalsIgnoreCase(outputValues.getInterfaceHeaderAttribute4()))
            validatedResults.add("22~"+"Interface_Header_Attribute4~"+stagingValues.getCustomerSiteNumber()+"~"+ outputValues.getInterfaceHeaderAttribute4()+"~"+"Pass");
        else
            validatedResults.add("22~"+"Interface_Header_Attribute4~"+stagingValues.getCustomerSiteNumber()+"~"+ outputValues.getInterfaceHeaderAttribute4()+"~"+"Fail");


        if(stagingValues.getCusttrxtypename().toLowerCase().equalsIgnoreCase(outputValues.getTrxClass().toLowerCase()))
            validatedResults.add("24~" + "Trx_Class~" + stagingValues.getCusttrxtypename() + "~" + outputValues.getTrxClass() + "~" + "Pass");
         else
            validatedResults.add("24~" + "Trx_Class~" + stagingValues.getCusttrxtypename() + "~" + outputValues.getTrxClass() + "~" + "Fail");


            if (stagingValues.getLineAmount().equalsIgnoreCase(outputValues.getLineAmount())) {
                validatedResults.add("25~" + "Line_Amount~" + stagingValues.getLineAmount() + "~" + outputValues.getLineAmount() + "~" + "Pass");
            }
            else
                validatedResults.add("25~" + "Line_Amount~" + stagingValues.getLineAmount() + "~" + outputValues.getLineAmount() + "~" + "Fail");

        System.out.println(validatedResults.size());
        return validatedResults;

    }
}
