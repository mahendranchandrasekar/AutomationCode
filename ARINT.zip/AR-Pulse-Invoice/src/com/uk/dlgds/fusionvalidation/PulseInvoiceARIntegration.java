package com.uk.dlgds.fusionvalidation;

import com.uk.dlgds.fusionvalidation.Utils.Output;
import com.uk.dlgds.fusionvalidation.Utils.Staging;
import com.uk.dlgds.fusionvalidation.resources.Comparator.FshToCloudComparator;
import com.uk.dlgds.fusionvalidation.resources.datasource.DatabaseConnect;
import com.uk.dlgds.fusionvalidation.resources.datasource.StgValidations;
import com.uk.dlgds.fusionvalidation.service.ApplicationDetails;
import com.uk.dlgds.fusionvalidation.service.EndpointValidation;
import com.uk.dlgds.fusionvalidation.service.ReportCreation;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;


public class PulseInvoiceARIntegration {

    private static final String CONCATENATETRXNUMBER = "concatenatetrxnumber";
    private final ApplicationDetails applicationDetails = new ApplicationDetails();
private final EndpointValidation endpointValidation = new EndpointValidation();
private final DatabaseConnect databaseConnect = new DatabaseConnect();
private final StgValidations stgValidations = new StgValidations();
private final FshToCloudComparator fshToCloudComparator = new FshToCloudComparator();

private ReportCreation reportCreation;

    {
        try {
            reportCreation = new ReportCreation();
        } catch (Exception e) {
            e.printStackTrace();

        }
    }


@Test
public void accountReceivables() throws IOException,  ParserConfigurationException, SAXException, TransformerException, SQLException, ClassNotFoundException {
    final String journalPath = "com/uk/dlgds/fusionvalidation/resources/queries/Account-Receivables.json";

        if(applicationDetails.readProperties("com.uk.dlgds.fshValidation").equalsIgnoreCase("yes")) {

            List<Staging> stagingToList = databaseConnect.createConnection(applicationDetails.readJournalFile(journalPath), "fsh-customer-query");
            List<String> fileName = stgValidations.sourceFilename(stagingToList);

            if (fileName.isEmpty()) {
                String emptyFileName = stgValidations.sourceEmptyFilename();
                System.out.println("Empty files : " + emptyFileName);
                reportCreation.createDisplayEmptyFileName(emptyFileName, "Section1", "Source FSH FileName", "EVENT_ID", "Report_Name", "Header_Name");
            } else {

                List<Output> oracleWebservice = endpointValidation.triggerEndPoint(applicationDetails.readJournalFile(journalPath)
                        .getJSONObject("Query")
                        .getString("cloud-fsh-ra-customer-trx-all-query")
                        .replace(CONCATENATETRXNUMBER, fshToCloudComparator
                                .concatenateFSHValues(stagingToList)));

                // Validating match records
                ArrayList<ArrayList<String>> compareResults = fshToCloudComparator.compareMatchValues(stagingToList, oracleWebservice);
                String missingTxn = fshToCloudComparator.compareNotMatchValues(stagingToList, oracleWebservice);
                List transactionMissed = null;
                Set<String> transactionLost = null;
                if (!missingTxn.equals("")) {
                    // Validating missing records
                    List<Output> Output = endpointValidation.triggerEndPoint(applicationDetails.readJournalFile(journalPath)
                            .getJSONObject("Query")
                            .getString("cloud-interface-error")
                            .replace("missing trx number", missingTxn));


                    transactionMissed = fshToCloudComparator.concatenateMissedTxn(Output);
                    transactionLost = fshToCloudComparator.transactionLost(transactionMissed, missingTxn);
                }

                reportCreation.createDisplayFileName(fileName, "Section1", "Source FSH FileName", "EVENT_ID", "Report_Name", "Header_Name");
                reportCreation.createCompareSection(compareResults, "Section1", "Transactions successfully processed from FSH to Cloud", "Reporting ", "Report_Name", "Header_Name");
                reportCreation.createDisplaySection(transactionMissed, "Section1", "RA Interface Errors table", "EVENT_ID", "Report_Name", "Header_Name");
                reportCreation.createDisplayTransactionLost(transactionLost, "Section1", "Transactions lost between FSH and Cloud", "EVENT_ID", "Report_Name", "Header_Name");

            }
        }
    }

}