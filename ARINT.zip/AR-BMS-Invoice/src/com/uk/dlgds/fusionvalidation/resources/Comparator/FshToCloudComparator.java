package com.uk.dlgds.fusionvalidation.resources.Comparator;
import com.uk.dlgds.fusionvalidation.Utils.Output;
import com.uk.dlgds.fusionvalidation.Utils.Staging;
import com.uk.dlgds.fusionvalidation.Utils.ValuesWrapper;
import org.testng.collections.Sets;

import java.util.*;
import java.util.stream.Collectors;

public class FshToCloudComparator {

    private final FieldComparison fieldComparison = new FieldComparison();
    private final CloudComparison cloudComparison = new CloudComparison();



     public ArrayList<ArrayList<String>> compareMatchValues(List<Staging> listStaging, List<Output> listOutput) {

        List<ValuesWrapper> resultSet = listStaging.stream()
                .map(p -> listOutput.stream()
                        .filter(sr -> p.getTrxNumber().equals(sr.getTrxNumber()) && p.getLineNumber().equalsIgnoreCase(sr.getLineNumber()))
                        .findFirst()
                        .map(q -> new ValuesWrapper(p, q))
                        .orElse(null))
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
        return validateElements(resultSet);

    }


    public String compareNotMatchValues(List<Staging> listStaging, List<Output> listOutput) {

        List<ValuesWrapper> resultSet = listStaging.stream()
                .map(p -> listOutput.stream()
                        .filter(sr -> p.getTrxNumber().equals(sr.getTrxNumber()) && p.getLineNumber().equalsIgnoreCase(sr.getLineNumber()))
                        .findFirst()
                        .map(q -> new ValuesWrapper(p, q))
                        .orElse(null))
                .filter(Objects::nonNull)
                .collect(Collectors.toList());

        Set<String> transactionPresentSet = Sets.newHashSet();
        for(ValuesWrapper model : resultSet) {
            transactionPresentSet.add(model.getStaging().getTrxNumber());
        }

        Set<String> allTransactions = Sets.newHashSet();
        for(Staging transaction : listStaging) {
            allTransactions.add(transaction.getTrxNumber());
        }

        allTransactions.removeAll(transactionPresentSet);

        List<String> aList = new ArrayList<>(allTransactions);

        for (String anAList : aList) {
            System.out.println(anAList);
        }

        return aList.stream()
                .map(strings -> "\'"+strings.trim()+"\'")
                .collect(Collectors.joining(","));


    }

    public String concatenateFSHValues(List<Staging> listStaging){


        return listStaging.stream()
                .map(staging -> "\'"+staging.getTrxNumber()+"\'")
                .collect(Collectors.joining(","));
    }

    public ArrayList<String> concatenateCloudValues(List<Output> listOutput){
        return cloudComparison.compareElements(listOutput);
    }

    public ArrayList<String> concatenateMissedTxn(List<Output> listOutput){
        return cloudComparison.concatenateMissed(listOutput);
    }

    public Set<String> transactionLost(List<Output> listOutput, String missingTransactions) {
        Set<String> mySet1 = new HashSet<String>();
        String expResult;
        String[] expValues=new String[1000];
        for (Object object : listOutput) {
            expResult = (String) object;
            expValues = expResult.split(":");
        }

        for (int j = 1; j < expValues.length; j=j+2) {
            String abcsd=expValues[j];
            mySet1.add(abcsd);
        }


        String str[] = missingTransactions.replaceAll("'","").split(",");
        Set<String> mySet = new HashSet<>(Arrays.asList(str));
        mySet.removeAll(mySet1);
        return mySet;

    }

    public ArrayList<ArrayList<String>> validateElements(List<ValuesWrapper> resultSet){

         ArrayList<ArrayList<String>> compareListResults = new ArrayList<>();
        for(ValuesWrapper stagingValues : resultSet ){

            if(stagingValues.getStaging().getTrxNumber().equalsIgnoreCase( stagingValues.getOutput().getTrxNumber()) && stagingValues.getStaging().getLineNumber().equalsIgnoreCase( stagingValues.getOutput().getLineNumber()) )
              compareListResults.add(fieldComparison.compareElements(stagingValues.getStaging(),stagingValues.getOutput()));

        }


        return compareListResults;
    }

}