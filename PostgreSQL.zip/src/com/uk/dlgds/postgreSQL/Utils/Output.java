package com.uk.dlgds.postgreSQL.Utils;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;


@Data
@RequiredArgsConstructor(staticName = "of")
@AllArgsConstructor(access = AccessLevel.PROTECTED)
public class Output {

    public String getTrxNumber() {
        return trxNumber;
    }

    public void setTrxNumber(String trxNumber) {
        this.trxNumber = objectToString(trxNumber);
    }

    public String getInvoiceCurrencyCode() {
        return invoiceCurrencyCode;
    }

    public void setInvoiceCurrencyCode(String invoiceCurrencyCode) {
        this.invoiceCurrencyCode = objectToString(invoiceCurrencyCode);
    }

    public String getAttributeCategory() {
        return attributeCategory;
    }

    public void setAttributeCategory(String attributeCategory) {
        this.attributeCategory = objectToString(attributeCategory);
    }

    public String getAttribute1() {
        return attribute1;
    }

    public void setAttribute1(String attribute1) {
        this.attribute1 = objectToString(attribute1);
    }

    public String getAttribute2() {
        return attribute2;
    }

    public void setAttribute2(String attribute2) {
        this.attribute2 = objectToString(attribute2);
    }

    public String getAttribute3() {
        return attribute3;
    }

    public void setAttribute3(String attribute3) {
        this.attribute3 = objectToString(attribute3);
    }

    public String getAttribute4() {
        return attribute4;
    }

    public void setAttribute4(String attribute4) {
        this.attribute4 = objectToString(attribute4);
    }

    public String getAttribute5() {
        return attribute5;
    }

    public void setAttribute5(String attribute5) {
        this.attribute5 = objectToString(attribute5);
    }

    public String getAttribute6() {
        return attribute6;
    }

    public void setAttribute6(String attribute6) {
        this.attribute6 = objectToString(attribute6);
    }

    public String getAttribute7() {
        return attribute7;
    }

    public void setAttribute7(String attribute7) {
        this.attribute7 = objectToString(attribute7);
    }

    public String getAttribute8() {
        return attribute8;
    }

    public void setAttribute8(String attribute8) {
        this.attribute8 = objectToString(attribute8);
    }

    public String getAttribute9() {
        return attribute9;
    }

    public void setAttribute9(String attribute9) {
        this.attribute9 = objectToString(attribute9);
    }

    public String getAttribute10() {
        return attribute10;
    }

    public void setAttribute10(String attribute10) {
        this.attribute10 = objectToString(attribute10);
    }

    public String getAttribute11() {
        return attribute11;
    }

    public void setAttribute11(String attribute11) {
        this.attribute11 = objectToString(attribute11);
    }

    public String getAttribute12() {
        return attribute12;
    }

    public void setAttribute12(String attribute12) {
        this.attribute12 = objectToString(attribute12);
    }

    public String getAttribute13() {
        return attribute13;
    }

    public void setAttribute13(String attribute13) {
        this.attribute13 = objectToString(attribute13);
    }

    public String getAttribute14() {
        return attribute14;
    }

    public void setAttribute14(String attribute14) {
        this.attribute14 = objectToString(attribute14);
    }

    public String getAttribute15() {
        return attribute15;
    }

    public void setAttribute15(String attribute15) {
        this.attribute15 = objectToString(attribute15);
    }

    public String getInterfaceHeaderAttribute1() {
        return interfaceHeaderAttribute1;
    }

    public void setInterfaceHeaderAttribute1(String interfaceHeaderAttribute1) {
        this.interfaceHeaderAttribute1 = objectToString(interfaceHeaderAttribute1);
    }

    public String getInterfaceHeaderAttribute2() {
        return interfaceHeaderAttribute2;
    }

    public void setInterfaceHeaderAttribute2(String interfaceHeaderAttribute2) {
        this.interfaceHeaderAttribute2 = objectToString(interfaceHeaderAttribute2);
    }

    public String getInterfaceHeaderAttribute3() {
        return interfaceHeaderAttribute3;
    }

    public void setInterfaceHeaderAttribute3(String interfaceHeaderAttribute3) {
        this.interfaceHeaderAttribute3 = objectToString(interfaceHeaderAttribute3);
    }

    public String getInterfaceHeaderAttribute4() {
        return interfaceHeaderAttribute4;
    }

    public void setInterfaceHeaderAttribute4(String interfaceHeaderAttribute4) {
        this.interfaceHeaderAttribute4 = objectToString(interfaceHeaderAttribute4);
    }

    public String getInterfaceHeaderContext() {
        return interfaceHeaderContext;
    }

    public void setInterfaceHeaderContext(String interfaceHeaderContext) {
        this.interfaceHeaderContext = objectToString(interfaceHeaderContext);
    }
    public String getMessageText() {
        return messageText;
    }

    public void setMessageText(String messageText) {
        this.messageText = objectToString(messageText);
    }

    public String getTrxClass() {
        return trxClass;
    }

    public void setTrxClass(String trxClass) {
        this.trxClass = objectToString(trxClass);
    }


    @JacksonXmlProperty(localName ="TRX_NUMBER")
    private String trxNumber;
    @JacksonXmlProperty(localName ="INVOICE_CURRENCY_CODE")
    private String invoiceCurrencyCode;
    @JacksonXmlProperty(localName ="ATTRIBUTE_CATEGORY")
    private String attributeCategory;
    @JacksonXmlProperty(localName ="ATTRIBUTE1")
    private String attribute1;
    @JacksonXmlProperty(localName ="ATTRIBUTE2")
    private String attribute2;
    @JacksonXmlProperty(localName ="ATTRIBUTE3")
    private String attribute3;
    @JacksonXmlProperty(localName ="ATTRIBUTE4")
    private String attribute4;
    @JacksonXmlProperty(localName ="ATTRIBUTE5")
    private String attribute5;
    @JacksonXmlProperty(localName ="ATTRIBUTE6")
    private String attribute6;
    @JacksonXmlProperty(localName ="ATTRIBUTE7")
    private String attribute7;
    @JacksonXmlProperty(localName ="ATTRIBUTE8")
    private String attribute8;
    @JacksonXmlProperty(localName ="ATTRIBUTE9")
    private String attribute9;
    @JacksonXmlProperty(localName ="ATTRIBUTE10")
    private String attribute10;
    @JacksonXmlProperty(localName ="ATTRIBUTE11")
    private String attribute11;
    @JacksonXmlProperty(localName ="ATTRIBUTE12")
    private String attribute12;
    @JacksonXmlProperty(localName ="ATTRIBUTE13")
    private String attribute13;
    @JacksonXmlProperty(localName ="ATTRIBUTE14")
    private String attribute14;
    @JacksonXmlProperty(localName ="ATTRIBUTE15")
    private String attribute15;
    @JacksonXmlProperty(localName ="INTERFACE_HEADER_ATTRIBUTE1")
    private String interfaceHeaderAttribute1;
    @JacksonXmlProperty(localName ="INTERFACE_HEADER_ATTRIBUTE2")
    private String interfaceHeaderAttribute2;
    @JacksonXmlProperty(localName ="INTERFACE_HEADER_ATTRIBUTE3")
    private String interfaceHeaderAttribute3;
    @JacksonXmlProperty(localName ="INTERFACE_HEADER_ATTRIBUTE4")
    private String interfaceHeaderAttribute4;
    @JacksonXmlProperty(localName ="INTERFACE_HEADER_CONTEXT")
    private String interfaceHeaderContext;
    @JacksonXmlProperty(localName ="TRX_CLASS")
    private String trxClass;
    @JacksonXmlProperty(localName ="MESSAGE_TEXT")
    private String messageText;


    private String objectToString(Object  obj) {
        if ( obj==null)
            return  "";
        else
            return  obj.toString();
    }
}
