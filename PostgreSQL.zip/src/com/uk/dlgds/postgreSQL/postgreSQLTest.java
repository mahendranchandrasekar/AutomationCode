package com.uk.dlgds.postgreSQL;

import com.uk.dlgds.postgreSQL.service.ReportCreation;

import java.io.*;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;



public class postgreSQLTest {

    static Statement SQLstmt = null;
    static ResultSet SQLResultset = null;
    public static ReportCreation report_generation;


    public static void main(String[] args) throws SQLException, IOException {
        report_generation = new ReportCreation();

        //---------------- PostgreSQL Database details -----------------------
        String URL_DB1 = "jdbc:postgresql://fdptestpoc-instance-1.csbxlmlxljec.eu-west-1.rds.amazonaws.com:5432/postgres";
        String Username_DB1 = "FDPTestUser";
        String password_DB1 = "FDP_TestUser";

        int section2_map_row = 1;

        //Cons table
        String db_cons_policy_consrunnumber = "";
        String db_cons_id = "";
        String db_cons_policydate = "";
        String db_cons_policyamount = "";

        //Stg table
        String db_stg_id = "";
        String db_stg_asofdaterun = "";
        String db_stg_policy_consrunnumber = "";
        String db_stg_policytotal = "";


        String db_CONS_SOURCE = "";
        String db_STG_SOURCE = "";


        List<String> list = new ArrayList<String>();
        List<String> section1_results = new ArrayList<String>();
        List<String> section2_results = new ArrayList<String>();


        //-------- Connect to Database --------------
        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        Connection connection_DB1 = null;

        try {
            connection_DB1 = DriverManager.getConnection(URL_DB1, Username_DB1, password_DB1); // --- database details
            System.out.println("The PostgreSQL Database got connected successfully");
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // -------------------- Create a statement for sending SQL Query to DB. -----------------
        try {
            SQLstmt = connection_DB1.createStatement();
        } catch (SQLException e) {
            e.printStackTrace();
        }


        //-------------- Validation Cons to Stag table ----------------
        SQLResultset = SQLstmt.executeQuery("SELECT * from src_policy");
        while (SQLResultset.next()) {
            db_cons_policy_consrunnumber = SQLResultset.getString("policy_consrunnumber");
            list.add(db_cons_policy_consrunnumber);
        }
        for (int i_header_id = 0; i_header_id < list.size(); i_header_id++) {
            SQLResultset = SQLstmt.executeQuery("SELECT * from src_policy WHERE  policy_consrunnumber = '" + list.get(i_header_id) + "' group by policydate, policy_consrunnumber,id");
            //SQLResultset = SQLstmt.executeQuery("SELECT id, policydate, policy_consrunnumber, sum(policyamount) as policyamount from src_policy group by policydate, policy_consrunnumber");
            while (SQLResultset.next()) {
                db_cons_id = SQLResultset.getString("id");
                db_cons_policydate = SQLResultset.getString("policydate");
                db_cons_policy_consrunnumber = SQLResultset.getString("policy_consrunnumber");
                db_cons_policyamount = SQLResultset.getString("policyamount");


                SQLResultset = SQLstmt.executeQuery("SELECT * from policycons where policy_consrunnumber = '" + db_cons_policy_consrunnumber + "'");
                System.out.println("Header id outer ---" + db_cons_policy_consrunnumber);
                if (!SQLResultset.next()) {
                    String stg_header_id = section2_map_row + ",BC_HEADER_ID," + "no records available in STG table" + "," + db_cons_policy_consrunnumber + ",Fail";
                    section2_results.add(stg_header_id);
                } else {
                    SQLResultset = SQLstmt.executeQuery("SELECT * from policycons WHERE policy_consrunnumber = '" + db_cons_policy_consrunnumber + "'");
                    while (SQLResultset.next()) {
                        db_stg_id = SQLResultset.getString("id");
                        db_stg_asofdaterun = SQLResultset.getString("asofdaterun");
                        db_stg_policy_consrunnumber = SQLResultset.getString("policy_consrunnumber");
                        db_stg_policytotal = SQLResultset.getString("policytotal");

                        //-------------- Validate Policy_ConsRunNumber -------------
                        if (db_cons_policy_consrunnumber.equals(db_stg_policy_consrunnumber)) {
                            String stg_header_id = section2_map_row + ",Policy_ConsRunNumber," + db_stg_policy_consrunnumber + "," + db_cons_policy_consrunnumber + ",Pass";
                            section2_results.add(stg_header_id);
                            section2_map_row++;
                        } else {
                            String stg_header_id = section2_map_row + ",Policy_ConsRunNumber," + db_stg_policy_consrunnumber + "," + db_cons_policy_consrunnumber + ",Fail";
                            section2_results.add(stg_header_id);
                            section2_map_row++;
                        }

                        //-------------- Validate policydate -------------
                        if (db_cons_policydate.equals(db_stg_asofdaterun)) {
                            String stg_header_id = ",policydate," + db_stg_asofdaterun + "," + db_cons_policydate + ",Pass";
                            section2_results.add(stg_header_id);
                        } else {
                            String stg_header_id = ",policydate," + db_stg_asofdaterun + "," + db_cons_policydate + ",Fail";
                            section2_results.add(stg_header_id);
                        }

                        //-------------- Validate ID -------------
                        if (db_cons_id.equals(db_stg_id)) {
                            String stg_header_id = ",ID," + db_stg_id + "," + db_cons_id + ",Pass";
                            section2_results.add(stg_header_id);
                        } else {
                            String stg_header_id = ",ID," + db_stg_id + "," + db_cons_id + ",Fail";
                            section2_results.add(stg_header_id);
                        }

                        //-------------- Validate policyamount -------------
                        if (db_cons_policyamount.equals(db_stg_policytotal)) {
                            String stg_header_id = ",policyamount," + db_stg_policytotal + "," + db_cons_policyamount + ",Pass";
                            section2_results.add(stg_header_id);
                        } else {
                            String stg_header_id = ",policyamount," + db_stg_policytotal + "," + db_cons_policyamount + ",Fail";
                            section2_results.add(stg_header_id);
                        }
                    }
                }
                }

            //report_generation.report_Test1(section2_results, "Section2", "file_name", "postgreSQL Database testing", "postgreSQL Database testing", "Overall", " ");
        }
        report_generation.report_Test1(section2_results, "Section2", "file_name", "postgreSQL Database testing", "postgreSQL Database testing", "Overall", " ");
    }
}

