package FileMockupCreation.resources.Utility;

import FileMockupCreation.resources.ExcelReader.Xls_Reader;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class ApplicationDetails {
    private static final Xls_Reader xls_reader = new Xls_Reader();
    private static final FileProcessing fileProcessing = new FileProcessing();

    public String readProperties(String value) throws IOException {
        Properties credentials = new Properties();
        try(InputStream stream = getClass().getClassLoader().getResourceAsStream("application.properties")) {
            credentials.load(stream);
            return  credentials.getProperty(value);
        }
    }

    public Map<String, String> fillMapToOneVariable(String sheetName, String column2, int lastRow) throws IOException {
        Map<String, String> map = new HashMap<String, String>();
        String oldValue2 = xls_reader.excelUtil().getCellData(sheetName, column2, lastRow - 1);
        String newValue2 = xls_reader.excelUtil().getCellData(sheetName, column2, lastRow);
        System.out.println("#########################################################################");
        System.out.println("The Existing UniqueID is available in the document :         " + oldValue2);
        System.out.println("The Existing UniqueID got replaced with the New UniqueID :   " + newValue2);
        System.out.println("-------------------------------------------------------------------------");

        // update
        map.put(oldValue2, newValue2);


        /*fileProcessing.b4cAccrualUniqueId2Incr(newValue2,lastRow);
        this.statusUpdate(sheetName, lastRow);*/

        return map;
    }

    public Map<String, String> fillMapToSixVariable(String sheetName, String column2,String column3,String column4,String column5,String column6,String column7, int lastRow) throws IOException {
        Map<String, String> map = new HashMap<String, String>();
        String oldValue2 = xls_reader.excelUtil().getCellData(sheetName, column2, lastRow-1);
        String newValue2 = xls_reader.excelUtil().getCellData(sheetName, column2, lastRow);
        System.out.println("The Existing UniqueID2 is available in the document :        "+oldValue2);
        System.out.println("The Existing UniqueID2 got replaced with the New UniqueID2 : "+newValue2);
        System.out.println("-------------------------------------------------------------------------");

        String oldValue3 = xls_reader.excelUtil().getCellData(sheetName, column3, lastRow-1);
        String newValue3 = xls_reader.excelUtil().getCellData(sheetName, column3, lastRow);
        System.out.println("The Existing UniqueID3 is available in the document :        "+oldValue3);
        System.out.println("The Existing UniqueID3 got replaced with the New UniqueID3 : "+newValue3);
        System.out.println("-------------------------------------------------------------------------");

        String oldValue4 = xls_reader.excelUtil().getCellData(sheetName, column4, lastRow-1);
        String newValue4 = xls_reader.excelUtil().getCellData(sheetName, column4, lastRow);
        System.out.println("The Existing UniqueID4 is available in the document :        "+oldValue4);
        System.out.println("The Existing UniqueID4 got replaced with the New UniqueID4 : "+newValue4);
        System.out.println("-------------------------------------------------------------------------");

        String oldValue5 = xls_reader.excelUtil().getCellData(sheetName, column5, lastRow-1);
        String newValue5 = xls_reader.excelUtil().getCellData(sheetName, column5, lastRow);
        System.out.println("The Existing UniqueID5 is available in the document :        "+oldValue5);
        System.out.println("The Existing UniqueID5 got replaced with the New UniqueID5 : "+newValue5);
        System.out.println("-------------------------------------------------------------------------");

        String oldValue6 = xls_reader.excelUtil().getCellData(sheetName, column6, lastRow-1);
        String newValue6 = xls_reader.excelUtil().getCellData(sheetName, column6, lastRow);
        System.out.println("The Existing UniqueID6 is available in the document :        "+oldValue6);
        System.out.println("The Existing UniqueID6 got replaced with the New UniqueID6 : "+newValue6);
        System.out.println("-------------------------------------------------------------------------");

        String oldValue7 = xls_reader.excelUtil().getCellData(sheetName, column7, lastRow-1);
        String newValue7 = xls_reader.excelUtil().getCellData(sheetName, column7, lastRow);
        System.out.println("The Existing UniqueID7 is available in the document :        "+oldValue7);
        System.out.println("The Existing UniqueID7 got replaced with the New UniqueID7 : "+newValue7);
        System.out.println("-------------------------------------------------------------------------");

        // PC_header_id
        map.put(oldValue2,newValue2);
        map.put(oldValue3,newValue3);
        map.put(oldValue4,newValue4);
        map.put(oldValue5,newValue5);
        map.put(oldValue6,newValue6);
        map.put(oldValue7,newValue7);


        return map;
    }

    public String replaceTag(String str, Map<String, String> map) {
        for (Map.Entry<String, String> entry : map.entrySet()) {
            if (str.contains(entry.getKey())) {
                str = str.replace(entry.getKey(), entry.getValue());
            }
        }
        return str;
    }


    public void statusUpdate(String sheetName, int lastRow) {
        xls_reader.excelUtil().setCellData(sheetName, "Status", lastRow - 1, "USED - PREVIOUSLY USED");
        xls_reader.excelUtil().setCellData(sheetName, "Status", lastRow, "USED - CURRENTLY USED");
        xls_reader.excelUtil().setCellData(sheetName, "Status", lastRow + 1, "NEW - NOT USED");
    }

}
