package FileMockupCreation.resources.Utility;

import FileMockupCreation.resources.ExcelReader.Xls_Reader;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

public class FileProcessing {
    public static final Xls_Reader xls_reader = new Xls_Reader();

    public void sourceToDestination(File sourceFile, File destinationFileNameMod) {

        try {
            if (destinationFileNameMod.exists()) {
                destinationFileNameMod.delete();
            } else {
                System.out.println("The existing File is not available in the folder :");
            }
            Files.copy(sourceFile.toPath(), destinationFileNameMod.toPath());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void destinationToSource(File sourceFile, File destinationFile, File sourceFileNameMod){

        try {
            if (sourceFile.exists()) {
                sourceFile.delete();
            } else {
                System.out.println("The existing File is not available in the folder :");
            }
            Files.copy(destinationFile.toPath(), sourceFileNameMod.toPath());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
