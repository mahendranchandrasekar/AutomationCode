package FileMockupCreation.resources.Template;

import FileMockupCreation.resources.ExcelReader.Xls_Reader;

public class B4CPremiumTemplate {
    public static final Xls_Reader xls_reader = new Xls_Reader();

    public void b4cPremiumUniqueId1Incr(String sheetName, String column1, String newValue1, int lastRow) {
        xls_reader.excelUtil().setCellData(sheetName, column1, lastRow, newValue1);
        String newValue1Split = newValue1.substring(29, 32);
        int newValue1ConvInt = Integer.parseInt(newValue1Split);
        int newValue1Incremt = newValue1ConvInt + 1;
        String newValue1ConvStr = String.valueOf(newValue1Incremt);
        String newValue1Repl = newValue1.replace(newValue1Split, newValue1ConvStr);
        xls_reader.excelUtil().setCellData(sheetName, column1, lastRow + 1, newValue1Repl);
    }

    public void b4cPremiumUniqueId2Incr(String sheetName, String column2, String newValue2, String newValue7, int lastRow) {
        xls_reader.excelUtil().setCellData(sheetName, column2, lastRow, newValue2);
        String newValue2Split1 = newValue2.substring(17,20);
        String newValue2Split2 = newValue7.substring(17,20);
        int newValue2ConvInt = Integer.parseInt(newValue2Split2);
        int newValue2Incremt = newValue2ConvInt+1;
        String newValue2ConvStr = String.valueOf(newValue2Incremt);
        String newValue2Repl = newValue2.replace(newValue2Split1,newValue2ConvStr);
        xls_reader.excelUtil().setCellData(sheetName, column2, lastRow + 1, newValue2Repl);
    }

    public void b4cPremiumUniqueId3Incr(String sheetName, String column3, String newValue3, String newValue7, int lastRow) {
        xls_reader.excelUtil().setCellData(sheetName, column3, lastRow, newValue3);
        String newValue3Split1 = newValue3.substring(17, 20);
        String newValue3Split2 = newValue7.substring(17, 20);
        int newValue3ConvInt = Integer.parseInt(newValue3Split2);
        int newValue3Incremt = newValue3ConvInt + 2;
        String newValue3ConvStr = String.valueOf(newValue3Incremt);
        String newValue3Repl = newValue3.replace(newValue3Split1, newValue3ConvStr);
        xls_reader.excelUtil().setCellData(sheetName, column3, lastRow + 1, newValue3Repl);
    }


    public void b4cPremiumUniqueId4Incr(String sheetName, String column4, String newValue4, String newValue7, int lastRow) {
        xls_reader.excelUtil().setCellData(sheetName, column4, lastRow, newValue4);
        String newValue4Split1 = newValue4.substring(17, 20);
        String newValue4Split2 = newValue7.substring(17, 20);
        int newValue4ConvInt = Integer.parseInt(newValue4Split2);
        int newValue4Incremt = newValue4ConvInt + 3;
        String newValue4ConvStr = String.valueOf(newValue4Incremt);
        String newValue4Repl = newValue4.replace(newValue4Split1, newValue4ConvStr);
        xls_reader.excelUtil().setCellData(sheetName, column4, lastRow + 1, newValue4Repl);
    }

    public void b4cPremiumUniqueId5Incr(String sheetName, String column5, String newValue5, String newValue7, int lastRow) {
        xls_reader.excelUtil().setCellData(sheetName, column5, lastRow, newValue5);
        String newValue5Split1 = newValue5.substring(17, 20);
        String newValue5Split2 = newValue7.substring(17, 20);
        int newValue5ConvInt = Integer.parseInt(newValue5Split2);
        int newValue5Incremt = newValue5ConvInt + 4;
        String newValue5ConvStr = String.valueOf(newValue5Incremt);
        String newValue5Repl = newValue5.replace(newValue5Split1, newValue5ConvStr);
        xls_reader.excelUtil().setCellData(sheetName, column5, lastRow + 1, newValue5Repl);
    }

    public void b4cPremiumUniqueId6Incr(String sheetName, String column6, String newValue6, String newValue7, int lastRow) {
        xls_reader.excelUtil().setCellData(sheetName, column6, lastRow, newValue6);
        String newValue6Split1 = newValue6.substring(17, 20);
        String newValue6Split2 = newValue7.substring(17, 20);
        int newValue6ConvInt = Integer.parseInt(newValue6Split2);
        int newValue6Incremt = newValue6ConvInt + 5;
        String newValue6ConvStr = String.valueOf(newValue6Incremt);
        String newValue6Repl = newValue6.replace(newValue6Split1, newValue6ConvStr);
        xls_reader.excelUtil().setCellData(sheetName, column6, lastRow + 1, newValue6Repl);
    }


    public void b4cPremiumUniqueId7Incr(String sheetName, String column7, String newValue7, int lastRow) {
        xls_reader.excelUtil().setCellData(sheetName, column7, lastRow, newValue7);
        //String newValue7Split1 = newValue7.substring(17,20);
        String newValue7Split2 = newValue7.substring(17, 20);
        int newValue7ConvInt = Integer.parseInt(newValue7Split2);
        int newValue7Incremt = newValue7ConvInt + 6;
        String newValue7ConvStr = String.valueOf(newValue7Incremt);
        String newValue7Repl = newValue7.replace(newValue7Split2, newValue7ConvStr);
        xls_reader.excelUtil().setCellData(sheetName, column7, lastRow + 1, newValue7Repl);

    }

}
