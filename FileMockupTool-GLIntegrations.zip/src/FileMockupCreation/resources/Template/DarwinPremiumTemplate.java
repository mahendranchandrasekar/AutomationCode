package FileMockupCreation.resources.Template;

import FileMockupCreation.resources.ExcelReader.Xls_Reader;

public class DarwinPremiumTemplate {
    public static final Xls_Reader xls_reader = new Xls_Reader();

    public void darwinPremiumUniqueId1Incr(String sheetName, String column1, String newValue1, int lastRow) {
        xls_reader.excelUtil().setCellData(sheetName, column1, lastRow, newValue1);
        String newValue1Split = newValue1.substring(27, 30);
        int newValue1ConvInt = Integer.parseInt(newValue1Split);
        int newValue1Incremt = newValue1ConvInt + 1;
        String newValue1ConvStr = String.valueOf(newValue1Incremt);
        String newValue1Repl = newValue1.replace(newValue1Split, newValue1ConvStr);
        xls_reader.excelUtil().setCellData(sheetName, column1, lastRow + 1, newValue1Repl);
    }

    public void darwinPremiumUniqueId2Incr(String sheetName, String column2, String newValue2, int lastRow) {
        xls_reader.excelUtil().setCellData(sheetName, column2, lastRow, newValue2);
        String newValue2Split = newValue2.substring(17,20);
        int newValue2ConvInt = Integer.parseInt(newValue2Split);
        int newValue2Incremt = newValue2ConvInt+1;
        String newValue2ConvStr = String.valueOf(newValue2Incremt);
        String newValue2Repl = newValue2.replace(newValue2Split,newValue2ConvStr);
        xls_reader.excelUtil().setCellData(sheetName, column2, lastRow + 1, newValue2Repl);
    }



}
