package FileMockupCreation.resources.ExcelReader;

import FileMockupCreation.resources.Utility.ApplicationDetails;
import FileMockupCreation.resources.Utility.Xls_utils;


import java.io.IOException;

public class Xls_Reader {
    public static final ApplicationDetails applicationDetails = new ApplicationDetails();

    public static Xls_utils excelUtil() {
        Xls_utils reader = null;
        try {
            reader = new Xls_utils(applicationDetails.readProperties("com.uk.dlg.FileMockup.GL"));

        } catch (IOException e) {
            e.printStackTrace();
        }
        return reader;
    }

}
