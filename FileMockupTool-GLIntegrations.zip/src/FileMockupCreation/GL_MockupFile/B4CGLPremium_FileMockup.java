package FileMockupCreation.GL_MockupFile;

import FileMockupCreation.resources.ExcelReader.Xls_Reader;
import FileMockupCreation.resources.Template.B4CPremiumTemplate;
import FileMockupCreation.resources.Utility.ApplicationDetails;
import FileMockupCreation.resources.Utility.FileProcessing;
import org.testng.annotations.Test;
import java.io.*;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class B4CGLPremium_FileMockup {
    private static final FileProcessing fileProcessing = new FileProcessing();
    private static final B4CPremiumTemplate b4CPremiumTemplate = new B4CPremiumTemplate();
    private static final ApplicationDetails applicationDetails = new ApplicationDetails();
    private static final Xls_Reader xls_reader = new Xls_Reader();

    private static final String sheetName= "b4cpremium";
    private static final int lastRow = xls_reader.excelUtil().getRowCount(sheetName);
    private static final String column1= "UniqueId1";
    private static final String column2= "UniqueId2";
    private static final String column3= "UniqueId3";
    private static final String column4= "UniqueId4";
    private static final String column5= "UniqueId5";
    private static final String column6= "UniqueId6";
    private static final String column7= "UniqueId7";
    private static final String column8= "Status";
    private static String sourceFilePath = "";
    private static String destinationFilePath = "";
    private static String oldValue1 = "";
    private static String newValue1 = "";
    private static String newValue2 = "";private static String newValue3 = "";
    private static String newValue4 = "";private static String newValue5 = "";
    private static String newValue6 = "";private static String newValue7 = "";

    @Test
    public void b4cpremium() throws  IOException{

        oldValue1 = xls_reader.excelUtil().getCellData(sheetName, column1, lastRow - 1);
        newValue1 = xls_reader.excelUtil().getCellData(sheetName, column1, lastRow);

        sourceFilePath = applicationDetails.readProperties("com.uk.dlg.FileMockup.b4cpremium.source");
        destinationFilePath = applicationDetails.readProperties("com.uk.dlg.FileMockup.b4cpremium.dest");
        File sourceFile = new File(sourceFilePath + oldValue1);
        File destinationFile = new File(destinationFilePath + newValue1);
        File destinationFileNameMod = new File(destinationFilePath + oldValue1);

        fileProcessing.sourceToDestination(sourceFile,destinationFileNameMod);

        Map<String, String> variableMap = applicationDetails.fillMapToSixVariable(sheetName, column2,column3,column4,column5,column6,column7, lastRow);

        newValue2 = xls_reader.excelUtil().getCellData(sheetName, column2, lastRow);
        newValue3 = xls_reader.excelUtil().getCellData(sheetName, column3, lastRow);
        newValue4 = xls_reader.excelUtil().getCellData(sheetName, column4, lastRow);
        newValue5 = xls_reader.excelUtil().getCellData(sheetName, column5, lastRow);
        newValue6 = xls_reader.excelUtil().getCellData(sheetName, column6, lastRow);
        newValue7 = xls_reader.excelUtil().getCellData(sheetName, column7, lastRow);
        b4CPremiumTemplate.b4cPremiumUniqueId2Incr(sheetName, column2, newValue2,newValue7,lastRow);
        b4CPremiumTemplate.b4cPremiumUniqueId3Incr(sheetName, column3, newValue3,newValue7,lastRow);
        b4CPremiumTemplate.b4cPremiumUniqueId4Incr(sheetName, column4, newValue4,newValue7,lastRow);
        b4CPremiumTemplate.b4cPremiumUniqueId5Incr(sheetName, column5, newValue5,newValue7,lastRow);
        b4CPremiumTemplate.b4cPremiumUniqueId6Incr(sheetName, column6, newValue6,newValue7,lastRow);
        b4CPremiumTemplate.b4cPremiumUniqueId7Incr(sheetName, column7, newValue7,lastRow);
        applicationDetails.statusUpdate(sheetName, lastRow);

        Path path = Paths.get(destinationFilePath + oldValue1);
        Stream<String> lines = null;
        try {
            lines = Files.lines(path, Charset.forName("UTF-8"));
            List<String> replacedLines = lines.map(line -> applicationDetails.replaceTag(line, variableMap)).collect(Collectors.toList());
            Files.write(path, replacedLines, Charset.forName("UTF-8"));
            lines.close();
            System.out.println("B4C GL Premium file - Find and replace is done");
        } catch (IOException e) {
            e.printStackTrace();
        }

        File newFile = new File(destinationFilePath + oldValue1);
        File renamedFile = new File(destinationFilePath + newValue1);
        if (newFile.renameTo(renamedFile)) {
            System.out.println("B4C GL Premium file - The file has been renamed successfully!!");
            System.out.println("#########################################################################");

            b4CPremiumTemplate.b4cPremiumUniqueId1Incr(sheetName, column1, newValue1,lastRow);

            oldValue1 = xls_reader.excelUtil().getCellData(sheetName,column1, lastRow);
            File sourceFileNameMod = new File(sourceFilePath + oldValue1);
            fileProcessing.destinationToSource(sourceFile,destinationFile,sourceFileNameMod);


        } else {
            System.out.println("B4C GL Premium file - The file could not be renamed because its already there with the same name");
            System.out.println("#########################################################################");
        }

    }

}