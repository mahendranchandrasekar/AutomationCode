package FileMockupCreation.GL_MockupFile;

import FileMockupCreation.resources.ExcelReader.Xls_Reader;
import FileMockupCreation.resources.Template.B4CAccrualTemplate;
import FileMockupCreation.resources.Template.B4CBillingTemplate;
import FileMockupCreation.resources.Utility.ApplicationDetails;
import FileMockupCreation.resources.Utility.FileProcessing;
import org.testng.annotations.Test;
import java.io.*;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class B4CGLBilling_FileMockup {
    private static final FileProcessing fileProcessing = new FileProcessing();
    private static final B4CBillingTemplate b4cBillingTemplate = new B4CBillingTemplate();
    private static final ApplicationDetails applicationDetails = new ApplicationDetails();
    private static final Xls_Reader xls_reader = new Xls_Reader();

    private static final String sheetName= "b4cbilling";
    private static final int lastRow = xls_reader.excelUtil().getRowCount(sheetName);
    private static final String column1= "UniqueId1";
    private static final String column2= "UniqueId2";
    private static String sourceFilePath = "";
    private static String destinationFilePath = "";
    private static String oldValue1 = "";
    private static String newValue1 = "";
    private static String newValue2 = "";
    @Test
    public void b4cbilling() throws IOException{

        oldValue1 = xls_reader.excelUtil().getCellData(sheetName, column1, lastRow - 1);
        newValue1 = xls_reader.excelUtil().getCellData(sheetName, column1, lastRow);

        sourceFilePath = applicationDetails.readProperties("com.uk.dlg.FileMockup.b4cbilling.source");
        destinationFilePath = applicationDetails.readProperties("com.uk.dlg.FileMockup.b4cbilling.dest");
        File sourceFile = new File(sourceFilePath + oldValue1);
        File destinationFile = new File(destinationFilePath + newValue1);
        File destinationFileNameMod = new File(destinationFilePath + oldValue1);

        fileProcessing.sourceToDestination(sourceFile,destinationFileNameMod);

        Map<String, String> variableMap = applicationDetails.fillMapToOneVariable(sheetName, column2, lastRow);

        newValue2 = xls_reader.excelUtil().getCellData(sheetName, column2, lastRow);
        b4cBillingTemplate.b4cBillingUniqueId2Incr(sheetName, column2, newValue2,lastRow);
        applicationDetails.statusUpdate(sheetName, lastRow);

        Path path = Paths.get(destinationFilePath + oldValue1);
        Stream<String> lines = null;
        try {
            lines = Files.lines(path, Charset.forName("UTF-8"));
            List<String> replacedLines = lines.map(line -> applicationDetails.replaceTag(line, variableMap)).collect(Collectors.toList());
            Files.write(path, replacedLines, Charset.forName("UTF-8"));
            lines.close();
            System.out.println("B4C GL Billing file - Find and replace is done");
        } catch (IOException e) {
            e.printStackTrace();
        }

        File newFile = new File(destinationFilePath + oldValue1);
        File renamedFile = new File(destinationFilePath + newValue1);
        if (newFile.renameTo(renamedFile)) {
            System.out.println("B4C GL Billing file - The file has been renamed successfully!!");
            System.out.println("#########################################################################");

            b4cBillingTemplate.b4cBillingUniqueId1Incr(sheetName, column1, newValue1,lastRow);

            oldValue1 = xls_reader.excelUtil().getCellData(sheetName,column1, lastRow);
            File sourceFileNameMod = new File(sourceFilePath + oldValue1);
            fileProcessing.destinationToSource(sourceFile,destinationFile,sourceFileNameMod);


        } else {
            System.out.println("B4C GL Billing file - The file could not be renamed because its already there with the same name");
            System.out.println("#########################################################################");
        }

    }

}
