package com.uk.dlgds.fusionvalidation.resources.datasource;


import java.sql.*;
import java.util.LinkedList;
import java.util.List;

public class DbConnect {

    public List<String> fileNames = new LinkedList<>();

    public void getDbValues(String dbServer, String dbUserName, String dbPassword, String query) throws  SQLException {
        fileNames.clear();
        ResultSet resultSet;
        try (Connection connection = DriverManager.getConnection(dbServer, dbUserName, dbPassword)) {
            Statement stmt = connection.createStatement();
            resultSet = stmt.executeQuery(query);
            fshDbFileList(resultSet);
        }

    }


    private void fshDbFileList(ResultSet resultSet) throws SQLException {
             while (resultSet.next()) {
            fileNames.add(objectToString(resultSet.getObject(1)));
        }


    }

    private String objectToString(Object obj) {
        if (obj == null)
            return "";
        else
            return obj.toString();
    }
}
