package com.uk.dlgds.fusionvalidation.service;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



public class JDBCConnection {

    static Connection crunchifyConn = null;
    static Statement crunchifyStmt = null;
    static ResultSet crunchifyResultset = null;
    private final ApplicationDetails applicationDetails = new ApplicationDetails();

    public String listFroFSHDB(String jdbcQuery) throws SQLException,IOException {
        final String server=applicationDetails.readProperties("com.uk.dlgds.jdbcServerUrl");
        final String userName=applicationDetails.readProperties("com.uk.dlgds.jdbcUsername");
        final String password=applicationDetails.readProperties("com.uk.dlgds.jdbcPassword");
        String listOfFiles="";
        String queryBuilder=",";
        try {
            // Returns the Class object associated with the class
            Class.forName("oracle.jdbc.driver.OracleDriver");
        } catch (ClassNotFoundException exception) {
            System.out.println("Oracle Driver Class Not found Exception: " + exception.toString());

        }

        // Set connection timeout. Make sure you set this correctly as per your need
        DriverManager.setLoginTimeout(5);
        System.out.println("Oracle JDBC Driver Successfully Registered! Let's make connection now");

        try {
       crunchifyConn = DriverManager.getConnection(server, userName, password);
        } catch (SQLException e) {
            System.out.println("Connection Failed! Check output console");
            e.printStackTrace();

        }

        // Creates a Statement object for sending SQL statements to the database
        crunchifyStmt = crunchifyConn.createStatement();

        // Executes the given SQL statement, which returns a single ResultSet object
        crunchifyResultset = crunchifyStmt.executeQuery(jdbcQuery);

        while(crunchifyResultset.next()){
           /* if(crunchifyResultset.last()){
                queryBuilder="";
            }*/
            listOfFiles=listOfFiles+ "'"+crunchifyResultset.getString("FILE_NAME" )+ "'"+queryBuilder;
        }
        listOfFiles=replaceLast(listOfFiles,",","");
        System.out.println("Oracle JDBC connect and query test completed.");
        return listOfFiles;
    }

    public  String replaceLast(String string, String toReplace, String replacement) {
        int pos = string.lastIndexOf(toReplace);
        if (pos > -1) {
            return string.substring(0, pos)
                    + replacement
                    + string.substring(pos + toReplace.length());
        } else {
            return string;
        }
    }

}
