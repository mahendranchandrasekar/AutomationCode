package com.uk.dlgds.fusionvalidation.service;

import com.uk.dlgds.fusionvalidation.EVOPremiumGlIntegration;
import com.uk.dlgds.fusionvalidation.Utils.ApplicationConstants;
import com.uk.dlgds.fusionvalidation.Utils.TestReport;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

public class GLValidation {

    List<String> passList = new LinkedList<>();
    List<String> failList = new LinkedList<>();
    private List<List<String>> expectedList = new LinkedList<>();
    private List<List<String>> actualList = new LinkedList<>();
    private boolean duplicate = Boolean.FALSE;
    private int rowCounter = 0;

    private StringBuilder actualValues = new StringBuilder();


    private void getVaAlues() throws IOException {


        List<String> expected = Files.readAllLines(Paths.get(ApplicationConstants.EVO_SSPX_GL_EXPECTED_FILE_PATH));

        for (String value : expected) {
            List<String> list = Arrays.stream(value.trim().split(",")).map(String::trim).collect(Collectors.toList());

            expectedList.add(list);
        }

        List<String> actual = Files.readAllLines(Paths.get(ApplicationConstants.EVO_SSPX_GL_ACTUAL));
        for (String value : actual) {
            List<String> list = Arrays.stream(value.trim().split(",")).map(String::trim).collect(Collectors.toList());
            actualList.add(replaceCRDRactualList(list));
        }
        expectedList.remove(0);
        actualList.remove(0);
    }

    private List<String> replaceCRDRactualList(List<String> list) {
        int index;
        if (list.contains(ApplicationConstants.DLG_MISC_CR)) {
            index = list.indexOf(ApplicationConstants.DLG_MISC_CR);
            list.remove(index);
            list.add(index, ApplicationConstants.CR);
        }

        if (list.contains(ApplicationConstants.DLG_MISC_DR)) {
            index = list.indexOf(ApplicationConstants.DLG_MISC_DR);
            list.remove(index);
            list.add(index, ApplicationConstants.DR);
        }
        return list;

    }

    public void validateEvoPremium() throws IOException {
         StringBuilder expectedStringBuilder ;
         StringBuilder actualStringBuilder ;
         StringBuilder expectedValues;

        TestReport testReport = new TestReport();
        testReport.setFilesNotProcessed(EVOPremiumGlIntegration.FileNotProcessed.replace("'",", "));
        testReport.setFilesProcessed(EVOPremiumGlIntegration.UniqueFSHFiles.replace("'",", "));

        getVaAlues();

        for (List<String> expected : expectedList) {
            if(expected.get(ApplicationConstants.BASE_AMOUNT_EXPECTED).replace("-", "").trim().equals("0"))
                continue;

            String actualPublishedResultTestReport = "";
            String actualPublishedResultFailTestReport = "";
            String actualPublishedResult = "";
            String actualPublishedResultFail = "";
            duplicate = Boolean.FALSE;
            String dataPublishedResult = String.format("%s,%s,%s,%s,%s,%s,%s,%s,%s ", expected.get(ApplicationConstants.SOURCE_FILE_NAME_EXPECTED),
                    expected.get(ApplicationConstants.TRANSACTION_NUMBER_EXPECTED),
                    expected.get(ApplicationConstants.TRANSACTION_DATE_EXPECTED).replace("T00:00:00.000+00:00", ""),
                    expected.get(ApplicationConstants.FSH_BRAND_EXPECTED),
                    expected.get(ApplicationConstants.FSH_PRODUCT_EXPECTED),
                    expected.get(ApplicationConstants.EVENT_ID_EXPECTED),
                    expected.get(ApplicationConstants.CURRENCY_CODE_EXPECTED),
                    expected.get(ApplicationConstants.AHCS_EVENT_CODE_EXPECTED),
                    expected.get(ApplicationConstants.FSH_CHANNEL_EXPECTED));

            String segmentTestReport = String.format("%s-%s-%s-%s-%s-%s-%s-%s-%s-%s ",
                    expected.get(ApplicationConstants.SEGMENT1_EXPECTED),
                    expected.get(ApplicationConstants.SEGMENT2_EXPECTED),
                    expected.get(ApplicationConstants.SEGMENT3_EXPECTED),
                    expected.get(ApplicationConstants.SEGMENT4_EXPECTED),
                    expected.get(ApplicationConstants.SEGMENT5_EXPECTED),
                    expected.get(ApplicationConstants.SEGMENT6_EXPECTED),
                    expected.get(ApplicationConstants.SEGMENT7_EXPECTED),
                    expected.get(ApplicationConstants.SEGMENT8_EXPECTED),
                    expected.get(ApplicationConstants.SEGMENT9_EXPECTED),
                    expected.get(ApplicationConstants.SEGMENT10_EXPECTED));

            String expectedPublishedResult = String.format("%s,%s,%s,%s,%s ",
                    expected.get(ApplicationConstants.DR_CR_EXPECTED),
                    expected.get(ApplicationConstants.BASE_AMOUNT_EXPECTED),
                    expected.get(ApplicationConstants.CODE_COMBINATION_ID_EXPECTED),
                    expected.get(ApplicationConstants.LINE_OF_BUSINESS_EXPECTED),
                    segmentTestReport);

            expectedStringBuilder = new StringBuilder();
            expectedStringBuilder.append(expected.get(ApplicationConstants.CODE_COMBINATION_ID_EXPECTED));
            expectedStringBuilder.append(expected.get(ApplicationConstants.BASE_AMOUNT_EXPECTED).replace("-", ""));
            expectedStringBuilder.append(expected.get(ApplicationConstants.DR_CR_EXPECTED));

            expectedValues = new StringBuilder();
            expectedValues.append(expected.get(ApplicationConstants.APPLICATION_ID_EXPECTED));
            expectedValues.append(expected.get(ApplicationConstants.LINE_OF_BUSINESS_EXPECTED));
            expectedValues.append(expected.get(ApplicationConstants.FSH_BRAND_EXPECTED));
            expectedValues.append(expected.get(ApplicationConstants.FSH_CHANNEL_EXPECTED));
            expectedValues.append(expected.get(ApplicationConstants.FSH_PRODUCT_EXPECTED));
            expectedValues.append(expected.get(ApplicationConstants.LINE_OF_BUSINESS_EXPECTED));
            expectedValues.append(expected.get(ApplicationConstants.PRODUCT_TYPE_EXPECTED));
            expectedValues.append(expected.get(ApplicationConstants.PRODUCT_KEY_EXPECTED));

            String expectedPassValue = expected.toString().replace("[", "").replace("]", "");

            for (List<String> actual : actualList) {
                String amountActual = String.format("%s%s", actual.get(ApplicationConstants.ENTERED_CR_ACTUAL), actual.get(ApplicationConstants.ENTERED_DR_ACTUAL)).trim();
                actualStringBuilder = new StringBuilder();
                actualStringBuilder.append(actual.get(ApplicationConstants.CODE_COMBINATION_ID_ACTUAL));
                actualStringBuilder.append(amountActual);
                actualStringBuilder.append(actual.get(ApplicationConstants.ACCOUNTING_CLASS_CODE_ACTUAL));

                actualPublishedResult = String.format("%s,%s,%s,%s,%s ",
                        actual.get(ApplicationConstants.ACCOUNTING_CLASS_CODE_ACTUAL),
                        amountActual,
                        actual.get(ApplicationConstants.CODE_COMBINATION_ID_ACTUAL),
                        actual.get(ApplicationConstants.LINE_OF_BUSINESS_ACTUAL),
                        segmentTestReport);

                actualPublishedResultFail = String.format("%s,%s,%s,%s, ",
                        actual.get(ApplicationConstants.ACCOUNTING_CLASS_CODE_ACTUAL),
                        amountActual,
                        actual.get(ApplicationConstants.CODE_COMBINATION_ID_ACTUAL),
                        actual.get(ApplicationConstants.LINE_OF_BUSINESS_ACTUAL));

                if (expectedStringBuilder.toString().equals(actualStringBuilder.toString())) {

                    actualValues = new StringBuilder();
                    actualValues.append(actual.get(ApplicationConstants.APPLICATION_ID_ACTUAL));
                    actualValues.append(actual.get(ApplicationConstants.LINE_OF_BUSINESS_ACTUAL));
                    actualValues.append(actual.get(ApplicationConstants.FSH_BRAND_ACTUAL));
                    actualValues.append(actual.get(ApplicationConstants.FSH_CHANNEL_ACTUAL));
                    actualValues.append(actual.get(ApplicationConstants.FSH_PRODUCT_ACTUAL));
                    actualValues.append(actual.get(ApplicationConstants.LINE_OF_BUSINESS_ACTUAL));
                    actualValues.append(actual.get(ApplicationConstants.PRODUCT_TYPE_ACTUAL));
                    actualValues.append(actual.get(ApplicationConstants.PRODUCT_KEY_ACTUAL));

                    if (expectedValues.toString().equals(actualValues.toString())) {
                        passList.add(expectedPassValue);
                        actualPublishedResultTestReport = actualPublishedResult;
                    } else
                        actualPublishedResultFailTestReport = actualPublishedResultFail;
                }
            }

            System.out.print("\n\n" + ++rowCounter + " -> ");
            if (passList.stream().filter(o -> o.equals(expectedPassValue)).count() > 1) {
                System.out.println(expectedPassValue + " : Duplicate");
                testReport.setValuesToReport(dataPublishedResult, expectedPublishedResult, actualPublishedResultTestReport, TestReport.WARNING, "Code combination is matched but Expected Data is available in Actuals for multiple records - Kindly check");
            } else if (passList.stream().filter(o -> o.equals(expectedPassValue)).count() == 1) {
                System.out.println(expectedPassValue + " : Pass");
                testReport.setValuesToReport(dataPublishedResult, expectedPublishedResult, actualPublishedResultTestReport, TestReport.PASS, "Expected Data is available in Actuals and code combinations is matched");
            } else if (!passList.contains(expectedPassValue)) {
                System.out.println(expectedPassValue + " : Fail : No entry in actual");
                testReport.setValuesToReport(dataPublishedResult, expectedPublishedResult, actualPublishedResultFailTestReport, TestReport.FAIL, "Code combinations is not matched - Kindly check");
            }
        }

        testReport.publishReportFinal();
    }
}

