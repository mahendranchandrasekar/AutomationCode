package com.uk.dlgds.fusionvalidation.service;

import com.uk.dlgds.fusionvalidation.Utils.ApplicationConstants;
import org.dom4j.DocumentException;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;


public class CodeCombination extends EndpointValidation {

    private static int count = 0;
    private final ApplicationDetails applicationDetails = new ApplicationDetails();
    private String username;
    private String password;
    private String url;
    private String ip;
    private String port;
    private String runInDLG;

    private String readCombination(String query) throws IOException, SAXException, ParserConfigurationException, TransformerException {

        readValues();

        HttpURLConnection con = null;
        Proxy proxy = null;
        URL obj = null;

        if (runInDLG.equalsIgnoreCase("yes")) {
            proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(ip, Integer.parseInt(port)));
            obj = new URL(url);
            con = (HttpURLConnection) obj.openConnection(proxy);
        } else {
            obj = new URL(url);
            con = (HttpURLConnection) obj.openConnection();
        }

        //  HttpURLConnection con = (HttpURLConnection) obj.openConnection();
        con.setRequestMethod("POST");
        con.setRequestProperty("Content-Type", "application/soap+xml; charset=utf-8");
        String encoded = Base64.getEncoder().encodeToString((username + ":" + password).getBytes(StandardCharsets.UTF_8));
        con.setRequestProperty("Authorization", "Basic " + encoded);
        String inputXML = updateQuerySegments(readInputXML("CODECOMBINATIONRequest"), query);
        con.setDoOutput(true);
        DataOutputStream wr = new DataOutputStream(con.getOutputStream());
        wr.writeBytes(inputXML);
        wr.flush();
        wr.close();
        org.w3c.dom.Document document = convertStringToXMLDocument(readResponse(con).toString());
        String nodes = document.getElementsByTagName("ns2:runReportResponse").item(0).getTextContent();
        byte[] byteArray = Base64.getDecoder().decode(nodes.substring(0, nodes.length() - 8));
        String output = new String(byteArray);
        return readCombinationID(convertStringToXMLDocument(output));

    }

    private String readCombinationID(org.w3c.dom.Document elementOutput) {
        NodeList nList = elementOutput.getElementsByTagName("CODECOMBINATIONSQL");
        String combinationID = null;
        for (int temp = 0; temp < nList.getLength(); temp++) {
            org.w3c.dom.Node nNode = nList.item(temp);
            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                Element eElement = (Element) nNode;
                combinationID = eElement.getElementsByTagName("CODE_COMBINATION_ID").item(0).getTextContent();
            }
        }
        return combinationID;
    }

    @Override
    public void readValues() throws IOException {
        String runner = "JENKINS";

        username = applicationDetails.readProperties("com.uk.dlgds.username").trim();
        password = applicationDetails.readProperties("com.uk.dlgds.password").trim();
        url = applicationDetails.readProperties("com.uk.dlgds.endpoint.url").trim();

        if (System.getProperty("runner.name").equals(runner))
            ip = applicationDetails.readProperties("com.uk.dlgds.proxy.ip.jenkins").trim();
        else
            ip = applicationDetails.readProperties("com.uk.dlgds.proxy.ip").trim();

        port = applicationDetails.readProperties("com.uk.dlgds.proxy.port").trim();

        runInDLG = applicationDetails.readProperties("com.uk.dlgds.run.runInDLG").trim();
    }

    public void getVaAlues() throws IOException, DocumentException, SAXException, ParserConfigurationException, TransformerException {

        List<String> codeCombinationList = new LinkedList<>();
        Map<String, String> codeCombinationValue = new HashMap<>();

        List<String> expected = Files.readAllLines(Paths.get(ApplicationConstants.EVO_SSPX_GL_EXPECTED_FILE_PATH));
        List<String> expectedList;

        for (String value : expected) {
            String codeCombination = value.trim().split(",")[ApplicationConstants.CODE_COMBINATION_ID_EXPECTED];
            codeCombinationList.add(codeCombination);
        }

        codeCombinationList = codeCombinationList.stream()
                .filter(o -> !o.equalsIgnoreCase("CODE_COMBINATION_ID"))
                .distinct()
                .collect(Collectors.toList());

        for (String value : codeCombinationList) {
            /*codeCombinationValue.put(objectToString(readCombination(value)), value);
        System.out.println(codeCombinationList);
        System.out.println(codeCombinationValue);*/
            String ccId =objectToString(readCombination(value));
        codeCombinationValue.put(value, ccId);

        if (ccId.equals("UTD"))
            System.out.println(value);
    }


        expectedList = new LinkedList<>();
        for (String value : expected) {
            for (Map.Entry<String, String> map : codeCombinationValue.entrySet())
                value = value.replace(map.getValue(), map.getKey());
            expectedList.add(value);
        }

        writeExpectedFile(expectedList);

    }

    private void writeExpectedFile(List<String> expectedList)
            throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(ApplicationConstants.EVO_SSPX_GL_EXPECTED_FILE_PATH))) {
            for (String value : expectedList)
                writer.write(value.trim() + "\n");
        }
    }

    private String objectToString(Object obj) {

        if (obj == null)
            return "UTD";
        else
            return obj.toString();
    }
}
