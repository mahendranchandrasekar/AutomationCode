package com.uk.dlgds.fusionvalidation;

import com.uk.dlgds.fusionvalidation.Utils.ApplicationConstants;
import com.uk.dlgds.fusionvalidation.Utils.EVOPremium;
import com.uk.dlgds.fusionvalidation.resources.datasource.DbConnect;
import com.uk.dlgds.fusionvalidation.service.*;
import org.dom4j.DocumentException;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.xpath.XPathExpressionException;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

public class EVOPremiumGlIntegration {

    public static String FileNotProcessed = "< ---NO--FILE--- >";
    public static String UniqueFSHFiles = "< ---NO--FILE--- >";
    private final ApplicationDetails applicationDetails = new ApplicationDetails();
    private final EndpointValidation endpointValidation = new EndpointValidation();
    private final JDBCConnection jdbcConnection = new JDBCConnection();
    GLValidation glLValidation = new GLValidation();
    EVOPremium evoPremium = new EVOPremium();
    CodeCombination codeCombination = new CodeCombination();
    private boolean singleFileValidation;

    private String expectedQuery;
    private String actualQuery;
    private String fileListExpected;
    private String fileListActual;
    private String fileNotProcessedQuery;
    private String fshDbValidation;
    private String fileNotProcessed;
    private String uniqueFSHFiles;
    private String singleFileExpected;
    private String singleFileActual;
    private String singleFile;
    private String expectedQuerySingle;
    private String actualQuerySingle;
    private String expectedQueryList;
    private String actualQueryList;
    private String jdbcFshQueryDate;
    private String jdbcFshQuerySingleFile;
    private String jdbcFileNotProcessQueryDate;
    private String jdbcFileNotProcessQuerySingleFile;
    private String dbServer;
    private String dbUserName;
    private String dbPassword;
    private DbConnect dbConnect = new DbConnect();
    private String jdbcFshFileProcessedQuery;
    private String jdbcFshFileNotProcessedQuery;
    private List<String> jdbcFshFileProcessedList = new LinkedList<>();
    private List<String> jdbcFshFileNotProcessedList = new LinkedList<>();


    @Test
    public void evoPremium() throws ClassNotFoundException, DocumentException,IOException,  ParserConfigurationException, SAXException, TransformerException, SQLException,XPathExpressionException {


        readValuesFromProperties();
        Boolean dbValidation = Boolean.parseBoolean(fshDbValidation.trim().toUpperCase());


        if (Boolean.TRUE.equals(dbValidation)) {
            List<String> jdbcFshFileNotProcessedList;
            dbConnect.getDbValues(dbServer, dbUserName, dbPassword, jdbcFshFileProcessedQuery);
            List<String> jdbcFshFileProcessedList = dbConnect.fileNames;
            UniqueFSHFiles = String.join("','", jdbcFshFileProcessedList);
            fileListExpected = UniqueFSHFiles;
            fileListActual = jdbcFshFileProcessedList.stream()
                    .map(o -> o.trim().substring(0, 30))
                    .collect(Collectors.joining("','"));
            if ( UniqueFSHFiles.trim().isEmpty() )
                UniqueFSHFiles="< ---NO--DATA--- >";

            dbConnect.getDbValues(dbServer, dbUserName, dbPassword, jdbcFshFileNotProcessedQuery);
            jdbcFshFileNotProcessedList = dbConnect.fileNames;
            if(!(jdbcFshFileNotProcessedList.isEmpty())){
                fileNotProcessed = String.join("','", jdbcFshFileNotProcessedList);
            }else
                fileNotProcessed = "< ---NO--DATA--- >";

            expectedQuery = expectedQuery.replace(ApplicationConstants.EVO_REPLACE_FILE_LIST, fileListExpected);
            actualQuery = actualQuery.replace(ApplicationConstants.EVO_REPLACE_FILE_LIST, fileListActual);

        } else {
            UniqueFSHFiles = "< ---NO--DB--CHECK--- >";
            FileNotProcessed = "< ---NO--DB--CHECK--- >";

            if (singleFileExpected.contains(",")) {
                singleFileActual = Arrays.stream(singleFileExpected.split(","))
                        .map(o -> o.trim().substring(0, 30))
                        .collect(Collectors.joining("','"));
                singleFileExpected = singleFileExpected.replace(",", "','");
            }

            expectedQuery = expectedQuerySingle.replace(ApplicationConstants.EVO_REPLACE_FILE_LIST, singleFileExpected);
            actualQuery = actualQuery.replace(ApplicationConstants.EVO_REPLACE_FILE_LIST, singleFileActual);
        }

        endpointValidation.triggerEndPoint(fileListExpected, new File(ApplicationConstants.EVO_SSPX_GL_TEMP_FILE_PATH));
        evoPremium.readEvoPremiumValues();

        ArrayList<ArrayList<String>> arrayList = endpointValidation.triggerActualEndPoint(fileListExpected.trim().substring(0, 30));
        writeActualFile(arrayList);

        codeCombination.getVaAlues();

        glLValidation.validateEvoPremium();


    }


    private void readValuesFromProperties() throws IOException {


        expectedQuerySingle = applicationDetails.readProperties("com.uk.dlgds.evoSingle.expectedQuery").trim();
        actualQuerySingle = applicationDetails.readProperties("com.uk.dlgds.evoSingle.ActualQuery").trim();
        expectedQuery = applicationDetails.readProperties("com.uk.dlgds.evo.expectedQuery").trim();
        actualQueryList = applicationDetails.readProperties("com.uk.dlgds.evo.ActualQuery").trim();

        actualQuery = applicationDetails.readProperties("com.uk.dlgds.evo.ActualQuery").trim();

        fshDbValidation = applicationDetails.readProperties("com.uk.dlgds.fshValidation").trim();
        singleFile = applicationDetails.readProperties("com.uk.dlgds.run.runInSingleFile").trim();
        singleFileValidation = Boolean.parseBoolean(singleFile.trim());
        singleFileExpected = applicationDetails.readProperties("com.uk.dlgds.evo.singleFile.Name").trim();
        singleFileActual = singleFileExpected.trim().substring(0, 30);
        System.out.println("singleFileActual:"+singleFileActual);

        String runQueryBy  =  System.getProperty("runQueryBy").trim().split("-")[0].trim();
        String fileExpectedOrDate  =  System.getProperty("runQueryBy").trim().split("-")[1].trim();

        jdbcFshQueryDate = applicationDetails.readProperties("evo.premium.FSHJDBCQuery.date").trim();
        jdbcFshQuerySingleFile = applicationDetails.readProperties("evo.premium.FSHJDBCQuery.singleFile").trim();
        jdbcFileNotProcessQueryDate = applicationDetails.readProperties("evo.premium.FSHFileNotProcessQuery.date").trim();
        jdbcFileNotProcessQuerySingleFile = applicationDetails.readProperties("evo.premium.FSHFileNotProcessQuery.singleFile").trim();


        if (singleFileExpected.contains(",")) {
            jdbcFshQuerySingleFile = jdbcFshQuerySingleFile.replace(ApplicationConstants.EVO_REPLACE_FILE, (fileExpectedOrDate.replace(",", "','")));
            jdbcFileNotProcessQuerySingleFile = jdbcFileNotProcessQuerySingleFile.replace(ApplicationConstants.EVO_REPLACE_FILE, (fileExpectedOrDate.replace(",", "','")));
        } else {
            jdbcFshQuerySingleFile = jdbcFshQuerySingleFile.replace(ApplicationConstants.EVO_REPLACE_FILE, fileExpectedOrDate);
            jdbcFileNotProcessQuerySingleFile = jdbcFileNotProcessQuerySingleFile.replace(ApplicationConstants.EVO_REPLACE_FILE, fileExpectedOrDate);
        }
        String env = applicationDetails.readProperties("com.uk.dlgds.db.evn").trim();

        dbServer = applicationDetails.readProperties(String.format("com.uk.dlgds.%s.dbServer", env)).trim();
        dbUserName = applicationDetails.readProperties(String.format("com.uk.dlgds.%s.dbUserName", env)).trim();
        dbPassword = applicationDetails.readProperties(String.format("com.uk.dlgds.%s.dbPassword", env)).trim();

        if (runQueryBy.equalsIgnoreCase(ApplicationConstants.RUN_QUERY_BY)) {
            jdbcFshFileProcessedQuery = jdbcFshQuerySingleFile;
            jdbcFshFileNotProcessedQuery = jdbcFileNotProcessQuerySingleFile;
            expectedQuery = expectedQuerySingle;
            actualQuery = actualQuerySingle;
        } else {
            jdbcFshFileProcessedQuery = jdbcFshQueryDate.replace( ApplicationConstants.DAYS,fileExpectedOrDate );
            jdbcFshFileNotProcessedQuery = jdbcFileNotProcessQueryDate.replace( ApplicationConstants.DAYS,fileExpectedOrDate );
        }


    }

    public void writeActualFile(ArrayList<ArrayList<String>> arrayList)
            throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(ApplicationConstants.EVO_SSPX_GL_ACTUAL))) {
            writer.write(ApplicationConstants.ACTUAL_HEADER);
            for (ArrayList<String> value : arrayList)
                writer.write(value.toString().replace("[", "").replace("]", "") + "\n");
        }
    }
}