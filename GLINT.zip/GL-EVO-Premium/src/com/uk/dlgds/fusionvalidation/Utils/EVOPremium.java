package com.uk.dlgds.fusionvalidation.Utils;

import com.uk.dlgds.fusionvalidation.service.CodeCombination;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.io.IOUtils;
import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.List;

public class EVOPremium {

    private JSONObject postingRules;
    private String segment1CR = "";
    private String segment2CR = "";
    private String segment3CR = "";
    private String segment4CR = "";
    private String segment5CR = "";
    private String segment6CR = "";
    private String segment7CR = "";
    private String segment8CR = "";
    private String segment9CR = "";
    private String segment10CR = "";
    private String segment1DR = "";
    private String segment2DR = "";
    private String segment3DR = "";
    private String segment4DR = "";
    private String segment5DR = "";
    private String segment6DR = "";
    private String segment7DR = "";
    private String segment8DR = "";
    private String segment9DR = "";
    private String segment10DR = "";

    private JSONObject readPostingRules() throws IOException {
        JSONObject postingRulesConfig = null;
        try (InputStream stream = Files.newInputStream(Paths.get(ApplicationConstants.POSTING_RULES_JSON_PATH))) {
            assert stream != null;
            postingRulesConfig = new JSONObject(IOUtils.toString(stream, StandardCharsets.UTF_8));
        }
        return postingRulesConfig;
    }

    public void readEvoPremiumValues() throws IOException {


        postingRules = readPostingRules();
        File sspxGLFile = new File(ApplicationConstants.EVO_SSPX_GL_EXPECTED_FILE_PATH);
        CodeCombination post = new CodeCombination();


        try (
                Reader reader = Files.newBufferedReader(Paths.get(ApplicationConstants.EVO_SSPX_GL_TEMP_FILE_PATH));
                CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT.withHeader().withIgnoreEmptyLines());
                FileWriter writer = new FileWriter(sspxGLFile);
                CSVPrinter csvPrinter = new CSVPrinter(writer, CSVFormat.DEFAULT
                        .withHeader("TRANSACTION_DATE", "TRANSACTION_NUMBER", "AHCS_EVENT_CODE", "FSH_SOURCE", "SOURCE_FILE_NAME", "ACCOUNT_NUMBER", "UNDERWRITER", "BILLING_INSTRUCTION_TYPE",
                                "ON_RISK_DATE", "OFF_RISK_DATE", "ORIGINAL_SOURCE", "ACCOUNTING_METHOD", "CREDIT_IND", "SUMMARY_FLAG", "EVENT_ID", "LINE_NUMBER", "APPLICATION_ID",
                                "BASE_AMOUNT", "CURRENCY_CODE", "ORIGINAL_AMOUNT", "LINE_OF_BUSINESS", "FSH_BRAND", "FSH_CHANNEL", "FSH_PRODUCT", "PRODUCT_TYPE", "EXCHANGE_RATE",
                                "EXCHANGE_RATE_TYPE", "EXCHANGE_DATE", "PRODUCT_KEY", "TAX_RATE", "TAX_TYPE", "DR/CR", "CODE_COMBINATION_ID", "SEGMENT1", "SEGMENT2", "SEGMENT3", "SEGMENT4", "SEGMENT5",
                                "SEGMENT6", "SEGMENT7", "SEGMENT8", "SEGMENT9", "SEGMENT10"
                        ))

        ) {
            for (CSVRecord csvRecord : csvParser) {
                String query;

                getSegmentValues(csvRecord);

                query = segment1DR.trim() + "#" + segment2DR.trim() + "#" + segment3DR.trim() + "#" + segment4DR.trim() + "#" + segment5DR.trim() + "#" + segment6DR.trim() + "#" + segment7DR.trim() + "#" + segment8DR.trim() + "#" + segment9DR.trim() + "#" + segment10DR.trim();

                csvPrinter.printRecord(csvRecord.get("TRANSACTION_DATE"), csvRecord.get("TRANSACTION_NUMBER"), csvRecord.get("AHCS_EVENT_CODE"), csvRecord.get("FSH_SOURCE"),
                        csvRecord.get("SOURCE_FILE_NAME"), csvRecord.get("ACCOUNT_NUMBER"), csvRecord.get("UNDERWRITER"), csvRecord.get("BILLING_INSTRUCTION_TYPE"),
                        csvRecord.get("ON_RISK_DATE"), csvRecord.get("OFF_RISK_DATE"), csvRecord.get("ORIGINAL_SOURCE"), csvRecord.get("ACCOUNTING_METHOD"), csvRecord.get("CREDIT_IND"),
                        csvRecord.get("SUMMARY_FLAG"), csvRecord.get("EVENT_ID"), csvRecord.get("LINE_NUMBER"), csvRecord.get("APPLICATION_ID"), csvRecord.get("BASE_AMOUNT"),
                        csvRecord.get("CURRENCY_CODE"), csvRecord.get("ORIGINAL_AMOUNT"), csvRecord.get("LINE_OF_BUSINESS"), csvRecord.get("FSH_BRAND"), csvRecord.get("FSH_CHANNEL"),
                        csvRecord.get("FSH_PRODUCT"), csvRecord.get("PRODUCT_TYPE"), csvRecord.get("EXCHANGE_RATE"), csvRecord.get("EXCHANGE_RATE_TYPE"), csvRecord.get("EXCHANGE_DATE"),
                        csvRecord.get("PRODUCT_KEY"), csvRecord.get("TAX_RATE"), csvRecord.get("TAX_TYPE"), ApplicationConstants.DR, query, segment1DR, segment2DR, segment3DR, segment4DR, segment5DR, segment6DR, segment7DR, segment8DR, segment9DR, segment10DR);


                query = segment1CR.trim() + "#" + segment2CR.trim() + "#" + segment3CR.trim() + "#" + segment4CR.trim() + "#" + segment5CR.trim() + "#" + segment6CR.trim() + "#" + segment7CR.trim() + "#" + segment8CR.trim() + "#" + segment9CR.trim() + "#" + segment10CR.trim();

                csvPrinter.printRecord(csvRecord.get("TRANSACTION_DATE"), csvRecord.get("TRANSACTION_NUMBER"), csvRecord.get("AHCS_EVENT_CODE"), csvRecord.get("FSH_SOURCE"),
                        csvRecord.get("SOURCE_FILE_NAME"), csvRecord.get("ACCOUNT_NUMBER"), csvRecord.get("UNDERWRITER"), csvRecord.get("BILLING_INSTRUCTION_TYPE"),
                        csvRecord.get("ON_RISK_DATE"), csvRecord.get("OFF_RISK_DATE"), csvRecord.get("ORIGINAL_SOURCE"), csvRecord.get("ACCOUNTING_METHOD"), csvRecord.get("CREDIT_IND"),
                        csvRecord.get("SUMMARY_FLAG"), csvRecord.get("EVENT_ID"), csvRecord.get("LINE_NUMBER"), csvRecord.get("APPLICATION_ID"), csvRecord.get("BASE_AMOUNT"),
                        csvRecord.get("CURRENCY_CODE"), csvRecord.get("ORIGINAL_AMOUNT"), csvRecord.get("LINE_OF_BUSINESS"), csvRecord.get("FSH_BRAND"), csvRecord.get("FSH_CHANNEL"),
                        csvRecord.get("FSH_PRODUCT"), csvRecord.get("PRODUCT_TYPE"), csvRecord.get("EXCHANGE_RATE"), csvRecord.get("EXCHANGE_RATE_TYPE"), csvRecord.get("EXCHANGE_DATE"),
                        csvRecord.get("PRODUCT_KEY"), csvRecord.get("TAX_RATE"), csvRecord.get("TAX_TYPE"), ApplicationConstants.CR, query, segment1CR, segment2CR, segment3CR, segment4CR, segment5CR, segment6CR, segment7CR, segment8CR, segment9CR, segment10CR);

            }
        }
    }


    private void getSegmentValues(CSVRecord csvRecord) {


        Object[] productNameJSON = postingRules.getJSONObject(ApplicationConstants.CREDIT)
                .getJSONObject(ApplicationConstants.PRODUCT_TYPE)
                .keySet().toArray();

        List<String> productName = new LinkedList<>();


        for (Object obj : productNameJSON)
            productName.add(obj.toString());

        segment1DR = postingRules.getJSONObject(ApplicationConstants.DEBIT).optString(ApplicationConstants.DLG_COMPANY, ApplicationConstants.UTD);
        segment2DR = postingRules.getJSONObject(ApplicationConstants.DEBIT).optString(ApplicationConstants.DLG_COST_CENTRE, ApplicationConstants.UTD);
        segment3DR = postingRules.getJSONObject(ApplicationConstants.DEBIT).optString(ApplicationConstants.DLG_ACCOUNT, ApplicationConstants.UTD);
        segment4DR = postingRules.getJSONObject(ApplicationConstants.DEBIT).getJSONObject(ApplicationConstants.DLG_PRODUCT).optString(csvRecord.get("LINE_OF_BUSINESS"), ApplicationConstants.UTD);
        segment5DR = postingRules.getJSONObject(ApplicationConstants.DEBIT).getJSONObject(ApplicationConstants.DLG_BRAND).optString(ApplicationConstants.DIRECT_LINE_4B, ApplicationConstants.UTD);
        segment6DR = postingRules.getJSONObject(ApplicationConstants.DEBIT).optString(ApplicationConstants.DLG_CHANNEL, ApplicationConstants.UTD);
        segment7DR = postingRules.getJSONObject(ApplicationConstants.DEBIT).optString(ApplicationConstants.DLG_INTERCO, ApplicationConstants.UTD);
        segment8DR = postingRules.getJSONObject(ApplicationConstants.DEBIT).getJSONObject(ApplicationConstants.DLG_ORIGIN).optString(ApplicationConstants.SSPX_GL_PREMIUM, ApplicationConstants.UTD);
        segment9DR = postingRules.getJSONObject(ApplicationConstants.DEBIT).optString(ApplicationConstants.DLG_SPARE1, ApplicationConstants.UTD);
        segment10DR = postingRules.getJSONObject(ApplicationConstants.DEBIT).optString(ApplicationConstants.DLG_SPARE2, ApplicationConstants.UTD);

        segment1CR = postingRules.getJSONObject(ApplicationConstants.CREDIT).optString(ApplicationConstants.DLG_COMPANY, ApplicationConstants.UTD);
        //segment2CR -> if DLG_Cost Centre
        //segment3CR -> if DLG_Account
        segment4CR = postingRules.getJSONObject(ApplicationConstants.CREDIT).getJSONObject(ApplicationConstants.DLG_PRODUCT).optString(csvRecord.get("FSH_PRODUCT"), ApplicationConstants.UTD);
        segment5CR = postingRules.getJSONObject(ApplicationConstants.CREDIT).getJSONObject(ApplicationConstants.DLG_BRAND).optString(csvRecord.get("PRODUCT_TYPE"), ApplicationConstants.UTD);
        //segment6CR -> if DLG_Channel
        segment7CR = postingRules.getJSONObject(ApplicationConstants.CREDIT).optString(ApplicationConstants.DLG_INTERCO, ApplicationConstants.UTD);
        segment8CR = postingRules.getJSONObject(ApplicationConstants.CREDIT).getJSONObject(ApplicationConstants.DLG_ORIGIN).optString(ApplicationConstants.SSPX_GL_PREMIUM, ApplicationConstants.UTD);
        segment9CR = postingRules.getJSONObject(ApplicationConstants.CREDIT).optString(ApplicationConstants.DLG_SPARE1, ApplicationConstants.UTD);
        segment10CR = postingRules.getJSONObject(ApplicationConstants.CREDIT).optString(ApplicationConstants.DLG_SPARE2, ApplicationConstants.UTD);

        String productType = postingRules.getJSONObject(ApplicationConstants.CREDIT).getJSONObject(ApplicationConstants.PRODUCT_TYPE).optString(csvRecord.get("FSH_PRODUCT"), ApplicationConstants.UTD);

        if (productType.equals(ApplicationConstants.UTD)) {
            segment2CR = postingRules.getJSONObject(ApplicationConstants.CREDIT).getJSONObject(ApplicationConstants.PRODUCT_TYPE).getJSONObject(ApplicationConstants.BLANK).optString(ApplicationConstants.DLG_COST_CENTRE, ApplicationConstants.UTD);
            segment3CR = postingRules.getJSONObject(ApplicationConstants.CREDIT).getJSONObject(ApplicationConstants.PRODUCT_TYPE).getJSONObject(ApplicationConstants.BLANK).optString(ApplicationConstants.DLG_ACCOUNT, ApplicationConstants.UTD);
            segment6CR = postingRules.getJSONObject(ApplicationConstants.CREDIT).getJSONObject(ApplicationConstants.PRODUCT_TYPE).getJSONObject(ApplicationConstants.BLANK).optString(ApplicationConstants.DLG_CHANNEL, ApplicationConstants.UTD);

        } else {
            segment2CR = postingRules.getJSONObject(ApplicationConstants.CREDIT).getJSONObject(ApplicationConstants.PRODUCT_TYPE).getJSONObject(csvRecord.get("FSH_PRODUCT")).optString(ApplicationConstants.DLG_COST_CENTRE, ApplicationConstants.UTD);
            segment3CR = postingRules.getJSONObject(ApplicationConstants.CREDIT).getJSONObject(ApplicationConstants.PRODUCT_TYPE).getJSONObject(csvRecord.get("FSH_PRODUCT")).optString(ApplicationConstants.DLG_ACCOUNT, ApplicationConstants.UTD);
            segment6CR = postingRules.getJSONObject(ApplicationConstants.CREDIT).getJSONObject(ApplicationConstants.PRODUCT_TYPE).getJSONObject(csvRecord.get("FSH_PRODUCT")).optString(ApplicationConstants.DLG_CHANNEL, ApplicationConstants.UTD);

        }
        if (segment6CR.contains(csvRecord.get("FSH_CHANNEL")))
            segment6CR = postingRules.getJSONObject(ApplicationConstants.CREDIT).getJSONObject(ApplicationConstants.PRODUCT_TYPE).getJSONObject(ApplicationConstants.BLANK).getJSONObject(ApplicationConstants.DLG_CHANNEL).optString(csvRecord.get("FSH_CHANNEL"), ApplicationConstants.UTD);


    }


}
