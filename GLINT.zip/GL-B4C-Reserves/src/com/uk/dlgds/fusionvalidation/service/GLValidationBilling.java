package com.uk.dlgds.fusionvalidation.service;

import com.uk.dlgds.fusionvalidation.utils.ApplicationConstants;
import com.uk.dlgds.fusionvalidation.utils.BillingConstants;
import com.uk.dlgds.fusionvalidation.utils.TestReport;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

public class GLValidationBilling {

    List<String> passList = new LinkedList<>();
    List<String> failList = new LinkedList<>();
    private List<List<String>> expectedList = new LinkedList<>();
    private List<List<String>> actualList = new LinkedList<>();






    private void getVaAlues() throws IOException {


        List<String> expected = Files.readAllLines(Paths.get(BillingConstants.B4C_RESERVE_EXPECTED_FILE_PATH));

        for (String value : expected) {
            List<String> list = Arrays.stream(value.trim().split(",")).map(String::trim).collect(Collectors.toList());

            expectedList.add(list);
        }

        List<String> actual = Files.readAllLines(Paths.get(BillingConstants.B4C_RESERVE_ACTUAL));
        for (String value : actual) {
            List<String> list = Arrays.stream(value.trim().split(",")).map(String::trim).collect(Collectors.toList());
            actualList.add(replaceCRDRactualList(list));
        }
        expectedList.remove(0);
        actualList.remove(0);
    }

    private List<String> replaceCRDRactualList(List<String> list) {
        int index;
        if (list.contains(BillingConstants.DLG_MISC_CR)) {
            index = list.indexOf(BillingConstants.DLG_MISC_CR);
            list.remove(index);
            list.add(index, BillingConstants.CR);
        }

        if (list.contains(BillingConstants.DLG_MISC_DR)) {
            index = list.indexOf(BillingConstants.DLG_MISC_DR);
            list.remove(index);
            list.add(index, BillingConstants.DR);
        }
        return list;

    }

    public void validateEvoBilling(TestReport testReport) throws IOException {
         StringBuilder expectedStringBuilder ;
         StringBuilder actualStringBuilder;
         StringBuilder expectedValues ;

        getVaAlues();

        for (List<String> expected : expectedList) {

            if(expected.get(BillingConstants.BASE_AMOUNT_EXPECTED).replace("-", "").trim().equals("0"))
                continue;

            String actualPublishedResultTestReport = "";
            String actualPublishedResultFailTestReport = "";
            String actualPublishedResult = "";
            String actualPublishedResultFail = "";

            String dataPublishedResult = String.format("%s,%s,%s,%s,%s,%s,%s,%s,%s ", expected.get(ApplicationConstants.SOURCE_FILE_NAME_EXPECTED),
                    expected.get(BillingConstants.TRANSACTION_NUMBER_EXPECTED),
                    expected.get(BillingConstants.TRANSACTION_DATE_EXPECTED).replace("T00:00:00.000+00:00", ""),
                    expected.get(BillingConstants.FSH_BRAND_EXPECTED),
                    expected.get(BillingConstants.FSH_PRODUCT_EXPECTED),
                    expected.get(BillingConstants.EVENT_ID_EXPECTED),
                    expected.get(BillingConstants.CURRENCY_CODE_EXPECTED),
                    expected.get(BillingConstants.AHCS_EVENT_CODE_EXPECTED),
                    expected.get(BillingConstants.FSH_CHANNEL_EXPECTED));

            String segmentTestReport = String.format("%s-%s-%s-%s-%s-%s-%s-%s-%s-%s ",
                    expected.get(BillingConstants.SEGMENT1_EXPECTED),
                    expected.get(BillingConstants.SEGMENT2_EXPECTED),
                    expected.get(BillingConstants.SEGMENT3_EXPECTED),
                    expected.get(BillingConstants.SEGMENT4_EXPECTED),
                    expected.get(BillingConstants.SEGMENT5_EXPECTED),
                    expected.get(BillingConstants.SEGMENT6_EXPECTED),
                    expected.get(BillingConstants.SEGMENT7_EXPECTED),
                    expected.get(BillingConstants.SEGMENT8_EXPECTED),
                    expected.get(BillingConstants.SEGMENT9_EXPECTED),
                    expected.get(BillingConstants.SEGMENT10_EXPECTED));

            String expectedPublishedResult = String.format("%s,%s,%s,%s,%s ",
                    expected.get(BillingConstants.DR_CR_EXPECTED),
                    expected.get(BillingConstants.BASE_AMOUNT_EXPECTED),
                    expected.get(BillingConstants.CODE_COMBINATION_ID_EXPECTED),
                    expected.get(BillingConstants.LINE_OF_BUSINESS_EXPECTED),
                    segmentTestReport);

            expectedStringBuilder = new StringBuilder();
            expectedStringBuilder.append(expected.get(BillingConstants.CODE_COMBINATION_ID_EXPECTED));
            expectedStringBuilder.append(expected.get(BillingConstants.BASE_AMOUNT_EXPECTED).replace("-", ""));
            expectedStringBuilder.append(expected.get(BillingConstants.DR_CR_EXPECTED));
            expectedStringBuilder.append(expected.get(BillingConstants.TRANSACTION_NUMBER_EXPECTED));

            expectedValues = new StringBuilder();
            expectedValues.append(expected.get(BillingConstants.APPLICATION_ID_EXPECTED));
            expectedValues.append(expected.get(BillingConstants.LINE_OF_BUSINESS_EXPECTED));
            expectedValues.append(expected.get(BillingConstants.FSH_BRAND_EXPECTED));
            expectedValues.append(expected.get(BillingConstants.FSH_CHANNEL_EXPECTED));
            expectedValues.append(expected.get(BillingConstants.FSH_PRODUCT_EXPECTED));
            expectedValues.append(expected.get(BillingConstants.LINE_OF_BUSINESS_EXPECTED));
            expectedValues.append(expected.get(BillingConstants.PRODUCT_TYPE_EXPECTED));
            expectedValues.append(expected.get(BillingConstants.PRODUCT_KEY_EXPECTED));

            String expectedPassValue = expected.toString().replace("[", "").replace("]", "");

            for (List<String> actual : actualList) {
                String amountActual = String.format("%s%s", actual.get(BillingConstants.ENTERED_CR_ACTUAL), actual.get(BillingConstants.ENTERED_DR_ACTUAL)).trim();
                actualStringBuilder = new StringBuilder();
                actualStringBuilder.append(actual.get(BillingConstants.CODE_COMBINATION_ID_ACTUAL));
                actualStringBuilder.append(amountActual);
                actualStringBuilder.append(actual.get(BillingConstants.ACCOUNTING_CLASS_CODE_ACTUAL));
                actualStringBuilder.append(actual.get(BillingConstants.TRANSACTION_NUMBER_ACTUAL));

                actualPublishedResult = String.format("%s,%s,%s,%s,%s ",
                        actual.get(BillingConstants.ACCOUNTING_CLASS_CODE_ACTUAL),
                        amountActual,
                        actual.get(BillingConstants.CODE_COMBINATION_ID_ACTUAL),
                        actual.get(BillingConstants.LINE_OF_BUSINESS_ACTUAL),
                        segmentTestReport);

                actualPublishedResultFail = String.format("%s,%s,%s,%s, ",
                        actual.get(BillingConstants.ACCOUNTING_CLASS_CODE_ACTUAL),
                        amountActual,
                        actual.get(BillingConstants.CODE_COMBINATION_ID_ACTUAL),
                        actual.get(BillingConstants.LINE_OF_BUSINESS_ACTUAL));

                if (expectedStringBuilder.toString().equals(actualStringBuilder.toString())) {
                        passList.add(expectedPassValue);
                        actualPublishedResultTestReport = actualPublishedResult;
                    } else{
                        actualPublishedResultFailTestReport = actualPublishedResultFail;
                }

            }



            if (passList.stream().filter(o -> o.equals(expectedPassValue)).count() == 1) {

                testReport.setValuesToReport(dataPublishedResult, expectedPublishedResult, actualPublishedResultTestReport, TestReport.PASS, "Expected Data is available in Actuals and code combinations is matched");

            }
            if (passList.stream().filter(o -> o.equals(expectedPassValue)).count() > 1) {

                testReport.setValuesToReport(dataPublishedResult, expectedPublishedResult, actualPublishedResultTestReport, TestReport.WARNING, "Code combination is matched but Expected Data is available in Actuals for multiple records - Kindly check");
            }
             if (!passList.contains(expectedPassValue)) {

                testReport.setValuesToReport(dataPublishedResult, expectedPublishedResult, actualPublishedResultFailTestReport, TestReport.FAIL, "Code combinations is not matched - Kindly check");
            }
        }


    }
}

