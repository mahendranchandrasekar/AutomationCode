package com.uk.dlgds.fusionvalidation.service;

import com.uk.dlgds.fusionvalidation.utils.BillingConstants;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.dom4j.Node;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import javax.xml.xpath.XPathExpressionException;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class ReadOuput {

    public void createTempCSV(org.w3c.dom.Document elementOutput, File newFile) throws IOException, XPathExpressionException {
        elementOutput.getDocumentElement().normalize();
        System.out.println("Root element: " + elementOutput.getDocumentElement().getNodeName());
        NodeList nList = elementOutput.getElementsByTagName("GLB4CRESERV");
        try (
                FileWriter writer = new FileWriter(newFile);
                CSVPrinter csvPrinter = new CSVPrinter(writer, CSVFormat.DEFAULT
                        .withHeader(BillingConstants.TRANSACTION_DATE_HEADER_STR,BillingConstants.TRANSACTION_NUMBER_HEADER_STR,BillingConstants.AHCS_EVENT_CODE_HEADER_STR,
                                BillingConstants.FSH_SOURCE_HEADER_STR,BillingConstants.SOURCE_FILE_NAME_HEADER_STR,BillingConstants.RESERVE_FLAG_NUMBER_HEADER_STR,
                                BillingConstants.UNDERWRITER_HEADER_STR,BillingConstants.SUMMARY_FLAG_HEADER_STR,BillingConstants.EVENT_ID_HEADER_STR,BillingConstants.LINE_NUMBER_HEADER_STR,
                                BillingConstants.APPLICATION_ID_HEADER_STR,BillingConstants.BASE_AMOUNT_HEADER_STR,BillingConstants.CURRENCY_CODE_HEADER_STR,BillingConstants.ORIGINAL_AMOUNT_HEADER_STR,
                                BillingConstants.LINE_OF_BUSINESS_HEADER_STR,BillingConstants.FSH_BRAND_HEADER_STR,BillingConstants.FSH_CHANNEL_HEADER_STR,BillingConstants.FSH_PRODUCT_HEADER_STR,
                                BillingConstants.PRODUCT_TYPE_HEADER_STR,BillingConstants.EXCHANGE_RATE_HEADER_STR,BillingConstants.EXCHANGE_RATE_TYPE_HEADER_STR,BillingConstants.EXCHANGE_DATE_HEADER_STR,
                                BillingConstants.PRODUCT_KEY_HEADER_STR));
        ) {
            for (int temp = 0; temp < nList.getLength(); temp++) {
                org.w3c.dom.Node nNode = nList.item(temp);
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    csvPrinter.printRecord(eElement.getElementsByTagName(BillingConstants.TRANSACTION_DATE_HEADER_STR).item(0).getTextContent(),
                            eElement.getElementsByTagName(BillingConstants.TRANSACTION_NUMBER_HEADER_STR).item(0).getTextContent(),
                            eElement.getElementsByTagName(BillingConstants.AHCS_EVENT_CODE_HEADER_STR).item(0).getTextContent(),
                            eElement.getElementsByTagName(BillingConstants.FSH_SOURCE_HEADER_STR).item(0).getTextContent(),
                            eElement.getElementsByTagName(BillingConstants.SOURCE_FILE_NAME_HEADER_STR).item(0).getTextContent(),
                            eElement.getElementsByTagName(BillingConstants.RESERVE_FLAG_NUMBER_HEADER_STR).item(0).getTextContent(),
                            eElement.getElementsByTagName(BillingConstants.UNDERWRITER_HEADER_STR).item(0).getTextContent(),
                            ApplicationDetails.getNodeData(eElement,BillingConstants.SUMMARY_FLAG_HEADER_STR),
                            //eElement.getElementsByTagName(BillingConstants.SUMMARY_FLAG_HEADER_STR).item(0).getTextContent(),
                            eElement.getElementsByTagName(BillingConstants.EVENT_ID_HEADER_STR).item(0).getTextContent(),
                            eElement.getElementsByTagName(BillingConstants.LINE_NUMBER_HEADER_STR).item(0).getTextContent(),
                            eElement.getElementsByTagName(BillingConstants.APPLICATION_ID_HEADER_STR).item(0).getTextContent(),
                            eElement.getElementsByTagName(BillingConstants.BASE_AMOUNT_HEADER_STR).item(0).getTextContent(),
                            eElement.getElementsByTagName(BillingConstants.CURRENCY_CODE_HEADER_STR).item(0).getTextContent(),
                            eElement.getElementsByTagName(BillingConstants.ORIGINAL_AMOUNT_HEADER_STR).item(0).getTextContent(),
                            eElement.getElementsByTagName(BillingConstants.LINE_OF_BUSINESS_HEADER_STR).item(0).getTextContent(),
                            eElement.getElementsByTagName(BillingConstants.FSH_BRAND_HEADER_STR).item(0).getTextContent(),
                            eElement.getElementsByTagName(BillingConstants.FSH_CHANNEL_HEADER_STR).item(0).getTextContent(),
                            eElement.getElementsByTagName(BillingConstants.FSH_PRODUCT_HEADER_STR).item(0).getTextContent(),
                            eElement.getElementsByTagName(BillingConstants.PRODUCT_TYPE_HEADER_STR).item(0).getTextContent(),
                            eElement.getElementsByTagName(BillingConstants.EXCHANGE_RATE_HEADER_STR).item(0).getTextContent(),
                            eElement.getElementsByTagName(BillingConstants.EXCHANGE_RATE_TYPE_HEADER_STR).item(0).getTextContent(),
                            ApplicationDetails.getNodeData(eElement,BillingConstants.EXCHANGE_DATE_HEADER_STR),
                            //eElement.getElementsByTagName(BillingConstants.EXCHANGE_DATE_HEADER_STR).item(0).getTextContent(),
                            eElement.getElementsByTagName(BillingConstants.PRODUCT_KEY_HEADER_STR).item(0).getTextContent()
                    );
                }
            }
        }
    }
}
