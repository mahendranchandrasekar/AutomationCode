package com.uk.dlgds.fusionvalidation.service;


import org.dom4j.Node;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPathExpressionException;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Objects;

import static javax.xml.parsers.DocumentBuilderFactory.newInstance;

public class EndpointValidation {


    private final ApplicationDetails applicationDetails = new ApplicationDetails();
    private ReadOuputBilling readOutput = new ReadOuputBilling();
    private String username;
    private String password;
    private String url;
    private String ip;
    private String port;
    private String runInDLG;


    public void triggerEndPoint(String fileName, File newFile) throws IOException, ParserConfigurationException, SAXException, TransformerException, Exception {


        readValues();

        HttpURLConnection con = null;
        Proxy proxy = null;
        URL obj = null;

        if (runInDLG.equalsIgnoreCase("yes")) {
            proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(ip, Integer.parseInt(port)));
            obj = new URL(url);
            con = (HttpURLConnection) obj.openConnection(proxy);
        } else {
            obj = new URL(url);
            con = (HttpURLConnection) obj.openConnection();
        }

        con.setRequestMethod("POST");
        con.setRequestProperty("Content-Type", "application/soap+xml; charset=utf-8");
        con.setRequestProperty("Authorization", "Basic " + encodeCredentials());
        con.setDoOutput(true);
        DataOutputStream wr = new DataOutputStream(con.getOutputStream());

        wr.writeBytes(updateQuery(readInputXML("EXPECTEDRequest"), fileName));
        wr.flush();
        wr.close();
        org.w3c.dom.Document document = convertStringToXMLDocument(readResponse(con).toString());
        String nodes = document.getElementsByTagName("ns2:runReportResponse").item(0).getTextContent();
        byte[] byteArray = Base64.getDecoder().decode(nodes.substring(0, nodes.length() - 8));
        String output = new String(byteArray);

        output = output.replaceAll("[\\r\\n]", "");
        readOutput.createTempCSV(convertStringToXMLDocument(output), newFile);

    }

    public org.w3c.dom.Document readInputXML(String fileName) throws IOException, ParserConfigurationException, SAXException {
        org.w3c.dom.Document document = null;
        try (InputStream stream = getClass().getClassLoader().getResourceAsStream("com/uk/dlgds/fusionvalidation/resources/samples/" + fileName + ".xml")) {
            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
            document = docBuilder.parse(Objects.requireNonNull(stream));
        }
        return document;

    }

    public String encodeCredentials() {

        return Base64.getEncoder().encodeToString((username + ":" + password).getBytes(StandardCharsets.UTF_8));

    }

    public String updateQuery(org.w3c.dom.Document inputXML, String values) throws TransformerException {

        inputXML.getElementsByTagName("pub:item").item(1).setTextContent(values);
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();
        transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
        DOMSource source = new DOMSource(inputXML);
        StringWriter strWriter = new StringWriter();
        StreamResult result = new StreamResult(strWriter);
        transformer.transform(source, result);
        String output = strWriter.getBuffer().toString();
        output = output.replaceAll("[\\r\\n]", "");
        return output;

    }


    public String updateQuerySegments(org.w3c.dom.Document inputXML, String values) throws TransformerException {
        int itemIndex = 1;

        String segment[] = values.split("#");


        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();
        transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
        DOMSource source = new DOMSource(inputXML);
        StringWriter strWriter = new StringWriter();
        StreamResult result = new StreamResult(strWriter);
        transformer.transform(source, result);
        String output = strWriter.getBuffer().toString();
        output = output.replaceAll("[\\r\\n]", "");

        output = output.replace("##segment1##",segment[0]);
        output = output.replace("##segment2##",segment[1]);
        output = output.replace("##segment3##",segment[2]);
        output = output.replace("##segment4##",segment[3]);
        output = output.replace("##segment5##",segment[4]);
        output = output.replace("##segment6##",segment[5]);
        output = output.replace("##segment7##",segment[6]);
        output = output.replace("##segment8##",segment[7]);
        output = output.replace("##segment9##",segment[8]);
        output = output.replace("##segment10##",segment[9]);

        return output;

    }

    public StringBuffer readResponse(HttpURLConnection con) throws IOException {

        BufferedReader in = null;
        if (con.getResponseCode() == 200) {
            in = new BufferedReader(new
                    InputStreamReader(con.getInputStream()));
        } else {
            in = new BufferedReader(new
                    InputStreamReader(con.getErrorStream()));
            System.exit(0);
        }
        String inputLine;
        StringBuffer response = new StringBuffer();
        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();
        return response;
    }

    public org.w3c.dom.Document convertStringToXMLDocument(String xmlString) throws ParserConfigurationException, IOException, SAXException {

        DocumentBuilderFactory docBuilderFactory = newInstance();
        DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
        return docBuilder.parse(new InputSource(new StringReader(xmlString)));
    }

    public List<ArrayList<String>> triggerActualEndPoint(String query) throws IOException, ParserConfigurationException, SAXException, TransformerException, XPathExpressionException {

        readValues();


        HttpURLConnection con = null;
        Proxy proxy = null;
        URL obj = null;

        if (runInDLG.equalsIgnoreCase("yes")) {
            proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(ip, Integer.parseInt(port)));
            obj = new URL(url);
            con = (HttpURLConnection) obj.openConnection(proxy);
        } else {
            obj = new URL(url);
            con = (HttpURLConnection) obj.openConnection();
        }

        con.setRequestMethod("POST");
        con.setRequestProperty("Content-Type", "application/soap+xml; charset=utf-8");
        con.setRequestProperty("Authorization", "Basic " + encodeCredentials());
        con.setDoOutput(true);
        DataOutputStream wr = new DataOutputStream(con.getOutputStream());
        wr.writeBytes(updateQuery(readInputXML("ACTUALRequest"), query));
        wr.flush();
        wr.close();
        org.w3c.dom.Document document = convertStringToXMLDocument(readResponse(con).toString());
        String nodes = document.getElementsByTagName("ns2:runReportResponse").item(0).getTextContent();
        byte[] byteArray = Base64.getDecoder().decode(nodes.substring(0, nodes.length() - 8));
        String output = new String(byteArray);
        return readActualOutput(convertStringToXMLDocument(output));


    }


    public List<ArrayList<String>> readActualOutput(org.w3c.dom.Document elementOutput) throws XPathExpressionException {
        ArrayList<ArrayList<String>> config = new ArrayList<>();


        NodeList nList = elementOutput.getElementsByTagName("GLEVOBILLNG");

        for (int temp = 0; temp < nList.getLength(); temp++) {
            ArrayList<String> responseValues = new ArrayList<>();
            org.w3c.dom.Node nNode = nList.item(temp);
            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                Element eElement = (Element) nNode;
                System.out.println(eElement);


                String enteredDr = "";
                NodeList nl = eElement.getElementsByTagName("ENTERED_DR");
                if (nl.getLength() > 0)
                    enteredDr = eElement.getElementsByTagName("ENTERED_DR").item(0).getTextContent();

                String enteredCr = "";
                nl = eElement.getElementsByTagName("ENTERED_CR");
                if (nl.getLength() > 0)
                    enteredCr = eElement.getElementsByTagName("ENTERED_CR").item(0).getTextContent();

                String sr32 = "";
                nl = eElement.getElementsByTagName("SR32");
                if (nl.getLength() > 0)
                    sr32 = eElement.getElementsByTagName("SR32").item(0).getTextContent();

                String sr33 = "";
                nl = eElement.getElementsByTagName("SR33");
                if (nl.getLength() > 0)
                    sr33 = eElement.getElementsByTagName("SR33").item(0).getTextContent();


                responseValues.add(eElement.getElementsByTagName("APPLICATION_ID").item(0).getTextContent());  //"APPLICATION_ID",
                responseValues.add(eElement.getElementsByTagName("CODE_COMBINATION_ID").item(0).getTextContent());  //"CODE_COMBINATION_ID"
                responseValues.add(eElement.getElementsByTagName("ACCOUNTING_CLASS_CODE").item(0).getTextContent()); //"ACCOUNTING_CLASS_CODE"
                responseValues.add(enteredDr);   //"ENTERED_DR"
                responseValues.add(enteredCr);
                responseValues.add(eElement.getElementsByTagName("CURRENCY_CODE").item(0).getTextContent());
                responseValues.add(sr32);
                responseValues.add(sr33);

                String description = eElement.getElementsByTagName("DESCRIPTION").item(0).getTextContent();
                String[] descriptions = description.split(",");
                String lineOfBusiness = "";
                for (String eachDesc : descriptions) {
                    if (eachDesc.contains("LOB")) {
                        lineOfBusiness = eachDesc.split(":")[1].trim();
                    }
                }
                responseValues.add(lineOfBusiness);
                responseValues.add(eElement.getElementsByTagName("TRANSACTION_NUMBER").item(0).getTextContent());
                config.add(responseValues);
            }

        }

        return config;

    }


    public void readValues() throws IOException {

        String runner = "JENKINS";

        username = applicationDetails.readProperties("com.uk.dlgds.username").trim();
        password = applicationDetails.readProperties("com.uk.dlgds.password").trim();
        url = applicationDetails.readProperties("com.uk.dlgds.endpoint.url").trim();

        if (System.getProperty("runner.name").equals(runner))
            ip = applicationDetails.readProperties("com.uk.dlgds.proxy.ip.jenkins").trim();
        else
            ip = applicationDetails.readProperties("com.uk.dlgds.proxy.ip").trim();

        port = applicationDetails.readProperties("com.uk.dlgds.proxy.port").trim();

        runInDLG = applicationDetails.readProperties("com.uk.dlgds.run.runInDLG").trim();


    }

}
