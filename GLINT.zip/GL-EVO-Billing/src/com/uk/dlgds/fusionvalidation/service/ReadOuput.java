package com.uk.dlgds.fusionvalidation.service;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.dom4j.Node;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class ReadOuput {

    public void createTempCSV(org.w3c.dom.Document elementOutput, File newFile) throws IOException {
        NodeList nList = elementOutput.getElementsByTagName("Output");
        try (
                FileWriter writer = new FileWriter(newFile);
                CSVPrinter csvPrinter = new CSVPrinter(writer, CSVFormat.DEFAULT
                        .withHeader("TRANSACTION_DATE","TRANSACTION_NUMBER","AHCS_EVENT_CODE","FSH_SOURCE","SOURCE_FILE_NAME","ACCOUNT_NUMBER","UNDERWRITER",
                                "BILLING_INSTRUCTION_TYPE", "ON_RISK_DATE","OFF_RISK_DATE","ORIGINAL_SOURCE","ACCOUNTING_METHOD",
                                "CREDIT_IND","SUMMARY_FLAG","EVENT_ID", "LINE_NUMBER","APPLICATION_ID","BASE_AMOUNT","CURRENCY_CODE","ORIGINAL_AMOUNT",
                                "LINE_OF_BUSINESS","FSH_BRAND","FSH_CHANNEL","FSH_PRODUCT", "PRODUCT_TYPE","EXCHANGE_RATE","EXCHANGE_RATE_TYPE",
                                "EXCHANGE_DATE","PRODUCT_KEY","TAX_RATE","TAX_TYPE"
                        ));
        ) {
            for (int temp = 0; temp < nList.getLength(); temp++) {
                org.w3c.dom.Node nNode = nList.item(temp);
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    csvPrinter.printRecord(eElement.getElementsByTagName("TRANSACTION_DATE").item(0).getTextContent(),
                            eElement.getElementsByTagName("TRANSACTION_NUMBER").item(0).getTextContent(),
                            eElement.getElementsByTagName("AHCS_EVENT_CODE").item(0).getTextContent(),
                            eElement.getElementsByTagName("FSH_SOURCE").item(0).getTextContent(),
                            eElement.getElementsByTagName("SOURCE_FILE_NAME").item(0).getTextContent(),
                            eElement.getElementsByTagName("ACCOUNT_NUMBER").item(0).getTextContent(),
                            eElement.getElementsByTagName("UNDERWRITER").item(0).getTextContent(),
                            eElement.getElementsByTagName("BILLING_INSTRUCTION_TYPE").item(0).getTextContent(),
                            eElement.getElementsByTagName("ON_RISK_DATE").item(0).getTextContent(),
                            eElement.getElementsByTagName("OFF_RISK_DATE").item(0).getTextContent(),
                            eElement.getElementsByTagName("ORIGINAL_SOURCE").item(0).getTextContent(),
                            eElement.getElementsByTagName("ACCOUNTING_METHOD").item(0).getTextContent(),
                            eElement.getElementsByTagName("CREDIT_IND").item(0).getTextContent(),
                            eElement.getElementsByTagName("SUMMARY_FLAG").item(0).getTextContent(),
                            eElement.getElementsByTagName("EVENT_ID").item(0).getTextContent(),
                            eElement.getElementsByTagName("LINE_NUMBER").item(0).getTextContent(),
                            eElement.getElementsByTagName("APPLICATION_ID").item(0).getTextContent(),
                            eElement.getElementsByTagName("BASE_AMOUNT").item(0).getTextContent(),
                            eElement.getElementsByTagName("CURRENCY_CODE").item(0).getTextContent(),
                            eElement.getElementsByTagName("ORIGINAL_AMOUNT").item(0).getTextContent(),
                            eElement.getElementsByTagName("LINE_OF_BUSINESS").item(0).getTextContent(),
                            eElement.getElementsByTagName("FSH_BRAND").item(0).getTextContent(),
                            eElement.getElementsByTagName("FSH_CHANNEL").item(0).getTextContent(),
                            eElement.getElementsByTagName("FSH_PRODUCT").item(0).getTextContent(),
                            eElement.getElementsByTagName("PRODUCT_TYPE").item(0).getTextContent(),
                            eElement.getElementsByTagName("EXCHANGE_RATE").item(0).getTextContent(),
                            eElement.getElementsByTagName("EXCHANGE_RATE_TYPE").item(0).getTextContent(),
                            eElement.getElementsByTagName("EXCHANGE_DATE").item(0).getTextContent(),
                            eElement.getElementsByTagName("PRODUCT_KEY").item(0).getTextContent(),
                            eElement.getElementsByTagName("TAX_RATE").item(0).getTextContent(),
                            eElement.getElementsByTagName("TAX_TYPE").item(0).getTextContent()
                    );
                }
            }
        }
    }
}
