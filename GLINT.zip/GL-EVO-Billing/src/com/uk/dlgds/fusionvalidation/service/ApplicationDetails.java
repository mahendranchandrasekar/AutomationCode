package com.uk.dlgds.fusionvalidation.service;

import org.apache.commons.io.IOUtils;
import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import javax.xml.xpath.*;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Properties;

public class ApplicationDetails {

    public JSONObject readJournalFile(String path) throws IOException {

        final InputStream readQuery = getClass().getClassLoader().getResourceAsStream(path);
        return new JSONObject(IOUtils.toString(readQuery, StandardCharsets.UTF_8));

    }

    public String readProperties(String value) throws IOException {
        Properties credentials = new Properties();
        try (InputStream stream = getClass().getClassLoader().getResourceAsStream("application.properties")) {
            credentials.load(stream);
            return credentials.getProperty(value).trim();
        }
    }


    public static boolean checkIfNodeExists(Document document, String xpathExpression) throws XPathExpressionException
    {
        boolean matches = false;

        // Create XPathFactory object
        XPathFactory xpathFactory = XPathFactory.newInstance();

        // Create XPath object
        XPath xpath = xpathFactory.newXPath();

        try {
            // Create XPathExpression object
            XPathExpression expr = xpath.compile(xpathExpression);

            // Evaluate expression result on XML document
            NodeList nodes = (NodeList) expr.evaluate(document, XPathConstants.NODESET);

            if(nodes != null  && nodes.getLength() > 0) {
                matches = true;
            }

        } catch (XPathExpressionException e) {
            e.printStackTrace();
        }
        return matches;
    }

}
