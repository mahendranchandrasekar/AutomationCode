package com.uk.dlgds.fusionvalidation.utils;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class TestReport {

    public static final String PASS = "pass";
    public static final String FAIL = "fail";
    public static final String WARNING = "warning";
    private static final String COMMA_SPLIT = ",";
    private static final String TABLE_PATH = "./src/com/uk/dlgds/fusionvalidation/utils/table.htm";
    private static final String XLA_TABLE_PATH = "./src/com/uk/dlgds/fusionvalidation/utils/XLAtable.htm";
    private static final String REPORT_PATH = "./src/com/uk/dlgds/fusionvalidation/utils/report.htm";
    private static final String REPORT_OUTPUT = "./src/com/uk/dlgds/fusionvalidation/utils/reportOutput.html";
    private static final String DATE_FORMAT_REPORT_NAME = "yyyy_MM_dd_HH_mm_ss";
    private static final String DATE_FORMAT_REPORT = "yyyy_MM_dd HH:mm:ss";
    private int sNo = 0;

    int crDr = 0;
    int amount = 1;
    int codeCombinationId = 2;
    int lob = 3;
    int segment = 4;
    private String reportName;


    protected String filesProcessed;
    protected String filesNotProcessed;
    protected String fileName;
    protected String transactionNumber;
    protected String reportDate;
    protected String trnDate;
    protected String brand;
    protected String product;
    protected String eventId;
    protected String currency;
    protected String ahcsEventCode;
    protected String fshChannel;
    protected String crDrActual;
    protected String amountActual;
    protected String codeCombinationIdActual;
    protected String lobActual;
    protected String segmentActual;
    protected String crDrExpected;
    protected String amountExpected;
    protected String codeCombinationIdExpected;
    protected String lobExpected;
    protected String segmentExpected;
    protected String testResult;
    protected String testResultMsg;
    private String htmlReport="";
    private String table="";
    private String xlaTable ="";
    private Map<String, String> replaceValueMap = new HashMap<>();

    public TestReport() {
        DateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT_REPORT);
        Date date = new Date();

        setBlankValues();
        setReportName("EVO Billing - FSH to AHCS/GL Integration Test Report");
        setReportDate(dateFormat.format(date));
        setFilesProcessed("< ---NO--DATA--- >");
        setFilesNotProcessed("< ---NO--DATA--- >");
        readReport();
    }

    public void setExpectedValues(String expectedValues) {
        expectedValues = expectedValues.trim();
        setCrDrExpected(expectedValues.split(COMMA_SPLIT)[crDr]);
        setAmountExpected(expectedValues.split(COMMA_SPLIT)[amount]);
        setCodeCombinationIdExpected(expectedValues.split(COMMA_SPLIT)[codeCombinationId]);
        setLobExpected(expectedValues.split(COMMA_SPLIT)[lob]);
        setSegmentExpected(expectedValues.split(COMMA_SPLIT)[segment]);

    }

    public void setActualValues(String actualValues) {

        actualValues = actualValues.trim();

        try {
            setCrDrActual(actualValues.split(COMMA_SPLIT)[crDr]);
            setAmountActual(actualValues.split(COMMA_SPLIT)[amount]);
            setCodeCombinationIdActual(actualValues.split(COMMA_SPLIT)[codeCombinationId]);
            setLobActual(actualValues.split(COMMA_SPLIT)[lob]);
            setSegmentActual(actualValues.split(COMMA_SPLIT)[segment]);
        } catch (Exception e) {
            setCrDrActual("");
            setAmountActual("");
            setCodeCombinationIdActual("");
            setLobActual("");
            setSegmentActual("");
        }
    }

    public void setDataValues(String dataValues) {

        dataValues = dataValues.trim();
        DateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT_REPORT);
        Date date = new Date();


        int fileNameIndex = 0;
        int transactionNumberIndex = 1;
        int trnDateIndex = 2;
        int brandIndex = 3;
        int productIndex = 4;
        int eventIdIndex = 5;
        int currencyIndex = 6;
        int ahcsEventCodeIndex = 7;
        int fshChannelIndex = 8;


        setReportName("EVO Billing - FSH to AHCS/GL Integration Test Report");
        setReportDate(dateFormat.format(date));
        setFileName(dataValues.split(COMMA_SPLIT)[fileNameIndex]);
        setTransactionNumber(dataValues.split(COMMA_SPLIT)[transactionNumberIndex]);
        setTrnDate(dataValues.split(COMMA_SPLIT)[trnDateIndex]);
        setBrand(dataValues.split(COMMA_SPLIT)[brandIndex]);
        setProduct(dataValues.split(COMMA_SPLIT)[productIndex]);
        setEventId(dataValues.split(COMMA_SPLIT)[eventIdIndex]);
        setCurrency(dataValues.split(COMMA_SPLIT)[currencyIndex]);
        setAhcsEventCode(dataValues.split(COMMA_SPLIT)[ahcsEventCodeIndex]);
        setFshChannel(dataValues.split(COMMA_SPLIT)[fshChannelIndex]);
    }

    public void setResultData(String result, String resultMsg) {

        if (result.trim().equalsIgnoreCase(PASS)) {
            setTestResult("<span style=\"background-color: rgb(0, 254, 0);font-weight: bold;\">PASS</span>");
        } else if (result.trim().equalsIgnoreCase(FAIL)) {
            setTestResult("<span style=\"background-color: rgb(254, 0, 0);font-weight: bold;\">FAIL</span>");
        } else if (result.trim().equalsIgnoreCase(WARNING)) {
            setTestResult("<span style=\"background-color: rgb(254, 216, 0);font-weight: bold;\">WARNING</span>");
        }

        setTestResultMsg(resultMsg);


    }

    public void setValuesToReport(String dataValues, String expectedValues, String actualValues, String result, String resultMsg) throws IOException {

        readTable();
        readXLATable();

        setBlankValues();
        setDataValues(dataValues);
        setExpectedValues(expectedValues);
        setActualValues(actualValues);
        setResultData(result, resultMsg);

        writeTable();
        replaceTableValues();
        pushReport();

    }

    public void setBlankValues() {
        this.reportName = "";
        this.fileName = "";
        this.transactionNumber = "";
        this.trnDate = "";
        this.brand = "";
        this.product = "";
        this.eventId = "";
        this.currency = "";
        this.ahcsEventCode = "";
        this.fshChannel = "";
        this.crDrActual = "";
        this.amountActual = "";
        this.codeCombinationIdActual = "";
        this.lobActual = "";
        this.segmentActual = "";
        this.crDrExpected = "";
        this.amountExpected = "";
        this.codeCombinationIdExpected = "";
        this.lobExpected = "";
        this.segmentExpected = "";
        this.testResult = "";
        this.testResultMsg = "";
    }

    private void setReportName(String reportName) {
        this.reportName = reportName;
        replaceValueMap.put("##report_name##", this.reportName);
    }

    public void setFilesProcessed(String filesProcessed) {

        this.filesProcessed = filesProcessed;
        replaceValueMap.put("##files_processed##", this.filesProcessed);
    }

    public void setFilesNotProcessed(String filesNotProcessed) {
        this.filesNotProcessed = filesNotProcessed;
        replaceValueMap.put("##files_not_processed##", filesNotProcessed);
    }

    private void setFileName(String fileName) {
        this.fileName = fileName;
        replaceValueMap.put("##file_name##", fileName);
    }

    private void setReportDate(String reportDate) {
        this.reportDate = reportDate;
        replaceValueMap.put("##date_time##", reportDate);
    }

    private void setTransactionNumber(String transactionNumber) {
        this.transactionNumber = transactionNumber;
        replaceValueMap.put("##transaction_number##", transactionNumber);
    }

    private void setTrnDate(String trnDate) {
        this.trnDate = trnDate;
        replaceValueMap.put("#trn_date#", trnDate);
    }

    private void setEventId(String eventId) {
        this.eventId = eventId;
        replaceValueMap.put("#event_id#", eventId);
    }

    private void setCurrency(String currency) {
        this.currency = currency;
        replaceValueMap.put("#currency#", currency);
    }

    private void setAhcsEventCode(String ahcsEventCode) {
        this.ahcsEventCode = ahcsEventCode;
        replaceValueMap.put("#ahcs_event_code#", ahcsEventCode);
    }

    private void setFshChannel(String fshChannel) {
        this.fshChannel = fshChannel;
        replaceValueMap.put("#fsh_channel#", fshChannel);
    }

    private void setLobActual(String lobActual) {
        this.lobActual = lobActual;
        replaceValueMap.put("#actual_lob#", lobActual);
    }

    private void setSegmentActual(String segmentActual) {
        this.segmentActual = segmentActual;
        replaceValueMap.put("#actual_segment#", segmentActual);
    }

    private void setLobExpected(String lobExpected) {
        this.lobExpected = lobExpected;
        replaceValueMap.put("#expected_lob#", lobExpected);
    }

    private void setSegmentExpected(String segmentExpected) {
        this.segmentExpected = segmentExpected;
        replaceValueMap.put("#expected_segment#", segmentExpected);
    }

    private void setBrand(String brand) {
        this.brand = brand;
        replaceValueMap.put("#brand#", brand);
    }

    private void setProduct(String product) {
        this.product = product;
        replaceValueMap.put("#product#", product);
    }


    private void setCrDrActual(String crDrActual) {
        this.crDrActual = crDrActual;
        replaceValueMap.put("#actual_cr_dr#", crDrActual);
    }

    private void setAmountActual(String amountActual) {
        this.amountActual = amountActual;
        replaceValueMap.put("#actual_amount#", amountActual);
    }

    private void setCodeCombinationIdActual(String codeCombinationIdActual) {
        this.codeCombinationIdActual = codeCombinationIdActual;
        replaceValueMap.put("#actual_code_combination_id#", codeCombinationIdActual);
    }


    private void setCrDrExpected(String crDrExpected) {
        this.crDrExpected = crDrExpected;
        replaceValueMap.put("#expected_cr_dr#", crDrExpected);
    }

    private void setAmountExpected(String amountExpected) {
        this.amountExpected = amountExpected;
        replaceValueMap.put("#expected_amount#", amountExpected);
    }

    private void setCodeCombinationIdExpected(String codeCombinationIdExpected) {
        this.codeCombinationIdExpected = codeCombinationIdExpected;
        replaceValueMap.put("#expected_code_combination_id#", codeCombinationIdExpected);
    }

    private void setTestResult(String testResult) {
        this.testResult = testResult;
        replaceValueMap.put("#test_result#", testResult);
    }

    private void setTestResultMsg(String testResultMsg) {
        this.testResultMsg = testResultMsg;
        replaceValueMap.put("#test_result_msg#", testResultMsg);
    }


    public void readReport()  {
        try {
            List<String> content = Files.readAllLines(Paths.get(REPORT_PATH));
            htmlReport = content.stream().collect(Collectors.joining(""));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    private void readTable() throws IOException {
        List<String> content = Files.readAllLines(Paths.get(TABLE_PATH));
        table = content.stream().collect(Collectors.joining(""));
    }

    private void writeTable() {
        String replaceValue = String.format("%s%s", table, "<br>::::End of Report::::");
        htmlReport = htmlReport.replace("::::End of Report::::", replaceValue);
    }

    private void pushReport() throws IOException {
        Files.write(Paths.get(REPORT_OUTPUT), htmlReport.getBytes());
    }

    private void replaceTableValues() {
        for (Map.Entry<String, String> map : replaceValueMap.entrySet())
            htmlReport = htmlReport.replace(map.getKey(), map.getValue());
    }


    public void publishReportFinal() throws IOException {
        replaceTableValues();
        htmlReport = htmlReport.replace("::::End of Report::::", xlaTable);
        htmlReport = String.format("%s%s",htmlReport,"<br>::::End of Report::::");

        DateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT_REPORT_NAME);
        Date date = new Date();
        String reportPath = "./GL-EVO-Billing.html";
        String reportPathDate = String.format("./GL-EVO-Billing_%s.html", dateFormat.format(date));
        Files.write(Paths.get(reportPath), htmlReport.getBytes());
        Files.write(Paths.get(reportPathDate), htmlReport.getBytes());

    }

    private void readXLATable() throws IOException {
        List<String> content = Files.readAllLines(Paths.get(XLA_TABLE_PATH));
        xlaTable = content.stream().collect(Collectors.joining(""));
    }


    public void setXLAtableValue(String transactionNumber ,String  eventID, String accountingClassCode , String baseAmount, String  message ) {
        String html = "<tr><td style=\"text-align: center;\">##S_No##</td><td style=\"text-align: center;\">##Transaction_Number##</td><td style=\"text-align: center;\">##Event_ID##</td><td style=\"text-align: center;\">##Accounting_Class_Code##</td><td style=\"text-align: center;\">##Base_Amount##</td><td style=\"text-align: center;\">##Message##</td></tr>\n<!--addNewRow-->";

        html = html.replace("##S_No##", String.valueOf(++sNo));
        html = html.replace("##Transaction_Number##", transactionNumber);
        html = html.replace("##Event_ID##", eventID);
        html = html.replace("##Accounting_Class_Code##", accountingClassCode);
        html = html.replace("##Base_Amount##", baseAmount);
        html = html.replace("##Message##", message);

        xlaTable = xlaTable.replace("<!--addNewRow-->", html);

    }


}

