package com.uk.dlgds.fusionvalidation.utils;

public class BillingConstants {

    public static final String EVO_SSPX_GL_BILLING_EXPECTED_FILE_PATH = "./src/com/uk/dlgds/fusionvalidation/expectedfiles/SSPX-GL-Billing-Expected.csv";
    public static final String EVO_SSPX_GL_BILLING_TEMP_FILE_PATH = "./src/com/uk/dlgds/fusionvalidation/expectedfiles/SSPX-GL-Billing-Temp.csv";
    public static final String EVO_SSPX_GL_BILLING_ACTUAL = "./src/com/uk/dlgds/fusionvalidation/expectedfiles/SSPX-GL-Billing-Actual.csv";
    public static final String EVO_SSPX_GL_BILLING_POSTING_RULE = "./src/com/uk/dlgds/fusionvalidation/resources/postingrules/SSPX-Billing.json";
    public static final String EVO_REPLACE_FILE = "REPLACE_FILE";
    public static final String EVO_REPLACE_FILE_LIST = "REPLACE_FILE_LIST";
    public static final String UTD = "UTD";
    public static final String DEBIT = "Debit";
    public static final String CREDIT = "Credit";
    public static final String DLG_COMPANY = "DLG_Company";
    public static final String DLG_INTERCO = "DLG_Interco";
    public static final String DLG_SPARE1 = "DLG_Spare1";
    public static final String DLG_SPARE2 = "DLG_Spare2";
    public static final String DLG_COST_CENTRE = "DLG_CostCentre";
    public static final String DLG_ACCOUNT = "DLG_Account";
    public static final String DLG_CHANNEL = "DLG_Channel";
    public static final String TRANSACTION_SUBTYPE = "Transaction_Subtype_Code";
    public static final String TRANSACTION_REASON = "Reason_Code";
    public static final String DLG_PRODUCT = "DLG_Product";
    public static final String DLG_BRAND = "DLG_Brand";
    public static final String DIRECT_LINE_4B = "DL4B";
    public static final String DLG_ORIGIN = "DLG_Origin";
    public static final String SSPX_GL_PREMIUM = "SSPXGLBilling";
    public static final int TRANSACTION_DATE_EXPECTED = 0;
    public static final int TRANSACTION_NUMBER_EXPECTED = 1;
    public static final int AHCS_EVENT_CODE_EXPECTED = 2;
    public static final int FSH_SOURCE_EXPECTED = 3;
    public static final int CREDIT_IND_EXPECTED = 9;
    public static final int EVENT_ID_EXPECTED = 11;
    public static final int APPLICATION_ID_EXPECTED = 13;
    public static final int BASE_AMOUNT_EXPECTED = 14;
    public static final int CURRENCY_CODE_EXPECTED = 15;
    public static final int ORIGINAL_AMOUNT_EXPECTED = 16;
    public static final int LINE_OF_BUSINESS_EXPECTED = 17;
    public static final int FSH_BRAND_EXPECTED = 18;
    public static final int FSH_CHANNEL_EXPECTED = 19;
    public static final int FSH_PRODUCT_EXPECTED = 20;
    public static final int PRODUCT_TYPE_EXPECTED = 21;
    public static final int EXCHANGE_RATE_EXPECTED = 22;
    public static final int EXCHANGE_RATE_TYPE_EXPECTED = 23;
    public static final int EXCHANGE_DATE_EXPECTED = 24;
    public static final int PRODUCT_KEY_EXPECTED = 25;
    public static final int DR_CR_EXPECTED = 26;
    public static final int CODE_COMBINATION_ID_EXPECTED = 27;
    public static final int SEGMENT1_EXPECTED = 28;
    public static final int SEGMENT2_EXPECTED = 29;
    public static final int SEGMENT3_EXPECTED = 30;
    public static final int SEGMENT4_EXPECTED = 31;
    public static final int SEGMENT5_EXPECTED = 32;
    public static final int SEGMENT6_EXPECTED = 33;
    public static final int SEGMENT7_EXPECTED = 34;
    public static final int SEGMENT8_EXPECTED = 35;
    public static final int SEGMENT9_EXPECTED = 36;
    public static final int SEGMENT10_EXPECTED = 37;
    public static final int APPLICATION_ID_ACTUAL = 0;
    public static final int CODE_COMBINATION_ID_ACTUAL = 1;
    public static final int ACCOUNTING_CLASS_CODE_ACTUAL = 2;
    public static final int ENTERED_DR_ACTUAL = 3;
    public static final int ENTERED_CR_ACTUAL = 4;
    public static final int LINE_OF_BUSINESS_ACTUAL = 8;
    public static final int TRANSACTION_NUMBER_ACTUAL = 9;
    public static final String DLG_MISC_DR = "DLG_MISC_DR";
    public static final String DLG_MISC_CR = "DLG_MISC_CR";
    public static final String CR = "CR";
    public static final String DR = "DR";

    public static final String  TRANSACTION_DATE_HEADER_STR = "TRANSACTION_DATE" ;
    public static final String  TRANSACTION_NUMBER_HEADER_STR = "TRANSACTION_NUMBER" ;
    public static final String  AHCS_EVENT_CODE_HEADER_STR = "AHCS_EVENT_CODE" ;
    public static final String  FSH_SOURCE_HEADER_STR = "FSH_SOURCE" ;
    public static final String  SOURCE_FILE_NAME_HEADER_STR = "SOURCE_FILE_NAME" ;
    public static final String  ACCOUNT_NUMBER_HEADER_STR = "ACCOUNT_NUMBER" ;
    public static final String  UNDERWRITER_HEADER_STR = "UNDERWRITER" ;
    public static final String  TRANSACTION_SUBTYPE_HEADER_STR = "TRANSACTION_SUBTYPE" ;
    public static final String   TRANSACTION_REASON_HEADER_STR = "TRANSACTION_REASON" ;
    public static final String  CREDIT_IND_HEADER_STR = "CREDIT_IND" ;
    public static final String  SUMMARY_FLAG_HEADER_STR = "SUMMARY_FLAG" ;
    public static final String  EVENT_ID_HEADER_STR = "EVENT_ID" ;
    public static final String  LINE_NUMBER_HEADER_STR = "LINE_NUMBER" ;
    public static final String  APPLICATION_ID_HEADER_STR = "APPLICATION_ID" ;
    public static final String  BASE_AMOUNT_HEADER_STR = "BASE_AMOUNT" ;
    public static final String  CURRENCY_CODE_HEADER_STR = "CURRENCY_CODE" ;
    public static final String  ORIGINAL_AMOUNT_HEADER_STR = "ORIGINAL_AMOUNT" ;
    public static final String  LINE_OF_BUSINESS_HEADER_STR = "LINE_OF_BUSINESS" ;
    public static final String  FSH_BRAND_HEADER_STR = "FSH_BRAND" ;
    public static final String  FSH_CHANNEL_HEADER_STR = "FSH_CHANNEL" ;
    public static final String  FSH_PRODUCT_HEADER_STR = "FSH_PRODUCT" ;
    public static final String  PRODUCT_TYPE_HEADER_STR = "PRODUCT_TYPE" ;
    public static final String  EXCHANGE_RATE_HEADER_STR = "EXCHANGE_RATE" ;
    public static final String  EXCHANGE_RATE_TYPE_HEADER_STR = "EXCHANGE_RATE_TYPE" ;
    public static final String  EXCHANGE_DATE_HEADER_STR = "EXCHANGE_DATE" ;
    public static final String  PRODUCT_KEY_HEADER_STR = "PRODUCT_KEY" ;
    public static final String  DR_CR_HEADER_STR = "DR/CR" ;
    public static final String  CODE_COMBINATION_ID_HEADER_STR = "CODE_COMBINATION_ID" ;
    public static final String  SEGMENT1_HEADER_STR = "SEGMNT1" ;
    public static final String  SEGMENT2_HEADER_STR = "SEGMENT2" ;
    public static final String  SEGMENT3_HEADER_STR = "SEGMENT3" ;
    public static final String  SEGMENT4_HEADER_STR = "SEGMENT4" ;
    public static final String  SEGMENT5_HEADER_STR = "SEGMENT5" ;
    public static final String  SEGMENT6_HEADER_STR = "SEGMENT6" ;
    public static final String  SEGMENT7_HEADER_STR = "SEGMENT7" ;
    public static final String  SEGMENT8_HEADER_STR = "SEGMENT8" ;
    public static final String  SEGMENT9_HEADER_STR = "SEGMENT9" ;
    public static final String  SEGMENT10_HEADER_STR = "SEGMENT10" ;


    private BillingConstants() {
        throw new IllegalStateException("Billing Constant Utility class");
    }


}

