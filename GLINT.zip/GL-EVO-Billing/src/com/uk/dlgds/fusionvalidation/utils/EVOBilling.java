package com.uk.dlgds.fusionvalidation.utils;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.io.IOUtils;
import org.json.JSONObject;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

public class EVOBilling {

    private JSONObject postingRules;
    private String segment1CR = "";
    private String segment2CR = "";
    private String segment3CR = "";
    private String segment4CR = "";
    private String segment5CR = "";
    private String segment6CR = "";
    private String segment7CR = "";
    private String segment8CR = "";
    private String segment9CR = "";
    private String segment10CR = "";
    private String segment1DR = "";
    private String segment2DR = "";
    private String segment3DR = "";
    private String segment4DR = "";
    private String segment5DR = "";
    private String segment6DR = "";
    private String segment7DR = "";
    private String segment8DR = "";
    private String segment9DR = "";
    private String segment10DR = "";

    private JSONObject readPostingRules() throws IOException {
        JSONObject postingRulesConfig = null;
        try (InputStream stream = Files.newInputStream(Paths.get(BillingConstants.EVO_SSPX_GL_BILLING_POSTING_RULE))) {
            assert stream != null;
            postingRulesConfig = new JSONObject(IOUtils.toString(stream, StandardCharsets.UTF_8));
        }
        return postingRulesConfig;
    }

    public void readEvoBillingValues() throws IOException {


        postingRules = readPostingRules();
        File sspxGLFile = new File(BillingConstants.EVO_SSPX_GL_BILLING_EXPECTED_FILE_PATH);


        try (
                Reader reader = Files.newBufferedReader(Paths.get(BillingConstants.EVO_SSPX_GL_BILLING_TEMP_FILE_PATH));
                CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT.withHeader().withIgnoreEmptyLines());
                FileWriter writer = new FileWriter(sspxGLFile);
                CSVPrinter csvPrinter = new CSVPrinter(writer, CSVFormat.DEFAULT
                        .withHeader(BillingConstants.TRANSACTION_DATE_HEADER_STR, BillingConstants.TRANSACTION_NUMBER_HEADER_STR, BillingConstants.AHCS_EVENT_CODE_HEADER_STR,
                                BillingConstants.FSH_SOURCE_HEADER_STR, BillingConstants.SOURCE_FILE_NAME_HEADER_STR, BillingConstants.ACCOUNT_NUMBER_HEADER_STR,
                                BillingConstants.UNDERWRITER_HEADER_STR, BillingConstants.TRANSACTION_SUBTYPE_HEADER_STR, BillingConstants.TRANSACTION_REASON_HEADER_STR,
                                BillingConstants.CREDIT_IND_HEADER_STR, BillingConstants.SUMMARY_FLAG_HEADER_STR, BillingConstants.EVENT_ID_HEADER_STR, BillingConstants.LINE_NUMBER_HEADER_STR,
                                BillingConstants.APPLICATION_ID_HEADER_STR, BillingConstants.BASE_AMOUNT_HEADER_STR, BillingConstants.CURRENCY_CODE_HEADER_STR, BillingConstants.ORIGINAL_AMOUNT_HEADER_STR,
                                BillingConstants.LINE_OF_BUSINESS_HEADER_STR, BillingConstants.FSH_BRAND_HEADER_STR, BillingConstants.FSH_CHANNEL_HEADER_STR, BillingConstants.FSH_PRODUCT_HEADER_STR,
                                BillingConstants.PRODUCT_TYPE_HEADER_STR, BillingConstants.EXCHANGE_RATE_HEADER_STR, BillingConstants.EXCHANGE_RATE_TYPE_HEADER_STR, BillingConstants.EXCHANGE_DATE_HEADER_STR,
                                BillingConstants.PRODUCT_KEY_HEADER_STR, BillingConstants.DR_CR_HEADER_STR, BillingConstants.CODE_COMBINATION_ID_HEADER_STR, BillingConstants.SEGMENT1_HEADER_STR,
                                BillingConstants.SEGMENT2_HEADER_STR, BillingConstants.SEGMENT3_HEADER_STR, BillingConstants.SEGMENT4_HEADER_STR, BillingConstants.SEGMENT5_HEADER_STR,
                                BillingConstants.SEGMENT6_HEADER_STR, BillingConstants.SEGMENT7_HEADER_STR, BillingConstants.SEGMENT8_HEADER_STR, BillingConstants.SEGMENT9_HEADER_STR, BillingConstants.SEGMENT10_HEADER_STR))


        ) {
            for (CSVRecord csvRecord : csvParser) {
                String query;

                getSegmentValues(csvRecord);

                query = segment1DR.trim() + "#" + segment2DR.trim() + "#" + segment3DR.trim() + "#" + segment4DR.trim() + "#" + segment5DR.trim() + "#" + segment6DR.trim() + "#" + segment7DR.trim() + "#" + segment8DR.trim() + "#" + segment9DR.trim() + "#" + segment10DR.trim();

                csvPrinter.printRecord(csvRecord.get(BillingConstants.TRANSACTION_DATE_HEADER_STR),
                        csvRecord.get(BillingConstants.TRANSACTION_NUMBER_HEADER_STR),
                        csvRecord.get(BillingConstants.AHCS_EVENT_CODE_HEADER_STR),
                        csvRecord.get(BillingConstants.FSH_SOURCE_HEADER_STR),
                        csvRecord.get(BillingConstants.SOURCE_FILE_NAME_HEADER_STR),
                        csvRecord.get(BillingConstants.ACCOUNT_NUMBER_HEADER_STR),
                        csvRecord.get(BillingConstants.UNDERWRITER_HEADER_STR),
                        csvRecord.get(BillingConstants.TRANSACTION_SUBTYPE_HEADER_STR),
                        csvRecord.get(BillingConstants.TRANSACTION_REASON_HEADER_STR),
                        csvRecord.get(BillingConstants.CREDIT_IND_HEADER_STR),
                        csvRecord.get(BillingConstants.SUMMARY_FLAG_HEADER_STR),
                        csvRecord.get(BillingConstants.EVENT_ID_HEADER_STR),
                        csvRecord.get(BillingConstants.LINE_NUMBER_HEADER_STR),
                        csvRecord.get(BillingConstants.APPLICATION_ID_HEADER_STR),
                        csvRecord.get(BillingConstants.BASE_AMOUNT_HEADER_STR),
                        csvRecord.get(BillingConstants.CURRENCY_CODE_HEADER_STR),
                        csvRecord.get(BillingConstants.ORIGINAL_AMOUNT_HEADER_STR),
                        csvRecord.get(BillingConstants.LINE_OF_BUSINESS_HEADER_STR),
                        csvRecord.get(BillingConstants.FSH_BRAND_HEADER_STR),
                        csvRecord.get(BillingConstants.FSH_CHANNEL_HEADER_STR),
                        csvRecord.get(BillingConstants.FSH_PRODUCT_HEADER_STR),
                        csvRecord.get(BillingConstants.PRODUCT_TYPE_HEADER_STR),
                        csvRecord.get(BillingConstants.EXCHANGE_RATE_HEADER_STR),
                        csvRecord.get(BillingConstants.EXCHANGE_RATE_TYPE_HEADER_STR),
                        csvRecord.get(BillingConstants.EXCHANGE_DATE_HEADER_STR),
                        csvRecord.get(BillingConstants.PRODUCT_KEY_HEADER_STR),
                        ApplicationConstants.DR, query.trim(), segment1DR.trim(), segment2DR.trim(), segment3DR.trim(), segment4DR.trim(), segment5DR.trim(), segment6DR.trim(), segment7DR.trim(), segment8DR.trim(), segment9DR.trim(), segment10DR.trim());


                query = segment1CR.trim() + "#" + segment2CR.trim() + "#" + segment3CR.trim() + "#" + segment4CR.trim() + "#" + segment5CR.trim() + "#" + segment6CR.trim() + "#" + segment7CR.trim() + "#" + segment8CR.trim() + "#" + segment9CR.trim() + "#" + segment10CR.trim();

                csvPrinter.printRecord(csvRecord.get(BillingConstants.TRANSACTION_DATE_HEADER_STR),
                        csvRecord.get(BillingConstants.TRANSACTION_NUMBER_HEADER_STR),
                        csvRecord.get(BillingConstants.AHCS_EVENT_CODE_HEADER_STR),
                        csvRecord.get(BillingConstants.FSH_SOURCE_HEADER_STR),
                        csvRecord.get(BillingConstants.SOURCE_FILE_NAME_HEADER_STR),
                        csvRecord.get(BillingConstants.ACCOUNT_NUMBER_HEADER_STR),
                        csvRecord.get(BillingConstants.UNDERWRITER_HEADER_STR),
                        csvRecord.get(BillingConstants.TRANSACTION_SUBTYPE_HEADER_STR),
                        csvRecord.get(BillingConstants.TRANSACTION_REASON_HEADER_STR),
                        csvRecord.get(BillingConstants.CREDIT_IND_HEADER_STR),
                        csvRecord.get(BillingConstants.SUMMARY_FLAG_HEADER_STR),
                        csvRecord.get(BillingConstants.EVENT_ID_HEADER_STR),
                        csvRecord.get(BillingConstants.LINE_NUMBER_HEADER_STR),
                        csvRecord.get(BillingConstants.APPLICATION_ID_HEADER_STR),
                        csvRecord.get(BillingConstants.BASE_AMOUNT_HEADER_STR),
                        csvRecord.get(BillingConstants.CURRENCY_CODE_HEADER_STR),
                        csvRecord.get(BillingConstants.ORIGINAL_AMOUNT_HEADER_STR),
                        csvRecord.get(BillingConstants.LINE_OF_BUSINESS_HEADER_STR),
                        csvRecord.get(BillingConstants.FSH_BRAND_HEADER_STR),
                        csvRecord.get(BillingConstants.FSH_CHANNEL_HEADER_STR),
                        csvRecord.get(BillingConstants.FSH_PRODUCT_HEADER_STR),
                        csvRecord.get(BillingConstants.PRODUCT_TYPE_HEADER_STR),
                        csvRecord.get(BillingConstants.EXCHANGE_RATE_HEADER_STR),
                        csvRecord.get(BillingConstants.EXCHANGE_RATE_TYPE_HEADER_STR),
                        csvRecord.get(BillingConstants.EXCHANGE_DATE_HEADER_STR),
                        csvRecord.get(BillingConstants.PRODUCT_KEY_HEADER_STR),
                        ApplicationConstants.CR, query, segment1CR.trim(), segment2CR.trim(), segment3CR.trim(), segment4CR.trim(), segment5CR.trim(), segment6CR.trim(), segment7CR.trim(), segment8CR.trim(), segment9CR.trim(), segment10CR.trim());

            }
        }
    }


    private void getSegmentValues(CSVRecord csvRecord) {

        String transactionSubtype = csvRecord.get("TRANSACTION_SUBTYPE");
        String transactionReason = csvRecord.get("TRANSACTION_REASON");


        segment1DR = postingRules.getJSONObject(BillingConstants.DEBIT).optString(BillingConstants.DLG_COMPANY, BillingConstants.UTD);
        segment2DR = postingRules.getJSONObject(BillingConstants.DEBIT).getJSONObject(BillingConstants.TRANSACTION_SUBTYPE)
                .getJSONObject(transactionSubtype).getJSONObject(BillingConstants.TRANSACTION_REASON)
                .getJSONObject(transactionReason).optString(BillingConstants.DLG_COST_CENTRE, BillingConstants.UTD);
        segment3DR = postingRules.getJSONObject(BillingConstants.DEBIT).getJSONObject(BillingConstants.TRANSACTION_SUBTYPE)
                .getJSONObject(transactionSubtype).getJSONObject(BillingConstants.TRANSACTION_REASON)
                .getJSONObject(transactionReason).optString(BillingConstants.DLG_ACCOUNT, BillingConstants.UTD);

        if (transactionSubtype.trim().toLowerCase().contains("account"))
            segment4DR = postingRules.getJSONObject(BillingConstants.DEBIT).getJSONObject(BillingConstants.TRANSACTION_SUBTYPE)
                    .getJSONObject(transactionSubtype).getJSONObject(BillingConstants.TRANSACTION_REASON)
                    .getJSONObject(transactionReason).getJSONObject(BillingConstants.DLG_PRODUCT)
                    .optString(csvRecord.get("LINE_OF_BUSINESS"), BillingConstants.UTD);
        else
            segment4DR = postingRules.getJSONObject(BillingConstants.DEBIT).getJSONObject(BillingConstants.TRANSACTION_SUBTYPE)
                    .getJSONObject(transactionSubtype).getJSONObject(BillingConstants.TRANSACTION_REASON)
                    .getJSONObject(transactionReason).optString(BillingConstants.DLG_PRODUCT, BillingConstants.UTD);

        if (transactionSubtype.trim().equalsIgnoreCase("DirectBillMoneyRcvdTxn") || transactionSubtype.trim().equalsIgnoreCase("Interest Charges"))
            segment5DR = postingRules.getJSONObject(BillingConstants.DEBIT).getJSONObject(BillingConstants.TRANSACTION_SUBTYPE)
                    .getJSONObject(transactionSubtype).getJSONObject(BillingConstants.TRANSACTION_REASON)
                    .getJSONObject(transactionReason).optString(BillingConstants.DLG_BRAND, BillingConstants.UTD);
        else
            segment5DR = postingRules.getJSONObject(BillingConstants.DEBIT).getJSONObject(BillingConstants.TRANSACTION_SUBTYPE)
                    .getJSONObject(transactionSubtype).getJSONObject(BillingConstants.TRANSACTION_REASON)
                    .getJSONObject(transactionReason).getJSONObject(BillingConstants.DLG_BRAND)
                    .optString(BillingConstants.DIRECT_LINE_4B, BillingConstants.UTD);

        if (transactionSubtype.trim().toLowerCase().contains("account"))
            segment6DR = postingRules.getJSONObject(BillingConstants.DEBIT).getJSONObject(BillingConstants.TRANSACTION_SUBTYPE)
                    .getJSONObject(transactionSubtype).getJSONObject(BillingConstants.TRANSACTION_REASON)
                    .getJSONObject(transactionReason).getJSONObject(BillingConstants.DLG_CHANNEL)
                    .optString(csvRecord.get("FSH_CHANNEL"), BillingConstants.UTD);
        else
            segment6DR = postingRules.getJSONObject(BillingConstants.DEBIT).getJSONObject(BillingConstants.TRANSACTION_SUBTYPE)
                    .getJSONObject(transactionSubtype).getJSONObject(BillingConstants.TRANSACTION_REASON)
                    .getJSONObject(transactionReason).optString(BillingConstants.DLG_CHANNEL, BillingConstants.UTD);


        segment7DR = postingRules.getJSONObject(BillingConstants.DEBIT).optString(BillingConstants.DLG_INTERCO, ApplicationConstants.UTD);

        if (transactionSubtype.trim().equalsIgnoreCase("DirectBillMoneyRcvdTxn") || transactionSubtype.trim().equalsIgnoreCase("Interest Charges"))
            segment8DR = postingRules.getJSONObject(BillingConstants.DEBIT).getJSONObject(BillingConstants.TRANSACTION_SUBTYPE)
                    .getJSONObject(transactionSubtype).getJSONObject(BillingConstants.TRANSACTION_REASON)
                    .getJSONObject(transactionReason).optString(BillingConstants.DLG_ORIGIN, ApplicationConstants.UTD);
        else
            segment8DR = postingRules.getJSONObject(BillingConstants.DEBIT).getJSONObject(BillingConstants.TRANSACTION_SUBTYPE)
                    .getJSONObject(transactionSubtype).getJSONObject(BillingConstants.TRANSACTION_REASON)
                    .getJSONObject(transactionReason).getJSONObject(BillingConstants.DLG_ORIGIN)
                    .optString(BillingConstants.SSPX_GL_PREMIUM, ApplicationConstants.UTD);
        segment9DR = postingRules.getJSONObject(BillingConstants.DEBIT).optString(BillingConstants.DLG_SPARE1, ApplicationConstants.UTD);
        segment10DR = postingRules.getJSONObject(BillingConstants.DEBIT).optString(BillingConstants.DLG_SPARE2, ApplicationConstants.UTD);


        segment1CR = postingRules.getJSONObject(BillingConstants.CREDIT).optString(BillingConstants.DLG_COMPANY, ApplicationConstants.UTD);
        segment2CR = postingRules.getJSONObject(BillingConstants.CREDIT).getJSONObject(BillingConstants.TRANSACTION_SUBTYPE)
                .getJSONObject(transactionSubtype).getJSONObject(BillingConstants.TRANSACTION_REASON)
                .getJSONObject(transactionReason).optString(BillingConstants.DLG_COST_CENTRE, BillingConstants.UTD);
        segment3CR = postingRules.getJSONObject(BillingConstants.CREDIT).getJSONObject(BillingConstants.TRANSACTION_SUBTYPE)
                .getJSONObject(transactionSubtype).getJSONObject(BillingConstants.TRANSACTION_REASON)
                .getJSONObject(transactionReason).optString(BillingConstants.DLG_ACCOUNT, BillingConstants.UTD);
        segment4CR = postingRules.getJSONObject(BillingConstants.CREDIT).optString(BillingConstants.DLG_PRODUCT, ApplicationConstants.UTD);

        segment6CR = postingRules.getJSONObject(BillingConstants.CREDIT).optString(BillingConstants.DLG_CHANNEL, BillingConstants.UTD);
        segment7CR = postingRules.getJSONObject(BillingConstants.CREDIT).optString(BillingConstants.DLG_INTERCO, ApplicationConstants.UTD);

        segment9CR = postingRules.getJSONObject(BillingConstants.CREDIT).optString(BillingConstants.DLG_SPARE1, ApplicationConstants.UTD);
        segment10CR = postingRules.getJSONObject(BillingConstants.CREDIT).optString(BillingConstants.DLG_SPARE2, ApplicationConstants.UTD);


        if (!transactionSubtype.trim().equalsIgnoreCase("DisbursementPaid")) {
            segment5CR = postingRules.getJSONObject(BillingConstants.CREDIT).getJSONObject(BillingConstants.TRANSACTION_SUBTYPE)
                    .getJSONObject(transactionSubtype).getJSONObject(BillingConstants.TRANSACTION_REASON)
                    .getJSONObject(transactionReason).getJSONObject(BillingConstants.DLG_BRAND)
                    .optString(BillingConstants.DIRECT_LINE_4B, BillingConstants.UTD);
            segment8CR = postingRules.getJSONObject(BillingConstants.CREDIT).getJSONObject(BillingConstants.TRANSACTION_SUBTYPE)
                    .getJSONObject(transactionSubtype).getJSONObject(BillingConstants.TRANSACTION_REASON)
                    .getJSONObject(transactionReason).getJSONObject(BillingConstants.DLG_ORIGIN)
                    .optString(BillingConstants.SSPX_GL_PREMIUM, ApplicationConstants.UTD);
        } else {
            segment5CR = postingRules.getJSONObject(BillingConstants.CREDIT).getJSONObject(BillingConstants.TRANSACTION_SUBTYPE)
                    .getJSONObject(transactionSubtype).getJSONObject(BillingConstants.TRANSACTION_REASON)
                    .getJSONObject(transactionReason).optString(BillingConstants.DLG_BRAND, BillingConstants.UTD);

            segment8CR = postingRules.getJSONObject(BillingConstants.CREDIT).getJSONObject(BillingConstants.TRANSACTION_SUBTYPE)
                    .getJSONObject(transactionSubtype).getJSONObject(BillingConstants.TRANSACTION_REASON)
                    .getJSONObject(transactionReason).optString(BillingConstants.DLG_ORIGIN, ApplicationConstants.UTD);
        }


    }


}
