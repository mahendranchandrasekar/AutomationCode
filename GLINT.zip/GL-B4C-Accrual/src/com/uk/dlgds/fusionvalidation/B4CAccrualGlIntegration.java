package com.uk.dlgds.fusionvalidation;

import com.uk.dlgds.fusionvalidation.resources.datasource.DbConnect;
import com.uk.dlgds.fusionvalidation.service.ApplicationDetails;
import com.uk.dlgds.fusionvalidation.service.CodeCombination;
import com.uk.dlgds.fusionvalidation.service.EndpointValidation;
import com.uk.dlgds.fusionvalidation.service.GLValidationBilling;
import com.uk.dlgds.fusionvalidation.utils.ApplicationConstants;
import com.uk.dlgds.fusionvalidation.utils.BillingConstants;
import com.uk.dlgds.fusionvalidation.utils.B4CAccrual;
import com.uk.dlgds.fusionvalidation.utils.TestReport;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class B4CAccrualGlIntegration {


    private final ApplicationDetails applicationDetails = new ApplicationDetails();
    private final EndpointValidation endpointValidation = new EndpointValidation();

    private GLValidationBilling glLValidation = new GLValidationBilling();
    private B4CAccrual b4CAccrual = new B4CAccrual();
    private CodeCombination codeCombination = new CodeCombination();
    private TestReport testReport = new TestReport();

    private String expectedQuery;
    private String actualQuery;
    private String fshDbValidation;
    private String fileExpected;
    private String fileActual;
    private String expectedQueryFlag;
    private String dbServer;
    private String dbUserName;
    private String dbPassword;
    private DbConnect dbConnect = new DbConnect();
    private String jdbcFshFileProcessedQuery;
    private String jdbcFshFileNotProcessedQuery;


    @Test
    public void b4cAcrual() throws  IOException, ParserConfigurationException, SAXException, TransformerException, SQLException {
        String fileListExpected;
        String fileListActual;
        String fileNotProcessed;
        String uniqueFSHFiles;


        readValuesFromProperties();

        Boolean dbValidation = Boolean.parseBoolean(fshDbValidation.trim().toUpperCase());


        if (Boolean.TRUE.equals(dbValidation)) {

            List<String> jdbcFshFileNotProcessedList;
            dbConnect.getDbValues(dbServer, dbUserName, dbPassword, jdbcFshFileProcessedQuery);
            List<String> jdbcFshFileProcessedList = dbConnect.getFileNames();
            uniqueFSHFiles = String.join("','", jdbcFshFileProcessedList);
            fileListExpected = uniqueFSHFiles;
            fileListActual = jdbcFshFileProcessedList.stream()
                    .map(o -> o.trim().substring(0, 30))
                    .collect(Collectors.joining("','"));
            if ( uniqueFSHFiles.trim().isEmpty() )
                uniqueFSHFiles="< ---NO--DATA--- >";

            dbConnect.getDbValues(dbServer, dbUserName, dbPassword, jdbcFshFileNotProcessedQuery);
            jdbcFshFileNotProcessedList = dbConnect.getFileNames();

            if(!(jdbcFshFileNotProcessedList.isEmpty())){
                fileNotProcessed = String.join("','", jdbcFshFileNotProcessedList);
            }else
                fileNotProcessed = "< ---NO--DATA--- >";


            expectedQuery = expectedQuery.replace(ApplicationConstants.REPLACE_FILE_LIST, fileListExpected);
            actualQuery = actualQuery.replace(ApplicationConstants.REPLACE_FILE_LIST, fileListActual);

        } else {
            uniqueFSHFiles = "< ---NO--DB--CHECK--- >";
            fileNotProcessed = "< ---NO--DB--CHECK--- >";

            if (fileExpected.contains(",")) {
                fileActual = Arrays.stream(fileExpected.split(","))
                        .map(o -> o.trim().substring(0, 30))
                        .collect(Collectors.joining("','"));
                fileExpected = fileExpected.replace(",", "','");
            }

            expectedQuery = expectedQueryFlag.replace(ApplicationConstants.REPLACE_FILE_LIST, fileExpected);
            actualQuery = actualQuery.replace(ApplicationConstants.REPLACE_FILE_LIST, fileActual);
        }


        endpointValidation.triggerEndPoint(expectedQuery, new File(BillingConstants.B4C_ACCRUAL_TEMP_FILE_PATH));
        b4CAccrual.readB4CAccrualValues();

        List<ArrayList<String>> arrayList = endpointValidation.triggerActualEndPoint(actualQuery);
        writeActualFile(arrayList);
        codeCombination.getVaAlues();
        testReport.setFilesNotProcessed(fileNotProcessed.replace("','", ", "));
        testReport.setFilesProcessed(uniqueFSHFiles.replace("','", ", "));
        glLValidation.validateB4CAccrual(testReport);
        testReport.publishReportFinal();

    }


    private void readValuesFromProperties() throws IOException {
        String fileFlag;
        String actualQueryFlag;
        String jdbcFshQueryDate;
        String jdbcFshQueryFile;
        String jdbcFileNotProcessQueryDate;
        String jdbcFileNotProcessQueryFile;

        expectedQueryFlag = applicationDetails.readProperties("com.uk.dlgds.b4cAccrual.File.billing.expectedQuery");
        actualQueryFlag = applicationDetails.readProperties("com.uk.dlgds.b4c.Accrual.File.billing.actualQuery");
        expectedQuery = applicationDetails.readProperties("com.uk.dlgds.b4c.Accrual.billing.expectedQuery");


        actualQuery = applicationDetails.readProperties("com.uk.dlgds.b4c.Accrual.billing.ActualQuery");


        fshDbValidation = applicationDetails.readProperties("com.uk.dlgds.fshValidation");
        fileFlag = applicationDetails.readProperties("com.uk.dlgds.ap.select.runQueryBy");

        fileExpected = applicationDetails.readProperties("com.uk.dlgds.b4c.Accrual.billing.FileName");
        fileActual = fileExpected.trim().substring(0, 30);


        jdbcFshQueryDate = applicationDetails.readProperties("b4c.Accrual.FSHJDBCQuery.date").trim();
        jdbcFshQueryFile = applicationDetails.readProperties("b4c.Accrual.FSHJDBCQuery.file").trim();
        jdbcFileNotProcessQueryDate = applicationDetails.readProperties("b4c.Accrual.FSHFileNotProcessQuery.date").trim();
        jdbcFileNotProcessQueryFile = applicationDetails.readProperties("b4c.Accrual.FSHFileNotProcessQuery.file").trim();


        if (fileExpected.contains(",")) {
            jdbcFshQueryFile = jdbcFshQueryFile.replace(ApplicationConstants.REPLACE_FILE, (fileExpected.replace(",", "','")));
            jdbcFileNotProcessQueryFile = jdbcFileNotProcessQueryFile.replace(ApplicationConstants.REPLACE_FILE, (fileExpected.replace(",", "','")));
        } else {
            jdbcFshQueryFile = jdbcFshQueryFile.replace(ApplicationConstants.REPLACE_FILE, fileExpected);
            jdbcFileNotProcessQueryFile = jdbcFileNotProcessQueryFile.replace(ApplicationConstants.REPLACE_FILE, fileExpected);
        }

        String env = applicationDetails.readProperties("com.uk.dlgds.db.evn").trim();

        dbServer = applicationDetails.readProperties(String.format("com.uk.dlgds.%s.dbServer", env)).trim();
        dbUserName = applicationDetails.readProperties(String.format("com.uk.dlgds.%s.dbUserName", env)).trim();
        dbPassword = applicationDetails.readProperties(String.format("com.uk.dlgds.%s.dbPassword", env)).trim();

        if (fileFlag.equalsIgnoreCase(ApplicationConstants.RUN_QUERY_BY)) {
            jdbcFshFileProcessedQuery = jdbcFshQueryFile;
            jdbcFshFileNotProcessedQuery = jdbcFileNotProcessQueryFile;
            expectedQuery = expectedQueryFlag;
            actualQuery = actualQueryFlag;
        } else {
            jdbcFshFileProcessedQuery = jdbcFshQueryDate;
            jdbcFshFileNotProcessedQuery = jdbcFileNotProcessQueryDate;
        }
    }

    private void writeActualFile(List<ArrayList<String>> arrayList)
            throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(BillingConstants.B4C_ACCRUAL_ACTUAL))) {
            writer.write(ApplicationConstants.ACTUAL_HEADER);
            for (ArrayList<String> value : arrayList)
                writer.write(value.toString().replace("[", "").replace("]", "") + "\n");
        }
    }
}