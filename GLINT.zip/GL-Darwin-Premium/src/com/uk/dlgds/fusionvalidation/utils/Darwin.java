package com.uk.dlgds.fusionvalidation.utils;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.io.IOUtils;
import org.json.JSONObject;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.List;

public class Darwin {

    private JSONObject postingRules;
    private String segment1CR = "";
    private String segment2CR = "";
    private String segment3CR = "";
    private String segment4CR = "";
    private String segment5CR = "";
    private String segment6CR = "";
    private String segment7CR = "";
    private String segment8CR = "";
    private String segment9CR = "";
    private String segment10CR = "";
    private String segment1DR = "";
    private String segment2DR = "";
    private String segment3DR = "";
    private String segment4DR = "";
    private String segment5DR = "";
    private String segment6DR = "";
    private String segment7DR = "";
    private String segment8DR = "";
    private String segment9DR = "";
    private String segment10DR = "";

    private JSONObject readPostingRules() throws IOException {
        JSONObject postingRulesConfig = null;
        try (InputStream stream = Files.newInputStream(Paths.get(BillingConstants.DARWIN_POSTING_RULE))) {
            assert stream != null;
            postingRulesConfig = new JSONObject(IOUtils.toString(stream, StandardCharsets.UTF_8));
        }
        return postingRulesConfig;
    }

    public void readDarwin() throws IOException {


        postingRules = readPostingRules();
        File sspxGLFile = new File(BillingConstants.DARWIN_EXPECTED_FILE_PATH);


        try (
                Reader reader = Files.newBufferedReader(Paths.get(BillingConstants.DARWIN_TEMP_FILE_PATH));
                CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT.withHeader().withIgnoreEmptyLines());
                FileWriter writer = new FileWriter(sspxGLFile);
                CSVPrinter csvPrinter = new CSVPrinter(writer, CSVFormat.DEFAULT
                        .withHeader(BillingConstants.TRANSACTION_DATE_HEADER_STR, BillingConstants.TRANSACTION_NUMBER_HEADER_STR, BillingConstants.AHCS_EVENT_CODE_HEADER_STR,
                                BillingConstants.FSH_SOURCE_HEADER_STR, BillingConstants.SOURCE_FILE_NAME_HEADER_STR, BillingConstants.CREDIT_IND_NUMBER_HEADER_STR,
                                BillingConstants.UNDERWRITER_HEADER_STR, BillingConstants.SUMMARY_FLAG_HEADER_STR, BillingConstants.EVENT_ID_HEADER_STR, BillingConstants.LINE_NUMBER_HEADER_STR,
                                BillingConstants.APPLICATION_ID_HEADER_STR, BillingConstants.BASE_AMOUNT_HEADER_STR, BillingConstants.CURRENCY_CODE_HEADER_STR, BillingConstants.ORIGINAL_AMOUNT_HEADER_STR,
                                BillingConstants.LINE_OF_BUSINESS_HEADER_STR, BillingConstants.FSH_BRAND_HEADER_STR, BillingConstants.FSH_CHANNEL_HEADER_STR, BillingConstants.FSH_PRODUCT_HEADER_STR,
                                BillingConstants.PRODUCT_TYPE_HEADER_STR, BillingConstants.EXCHANGE_RATE_HEADER_STR, BillingConstants.EXCHANGE_RATE_TYPE_HEADER_STR, BillingConstants.EXCHANGE_DATE_HEADER_STR,
                                BillingConstants.PRODUCT_KEY_HEADER_STR, BillingConstants.DR_CR_HEADER_STR, BillingConstants.CODE_COMBINATION_ID_HEADER_STR, BillingConstants.SEGMENT1_HEADER_STR,
                                BillingConstants.SEGMENT2_HEADER_STR, BillingConstants.SEGMENT3_HEADER_STR, BillingConstants.SEGMENT4_HEADER_STR, BillingConstants.SEGMENT5_HEADER_STR,
                                BillingConstants.SEGMENT6_HEADER_STR, BillingConstants.SEGMENT7_HEADER_STR, BillingConstants.SEGMENT8_HEADER_STR, BillingConstants.SEGMENT9_HEADER_STR, BillingConstants.SEGMENT10_HEADER_STR))


        ) {
            for (CSVRecord csvRecord : csvParser) {
                String query;

                getSegmentValues(csvRecord);

                //query = "select code_combination_id from gl_code_combinations where segment1 ='" + segment1DR + "' and segment2 ='" + segment2DR + "' and segment3 ='" + segment3DR + "' and segment4 ='" + segment4DR + "'and segment5 ='" + segment5DR + "'and segment6 ='" + segment6DR + "'and segment7 ='" + segment7DR + "'and segment8 ='" + segment8DR + "'and segment9 ='" + segment9DR + "'and segment10 ='" + segment10DR + "'";
                query = segment1DR.trim() + "#" + segment2DR.trim() + "#" + segment3DR.trim() + "#" + segment4DR.trim() + "#" + segment5DR.trim() + "#" + segment6DR.trim() + "#" + segment7DR.trim() + "#" + segment8DR.trim() + "#" + segment9DR.trim() + "#" + segment10DR.trim();

                csvPrinter.printRecord(csvRecord.get(BillingConstants.TRANSACTION_DATE_HEADER_STR),
                        csvRecord.get(BillingConstants.TRANSACTION_NUMBER_HEADER_STR),
                        csvRecord.get(BillingConstants.AHCS_EVENT_CODE_HEADER_STR),
                        csvRecord.get(BillingConstants.FSH_SOURCE_HEADER_STR),
                        csvRecord.get(BillingConstants.SOURCE_FILE_NAME_HEADER_STR),
                        csvRecord.get(BillingConstants.CREDIT_IND_NUMBER_HEADER_STR),
                        csvRecord.get(BillingConstants.UNDERWRITER_HEADER_STR),
                        csvRecord.get(BillingConstants.SUMMARY_FLAG_HEADER_STR),
                        csvRecord.get(BillingConstants.EVENT_ID_HEADER_STR),
                        csvRecord.get(BillingConstants.LINE_NUMBER_HEADER_STR),
                        csvRecord.get(BillingConstants.APPLICATION_ID_HEADER_STR),
                        csvRecord.get(BillingConstants.BASE_AMOUNT_HEADER_STR),
                        csvRecord.get(BillingConstants.CURRENCY_CODE_HEADER_STR),
                        csvRecord.get(BillingConstants.ORIGINAL_AMOUNT_HEADER_STR),
                        csvRecord.get(BillingConstants.LINE_OF_BUSINESS_HEADER_STR),
                        csvRecord.get(BillingConstants.FSH_BRAND_HEADER_STR),
                        csvRecord.get(BillingConstants.FSH_CHANNEL_HEADER_STR),
                        csvRecord.get(BillingConstants.FSH_PRODUCT_HEADER_STR),
                        csvRecord.get(BillingConstants.PRODUCT_TYPE_HEADER_STR),
                        csvRecord.get(BillingConstants.EXCHANGE_RATE_HEADER_STR),
                        csvRecord.get(BillingConstants.EXCHANGE_RATE_TYPE_HEADER_STR),
                        csvRecord.get(BillingConstants.EXCHANGE_DATE_HEADER_STR),
                        csvRecord.get(BillingConstants.PRODUCT_KEY_HEADER_STR),
                        ApplicationConstants.DR, query.trim(), segment1DR.trim(), segment2DR.trim(), segment3DR.trim(), segment4DR.trim(), segment5DR.trim(), segment6DR.trim(), segment7DR.trim(), segment8DR.trim(), segment9DR.trim(), segment10DR.trim());


                //query = "select code_combination_id from gl_code_combinations where segment1 ='" + segment1CR + "' and segment2 ='" + segment2CR + "' and segment3 ='" + segment3CR + "' and segment4 ='" + segment4CR + "'and segment5 ='" + segment5CR + "'and segment6 ='" + segment6CR + "'and segment7 ='" + segment7CR + "'and segment8 ='" + segment8CR + "'and segment9 ='" + segment9CR + "'and segment10 ='" + segment10CR + "'";
                query = segment1CR.trim() + "#" + segment2CR.trim() + "#" + segment3CR.trim() + "#" + segment4CR.trim() + "#" + segment5CR.trim() + "#" + segment6CR.trim() + "#" + segment7CR.trim() + "#" + segment8CR.trim() + "#" + segment9CR.trim() + "#" + segment10CR.trim();

                csvPrinter.printRecord(csvRecord.get(BillingConstants.TRANSACTION_DATE_HEADER_STR),
                        csvRecord.get(BillingConstants.TRANSACTION_NUMBER_HEADER_STR),
                        csvRecord.get(BillingConstants.AHCS_EVENT_CODE_HEADER_STR),
                        csvRecord.get(BillingConstants.FSH_SOURCE_HEADER_STR),
                        csvRecord.get(BillingConstants.SOURCE_FILE_NAME_HEADER_STR),
                        csvRecord.get(BillingConstants.CREDIT_IND_NUMBER_HEADER_STR),
                        csvRecord.get(BillingConstants.UNDERWRITER_HEADER_STR),
                        csvRecord.get(BillingConstants.SUMMARY_FLAG_HEADER_STR),
                        csvRecord.get(BillingConstants.EVENT_ID_HEADER_STR),
                        csvRecord.get(BillingConstants.LINE_NUMBER_HEADER_STR),
                        csvRecord.get(BillingConstants.APPLICATION_ID_HEADER_STR),
                        csvRecord.get(BillingConstants.BASE_AMOUNT_HEADER_STR),
                        csvRecord.get(BillingConstants.CURRENCY_CODE_HEADER_STR),
                        csvRecord.get(BillingConstants.ORIGINAL_AMOUNT_HEADER_STR),
                        csvRecord.get(BillingConstants.LINE_OF_BUSINESS_HEADER_STR),
                        csvRecord.get(BillingConstants.FSH_BRAND_HEADER_STR),
                        csvRecord.get(BillingConstants.FSH_CHANNEL_HEADER_STR),
                        csvRecord.get(BillingConstants.FSH_PRODUCT_HEADER_STR),
                        csvRecord.get(BillingConstants.PRODUCT_TYPE_HEADER_STR),
                        csvRecord.get(BillingConstants.EXCHANGE_RATE_HEADER_STR),
                        csvRecord.get(BillingConstants.EXCHANGE_RATE_TYPE_HEADER_STR),
                        csvRecord.get(BillingConstants.EXCHANGE_DATE_HEADER_STR),
                        csvRecord.get(BillingConstants.PRODUCT_KEY_HEADER_STR),
                        ApplicationConstants.CR, query, segment1CR.trim(), segment2CR.trim(), segment3CR.trim(), segment4CR.trim(), segment5CR.trim(), segment6CR.trim(), segment7CR.trim(), segment8CR.trim(), segment9CR.trim(), segment10CR.trim());

            }
        }
    }


    private void getSegmentValues(CSVRecord csvRecord) {
        Object[] productNameJSON = postingRules.getJSONObject(ApplicationConstants.CREDIT)
                .getJSONObject(ApplicationConstants.DLG_PRODUCT)
                .keySet().toArray();

        List<String> productName = new LinkedList<>();


        for (Object obj : productNameJSON)
            productName.add(obj.toString());

        segment1DR = postingRules.getJSONObject(BillingConstants.DEBIT).optString(BillingConstants.DLG_COMPANY, BillingConstants.UTD);
        segment2DR = postingRules.getJSONObject(BillingConstants.DEBIT).getJSONObject(BillingConstants.DLG_COST_CENTRE).optString(csvRecord.get(BillingConstants.FSH_PRODUCT), BillingConstants.UTD);
        segment3DR = postingRules.getJSONObject(BillingConstants.DEBIT).getJSONObject(BillingConstants.DLG_ACCOUNT).optString(csvRecord.get(BillingConstants.FSH_PRODUCT), BillingConstants.UTD);
        segment4DR = postingRules.getJSONObject(BillingConstants.DEBIT).getJSONObject(BillingConstants.DLG_PRODUCT).optString(csvRecord.get(BillingConstants.LINE_OF_BUSINESS), BillingConstants.UTD);

        if (csvRecord.get(BillingConstants.FSH_PRODUCT).equalsIgnoreCase("BWO")) {
            segment5DR = postingRules.getJSONObject(BillingConstants.DEBIT).getJSONObject(BillingConstants.DLG_BRAND).optString(csvRecord.get(BillingConstants.PRODUCT_TYPE), BillingConstants.UTD);
        } else {
            segment5DR = postingRules.getJSONObject(BillingConstants.DEBIT).getJSONObject(BillingConstants.DLG_BRAND).optString("Default", BillingConstants.UTD);
        }

        if (csvRecord.get(BillingConstants.FSH_PRODUCT).equalsIgnoreCase("BWO")) {
            segment6DR = postingRules.getJSONObject(BillingConstants.DEBIT).getJSONObject(BillingConstants.DLG_CHANNEL).optString(csvRecord.get(BillingConstants.FSH_CHANNEL), BillingConstants.UTD);
        } else {
            segment6DR = postingRules.getJSONObject(BillingConstants.DEBIT).getJSONObject(BillingConstants.DLG_CHANNEL).optString(csvRecord.get(BillingConstants.FSH_PRODUCT), BillingConstants.UTD);
        }
        segment7DR = postingRules.getJSONObject(BillingConstants.DEBIT).optString(BillingConstants.DLG_INTERCO, BillingConstants.UTD);
        segment8DR = postingRules.getJSONObject(BillingConstants.DEBIT).getJSONObject(BillingConstants.DLG_ORIGIN).optString(csvRecord.get(BillingConstants.FSH_SOURCE), BillingConstants.UTD);
        segment9DR = postingRules.getJSONObject(BillingConstants.DEBIT).optString(BillingConstants.DLG_SPARE1, BillingConstants.UTD);
        segment10DR = postingRules.getJSONObject(BillingConstants.DEBIT).optString(BillingConstants.DLG_SPARE2, BillingConstants.UTD);


        segment1CR = postingRules.getJSONObject(BillingConstants.CREDIT).optString(BillingConstants.DLG_COMPANY,BillingConstants.UTD);
        segment2CR = postingRules.getJSONObject(BillingConstants.CREDIT).getJSONObject(BillingConstants.DLG_COST_CENTRE).optString(csvRecord.get(BillingConstants.FSH_PRODUCT),BillingConstants.UTD);
        segment3CR = postingRules.getJSONObject(BillingConstants.CREDIT).getJSONObject(BillingConstants.DLG_ACCOUNT).optString(csvRecord.get(BillingConstants.FSH_PRODUCT),BillingConstants.UTD);
        segment4CR = postingRules.getJSONObject(BillingConstants.CREDIT).getJSONObject(BillingConstants.DLG_PRODUCT).optString(csvRecord.get(BillingConstants.FSH_PRODUCT), BillingConstants.UTD);

        if(csvRecord.get(BillingConstants.FSH_PRODUCT).equalsIgnoreCase("BWO")){
            segment5CR = postingRules.getJSONObject(BillingConstants.CREDIT).getJSONObject(BillingConstants.DLG_BRAND).optString("Default",BillingConstants.UTD);
        }else{
            segment5CR = postingRules.getJSONObject(BillingConstants.CREDIT).getJSONObject(BillingConstants.DLG_BRAND).optString(csvRecord.get(BillingConstants.PRODUCT_TYPE),BillingConstants.UTD);
        }

        if(csvRecord.get(BillingConstants.FSH_PRODUCT).equalsIgnoreCase("BWO")){
            segment6CR = postingRules.getJSONObject(BillingConstants.CREDIT).getJSONObject(BillingConstants.DLG_CHANNEL).optString("Default",BillingConstants.UTD);
        }else{
            segment6CR = postingRules.getJSONObject(BillingConstants.CREDIT).getJSONObject(BillingConstants.DLG_CHANNEL).optString(csvRecord.get(BillingConstants.FSH_CHANNEL),BillingConstants.UTD);
        }

        segment7CR = postingRules.getJSONObject(BillingConstants.CREDIT).optString(BillingConstants.DLG_INTERCO,BillingConstants.UTD);
        segment8CR = postingRules.getJSONObject(BillingConstants.CREDIT).getJSONObject(BillingConstants.DLG_ORIGIN).optString(csvRecord.get(BillingConstants.FSH_SOURCE),BillingConstants.UTD);
        segment9CR = postingRules.getJSONObject(BillingConstants.CREDIT).optString(BillingConstants.DLG_SPARE1,BillingConstants.UTD);
        segment10CR= postingRules.getJSONObject(BillingConstants.CREDIT).optString(BillingConstants.DLG_SPARE2,BillingConstants.UTD);


    }


}
