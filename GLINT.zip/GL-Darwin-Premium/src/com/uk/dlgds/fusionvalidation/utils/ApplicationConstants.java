package com.uk.dlgds.fusionvalidation.utils;

public class ApplicationConstants {

    public static final String EVO_SSPX_GL_EXPECTED_FILE_PATH = "./src/com/uk/dlgds/fusionvalidation/expectedfiles/SSPX-GL-Premium-ExpectedCsvRecord.csv";
    public static final String EVO_SSPX_GL_TEMP_FILE_PATH = "./src/com/uk/dlgds/fusionvalidation/expectedfiles/SSPX-GL-Premium.csv";
    public static final String EVO_SSPX_GL_ACTUAL = "./src/com/uk/dlgds/fusionvalidation/expectedfiles/SSPX-GL-Premium-Actual.csv";
    public static final String POSTING_RULES_JSON_PATH = "./src/com/uk/dlgds/fusionvalidation/resources/postingrules/SSPX-Premium-Updated.json";
    public static final String REPLACE_FILE = "REPLACE_FILE";
    public static final String REPLACE_FILE_LIST = "REPLACE_FILE_LIST";
    public static final String DAYS = "##DAYS##";
    public static final String EVO_SSPX_GL_BILLING_EXPECTED_FILE_PATH = "./src/com/uk/dlgds/fusionvalidation/expectedfiles/SSPX-GL-Billing-ExpectedCsvRecord.csv";
    public static final String EVO_SSPX_GL_BILLING_TEMP_FILE_PATH = "./src/com/uk/dlgds/fusionvalidation/expectedfiles/SSPX-GL-Billing.csv";
    public static final String EVO_SSPX_GL_BILLING_ACTUAL = "./src/com/uk/dlgds/fusionvalidation/expectedfiles/Darwin-Actual.csv";
    public static final String JOURNAL_QUERIES_FILE_PATH = "com/uk/dlgds/fusionvalidation/resources/queries/Journal-Queries.json";
    public static final String RUN_QUERY_BY = "file";
    public static final String CR = "CR";
    public static final String DR = "DR";
    public static final String UTD = "UTD";
    public static final String DEBIT = "Debit";
    public static final String CREDIT = "Credit";
    public static final String DLG_COMPANY = "DLG_Company";
    public static final String DLG_INTERCO = "DLG_Interco";
    public static final String DLG_SPARE1 = "DLG_Spare1";
    public static final String DLG_SPARE2 = "DLG_Spare2";
    public static final String DLG_COST_CENTRE = "DLG_CostCentre";
    public static final String DLG_ACCOUNT = "DLG_Account";
    public static final String DLG_CHANNEL = "DLG_Channel";
    public static final String DLG_ORIGIN = "DLG_Origin";
    public static final String SSPX_GL_PREMIUM = "SSPXGLPremium";
    public static final String DLG_PRODUCT = "DLG_Product";
    public static final String COMMERCIAL_VAN = "Commercial Van";
    public static final String LANDLORD = "Landlord";
    public static final String SME = "SME";
    public static final String DLG_BRAND = "DLG_Brand";
    public static final String DIRECT_LINE_4B = "DL4B";
    public static final String PRODUCT_TYPE = "Product_Type";
    public static final int APPLICATION_ID_EXPECTED = 16;
    public static final int LINE_OF_BUSINESS_EXPECTED = 20;
    public static final int FSH_BRAND_EXPECTED = 21;
    public static final int FSH_CHANNEL_EXPECTED = 22;
    public static final int FSH_PRODUCT_EXPECTED = 23;
    public static final int PRODUCT_TYPE_EXPECTED = 24;
    public static final int DR_CR_EXPECTED = 31;
    public static final int CODE_COMBINATION_ID_EXPECTED = 32;
    public static final int BASE_AMOUNT_EXPECTED = 17;
    public static final int PRODUCT_KEY_EXPECTED = 28;
    public static final int SOURCE_FILE_NAME_EXPECTED = 4;
    public static final int TRANSACTION_NUMBER_EXPECTED = 1;
    public static final int TRANSACTION_DATE_EXPECTED = 0;
    public static final int EVENT_ID_EXPECTED = 14;
    public static final int CURRENCY_CODE_EXPECTED = 18;
    public static final int AHCS_EVENT_CODE_EXPECTED = 2;
    public static final int SEGMENT1_EXPECTED = 33;
    public static final int SEGMENT2_EXPECTED = 34;
    public static final int SEGMENT3_EXPECTED = 35;
    public static final int SEGMENT4_EXPECTED = 36;
    public static final int SEGMENT5_EXPECTED = 37;
    public static final int SEGMENT6_EXPECTED = 38;
    public static final int SEGMENT7_EXPECTED = 39;
    public static final int SEGMENT8_EXPECTED = 40;
    public static final int SEGMENT9_EXPECTED = 41;
    public static final int SEGMENT10_EXPECTED = 42;
    public static final String ACTUAL_HEADER = "﻿APPLICATION_ID,CODE_COMBINATION_ID,ACCOUNTING_CLASS_CODE,ENTERED_DR,ENTERED_CR,CURRENCY_CODE,SR32,SR33,LINE_OF_BUSINESS,TRANSACTION_NUMBER\n";
    public static final int APPLICATION_ID_ACTUAL = 0;
    public static final int CODE_COMBINATION_ID_ACTUAL = 1;
    public static final int ACCOUNTING_CLASS_CODE_ACTUAL = 2;
    public static final int LINE_OF_BUSINESS_ACTUAL = 9;
    public static final int FSH_PRODUCT_ACTUAL = 10;
    public static final int PRODUCT_TYPE_ACTUAL = 11;
    public static final int PRODUCT_KEY_ACTUAL = 12;
    public static final int FSH_CHANNEL_ACTUAL = 13;
    public static final int FSH_BRAND_ACTUAL = 14;
    public static final int ENTERED_DR_ACTUAL = 3;
    public static final int ENTERED_CR_ACTUAL = 4;
    public static final String DLG_MISC_DR = "DLG_MISC_DR";
    public static final String DLG_MISC_CR = "DLG_MISC_CR";
    private ApplicationConstants() {
        throw new IllegalStateException("Application Constant Utility class");
    }


}

