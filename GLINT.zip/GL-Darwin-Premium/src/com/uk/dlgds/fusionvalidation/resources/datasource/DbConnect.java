package com.uk.dlgds.fusionvalidation.resources.datasource;

import java.sql.*;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

public class DbConnect {



    private  List<String> fileNames = new LinkedList<>();
    public List<String> getFileNames() {
        return fileNames;
    }

    public void getDbValues(String dbServer, String dbUserName, String dbPassword, String query) throws SQLException {
        fileNames.clear();
        ResultSet resultSet;
        try (Connection connection = DriverManager.getConnection(dbServer, dbUserName, dbPassword);Statement stmt = connection.createStatement();) {

            resultSet = stmt.executeQuery(query);
            fshDbFileList(resultSet);

        }

    }


    private void fshDbFileList(ResultSet resultSet) throws SQLException {
        while (resultSet.next()) {
            fileNames.add(objectToString(resultSet.getObject(1)));
        }

        fileNames = fileNames.parallelStream().distinct().collect(Collectors.toList());

    }

    private String objectToString(Object obj) {
        if (obj == null)
            return "";
        else
            return obj.toString();
    }
}
