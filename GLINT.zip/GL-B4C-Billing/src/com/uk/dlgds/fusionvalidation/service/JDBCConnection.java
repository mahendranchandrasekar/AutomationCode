package com.uk.dlgds.fusionvalidation.service;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedHashSet;
import java.util.stream.Collectors;


public class JDBCConnection {

    private static Connection crunchifyConn = null;
     static Statement crunchifyStmt = null;
     static ResultSet crunchifyResultset = null;
    private final ApplicationDetails applicationDetails = new ApplicationDetails();

    public String listFroFSHDB(String jdbcQuery) throws SQLException,IOException {
        LinkedHashSet<String> hashSet = new LinkedHashSet<>();
        final String server=applicationDetails.readProperties("com.uk.dlgds.jdbcServerUrl");
        final String userName=applicationDetails.readProperties("com.uk.dlgds.jdbcUsername");
        final String password=applicationDetails.readProperties("com.uk.dlgds.jdbcPassword");
        String listOfFiles="";
        String queryBuilder=",";
        try {
            // Returns the Class object associated with the class
            Class.forName("oracle.jdbc.driver.OracleDriver");
        } catch (ClassNotFoundException exception) {
            System.out.println("Oracle Driver Class Not found Exception: " + exception.toString());

        }

        // Set connection timeout. Make sure you set this correctly as per your need
        DriverManager.setLoginTimeout(5);
        System.out.println("Oracle JDBC Driver Successfully Registered! Let's make connection now");

        try {
            // Attempts to establish a connection
           crunchifyConn = DriverManager.getConnection(server, userName, password);
        } catch (SQLException e) {
            System.out.println("Connection Failed! Check output console");
            e.printStackTrace();

        }

        // Creates a Statement object for sending SQL statements to the database
        crunchifyStmt = crunchifyConn.createStatement();

        // Executes the given SQL statement, which returns a single ResultSet object
        crunchifyResultset = crunchifyStmt.executeQuery(jdbcQuery);

        while(crunchifyResultset.next()){
            hashSet.add(crunchifyResultset.getString("FILE_NAME" ));

        }

            System.out.println("Oracle JDBC connect and query test completed.");

        return  hashSet.stream()
                .map(strings -> "\'"+strings.trim()+"\'")
                .collect(Collectors.joining(","));

    }


}
