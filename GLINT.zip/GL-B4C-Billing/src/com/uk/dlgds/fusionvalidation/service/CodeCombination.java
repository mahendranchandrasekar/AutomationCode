package com.uk.dlgds.fusionvalidation.service;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;


public class CodeCombination extends EndpointValidation {
    private final ApplicationDetails applicationDetails = new ApplicationDetails();
    private String userName;
    private String passWord;
    private String url;
    private String ip;
    private String port;
    private String runInDLG;

    public String readCombination(String query) throws IOException, SAXException, ParserConfigurationException, TransformerException {


        readValues();


        HttpURLConnection httpURLConnection = null;
        Proxy proxy = null;
        URL obj = null;


        if ( runInDLG.equalsIgnoreCase( "YES" ) ) {

            proxy = new Proxy( Proxy.Type.HTTP, new InetSocketAddress( ip, Integer.parseInt( port ) ) );
            obj = new URL( url );
            httpURLConnection = (HttpURLConnection) obj.openConnection( proxy );
        } else {
            obj = new URL( url );
            httpURLConnection = (HttpURLConnection) obj.openConnection();
        }

        httpURLConnection.setRequestMethod( "POST" );
        httpURLConnection.setRequestProperty( "Content-Type", "application/soap+xml; charset=utf-8" );
        String encoded = Base64.getEncoder().encodeToString( (userName + ":" + passWord).getBytes( StandardCharsets.UTF_8 ) );
        httpURLConnection.setRequestProperty( "Authorization", "Basic " + encoded );
        String inputXML = updateQuery( readInputXML(), query );
        httpURLConnection.setDoOutput( true );
        DataOutputStream wr = new DataOutputStream( httpURLConnection.getOutputStream() );
        wr.writeBytes( inputXML );
        wr.flush();
        wr.close();
        org.w3c.dom.Document document = convertStringToXMLDocument( readResponse( httpURLConnection ).toString() );
        String nodes = document.getElementsByTagName( "ns2:runReportResponse" ).item( 0 ).getTextContent();
        byte[] byteArray = Base64.getDecoder().decode( nodes.substring( 0, nodes.length() - 8 ) );
        String output = new String( byteArray );
        return readCombinationID( convertStringToXMLDocument( output ) );
    }

    private String readCombinationID(org.w3c.dom.Document elementOutput) {
        System.out.println( "readcombinationID" );
        NodeList nList = elementOutput.getElementsByTagName( "Output" );
        String combinationID = null;
        for (int temp = 0; temp < nList.getLength(); temp++) {
            org.w3c.dom.Node nNode = nList.item( temp );
            if ( nNode.getNodeType() == Node.ELEMENT_NODE ) {
                Element eElement = (Element) nNode;
                combinationID = eElement.getElementsByTagName( "CODE_COMBINATION_ID" ).item( 0 ).getTextContent();
            }
        }
        return combinationID;
    }


    public void readValues() throws IOException {

        String runner = "JENKINS";

        userName = applicationDetails.readProperties( "com.uk.dlgds.username" ).trim();
        passWord = applicationDetails.readProperties( "com.uk.dlgds.password" ).trim();
        url = applicationDetails.readProperties( "com.uk.dlgds.endpoint.url" ).trim();

        if ( System.getProperty( "runner.name" ).equals( runner ) )
            ip = applicationDetails.readProperties( "com.uk.dlgds.proxy.ip.jenkins" ).trim();
        else
            ip = applicationDetails.readProperties( "com.uk.dlgds.proxy.ip" ).trim();

        port = applicationDetails.readProperties( "com.uk.dlgds.proxy.port" ).trim();

        runInDLG = applicationDetails.readProperties( "com.uk.dlgds.run.runInDLG" ).trim();
    }


    public void getVaAlues() throws IOException, SAXException, ParserConfigurationException, TransformerException {


        Map<String, String> codeCombinationValue = new HashMap<>();

        List<String> expected = Files.readAllLines( Paths.get( "./src/com/uk/dlgds/fusionvalidation/expectedfiles/B4CBillingExpectedRecords.csv" ) );
        List<String> expectedList;
        List<String> codeCombinationList = expected.stream()
                .map( o -> o.trim().split( "," )[26] )
                .filter( o -> !o.equalsIgnoreCase( "CODE_COMBINATION_ID" ) )
                .distinct()
                .collect( Collectors.toList() );


        for (String value : codeCombinationList)
            codeCombinationValue.put( value, objectToString( readCombination( value ) ) );


        System.out.println( codeCombinationList );
        System.out.println( codeCombinationValue );


        expectedList = new LinkedList<>();
        for (String value : expected) {
            for (Map.Entry<String, String> map : codeCombinationValue.entrySet())
                value = value.replace( map.getKey(), map.getValue() );
            expectedList.add( value );
        }

        writeExpectedFile( expectedList );

    }

    private void writeExpectedFile(List<String> expectedList)
            throws IOException {
        try (BufferedWriter writer = new BufferedWriter( new FileWriter( "./src/com/uk/dlgds/fusionvalidation/expectedfiles/B4CBillingExpectedRecords.csv" ) )) {
            for (String value : expectedList)
                writer.write( value.trim() + "\n" );
        }
    }

    private String objectToString(Object obj) {

        if ( obj == null )
            return "UTD";
        else
            return obj.toString();
    }


}
