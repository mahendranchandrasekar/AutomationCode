package com.uk.dlgds.fusionvalidation.service;

import com.uk.dlgds.fusionvalidation.B4CBillingGLIntegration;
import com.uk.dlgds.fusionvalidation.Utils.TestReport;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

import static java.lang.Math.abs;

public class B4CBillingActuals {

    public void glValidationActual(ArrayList<HashMap<String, String>> Actuals) throws IOException {

        TestReport testReport = new TestReport();
        testReport.setFilesNotProcessed(B4CBillingGLIntegration.FileNotProcessed);
        testReport.setFilesProcessed(B4CBillingGLIntegration.UniqueFSHFiles);
        String dataPublishedResult="";
        String expectedPublishedResult="";
        String actualPublishedResult="";

       // boolean multiple
        try (
                Reader reader = Files.newBufferedReader(Paths.get(".\\src\\com\\uk\\dlgds\\fusionvalidation\\expectedfiles\\B4CBillingExpectedRecords.csv"));
                CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT.withHeader().withIgnoreEmptyLines());

        ) {
            for (CSVRecord csvRecord : csvParser) {
                boolean duplicate=false;
                dataPublishedResult=csvRecord.get("SOURCE_FILE_NAME").trim()+ "," +csvRecord.get("TRANSACTION_NUMBER").trim()+ ","  +csvRecord.get("TRANSACTION_DATE").trim().replace("T00:00:00.000+00:00", "")+ ","  +csvRecord.get("FSH_BRAND").trim()+ ","  +csvRecord.get("FSH_PRODUCT").trim()+ "," +csvRecord.get("PRODUCT_KEY").trim()+ ","  +csvRecord.get("CURRENCY_CODE").trim()+ ","  +csvRecord.get("AHCS_EVENT_CODE").trim()+ "," +csvRecord.get("FSH_CHANNEL").trim();
                expectedPublishedResult=csvRecord.get("ACCOUNTING_CLASS_CODE").trim()+ ","+csvRecord.get("BASE_AMOUNT").trim()+ "," +csvRecord.get("Code_Combination_ID").trim()+ "," +csvRecord.get("LINE_OF_BUSINESS").trim()+ "," + csvRecord.get("SEGMENT1").trim()+ "-" + csvRecord.get("SEGMENT2").trim()+ "-" + csvRecord.get("SEGMENT3").trim()+ "-" + csvRecord.get("SEGMENT4").trim()+ "-" + csvRecord.get("SEGMENT5").trim()+ "-" + csvRecord.get("SEGMENT6").trim()+ "-" + csvRecord.get("SEGMENT7").trim()+ "-" + csvRecord.get("SEGMENT8").trim()+ "-" + csvRecord.get("SEGMENT9").trim()+ "-" + csvRecord.get("SEGMENT10").trim();


                int checkActualsDataPresent=0;
                boolean recordFoumd=false;
                for (HashMap<String, String> actual : Actuals) {
                    checkActualsDataPresent=checkActualsDataPresent+1;
                    boolean amountCheck=false;
                    if(Double.doubleToRawLongBits(Double.parseDouble(csvRecord.get("BASE_AMOUNT"))) >= 0){
                        if(csvRecord.get("ACCOUNTING_CLASS_CODE").equalsIgnoreCase(actual.get("ACCOUNTING_CLASS_CODE"))){
                          if(csvRecord.get("ACCOUNTING_CLASS_CODE").contains("DR")){
                            if(!actual.get("ENTERED_DR").equalsIgnoreCase("")){
                                if(abs(Double.parseDouble(csvRecord.get("BASE_AMOUNT"))) == Double.parseDouble(actual.get("ENTERED_DR"))){
                                    amountCheck=true;
                                }
                            }
                        }else if(csvRecord.get("ACCOUNTING_CLASS_CODE").contains("CR")){
                              if(!actual.get("ENTERED_CR").equalsIgnoreCase("")){
                                  if(abs(Double.parseDouble(csvRecord.get("BASE_AMOUNT"))) == Double.parseDouble(actual.get("ENTERED_CR"))){
                                      amountCheck=true;
                                  }
                              }
                          }

                          }

                    }else if(Double.doubleToRawLongBits(Double.parseDouble(csvRecord.get("BASE_AMOUNT"))) < 0){
                        if(!(csvRecord.get("ACCOUNTING_CLASS_CODE").equalsIgnoreCase(actual.get("ACCOUNTING_CLASS_CODE")))){
                            if(csvRecord.get("ACCOUNTING_CLASS_CODE").contains("CR")){
                                if(!actual.get("ENTERED_CR").equalsIgnoreCase("")){
                                    if(abs(Double.parseDouble(csvRecord.get("BASE_AMOUNT"))) == Double.parseDouble(actual.get("ENTERED_CR"))){
                                        amountCheck=true;
                                    }
                                }
                            }else if(csvRecord.get("ACCOUNTING_CLASS_CODE").contains("DR")){
                                if(!actual.get("ENTERED_DR").equalsIgnoreCase("")){
                                    if(abs(Double.parseDouble(csvRecord.get("BASE_AMOUNT"))) == Double.parseDouble(actual.get("ENTERED_DR"))){
                                        amountCheck=true;
                                    }
                                }
                            }


                        }

                    }


                            if(amountCheck &&
                            csvRecord.get("TRANSACTION_NUMBER").equalsIgnoreCase(actual.get("TRANSACTION_NUMBER"))

                            ) {
                                actualPublishedResult=actual.get("ACCOUNTING_CLASS_CODE")+ "," + csvRecord.get("BASE_AMOUNT") + "," + actual.get("CODE_COMBINATION_ID") +"," + actual.get("LINE_OF_BUSINESS");
                       if(csvRecord.get("Code_Combination_ID").equalsIgnoreCase(actual.get("CODE_COMBINATION_ID"))){
                           recordFoumd=true;
                           actualPublishedResult = actualPublishedResult + "," + csvRecord.get("SEGMENT1").trim()+ "-" + csvRecord.get("SEGMENT2").trim()+ "-" + csvRecord.get("SEGMENT3").trim()+ "-" + csvRecord.get("SEGMENT4").trim()+ "-" + csvRecord.get("SEGMENT5").trim()+ "-" + csvRecord.get("SEGMENT6").trim()+ "-" + csvRecord.get("SEGMENT7").trim()+ "-" + csvRecord.get("SEGMENT8").trim()+ "-" + csvRecord.get("SEGMENT9").trim()+ "-" + csvRecord.get("SEGMENT10").trim();
                           System.out.println("Passed - "+csvRecord.get("TRANSACTION_NUMBER") +"-"+csvRecord.get("Code_Combination_ID") +"-"+actual.get("CODE_COMBINATION_ID")+"-"+csvRecord.get("BASE_AMOUNT")) ;
                           if(duplicate){
                               testReport.setValuesToReport(dataPublishedResult, expectedPublishedResult, actualPublishedResult, TestReport.WARNING, "Code combination is matched but Expected Data is available in Actuals for multiple records - Kindly check");
                           }else{
                               testReport.setValuesToReport(dataPublishedResult, expectedPublishedResult, actualPublishedResult, TestReport.PASS, "Expected Data is available in Actuals and code combinations is matched");
                           }

                       }else{
                           System.out.println("Failed - "+csvRecord.get("TRANSACTION_NUMBER") +"-"+csvRecord.get("Code_Combination_ID")+"-"+actual.get("CODE_COMBINATION_ID")+"-"+csvRecord.get("BASE_AMOUNT")) ;

                           actualPublishedResult = actualPublishedResult + "," + "-";
                           if(duplicate){
                               testReport.setValuesToReport(dataPublishedResult, expectedPublishedResult, actualPublishedResult, TestReport.WARNING, "Code combination is not matched but Expected Data is available in Actuals for multiple records - Kindly check");
                           }else {
                               testReport.setValuesToReport(dataPublishedResult, expectedPublishedResult, actualPublishedResult, TestReport.FAIL, "Code combinations is not matched - Kindly check");

                           }}

                       duplicate=true;

                    }else if(!recordFoumd) {
                                if(Actuals.size() == checkActualsDataPresent){

                                    actualPublishedResult="-,"+"-,"+"-,"+"-,"+"-";
                                    testReport.setValuesToReport(dataPublishedResult, expectedPublishedResult, actualPublishedResult, TestReport.FAIL, "Expected Data is not available in Actuals - Kindly check");
                                }
                            }

                }
            }


        }
        testReport.publishReportFinal();
    }



}
