package com.uk.dlgds.fusionvalidation.service;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class ApplicationDetails {


    public String readProperties(String value) throws IOException {
        Properties credentials = new Properties();
        try (InputStream stream = getClass().getClassLoader().getResourceAsStream( "application.properties" )) {
            credentials.load( stream );
            return credentials.getProperty( value ).trim();
        }

    }
}

