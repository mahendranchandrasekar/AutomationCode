package com.uk.dlgds.fusionvalidation.service;


import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.dom4j.DocumentException;
import org.dom4j.Node;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;

import static javax.xml.parsers.DocumentBuilderFactory.*;

public class EndpointValidation {

    private ReadOuput readOuput = new ReadOuput();

    private final ApplicationDetails applicationDetails = new ApplicationDetails();

    private String username;
    private String password;
    private String url;
    private String ip;
    private String port;
    private String runInDLG;

    public void triggerEndPoint(String query, File newFile) throws IOException, ParserConfigurationException, SAXException, TransformerException {

        readValues();

        HttpURLConnection con = null;
        Proxy proxy = null;
        URL obj = null;

        if ( runInDLG.equalsIgnoreCase( "YES" ) ) {
            proxy = new Proxy( Proxy.Type.HTTP, new InetSocketAddress( ip, Integer.parseInt( port ) ) );
            obj = new URL( url );
            con = (HttpURLConnection) obj.openConnection( proxy );
        } else {
            obj = new URL( url );
            con = (HttpURLConnection) obj.openConnection();
        }


        con.setRequestMethod( "POST" );
        con.setRequestProperty( "Content-Type", "application/soap+xml; charset=utf-8" );
        con.setRequestProperty( "Authorization", "Basic " + encodeCredentials() );
        con.setDoOutput( true );
        DataOutputStream wr = new DataOutputStream( con.getOutputStream() );
        wr.writeBytes( updateQuery( readInputXML(), query ) );
        wr.flush();
        wr.close();
        org.w3c.dom.Document document = convertStringToXMLDocument( readResponse( con ).toString() );
        String nodes = document.getElementsByTagName( "ns2:runReportResponse" ).item( 0 ).getTextContent();
        byte[] byteArray = Base64.getDecoder().decode( nodes.substring( 0, nodes.length() - 8 ) );
        String output = new String( byteArray );
        readOuput.createTempCSV( convertStringToXMLDocument( output ), newFile );
    }

    public org.w3c.dom.Document readInputXML() throws IOException, ParserConfigurationException, SAXException {
        org.w3c.dom.Document document = null;
        try (InputStream stream = getClass().getClassLoader().getResourceAsStream( "com/uk/dlgds/fusionvalidation/resources/samples/SampleRequest.xml" )) {
            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
            document = docBuilder.parse( Objects.requireNonNull( stream ) );
        }
        return document;

    }

    public String encodeCredentials() throws IOException {
        /*Properties credentials = new Properties();
        try (InputStream stream = getClass().getClassLoader().getResourceAsStream("application.properties")) {
            assert stream != null;
            credentials.load(stream);
            return Base64.getEncoder().encodeToString((credentials.getProperty("com.uk.dlgds.username") + ":" +
                    credentials.getProperty("com.uk.dlgds.password")).getBytes(StandardCharsets.UTF_8));
        }*/
        return Base64.getEncoder().encodeToString( (username + ":" + password).getBytes( StandardCharsets.UTF_8 ) );
    }

    public String updateQuery(org.w3c.dom.Document inputXML, String values) throws TransformerException {

        inputXML.getElementsByTagName( "pub:item" ).item( 1 ).setTextContent( values );
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();
        transformer.setOutputProperty( OutputKeys.OMIT_XML_DECLARATION, "yes" );
        DOMSource source = new DOMSource( inputXML );
        StringWriter strWriter = new StringWriter();
        StreamResult result = new StreamResult( strWriter );
        transformer.transform( source, result );
        String output = strWriter.getBuffer().toString();
        output = output.replaceAll( "[\\r\\n]", "" );
        return output;

    }

    public StringBuffer readResponse(HttpURLConnection con) throws IOException {

        BufferedReader in = null;
        if ( con.getResponseCode() == 200 ) {
            System.out.println( "Response code is " + con.getResponseCode() );
            in = new BufferedReader( new
                    InputStreamReader( con.getInputStream() ) );
        } else {
            System.out.println( "Response code is not 200" );
            System.out.println( "Response code is " + con.getResponseCode() );
            in = new BufferedReader( new
                    InputStreamReader( con.getErrorStream() ) );
            System.exit( 0 );
        }
        String inputLine;
        StringBuffer response = new StringBuffer();
        while ((inputLine = in.readLine()) != null) {
            response.append( inputLine );
        }
        in.close();
        return response;
    }

    public org.w3c.dom.Document convertStringToXMLDocument(String xmlString) throws ParserConfigurationException, IOException, SAXException {

        DocumentBuilderFactory docBuilderFactory = newInstance();
        DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
        return docBuilder.parse( new InputSource( new StringReader( xmlString ) ) );
    }

    public ArrayList<HashMap<String, String>> triggerActualEndPoint(String query) throws IOException, DocumentException, ParserConfigurationException, SAXException, TransformerException {

        readValues();

        HttpURLConnection con = null;
        Proxy proxy = null;
        URL obj = null;

        if ( runInDLG.equalsIgnoreCase( "Yes" ) ) {
            proxy = new Proxy( Proxy.Type.HTTP, new InetSocketAddress( ip, Integer.parseInt( port ) ) );
            obj = new URL( url );
            con = (HttpURLConnection) obj.openConnection( proxy );
        } else {
            obj = new URL( url );
            con = (HttpURLConnection) obj.openConnection();
        }
        con.setRequestMethod( "POST" );
        con.setRequestProperty( "Content-Type", "application/soap+xml; charset=utf-8" );
        con.setRequestProperty( "Authorization", "Basic " + encodeCredentials() );
        con.setDoOutput( true );
        DataOutputStream wr = new DataOutputStream( con.getOutputStream() );
        wr.writeBytes( updateQuery( readInputXML(), query ) );
        wr.flush();
        wr.close();
        org.w3c.dom.Document document = convertStringToXMLDocument( readResponse( con ).toString() );
        String nodes = document.getElementsByTagName( "ns2:runReportResponse" ).item( 0 ).getTextContent();
        byte[] byteArray = Base64.getDecoder().decode( nodes.substring( 0, nodes.length() - 8 ) );
        String output = new String( byteArray );
        return readActualOutputs( convertStringToXMLDocument( output ) );

    }


    private ArrayList<ArrayList<String>> readActualOutput(org.w3c.dom.Document elementOutput) throws IOException {
        ArrayList<ArrayList<String>> config = new ArrayList<>();

        NodeList nList = elementOutput.getElementsByTagName( "Output" );
        System.out.println( "Total length of the node: " + nList.getLength() );

        for (int temp = 0; temp < nList.getLength(); temp++) {
            ArrayList<String> responseValues = new ArrayList<>();
            org.w3c.dom.Node nNode = nList.item( temp );
            if ( nNode.getNodeType() == Node.ELEMENT_NODE ) {
                Element eElement = (Element) nNode;
                responseValues.add( eElement.getElementsByTagName( "APPLICATION_ID" ).item( 0 ).getTextContent() );  //"APPLICATION_ID",
                responseValues.add( eElement.getElementsByTagName( "CODE_COMBINATION_ID" ).item( 0 ).getTextContent() );  //"CODE_COMBINATION_ID"
                responseValues.add( eElement.getElementsByTagName( "ACCOUNTING_CLASS_CODE" ).item( 0 ).getTextContent() ); //"ACCOUNTING_CLASS_CODE"
                responseValues.add( eElement.getElementsByTagName( "ENTERED_DR" ).item( 0 ).getTextContent() );   //"ENTERED_DR"
                responseValues.add( eElement.getElementsByTagName( "ENTERED_CR" ).item( 0 ).getTextContent() );
                responseValues.add( eElement.getElementsByTagName( "SR32" ).item( 0 ).getTextContent() );
                responseValues.add( eElement.getElementsByTagName( "SR33" ).item( 0 ).getTextContent() );
                responseValues.add( eElement.getElementsByTagName( "TRANSACTION_NUMBER" ).item( 0 ).getTextContent() );


                String Description = eElement.getElementsByTagName( "DESCRIPTION" ).item( 0 ).getTextContent();
                String[] Descriptions = Description.split( "," );


                String LINE_OF_BUSINESS = "";
                for (String eachDesc : Descriptions) {
                    if ( eachDesc.contains( "LOB" ) ) {
                        LINE_OF_BUSINESS = eachDesc.split( ":" )[1].trim();
                    }
                }

                String FSH_Product = "";
                for (String eachDesc : Descriptions) {
                    if ( eachDesc.contains( "FSH Product" ) ) {
                        FSH_Product = eachDesc.split( ":" )[1].trim();
                    }
                }

                String Product_Type = "";
                for (String eachDesc : Descriptions) {
                    if ( eachDesc.contains( "Product Type" ) ) {
                        Product_Type = eachDesc.split( ":" )[1].trim();
                    }
                }

                String Product_Key = "";
                for (String eachDesc : Descriptions) {
                    if ( eachDesc.contains( "Product Key" ) ) {
                        Product_Key = eachDesc.split( ":" )[1].trim();
                    }
                }

                String FSH_Brand = "";
                for (String eachDesc : Descriptions) {
                    if ( eachDesc.contains( "FSH Brand" ) ) {
                        FSH_Brand = eachDesc.split( ":" )[1].trim();
                    }
                }


                String FSH_Channel = "";
                for (String eachDesc : Descriptions) {
                    if ( eachDesc.contains( "FSH Channel" ) ) {
                        FSH_Channel = eachDesc.split( ":" )[1].trim();
                    }
                }


                /*  responseValues.add(ReserveFlag);*/
                responseValues.add( LINE_OF_BUSINESS );
                responseValues.add( FSH_Product );
                responseValues.add( Product_Type );
                responseValues.add( Product_Key );
                responseValues.add( FSH_Channel );
                responseValues.add( FSH_Brand );
                //System.out.println("Arraylist Printing"+ Arrays.toString(responseValues.toArray()));
                config.add( responseValues );
            }

        }
        System.out.println( "Arraylist" + config.toString() );
        return config;

    }

    private ArrayList<HashMap<String, String>> readActualOutputs(org.w3c.dom.Document elementOutput) throws IOException {
        ArrayList<HashMap<String, String>> config = new ArrayList<>();

        NodeList nList = elementOutput.getElementsByTagName( "Output" );
        System.out.println( "Total length of the node: " + nList.getLength() );

        for (int temp = 0; temp < nList.getLength(); temp++) {
            HashMap<String, String> responseValues = new HashMap<>();
            org.w3c.dom.Node nNode = nList.item( temp );
            if ( nNode.getNodeType() == Node.ELEMENT_NODE ) {
                Element eElement = (Element) nNode;
                responseValues.put( "APPLICATION_ID", eElement.getElementsByTagName( "APPLICATION_ID" ).item( 0 ).getTextContent() );  //"APPLICATION_ID",
                responseValues.put( "CODE_COMBINATION_ID", eElement.getElementsByTagName( "CODE_COMBINATION_ID" ).item( 0 ).getTextContent() );  //"CODE_COMBINATION_ID"
                responseValues.put( "ACCOUNTING_CLASS_CODE", eElement.getElementsByTagName( "ACCOUNTING_CLASS_CODE" ).item( 0 ).getTextContent() ); //"ACCOUNTING_CLASS_CODE"
                responseValues.put( "ENTERED_DR", eElement.getElementsByTagName( "ENTERED_DR" ).item( 0 ).getTextContent() );   //"ENTERED_DR"
                responseValues.put( "ENTERED_CR", eElement.getElementsByTagName( "ENTERED_CR" ).item( 0 ).getTextContent() );
                responseValues.put( "SR32", eElement.getElementsByTagName( "SR32" ).item( 0 ).getTextContent() );
                responseValues.put( "CURRENCY_CODE", eElement.getElementsByTagName( "CURRENCY_CODE" ).item( 0 ).getTextContent() );
                responseValues.put( "TRANSACTION_NUMBER", eElement.getElementsByTagName( "TRANSACTION_NUMBER" ).item( 0 ).getTextContent() );


                String Description = eElement.getElementsByTagName( "DESCRIPTION" ).item( 0 ).getTextContent();
                String[] Descriptions = Description.split( "," );


                String LINE_OF_BUSINESS = "";
                for (String eachDesc : Descriptions) {
                    if ( eachDesc.contains( "LOB" ) ) {
                        LINE_OF_BUSINESS = eachDesc.split( ":" )[1].trim();
                    }
                }

                String FSH_Product = "";
                for (String eachDesc : Descriptions) {
                    if ( eachDesc.contains( "FSH Product" ) ) {
                        FSH_Product = eachDesc.split( ":" )[1].trim();
                    }
                }

                String Product_Type = "";
                for (String eachDesc : Descriptions) {
                    if ( eachDesc.contains( "Product Type" ) ) {
                        Product_Type = eachDesc.split( ":" )[1].trim();
                    }
                }

                String Product_Key = "";
                for (String eachDesc : Descriptions) {
                    if ( eachDesc.contains( "Product Key" ) ) {
                        Product_Key = eachDesc.split( ":" )[1].trim();
                    }
                }

                String FSH_Brand = "";
                for (String eachDesc : Descriptions) {
                    if ( eachDesc.contains( "FSH Brand" ) ) {
                        FSH_Brand = eachDesc.split( ":" )[1].trim();
                    }
                }


                String FSH_Channel = "";
                for (String eachDesc : Descriptions) {
                    if ( eachDesc.contains( "FSH Channel" ) ) {
                        FSH_Channel = eachDesc.split( ":" )[1].trim();
                    }
                }


                responseValues.put( "LINE_OF_BUSINESS", LINE_OF_BUSINESS );
                responseValues.put( "FSH_Product", FSH_Product );
                responseValues.put( "Product_Type", Product_Type );
                responseValues.put( "Product_Key", Product_Key );
                responseValues.put( "FSH_Channel", FSH_Channel );
                responseValues.put( "FSH_Brand", FSH_Brand );
                config.add( responseValues );
            }

        }
        System.out.println( "Arraylist" + config.toString() );
        return config;

    }


    public String processActualQuerys(String query) {
        String csvFile = ".\\src\\com\\uk\\dlgds\\fusionvalidation\\expectedfiles\\B4CBillingExpectedRecords.csv";
        Reader reader = null;
        ArrayList<String> listOfFiles = new ArrayList<>();
        try {

            reader = Files.newBufferedReader( Paths.get( csvFile ) );
            CSVReader csvReader = new CSVReaderBuilder( reader ).withSkipLines( 1 ).build();
            String[] expectedData;

            while ((expectedData = csvReader.readNext()) != null) {
                listOfFiles.add( expectedData[5].trim() );
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if ( reader != null ) {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        String fileNamesExpected = "";
        String queryBuilder = ",";
        LinkedHashSet<String> hashSet = new LinkedHashSet<>( listOfFiles );
        Iterator fileList = hashSet.iterator();
        int count = 1;
        while (fileList.hasNext()) {
            if ( count == hashSet.size() ) {
                queryBuilder = "";
            }
            String file = fileList.next().toString();
            fileNamesExpected = fileNamesExpected + "'" + fileList.next().toString().substring( 0, Math.min( fileList.next().toString().length(), 30 ) ) + "'" + queryBuilder;
            count++;
        }

        query = query.replace( "uniqueFile", fileNamesExpected );
        System.out.println( query );
        return query;
    }

    public String processActualQuery() throws IOException {

        LinkedHashSet<String> hashSet = new LinkedHashSet<>();
        try (
                Reader reader = Files.newBufferedReader( Paths.get( ".\\src\\com\\uk\\dlgds\\fusionvalidation\\expectedfiles\\B4CBillingExpectedRecords.csv" ) );
                CSVParser csvParser = new CSVParser( reader, CSVFormat.DEFAULT.withHeader().withIgnoreEmptyLines() );

        ) {
            for (CSVRecord csvRecord : csvParser) {
                String sourceFileNameile = csvRecord.get( "SOURCE_FILE_NAME" );
                hashSet.add( sourceFileNameile.substring( 0, Math.min( sourceFileNameile.length(), 30 ) ) );
            }

            return hashSet.stream()
                    .map( strings -> "\'" + strings.trim() + "\'" )
                    .collect( Collectors.joining( "," ) );

        }

    }

    public void readValues() throws IOException {

        String runner = "JENKINS";

        username = applicationDetails.readProperties( "com.uk.dlgds.username" ).trim();
        password = applicationDetails.readProperties( "com.uk.dlgds.password" ).trim();
        url = applicationDetails.readProperties( "com.uk.dlgds.endpoint.url" ).trim();

        if ( System.getProperty( "runner.name" ).equals( runner ) )
            ip = applicationDetails.readProperties( "com.uk.dlgds.proxy.ip.jenkins" ).trim();
        else
            ip = applicationDetails.readProperties( "com.uk.dlgds.proxy.ip" ).trim();

        port = applicationDetails.readProperties( "com.uk.dlgds.proxy.port" ).trim();

        runInDLG = applicationDetails.readProperties( "com.uk.dlgds.run.runInDLG" ).trim();
    }

}