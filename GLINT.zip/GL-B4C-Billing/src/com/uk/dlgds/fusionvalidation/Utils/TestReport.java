package com.uk.dlgds.fusionvalidation.Utils;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class TestReport {

    public static final String PASS = "pass";
    public static final String FAIL = "fail";
    public static final String WARNING = "warning";
    private static final String COMMA_SPLIT = ",";
    private static final String TABLE_PATH = "./src/com/uk/dlgds/fusionvalidation/Utils/table.htm";
    private static final String REPORT_PATH = "./src/com/uk/dlgds/fusionvalidation/Utils/report.htm";
    private static final String REPORT_OUTPUT = "./src/com/uk/dlgds/fusionvalidation/Utils/reportOutput.html";
    private static final String DATE_FORMAT_REPORT_NAME = "yyyy_MM_dd_HH_mm_ss";
    private static final String DATE_FORMAT_REPORT = "yyyy_MM_dd HH:mm:ss";

    int crDr = 0;
    int amount = 1;
    int codeCombinationId = 2;
    int lob = 3;
    int segment = 4;
    private String reportName;


    private String filesProcessed;
    private String filesNotProcessed;
    private String fileName;
    private String transactionNumber;
    private String reportDate;
    private String trnDate;
    private String brand;
    private String product;
    private String eventId;
    private String currency;
    private String ahcsEventCode;
    private String fshChannel;
    private String crDrActual;
    private String amountActual;
    private String codeCombinationIdActual;
    private String lobActual;
    private String segmentActual;
    private String crDrExpected;
    private String amountExpected;
    private String codeCombinationIdExpected;
    private String lobExpected;
    private String segmentExpected;
    private String testResult;
    private String testResultMsg;
    private String htmlReport;
    private String table;
    private String xlaTable = "";
    private Map<String, String> replaceValueMap = new HashMap<>();

    public TestReport() {

        DateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT_REPORT);
        Date date = new Date();

        setBlankValues();
        setReportName("B4C Billing FSH to AHCS/GL Integration Test Report");
        setReportDate(dateFormat.format(date));
        setFilesProcessed("< ---NO--DATA--- >");
        setFilesNotProcessed("< ---NO--DATA--- >");
        readReport();
    }

    public void setExpectedValues(String expectedValues) {
        expectedValues = expectedValues.trim();
        setCrDrExpected( expectedValues.split( COMMA_SPLIT )[crDr] );
        setAmountExpected( expectedValues.split( COMMA_SPLIT )[amount] );
        setCodeCombinationIdExpected( expectedValues.split( COMMA_SPLIT )[codeCombinationId] );
        setLobExpected( expectedValues.split( COMMA_SPLIT )[lob] );
        setSegmentExpected( expectedValues.split( COMMA_SPLIT )[segment] );

    }

    public void setActualValues(String actualValues) {

        actualValues = actualValues.trim();

        try {
            setCrDrActual( actualValues.split( COMMA_SPLIT )[crDr] );
            setAmountActual( actualValues.split( COMMA_SPLIT )[amount] );
            setCodeCombinationIdActual( actualValues.split( COMMA_SPLIT )[codeCombinationId] );
            setLobActual( actualValues.split( COMMA_SPLIT )[lob] );
            setSegmentActual( actualValues.split( COMMA_SPLIT )[segment] );
        } catch (Exception e) {
            setCrDrActual( "" );
            setAmountActual( "" );
            setCodeCombinationIdActual( "" );
            setLobActual( "" );
            setSegmentActual( "" );
        }
    }

    public void setDataValues(String dataValues) {

        dataValues = dataValues.trim();
        DateFormat dateFormat = new SimpleDateFormat( DATE_FORMAT_REPORT );
        Date date = new Date();


        int fileName = 0;
        int transactionNumber = 1;
        int trnDate = 2;
        int brand = 3;
        int product = 4;
        int eventId = 5;
        int currency = 6;
        int ahcsEventCode = 7;
        int fshChannel = 8;


        /*setReportName( "B4C Billing - FSH to AHCS/GL Integration Test Report" );
        setReportDate( dateFormat.format( date ) );*/
        setFileName( dataValues.split( COMMA_SPLIT )[fileName] );
        setTransactionNumber( dataValues.split( COMMA_SPLIT )[transactionNumber] );
        setTrnDate( dataValues.split( COMMA_SPLIT )[trnDate] );
        setBrand( dataValues.split( COMMA_SPLIT )[brand] );
        setProduct( dataValues.split( COMMA_SPLIT )[product] );
        setEventId( dataValues.split( COMMA_SPLIT )[eventId] );
        setCurrency( dataValues.split( COMMA_SPLIT )[currency] );
        setAhcsEventCode( dataValues.split( COMMA_SPLIT )[ahcsEventCode] );
        setFshChannel( dataValues.split( COMMA_SPLIT )[fshChannel] );
    }

    public void setResultData(String Result, String ResultMsg) {

        if ( Result.trim().equalsIgnoreCase( PASS ) ) {
            setTestResult( "<span style=\"background-color: rgb(0, 254, 0);font-weight: bold;\">PASS</span>" );
        } else if ( Result.trim().equalsIgnoreCase( FAIL ) ) {
            setTestResult( "<span style=\"background-color: rgb(254, 0, 0);font-weight: bold;\">FAIL</span>" );
        } else if ( Result.trim().equalsIgnoreCase( WARNING ) ) {
            setTestResult( "<span style=\"background-color: rgb(254, 216, 0);font-weight: bold;\">WARNING</span>" );
        }

        setTestResultMsg( ResultMsg );

    }

    public void setValuesToReport(String dataValues, String expectedValues, String actualValues, String Result, String ResultMsg) throws IOException {

        readTable();

        setBlankValues();
        setDataValues( dataValues );
        setExpectedValues( expectedValues );
        setActualValues( actualValues );
        setResultData( Result, ResultMsg );

        writeTable();
        replaceTableValues();
        pushReport();

    }

    public void setBlankValues() {
        this.reportName = "";
        this.fileName = "";
        this.transactionNumber = "";
        this.trnDate = "";
        this.brand = "";
        this.product = "";
        this.eventId = "";
        this.currency = "";
        this.ahcsEventCode = "";
        this.fshChannel = "";
        this.crDrActual = "";
        this.amountActual = "";
        this.codeCombinationIdActual = "";
        this.lobActual = "";
        this.segmentActual = "";
        this.crDrExpected = "";
        this.amountExpected = "";
        this.codeCombinationIdExpected = "";
        this.lobExpected = "";
        this.segmentExpected = "";
        this.testResult = "";
        this.testResultMsg = "";
    }

    public void setReportName(String reportName) {
        this.reportName = reportName;
        replaceValueMap.put( "##report_name##", this.reportName );
    }

    public void setFilesProcessed(String filesProcessed) {
        this.filesProcessed = filesProcessed;
        replaceValueMap.put( "##files_processed##", filesProcessed );
    }

    public void setFilesNotProcessed(String filesNotProcessed) {
        this.filesNotProcessed = filesNotProcessed;
        replaceValueMap.put( "##files_not_processed##", filesNotProcessed );
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
        replaceValueMap.put( "##file_name##", fileName );
    }

    public void setReportDate(String reportDate) {
        this.reportDate = reportDate;
        replaceValueMap.put( "##date_time##", reportDate );
    }

    public void setTransactionNumber(String transactionNumber) {
        this.transactionNumber = transactionNumber;
        replaceValueMap.put( "##transaction_number##", transactionNumber );
    }

    public void setTrnDate(String trnDate) {
        this.trnDate = trnDate;
        replaceValueMap.put( "#trn_date#", trnDate );
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
        replaceValueMap.put( "#event_id#", eventId );
    }

    public void setCurrency(String currency) {
        this.currency = currency;
        replaceValueMap.put( "#currency#", currency );
    }

    public void setAhcsEventCode(String ahcsEventCode) {
        this.ahcsEventCode = ahcsEventCode;
        replaceValueMap.put( "#ahcs_event_code#", ahcsEventCode );
    }

    public void setFshChannel(String fshChannel) {
        this.fshChannel = fshChannel;
        replaceValueMap.put( "#fsh_channel#", fshChannel );
    }

    public void setLobActual(String lobActual) {
        this.lobActual = lobActual;
        replaceValueMap.put( "#actual_lob#", lobActual );
    }

    public void setSegmentActual(String segmentActual) {
        this.segmentActual = segmentActual;
        replaceValueMap.put( "#actual_segment#", segmentActual );
    }

    public void setLobExpected(String lobExpected) {
        this.lobExpected = lobExpected;
        replaceValueMap.put( "#expected_lob#", lobExpected );
    }

    public void setSegmentExpected(String segmentExpected) {
        this.segmentExpected = segmentExpected;
        replaceValueMap.put( "#expected_segment#", segmentExpected );
    }

    public void setBrand(String brand) {
        this.brand = brand;
        replaceValueMap.put( "#brand#", brand );
    }

    public void setProduct(String product) {
        this.product = product;
        replaceValueMap.put( "#product#", product );
    }


    public void setCrDrActual(String crDrActual) {
        this.crDrActual = crDrActual;
        replaceValueMap.put( "#actual_cr_dr#", crDrActual );
    }

    public void setAmountActual(String amountActual) {
        this.amountActual = amountActual;
        replaceValueMap.put( "#actual_amount#", amountActual );
    }

    public void setCodeCombinationIdActual(String codeCombinationIdActual) {
        this.codeCombinationIdActual = codeCombinationIdActual;
        replaceValueMap.put( "#actual_code_combination_id#", codeCombinationIdActual );
    }


    public void setCrDrExpected(String crDrExpected) {
        this.crDrExpected = crDrExpected;
        replaceValueMap.put( "#expected_cr_dr#", crDrExpected );
    }

    public void setAmountExpected(String amountExpected) {
        this.amountExpected = amountExpected;
        replaceValueMap.put( "#expected_amount#", amountExpected );
    }

    public void setCodeCombinationIdExpected(String codeCombinationIdExpected) {
        this.codeCombinationIdExpected = codeCombinationIdExpected;
        replaceValueMap.put( "#expected_code_combination_id#", codeCombinationIdExpected );
    }

    public void setTestResult(String testResult) {
        this.testResult = testResult;
        replaceValueMap.put( "#test_result#", testResult );
    }

    public void setTestResultMsg(String testResultMsg) {
        this.testResultMsg = testResultMsg;
        replaceValueMap.put( "#test_result_msg#", testResultMsg );
    }


    public void readReport() {
        try {
            List<String> content = Files.readAllLines( Paths.get( REPORT_PATH ) );
            htmlReport = content.stream().collect( Collectors.joining( "" ) );
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public void readTable() throws IOException {
        List<String> content = Files.readAllLines( Paths.get( TABLE_PATH ) );
        table = content.stream().collect( Collectors.joining( "" ) );
    }

    public void writeTable() {
        String replaceValue = String.format( "%s%s", table, "<br>::::End of Report::::" );
        htmlReport = htmlReport.replace( "::::End of Report::::", replaceValue );
    }

    public void pushReport() throws IOException {
        Files.write( Paths.get( REPORT_OUTPUT ), htmlReport.getBytes() );
    }

    public void replaceTableValues() {
        for (Map.Entry<String, String> map : replaceValueMap.entrySet())
            htmlReport = htmlReport.replace( map.getKey(), map.getValue() );
    }


    public void publishReportFinal() throws IOException {
        replaceTableValues();
        htmlReport = htmlReport.replace( "::::End of Report::::", xlaTable );
        htmlReport = String.format( "%s%s", htmlReport, "<br>::::End of Report::::" );

        DateFormat dateFormat = new SimpleDateFormat( DATE_FORMAT_REPORT_NAME );
        Date date = new Date();
        String reportPathDate = String.format( "./B4CBilling_TestReport_%s.html", dateFormat.format( date ) );
        Files.write( Paths.get( reportPathDate ), htmlReport.getBytes() );

        String reportPath = "./B4C-Billing.html";
        Files.write( Paths.get( reportPath ), htmlReport.getBytes() );


    }
}



