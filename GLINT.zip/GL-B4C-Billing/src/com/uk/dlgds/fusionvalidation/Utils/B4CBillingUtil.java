package com.uk.dlgds.fusionvalidation.Utils;

import com.uk.dlgds.fusionvalidation.service.CodeCombination;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.io.IOUtils;
import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;


public class B4CBillingUtil {

    public JSONObject readPostingRules() throws IOException {

        JSONObject postingRulesConfig = null;
        try(InputStream stream = getClass().getClassLoader().getResourceAsStream("com/uk/dlgds/fusionvalidation/resources/postingrules/B4CBilling.json")){
            assert stream != null;
            postingRulesConfig = new JSONObject(IOUtils.toString(stream, StandardCharsets.UTF_8));
        }
        return postingRulesConfig;
    }

    public void readB4CAccrualValues() throws IOException {


        JSONObject postingRules= readPostingRules();
        File newFile = new File(".\\src\\com\\uk\\dlgds\\fusionvalidation\\expectedfiles\\B4CBillingExpectedRecords.csv");
        CodeCombination post = new CodeCombination();
        String debit ="Debit";
        String credit ="Credit";

        try (
                Reader reader = Files.newBufferedReader(Paths.get(".\\src\\com\\uk\\dlgds\\fusionvalidation\\expectedfiles\\B4CBillingTemp.csv"));
                CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT.withHeader().withIgnoreEmptyLines());
                FileWriter writer = new FileWriter(newFile);
                CSVPrinter csvPrinter = new CSVPrinter(writer, CSVFormat.DEFAULT
                        .withHeader("TRANSACTION_DATE","TRANSACTION_NUMBER","TRANSACTION_SUBTYPE","TRANSACTION_REASON","AHCS_EVENT_CODE","FSH_SOURCE","SOURCE_FILE_NAME",
                                "UNDERWRITER","SUMMARY_FLAG","CREDIT_IND","EVENT_ID","LINE_NUMBER","APPLICATION_ID","BASE_AMOUNT",
                                "CURRENCY_CODE","ORIGINAL_AMOUNT","LINE_OF_BUSINESS","FSH_BRAND","FSH_CHANNEL","FSH_PRODUCT","PRODUCT_TYPE",
                                "EXCHANGE_RATE","EXCHANGE_RATE_TYPE","EXCHANGE_DATE","PRODUCT_KEY",
                                "ACCOUNTING_CLASS_CODE","Code_Combination_ID","SEGMENT1","SEGMENT2","SEGMENT3","SEGMENT4","SEGMENT5",
                                "SEGMENT6","SEGMENT7","SEGMENT8","SEGMENT9","SEGMENT10"
                        ));

        ) {
            for (CSVRecord csvRecord : csvParser) {

                if((Double.doubleToRawLongBits(Double.parseDouble(csvRecord.get("BASE_AMOUNT"))) >= 0)) {
                    String segment1 = postingRules.getJSONArray(debit).getJSONObject(0).optString("DLG_Company", "UTD");
                    String segment2 = postingRules.getJSONArray(debit).getJSONObject(0).getJSONObject("DLG_Transaction_Sub_Type").getJSONObject(csvRecord.get("TRANSACTION_SUBTYPE")).getJSONObject("DLG_Transaction_Reason").getJSONObject(csvRecord.get("TRANSACTION_REASON")).optString("DLG_CostCentre","UTD");
                    String segment3 = postingRules.getJSONArray(debit).getJSONObject(0).getJSONObject("DLG_Transaction_Sub_Type").getJSONObject(csvRecord.get("TRANSACTION_SUBTYPE")).getJSONObject("DLG_Transaction_Reason").getJSONObject(csvRecord.get("TRANSACTION_REASON")).optString("DLG_Account","UTD");
                    String segment4 ;
                    if((postingRules.getJSONArray(debit).getJSONObject(0).getJSONObject("DLG_Transaction_Sub_Type").getJSONObject(csvRecord.get("TRANSACTION_SUBTYPE")).getJSONObject("DLG_Transaction_Reason").optString(csvRecord.get("TRANSACTION_REASON"))
                            .contains("DLG_Product"))) {
                        segment4 = postingRules.getJSONArray(debit).getJSONObject(0).getJSONObject("DLG_Transaction_Sub_Type").getJSONObject(csvRecord.get("TRANSACTION_SUBTYPE")).getJSONObject("DLG_Transaction_Reason").getJSONObject(csvRecord.get("TRANSACTION_REASON")).optString("DLG_Product","UTD");
                    }else {
                        segment4 = postingRules.getJSONArray(debit).getJSONObject(0).getJSONObject("DLG_Product").optString(csvRecord.get("LINE_OF_BUSINESS"),"UTD");
                    }
                    String segment5 ;

                    if((postingRules.getJSONArray(debit).getJSONObject(0).getJSONObject("DLG_Transaction_Sub_Type").getJSONObject(csvRecord.get("TRANSACTION_SUBTYPE")).getJSONObject("DLG_Transaction_Reason").optString(csvRecord.get("TRANSACTION_REASON"),"UTD")
                            .contains("DLG_Brand"))) {
                        segment5 = postingRules.getJSONArray(debit).getJSONObject(0).getJSONObject("DLG_Transaction_Sub_Type").getJSONObject(csvRecord.get("TRANSACTION_SUBTYPE")).getJSONObject("DLG_Transaction_Reason").getJSONObject(csvRecord.get("TRANSACTION_REASON")).optString("DLG_Brand","UTD");
                    }else {
                        segment5 = postingRules.getJSONArray(debit).getJSONObject(0).getJSONObject("DLG_Brand").optString(csvRecord.get("FSH_BRAND"),"UTD");
                    }
                    String segment6 ;
                    if((postingRules.getJSONArray(debit).getJSONObject(0).getJSONObject("DLG_Transaction_Sub_Type").getJSONObject(csvRecord.get("TRANSACTION_SUBTYPE")).getJSONObject("DLG_Transaction_Reason").getJSONObject(csvRecord.get("TRANSACTION_REASON")).optString("DLG_Channel","UTD")
                            .contains("{"))) {
                        segment6 = postingRules.getJSONArray(debit).getJSONObject(0).getJSONObject("DLG_Transaction_Sub_Type").getJSONObject(csvRecord.get("TRANSACTION_SUBTYPE")).getJSONObject("DLG_Transaction_Reason").getJSONObject(csvRecord.get("TRANSACTION_REASON")).getJSONObject("DLG_Channel").optString(csvRecord.get("FSH_CHANNEL"),"UTD");
                    }else {
                        segment6 = postingRules.getJSONArray(debit).getJSONObject(0).getJSONObject("DLG_Transaction_Sub_Type").getJSONObject(csvRecord.get("TRANSACTION_SUBTYPE")).getJSONObject("DLG_Transaction_Reason").getJSONObject(csvRecord.get("TRANSACTION_REASON")).optString("DLG_Channel","UTD");
                    }
                    String segment7 = postingRules.getJSONArray(debit).getJSONObject(0).optString("DLG_Interco", "UTD");
                    String segment8;
                    if((postingRules.getJSONArray(debit).getJSONObject(0).getJSONObject("DLG_Transaction_Sub_Type").getJSONObject(csvRecord.get("TRANSACTION_SUBTYPE")).getJSONObject("DLG_Transaction_Reason").optString(csvRecord.get("TRANSACTION_REASON"))
                            .contains("DLG_Origin"))) {
                        segment8 = postingRules.getJSONArray(debit).getJSONObject(0).getJSONObject("DLG_Transaction_Sub_Type").getJSONObject(csvRecord.get("TRANSACTION_SUBTYPE")).getJSONObject("DLG_Transaction_Reason").getJSONObject(csvRecord.get("TRANSACTION_REASON")).optString("DLG_Origin","UTD");
                    }else {
                        segment8 = postingRules.getJSONArray(debit).getJSONObject(0).getJSONObject("DLG_Origin").optString(csvRecord.get("FSH_SOURCE"), "UTD");
                    }
                    String segment9 = postingRules.getJSONArray(debit).getJSONObject(0).optString("DLG_Spare1", "UTD");
                    String segment10 = postingRules.getJSONArray(debit).getJSONObject(0).optString("DLG_Spare2", "UTD");
                    String query = "select code_combination_id from gl_code_combinations where segment1 = '" + segment1 + "' and segment2 ='" + segment2 + "' and segment3 ='" + segment3 + "' and segment4 ='" + segment4 + "'and segment5 ='" + segment5 + "'and segment6 ='" + segment6 + "'and segment7 ='" + segment7 + "'and segment8 ='" + segment8 + "'and segment9 ='" + segment9 + "'and segment10='" + segment10 + "'";

                    csvPrinter.printRecord(csvRecord.get("TRANSACTION_DATE"), csvRecord.get("TRANSACTION_NUMBER"), csvRecord.get("TRANSACTION_SUBTYPE"), csvRecord.get("TRANSACTION_REASON"), csvRecord.get("AHCS_EVENT_CODE"),
                            csvRecord.get("FSH_SOURCE"), csvRecord.get("SOURCE_FILE_NAME"), csvRecord.get("UNDERWRITER"),
                            csvRecord.get("SUMMARY_FLAG"),csvRecord.get("CREDIT_IND"), csvRecord.get("EVENT_ID"), csvRecord.get("LINE_NUMBER"), csvRecord.get("APPLICATION_ID"),
                            csvRecord.get("BASE_AMOUNT"), csvRecord.get("CURRENCY_CODE"), csvRecord.get("ORIGINAL_AMOUNT"), csvRecord.get("LINE_OF_BUSINESS"),
                            csvRecord.get("FSH_BRAND"), csvRecord.get("FSH_CHANNEL"), csvRecord.get("FSH_PRODUCT"), csvRecord.get("PRODUCT_TYPE"),
                            csvRecord.get("EXCHANGE_RATE"), csvRecord.get("EXCHANGE_RATE_TYPE"), csvRecord.get("EXCHANGE_DATE"), csvRecord.get("PRODUCT_KEY"),
                            "DLG_MISC_DR", query,
                            segment1, segment2, segment3, segment4, segment5, segment6, segment7, segment8, segment9, segment10);

                     segment1 = postingRules.getJSONArray(credit).getJSONObject(0).optString("DLG_Company", "UTD");
                     segment2 = postingRules.getJSONArray(credit).getJSONObject(0).getJSONObject("DLG_Transaction_Sub_Type").getJSONObject(csvRecord.get("TRANSACTION_SUBTYPE")).getJSONObject("DLG_Transaction_Reason").getJSONObject(csvRecord.get("TRANSACTION_REASON")).optString("DLG_CostCentre","UTD");
                     segment3 = postingRules.getJSONArray(credit).getJSONObject(0).getJSONObject("DLG_Transaction_Sub_Type").getJSONObject(csvRecord.get("TRANSACTION_SUBTYPE")).getJSONObject("DLG_Transaction_Reason").getJSONObject(csvRecord.get("TRANSACTION_REASON")).optString("DLG_Account","UTD");

                    if((postingRules.getJSONArray(credit).getJSONObject(0).getJSONObject("DLG_Transaction_Sub_Type").getJSONObject(csvRecord.get("TRANSACTION_SUBTYPE")).getJSONObject("DLG_Transaction_Reason").optString(csvRecord.get("TRANSACTION_REASON"))
                            .contains("DLG_Product"))) {
                        segment4 = postingRules.getJSONArray(credit).getJSONObject(0).getJSONObject("DLG_Transaction_Sub_Type").getJSONObject(csvRecord.get("TRANSACTION_SUBTYPE")).getJSONObject("DLG_Transaction_Reason").getJSONObject(csvRecord.get("TRANSACTION_REASON")).optString("DLG_Product","UTD");
                    }else {
                        segment4 = postingRules.getJSONArray(credit).getJSONObject(0).getJSONObject("DLG_Product").optString(csvRecord.get("LINE_OF_BUSINESS"),"UTD");
                    }

                    if((postingRules.getJSONArray(credit).getJSONObject(0).getJSONObject("DLG_Transaction_Sub_Type").getJSONObject(csvRecord.get("TRANSACTION_SUBTYPE")).getJSONObject("DLG_Transaction_Reason").optString(csvRecord.get("TRANSACTION_REASON"),"UTD")
                            .contains("DLG_Brand"))) {
                        segment5 = postingRules.getJSONArray(credit).getJSONObject(0).getJSONObject("DLG_Transaction_Sub_Type").getJSONObject(csvRecord.get("TRANSACTION_SUBTYPE")).getJSONObject("DLG_Transaction_Reason").getJSONObject(csvRecord.get("TRANSACTION_REASON")).optString("DLG_Brand","UTD");
                    }else {
                        segment5 = postingRules.getJSONArray(credit).getJSONObject(0).getJSONObject("DLG_Brand").optString(csvRecord.get("FSH_BRAND"),"UTD");
                    }

                    if((postingRules.getJSONArray(credit).getJSONObject(0).getJSONObject("DLG_Transaction_Sub_Type").getJSONObject(csvRecord.get("TRANSACTION_SUBTYPE")).getJSONObject("DLG_Transaction_Reason").getJSONObject(csvRecord.get("TRANSACTION_REASON")).optString("DLG_Channel","UTD")
                            .contains("{"))) {
                        segment6 = postingRules.getJSONArray(credit).getJSONObject(0).getJSONObject("DLG_Transaction_Sub_Type").getJSONObject(csvRecord.get("TRANSACTION_SUBTYPE")).getJSONObject("DLG_Transaction_Reason").getJSONObject(csvRecord.get("TRANSACTION_REASON")).getJSONObject("DLG_Channel").optString(csvRecord.get("FSH_CHANNEL"),"UTD");
                    }else {
                        segment6 = postingRules.getJSONArray(credit).getJSONObject(0).getJSONObject("DLG_Transaction_Sub_Type").getJSONObject(csvRecord.get("TRANSACTION_SUBTYPE")).getJSONObject("DLG_Transaction_Reason").getJSONObject(csvRecord.get("TRANSACTION_REASON")).optString("DLG_Channel","UTD");
                    }
                    segment7 = postingRules.getJSONArray(credit).getJSONObject(0).optString("DLG_Interco", "UTD");
                    if((postingRules.getJSONArray(credit).getJSONObject(0).getJSONObject("DLG_Transaction_Sub_Type").getJSONObject(csvRecord.get("TRANSACTION_SUBTYPE")).getJSONObject("DLG_Transaction_Reason").optString(csvRecord.get("TRANSACTION_REASON"))
                            .contains("DLG_Origin"))) {
                        segment8 = postingRules.getJSONArray(credit).getJSONObject(0).getJSONObject("DLG_Transaction_Sub_Type").getJSONObject(csvRecord.get("TRANSACTION_SUBTYPE")).getJSONObject("DLG_Transaction_Reason").getJSONObject(csvRecord.get("TRANSACTION_REASON")).optString("DLG_Origin","UTD");
                    }else {
                        segment8 = postingRules.getJSONArray(credit).getJSONObject(0).getJSONObject("DLG_Origin").optString(csvRecord.get("FSH_SOURCE"), "UTD");
                    }
                    segment9 = postingRules.getJSONArray(credit).getJSONObject(0).optString("DLG_Spare1", "UTD");
                    segment10 = postingRules.getJSONArray(credit).getJSONObject(0).optString("DLG_Spare2", "UTD");
                    query = "select code_combination_id from gl_code_combinations where segment1 = '" + segment1 + "' and segment2 ='" + segment2 + "' and segment3 ='" + segment3 + "' and segment4 ='" + segment4 + "'and segment5 ='" + segment5 + "'and segment6 ='" + segment6 + "'and segment7 ='" + segment7 + "'and segment8 ='" + segment8 + "'and segment9 ='" + segment9 + "'and segment10='" + segment10 + "'";

                    csvPrinter.printRecord(csvRecord.get("TRANSACTION_DATE"), csvRecord.get("TRANSACTION_NUMBER"), csvRecord.get("TRANSACTION_SUBTYPE"), csvRecord.get("TRANSACTION_REASON"), csvRecord.get("AHCS_EVENT_CODE"),
                            csvRecord.get("FSH_SOURCE"), csvRecord.get("SOURCE_FILE_NAME"), csvRecord.get("UNDERWRITER"),
                            csvRecord.get("SUMMARY_FLAG"),csvRecord.get("CREDIT_IND"), csvRecord.get("EVENT_ID"), csvRecord.get("LINE_NUMBER"), csvRecord.get("APPLICATION_ID"),
                            csvRecord.get("BASE_AMOUNT"), csvRecord.get("CURRENCY_CODE"), csvRecord.get("ORIGINAL_AMOUNT"), csvRecord.get("LINE_OF_BUSINESS"),
                            csvRecord.get("FSH_BRAND"), csvRecord.get("FSH_CHANNEL"), csvRecord.get("FSH_PRODUCT"), csvRecord.get("PRODUCT_TYPE"),
                            csvRecord.get("EXCHANGE_RATE"), csvRecord.get("EXCHANGE_RATE_TYPE"), csvRecord.get("EXCHANGE_DATE"), csvRecord.get("PRODUCT_KEY"),
                            "DLG_MISC_CR", query,
                            segment1, segment2, segment3, segment4, segment5, segment6, segment7, segment8, segment9, segment10);
                }else{
                    String segment1 = postingRules.getJSONArray(credit).getJSONObject(0).optString("DLG_Company", "UTD");
                    String segment2 = postingRules.getJSONArray(credit).getJSONObject(0).getJSONObject("DLG_Transaction_Sub_Type").getJSONObject(csvRecord.get("TRANSACTION_SUBTYPE")).getJSONObject("DLG_Transaction_Reason").getJSONObject(csvRecord.get("TRANSACTION_REASON")).optString("DLG_CostCentre","UTD");
                    String segment3 = postingRules.getJSONArray(credit).getJSONObject(0).getJSONObject("DLG_Transaction_Sub_Type").getJSONObject(csvRecord.get("TRANSACTION_SUBTYPE")).getJSONObject("DLG_Transaction_Reason").getJSONObject(csvRecord.get("TRANSACTION_REASON")).optString("DLG_Account","UTD");
                    String segment4;
                    String segment5;
                    String segment6;
                    if((postingRules.getJSONArray(credit).getJSONObject(0).getJSONObject("DLG_Transaction_Sub_Type").getJSONObject(csvRecord.get("TRANSACTION_SUBTYPE")).getJSONObject("DLG_Transaction_Reason").optString(csvRecord.get("TRANSACTION_REASON"))
                            .contains("DLG_Product"))) {
                        segment4 = postingRules.getJSONArray(credit).getJSONObject(0).getJSONObject("DLG_Transaction_Sub_Type").getJSONObject(csvRecord.get("TRANSACTION_SUBTYPE")).getJSONObject("DLG_Transaction_Reason").getJSONObject(csvRecord.get("TRANSACTION_REASON")).optString("DLG_Product","UTD");
                    }else {
                        segment4 = postingRules.getJSONArray(credit).getJSONObject(0).getJSONObject("DLG_Product").optString(csvRecord.get("LINE_OF_BUSINESS"),"UTD");
                    }

                    if((postingRules.getJSONArray(credit).getJSONObject(0).getJSONObject("DLG_Transaction_Sub_Type").getJSONObject(csvRecord.get("TRANSACTION_SUBTYPE")).getJSONObject("DLG_Transaction_Reason").optString(csvRecord.get("TRANSACTION_REASON"),"UTD")
                            .contains("DLG_Brand"))) {
                        segment5 = postingRules.getJSONArray(credit).getJSONObject(0).getJSONObject("DLG_Transaction_Sub_Type").getJSONObject(csvRecord.get("TRANSACTION_SUBTYPE")).getJSONObject("DLG_Transaction_Reason").getJSONObject(csvRecord.get("TRANSACTION_REASON")).optString("DLG_Brand","UTD");
                    }else {
                        segment5 = postingRules.getJSONArray(credit).getJSONObject(0).getJSONObject("DLG_Brand").optString(csvRecord.get("FSH_BRAND"),"UTD");
                    }

                    if((postingRules.getJSONArray(credit).getJSONObject(0).getJSONObject("DLG_Transaction_Sub_Type").getJSONObject(csvRecord.get("TRANSACTION_SUBTYPE")).getJSONObject("DLG_Transaction_Reason").getJSONObject(csvRecord.get("TRANSACTION_REASON")).optString("DLG_Channel","UTD")
                            .contains("{"))) {
                        segment6 = postingRules.getJSONArray(credit).getJSONObject(0).getJSONObject("DLG_Transaction_Sub_Type").getJSONObject(csvRecord.get("TRANSACTION_SUBTYPE")).getJSONObject("DLG_Transaction_Reason").getJSONObject(csvRecord.get("TRANSACTION_REASON")).getJSONObject("DLG_Channel").optString(csvRecord.get("FSH_CHANNEL"),"UTD");
                    }else {
                        segment6 = postingRules.getJSONArray(credit).getJSONObject(0).getJSONObject("DLG_Transaction_Sub_Type").getJSONObject(csvRecord.get("TRANSACTION_SUBTYPE")).getJSONObject("DLG_Transaction_Reason").getJSONObject(csvRecord.get("TRANSACTION_REASON")).optString("DLG_Channel","UTD");
                    }
                    String segment7 = postingRules.getJSONArray(credit).getJSONObject(0).optString("DLG_Interco", "UTD");
                    String segment8;
                    if((postingRules.getJSONArray(credit).getJSONObject(0).getJSONObject("DLG_Transaction_Sub_Type").getJSONObject(csvRecord.get("TRANSACTION_SUBTYPE")).getJSONObject("DLG_Transaction_Reason").optString(csvRecord.get("TRANSACTION_REASON"))
                            .contains("DLG_Origin"))) {
                        segment8 = postingRules.getJSONArray(credit).getJSONObject(0).getJSONObject("DLG_Transaction_Sub_Type").getJSONObject(csvRecord.get("TRANSACTION_SUBTYPE")).getJSONObject("DLG_Transaction_Reason").getJSONObject(csvRecord.get("TRANSACTION_REASON")).optString("DLG_Origin","UTD");
                    }else {
                        segment8 = postingRules.getJSONArray(credit).getJSONObject(0).getJSONObject("DLG_Origin").optString(csvRecord.get("FSH_SOURCE"), "UTD");
                    }
                    String segment9 = postingRules.getJSONArray(credit).getJSONObject(0).optString("DLG_Spare1", "UTD");
                    String segment10 = postingRules.getJSONArray(credit).getJSONObject(0).optString("DLG_Spare2", "UTD");
                    String query = "select code_combination_id from gl_code_combinations where segment1 = '" + segment1 + "' and segment2 ='" + segment2 + "' and segment3 ='" + segment3 + "' and segment4 ='" + segment4 + "'and segment5 ='" + segment5 + "'and segment6 ='" + segment6 + "'and segment7 ='" + segment7 + "'and segment8 ='" + segment8 + "'and segment9 ='" + segment9 + "'and segment10='" + segment10 + "'";


                    csvPrinter.printRecord(csvRecord.get("TRANSACTION_DATE"), csvRecord.get("TRANSACTION_NUMBER"),  csvRecord.get("TRANSACTION_SUBTYPE"), csvRecord.get("TRANSACTION_REASON"), csvRecord.get("AHCS_EVENT_CODE"),
                            csvRecord.get("FSH_SOURCE"), csvRecord.get("SOURCE_FILE_NAME"), csvRecord.get("UNDERWRITER"),
                            csvRecord.get("SUMMARY_FLAG"), csvRecord.get("CREDIT_IND"),csvRecord.get("EVENT_ID"), csvRecord.get("LINE_NUMBER"), csvRecord.get("APPLICATION_ID"),
                            csvRecord.get("BASE_AMOUNT"), csvRecord.get("CURRENCY_CODE"), csvRecord.get("ORIGINAL_AMOUNT"), csvRecord.get("LINE_OF_BUSINESS"),
                            csvRecord.get("FSH_BRAND"), csvRecord.get("FSH_CHANNEL"), csvRecord.get("FSH_PRODUCT"), csvRecord.get("PRODUCT_TYPE"),
                            csvRecord.get("EXCHANGE_RATE"), csvRecord.get("EXCHANGE_RATE_TYPE"), csvRecord.get("EXCHANGE_DATE"), csvRecord.get("PRODUCT_KEY"),
                            "DLG_MISC_DR", query,
                            segment1, segment2, segment3, segment4, segment5, segment6, segment7, segment8, segment9, segment10);


                     segment1 = postingRules.getJSONArray(debit).getJSONObject(0).optString("DLG_Company", "UTD");
                     segment2 = postingRules.getJSONArray(debit).getJSONObject(0).getJSONObject("DLG_Transaction_Sub_Type").getJSONObject(csvRecord.get("TRANSACTION_SUBTYPE")).getJSONObject("DLG_Transaction_Reason").getJSONObject(csvRecord.get("TRANSACTION_REASON")).optString("DLG_CostCentre","UTD");
                     segment3 = postingRules.getJSONArray(debit).getJSONObject(0).getJSONObject("DLG_Transaction_Sub_Type").getJSONObject(csvRecord.get("TRANSACTION_SUBTYPE")).getJSONObject("DLG_Transaction_Reason").getJSONObject(csvRecord.get("TRANSACTION_REASON")).optString("DLG_Account","UTD");

                    if((postingRules.getJSONArray(debit).getJSONObject(0).getJSONObject("DLG_Transaction_Sub_Type").getJSONObject(csvRecord.get("TRANSACTION_SUBTYPE")).getJSONObject("DLG_Transaction_Reason").optString(csvRecord.get("TRANSACTION_REASON"))
                            .contains("DLG_Product"))) {
                        segment4 = postingRules.getJSONArray(debit).getJSONObject(0).getJSONObject("DLG_Transaction_Sub_Type").getJSONObject(csvRecord.get("TRANSACTION_SUBTYPE")).getJSONObject("DLG_Transaction_Reason").getJSONObject(csvRecord.get("TRANSACTION_REASON")).optString("DLG_Product","UTD");
                    }else {
                        segment4 = postingRules.getJSONArray(debit).getJSONObject(0).getJSONObject("DLG_Product").optString(csvRecord.get("LINE_OF_BUSINESS"),"UTD");
                    }
                    if((postingRules.getJSONArray(debit).getJSONObject(0).getJSONObject("DLG_Transaction_Sub_Type").getJSONObject(csvRecord.get("TRANSACTION_SUBTYPE")).getJSONObject("DLG_Transaction_Reason").optString(csvRecord.get("TRANSACTION_REASON"),"UTD")
                            .contains("DLG_Brand"))) {
                        segment5 = postingRules.getJSONArray(debit).getJSONObject(0).getJSONObject("DLG_Transaction_Sub_Type").getJSONObject(csvRecord.get("TRANSACTION_SUBTYPE")).getJSONObject("DLG_Transaction_Reason").getJSONObject(csvRecord.get("TRANSACTION_REASON")).optString("DLG_Brand","UTD");
                    }else {
                        segment5 = postingRules.getJSONArray(debit).getJSONObject(0).getJSONObject("DLG_Brand").optString(csvRecord.get("FSH_BRAND"),"UTD");
                    }

                    if((postingRules.getJSONArray(debit).getJSONObject(0).getJSONObject("DLG_Transaction_Sub_Type").getJSONObject(csvRecord.get("TRANSACTION_SUBTYPE")).getJSONObject("DLG_Transaction_Reason").getJSONObject(csvRecord.get("TRANSACTION_REASON")).optString("DLG_Channel","UTD")
                            .contains("{"))) {
                        segment6 = postingRules.getJSONArray(debit).getJSONObject(0).getJSONObject("DLG_Transaction_Sub_Type").getJSONObject(csvRecord.get("TRANSACTION_SUBTYPE")).getJSONObject("DLG_Transaction_Reason").getJSONObject(csvRecord.get("TRANSACTION_REASON")).getJSONObject("DLG_Channel").optString(csvRecord.get("FSH_CHANNEL"),"UTD");
                    }else {
                        segment6 = postingRules.getJSONArray(debit).getJSONObject(0).getJSONObject("DLG_Transaction_Sub_Type").getJSONObject(csvRecord.get("TRANSACTION_SUBTYPE")).getJSONObject("DLG_Transaction_Reason").getJSONObject(csvRecord.get("TRANSACTION_REASON")).optString("DLG_Channel","UTD");
                    }
                     segment7 = postingRules.getJSONArray(debit).getJSONObject(0).optString("DLG_Interco", "UTD");
                    if((postingRules.getJSONArray(debit).getJSONObject(0).getJSONObject("DLG_Transaction_Sub_Type").getJSONObject(csvRecord.get("TRANSACTION_SUBTYPE")).getJSONObject("DLG_Transaction_Reason").optString(csvRecord.get("TRANSACTION_REASON"))
                            .contains("DLG_Origin"))) {
                        segment8 = postingRules.getJSONArray(debit).getJSONObject(0).getJSONObject("DLG_Transaction_Sub_Type").getJSONObject(csvRecord.get("TRANSACTION_SUBTYPE")).getJSONObject("DLG_Transaction_Reason").getJSONObject(csvRecord.get("TRANSACTION_REASON")).optString("DLG_Origin","UTD");
                    }else {
                        segment8 = postingRules.getJSONArray(debit).getJSONObject(0).getJSONObject("DLG_Origin").optString(csvRecord.get("FSH_SOURCE"), "UTD");
                    }
                    segment9 = postingRules.getJSONArray(debit).getJSONObject(0).optString("DLG_Spare1", "UTD");
                     segment10 = postingRules.getJSONArray(debit).getJSONObject(0).optString("DLG_Spare2", "UTD");
                    query = "select code_combination_id from gl_code_combinations where segment1 = '" + segment1 + "' and segment2 ='" + segment2 + "' and segment3 ='" + segment3 + "' and segment4 ='" + segment4 + "'and segment5 ='" + segment5 + "'and segment6 ='" + segment6 + "'and segment7 ='" + segment7 + "'and segment8 ='" + segment8 + "'and segment9 ='" + segment9 + "'and segment10='" + segment10 + "'";


                    csvPrinter.printRecord(csvRecord.get("TRANSACTION_DATE"), csvRecord.get("TRANSACTION_NUMBER"),  csvRecord.get("TRANSACTION_SUBTYPE"), csvRecord.get("TRANSACTION_REASON"), csvRecord.get("AHCS_EVENT_CODE"),
                            csvRecord.get("FSH_SOURCE"), csvRecord.get("SOURCE_FILE_NAME"), csvRecord.get("UNDERWRITER"),
                            csvRecord.get("SUMMARY_FLAG"),csvRecord.get("CREDIT_IND"), csvRecord.get("EVENT_ID"), csvRecord.get("LINE_NUMBER"), csvRecord.get("APPLICATION_ID"),
                            csvRecord.get("BASE_AMOUNT"), csvRecord.get("CURRENCY_CODE"), csvRecord.get("ORIGINAL_AMOUNT"), csvRecord.get("LINE_OF_BUSINESS"),
                            csvRecord.get("FSH_BRAND"), csvRecord.get("FSH_CHANNEL"), csvRecord.get("FSH_PRODUCT"), csvRecord.get("PRODUCT_TYPE"),
                            csvRecord.get("EXCHANGE_RATE"), csvRecord.get("EXCHANGE_RATE_TYPE"), csvRecord.get("EXCHANGE_DATE"), csvRecord.get("PRODUCT_KEY"),
                            "DLG_MISC_CR", query,
                            segment1, segment2, segment3, segment4, segment5, segment6, segment7, segment8, segment9, segment10);



                }
            }
        }
    }

}
