package com.uk.dlgds.fusionvalidation;

import com.uk.dlgds.fusionvalidation.Utils.B4CBillingUtil;
import com.uk.dlgds.fusionvalidation.service.*;
import org.dom4j.DocumentException;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

public class B4CBillingGLIntegration {

    private final ApplicationDetails applicationDetails = new ApplicationDetails();
    private final EndpointValidation endpointValidation = new EndpointValidation();
    private final B4CBillingUtil b4CBillingUtil = new B4CBillingUtil();
    private final JDBCConnection jdbcConnection = new JDBCConnection();
    private final B4CBillingActuals b4CBillingActuals =new B4CBillingActuals();
    public static String  FileNotProcessed="FSH Interface connection not triggered";
    public static String UniqueFSHFiles="FSH Interface connection not triggered";
    CodeCombination codeCombination = new CodeCombination();


    @Test
    public void B4CAccrual() throws IOException, DocumentException, ParserConfigurationException, SAXException, TransformerException,SQLException {
      final File newFile = new File(".\\src\\com\\uk\\dlgds\\fusionvalidation\\expectedfiles\\B4CBillingTemp.csv");

        String expectedFSHQuery=applicationDetails.readProperties("B4CBilling.FSHExpectedQuery");
        String expectedQuery=applicationDetails.readProperties("B4CBilling.ExpectedQuery");
        String actualQuery=applicationDetails.readProperties("B4CBilling.FSHActualQuery");

        final String jdbcQuery=applicationDetails.readProperties("B4CBilling.FSHJDBCQuery");
        final String jdbcFileNotProcessedQuery=applicationDetails.readProperties("B4CBilling.FSHFileNotProcessQuery");


       if(applicationDetails.readProperties("com.uk.dlgds.fshValidation").equalsIgnoreCase("true")){
           FileNotProcessed= jdbcConnection.listFroFSHDB(jdbcFileNotProcessedQuery).replaceAll("\'","");
           UniqueFSHFiles= jdbcConnection.listFroFSHDB(jdbcQuery);
           if(!(UniqueFSHFiles.equals("No Data available in FSH"))) {
               expectedFSHQuery = expectedFSHQuery.replace("FileNameFromFSH", UniqueFSHFiles);
               endpointValidation.triggerEndPoint(expectedFSHQuery, newFile);
               UniqueFSHFiles=UniqueFSHFiles.replaceAll("\'","");
           }


        } else {
           endpointValidation.triggerEndPoint(expectedQuery, newFile);
       }
        if(!(UniqueFSHFiles.equals("No Data available in FSH"))) {
            b4CBillingUtil.readB4CAccrualValues();
            codeCombination.getVaAlues();
            actualQuery=actualQuery.replace("uniqueFile", endpointValidation.processActualQuery());
            ArrayList<HashMap<String, String>> arrayList = endpointValidation.triggerActualEndPoint(actualQuery);
            b4CBillingActuals.glValidationActual(arrayList);
        }

    }



}