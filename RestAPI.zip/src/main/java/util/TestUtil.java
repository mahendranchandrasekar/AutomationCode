package util;

import org.json.JSONArray;
import org.json.JSONObject;

public class TestUtil {

    public static String getValueByJPath(JSONObject responsejson, String jpath) {
        Object obj = responsejson;
        for (String s1Value : jpath.split("/"))
            if (!s1Value.isEmpty())
                if (!(s1Value.contains("[") || s1Value.contains("]")))
                    obj = ((JSONObject) obj).get(s1Value);

                else if (s1Value.contains("[") || s1Value.contains("]"))
                    obj = ((JSONArray) ((JSONObject) obj).get(s1Value.split("\\[")[0])).
                            get(Integer.parseInt(s1Value.split("\\[")[1].
                                    replace("]", "")));
        return obj.toString();
    }

}
