package Java8Learnings;

import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.stream.Stream;

public class StreamsWithFilter {

    @Test
    public void testWithoutStreams(String[] args) {
        ArrayList<String> arrayList = new ArrayList<String>();
        arrayList.add("AbhiJeet");
        arrayList.add("Mardonna");
        arrayList.add("Alam");
        arrayList.add("Adam");
        arrayList.add("Ram");
        int count = 0;

        for(int i=0; i<arrayList.size(); i++){
            String actualValues = arrayList.get(i);
            if(actualValues.startsWith("A")){
                count++;
            }
        }
        System.out.println("count of names starts with A: " +count);
    }

    @Test
    public void testStreamsWithFilter(){
        ArrayList<String> arrayList = new ArrayList<String>();
        arrayList.add("AbhiJeet");
        arrayList.add("Mardonna");
        arrayList.add("Alam");
        arrayList.add("Adam");
        arrayList.add("Ram");
        int count = 0;

        long nameCount1 = arrayList.stream().filter(s->s.startsWith("A")).count();
        System.out.println("count of names starts with A in nameCount1: " +nameCount1);

        long nameCount2 = Stream.of("AbhiJeet","Mardonna","Alam","Adam","Ram").filter(s->
        {
            s.startsWith("A");
            return true;
        }).count();
        System.out.println("count of names starts with A in nameCount2: " +nameCount2);


        //print all the names of ArrayList
        arrayList.stream().filter(s -> s.length()>4).forEach(s -> System.out.println("print all the names of ArrayList :" + s));
        //Limited the resultSet
        arrayList.stream().filter(s -> s.length()>4).limit(1).forEach(s -> System.out.println("Limited the resultSet" +s));
        arrayList.stream().filter(s -> s.length()>4).skip(1).forEach(s -> System.out.println("Limited the resultSet" +s));
    }
}

