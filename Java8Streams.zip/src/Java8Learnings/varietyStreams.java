package Java8Learnings;

import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class varietyStreams {

    @Test
    public void streamsWithVariety() {
        //1. Pipeline of operations
        IntStream.of(new int[]{4, 7, 1, 8, 3, 9, 7}).filter((int i) -> i > 5).distinct().forEach(System.out::println);

        //2. Parallel Executions
        List<String>  names = new ArrayList<>();
        names.add("Daviddd");     names.add("Warnerrrrr");    names.add("Smithhhhh");  names.add("Steven");  names.add("mahi");
        names.stream().filter((String i) -> i.length() > 5).skip(2).forEach(System.out::println);
        names.parallelStream().filter((String i) -> i.length() > 3).skip(2).forEach(System.out::println);

        //3. empty()
        Stream<String>  emptyStream = Stream.empty();
        System.out.println(emptyStream.count());

        //4. Streams are traversed only once
        List<String> nameList = Arrays.asList("Natrajan","Pandya","Jadeja");
        Stream<String> s1 = nameList.stream();
        s1.forEach(System.out::println);   //s1.forEach(System.out::println);

        //5. create a stream from vlause
        Stream<Integer> s2= Stream.of(7,2,6,9,4,3,1);
        System.out.println(s2.count());

        //6. Creating Stream from collections
        List<String> s3= new ArrayList<>();
        s3.add("Tendulkar");
        s3.add("Jadeja");
        s3.add("Dhoni");
        s3.add("Sehwag");
        s3.add("Ganguly");
        s3.stream().forEach(System.out::println);

        //7. mapping operations - map(Function<T,R> mapper)
        s3.stream().map(String::length).forEach(System.out::println);

        //8. sorted(Comparator)
        s3.stream().sorted((String name1, String name2) -> name1.length()-name2.length()).forEach(System.out::println);



    }
}