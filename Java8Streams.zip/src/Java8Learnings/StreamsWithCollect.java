package Java8Learnings;

import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamsWithCollect {

    @Test
    public void streamsWithCollect(){
       List<String> S1= Stream.of("Abhijeet","Don","Alekhya","Rama","Adam").filter(s -> s.endsWith("a")).map(s->s.toUpperCase())
                .collect(Collectors.toList());
        System.out.println(S1.get(0));


        List<Integer> S2 = Arrays.asList(3,2,2,1,1,5,5,9,10,7,12);
        S2.stream().distinct().sorted().forEach(s-> System.out.println("To find Unique nunbers in ascending order:"+s));

        List<Integer> S3 = Arrays.asList(3,2,2,9,1,5,5,9,10,7,12); //1,2,3,5,7,9,10,12
        List<Integer> S4 = S3.stream().distinct().sorted().collect(Collectors.toList());
        System.out.println(S4.get(3));





    }


}
