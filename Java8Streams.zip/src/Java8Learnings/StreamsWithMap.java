package Java8Learnings;

import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class StreamsWithMap {

    @Test
    public void streamsWithMap(){
        ArrayList<String> array1 = new ArrayList<String>();
        array1.add("Ravi");
        array1.add("selva");
        array1.add("Don");

        //prints the name endswith 'a' to convert into uppercase
        Stream.of("Abhijeet","Don","Alekhya","Rama","Adam").filter(s -> s.endsWith("a")).map(s->s.toUpperCase())
                .forEach(s -> System.out.println("prints the name endswith 'a' to convert into uppercase :" +s));

        //prints the name startswith 'a' to convert into uppercase and sorted
        List<String> array = Arrays.asList("Azbhijeet","Don","Alekhya","Rama","Adam");
        array.stream().filter(s->s.startsWith("A")).sorted().map(s->s.toUpperCase())
                .forEach(s-> System.out.println("prints the name startswith 'a' to convert into uppercase and sorted : " +s));


        //Merging 2 different Lists
        Stream<String> S1= Stream.concat(array1.stream(),array.stream());
        //S1.distinct().sorted().forEach(s-> System.out.println("Merging 2 different Lists : "+s));

        //returns true if it is matching
        boolean flag= S1.anyMatch(s -> s.equalsIgnoreCase("Adam"));
        System.out.println(flag);



    }
}
