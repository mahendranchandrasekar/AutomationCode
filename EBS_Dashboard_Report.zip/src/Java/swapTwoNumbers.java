package Java;

import java.util.Scanner;

public class swapTwoNumbers {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the String");
        String S1 = sc.nextLine();
        String S2 = sc.nextLine();
        System.out.println("before swapping");
        System.out.println("S1--------" +S1);
        System.out.println("S2--------" +S2);

        S1 = S1 + S2;
        S2 = S1.substring(0,S1.length() - S2.length());
        S1 = S1.substring(S2.length());
        System.out.println("S1--------" +S1);
        System.out.println("S2--------" +S2);
    }
}
