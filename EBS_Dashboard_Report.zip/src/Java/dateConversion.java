package Java;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class dateConversion {
    public static void main(String[] args){

        try {
            /*Date sdf1= new SimpleDateFormat("dd-MMM-yyyy hh:mm:ss").parse("06-Nov-1989 08:45:00");
            System.out.println(sdf1);*/

            String sdf2 = new SimpleDateFormat("dd-MMM-yyyy").format(new Date());
            System.out.println(sdf2);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
