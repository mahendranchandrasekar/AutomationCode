package Java;

import java.util.Scanner;

public class vowelsInJava {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a String");
        String S1 = sc.nextLine();
        char[] S2 = S1.toCharArray();

        int Count = 0;
        for(char S3 : S2){
            switch(S3) {
                case 'a':
                case 'e':
                case 'o':
                case 'i':
                case 'u':
                    Count++;
                    break;
            }
        }
        System.out.println("Count of Vowels character in the given string:" +Count);
    }
}
