package Java;

import java.util.Scanner;

public class reverseNumber {
    public static void main(String[] args){
        int reverse = 0;
        int S1 = 0;
        System.out.println("Enter the Number");
        Scanner sc = new Scanner(System.in);
        int S2 = sc.nextInt();

        while(S2 >0){
            S1 = S2%10;
            reverse = reverse*10 + S1;
            S2 = S2/10;
        }
        System.out.println(reverse);
    }
}
