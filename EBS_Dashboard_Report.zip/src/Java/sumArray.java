package Java;

public class sumArray {
    public static void main(String[] args){
        sumOfDigits(485966);
    }

    public static void sumOfDigits(int S1){
        int S2 = S1;
        int sum =0;

        while(S2 !=0){
            int lastDigit = S2%10;
            sum = sum+lastDigit;
            S2 = S2/10;
        }
        System.out.println("Sum of all Digits: " +sum);
    }
}
