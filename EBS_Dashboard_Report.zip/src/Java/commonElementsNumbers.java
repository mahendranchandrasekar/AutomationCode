package Java;

import java.util.Arrays;
import java.util.HashSet;

public class commonElementsNumbers {
    public static void main(String[] args){
        Integer[] arr1 = {1,2,89,4,7,23};
        Integer[] arr2 = {12,89,4,6};
        HashSet<Integer> S1 = new HashSet<Integer>(Arrays.asList(arr1));
        HashSet<Integer> S2 = new HashSet<Integer>(Arrays.asList(arr2));

        S1.retainAll(S2);
        System.out.println(S1);
    }
}
