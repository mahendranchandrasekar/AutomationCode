package Java;

import java.util.Scanner;

public class NoOfWordsInString {
     public static void main(String[] args) {
         System.out.println("Enter the String");
         Scanner sc = new Scanner(System.in);
         String str = sc.nextLine();
         String str1[] = str.trim().split(" ");
         System.out.println("No of words in a string:" +str1.length);
}
}
