package Java;

public class maxTwoNumbers {
    public static void main(String[] args){
        int num[] = {4,64,8,45,22,42,9,10};
        maxTwoNumbers S1 = new maxTwoNumbers();
        S1.maximum(num);
    }

    public void maximum(int[] a){
        int firstBigNumber=0;
        int secondBigNumber=0;

        for(int num : a){
            if(firstBigNumber < num){
                secondBigNumber = firstBigNumber;
                firstBigNumber = num;
            } else if(secondBigNumber < num) {
                secondBigNumber = num;
            }
        }
        System.out.println("firstBigNumber--------" +firstBigNumber);
        System.out.println("secondBigNumber--------" +secondBigNumber);
    }
}
