package Java;

import java.util.Scanner;

public class reverseString {
    public static void main(String[] args){
        String reverse = "";
        System.out.println("Enter the String");
        Scanner sc = new Scanner(System.in);
        String S1 = sc.nextLine();

        for(int i=S1.length()-1; i>=0; i--){
            reverse = reverse+ S1.charAt(i);
            System.out.println(reverse);
        }
    }
}
