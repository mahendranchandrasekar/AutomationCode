package Java;

import java.util.HashMap;
import java.util.Set;

public class duplicateWordsInJava {
    public static void main(String[] args){
        duplicateWords("Bread butter and bread");
    }

    public static void duplicateWords(String S1){
        String[] words = S1.split(" ");

        HashMap<String, Integer> S2 = new HashMap<String, Integer>();
        for(String word : words){
            if(S2.containsKey(word.toLowerCase())) {
                S2.put(word.toLowerCase(), S2.get(word.toLowerCase()) +1);
            } else {
                S2.put(word.toLowerCase(), 1);
            }
            Set<String> S3 = S2.keySet();
            for(String word1 : S3) {
                if(S2.get(word1) > 1 ){
                    System.out.println(word+"-------------" +S2.get(word1));
                }
            }
        }
    }
}
