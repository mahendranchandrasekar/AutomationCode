package Java;

public class separationInJava {
    public static void main(String[] args){
        separationString("Today15512@#@");
    }

    public static void separationString(String S1){
        String Number = "";
        String Letter = "";
        String Symbol = "";

        for(int i=0; i<S1.length(); i++){
            char S2 = S1.charAt(i);
            if(Character.isDigit(S2)){
                Number = Number+S2;
            } else if(Character.isLetter(S2)){
                Letter = Letter + S2;
            } else {
                Symbol = Symbol+S2;
            }
        }
        System.out.println(Number);
        System.out.println(Letter);
        System.out.println(Symbol);
    }
}
