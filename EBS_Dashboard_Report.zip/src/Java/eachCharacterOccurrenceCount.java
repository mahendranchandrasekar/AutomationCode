package Java;

import java.util.HashMap;

public class eachCharacterOccurrenceCount {
    public static void main(String[] args){
        duplicateWords("JAVA J2EE JAVA JSP");
    }

    public static void duplicateWords(String S1){
        char[] words = S1.toCharArray();

        HashMap<Character, Integer> S2 = new HashMap<Character, Integer>();
        for(char word : words){
            if(S2.containsKey(word)){
                S2.put(word, S2.get(word)+1);
            } else {
                S2.put(word,1);
            }
        }
        System.out.println("Each character count: "+S2);
    }
}
