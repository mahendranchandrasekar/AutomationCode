package Dashboard_Report;

import java.io.IOException;
import java.sql.*;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONException;

public class Landscape_GL_Billing {

    static Statement SQLstmt = null;
    static ResultSet SQLResultset = null;

    public static HTML_Report_Generation_DB_EVO report_generation;
    public static HTML_Report_Generation_State_Model_B4C report_generation_state;
    public static SCH_EVO_PC_State_Model_B4C state_model;

    public static Table_Detail_Report table_detail_report;
    public static Table_Summary_Report table_summary_report;
    public static connectDatabase connect_db;

    public static void main(String[] args) throws SQLException, IOException, JSONException {

        report_generation = new HTML_Report_Generation_DB_EVO();
        report_generation_state = new HTML_Report_Generation_State_Model_B4C();
        state_model = new SCH_EVO_PC_State_Model_B4C();

        table_detail_report = new Table_Detail_Report();
        table_summary_report = new Table_Summary_Report();
        connect_db = new connectDatabase();

        //----------------------- delete the existing report --------------
        report_generation.clean_report("Landscape_GLBilling.html");
        report_generation_state.clean_report_summary("Landscape_GLBilling_Summary.html");

        /*//--------------- SIT  database details -------------------
        String URL_SIT1 = "jdbc:oracle:thin:@dbs119dev.gwd.grpinf.net:1521/FSHDTST3";
        String Username_SIT1 = "FSH_ORA_DATA";
        String password_SIT1 = "Development_Test3";*/

        /*//--------------- SIT  database details -------------------
        String URL_SIT1 = "jdbc:oracle:thin:@dcn2dcll11z:1521/FSHTSIT1.gwd.grpinf.net";
        String Username_SIT1 = "FSH_ORA_DATA";
        String password_SIT1 = "vMw5HpJaFy3uD6eW";

        //--------------- EBS  database details -------------------
        String URL_ICSI = "jdbc:oracle:thin:@dcn2ddbx340.gwd.grpinf.net:1618:ICSI";
        String Username_ICSI = "apps";
        String password_ICSI = "apps4icsi";*/

        List<String> file_list = new ArrayList<String>();
        List<String> list = new ArrayList<String>();
        List<String> section1_results = new ArrayList<String>();
        /*List<String> section2_results = new ArrayList<String>();
        List<String> section3_results = new ArrayList<String>();*/
        List<String> section4_results = new ArrayList<String>();

        List<String> OverAllStatus = new ArrayList<String>();
        List<String> CONS_STATUS = new ArrayList<String>();
        List<String> summary_results_tbl = new ArrayList<String>();

        String[] file_lists = null;
        int section1_map_row = 1;

        //--------------------- Decelaring the supporting details for reporting --------------
        String file_name = "null";
        String Source = "LAND";
        String pattern = "GLBilling";
        String header = "Header";

        //---- Initialiing row count variables -----
        int cons_stg_map_row = 1;

        //---- Initialiing Mandatory row count variables -----
        int mandatoryCONS_map_row = 1;
        int mandatorySTG_map_row = 1;
        int stg_line_map_row =1;

        // Consolidation Header table variable
        String btc_BATCH_PKEY = null;
        String db_CONS_BC_HEADER_ID = "null";
        String db_CONS_SOURCE = "null";
        String db_CONS_HDR_STATUS = "null";
        String db_CONS_ACCOUNT_NUMBER = "null";
        String db_CONS_POLICY_NUMBER = "null";
        String db_CONS_CLAIM_NUMBER = "null";
        String db_CONS_UNDERWRITER = null;
        String db_CONS_BRAND = "null";
        String db_CONS_LINE_OF_BUSINESS = "null";
        String db_CONS_PRODUCT_TYPE = "null";
        String db_CONS_TRANSACTION_REFERENCE = "null";
        String db_CONS_TRANSACTION_DATE = "null";
        String db_CONS_TRANSACTION_SUBTYPE = "null";
        String db_CONS_TRANSACTION_REASON = "null";
        String db_CONS_BANK_ACC = "null";
        String db_CONS_PAYMENT_METHOD = "null";
        String db_CONS_SUN_NUMBER = "null";
        String db_CONS_MID_NUMBER = "null";
        String db_CONS_DDI_REFERENCE = "null";
        String db_CONS_PAY_IN_SLIP_NUMBER = "null";
        String db_CONS_CHEQUE_NUMBER = "null";
        String db_CONS_CARD_TYPE = "null";
        String db_CONS_BACS_NARRATIVE = "null";
        String db_CONS_CHANNEL = "null";
        String db_CONS_INTEREST_AMOUNT = "null";
        String db_CONS_INTEREST_CURRENCY_CODE = "null";
        String db_CONS_BASE_INTEREST_AMOUNT = "null";
        String db_CONS_TAX_DEDUCTIBLE = "null";
        String db_CONS_ORDER_NUMBER = "null";
        String db_CONS_REVERSAL_INDICATOR = "null";
        String db_CONS_CARD_NARRATIVE = "null";
        String db_CONS_PAYMENT_TRANSACTION_TYPE_ID = "null";
        String db_CONS_CURRENCY_AMOUNT = "null";
        String db_CONS_CURRENCY_CODE = "null";
        String db_CONS_EXCHANGE_RATE = "null";
        String db_CONS_EXCHANGE_RATE_TYPE = "null";
        String db_CONS_BASE_CURRENCY_AMOUNT = "null";
        String db_CONS_FSH_ATTRIBUTE_1 = "null";
        String db_CONS_FSH_ATTRIBUTE_2 = "null";
        String db_CONS_LOSS_DATE = "null";
        String db_CONS_PRODUCT = "null";
        String db_CONS_GL_STRING = "null";
        String db_CONS_LPI_CODE = "null";
        String db_CONS_PERIL_CODE = "null";
        String load_date = null;
        Date load_dateFormat = null;

// Staging Header table variable declaration
        String db_STG_HEADER_ID = "null";
        String db_STG_SOURCE = "null";
        String db_STG_ACCOUNT_NUMBER = "null";
        String db_STG_HDR_STATUS = "null";
        String db_STG_POLICY_NUMBER = "null";
        String db_STG_CLAIM_NUMBER = "null";
        String db_STG_UNDERWRITER = "null";
        String db_STG_BRAND = "null";
        String db_STG_LINE_OF_BUSINESS = "null";
        String db_STG_PRODUCT_TYPE = "null";
        String db_STG_TRANSACTION_REFERENCE = "null";
        String db_STG_TRANSACTION_DATE = "null";
        String db_STG_TRANSACTION_SUBTYPE = "null";
        String db_STG_TRANSACTION_REASON = "null";
        String db_STG_BANK_ACC = "null";
        String db_STG_PAYMENT_METHOD = "null";
        String db_STG_SUN_NUMBER = "null";
        String db_STG_MID_NUMBER = "null";
        String db_STG_DDI_REFERENCE = "null";
        String db_STG_PAY_IN_SLIP_NUMBER = "null";
        String db_STG_CHEQUE_NUMBER = "null";
        String db_STG_CARD_TYPE = "null";
        String db_STG_BACS_NARRATIVE = "null";
        String db_STG_CHANNEL = "null";
        String db_STG_INTEREST_AMOUNT = "null";
        String db_STG_INTEREST_CURRENCY_CODE = "null";
        String db_STG_BASE_INTEREST_AMOUNT = "null";

        String db_STG_TAX_DEDUCTIBLE = "null";
        String db_STG_ORDER_NUMBER = "null";
        String db_STG_REVERSAL_INDICATOR = "null";
        String db_STG_CARD_NARRATIVE = "null";
        String db_STG_PAYMENT_TRANSACTION_TYPE_ID = "null";
        String db_STG_CURRENCY_AMOUNT = "null";
        String db_STG_CURRENCY_CODE = "null";
        String db_STG_EXCHANGE_RATE = "null";
        String db_STG_EXCHANGE_RATE_TYPE = "null";
        String db_STG_BASE_CURRENCY_AMOUNT = "null";
        String db_STG_LOSS_DATE = "null";
        String db_STG_PRODUCT = "null";
        String db_STG_FSH_ATTRIBUTE_01 = "null";
        String db_STG_PRODUCT_KEY = "null";
        String db_STG_PERIL_CODE = "null";
        String db_STG_TOH_ID = "null";
        String db_STG_EVENT_CODE = "null";
        String db_STG_ENTITY_TYPE_CODE = "null";
        String db_STG_BC_SUMMARY_ID = "null";
        String db_STG_SUMMARY_FLAG = "null";
        String db_STG_CREDIT_IND = "null";
        String STG_HDR_STATUS = "null";

        String xmlfile_name = "null";
        String xml_file_name1 = null;

        //-------- Connect to Database --------------
        connect_db.createConnection("SIT2");

        //------ get the new file from batch control table --------------
        boolean newRecord = true;
        String outSQL = connect_db.executeQuery_DB("BATCH", "GLBilling_batchCtl", "LANDSCAPE");
        SQLstmt = connect_db.resStatement();

        SQLResultset = SQLstmt.executeQuery(outSQL);
        while (SQLResultset.next()) {
            file_list.add(SQLResultset.getString("FILE_NAME"));
            System.out.println("File name---" + SQLResultset.getString("FILE_NAME"));
            list.addAll(section1_results);
        }

        // ---------------------------------- Get the batch PKEY ----------------------
        String outSQL_bkey = connect_db.executeQuery_DB("BATCH", "GLBilling_batchCtl_key","LANDSCAPE");

        SQLResultset = SQLstmt.executeQuery(outSQL_bkey);
        while (SQLResultset.next()) {
            btc_BATCH_PKEY = SQLResultset.getString("BATCH_PKEY");
        }

        /*// ---------------------------------- Get the batch PKEY ----------------------
        SQLResultset = SQLstmt.executeQuery("Select BATCH_PKEY from dlg_fsh_ctl_batch where  FILE_NAME = 'GWBCGLBilling_20191109161811.xml' ");
        while (SQLResultset.next()) {
            btc_BATCH_PKEY = SQLResultset.getString("BATCH_PKEY");
        }*/

        // ---------------------------------- Check the new file ----------------------
        SQLResultset = SQLstmt.executeQuery(outSQL);
        if (!SQLResultset.next()) {
            System.out.println("No new Landscape_GLBilling files have been received to FSH ");
            newRecord = false;
            String nonewfile = ",FILE_NAME," + "No new Landscape_GLBilling files have been received to FSH" + "," + "," + ",Pass";
            section1_results.add(nonewfile);
            list.addAll(section1_results);
        }

        if (newRecord) {

            //------------------------ Section 1 Start Print all the new file in the report-------------------
            for (String num_file : file_list) {
                file_lists = num_file.split(",");
                for (String file_list1 : file_lists) {
                    xml_file_name1 = file_list1;
                    //int section1_map_row = 1;
                    String newfile = section1_map_row + ",FILE_NAME," + xml_file_name1 + "," + xml_file_name1 + ",Pass";
                    section1_map_row++;
                    section1_results.add(newfile);
                }
            }
            list.addAll(section1_results);
            //------------------------ Section 1 End ----------------------------------------------
        }

        List<String> list_header = new ArrayList<String>(); // -- Add all the header id
        if (newRecord) {
            //------------ Split the file names form the list --------------
            for (String xml_file_name : file_list) {
                int section2_map_row = 1;
                int CONS_flag = 0;
                List<String> section2_results = new ArrayList<String>();
                List<String> section3_results = new ArrayList<String>();
                List<String> section2_results_tbl = new ArrayList<String>();

                file_name = xml_file_name;


                //--------------------------------- Section 3 Start Here ---------------------------------
                boolean sec3flag = true;
                String db_STG_ACTL_RCDS = null;
                Integer db_STG_ACTL_RCDS1 = 0;

                SQLResultset = SQLstmt.executeQuery("SELECT COUNT(HEADER_ID) as STG_ACTL_RCDS FROM FSH_ORA_DATA.DLG_FSH_STG_COMM_BCCC_HDR WHERE FILE_NAME = '" + xml_file_name + "'");
                while (SQLResultset.next()) {
                    db_STG_ACTL_RCDS = SQLResultset.getString("STG_ACTL_RCDS");
                    db_STG_ACTL_RCDS1 = SQLResultset.getInt("STG_ACTL_RCDS");
                    System.out.println("stag Actual header count ----" + db_STG_ACTL_RCDS);
                }

                if (db_STG_ACTL_RCDS1 == 0) {  //--- Zero record validation
                    sec3flag = false;
                    String pc_stg_header_line = 1 + "," + "STG_ACTL_RCDS DB Does not have any records" + "," + "STG_ACTL_RCDS DB Does not have any records" + "," + "STG_AGG_ACTUAL_HEADER DB Does not have any records" + ",Fail";
                    section3_results.add(pc_stg_header_line);
                }

                SQLResultset = SQLstmt.executeQuery("SELECT * FROM FSH_ORA_DATA.DLG_FSH_STG_COMM_BCCC_HDR WHERE FILE_NAME = '" + xml_file_name + "'");
                while (SQLResultset.next()) {
                    db_STG_SUMMARY_FLAG = SQLResultset.getString("SUMMARY_FLAG");
                    db_STG_REVERSAL_INDICATOR = SQLResultset.getString("REVERSAL_INDICATOR");
                    System.out.println("stag Summary Flag ----" + db_STG_SUMMARY_FLAG);
                }

                if (sec3flag) {
                    do {

                        SQLResultset = SQLstmt.executeQuery("SELECT COUNT(a.HEADER_ID) as STG_EXP_SUM_HDRS \n" +
                                "FROM(\n" +
                                "SELECt HEADER_ID,STATUS,\n" +
                                "row_number() over(partition by SOURCE,UNDERWRITER,PRODUCT_TYPE,LINE_OF_BUSINESS,trunc(TRANSACTION_DATE),TRANSACTION_SUB_TYPE,TRANSACTION_REASON,PAYMENT_METHOD,SUN_NUMBER,MID_NUMBER,CARD_TYPE,BACS_NARRATIVE,CHANNEL,REVERSAL_INDICATOR,CURRENCY_CODE,EXCHANGE_RATE,EXCHANGE_RATE_TYPE,CREDIT_IND,BATCH_FKEY,ENTITY_TYPE_CODE,EVENT_CODE,BRAND,INTEREST_CURRENCY_CODE,PAY_IN_SLIP_NUMBER,PAYMENT_TRANSACTION_TYPE_ID,FILE_NAME,CARD_NARRATIVE,SUMMARY_FLAG,BANK_ACC,PRODUCT,PRODUCT_KEY\n" +
                                "ORDER BY SOURCE,UNDERWRITER,PRODUCT_TYPE,LINE_OF_BUSINESS,TRANSACTION_DATE,TRANSACTION_SUB_TYPE,TRANSACTION_REASON,PAYMENT_METHOD,SUN_NUMBER,MID_NUMBER,CARD_TYPE,BACS_NARRATIVE,CHANNEL,REVERSAL_INDICATOR,CURRENCY_CODE,EXCHANGE_RATE,EXCHANGE_RATE_TYPE,CREDIT_IND,BATCH_FKEY,ENTITY_TYPE_CODE,EVENT_CODE,BRAND,INTEREST_CURRENCY_CODE,PAY_IN_SLIP_NUMBER,PAYMENT_TRANSACTION_TYPE_ID,FILE_NAME,CARD_NARRATIVE,SUMMARY_FLAG,BANK_ACC,PRODUCT,PRODUCT_KEY) row_1\n" +
                                "FROM FSH_ORA_DATA.DLG_FSH_STG_COMM_BCCC_HDR WHERE FILE_NAME = '" + xml_file_name + "')a \n" +
                                "where a.row_1 = 1\n" +
                                "AND a.STATUS = 'COMPLETE'");


                        while (SQLResultset.next()) {
                            String STG_EXP_SUM_HDRS = SQLResultset.getString("STG_EXP_SUM_HDRS");
                            SQLResultset = SQLstmt.executeQuery("SELECT count(TOH_ID)as STG_AGG_ACTUAL_HEADER FROM FSH_ORA_DATA.DLG_FSH_STG_COMM_BCCC_AGG_HDR WHERE FILE_NAME = '" + xml_file_name + "'");
                            while (SQLResultset.next()) {
                                String STG_AGG_ACTUAL_HEADER = SQLResultset.getString("STG_AGG_ACTUAL_HEADER");
                                System.out.println("stag Aggregate actual header count ----" + STG_AGG_ACTUAL_HEADER);
                                System.out.println("stag actual header count ----" + db_STG_ACTL_RCDS);
                                System.out.println("stag expected header count ----" + STG_EXP_SUM_HDRS);
                                if (db_STG_REVERSAL_INDICATOR.equals("N") && db_STG_SUMMARY_FLAG.equals("Y")) {
                                    if (STG_EXP_SUM_HDRS.equals(STG_AGG_ACTUAL_HEADER)) {
                                        String pc_stg_header_line = 1 + "," + db_STG_ACTL_RCDS + "," + STG_EXP_SUM_HDRS + "," + STG_AGG_ACTUAL_HEADER + ",Pass";
                                        section3_results.add(pc_stg_header_line);
                                    } else {
                                        String pc_stg_header_line = 1 + "," + db_STG_ACTL_RCDS + "," + STG_EXP_SUM_HDRS + "," + STG_AGG_ACTUAL_HEADER + ",Fail";
                                        section3_results.add(pc_stg_header_line);
                                    }
                                } else if ((db_STG_REVERSAL_INDICATOR.equals("Y")) || (db_STG_SUMMARY_FLAG.equals("N") && db_STG_REVERSAL_INDICATOR.equals("N"))) {
                                    if (db_STG_ACTL_RCDS.equals(STG_AGG_ACTUAL_HEADER)) {
                                        String pc_stg_header_line = 1 + "," + db_STG_ACTL_RCDS + "," + db_STG_ACTL_RCDS + "," + STG_AGG_ACTUAL_HEADER + ",Pass";
                                        section3_results.add(pc_stg_header_line);
                                    } else {
                                        String pc_stg_header_line = 1 + "," + db_STG_ACTL_RCDS + "," + db_STG_ACTL_RCDS + "," + STG_AGG_ACTUAL_HEADER + ",Fail";
                                        section3_results.add(pc_stg_header_line);
                                    }

                                }
                            }
                        }

                    } while (SQLResultset.next());
                }

                //-------------- Validation Cons to Stag table ----------------

                String LandscapeGLBilling_consSqlQuery = connect_db.executeQuery_DB("LandscapeGL", "GLBilling_Cons", "LANDSCAPE");
                SQLResultset = SQLstmt.executeQuery(LandscapeGLBilling_consSqlQuery + "'" + file_name + "'");
                while (SQLResultset.next()) {
                    db_CONS_BC_HEADER_ID = SQLResultset.getString("BC_HEADER_ID");
                    list_header.add(db_CONS_BC_HEADER_ID);
                }

                for (int i = 0; i < list_header.size(); i++) {
                    SQLResultset = SQLstmt.executeQuery(LandscapeGLBilling_consSqlQuery + "'" + file_name + "' and BC_HEADER_ID = '" + list_header.get(i) + "' ");
                    //SQLResultset = SQLstmt.executeQuery("SELECT * from DLG_FSH_CONS_LAND_BC_HDR WHERE FILE_NAME = '" + xml_file_name + "' and BC_HEADER_ID = '" + list_header.get(i) + "' ");
                    while (SQLResultset.next()) {
                        db_CONS_HDR_STATUS = SQLResultset.getString("STATUS");
                        db_CONS_SOURCE = SQLResultset.getString("SOURCE");
                        db_CONS_BC_HEADER_ID = SQLResultset.getString("BC_HEADER_ID");
                        db_CONS_ACCOUNT_NUMBER = SQLResultset.getString("ACCOUNT_NUMBER");
                        db_CONS_POLICY_NUMBER = SQLResultset.getString("POLICY_NUMBER");
                        db_CONS_CLAIM_NUMBER = SQLResultset.getString("CLAIM_NUMBER");
                        db_CONS_UNDERWRITER = SQLResultset.getString("UNDERWRITER");
                        db_CONS_BRAND = SQLResultset.getString("BRAND");
                        db_CONS_LINE_OF_BUSINESS = SQLResultset.getString("LINE_OF_BUSINESS");
                        db_CONS_PRODUCT_TYPE = SQLResultset.getString("PRODUCT_TYPE");
                        db_CONS_TRANSACTION_REFERENCE = SQLResultset.getString("TRANSACTION_REFERENCE");
                        db_CONS_TRANSACTION_DATE = SQLResultset.getString("TRANSACTION_DATE");
                        db_CONS_TRANSACTION_SUBTYPE = SQLResultset.getString("TRANSACTION_SUBTYPE");
                        db_CONS_TRANSACTION_REASON = SQLResultset.getString("TRANSACTION_REASON");
                        db_CONS_BANK_ACC = SQLResultset.getString("BANK_ACC");
                        db_CONS_PAYMENT_METHOD = SQLResultset.getString("PAYMENT_METHOD");
                        db_CONS_SUN_NUMBER = SQLResultset.getString("SUN_NUMBER");
                        db_CONS_MID_NUMBER = SQLResultset.getString("MID_NUMBER");
                        db_CONS_DDI_REFERENCE = SQLResultset.getString("DDI_REFERENCE");
                        db_CONS_PAY_IN_SLIP_NUMBER = SQLResultset.getString("PAY_IN_SLIP_NUMBER");
                        db_CONS_CHEQUE_NUMBER = SQLResultset.getString("CHEQUE_NUMBER");
                        db_CONS_CARD_TYPE = SQLResultset.getString("CARD_TYPE");
                        db_CONS_BACS_NARRATIVE = SQLResultset.getString("BACS_NARRATIVE");
                        db_CONS_CHANNEL = SQLResultset.getString("CHANNEL");
                        db_CONS_INTEREST_AMOUNT = SQLResultset.getString("INTEREST_AMOUNT");
                        db_CONS_INTEREST_CURRENCY_CODE = SQLResultset.getString("INTEREST_CURRENCY_CODE");
                        db_CONS_BASE_INTEREST_AMOUNT = SQLResultset.getString("BASE_INTEREST_AMOUNT");
                        db_CONS_TAX_DEDUCTIBLE = SQLResultset.getString("TAX_DEDUCTIBLE");
                        db_CONS_ORDER_NUMBER = SQLResultset.getString("ORDER_NUMBER");
                        db_CONS_REVERSAL_INDICATOR = SQLResultset.getString("REVERSAL_INDICATOR");
                        db_CONS_CARD_NARRATIVE = SQLResultset.getString("CARD_NARRATIVE");
                        db_CONS_PAYMENT_TRANSACTION_TYPE_ID = SQLResultset.getString("PAYMENT_TRANSACTION_TYPE_ID");
                        db_CONS_CURRENCY_AMOUNT = SQLResultset.getString("CURRENCY_AMOUNT");
                        db_CONS_CURRENCY_CODE = SQLResultset.getString("CURRENCY_CODE");
                        db_CONS_EXCHANGE_RATE = SQLResultset.getString("EXCHANGE_RATE");
                        db_CONS_EXCHANGE_RATE_TYPE = SQLResultset.getString("EXCHANGE_RATE_TYPE");
                        db_CONS_BASE_CURRENCY_AMOUNT = SQLResultset.getString("BASE_CURRENCY_AMOUNT");
                        //db_CONS_LOSS_DATE = SQLResultset.getString("LOSS_DATE");
                        //db_CONS_PRODUCT = SQLResultset.getString("PRODUCT");
                        db_CONS_FSH_ATTRIBUTE_1 = SQLResultset.getString("FSH_ATTRIBUTE_1");
                        db_CONS_FSH_ATTRIBUTE_2 = SQLResultset.getString("FSH_ATTRIBUTE_2");
                        //db_CONS_PERIL_CODE = SQLResultset.getString("PERIL_CODE");
                        load_date = SQLResultset.getString("LOAD_DATE");
                        String db_file_name = SQLResultset.getString("FILE_NAME");

                        //Converting Load date format
                        String load_dateTRIM = load_date.substring(0, 10);
                        load_dateFormat = Date.valueOf(load_dateTRIM);
                        System.out.println(load_dateFormat);


                        //Validating mandatory fields in consolidation table
                        //Source - mandatory validation
                        if ((db_CONS_SOURCE == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_SOURCE = mandatoryCONS_map_row + "," + db_CONS_BC_HEADER_ID + ",SOURCE," + "SOURCE : " + db_CONS_SOURCE + "," + "SOURCE was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_SOURCE);
                            mandatoryCONS_map_row++;
                        } else {
                            String CONS_SOURCE = mandatoryCONS_map_row + "," + db_CONS_BC_HEADER_ID + ",SOURCE," + "SOURCE : " + db_CONS_SOURCE + "," + "SOURCE was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_SOURCE);
                            mandatoryCONS_map_row++;
                        }

                        //ACCOUNT_NUMBER - mandatory validation
                        if ((db_CONS_ACCOUNT_NUMBER == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_ACCOUNT_NUMBER = "," + ",ACCOUNT_NUMBER," + "ACCOUNT_NUMBER : " + db_CONS_ACCOUNT_NUMBER + "," + "ACCOUNT_NUMBER was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_ACCOUNT_NUMBER);
                        } else {
                            String CONS_ACCOUNT_NUMBER = "," + ",ACCOUNT_NUMBER," + "ACCOUNT_NUMBER : " + db_CONS_ACCOUNT_NUMBER + "," + "ACCOUNT_NUMBER was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_ACCOUNT_NUMBER);
                        }

                        /*//POLICY_NUMBER - mandatory validation
                        if ((db_CONS_POLICY_NUMBER == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_POLICY_NUMBER = "," + db_CONS_BC_HEADER_ID + ",POLICY_NUMBER," + "POLICY_NUMBER : " + db_CONS_POLICY_NUMBER + "," + "POLICY_NUMBER was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_POLICY_NUMBER);
                        } else {
                            String CONS_POLICY_NUMBER = "," + db_CONS_BC_HEADER_ID + ",POLICY_NUMBER," + "POLICY_NUMBER : " + db_CONS_POLICY_NUMBER + "," + "POLICY_NUMBER was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_POLICY_NUMBER);
                        }

                        //CLAIM_NUMBER - mandatory validation
                        if ((db_CONS_CLAIM_NUMBER == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_CLAIM_NUMBER = "," + db_CONS_BC_HEADER_ID + ",CLAIM_NUMBER," + "CLAIM_NUMBER : " + db_CONS_CLAIM_NUMBER + "," + "CLAIM_NUMBER was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_CLAIM_NUMBER);
                        } else {
                            String CONS_CLAIM_NUMBER = "," + db_CONS_BC_HEADER_ID + ",POLICY_NUMBER," + "CLAIM_NUMBER : " + db_CONS_CLAIM_NUMBER + "," + "CLAIM_NUMBER was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_CLAIM_NUMBER);
                        }*/

                        //BRAND - mandatory validation
                        if (db_CONS_TRANSACTION_SUBTYPE.equals("Allocation")) {
                            if ((db_CONS_BRAND == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                                String CONS_BRAND = "," + ",BRAND," + "BRAND : " + db_CONS_BRAND + "," + "BRAND was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                                section2_results.add(CONS_BRAND);
                            } else {
                                String CONS_BRAND = "," + ",BRAND," + "BRAND : " + db_CONS_BRAND + "," + "BRAND was found," + db_CONS_HDR_STATUS + "," + "Pass";
                                section2_results.add(CONS_BRAND);
                            }

                        } else if (db_CONS_TRANSACTION_SUBTYPE.equals("Receipt") || db_CONS_TRANSACTION_SUBTYPE.equals("Write Off") || db_CONS_TRANSACTION_SUBTYPE.equals("Compensation") || db_CONS_TRANSACTION_SUBTYPE.equals("Outgoing Payment")) {
                            String CONS_BRAND = "," + ",BRAND," + "BRAND : " + db_CONS_BRAND + "," + "Conditional Mandatory check: Ignore BRAND is a mandatory field," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_BRAND);
                        }


                        //LINE_OF_BUSINESS - mandatory validation
                        if (db_CONS_TRANSACTION_SUBTYPE.equals("Allocation")) {
                            if ((db_CONS_LINE_OF_BUSINESS == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                                String CONS_LINE_OF_BUSINESS = "," + ",LINE_OF_BUSINESS," + "LINE_OF_BUSINESS : " + db_CONS_LINE_OF_BUSINESS + "," + "LINE_OF_BUSINESS was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                                section2_results.add(CONS_LINE_OF_BUSINESS);
                            } else {
                                String CONS_LINE_OF_BUSINESS = "," + ",LINE_OF_BUSINESS," + "LINE_OF_BUSINESS : " + db_CONS_LINE_OF_BUSINESS + "," + "LINE_OF_BUSINESS was found," + db_CONS_HDR_STATUS + "," + "Pass";
                                section2_results.add(CONS_LINE_OF_BUSINESS);
                            }
                        } else if (db_CONS_TRANSACTION_SUBTYPE.equals("Receipt") || db_CONS_TRANSACTION_SUBTYPE.equals("Write Off") || db_CONS_TRANSACTION_SUBTYPE.equals("Compensation") || db_CONS_TRANSACTION_SUBTYPE.equals("Outgoing Payment")) {
                            String CONS_LINE_OF_BUSINESS = "," + ",LINE_OF_BUSINESS," + "LINE_OF_BUSINESS : " + db_CONS_LINE_OF_BUSINESS + "," + "Conditional Mandatory check: Ignore LINE_OF_BUSINESS is a mandatory field," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_LINE_OF_BUSINESS);
                        }

                        //PRODUCT_TYPE - mandatory validation
                        if (db_CONS_TRANSACTION_SUBTYPE.equals("Allocation")) {
                            if ((db_CONS_PRODUCT_TYPE == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                                String CONS_PRODUCT_TYPE = "," + ",PRODUCT_TYPE," + "PRODUCT_TYPE : " + db_CONS_PRODUCT_TYPE + "," + "PRODUCT_TYPE was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                                section2_results.add(CONS_PRODUCT_TYPE);
                            } else {
                                String CONS_PRODUCT_TYPE = "," + ",PRODUCT_TYPE," + "PRODUCT_TYPE : " + db_CONS_PRODUCT_TYPE + "," + "PRODUCT_TYPE was found," + db_CONS_HDR_STATUS + "," + "Pass";
                                section2_results.add(CONS_PRODUCT_TYPE);
                            }
                        } else if (db_CONS_TRANSACTION_SUBTYPE.equals("Receipt") || db_CONS_TRANSACTION_SUBTYPE.equals("Write Off") || db_CONS_TRANSACTION_SUBTYPE.equals("Compensation") || db_CONS_TRANSACTION_SUBTYPE.equals("Outgoing Payment")) {
                            String CONS_PRODUCT_TYPE = "," + ",PRODUCT_TYPE," + "PRODUCT_TYPE : " + db_CONS_PRODUCT_TYPE + "," + "Conditional Mandatory check: Ignore PRODUCT_TYPE is a mandatory field," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_PRODUCT_TYPE);
                        }

                        //TRANSACTION_REFERENCE - mandatory validation
                        if ((db_CONS_TRANSACTION_REFERENCE == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_TRANSACTION_REFERENCE = "," + ",TRANSACTION_REFERENCE," + "TRANSACTION_REFERENCE : " + db_CONS_TRANSACTION_REFERENCE + "," + "TRANSACTION_REFERENCE was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_TRANSACTION_REFERENCE);
                        } else {
                            String CONS_TRANSACTION_REFERENCE = "," + ",TRANSACTION_REFERENCE," + "TRANSACTION_REFERENCE : " + db_CONS_TRANSACTION_REFERENCE + "," + "TRANSACTION_REFERENCE was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_TRANSACTION_REFERENCE);
                        }

                        //TRANSACTION_DATE - mandatory validation
                        if ((db_CONS_TRANSACTION_DATE == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_TRANSACTION_DATE = "," + ",TRANSACTION_DATE," + "TRANSACTION_DATE : " + db_CONS_TRANSACTION_DATE + "," + "TRANSACTION_DATE was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_TRANSACTION_DATE);
                        } else {
                            String CONS_TRANSACTION_DATE = "," + ",TRANSACTION_DATE," + "TRANSACTION_DATE : " + db_CONS_TRANSACTION_DATE + "," + "TRANSACTION_DATE was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_TRANSACTION_DATE);
                        }

                        //TRANSACTION_SUBTYPE - mandatory validation
                        if ((db_CONS_TRANSACTION_SUBTYPE == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_TRANSACTION_SUBTYPE = "," + ",TRANSACTION_SUBTYPE," + "TRANSACTION_SUBTYPE : " + db_CONS_TRANSACTION_SUBTYPE + "," + "TRANSACTION_SUBTYPE was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_TRANSACTION_SUBTYPE);
                        } else {
                            String CONS_TRANSACTION_SUBTYPE = "," + ",TRANSACTION_SUBTYPE," + "TRANSACTION_SUBTYPE : " + db_CONS_TRANSACTION_SUBTYPE + "," + "TRANSACTION_SUBTYPE was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_TRANSACTION_SUBTYPE);
                        }

                        //BANK_ACC - mandatory validation
                        if (db_CONS_TRANSACTION_SUBTYPE.equals("Allocation") || db_CONS_TRANSACTION_SUBTYPE.equals("Compensation")) {
                            if ((db_CONS_BANK_ACC == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                                String CONS_BANK_ACC = "," + ",BANK_ACC," + "BANK_ACC : " + db_CONS_BANK_ACC + "," + "BANK_ACC was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                                section2_results.add(CONS_BANK_ACC);
                            } else {
                                String CONS_BANK_ACC = "," + ",BANK_ACC," + "BANK_ACC : " + db_CONS_BANK_ACC + "," + "BANK_ACC was found," + db_CONS_HDR_STATUS + "," + "Pass";
                                section2_results.add(CONS_BANK_ACC);
                            }
                        } else if (db_CONS_TRANSACTION_SUBTYPE.equals("Receipt") || db_CONS_TRANSACTION_SUBTYPE.equals("Write Off") || db_CONS_TRANSACTION_SUBTYPE.equals("Compensation") || db_CONS_TRANSACTION_SUBTYPE.equals("Outgoing Payment")) {
                            String CONS_BANK_ACC = "," + ",BANK_ACC," + "BANK_ACC : " + db_CONS_BANK_ACC + "," + "Conditional Mandatory check: Ignore BANK_ACC is a mandatory field," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_BANK_ACC);
                        }

                        //PAYMENT_METHOD - mandatory validation
                        if ((db_CONS_PAYMENT_METHOD == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_PAYMENT_METHOD = "," + ",PAYMENT_METHOD," + "PAYMENT_METHOD : " + db_CONS_PAYMENT_METHOD + "," + "PAYMENT_METHOD was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_PAYMENT_METHOD);
                        } else {
                            String CONS_PAYMENT_METHOD = "," + ",PAYMENT_METHOD," + "PAYMENT_METHOD : " + db_CONS_PAYMENT_METHOD + "," + "PAYMENT_METHOD was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_PAYMENT_METHOD);
                        }


                        //CHANNEL - mandatory validation
                        if (db_CONS_TRANSACTION_SUBTYPE.equals("Allocation")) {
                            if ((db_CONS_CHANNEL == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                                String CONS_CHANNEL = "," + ",CHANNEL," + "CHANNEL : " + db_CONS_CHANNEL + "," + "CHANNEL was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                                section2_results.add(CONS_CHANNEL);
                            } else {
                                String CONS_CHANNEL = "," + ",CHANNEL," + "CHANNEL : " + db_CONS_CHANNEL + "," + "CHANNEL was found," + db_CONS_HDR_STATUS + "," + "Pass";
                                section2_results.add(CONS_CHANNEL);
                            }
                        } else if (db_CONS_TRANSACTION_SUBTYPE.equals("Receipt") || db_CONS_TRANSACTION_SUBTYPE.equals("Write Off") || db_CONS_TRANSACTION_SUBTYPE.equals("Compensation") || db_CONS_TRANSACTION_SUBTYPE.equals("Outgoing Payment")) {
                            String CONS_CHANNEL = "," + ",CHANNEL," + "CHANNEL : " + db_CONS_BANK_ACC + "," + "Conditional Mandatory check: Ignore CHANNEL is a mandatory field," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_CHANNEL);
                        }

                        //INTEREST_AMOUNT - mandatory validation
                        if ((db_CONS_INTEREST_AMOUNT == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_INTEREST_AMOUNT = "," + ",INTEREST_AMOUNT," + "INTEREST_AMOUNT : " + db_CONS_INTEREST_AMOUNT + "," + "INTEREST_AMOUNT was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_INTEREST_AMOUNT);
                        } else {
                            String CONS_INTEREST_AMOUNT = "," + ",INTEREST_AMOUNT," + "INTEREST_AMOUNT : " + db_CONS_INTEREST_AMOUNT + "," + "INTEREST_AMOUNT was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_INTEREST_AMOUNT);
                        }

                        //INTEREST_CURRENCY_CODE - mandatory validation
                        if ((db_CONS_INTEREST_CURRENCY_CODE == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_INTEREST_CURRENCY_CODE = "," + ",INTEREST_CURRENCY_CODE," + "INTEREST_CURRENCY_CODE : " + db_CONS_INTEREST_CURRENCY_CODE + "," + "INTEREST_CURRENCY_CODE was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_INTEREST_CURRENCY_CODE);
                        } else {
                            String CONS_INTEREST_CURRENCY_CODE = "," + ",INTEREST_CURRENCY_CODE," + "INTEREST_CURRENCY_CODE : " + db_CONS_INTEREST_CURRENCY_CODE + "," + "INTEREST_CURRENCY_CODE was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_INTEREST_CURRENCY_CODE);
                        }

                        //BASE_INTEREST_AMOUNT - mandatory validation
                        if ((db_CONS_BASE_INTEREST_AMOUNT == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_BASE_INTEREST_AMOUNT = "," + ",BASE_INTEREST_AMOUNT," + "BASE_INTEREST_AMOUNT : " + db_CONS_BASE_INTEREST_AMOUNT + "," + "BASE_INTEREST_AMOUNT was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_BASE_INTEREST_AMOUNT);
                        } else {
                            String CONS_BASE_INTEREST_AMOUNT = "," + ",BASE_INTEREST_AMOUNT," + "BASE_INTEREST_AMOUNT : " + db_CONS_BASE_INTEREST_AMOUNT + "," + "BASE_INTEREST_AMOUNT was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_BASE_INTEREST_AMOUNT);
                        }

                        //TAX_DEDUCTIBLE - mandatory validation
                        if ((db_CONS_TAX_DEDUCTIBLE == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_TAX_DEDUCTIBLE = "," + ",TAX_DEDUCTIBLE," + "TAX_DEDUCTIBLE : " + db_CONS_TAX_DEDUCTIBLE + "," + "TAX_DEDUCTIBLE was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_TAX_DEDUCTIBLE);
                        } else {
                            String CONS_TAX_DEDUCTIBLE = "," + ",TAX_DEDUCTIBLE," + "TAX_DEDUCTIBLE : " + db_CONS_TAX_DEDUCTIBLE + "," + "TAX_DEDUCTIBLE was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_TAX_DEDUCTIBLE);
                        }

                        //REVERSAL_INDICATOR - mandatory validation
                        if ((db_CONS_REVERSAL_INDICATOR == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_REVERSAL_INDICATOR = "," + ",REVERSAL_INDICATOR," + "REVERSAL_INDICATOR : " + db_CONS_REVERSAL_INDICATOR + "," + "REVERSAL_INDICATOR was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_REVERSAL_INDICATOR);
                        } else {
                            String CONS_REVERSAL_INDICATOR = "," + ",REVERSAL_INDICATOR," + "REVERSAL_INDICATOR : " + db_CONS_REVERSAL_INDICATOR + "," + "REVERSAL_INDICATOR was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_REVERSAL_INDICATOR);
                        }

                        //PAYMENT_TRANSACTION_TYPE_ID - mandatory validation
                        if ((db_CONS_PAYMENT_TRANSACTION_TYPE_ID == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_PAYMENT_TRANSACTION_TYPE_ID = "," + ",PAYMENT_TRANSACTION_TYPE_ID," + "PAYMENT_TRANSACTION_TYPE_ID : " + db_CONS_PAYMENT_TRANSACTION_TYPE_ID + "," + "PAYMENT_TRANSACTION_TYPE_ID was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_PAYMENT_TRANSACTION_TYPE_ID);
                        } else {
                            String CONS_PAYMENT_TRANSACTION_TYPE_ID = "," + ",PAYMENT_TRANSACTION_TYPE_ID," + "PAYMENT_TRANSACTION_TYPE_ID : " + db_CONS_PAYMENT_TRANSACTION_TYPE_ID + "," + "PAYMENT_TRANSACTION_TYPE_ID was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_PAYMENT_TRANSACTION_TYPE_ID);
                        }

                        //CURRENCY_AMOUNT - mandatory validation
                        if ((db_CONS_CURRENCY_AMOUNT == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_CURRENCY_AMOUNT = "," + ",CURRENCY_AMOUNT," + "CURRENCY_AMOUNT : " + db_CONS_CURRENCY_AMOUNT + "," + "CURRENCY_AMOUNT was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_CURRENCY_AMOUNT);
                        } else {
                            String CONS_CURRENCY_AMOUNT = "," + ",CURRENCY_AMOUNT," + "CURRENCY_AMOUNT : " + db_CONS_CURRENCY_AMOUNT + "," + "CURRENCY_AMOUNT was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_CURRENCY_AMOUNT);
                        }

                        //CURRENCY_CODE - mandatory validation
                        if ((db_CONS_CURRENCY_CODE == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_CURRENCY_CODE = "," + ",CURRENCY_CODE," + "CURRENCY_CODE : " + db_CONS_CURRENCY_CODE + "," + "CURRENCY_CODE was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_CURRENCY_CODE);
                        } else {
                            String CONS_CURRENCY_CODE = "," + ",CURRENCY_CODE," + "CURRENCY_CODE : " + db_CONS_CURRENCY_CODE + "," + "CURRENCY_CODE was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_CURRENCY_CODE);
                        }

                        //EXCHANGE_RATE - mandatory validation
                        if ((db_CONS_EXCHANGE_RATE == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_EXCHANGE_RATE = "," + ",EXCHANGE_RATE," + "EXCHANGE_RATE : " + db_CONS_EXCHANGE_RATE + "," + "EXCHANGE_RATE was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_EXCHANGE_RATE);
                        } else {
                            String CONS_EXCHANGE_RATE = "," + ",EXCHANGE_RATE," + "EXCHANGE_RATE : " + db_CONS_EXCHANGE_RATE + "," + "EXCHANGE_RATE was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_EXCHANGE_RATE);
                        }

                        //EXCHANGE_RATE_TYPE - mandatory validation
                        if ((db_CONS_EXCHANGE_RATE_TYPE == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_EXCHANGE_RATE_TYPE = "," + ",EXCHANGE_RATE_TYPE," + "EXCHANGE_RATE_TYPE : " + db_CONS_EXCHANGE_RATE_TYPE + "," + "EXCHANGE_RATE_TYPE was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_EXCHANGE_RATE_TYPE);
                        } else {
                            String CONS_EXCHANGE_RATE_TYPE = "," + ",EXCHANGE_RATE_TYPE," + "EXCHANGE_RATE_TYPE : " + db_CONS_EXCHANGE_RATE_TYPE + "," + "EXCHANGE_RATE_TYPE was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_EXCHANGE_RATE_TYPE);
                        }
                        //BASE_CURRENCY_AMOUNT - mandatory validation
                        if ((db_CONS_BASE_CURRENCY_AMOUNT == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_BASE_CURRENCY_AMOUNT = "," + ",BASE_CURRENCY_AMOUNT," + "BASE_CURRENCY_AMOUNT : " + db_CONS_BASE_CURRENCY_AMOUNT + "," + "BASE_CURRENCY_AMOUNT was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_BASE_CURRENCY_AMOUNT);
                        } else {
                            String CONS_BASE_CURRENCY_AMOUNT = "," + ",BASE_CURRENCY_AMOUNT," + "BASE_CURRENCY_AMOUNT : " + db_CONS_BASE_CURRENCY_AMOUNT + "," + "BASE_CURRENCY_AMOUNT was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_BASE_CURRENCY_AMOUNT);
                        }

                        //FSH_ATTRIBUTE_1 - mandatory validation
                        if ((db_CONS_FSH_ATTRIBUTE_1 == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_GL_STRING = "," + ",FSH_ATTRIBUTE_1," + "FSH_ATTRIBUTE_1 : " + db_CONS_FSH_ATTRIBUTE_1 + "," + "FSH_ATTRIBUTE_1 was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_GL_STRING);
                        } else {
                            String CONS_GL_STRING = "," + ",FSH_ATTRIBUTE_1," + "FSH_ATTRIBUTE_1 : " + db_CONS_FSH_ATTRIBUTE_1 + "," + "FSH_ATTRIBUTE_1 was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_GL_STRING);
                        }


                        //FSH_ATTRIBUTE_2 - mandatory validation
                        if (db_CONS_TRANSACTION_SUBTYPE.equals("Allocation") || db_CONS_TRANSACTION_SUBTYPE.equals("Write Off")) {
                            if ((db_CONS_FSH_ATTRIBUTE_2 == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                                String CONS_FSH_ATTRIBUTE_2 = "," + ",FSH_ATTRIBUTE_2," + "FSH_ATTRIBUTE_2 : " + db_CONS_FSH_ATTRIBUTE_2 + "," + "FSH_ATTRIBUTE_2 was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                                section2_results.add(CONS_FSH_ATTRIBUTE_2);
                            } else {
                                String CONS_FSH_ATTRIBUTE_2 = "," + ",FSH_ATTRIBUTE_2," + "FSH_ATTRIBUTE_2 : " + db_CONS_FSH_ATTRIBUTE_2 + "," + "FSH_ATTRIBUTE_2 was found," + db_CONS_HDR_STATUS + "," + "Pass";
                                section2_results.add(CONS_FSH_ATTRIBUTE_2);
                            }
                        } else if (db_CONS_TRANSACTION_SUBTYPE.equals("Receipt") || db_CONS_TRANSACTION_SUBTYPE.equals("Compensation") || db_CONS_TRANSACTION_SUBTYPE.equals("Outgoing Payment")) {
                            String CONS_CHANNEL = "," + ",CHANNEL," + "CHANNEL : " + db_CONS_BANK_ACC + "," + "Conditional Mandatory check: Ignore CHANNEL is a mandatory field," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_CHANNEL);
                        }

                        //------------------- Consolidation to Staging ----------------------------------
                        String LandscapeGLBilling_stgSqlQuery = connect_db.executeQuery_DB("LandscapeGL", "GLBilling_Stg", "LANDSCAPE");

                        SQLResultset = SQLstmt.executeQuery(LandscapeGLBilling_stgSqlQuery + "'" + file_name + "' and HEADER_ID = '" + list_header.get(i) + "' ");
                        if (!SQLResultset.next()) {
                            String stg_header_id = section2_map_row + ",HEADER_ID," + "no records available in STG table" + "," + db_CONS_BC_HEADER_ID + ",Fail";
                            section2_results.add(stg_header_id);
                        } else {
                            SQLResultset = SQLstmt.executeQuery(LandscapeGLBilling_stgSqlQuery + "'" + file_name + "' and HEADER_ID = '" + list_header.get(i) + "' ");
                            while (SQLResultset.next()) {

                                db_STG_HDR_STATUS = SQLResultset.getString("STATUS");
                                db_STG_HEADER_ID = SQLResultset.getString("HEADER_ID");
                                db_STG_SOURCE = SQLResultset.getString("SOURCE");
                                db_STG_ACCOUNT_NUMBER = SQLResultset.getString("ACCOUNT_NUMBER");
                                db_STG_POLICY_NUMBER = SQLResultset.getString("POLICY_NUMBER");
                                db_STG_CLAIM_NUMBER = SQLResultset.getString("CLAIM_NUMBER");
                                db_STG_UNDERWRITER = SQLResultset.getString("UNDERWRITER");
                                db_STG_BRAND = SQLResultset.getString("BRAND");
                                db_STG_LINE_OF_BUSINESS = SQLResultset.getString("LINE_OF_BUSINESS");
                                db_STG_PRODUCT_TYPE = SQLResultset.getString("PRODUCT_TYPE");
                                db_STG_TRANSACTION_REFERENCE = SQLResultset.getString("TRANSACTION_REFERENCE");
                                db_STG_TRANSACTION_DATE = SQLResultset.getString("TRANSACTION_DATE");
                                db_STG_TRANSACTION_SUBTYPE = SQLResultset.getString("TRANSACTION_SUB_TYPE");
                                db_STG_TRANSACTION_REASON = SQLResultset.getString("TRANSACTION_REASON");
                                db_STG_BANK_ACC = SQLResultset.getString("BANK_ACC");
                                db_STG_PAYMENT_METHOD = SQLResultset.getString("PAYMENT_METHOD");
                                db_STG_SUN_NUMBER = SQLResultset.getString("SUN_NUMBER");
                                db_STG_MID_NUMBER = SQLResultset.getString("MID_NUMBER");
                                db_STG_DDI_REFERENCE = SQLResultset.getString("DDI_REFERENCE");
                                db_STG_PAY_IN_SLIP_NUMBER = SQLResultset.getString("PAY_IN_SLIP_NUMBER");
                                db_STG_CHEQUE_NUMBER = SQLResultset.getString("CHEQUE_NUMBER");
                                db_STG_CARD_TYPE = SQLResultset.getString("CARD_TYPE");
                                db_STG_BACS_NARRATIVE = SQLResultset.getString("BACS_NARRATIVE");
                                db_STG_CHANNEL = SQLResultset.getString("CHANNEL");
                                db_STG_INTEREST_AMOUNT = SQLResultset.getString("INTEREST_AMOUNT");
                                db_STG_INTEREST_CURRENCY_CODE = SQLResultset.getString("INTEREST_CURRENCY_CODE");
                                db_STG_BASE_INTEREST_AMOUNT = SQLResultset.getString("BASE_INTEREST_AMOUNT");
                                db_STG_TAX_DEDUCTIBLE = SQLResultset.getString("TAX_DEDUCTIBLE");
                                db_STG_ORDER_NUMBER = SQLResultset.getString("ORDER_NUMBER");
                                db_STG_REVERSAL_INDICATOR = SQLResultset.getString("REVERSAL_INDICATOR");
                                db_STG_CARD_NARRATIVE = SQLResultset.getString("CARD_NARRATIVE");
                                db_STG_PAYMENT_TRANSACTION_TYPE_ID = SQLResultset.getString("PAYMENT_TRANSACTION_TYPE_ID");
                                db_STG_CURRENCY_AMOUNT = SQLResultset.getString("CURRENCY_AMOUNT");
                                db_STG_CURRENCY_CODE = SQLResultset.getString("CURRENCY_CODE");
                                db_STG_EXCHANGE_RATE = SQLResultset.getString("EXCHANGE_RATE");
                                db_STG_EXCHANGE_RATE_TYPE = SQLResultset.getString("EXCHANGE_RATE_TYPE");
                                db_STG_BASE_CURRENCY_AMOUNT = SQLResultset.getString("BASE_CURRENCY_AMOUNT");
                                db_STG_LOSS_DATE = SQLResultset.getString("LOSS_DATE");
                                db_STG_PRODUCT = SQLResultset.getString("PRODUCT");
                                db_STG_FSH_ATTRIBUTE_01 = SQLResultset.getString("FSH_ATTRIBUTE_01");
                                db_STG_PRODUCT_KEY = SQLResultset.getString("PRODUCT_KEY");
                                db_STG_PERIL_CODE = SQLResultset.getString("PERIL_CODE");
                                db_STG_TOH_ID = SQLResultset.getString("TOH_ID");
                                db_STG_EVENT_CODE = SQLResultset.getString("EVENT_CODE");
                                db_STG_ENTITY_TYPE_CODE = SQLResultset.getString("ENTITY_TYPE_CODE");
                                db_STG_BC_SUMMARY_ID = SQLResultset.getString("BC_SUMMARY_ID");
                                db_STG_SUMMARY_FLAG = SQLResultset.getString("SUMMARY_FLAG");
                                db_STG_CREDIT_IND = SQLResultset.getString("CREDIT_IND");
                                STG_HDR_STATUS = SQLResultset.getString("STATUS");


                                //Staging mandatory validations
                                //HEADER_ID - mandatory validation
                                if ((db_STG_HEADER_ID == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = stg_line_map_row + "," + db_STG_HEADER_ID + ",HEADER_ID," + "HEADER_ID : " + db_STG_HEADER_ID + "," + "HEADER_ID was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                    stg_line_map_row++;
                                } else {
                                    String stg_header_id = stg_line_map_row + "," + db_STG_HEADER_ID + ",HEADER_ID," + "HEADER_ID : " + db_STG_HEADER_ID + "," + "HEADER_ID was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                    stg_line_map_row++;
                                }

                                //SOURCE - mandatory validation
                                if ((db_STG_SOURCE == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",SOURCE," + "SOURCE : " + db_STG_SOURCE + "," + "SOURCE was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",SOURCE," + "SOURCE : " + db_STG_SOURCE + "," + "SOURCE was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //ACCOUNT_NUMBER - mandatory validation
                                if ((db_STG_ACCOUNT_NUMBER == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",ACCOUNT_NUMBER," + "ACCOUNT_NUMBER : " + db_STG_ACCOUNT_NUMBER + "," + "ACCOUNT_NUMBER was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",ACCOUNT_NUMBER," + "ACCOUNT_NUMBER : " + db_STG_ACCOUNT_NUMBER + "," + "ACCOUNT_NUMBER was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //POLICY_NUMBER - mandatory validation
                                if ((db_STG_POLICY_NUMBER == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",POLICY_NUMBER," + "POLICY_NUMBER : " + db_STG_POLICY_NUMBER + "," + "POLICY_NUMBER was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",POLICY_NUMBER," + "POLICY_NUMBER : " + db_STG_POLICY_NUMBER + "," + "POLICY_NUMBER was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //UNDERWRITER - mandatory validation
                                if ((db_STG_UNDERWRITER == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",UNDERWRITER," + "UNDERWRITER : " + db_STG_UNDERWRITER + "," + "UNDERWRITER was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",UNDERWRITER," + "UNDERWRITER : " + db_STG_UNDERWRITER + "," + "UNDERWRITER was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //PRODUCT_TYPE - mandatory validation
                                if ((db_STG_PRODUCT_TYPE == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",PRODUCT_TYPE," + "PRODUCT_TYPE : " + db_STG_PRODUCT_TYPE + "," + "PRODUCT_TYPE was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",PRODUCT_TYPE," + "PRODUCT_TYPE : " + db_STG_PRODUCT_TYPE + "," + "PRODUCT_TYPE was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //LINE_OF_BUSINESS - mandatory validation
                                if ((db_STG_LINE_OF_BUSINESS == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",LINE_OF_BUSINESS," + "LINE_OF_BUSINESS : " + db_STG_LINE_OF_BUSINESS + "," + "LINE_OF_BUSINESS was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",LINE_OF_BUSINESS," + "LINE_OF_BUSINESS : " + db_STG_LINE_OF_BUSINESS + "," + "LINE_OF_BUSINESS was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //TRANSACTION_REFERENCE - mandatory validation
                                if ((db_STG_TRANSACTION_REFERENCE == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",TRANSACTION_REFERENCE," + "TRANSACTION_REFERENCE : " + db_STG_TRANSACTION_REFERENCE + "," + "TRANSACTION_REFERENCE was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",TRANSACTION_REFERENCE," + "TRANSACTION_REFERENCE : " + db_STG_TRANSACTION_REFERENCE + "," + "TRANSACTION_REFERENCE was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //TRANSACTION_DATE - mandatory validation
                                if ((db_STG_TRANSACTION_DATE == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",TRANSACTION_DATE," + "TRANSACTION_DATE : " + db_STG_TRANSACTION_DATE + "," + "TRANSACTION_DATE was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",TRANSACTION_DATE," + "TRANSACTION_DATE : " + db_STG_TRANSACTION_DATE + "," + "TRANSACTION_DATE was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //TRANSACTION_SUB_TYPE - mandatory validation
                                if ((db_STG_TRANSACTION_SUBTYPE == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",TRANSACTION_SUB_TYPE," + "TRANSACTION_SUB_TYPE : " + db_STG_TRANSACTION_SUBTYPE + "," + "TRANSACTION_SUB_TYPE was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",TRANSACTION_SUB_TYPE," + "TRANSACTION_SUB_TYPE : " + db_STG_TRANSACTION_SUBTYPE + "," + "TRANSACTION_SUB_TYPE was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //TRANSACTION_REASON - mandatory validation
                                if ((db_STG_TRANSACTION_REASON == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",TRANSACTION_REASON," + "TRANSACTION_REASON : " + db_STG_TRANSACTION_REASON + "," + "TRANSACTION_REASON was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",TRANSACTION_REASON," + "TRANSACTION_REASON : " + db_STG_TRANSACTION_REASON + "," + "TRANSACTION_REASON was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //PAYMENT_METHOD - mandatory validation
                                if ((db_STG_PAYMENT_METHOD == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",PAYMENT_METHOD," + "PAYMENT_METHOD : " + db_STG_PAYMENT_METHOD + "," + "PAYMENT_METHOD was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",PAYMENT_METHOD," + "PAYMENT_METHOD : " + db_STG_PAYMENT_METHOD + "," + "PAYMENT_METHOD was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //SUN_NUMBER - mandatory validation
                                if (db_STG_PAYMENT_METHOD.contains("bacs")) {
                                    if ((db_STG_SUN_NUMBER == null) && (STG_HDR_STATUS != "REVIEW")) {

                                        String stg_header_id = "," + ",SUN_NUMBER," + "SUN_NUMBER : " + db_STG_SUN_NUMBER + "," + "SUN_NUMBER was not found," + STG_HDR_STATUS + "," + "Fail";
                                        section4_results.add(stg_header_id);
                                    } else {
                                        String stg_header_id = "," + ",SUN_NUMBER," + "SUN_NUMBER : " + db_STG_SUN_NUMBER + "," + "SUN_NUMBER was found," + STG_HDR_STATUS + "," + "Pass";
                                        section4_results.add(stg_header_id);
                                    }
                                } else {
                                    String stg_header_id = "," + ",SUN_NUMBER," + "SUN_NUMBER : " + db_STG_SUN_NUMBER + "," + "SUN_NUMBER is not a mandatory," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //MID_NUMBER - mandatory validation
                                if (db_STG_PAYMENT_METHOD.contains("card")) {
                                    if ((db_STG_MID_NUMBER == null) && (STG_HDR_STATUS != "REVIEW")) {

                                        String stg_header_id = "," + ",MID_NUMBER," + "MID_NUMBER : " + db_STG_MID_NUMBER + "," + "MID_NUMBER was not found," + STG_HDR_STATUS + "," + "Fail";
                                        section4_results.add(stg_header_id);
                                    } else {
                                        String stg_header_id = "," + ",MID_NUMBER," + "MID_NUMBER : " + db_STG_MID_NUMBER + "," + "MID_NUMBER was found," + STG_HDR_STATUS + "," + "Pass";
                                        section4_results.add(stg_header_id);
                                    }
                                } else {
                                    String stg_header_id = "," + ",MID_NUMBER," + "MID_NUMBER : " + db_STG_MID_NUMBER + "," + "MID_NUMBER is not a mandatory," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }
                                //DDI_REFERENCE - mandatory validation
                                if (db_STG_PAYMENT_METHOD.contains("bacs")) {
                                    if ((db_STG_DDI_REFERENCE == null) && (STG_HDR_STATUS != "REVIEW")) {

                                        String stg_header_id = "," + ",DDI_REFERENCE," + "DDI_REFERENCE : " + db_STG_DDI_REFERENCE + "," + "DDI_REFERENCE was not found," + STG_HDR_STATUS + "," + "Fail";
                                        section4_results.add(stg_header_id);
                                    } else {
                                        String stg_header_id = "," + ",DDI_REFERENCE," + "DDI_REFERENCE : " + db_STG_DDI_REFERENCE + "," + "DDI_REFERENCE was found," + STG_HDR_STATUS + "," + "Pass";
                                        section4_results.add(stg_header_id);
                                    }
                                } else {
                                    String stg_header_id = "," + ",DDI_REFERENCE," + "DDI_REFERENCE : " + db_STG_DDI_REFERENCE + "," + "DDI_REFERENCE is not a mandatory," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //CARD_TYPE - mandatory validation
                                if (db_STG_PAYMENT_METHOD.contains("card")) {
                                    if ((db_STG_CARD_TYPE == null) && (STG_HDR_STATUS != "REVIEW")) {

                                        String stg_header_id = "," + ",CARD_TYPE," + "CARD_TYPE : " + db_STG_CARD_TYPE + "," + "CARD_TYPE was not found," + STG_HDR_STATUS + "," + "Fail";
                                        section4_results.add(stg_header_id);
                                    } else {
                                        String stg_header_id = "," + ",CARD_TYPE," + "CARD_TYPE : " + db_STG_CARD_TYPE + "," + "CARD_TYPE was found," + STG_HDR_STATUS + "," + "Pass";
                                        section4_results.add(stg_header_id);
                                    }
                                } else {
                                    String stg_header_id = "," + ",CARD_TYPE," + "CARD_TYPE : " + db_STG_CARD_TYPE + "," + "CARD_TYPE is not a mandatory," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //BACS_NARRATIVE - mandatory validation
                                if (db_STG_PAYMENT_METHOD.contains("bacs")) {
                                    if ((db_STG_BACS_NARRATIVE == null) && (STG_HDR_STATUS != "REVIEW")) {

                                        String stg_header_id = "," + ",BACS_NARRATIVE," + "BACS_NARRATIVE : " + db_STG_BACS_NARRATIVE + "," + "BACS_NARRATIVE was not found," + STG_HDR_STATUS + "," + "Fail";
                                        section4_results.add(stg_header_id);
                                    } else {
                                        String stg_header_id = "," + ",BACS_NARRATIVE," + "BACS_NARRATIVE : " + db_STG_BACS_NARRATIVE + "," + "BACS_NARRATIVE was found," + STG_HDR_STATUS + "," + "Pass";
                                        section4_results.add(stg_header_id);
                                    }
                                } else {
                                    String stg_header_id = "," + ",BACS_NARRATIVE," + "BACS_NARRATIVE : " + db_STG_BACS_NARRATIVE + "," + "BACS_NARRATIVE is not a mandatory," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //ORDER_NUMBER - mandatory validation
                                if (db_STG_PAYMENT_METHOD.contains("card")) {
                                    if ((db_STG_ORDER_NUMBER == null) && (STG_HDR_STATUS != "REVIEW")) {

                                        String stg_header_id = "," + ",ORDER_NUMBER," + "ORDER_NUMBER : " + db_STG_ORDER_NUMBER + "," + "ORDER_NUMBER was not found," + STG_HDR_STATUS + "," + "Fail";
                                        section4_results.add(stg_header_id);
                                    } else {
                                        String stg_header_id = "," + ",ORDER_NUMBER," + "ORDER_NUMBER : " + db_STG_ORDER_NUMBER + "," + "ORDER_NUMBER was found," + STG_HDR_STATUS + "," + "Pass";
                                        section4_results.add(stg_header_id);
                                    }
                                } else {
                                    String stg_header_id = "," + ",ORDER_NUMBER," + "ORDER_NUMBER : " + db_STG_ORDER_NUMBER + "," + "ORDER_NUMBER is not a mandatory," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //CHANNEL - mandatory validation
                                if ((db_STG_CHANNEL == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",CHANNEL," + "CHANNEL : " + db_STG_CHANNEL + "," + "CHANNEL was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",CHANNEL," + "CHANNEL : " + db_STG_CHANNEL + "," + "CHANNEL was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //REVERSAL_INDICATOR - mandatory validation
                                if ((db_STG_REVERSAL_INDICATOR == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",REVERSAL_INDICATOR," + "REVERSAL_INDICATOR : " + db_STG_REVERSAL_INDICATOR + "," + "REVERSAL_INDICATOR was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",REVERSAL_INDICATOR," + "REVERSAL_INDICATOR : " + db_STG_REVERSAL_INDICATOR + "," + "REVERSAL_INDICATOR was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }


                                //CURRENCY_CODE - mandatory validation
                                if ((db_STG_CURRENCY_CODE == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",CURRENCY_CODE," + "CURRENCY_CODE : " + db_STG_CURRENCY_CODE + "," + "CURRENCY_CODE was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",CURRENCY_CODE," + "CURRENCY_CODE : " + db_STG_CURRENCY_CODE + "," + "CURRENCY_CODE was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //EXCHANGE_RATE - mandatory validation
                                if ((db_STG_EXCHANGE_RATE == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",EXCHANGE_RATE," + "EXCHANGE_RATE : " + db_STG_EXCHANGE_RATE + "," + "EXCHANGE_RATE was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",EXCHANGE_RATE," + "EXCHANGE_RATE : " + db_STG_EXCHANGE_RATE + "," + "EXCHANGE_RATE was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //EXCHANGE_RATE_TYPE - mandatory validation
                                if ((db_STG_EXCHANGE_RATE_TYPE == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",EXCHANGE_RATE_TYPE," + "EXCHANGE_RATE_TYPE : " + db_STG_EXCHANGE_RATE_TYPE + "," + "EXCHANGE_RATE_TYPE was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",EXCHANGE_RATE_TYPE," + "EXCHANGE_RATE_TYPE : " + db_STG_EXCHANGE_RATE_TYPE + "," + "EXCHANGE_RATE_TYPE was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //BASE_CURRENCY_AMOUNT - mandatory validation
                                if ((db_STG_BASE_CURRENCY_AMOUNT == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",BASE_CURRENCY_AMOUNT," + "BASE_CURRENCY_AMOUNT : " + db_STG_BASE_CURRENCY_AMOUNT + "," + "BASE_CURRENCY_AMOUNT was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",BASE_CURRENCY_AMOUNT," + "BASE_CURRENCY_AMOUNT : " + db_STG_BASE_CURRENCY_AMOUNT + "," + "BASE_CURRENCY_AMOUNT was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //CREDIT_IND - mandatory validation
                                if ((db_STG_CREDIT_IND == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",CREDIT_IND," + "CREDIT_IND : " + db_STG_CREDIT_IND + "," + "CREDIT_IND was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",CREDIT_IND," + "CREDIT_IND : " + db_STG_CREDIT_IND + "," + "CREDIT_IND was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //CURRENCY_AMOUNT - mandatory validation
                                if ((db_STG_CURRENCY_AMOUNT == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",CURRENCY_AMOUNT," + "CURRENCY_AMOUNT : " + db_STG_CURRENCY_AMOUNT + "," + "CURRENCY_AMOUNT was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",CURRENCY_AMOUNT," + "CURRENCY_AMOUNT : " + db_STG_CURRENCY_AMOUNT + "," + "CURRENCY_AMOUNT was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //ENTITY_TYPE_CODE - mandatory validation
                                if ((db_STG_ENTITY_TYPE_CODE == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",ENTITY_TYPE_CODE," + "ENTITY_TYPE_CODE : " + db_STG_ENTITY_TYPE_CODE + "," + "ENTITY_TYPE_CODE was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",ENTITY_TYPE_CODE," + "ENTITY_TYPE_CODE : " + db_STG_ENTITY_TYPE_CODE + "," + "ENTITY_TYPE_CODE was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //EVENT_CODE - mandatory validation
                                if ((db_STG_EVENT_CODE == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",EVENT_CODE," + "EVENT_CODE : " + db_STG_EVENT_CODE + "," + "EVENT_CODE was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",EVENT_CODE," + "EVENT_CODE : " + db_STG_EVENT_CODE + "," + "EVENT_CODE was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //BRAND - mandatory validation
                                if ((db_STG_BRAND == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",BRAND," + "BRAND : " + db_STG_BRAND + "," + "BRAND was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",BRAND," + "BRAND : " + db_STG_BRAND + "," + "BRAND was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //SUMMARY_FLAG - mandatory validation
                                if ((db_STG_SUMMARY_FLAG == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",SUMMARY_FLAG," + "SUMMARY_FLAG : " + db_STG_SUMMARY_FLAG + "," + "SUMMARY_FLAG was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",SUMMARY_FLAG," + "SUMMARY_FLAG : " + db_STG_SUMMARY_FLAG + "," + "SUMMARY_FLAG was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }


                                //Comparing Consolidation table and Staging table
                                if (db_CONS_BC_HEADER_ID != null && db_STG_HEADER_ID != null) {
                                    if (db_CONS_BC_HEADER_ID.equals(db_STG_HEADER_ID)) {
                                        String STG_HEADER_ID = cons_stg_map_row + ",HEADER_ID," + db_STG_HEADER_ID + "," + db_CONS_BC_HEADER_ID + ",Pass";
                                        section1_results.add(STG_HEADER_ID);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",HEADER_ID" + "," + db_STG_HEADER_ID + "," + db_CONS_BC_HEADER_ID + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        cons_stg_map_row++;
                                    } else {
                                        String STG_HEADER_ID = cons_stg_map_row + ",HEADER_ID," + db_STG_HEADER_ID + "," + db_CONS_BC_HEADER_ID + ",Fail";
                                        section1_results.add(STG_HEADER_ID);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",HEADER_ID" + "," + db_STG_HEADER_ID + "," + db_CONS_BC_HEADER_ID + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        cons_stg_map_row++;
                                        CONS_flag++;
                                    }
                                }

                                //--------------------  Validation SOURCE ---------------
                                if (db_CONS_SOURCE.equals(db_STG_SOURCE)) {
                                    String STG_SOURCE = ",SOURCE," + db_STG_SOURCE + "," + db_CONS_SOURCE + ",Pass";
                                    section1_results.add(STG_SOURCE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SOURCE" + "," + db_STG_SOURCE + "," + db_CONS_SOURCE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);

                                } else {
                                    String STG_SOURCE = ",SOURCE," + db_STG_SOURCE + "," + db_CONS_SOURCE + ",Fail";
                                    section1_results.add(STG_SOURCE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SOURCE" + "," + db_STG_SOURCE + "," + db_CONS_SOURCE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation ACCOUNT_NUMBER ---------------
                                if (db_CONS_ACCOUNT_NUMBER.equals(db_STG_ACCOUNT_NUMBER)) {
                                    String STG_ACCOUNT_NUMBER = ",ACCOUNT_NUMBER," + db_STG_ACCOUNT_NUMBER + "," + db_CONS_ACCOUNT_NUMBER + ",Pass";
                                    section1_results.add(STG_ACCOUNT_NUMBER);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ACCOUNT_NUMBER" + "," + db_STG_ACCOUNT_NUMBER + "," + db_CONS_ACCOUNT_NUMBER + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_ACCOUNT_NUMBER = ",ACCOUNT_NUMBER," + db_STG_ACCOUNT_NUMBER + "," + db_CONS_ACCOUNT_NUMBER + ",Fail";
                                    section1_results.add(STG_ACCOUNT_NUMBER);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ACCOUNT_NUMBER" + "," + db_STG_ACCOUNT_NUMBER + "," + db_CONS_ACCOUNT_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;

                                }

                                //--------------------  Validation TRANSACTION_REFERENCE ---------------
                                if (db_CONS_TRANSACTION_REFERENCE.equals(db_STG_TRANSACTION_REFERENCE)) {
                                    String STG_TRANSACTION_REFERENCE = ",TRANSACTION_REFERENCE," + db_STG_TRANSACTION_REFERENCE + "," + db_CONS_TRANSACTION_REFERENCE + ",Pass";
                                    section1_results.add(STG_TRANSACTION_REFERENCE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_REFERENCE" + "," + db_STG_TRANSACTION_REFERENCE + "," + db_CONS_TRANSACTION_REFERENCE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_TRANSACTION_REFERENCE = ",TRANSACTION_REFERENCE," + db_STG_TRANSACTION_REFERENCE + "," + db_CONS_TRANSACTION_REFERENCE + ",Fail";
                                    section1_results.add(STG_TRANSACTION_REFERENCE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_REFERENCE" + "," + db_STG_TRANSACTION_REFERENCE + "," + db_CONS_TRANSACTION_REFERENCE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation TRANSACTION_DATE ---------------
                                String db_STG_TRANSACTION_DATEModified = db_STG_TRANSACTION_DATE.substring(0, 10);
                                String db_CONS_TRANSACTION_DATEModified = db_CONS_TRANSACTION_DATE.substring(0, 10);
                                if (db_CONS_TRANSACTION_DATEModified.equals(db_STG_TRANSACTION_DATEModified)) {
                                    String cons_TRANSACTION_DATE = ",TRANSACTION_DATE," + db_STG_TRANSACTION_DATEModified + "," + db_CONS_TRANSACTION_DATEModified + ",Pass";
                                    section1_results.add(cons_TRANSACTION_DATE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATEModified + "," + db_CONS_TRANSACTION_DATEModified + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_TRANSACTION_DATE = ",TRANSACTION_DATE," + db_STG_TRANSACTION_DATEModified + "," + db_CONS_TRANSACTION_DATEModified + ",Fail";
                                    section1_results.add(cons_TRANSACTION_DATE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATEModified + "," + db_CONS_TRANSACTION_DATEModified + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation TRANSACTION_SUBTYPE ---------------
                                if (db_CONS_TRANSACTION_SUBTYPE.equals(db_STG_TRANSACTION_SUBTYPE)) {
                                    String STG_TRANSACTION_SUBTYPE = ",TRANSACTION_SUBTYPE," + db_STG_TRANSACTION_SUBTYPE + "," + db_CONS_TRANSACTION_SUBTYPE + ",Pass";
                                    section1_results.add(STG_TRANSACTION_SUBTYPE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_SUBTYPE" + "," + db_STG_TRANSACTION_SUBTYPE + "," + db_CONS_TRANSACTION_SUBTYPE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_TRANSACTION_SUBTYPE = ",TRANSACTION_SUBTYPE," + db_STG_TRANSACTION_SUBTYPE + "," + db_CONS_TRANSACTION_SUBTYPE + ",Fail";
                                    section1_results.add(STG_TRANSACTION_SUBTYPE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_SUBTYPE" + "," + db_STG_TRANSACTION_SUBTYPE + "," + db_CONS_TRANSACTION_SUBTYPE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }


                                //--------------------  Validation INTEREST_AMOUNT ---------------
                                if (db_CONS_INTEREST_AMOUNT.equals(db_STG_INTEREST_AMOUNT)) {
                                    String STG_INTEREST_AMOUNT = ",INTEREST_AMOUNT," + db_STG_INTEREST_AMOUNT + "," + db_CONS_INTEREST_AMOUNT + ",Pass";
                                    section1_results.add(STG_INTEREST_AMOUNT);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",INTEREST_AMOUNT" + "," + db_STG_INTEREST_AMOUNT + "," + db_CONS_INTEREST_AMOUNT + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_INTEREST_AMOUNT = ",INTEREST_AMOUNT," + db_STG_INTEREST_AMOUNT + "," + db_CONS_INTEREST_AMOUNT + ",Fail";
                                    section1_results.add(STG_INTEREST_AMOUNT);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",INTEREST_AMOUNT" + "," + db_STG_INTEREST_AMOUNT + "," + db_CONS_INTEREST_AMOUNT + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation INTEREST_CURRENCY_CODE ---------------
                                if (db_CONS_INTEREST_CURRENCY_CODE.equals(db_STG_INTEREST_CURRENCY_CODE)) {
                                    String STG_INTEREST_CURRENCY_CODE = ",INTEREST_CURRENCY_CODE," + db_STG_INTEREST_CURRENCY_CODE + "," + db_CONS_INTEREST_CURRENCY_CODE + ",Pass";
                                    section1_results.add(STG_INTEREST_CURRENCY_CODE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",INTEREST_CURRENCY_CODE" + "," + db_STG_INTEREST_CURRENCY_CODE + "," + db_CONS_INTEREST_CURRENCY_CODE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_INTEREST_CURRENCY_CODE = ",INTEREST_CURRENCY_CODE," + db_STG_INTEREST_CURRENCY_CODE + "," + db_CONS_INTEREST_CURRENCY_CODE + ",Fail";
                                    section1_results.add(STG_INTEREST_CURRENCY_CODE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",INTEREST_CURRENCY_CODE" + "," + db_STG_INTEREST_CURRENCY_CODE + "," + db_CONS_INTEREST_CURRENCY_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation BASE_INTEREST_AMOUNT ---------------
                                if (db_CONS_BASE_INTEREST_AMOUNT.equals(db_STG_BASE_INTEREST_AMOUNT)) {
                                    String STG_BASE_INTEREST_AMOUNT = ",BASE_INTEREST_AMOUNT," + db_STG_BASE_INTEREST_AMOUNT + "," + db_CONS_BASE_INTEREST_AMOUNT + ",Pass";
                                    section1_results.add(STG_BASE_INTEREST_AMOUNT);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BASE_INTEREST_AMOUNT" + "," + db_STG_BASE_INTEREST_AMOUNT + "," + db_CONS_BASE_INTEREST_AMOUNT + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_BASE_INTEREST_AMOUNT = ",BASE_INTEREST_AMOUNT," + db_STG_BASE_INTEREST_AMOUNT + "," + db_CONS_BASE_INTEREST_AMOUNT + ",Fail";
                                    section1_results.add(STG_BASE_INTEREST_AMOUNT);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BASE_INTEREST_AMOUNT" + "," + db_STG_BASE_INTEREST_AMOUNT + "," + db_CONS_BASE_INTEREST_AMOUNT + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }


                                //--------------------  Validation TAX_DEDUCTIBLE ---------------
                                if (db_CONS_TAX_DEDUCTIBLE.equals(db_STG_TAX_DEDUCTIBLE)) {
                                    String STG_TAX_DEDUCTIBLE = ",TAX_DEDUCTIBLE," + db_STG_TAX_DEDUCTIBLE + "," + db_CONS_TAX_DEDUCTIBLE + ",Pass";
                                    section1_results.add(STG_TAX_DEDUCTIBLE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TAX_DEDUCTIBLE" + "," + db_STG_TAX_DEDUCTIBLE + "," + db_CONS_TAX_DEDUCTIBLE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_TAX_DEDUCTIBLE = ",TAX_DEDUCTIBLE," + db_STG_TAX_DEDUCTIBLE + "," + db_CONS_TAX_DEDUCTIBLE + ",Fail";
                                    section1_results.add(STG_TAX_DEDUCTIBLE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TAX_DEDUCTIBLE" + "," + db_STG_TAX_DEDUCTIBLE + "," + db_CONS_TAX_DEDUCTIBLE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }


                                //--------------------  Validation CURRENCY_CODE ---------------
                                if (db_CONS_CURRENCY_CODE.equals(db_STG_CURRENCY_CODE)) {
                                    String STG_CURRENCY_CODE = ",CURRENCY_CODE," + db_STG_CURRENCY_CODE + "," + db_CONS_CURRENCY_CODE + ",Pass";
                                    section1_results.add(STG_CURRENCY_CODE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CURRENCY_CODE" + "," + db_STG_CURRENCY_CODE + "," + db_CONS_CURRENCY_CODE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_CURRENCY_CODE = ",CURRENCY_CODE," + db_STG_CURRENCY_CODE + "," + db_CONS_CURRENCY_CODE + ",Fail";
                                    section1_results.add(STG_CURRENCY_CODE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CURRENCY_CODE" + "," + db_STG_CURRENCY_CODE + "," + db_CONS_CURRENCY_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }


                                //--------------------  Validation EXCHANGE_RATE     ---------------
                                if (db_CONS_EXCHANGE_RATE.equals(db_STG_EXCHANGE_RATE)) {
                                    String STG_EXCHANGE_RATE = ",EXCHANGE_RATE," + db_STG_EXCHANGE_RATE + "," + db_CONS_EXCHANGE_RATE + ",Pass";
                                    section1_results.add(STG_EXCHANGE_RATE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",EXCHANGE_RATE" + "," + db_STG_EXCHANGE_RATE + "," + db_CONS_EXCHANGE_RATE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);

                                } else {
                                    String STG_EXCHANGE_RATE = ",EXCHANGE_RATE," + db_STG_EXCHANGE_RATE + "," + db_CONS_EXCHANGE_RATE + ",Fail";
                                    section1_results.add(STG_EXCHANGE_RATE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",EXCHANGE_RATE" + "," + db_STG_EXCHANGE_RATE + "," + db_CONS_EXCHANGE_RATE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation EXCHANGE_RATE_TYPE ---------------
                                if (db_CONS_EXCHANGE_RATE_TYPE.equals(db_STG_EXCHANGE_RATE_TYPE)) {
                                    String STG_EXCHANGE_RATE_TYPE = ",EXCHANGE_RATE_TYPE," + db_STG_EXCHANGE_RATE_TYPE + "," + db_CONS_EXCHANGE_RATE_TYPE + ",Pass";
                                    section1_results.add(STG_EXCHANGE_RATE_TYPE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",EXCHANGE_RATE_TYPE" + "," + db_STG_EXCHANGE_RATE_TYPE + "," + db_CONS_EXCHANGE_RATE_TYPE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_EXCHANGE_RATE_TYPE = ",EXCHANGE_RATE_TYPE," + db_STG_EXCHANGE_RATE_TYPE + "," + db_CONS_EXCHANGE_RATE_TYPE + ",Fail";
                                    section1_results.add(STG_EXCHANGE_RATE_TYPE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",EXCHANGE_RATE_TYPE" + "," + db_STG_EXCHANGE_RATE_TYPE + "," + db_CONS_EXCHANGE_RATE_TYPE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation FSH_ATTRIBUTE_01     ---------------
                                if (db_CONS_FSH_ATTRIBUTE_1.equals(db_STG_FSH_ATTRIBUTE_01)) {
                                    String STG_FSH_ATTRIBUTE_01 = ",FSH_ATTRIBUTE_01," + db_STG_FSH_ATTRIBUTE_01 + "," + db_CONS_FSH_ATTRIBUTE_1 + ",Pass";
                                    section1_results.add(STG_FSH_ATTRIBUTE_01);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",FSH_ATTRIBUTE_01" + "," + db_STG_FSH_ATTRIBUTE_01 + "," + db_CONS_FSH_ATTRIBUTE_1 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_FSH_ATTRIBUTE_01 = ",FSH_ATTRIBUTE_01," + db_STG_FSH_ATTRIBUTE_01 + "," + db_CONS_FSH_ATTRIBUTE_1 + ",Fail";
                                    section1_results.add(STG_FSH_ATTRIBUTE_01);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",FSH_ATTRIBUTE_01" + "," + db_STG_FSH_ATTRIBUTE_01 + "," + db_CONS_FSH_ATTRIBUTE_1 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //----------------------- STANDARDISATION start here -----------------------------
                                String db_lookup_underwriter_meaning = "null";
                                String db_lookup_PRODUCT_TYPE_meaning = "null";
                                String db_lookup_CLAIM_NUMBER_meaning = "null";
                                String db_lookup_POLICY_NUMBER_meaning = "null";
                                String db_lookup_LINE_OF_BUSINESS_meaning = "null";
                                String db_lookup_CHANNEL_meaning = "null";
                                String db_lookup_BRAND_meaning = "null";
                                String db_lookup_TRANSACTION_REASON_meaning = "null";
                                String db_lookup_PAYMENT_METHOD_meaning = "null";
                                String db_lookup_SUN_NUMBER_meaning = "null";
                                String db_lookup_PAYMENT_TRANSACTION_TYPE_ID_meaning = "null";
                                String db_lookup_MID_NUMBER_meaning = "null";
                                String db_lookup_DDI_REFERENCE_meaning = "null";
                                String db_lookup_PAY_IN_SLIP_NUMBER_meaning = "null";
                                String db_lookup_CARD_TYPE_meaning = "null";
                                String db_lookup_BACS_NARRATIVE_meaning = "null";
                                String db_lookup_ORDER_NUMBER_meaning = "null";
                                String db_lookup_credit_ind_meaning = "null";
                                String db_lookup_REVERSAL_INDICATOR_meaning = "null";
                                String db_lookup_EVENT_CODE_meaning = "null";
                                String db_lookup_ENTITY_TYPE_CODE_meaning = "null";
                                String db_lookup_SUMMARY_FLAG_meaning = "null";


                                //------------------------ UnderWriter Validation -----------------

                                String LandscapeGLBilling_fsh_lookup = connect_db.executeQuery_DB("Lookup", "FSH_LOOKUP","LANDSCAPE");
                                String fsh_source = connect_db.executeQuery_DB("Lookup", "FSH_LOOKUP_SOURCE_LandscapeGLBilling","LANDSCAPE");


                                if (db_CONS_UNDERWRITER == (null)) {
                                    SQLResultset = SQLstmt.executeQuery(LandscapeGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'UNDERWRITER'" + fsh_source);
                                    //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'UNDERWRITER' and System = 'LAND'  and PATTERN = 'GLBilling'");
                                    while (SQLResultset.next()) {
                                        db_lookup_underwriter_meaning = SQLResultset.getString("MEANING");
                                    }

                                    if (db_lookup_underwriter_meaning.equals("null")) {
                                        String STG_UNDERWRITER = ",UNDERWRITER LOOKUP," + "LookUp value not found" + "," + db_STG_UNDERWRITER + ",Fail";
                                        section1_results.add(STG_UNDERWRITER);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",UNDERWRITER LOOKUP" + "," + "LookUp value not found" + "," + db_STG_UNDERWRITER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_underwriter_meaning != null) {
                                        if (db_lookup_underwriter_meaning.equals(db_STG_UNDERWRITER)) {
                                            String STG_UNDERWRITER = ",UNDERWRITER LOOKUP," + db_lookup_underwriter_meaning + "," + db_STG_UNDERWRITER + ",Pass";
                                            section1_results.add(STG_UNDERWRITER);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",UNDERWRITER LOOKUP" + "," + db_lookup_underwriter_meaning + "," + db_STG_UNDERWRITER + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String STG_UNDERWRITER = ",UNDERWRITER LOOKUP," + db_lookup_underwriter_meaning + "," + db_STG_UNDERWRITER + ",Fail";
                                            section1_results.add(STG_UNDERWRITER);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",UNDERWRITER LOOKUP" + "," + db_lookup_underwriter_meaning + "," + db_STG_UNDERWRITER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }
                                } else {
                                    if (db_CONS_UNDERWRITER.equals(db_STG_UNDERWRITER)) {
                                        String STG_UNDERWRITER = ",UNDERWRITER," + db_STG_UNDERWRITER + "," + db_CONS_UNDERWRITER + ",Pass";
                                        section1_results.add(STG_UNDERWRITER);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",UNDERWRITER" + "," + db_STG_UNDERWRITER + "," + db_CONS_UNDERWRITER + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String STG_UNDERWRITER = ",UNDERWRITER," + db_STG_UNDERWRITER + "," + db_CONS_UNDERWRITER + ",Fail";
                                        section1_results.add(STG_UNDERWRITER);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",UNDERWRITER" + "," + db_STG_UNDERWRITER + "," + db_CONS_UNDERWRITER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }


                                //------------------------ Claim_number Validation -----------------
                                if (db_CONS_CLAIM_NUMBER == (null)) {
                                    SQLResultset = SQLstmt.executeQuery(LandscapeGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'CLAIM_NUMBER'" + fsh_source);
                                    //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'CLAIM_NUMBER' and System = 'LAND'  and PATTERN = 'GLBilling'");
                                    while (SQLResultset.next()) {
                                        db_lookup_CLAIM_NUMBER_meaning = SQLResultset.getString("MEANING");
                                    }

                                    if (db_lookup_CLAIM_NUMBER_meaning.equals("null")) {
                                        String STG_CLAIM_NUMBER = ",CLAIM_NUMBER LOOKUP," + "LookUp value not found" + "," + db_STG_CLAIM_NUMBER + ",Fail";
                                        section1_results.add(STG_CLAIM_NUMBER);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CLAIM_NUMBER LOOKUP" + "," + "LookUp value not found" + "," + db_STG_CLAIM_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_CLAIM_NUMBER_meaning != null) {
                                        if (db_lookup_CLAIM_NUMBER_meaning.equals(db_STG_CLAIM_NUMBER)) {
                                            String STG_CLAIM_NUMBER = ",CLAIM_NUMBER LOOKUP," + db_lookup_CLAIM_NUMBER_meaning + "," + db_STG_CLAIM_NUMBER + ",Pass";
                                            section1_results.add(STG_CLAIM_NUMBER);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CLAIM_NUMBER LOOKUP" + "," + db_lookup_CLAIM_NUMBER_meaning + "," + db_STG_CLAIM_NUMBER + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String STG_CLAIM_NUMBER = ",CLAIM_NUMBER LOOKUP," + db_lookup_CLAIM_NUMBER_meaning + "," + db_STG_CLAIM_NUMBER + ",Fail";
                                            section1_results.add(STG_CLAIM_NUMBER);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CLAIM_NUMBER LOOKUP" + "," + db_lookup_CLAIM_NUMBER_meaning + "," + db_STG_CLAIM_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }
                                } else {
                                    if (db_CONS_CLAIM_NUMBER.equals(db_STG_CLAIM_NUMBER)) {
                                        String STG_CLAIM_NUMBER = ",CLAIM_NUMBER," + db_STG_CLAIM_NUMBER + "," + db_CONS_CLAIM_NUMBER + ",Pass";
                                        section1_results.add(STG_CLAIM_NUMBER);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CLAIM_NUMBER" + "," + db_STG_CLAIM_NUMBER + "," + db_CONS_CLAIM_NUMBER + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String STG_CLAIM_NUMBER = ",CLAIM_NUMBER," + db_STG_CLAIM_NUMBER + "," + db_CONS_CLAIM_NUMBER + ",Fail";
                                        section1_results.add(STG_CLAIM_NUMBER);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CLAIM_NUMBER" + "," + db_STG_CLAIM_NUMBER + "," + db_CONS_CLAIM_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }


                                //------------------------ POLICY_NUMBER Validation -----------------
                                if (db_CONS_POLICY_NUMBER == (null)) {
                                    SQLResultset = SQLstmt.executeQuery(LandscapeGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'POLICY_NUMBER'" + fsh_source);
                                    //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'POLICY_NUMBER' and System = 'LAND'  and PATTERN = 'GLBilling'");
                                    while (SQLResultset.next()) {
                                        db_lookup_POLICY_NUMBER_meaning = SQLResultset.getString("MEANING");
                                    }

                                    if (db_lookup_POLICY_NUMBER_meaning.equals("null")) {
                                        String STG_POLICY_NUMBER = ",POLICY_NUMBER LOOKUP," + "LookUp value not found" + "," + db_STG_POLICY_NUMBER + ",Fail";
                                        section1_results.add(STG_POLICY_NUMBER);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",POLICY_NUMBER LOOKUP" + "," + "LookUp value not found" + "," + db_STG_POLICY_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_POLICY_NUMBER_meaning != null) {
                                        if (db_lookup_POLICY_NUMBER_meaning.equals(db_STG_POLICY_NUMBER)) {
                                            String STG_POLICY_NUMBER = ",POLICY_NUMBER LOOKUP," + db_lookup_POLICY_NUMBER_meaning + "," + db_STG_POLICY_NUMBER + ",Pass";
                                            section1_results.add(STG_POLICY_NUMBER);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",POLICY_NUMBER LOOKUP" + "," + db_lookup_POLICY_NUMBER_meaning + "," + db_STG_POLICY_NUMBER + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String STG_POLICY_NUMBER = ",POLICY_NUMBER LOOKUP," + db_lookup_POLICY_NUMBER_meaning + "," + db_STG_POLICY_NUMBER + ",Fail";
                                            section1_results.add(STG_POLICY_NUMBER);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",POLICY_NUMBER LOOKUP" + "," + db_lookup_POLICY_NUMBER_meaning + "," + db_STG_POLICY_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }
                                } else {
                                    if (db_CONS_POLICY_NUMBER.equals(db_STG_POLICY_NUMBER)) {
                                        String STG_POLICY_NUMBER = ",POLICY_NUMBER," + db_STG_POLICY_NUMBER + "," + db_CONS_POLICY_NUMBER + ",Pass";
                                        section1_results.add(STG_POLICY_NUMBER);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",POLICY_NUMBER" + "," + db_STG_POLICY_NUMBER + "," + db_CONS_POLICY_NUMBER + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String STG_POLICY_NUMBER = ",POLICY_NUMBER," + db_STG_POLICY_NUMBER + "," + db_CONS_POLICY_NUMBER + ",Fail";
                                        section1_results.add(STG_POLICY_NUMBER);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",POLICY_NUMBER" + "," + db_STG_POLICY_NUMBER + "," + db_CONS_POLICY_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //------------------------ BRAND Validation -----------------
                                if (db_CONS_BRAND == (null)) {
                                    SQLResultset = SQLstmt.executeQuery(LandscapeGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'BRAND'" + fsh_source);
                                    //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'BRAND' and System = 'LAND'  and PATTERN = 'GLBilling'");
                                    while (SQLResultset.next()) {
                                        db_lookup_BRAND_meaning = SQLResultset.getString("MEANING");
                                    }

                                    if (db_lookup_BRAND_meaning.equals("null")) {
                                        String STG_BRAND = ",BRAND LOOKUP," + "LookUp value not found" + "," + db_STG_BRAND + ",Fail";
                                        section1_results.add(STG_BRAND);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BRAND LOOKUP" + "," + "LookUp value not found" + "," + db_STG_BRAND + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_BRAND_meaning != null) {
                                        if (db_lookup_BRAND_meaning.equals(db_STG_BRAND)) {
                                            String STG_BRAND = ",BRAND LOOKUP," + db_lookup_BRAND_meaning + "," + db_STG_BRAND + ",Pass";
                                            section1_results.add(STG_BRAND);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BRAND LOOKUP" + "," + db_lookup_BRAND_meaning + "," + db_STG_BRAND + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String STG_BRAND = ",BRAND LOOKUP," + db_lookup_BRAND_meaning + "," + db_STG_BRAND + ",Fail";
                                            section1_results.add(STG_BRAND);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BRAND LOOKUP" + "," + db_lookup_BRAND_meaning + "," + db_STG_BRAND + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }
                                } else {
                                    SQLResultset = SQLstmt.executeQuery(LandscapeGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_CONS_BRAND + "' and LOOKUP_TYPE = 'BRAND'" + fsh_source);
                                    //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_BRAND + "' and LOOKUP_TYPE = 'BRAND' and System = 'LAND'  and PATTERN = 'GLBilling'");
                                    while (SQLResultset.next()) {
                                        db_lookup_BRAND_meaning = SQLResultset.getString("MEANING");
                                    }

                                    if (db_lookup_BRAND_meaning.equals("null")) {
                                        String STG_BRAND = ",BRAND LOOKUP," + "LookUp value not found" + "," + db_STG_BRAND + ",Fail";
                                        section1_results.add(STG_BRAND);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BRAND LOOKUP" + "," + "LookUp value not found" + "," + db_STG_BRAND + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_BRAND_meaning != null) {
                                        if (db_lookup_BRAND_meaning.equals(db_STG_BRAND)) {
                                            String STG_BRAND = ",BRAND LOOKUP," + db_lookup_BRAND_meaning + "," + db_STG_BRAND + ",Pass";
                                            section1_results.add(STG_BRAND);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BRAND LOOKUP" + "," + db_lookup_BRAND_meaning + "," + db_STG_BRAND + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String STG_BRAND = ",BRAND LOOKUP," + db_lookup_BRAND_meaning + "," + db_STG_BRAND + ",Fail";
                                            section1_results.add(STG_BRAND);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BRAND LOOKUP" + "," + db_lookup_BRAND_meaning + "," + db_STG_BRAND + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }
                                }


                                //------------------------ LINE_OF_BUSINESS Validation -----------------
                                if (db_CONS_LINE_OF_BUSINESS == (null)) {
                                    SQLResultset = SQLstmt.executeQuery(LandscapeGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'LINE_OF_BUSINESS'" + fsh_source);
                                    //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'LINE_OF_BUSINESS' and System = 'LAND'  and PATTERN = 'GLBilling'");
                                    while (SQLResultset.next()) {
                                        db_lookup_LINE_OF_BUSINESS_meaning = SQLResultset.getString("MEANING");
                                    }

                                    if (db_lookup_LINE_OF_BUSINESS_meaning.equals("null")) {
                                        String STG_LINE_OF_BUSINESS = ",LINE_OF_BUSINESS LOOKUP," + "LookUp value not found" + "," + db_STG_LINE_OF_BUSINESS + ",Fail";
                                        section1_results.add(STG_LINE_OF_BUSINESS);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",LINE_OF_BUSINESS LOOKUP" + "," + "LookUp value not found" + "," + db_STG_LINE_OF_BUSINESS + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_LINE_OF_BUSINESS_meaning != null) {
                                        if (db_lookup_LINE_OF_BUSINESS_meaning.equals(db_STG_LINE_OF_BUSINESS)) {
                                            String STG_LINE_OF_BUSINESS = ",LINE_OF_BUSINESS LOOKUP," + db_lookup_LINE_OF_BUSINESS_meaning + "," + db_STG_LINE_OF_BUSINESS + ",Pass";
                                            section1_results.add(STG_LINE_OF_BUSINESS);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",LINE_OF_BUSINESS LOOKUP" + "," + db_lookup_LINE_OF_BUSINESS_meaning + "," + db_STG_LINE_OF_BUSINESS + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String STG_LINE_OF_BUSINESS = ",LINE_OF_BUSINESS LOOKUP," + db_lookup_LINE_OF_BUSINESS_meaning + "," + db_STG_LINE_OF_BUSINESS + ",Fail";
                                            section1_results.add(STG_LINE_OF_BUSINESS);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",LINE_OF_BUSINESS LOOKUP" + "," + db_lookup_LINE_OF_BUSINESS_meaning + "," + db_STG_LINE_OF_BUSINESS + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }
                                } else {
                                    SQLResultset = SQLstmt.executeQuery(LandscapeGLBilling_fsh_lookup + " WHERE  LOOKUP_CODE = '" + db_CONS_LINE_OF_BUSINESS + "' and LOOKUP_TYPE = 'LINE_OF_BUSINESS'" + fsh_source);
                                    //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_LINE_OF_BUSINESS + "' and LOOKUP_TYPE = 'LINE_OF_BUSINESS' and System = 'LAND'  and PATTERN = 'GLBilling'");
                                    while (SQLResultset.next()) {
                                        db_lookup_LINE_OF_BUSINESS_meaning = SQLResultset.getString("MEANING");
                                    }

                                    if (db_lookup_LINE_OF_BUSINESS_meaning.equals("null")) {
                                        String STG_LINE_OF_BUSINESS = ",LINE_OF_BUSINESS LOOKUP," + "LookUp value not found" + "," + db_STG_LINE_OF_BUSINESS + ",Fail";
                                        section1_results.add(STG_LINE_OF_BUSINESS);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",LINE_OF_BUSINESS LOOKUP" + "," + "LookUp value not found" + "," + db_STG_LINE_OF_BUSINESS + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_LINE_OF_BUSINESS_meaning != null) {
                                        if (db_lookup_LINE_OF_BUSINESS_meaning.equals(db_STG_LINE_OF_BUSINESS)) {
                                            String STG_LINE_OF_BUSINESS = ",LINE_OF_BUSINESS LOOKUP," + db_lookup_LINE_OF_BUSINESS_meaning + "," + db_STG_LINE_OF_BUSINESS + ",Pass";
                                            section1_results.add(STG_LINE_OF_BUSINESS);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",LINE_OF_BUSINESS LOOKUP" + "," + db_lookup_LINE_OF_BUSINESS_meaning + "," + db_STG_LINE_OF_BUSINESS + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String STG_LINE_OF_BUSINESS = ",LINE_OF_BUSINESS LOOKUP," + db_lookup_LINE_OF_BUSINESS_meaning + "," + db_STG_LINE_OF_BUSINESS + ",Fail";
                                            section1_results.add(STG_LINE_OF_BUSINESS);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",LINE_OF_BUSINESS LOOKUP" + "," + db_lookup_LINE_OF_BUSINESS_meaning + "," + db_STG_LINE_OF_BUSINESS + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }

                                }


                                //------------------------ PRODUCT_TYPE Validation -----------------
                                if (db_CONS_PRODUCT_TYPE == (null)) {
                                    SQLResultset = SQLstmt.executeQuery(LandscapeGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'PRODUCT_TYPE'" + fsh_source);
                                    //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'PRODUCT_TYPE' and System = 'LAND' and PATTERN = 'GLBilling'");
                                    while (SQLResultset.next()) {
                                        db_lookup_PRODUCT_TYPE_meaning = SQLResultset.getString("MEANING");
                                    }

                                    if (db_lookup_PRODUCT_TYPE_meaning.equals("null")) {
                                        String STG_PRODUCT_TYPE = ",PRODUCT_TYPE LOOKUP," + "LookUp value not found" + "," + db_STG_PRODUCT_TYPE + ",Fail";
                                        section1_results.add(STG_PRODUCT_TYPE);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT_TYPE LOOKUP" + "," + "LookUp value not found" + "," + db_STG_PRODUCT_TYPE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_PRODUCT_TYPE_meaning != null) {
                                        if (db_lookup_PRODUCT_TYPE_meaning.equals(db_STG_PRODUCT_TYPE)) {
                                            String STG_PRODUCT_TYPE = ",PRODUCT_TYPE LOOKUP," + db_lookup_PRODUCT_TYPE_meaning + "," + db_STG_PRODUCT_TYPE + ",Pass";
                                            section1_results.add(STG_PRODUCT_TYPE);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT_TYPE LOOKUP" + "," + db_lookup_PRODUCT_TYPE_meaning + "," + db_STG_PRODUCT_TYPE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String STG_PRODUCT_TYPE = ",PRODUCT_TYPE LOOKUP," + db_lookup_PRODUCT_TYPE_meaning + "," + db_STG_PRODUCT_TYPE + ",Fail";
                                            section1_results.add(STG_PRODUCT_TYPE);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT_TYPE LOOKUP" + "," + db_lookup_PRODUCT_TYPE_meaning + "," + db_STG_PRODUCT_TYPE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }
                                } else {
                                    SQLResultset = SQLstmt.executeQuery(LandscapeGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_CONS_PRODUCT_TYPE + "' and LOOKUP_TYPE = 'PRODUCT_TYPE'" + fsh_source);
                                    //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_PRODUCT_TYPE + "' and LOOKUP_TYPE = 'PRODUCT_TYPE' and System = 'LAND' and PATTERN = 'GLBilling'");
                                    while (SQLResultset.next()) {
                                        db_lookup_PRODUCT_TYPE_meaning = SQLResultset.getString("MEANING");
                                    }

                                    if (db_lookup_PRODUCT_TYPE_meaning.equals("null")) {
                                        String STG_PRODUCT_TYPE = ",PRODUCT_TYPE LOOKUP," + "LookUp value not found" + "," + db_STG_PRODUCT_TYPE + ",Fail";
                                        section1_results.add(STG_PRODUCT_TYPE);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT_TYPE LOOKUP" + "," + "LookUp value not found" + "," + db_STG_PRODUCT_TYPE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_PRODUCT_TYPE_meaning != null) {
                                        if (db_lookup_PRODUCT_TYPE_meaning.equals(db_STG_PRODUCT_TYPE)) {
                                            String STG_PRODUCT_TYPE = ",PRODUCT_TYPE LOOKUP," + db_lookup_PRODUCT_TYPE_meaning + "," + db_STG_PRODUCT_TYPE + ",Pass";
                                            section1_results.add(STG_PRODUCT_TYPE);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT_TYPE LOOKUP" + "," + db_lookup_PRODUCT_TYPE_meaning + "," + db_STG_PRODUCT_TYPE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String STG_PRODUCT_TYPE = ",PRODUCT_TYPE LOOKUP," + db_lookup_PRODUCT_TYPE_meaning + "," + db_STG_PRODUCT_TYPE + ",Fail";
                                            section1_results.add(STG_PRODUCT_TYPE);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT_TYPE LOOKUP" + "," + db_lookup_PRODUCT_TYPE_meaning + "," + db_STG_PRODUCT_TYPE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }

                                }

                                //------------------------ TRANSACTION_REASON Validation -----------------

                                if (db_CONS_CLAIM_NUMBER != null) {
                                    String db_STG_TRANSACTION_REASONModified = "CLAIM";
                                    if (db_STG_TRANSACTION_REASON.equals(db_STG_TRANSACTION_REASONModified)) {
                                        String STG_TRANSACTION_REASON = ",TRANSACTION_REASON," + db_STG_TRANSACTION_REASON + "," + db_STG_TRANSACTION_REASONModified + ",Pass";
                                        section1_results.add(STG_TRANSACTION_REASON);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_REASON" + "," + db_STG_TRANSACTION_REASON + "," + db_STG_TRANSACTION_REASONModified + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    }
                                } else if (db_STG_POLICY_NUMBER != null) {
                                    String db_STG_TRANSACTION_REASONModified = "POLICY";
                                    if (db_STG_TRANSACTION_REASON.equals(db_STG_TRANSACTION_REASONModified)) {
                                        String STG_TRANSACTION_REASON = ",TRANSACTION_REASON," + db_STG_TRANSACTION_REASON + "," + db_STG_TRANSACTION_REASONModified + ",Pass";
                                        section1_results.add(STG_TRANSACTION_REASON);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_REASON" + "," + db_STG_TRANSACTION_REASON + "," + db_STG_TRANSACTION_REASONModified + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);

                                    }
                                } else {
                                    SQLResultset = SQLstmt.executeQuery(LandscapeGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'TRANSACTION_REASON'" + fsh_source);
                                    //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'TRANSACTION_REASON' and System = 'LAND'  and PATTERN = 'GLBilling'");
                                    while (SQLResultset.next()) {
                                        db_lookup_TRANSACTION_REASON_meaning = SQLResultset.getString("MEANING");
                                    }
                                    if (db_lookup_TRANSACTION_REASON_meaning.equals("null")) {
                                        String lookup_TRANSACTION_REASON_meaning = ",TRANSACTION_REASON LOOKUP," + "LookUp value not found" + "," + db_STG_TRANSACTION_REASON + ",Fail";
                                        section1_results.add(lookup_TRANSACTION_REASON_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_REASON LOOKUP" + "," + "LookUp value not found" + "," + db_STG_TRANSACTION_REASON + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_TRANSACTION_REASON_meaning != null) {
                                        if (db_lookup_TRANSACTION_REASON_meaning.equals(db_STG_TRANSACTION_REASON)) {
                                            String lookup_TRANSACTION_REASON_meaning = ",TRANSACTION_REASON LOOKUP," + db_lookup_TRANSACTION_REASON_meaning + "," + db_STG_TRANSACTION_REASON + ",Pass";
                                            section1_results.add(lookup_TRANSACTION_REASON_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_REASON LOOKUP" + "," + db_lookup_TRANSACTION_REASON_meaning + "," + db_STG_TRANSACTION_REASON + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String lookup_TRANSACTION_REASON_meaning = ",TRANSACTION_REASON LOOKUP," + db_lookup_TRANSACTION_REASON_meaning + "," + db_STG_TRANSACTION_REASON + ",Fail";
                                            section1_results.add(lookup_TRANSACTION_REASON_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_REASON LOOKUP" + "," + db_lookup_TRANSACTION_REASON_meaning + "," + db_STG_TRANSACTION_REASON + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }
                                }


                                //------------------------ PAYMENT_METHOD Validation -----------------
                                if (db_CONS_PAYMENT_METHOD == (null)) {
                                    SQLResultset = SQLstmt.executeQuery(LandscapeGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'PAYMENT_METHOD'" + fsh_source);
                                    //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'PAYMENT_METHOD' and System = 'LAND'  and PATTERN = 'GLBilling'");
                                    while (SQLResultset.next()) {
                                        db_lookup_PAYMENT_METHOD_meaning = SQLResultset.getString("MEANING");
                                    }

                                    if (db_lookup_PAYMENT_METHOD_meaning.equals("null")) {
                                        String lookup_payment_method_meaning = ",PAYMENT_METHOD LOOKUP," + "LookUp value not found" + "," + db_STG_PAYMENT_METHOD + ",Fail";
                                        section1_results.add(lookup_payment_method_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_REASON LOOKUP" + "," + "LookUp value not found" + "," + db_STG_PAYMENT_METHOD + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_PAYMENT_METHOD_meaning != null) {
                                        if (db_lookup_PAYMENT_METHOD_meaning.equals(db_STG_PAYMENT_METHOD)) {
                                            String lookup_payment_method_meaning = ",PAYMENT_METHOD LOOKUP," + db_lookup_PAYMENT_METHOD_meaning + "," + db_STG_PAYMENT_METHOD + ",Pass";
                                            section1_results.add(lookup_payment_method_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_REASON LOOKUP" + "," + db_lookup_PAYMENT_METHOD_meaning + "," + db_STG_PAYMENT_METHOD + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String lookup_payment_method_meaning = ",PAYMENT_METHOD LOOKUP," + db_lookup_PAYMENT_METHOD_meaning + "," + db_STG_PAYMENT_METHOD + ",Fail";
                                            section1_results.add(lookup_payment_method_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAYMENT_METHOD LOOKUP" + "," + db_lookup_PAYMENT_METHOD_meaning + "," + db_STG_PAYMENT_METHOD + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }
                                } else {
                                    SQLResultset = SQLstmt.executeQuery(LandscapeGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_CONS_PAYMENT_METHOD + "' and LOOKUP_TYPE = 'PAYMENT_METHOD'" + fsh_source);
                                    //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_PAYMENT_METHOD + "' and LOOKUP_TYPE = 'PAYMENT_METHOD' and System = 'LAND'  and PATTERN = 'GLBilling'");
                                    while (SQLResultset.next()) {
                                        db_lookup_PAYMENT_METHOD_meaning = SQLResultset.getString("MEANING");
                                    }

                                    if (db_lookup_PAYMENT_METHOD_meaning.equals("null")) {
                                        String lookup_payment_method_meaning = ",PAYMENT_METHOD LOOKUP," + "LookUp value not found" + "," + db_STG_PAYMENT_METHOD + ",Fail";
                                        section1_results.add(lookup_payment_method_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAYMENT_METHOD LOOKUP" + "," + "LookUp value not found" + "," + db_STG_PAYMENT_METHOD + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_PAYMENT_METHOD_meaning != null) {
                                        if (db_lookup_PAYMENT_METHOD_meaning.equals(db_STG_PAYMENT_METHOD)) {
                                            String lookup_payment_method_meaning = ",PAYMENT_METHOD LOOKUP," + db_lookup_PAYMENT_METHOD_meaning + "," + db_STG_PAYMENT_METHOD + ",Pass";
                                            section1_results.add(lookup_payment_method_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAYMENT_METHOD LOOKUP" + "," + db_lookup_PAYMENT_METHOD_meaning + "," + db_STG_PAYMENT_METHOD + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String lookup_payment_method_meaning = ",PAYMENT_METHOD LOOKUP," + db_lookup_PAYMENT_METHOD_meaning + "," + db_STG_PAYMENT_METHOD + ",Fail";
                                            section1_results.add(lookup_payment_method_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAYMENT_METHOD LOOKUP" + "," + db_lookup_PAYMENT_METHOD_meaning + "," + db_STG_PAYMENT_METHOD + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }
                                }

                                //------------------------ SUN_NUMBER Validation -----------------
                                if (db_CONS_SUN_NUMBER == (null)) {
                                    SQLResultset = SQLstmt.executeQuery(LandscapeGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_CONS_PAYMENT_METHOD + "' and LOOKUP_TYPE = 'PAYMENT_METHOD'" + fsh_source);
                                    //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'SUN_NUMBER' and System = 'LAND'  and PATTERN = 'GLBilling'");
                                    while (SQLResultset.next()) {
                                        db_lookup_SUN_NUMBER_meaning = SQLResultset.getString("MEANING");
                                    }

                                    if (db_lookup_SUN_NUMBER_meaning.equals("null")) {
                                        String lookup_SUN_NUMBER_meaning = ",SUN_NUMBER LOOKUP," + "LookUp value not found" + "," + db_STG_SUN_NUMBER + ",Fail";
                                        section1_results.add(lookup_SUN_NUMBER_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SUN_NUMBER LOOKUP" + "," + "LookUp value not found" + "," + db_STG_SUN_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_SUN_NUMBER_meaning != null) {
                                        if (db_lookup_SUN_NUMBER_meaning.equals(db_STG_SUN_NUMBER)) {
                                            String lookup_SUN_NUMBER_meaning = ",SUN_NUMBER LOOKUP," + db_lookup_SUN_NUMBER_meaning + "," + db_STG_SUN_NUMBER + ",Pass";
                                            section1_results.add(lookup_SUN_NUMBER_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SUN_NUMBER LOOKUP" + "," + db_lookup_SUN_NUMBER_meaning + "," + db_STG_SUN_NUMBER + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String lookup_SUN_NUMBER_meaning = ",SUN_NUMBER LOOKUP," + db_lookup_SUN_NUMBER_meaning + "," + db_STG_SUN_NUMBER + ",Fail";
                                            section1_results.add(lookup_SUN_NUMBER_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SUN_NUMBER LOOKUP" + "," + db_lookup_SUN_NUMBER_meaning + "," + db_STG_SUN_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }
                                } else {
                                    SQLResultset = SQLstmt.executeQuery(LandscapeGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_CONS_SUN_NUMBER + "' and LOOKUP_TYPE = 'SUN_NUMBER'" + fsh_source);
                                    //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM FSH_ORA_DATA.DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_SUN_NUMBER + "' and LOOKUP_TYPE = 'SUN_NUMBER' and System = 'LAND'  and PATTERN = 'GLBilling'");
                                    while (SQLResultset.next()) {
                                        db_lookup_SUN_NUMBER_meaning = SQLResultset.getString("MEANING");
                                    }
                                    if (db_lookup_SUN_NUMBER_meaning.equals("null")) {
                                        String lookup_SUN_NUMBER_meaning = ",SUN_NUMBER LOOKUP," + "LookUp value not found" + "," + db_STG_SUN_NUMBER + ",Fail";
                                        section1_results.add(lookup_SUN_NUMBER_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SUN_NUMBER LOOKUP" + "," + "LookUp value not found" + "," + db_STG_SUN_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_SUN_NUMBER_meaning != null) {
                                        if (db_lookup_SUN_NUMBER_meaning.equals(db_STG_SUN_NUMBER)) {
                                            String lookup_SUN_NUMBER_meaning = ",SUN_NUMBER LOOKUP," + db_lookup_SUN_NUMBER_meaning + "," + db_STG_SUN_NUMBER + ",Pass";
                                            section1_results.add(lookup_SUN_NUMBER_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SUN_NUMBER LOOKUP" + "," + db_lookup_SUN_NUMBER_meaning + "," + db_STG_SUN_NUMBER + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String lookup_SUN_NUMBER_meaning = ",SUN_NUMBER LOOKUP," + db_lookup_SUN_NUMBER_meaning + "," + db_STG_SUN_NUMBER + ",Fail";
                                            section1_results.add(lookup_SUN_NUMBER_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SUN_NUMBER LOOKUP" + "," + db_lookup_SUN_NUMBER_meaning + "," + db_STG_SUN_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }
                                }

                                //------------------------ MID_NUMBER Validation -----------------
                                if (db_CONS_MID_NUMBER == (null)) {
                                    SQLResultset = SQLstmt.executeQuery(LandscapeGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'MID_NUMBER'" + fsh_source);
                                    //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'MID_NUMBER' and System = 'LAND'  and PATTERN = 'GLBilling'");
                                    while (SQLResultset.next()) {
                                        db_lookup_MID_NUMBER_meaning = SQLResultset.getString("MEANING");
                                    }

                                    if (db_lookup_MID_NUMBER_meaning.equals("null")) {
                                        String lookup_MID_NUMBER_meaning = ",MID_NUMBER LOOKUP," + "LookUp value not found" + "," + db_STG_MID_NUMBER + ",Fail";
                                        section1_results.add(lookup_MID_NUMBER_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",MID_NUMBER LOOKUP" + "," + "LookUp value not found" + "," + db_STG_MID_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_MID_NUMBER_meaning != null) {
                                        if (db_lookup_MID_NUMBER_meaning.equals(db_STG_MID_NUMBER)) {
                                            String lookup_MID_NUMBER_meaning = ",MID_NUMBER LOOKUP," + db_lookup_MID_NUMBER_meaning + "," + db_STG_MID_NUMBER + ",Pass";
                                            section1_results.add(lookup_MID_NUMBER_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",MID_NUMBER LOOKUP" + "," + db_lookup_MID_NUMBER_meaning + "," + db_STG_MID_NUMBER + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String lookup_MID_NUMBER_meaning = ",MID_NUMBER LOOKUP," + db_lookup_MID_NUMBER_meaning + "," + db_STG_MID_NUMBER + ",Fail";
                                            section1_results.add(lookup_MID_NUMBER_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",MID_NUMBER LOOKUP" + "," + db_lookup_MID_NUMBER_meaning + "," + db_STG_MID_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;

                                        }
                                    }
                                } else {
                                    SQLResultset = SQLstmt.executeQuery(LandscapeGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_CONS_MID_NUMBER + "' and LOOKUP_TYPE = 'MID_NUMBER'" + fsh_source);
                                    //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_MID_NUMBER + "' and LOOKUP_TYPE = 'MID_NUMBER' and System = 'LAND'  and PATTERN = 'GLBilling'");
                                    while (SQLResultset.next()) {
                                        db_lookup_MID_NUMBER_meaning = SQLResultset.getString("MEANING");
                                    }

                                    if (db_lookup_MID_NUMBER_meaning.equals("null")) {
                                        String lookup_MID_NUMBER_meaning = ",MID_NUMBER LOOKUP," + "LookUp value not found" + "," + db_STG_MID_NUMBER + ",Fail";
                                        section1_results.add(lookup_MID_NUMBER_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",MID_NUMBER LOOKUP" + "," + "LookUp value not found" + "," + db_STG_MID_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_MID_NUMBER_meaning != null) {
                                        if (db_lookup_MID_NUMBER_meaning.equals(db_STG_MID_NUMBER)) {
                                            String lookup_MID_NUMBER_meaning = ",MID_NUMBER LOOKUP," + db_lookup_MID_NUMBER_meaning + "," + db_STG_MID_NUMBER + ",Pass";
                                            section1_results.add(lookup_MID_NUMBER_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",MID_NUMBER LOOKUP" + "," + db_lookup_MID_NUMBER_meaning + "," + db_STG_MID_NUMBER + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String lookup_MID_NUMBER_meaning = ",MID_NUMBER LOOKUP," + db_lookup_MID_NUMBER_meaning + "," + db_STG_MID_NUMBER + ",Fail";
                                            section1_results.add(lookup_MID_NUMBER_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",MID_NUMBER LOOKUP" + "," + db_lookup_MID_NUMBER_meaning + "," + db_STG_MID_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }
                                }


                                //------------------------ DDI_REFERENCE Validation -----------------
                                if (db_CONS_DDI_REFERENCE == (null)) {
                                    SQLResultset = SQLstmt.executeQuery(LandscapeGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'DDI_REFERENCE'" + fsh_source);
                                    //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'DDI_REFERENCE' and System = 'LAND'  and PATTERN = 'GLBilling'");
                                    while (SQLResultset.next()) {
                                        db_lookup_DDI_REFERENCE_meaning = SQLResultset.getString("MEANING");
                                    }

                                    if (db_lookup_DDI_REFERENCE_meaning.equals("null")) {
                                        String lookup_DDI_REFERENCE_meaning = ",DDI_REFERENCE LOOKUP," + "LookUp value not found" + "," + db_STG_DDI_REFERENCE + ",Fail";
                                        section1_results.add(lookup_DDI_REFERENCE_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",DDI_REFERENCE LOOKUP" + "," + "LookUp value not found" + "," + db_STG_DDI_REFERENCE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_DDI_REFERENCE_meaning != null) {
                                        if (db_lookup_DDI_REFERENCE_meaning.equals(db_STG_DDI_REFERENCE)) {
                                            String lookup_DDI_REFERENCE_meaning = ",DDI_REFERENCE LOOKUP," + db_lookup_DDI_REFERENCE_meaning + "," + db_STG_DDI_REFERENCE + ",Pass";
                                            section1_results.add(lookup_DDI_REFERENCE_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",DDI_REFERENCE LOOKUP" + "," + db_lookup_DDI_REFERENCE_meaning + "," + db_STG_DDI_REFERENCE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String lookup_DDI_REFERENCE_meaning = ",DDI_REFERENCE LOOKUP," + db_lookup_DDI_REFERENCE_meaning + "," + db_STG_DDI_REFERENCE + ",Fail";
                                            section1_results.add(lookup_DDI_REFERENCE_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",DDI_REFERENCE LOOKUP" + "," + db_lookup_DDI_REFERENCE_meaning + "," + db_STG_DDI_REFERENCE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }
                                } else {
                                    if (db_CONS_DDI_REFERENCE.equals(db_STG_DDI_REFERENCE)) {
                                        String STG_DDI_REFERENCE = ",DDI_REFERENCE," + db_STG_DDI_REFERENCE + "," + db_CONS_DDI_REFERENCE + ",Pass";
                                        section1_results.add(STG_DDI_REFERENCE);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",DDI_REFERENCE" + "," + db_STG_DDI_REFERENCE + "," + db_CONS_DDI_REFERENCE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String STG_DDI_REFERENCE = ",DDI_REFERENCE," + db_STG_DDI_REFERENCE + "," + db_CONS_DDI_REFERENCE + ",Fail";
                                        section1_results.add(STG_DDI_REFERENCE);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",DDI_REFERENCE" + "," + db_STG_DDI_REFERENCE + "," + db_CONS_DDI_REFERENCE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //------------------------ PAY_IN_SLIP_NUMBER Validation -----------------
                                if (db_CONS_PAY_IN_SLIP_NUMBER == (null)) {
                                    SQLResultset = SQLstmt.executeQuery(LandscapeGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'PAY_IN_SLIP_NUMBER'" + fsh_source);
                                    //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'PAY_IN_SLIP_NUMBER' and System = 'LAND'  and PATTERN = 'GLBilling'");
                                    while (SQLResultset.next()) {
                                        db_lookup_PAY_IN_SLIP_NUMBER_meaning = SQLResultset.getString("MEANING");
                                    }

                                    if (db_lookup_PAY_IN_SLIP_NUMBER_meaning.equals("null")) {
                                        String lookup_PAY_IN_SLIP_NUMBER_meaning = ",PAY_IN_SLIP_NUMBER LOOKUP," + "LookUp value not found" + "," + db_STG_PAY_IN_SLIP_NUMBER + ",Fail";
                                        section1_results.add(lookup_PAY_IN_SLIP_NUMBER_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAY_IN_SLIP_NUMBER LOOKUP" + "," + "LookUp value not found" + "," + db_STG_PAY_IN_SLIP_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_PAY_IN_SLIP_NUMBER_meaning != null) {
                                        if (db_lookup_PAY_IN_SLIP_NUMBER_meaning.equals(db_STG_PAY_IN_SLIP_NUMBER)) {
                                            String lookup_PAY_IN_SLIP_NUMBER_meaning = ",PAY_IN_SLIP_NUMBER LOOKUP," + db_lookup_PAY_IN_SLIP_NUMBER_meaning + "," + db_STG_PAY_IN_SLIP_NUMBER + ",Pass";
                                            section1_results.add(lookup_PAY_IN_SLIP_NUMBER_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAY_IN_SLIP_NUMBER LOOKUP" + "," + db_lookup_PAY_IN_SLIP_NUMBER_meaning + "," + db_STG_PAY_IN_SLIP_NUMBER + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String lookup_PAY_IN_SLIP_NUMBER_meaning = ",PAY_IN_SLIP_NUMBER LOOKUP," + db_lookup_PAY_IN_SLIP_NUMBER_meaning + "," + db_STG_PAY_IN_SLIP_NUMBER + ",Fail";
                                            section1_results.add(lookup_PAY_IN_SLIP_NUMBER_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAY_IN_SLIP_NUMBER LOOKUP" + "," + db_lookup_PAY_IN_SLIP_NUMBER_meaning + "," + db_STG_PAY_IN_SLIP_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }
                                } else {
                                    if (db_CONS_PAY_IN_SLIP_NUMBER.equals(db_STG_PAY_IN_SLIP_NUMBER)) {
                                        String STG_PAY_IN_SLIP_NUMBER = ",PAY_IN_SLIP_NUMBER," + db_STG_PAY_IN_SLIP_NUMBER + "," + db_CONS_PAY_IN_SLIP_NUMBER + ",Pass";
                                        section1_results.add(STG_PAY_IN_SLIP_NUMBER);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAY_IN_SLIP_NUMBER" + "," + db_STG_PAY_IN_SLIP_NUMBER + "," + db_CONS_PAY_IN_SLIP_NUMBER + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String STG_PAY_IN_SLIP_NUMBER = ",PAY_IN_SLIP_NUMBER," + db_STG_PAY_IN_SLIP_NUMBER + "," + db_CONS_PAY_IN_SLIP_NUMBER + ",Fail";
                                        section1_results.add(STG_PAY_IN_SLIP_NUMBER);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAY_IN_SLIP_NUMBER" + "," + db_STG_PAY_IN_SLIP_NUMBER + "," + db_CONS_PAY_IN_SLIP_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //------------------------ CARD_TYPE Validation -----------------
                                if (db_CONS_CARD_TYPE == (null)) {
                                    SQLResultset = SQLstmt.executeQuery(LandscapeGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'CARD_TYPE'" + fsh_source);
                                    //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'CARD_TYPE' and System = 'LAND'  and PATTERN = 'GLBilling'");
                                    while (SQLResultset.next()) {
                                        db_lookup_CARD_TYPE_meaning = SQLResultset.getString("MEANING");
                                    }

                                    if (db_lookup_CARD_TYPE_meaning.equals("null")) {
                                        String lookup_CARD_TYPE_meaning = ",CARD_TYPE LOOKUP," + "LookUp value not found" + "," + db_STG_CARD_TYPE + ",Fail";
                                        section1_results.add(lookup_CARD_TYPE_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CARD_TYPE LOOKUP" + "," + "LookUp value not found" + "," + db_STG_CARD_TYPE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_CARD_TYPE_meaning != null) {
                                        if (db_lookup_CARD_TYPE_meaning.equals(db_STG_CARD_TYPE)) {
                                            String lookup_CARD_TYPE_meaning = ",CARD_TYPE LOOKUP," + db_lookup_CARD_TYPE_meaning + "," + db_STG_CARD_TYPE + ",Pass";
                                            section1_results.add(lookup_CARD_TYPE_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CARD_TYPE LOOKUP" + "," + db_lookup_CARD_TYPE_meaning + "," + db_STG_CARD_TYPE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String lookup_CARD_TYPE_meaning = ",CARD_TYPE LOOKUP," + db_lookup_CARD_TYPE_meaning + "," + db_STG_CARD_TYPE + ",Fail";
                                            section1_results.add(lookup_CARD_TYPE_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CARD_TYPE LOOKUP" + "," + db_lookup_CARD_TYPE_meaning + "," + db_STG_CARD_TYPE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }
                                } else {
                                    SQLResultset = SQLstmt.executeQuery(LandscapeGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_CONS_CARD_TYPE + "' and LOOKUP_TYPE = 'CARD_TYPE'" + fsh_source);
                                    //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_CARD_TYPE + "' and LOOKUP_TYPE = 'CARD_TYPE' and System = 'LAND'  and PATTERN = 'GLBilling'");
                                    while (SQLResultset.next()) {
                                        db_lookup_CARD_TYPE_meaning = SQLResultset.getString("MEANING");
                                    }

                                    if (db_lookup_CARD_TYPE_meaning.equals("null")) {
                                        String lookup_CARD_TYPE_meaning = ",CARD_TYPE LOOKUP," + "LookUp value not found" + "," + db_STG_CARD_TYPE + ",Fail";
                                        section1_results.add(lookup_CARD_TYPE_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CARD_TYPE LOOKUP" + "," + "LookUp value not found" + "," + db_STG_CARD_TYPE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_CARD_TYPE_meaning != null) {
                                        if (db_lookup_CARD_TYPE_meaning.equals(db_STG_CARD_TYPE)) {
                                            String lookup_CARD_TYPE_meaning = ",CARD_TYPE LOOKUP," + db_lookup_CARD_TYPE_meaning + "," + db_STG_CARD_TYPE + ",Pass";
                                            section1_results.add(lookup_CARD_TYPE_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CARD_TYPE LOOKUP" + "," + db_lookup_CARD_TYPE_meaning + "," + db_STG_CARD_TYPE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String lookup_CARD_TYPE_meaning = ",CARD_TYPE LOOKUP," + db_lookup_CARD_TYPE_meaning + "," + db_STG_CARD_TYPE + ",Fail";
                                            section1_results.add(lookup_CARD_TYPE_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CARD_TYPE LOOKUP" + "," + db_lookup_CARD_TYPE_meaning + "," + db_STG_CARD_TYPE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }
                                }

                                //------------------------ CHANNEL Validation -----------------
                                if (db_CONS_CHANNEL == (null)) {
                                    SQLResultset = SQLstmt.executeQuery(LandscapeGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'CHANNEL'" + fsh_source);
                                    //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'CHANNEL' and System = 'LAND'  and PATTERN = 'GLBilling'");
                                    while (SQLResultset.next()) {
                                        db_lookup_CHANNEL_meaning = SQLResultset.getString("MEANING");
                                    }

                                    if (db_lookup_CHANNEL_meaning.equals("null")) {
                                        String lookup_CHANNEL_meaning = ",CHANNEL LOOKUP," + "LookUp value not found" + "," + db_STG_CHANNEL + ",Fail";
                                        section1_results.add(lookup_CHANNEL_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CHANNEL LOOKUP" + "," + "LookUp value not found" + "," + db_STG_CHANNEL + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_CHANNEL_meaning != null) {
                                        if (db_lookup_CHANNEL_meaning.equals(db_STG_CHANNEL)) {
                                            String lookup_CHANNEL_meaning = ",CHANNEL LOOKUP," + db_lookup_CHANNEL_meaning + "," + db_STG_CHANNEL + ",Pass";
                                            section1_results.add(lookup_CHANNEL_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CHANNEL LOOKUP" + "," + db_lookup_CHANNEL_meaning + "," + db_STG_CHANNEL + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String lookup_CHANNEL_meaning = ",CHANNEL LOOKUP," + db_lookup_CHANNEL_meaning + "," + db_STG_CHANNEL + ",Fail";
                                            section1_results.add(lookup_CHANNEL_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CHANNEL LOOKUP" + "," + db_lookup_CHANNEL_meaning + "," + db_STG_CHANNEL + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }
                                } else {
                                    SQLResultset = SQLstmt.executeQuery(LandscapeGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_CONS_CHANNEL + "' and LOOKUP_TYPE = 'CHANNEL'" + fsh_source);
                                    //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_CHANNEL + "' and LOOKUP_TYPE = 'CHANNEL' and System = 'LAND'  and PATTERN = 'GLBilling'");
                                    while (SQLResultset.next()) {
                                        db_lookup_CHANNEL_meaning = SQLResultset.getString("MEANING");
                                    }

                                    if (db_lookup_CHANNEL_meaning.equals("null")) {
                                        String lookup_CHANNEL_meaning = ",CHANNEL LOOKUP," + "LookUp value not found" + "," + db_STG_CHANNEL + ",Fail";
                                        section1_results.add(lookup_CHANNEL_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CHANNEL LOOKUP" + "," + "LookUp value not found" + "," + db_STG_CHANNEL + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_CHANNEL_meaning != null) {
                                        if (db_lookup_CHANNEL_meaning.equals(db_STG_CHANNEL)) {
                                            String lookup_CHANNEL_meaning = ",CHANNEL LOOKUP," + db_lookup_CHANNEL_meaning + "," + db_STG_CHANNEL + ",Pass";
                                            section1_results.add(lookup_CHANNEL_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CHANNEL LOOKUP" + "," + db_lookup_CHANNEL_meaning + "," + db_STG_CHANNEL + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String lookup_CHANNEL_meaning = ",CHANNEL LOOKUP," + db_lookup_CHANNEL_meaning + "," + db_STG_CHANNEL + ",Fail";
                                            section1_results.add(lookup_CHANNEL_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CHANNEL LOOKUP" + "," + db_lookup_CHANNEL_meaning + "," + db_STG_CHANNEL + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }
                                }


                                //------------------------ PAYMENT_TRANSACTION_TYPE_ID Validation -----------------
                                if (db_CONS_PAYMENT_TRANSACTION_TYPE_ID == (null)) {
                                    SQLResultset = SQLstmt.executeQuery(LandscapeGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'PAYMENT_TRANSACTION_TYPE_ID'" + fsh_source);
                                    //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'PAYMENT_TRANSACTION_TYPE_ID' and System = 'LAND'  and PATTERN = 'GLBilling'");
                                    while (SQLResultset.next()) {
                                        db_lookup_PAYMENT_TRANSACTION_TYPE_ID_meaning = SQLResultset.getString("MEANING");
                                    }

                                    if (db_lookup_PAYMENT_TRANSACTION_TYPE_ID_meaning.equals("null")) {
                                        String lookup_PAYMENT_TRANSACTION_TYPE_ID_meaning = ",PAYMENT_TRANSACTION_TYPE_ID LOOKUP," + "LookUp value not found" + "," + db_STG_PAYMENT_TRANSACTION_TYPE_ID + ",Fail";
                                        section1_results.add(lookup_PAYMENT_TRANSACTION_TYPE_ID_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAYMENT_TRANSACTION_TYPE_ID LOOKUP" + "," + "LookUp value not found" + "," + db_STG_PAYMENT_TRANSACTION_TYPE_ID + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_PAYMENT_TRANSACTION_TYPE_ID_meaning != null) {
                                        if (db_lookup_PAYMENT_TRANSACTION_TYPE_ID_meaning.equals(db_STG_PAYMENT_TRANSACTION_TYPE_ID)) {
                                            String lookup_PAYMENT_TRANSACTION_TYPE_ID_meaning = ",PAYMENT_TRANSACTION_TYPE_ID LOOKUP," + db_lookup_PAYMENT_TRANSACTION_TYPE_ID_meaning + "," + db_STG_PAYMENT_TRANSACTION_TYPE_ID + ",Pass";
                                            section1_results.add(lookup_PAYMENT_TRANSACTION_TYPE_ID_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAYMENT_TRANSACTION_TYPE_ID LOOKUP" + "," + db_lookup_PAYMENT_TRANSACTION_TYPE_ID_meaning + "," + db_STG_PAYMENT_TRANSACTION_TYPE_ID + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String lookup_PAYMENT_TRANSACTION_TYPE_ID_meaning = ",PAYMENT_TRANSACTION_TYPE_ID LOOKUP," + db_lookup_PAYMENT_TRANSACTION_TYPE_ID_meaning + "," + db_STG_PAYMENT_TRANSACTION_TYPE_ID + ",Fail";
                                            section1_results.add(lookup_PAYMENT_TRANSACTION_TYPE_ID_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAYMENT_TRANSACTION_TYPE_ID LOOKUP" + "," + db_lookup_PAYMENT_TRANSACTION_TYPE_ID_meaning + "," + db_STG_PAYMENT_TRANSACTION_TYPE_ID + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }
                                } else {
                                    SQLResultset = SQLstmt.executeQuery(LandscapeGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_CONS_PAYMENT_TRANSACTION_TYPE_ID + "' and LOOKUP_TYPE = 'PAYMENT_TRANSACTION_TYPE_ID'" + fsh_source);
                                    //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_PAYMENT_TRANSACTION_TYPE_ID + "' and LOOKUP_TYPE = 'PAYMENT_TRANSACTION_TYPE_ID' and System = 'LAND'  and PATTERN = 'GLBilling'");
                                    while (SQLResultset.next()) {
                                        db_lookup_PAYMENT_TRANSACTION_TYPE_ID_meaning = SQLResultset.getString("MEANING");
                                    }

                                    if (db_lookup_PAYMENT_TRANSACTION_TYPE_ID_meaning.equals("null")) {
                                        String lookup_PAYMENT_TRANSACTION_TYPE_ID_meaning = ",PAYMENT_TRANSACTION_TYPE_ID LOOKUP," + "LookUp value not found" + "," + db_STG_PAYMENT_TRANSACTION_TYPE_ID + ",Fail";
                                        section1_results.add(lookup_PAYMENT_TRANSACTION_TYPE_ID_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAYMENT_TRANSACTION_TYPE_ID LOOKUP" + "," + "LookUp value not found" + "," + db_STG_PAYMENT_TRANSACTION_TYPE_ID + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_PAYMENT_TRANSACTION_TYPE_ID_meaning != null) {
                                        if (db_lookup_PAYMENT_TRANSACTION_TYPE_ID_meaning.equals(db_STG_PAYMENT_TRANSACTION_TYPE_ID)) {
                                            String lookup_PAYMENT_TRANSACTION_TYPE_ID_meaning = ",PAYMENT_TRANSACTION_TYPE_ID LOOKUP," + db_lookup_PAYMENT_TRANSACTION_TYPE_ID_meaning + "," + db_STG_PAYMENT_TRANSACTION_TYPE_ID + ",Pass";
                                            section1_results.add(lookup_PAYMENT_TRANSACTION_TYPE_ID_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAYMENT_TRANSACTION_TYPE_ID LOOKUP" + "," + db_lookup_PAYMENT_TRANSACTION_TYPE_ID_meaning + "," + db_STG_PAYMENT_TRANSACTION_TYPE_ID + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String lookup_PAYMENT_TRANSACTION_TYPE_ID_meaning = ",PAYMENT_TRANSACTION_TYPE_ID LOOKUP," + db_lookup_PAYMENT_TRANSACTION_TYPE_ID_meaning + "," + db_STG_PAYMENT_TRANSACTION_TYPE_ID + ",Fail";
                                            section1_results.add(lookup_PAYMENT_TRANSACTION_TYPE_ID_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAYMENT_TRANSACTION_TYPE_ID LOOKUP" + "," + db_lookup_PAYMENT_TRANSACTION_TYPE_ID_meaning + "," + db_STG_PAYMENT_TRANSACTION_TYPE_ID + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }
                                }

                                //------------------------ BACS_NARRATIVE Validation -----------------
                                if (db_CONS_BACS_NARRATIVE == (null)) {
                                    SQLResultset = SQLstmt.executeQuery(LandscapeGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'BACS_NARRATIVE'" + fsh_source);
                                    //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'BACS_NARRATIVE' and System = 'LAND'  and PATTERN = 'GLBilling'");
                                    while (SQLResultset.next()) {
                                        db_lookup_BACS_NARRATIVE_meaning = SQLResultset.getString("MEANING");
                                    }

                                    if (db_lookup_BACS_NARRATIVE_meaning.equals("null")) {
                                        String lookup_BACS_NARRATIVE_meaning = ",BACS_NARRATIVE LOOKUP," + "LookUp value not found" + "," + db_STG_BACS_NARRATIVE + ",Fail";
                                        section1_results.add(lookup_BACS_NARRATIVE_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BACS_NARRATIVE LOOKUP" + "," + "LookUp value not found" + "," + db_STG_BACS_NARRATIVE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_BACS_NARRATIVE_meaning != null) {
                                        if (db_lookup_BACS_NARRATIVE_meaning.equals(db_STG_BACS_NARRATIVE)) {
                                            String lookup_BACS_NARRATIVE_meaning = ",BACS_NARRATIVE LOOKUP," + db_lookup_BACS_NARRATIVE_meaning + "," + db_STG_BACS_NARRATIVE + ",Pass";
                                            section1_results.add(lookup_BACS_NARRATIVE_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BACS_NARRATIVE LOOKUP" + "," + db_lookup_BACS_NARRATIVE_meaning + "," + db_STG_BACS_NARRATIVE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String lookup_BACS_NARRATIVE_meaning = ",BACS_NARRATIVE LOOKUP," + db_lookup_BACS_NARRATIVE_meaning + "," + db_STG_BACS_NARRATIVE + ",Fail";
                                            section1_results.add(lookup_BACS_NARRATIVE_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BACS_NARRATIVE LOOKUP" + "," + db_lookup_BACS_NARRATIVE_meaning + "," + db_STG_BACS_NARRATIVE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }
                                } else {
                                    if (db_CONS_BACS_NARRATIVE.equals(db_STG_BACS_NARRATIVE)) {
                                        String STG_BACS_NARRATIVE = ",BACS_NARRATIVE," + db_STG_BACS_NARRATIVE + "," + db_CONS_BACS_NARRATIVE + ",Pass";
                                        section1_results.add(STG_BACS_NARRATIVE);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BACS_NARRATIVE" + "," + db_STG_BACS_NARRATIVE + "," + db_CONS_BACS_NARRATIVE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String STG_BACS_NARRATIVE = ",BACS_NARRATIVE," + db_STG_BACS_NARRATIVE + "," + db_CONS_BACS_NARRATIVE + ",Fail";
                                        section1_results.add(STG_BACS_NARRATIVE);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BACS_NARRATIVE" + "," + db_STG_BACS_NARRATIVE + "," + db_CONS_BACS_NARRATIVE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //------------------------ ORDER_NUMBER Validation -----------------
                                if (db_CONS_ORDER_NUMBER == (null)) {
                                    SQLResultset = SQLstmt.executeQuery(LandscapeGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'ORDER_NUMBER'" + fsh_source);
                                    //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'ORDER_NUMBER' and System = 'LAND'  and PATTERN = 'GLBilling'");
                                    while (SQLResultset.next()) {
                                        db_lookup_ORDER_NUMBER_meaning = SQLResultset.getString("MEANING");
                                    }

                                    if (db_lookup_ORDER_NUMBER_meaning.equals("null")) {
                                        String lookup_ORDER_NUMBER_meaning = ",ORDER_NUMBER LOOKUP," + "LookUp value not found" + "," + db_STG_ORDER_NUMBER + ",Fail";
                                        section1_results.add(lookup_ORDER_NUMBER_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ORDER_NUMBER LOOKUP" + "," + "LookUp value not found" + "," + db_STG_ORDER_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_ORDER_NUMBER_meaning != null) {
                                        if (db_lookup_ORDER_NUMBER_meaning.equals(db_STG_ORDER_NUMBER)) {
                                            String lookup_ORDER_NUMBER_meaning = ",ORDER_NUMBER LOOKUP," + db_lookup_ORDER_NUMBER_meaning + "," + db_STG_ORDER_NUMBER + ",Pass";
                                            section1_results.add(lookup_ORDER_NUMBER_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ORDER_NUMBER LOOKUP" + "," + db_lookup_ORDER_NUMBER_meaning + "," + db_STG_ORDER_NUMBER + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String lookup_ORDER_NUMBER_meaning = ",ORDER_NUMBER LOOKUP," + db_lookup_ORDER_NUMBER_meaning + "," + db_STG_ORDER_NUMBER + ",Fail";
                                            section1_results.add(lookup_ORDER_NUMBER_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ORDER_NUMBER LOOKUP" + "," + db_lookup_ORDER_NUMBER_meaning + "," + db_STG_ORDER_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }
                                } else {
                                    if (db_CONS_ORDER_NUMBER.equals(db_STG_ORDER_NUMBER)) {
                                        String STG_ORDER_NUMBER = ",ORDER_NUMBER," + db_STG_ORDER_NUMBER + "," + db_CONS_ORDER_NUMBER + ",Pass";
                                        section1_results.add(STG_ORDER_NUMBER);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ORDER_NUMBER" + "," + db_STG_ORDER_NUMBER + "," + db_CONS_ORDER_NUMBER + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String STG_ORDER_NUMBER = ",ORDER_NUMBER," + db_STG_ORDER_NUMBER + "," + db_CONS_ORDER_NUMBER + ",Fail";
                                        section1_results.add(STG_ORDER_NUMBER);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ORDER_NUMBER" + "," + db_STG_ORDER_NUMBER + "," + db_CONS_ORDER_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //------------------------ REVERSAL_INDICATOR Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(LandscapeGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_CONS_REVERSAL_INDICATOR + "' and LOOKUP_TYPE = 'REVERSAL_INDICATOR'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_REVERSAL_INDICATOR + "' and LOOKUP_TYPE = 'REVERSAL_INDICATOR' and System = 'LAND' and pattern = 'GLBilling'");
                                while (SQLResultset.next()) {
                                    db_lookup_REVERSAL_INDICATOR_meaning = SQLResultset.getString("MEANING");
                                }

                                if (db_lookup_REVERSAL_INDICATOR_meaning.equals("null")) {
                                    String lookup_reversal_indicator_meaning = ",REVERSAL_INDICATOR LOOKUP," + "LookUp value not found" + "," + db_STG_REVERSAL_INDICATOR + ",Fail";
                                    section1_results.add(lookup_reversal_indicator_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",REVERSAL_INDICATOR LOOKUP" + "," + "LookUp value not found" + "," + db_STG_REVERSAL_INDICATOR + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_lookup_REVERSAL_INDICATOR_meaning != null) {
                                    if (db_lookup_REVERSAL_INDICATOR_meaning.equals(db_STG_REVERSAL_INDICATOR)) {
                                        String lookup_reversal_indicator_meaning = ",REVERSAL_INDICATOR LOOKUP," + db_lookup_REVERSAL_INDICATOR_meaning + "," + db_STG_REVERSAL_INDICATOR + ",Pass";
                                        section1_results.add(lookup_reversal_indicator_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",REVERSAL_INDICATOR LOOKUP" + "," + db_lookup_REVERSAL_INDICATOR_meaning + "," + db_STG_REVERSAL_INDICATOR + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String lookup_reversal_indicator_meaning = ",REVERSAL_INDICATOR LOOKUP," + db_lookup_REVERSAL_INDICATOR_meaning + "," + db_STG_REVERSAL_INDICATOR + ",Fail";
                                        section1_results.add(lookup_reversal_indicator_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",REVERSAL_INDICATOR LOOKUP" + "," + db_lookup_REVERSAL_INDICATOR_meaning + "," + db_STG_REVERSAL_INDICATOR + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }


                                //------------------------ EVENT_CODE Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(LandscapeGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'EVENT_CODE'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'EVENT_CODE' and System = 'LAND'  and PATTERN = 'GLBilling'");
                                while (SQLResultset.next()) {
                                    db_lookup_EVENT_CODE_meaning = SQLResultset.getString("MEANING");
                                }

                                if (db_lookup_EVENT_CODE_meaning.equals("null")) {
                                    String lookup_EVENT_CODE_meaning = ",EVENT_CODE LOOKUP," + "LookUp value not found" + "," + db_STG_EVENT_CODE + ",Fail";
                                    section1_results.add(lookup_EVENT_CODE_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",EVENT_CODE LOOKUP" + "," + "LookUp value not found" + "," + db_STG_EVENT_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_lookup_EVENT_CODE_meaning != null) {
                                    if (db_lookup_EVENT_CODE_meaning.equals(db_STG_EVENT_CODE)) {
                                        String lookup_EVENT_CODE_meaning = ",EVENT_CODE LOOKUP," + db_lookup_EVENT_CODE_meaning + "," + db_STG_EVENT_CODE + ",Pass";
                                        section1_results.add(lookup_EVENT_CODE_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",EVENT_CODE LOOKUP" + "," + db_lookup_EVENT_CODE_meaning + "," + db_STG_EVENT_CODE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String lookup_EVENT_CODE_meaning = ",EVENT_CODE LOOKUP," + db_lookup_EVENT_CODE_meaning + "," + db_STG_EVENT_CODE + ",Fail";
                                        section1_results.add(lookup_EVENT_CODE_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",EVENT_CODE LOOKUP" + "," + db_lookup_EVENT_CODE_meaning + "," + db_STG_EVENT_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //------------------------ ENTITY_TYPE_CODE Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(LandscapeGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'ENTITY_TYPE_CODE'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'ENTITY_TYPE_CODE' and System = 'LAND'  and PATTERN = 'GLBilling'");
                                while (SQLResultset.next()) {
                                    db_lookup_ENTITY_TYPE_CODE_meaning = SQLResultset.getString("MEANING");
                                }

                                if (db_lookup_ENTITY_TYPE_CODE_meaning.equals("null")) {
                                    String lookup_ENTITY_TYPE_CODE_meaning = ",ENTITY_TYPE_CODE LOOKUP," + "LookUp value not found" + "," + db_STG_ENTITY_TYPE_CODE + ",Fail";
                                    section1_results.add(lookup_ENTITY_TYPE_CODE_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ENTITY_TYPE_CODE LOOKUP" + "," + "LookUp value not found" + "," + db_STG_ENTITY_TYPE_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_lookup_ENTITY_TYPE_CODE_meaning != null) {
                                    if (db_lookup_ENTITY_TYPE_CODE_meaning.equals(db_STG_ENTITY_TYPE_CODE)) {
                                        String lookup_ENTITY_TYPE_CODE_meaning = ",ENTITY_TYPE_CODE LOOKUP," + db_lookup_ENTITY_TYPE_CODE_meaning + "," + db_STG_ENTITY_TYPE_CODE + ",Pass";
                                        section1_results.add(lookup_ENTITY_TYPE_CODE_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ENTITY_TYPE_CODE LOOKUP" + "," + db_lookup_ENTITY_TYPE_CODE_meaning + "," + db_STG_ENTITY_TYPE_CODE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String lookup_ENTITY_TYPE_CODE_meaning = ",ENTITY_TYPE_CODE LOOKUP," + db_lookup_ENTITY_TYPE_CODE_meaning + "," + db_STG_ENTITY_TYPE_CODE + ",Fail";
                                        section1_results.add(lookup_ENTITY_TYPE_CODE_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ENTITY_TYPE_CODE LOOKUP" + "," + db_lookup_ENTITY_TYPE_CODE_meaning + "," + db_STG_ENTITY_TYPE_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }


                                //------------------------ SUMMARY_FLAG Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(LandscapeGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_CONS_SOURCE + "' and LOOKUP_TYPE = 'SUMMARISE_DATA_FLAG'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_SOURCE + "' and LOOKUP_TYPE = 'SUMMARISE_DATA_FLAG' and System = 'LAND'  and PATTERN = 'GLBilling'");
                                while (SQLResultset.next()) {
                                    db_lookup_SUMMARY_FLAG_meaning = SQLResultset.getString("MEANING");
                                }

                                if (db_lookup_SUMMARY_FLAG_meaning.equals("null")) {
                                    String lookup_SUMMARY_FLAG_meaning = ",SUMMARY_FLAG LOOKUP," + "LookUp value not found" + "," + db_STG_SUMMARY_FLAG + ",Fail";
                                    section1_results.add(lookup_SUMMARY_FLAG_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SUMMARY_FLAG LOOKUP" + "," + "LookUp value not found" + "," + db_STG_SUMMARY_FLAG + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_lookup_SUMMARY_FLAG_meaning != null) {
                                    if (db_lookup_SUMMARY_FLAG_meaning.equals(db_STG_SUMMARY_FLAG)) {
                                        String lookup_SUMMARY_FLAG_meaning = ",SUMMARY_FLAG LOOKUP," + db_lookup_SUMMARY_FLAG_meaning + "," + db_STG_SUMMARY_FLAG + ",Pass";
                                        section1_results.add(lookup_SUMMARY_FLAG_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SUMMARY_FLAG LOOKUP" + "," + db_lookup_SUMMARY_FLAG_meaning + "," + db_STG_SUMMARY_FLAG + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String lookup_SUMMARY_FLAG_meaning = ",SUMMARY_FLAG LOOKUP," + db_lookup_SUMMARY_FLAG_meaning + "," + db_STG_SUMMARY_FLAG + ",Fail";
                                        section1_results.add(lookup_SUMMARY_FLAG_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SUMMARY_FLAG LOOKUP" + "," + db_lookup_SUMMARY_FLAG_meaning + "," + db_STG_SUMMARY_FLAG + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //------------------------ CREDIT_IND Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(LandscapeGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'CREDIT_IND'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'CREDIT_IND' and System = 'LAND'  and PATTERN = 'GLBilling'");
                                while (SQLResultset.next()) {
                                    db_lookup_credit_ind_meaning = SQLResultset.getString("MEANING");
                                }

                                if (db_lookup_credit_ind_meaning.equals("null")) {
                                    String lookup_credit_ind_meaning = ",CREDIT_INDICATOR LOOKUP," + "LookUp value not found" + "," + db_STG_CREDIT_IND + ",Fail";
                                    section1_results.add(lookup_credit_ind_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CREDIT_INDICATOR LOOKUP" + "," + "LookUp value not found" + "," + db_STG_CREDIT_IND + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_lookup_credit_ind_meaning != null) {
                                    if (db_lookup_credit_ind_meaning.equals(db_STG_CREDIT_IND)) {
                                        String lookup_credit_ind_meaning = ",CREDIT_INDICATOR LOOKUP," + db_lookup_credit_ind_meaning + "," + db_STG_CREDIT_IND + ",Pass";
                                        section1_results.add(lookup_credit_ind_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CREDIT_INDICATOR LOOKUP" + "," + db_lookup_credit_ind_meaning + "," + db_STG_CREDIT_IND + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String lookup_credit_ind_meaning = ",CREDIT_INDICATOR LOOKUP," + db_lookup_credit_ind_meaning + "," + db_STG_CREDIT_IND + ",Fail";
                                        section1_results.add(lookup_credit_ind_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CREDIT_INDICATOR LOOKUP" + "," + db_lookup_credit_ind_meaning + "," + db_STG_CREDIT_IND + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }


                                //------------------------ BANK_ACC Validation -----------------
                                String db_lookup_BANK_ACC_fsh_lookup_meaning = "null";
                                String db_lookup_TRANSACTION_SUBTYPE_fsh_lookup_meaning = "null";
                                String db_lookup_BANK_ACCOUNT_NUM_EXC_1_fsh_lookup_meaning = "null";
                                String db_lookup_BANK_ACCOUNT_NUM_EXC_2_fsh_lookup_meaning = "null";
                                String db_lookup_BANK_ACC_lookup_meaning = "null";

                                SQLResultset = SQLstmt.executeQuery(LandscapeGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_CONS_BANK_ACC + "' and LOOKUP_TYPE = 'BANK_ACC'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_BANK_ACC + "' and LOOKUP_TYPE = 'BANK_ACC' and system = 'LAND' and pattern = 'GLBilling'");
                                while (SQLResultset.next()) {
                                    db_lookup_BANK_ACC_fsh_lookup_meaning = SQLResultset.getString("MEANING");
                                }

                                SQLResultset = SQLstmt.executeQuery(LandscapeGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_CONS_TRANSACTION_SUBTYPE + "' and LOOKUP_TYPE = 'TRANSACTION_SUBTYPE'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_TRANSACTION_SUBTYPE + "' and LOOKUP_TYPE = 'TRANSACTION_SUBTYPE' and system = 'LAND' and pattern = 'GLBilling'");
                                while (SQLResultset.next()) {
                                    db_lookup_TRANSACTION_SUBTYPE_fsh_lookup_meaning = SQLResultset.getString("MEANING");
                                }

                                SQLResultset = SQLstmt.executeQuery(LandscapeGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = 'Write Off' and LOOKUP_TYPE = 'BANK_ACCOUNT_NUM_EXC_1'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_TYPE = 'BANK_ACCOUNT_NUM_EXC_1' and LOOKUP_CODE = 'Write Off' and system = 'LAND' and pattern = 'GLBilling'");
                                while (SQLResultset.next()) {
                                    db_lookup_BANK_ACCOUNT_NUM_EXC_1_fsh_lookup_meaning = SQLResultset.getString("MEANING");
                                }

                                SQLResultset = SQLstmt.executeQuery(LandscapeGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = 'Allocation' and LOOKUP_TYPE = 'BANK_ACCOUNT_NUM_EXC_2'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_TYPE = 'BANK_ACCOUNT_NUM_EXC_2' and LOOKUP_CODE = 'Allocation' and system = 'LAND' and pattern = 'GLBilling'");
                                while (SQLResultset.next()) {
                                    db_lookup_BANK_ACCOUNT_NUM_EXC_2_fsh_lookup_meaning = SQLResultset.getString("MEANING");
                                }


                                if (db_lookup_BANK_ACC_fsh_lookup_meaning.equals("null") && (db_lookup_TRANSACTION_SUBTYPE_fsh_lookup_meaning != db_lookup_BANK_ACCOUNT_NUM_EXC_1_fsh_lookup_meaning || db_lookup_TRANSACTION_SUBTYPE_fsh_lookup_meaning != db_lookup_BANK_ACCOUNT_NUM_EXC_2_fsh_lookup_meaning)) {
                                    db_lookup_BANK_ACC_lookup_meaning = "Error: Missing <BANK_ACC> for Transaction Sub Type <TRANSACTION_SUBTYPE> value.";
                                    String lookup_BANK_ACC_lookup_meaning = ",CHEQUE_NUMBER," + db_lookup_BANK_ACC_lookup_meaning + "," + db_lookup_BANK_ACC_lookup_meaning + ",Pass";
                                    section1_results.add(lookup_BANK_ACC_lookup_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CHEQUE_NUMBER" + "," + db_lookup_BANK_ACC_lookup_meaning + "," + db_lookup_BANK_ACC_lookup_meaning + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);

                                } else if (db_lookup_BANK_ACC_fsh_lookup_meaning.equals("null") && (db_lookup_TRANSACTION_SUBTYPE_fsh_lookup_meaning.equals("db_lookup_BANK_ACCOUNT_NUM_EXC_1_fsh_lookup_meaning") || db_lookup_TRANSACTION_SUBTYPE_fsh_lookup_meaning.equals("db_lookup_BANK_ACCOUNT_NUM_EXC_2_fsh_lookup_meaning"))) {

                                    SQLResultset = SQLstmt.executeQuery(LandscapeGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'BANK_ACC'" + fsh_source);
                                    //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'BANK_ACC' and System = 'LAND' and PATTERN = 'GLBilling'");
                                    while (SQLResultset.next()) {
                                        db_lookup_BANK_ACC_lookup_meaning = SQLResultset.getString("MEANING");
                                    }

                                    if (db_lookup_BANK_ACC_lookup_meaning.equals("null")) {
                                        String lookup_BANK_ACC_lookup_meaning = ",BANK_ACC LOOKUP," + "LookUp value not found" + "," + db_STG_BANK_ACC + ",Fail";
                                        section1_results.add(lookup_BANK_ACC_lookup_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BANK_ACC LOOKUP" + "," + "LookUp value not found" + "," + db_STG_BANK_ACC + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;

                                    } else if (db_lookup_BANK_ACC_lookup_meaning != null) {
                                        if (db_lookup_BANK_ACC_lookup_meaning.equals(db_STG_BANK_ACC)) {
                                            String lookup_BANK_ACC_lookup_meaning = ",BANK_ACC LOOKUP," + db_lookup_BANK_ACC_lookup_meaning + "," + db_STG_BANK_ACC + ",Pass";
                                            section1_results.add(lookup_BANK_ACC_lookup_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BANK_ACC LOOKUP" + "," + db_lookup_BANK_ACC_lookup_meaning + "," + db_STG_BANK_ACC + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String lookup_BANK_ACC_lookup_meaning = ",BANK_ACC LOOKUP," + db_lookup_BANK_ACC_lookup_meaning + "," + db_STG_BANK_ACC + ",Fail";
                                            section1_results.add(lookup_BANK_ACC_lookup_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BANK_ACC LOOKUP" + "," + db_lookup_BANK_ACC_lookup_meaning + "," + db_STG_BANK_ACC + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }

                                } else if (db_lookup_BANK_ACC_fsh_lookup_meaning != "null") {

                                    if (db_CONS_BANK_ACC.equals(db_STG_BANK_ACC)) {
                                        String STG_BANK_ACC = ",BANK_ACC," + db_STG_BANK_ACC + "," + db_CONS_BANK_ACC + ",Pass";
                                        section1_results.add(STG_BANK_ACC);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BANK_ACC" + "," + db_STG_BANK_ACC + "," + db_CONS_BANK_ACC + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String STG_BANK_ACC = ",BANK_ACC," + db_STG_BANK_ACC + "," + db_CONS_BANK_ACC + ",Fail";
                                        section1_results.add(STG_BANK_ACC);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BANK_ACC" + "," + db_STG_BANK_ACC + "," + db_CONS_BANK_ACC + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }


                                //------------------------ CHEQUE_NUMBER Validation -----------------
                                String db_lookup_V_PAYMENT_METHOD_fsh_lookup_meaning = "null";
                                String db_lookup_CHEQUE_NUMBER_lookup_meaning = "null";


                                SQLResultset = SQLstmt.executeQuery(LandscapeGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_CONS_PAYMENT_METHOD + "' and LOOKUP_TYPE = 'PAYMENT_METHOD'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_PAYMENT_METHOD + "' and LOOKUP_TYPE = 'PAYMENT_METHOD' and system = 'LAND' and pattern = 'GLBilling'");
                                while (SQLResultset.next()) {
                                    db_lookup_V_PAYMENT_METHOD_fsh_lookup_meaning = SQLResultset.getString("MEANING");
                                }
                                if (db_lookup_V_PAYMENT_METHOD_fsh_lookup_meaning != null) {
                                    if ((db_lookup_V_PAYMENT_METHOD_fsh_lookup_meaning.equals("Cheque") || db_lookup_V_PAYMENT_METHOD_fsh_lookup_meaning.equals("System Cheque")) && db_CONS_CHEQUE_NUMBER == null) {
                                        db_lookup_CHEQUE_NUMBER_lookup_meaning = "Error: Missing <CHEQUE_NUMBER> for Payment Method <PAYMENT_METHOD> value.";
                                        String lookup_CHEQUE_NUMBER_lookup_meaning = ",CHEQUE_NUMBER," + db_lookup_CHEQUE_NUMBER_lookup_meaning + "," + db_lookup_CHEQUE_NUMBER_lookup_meaning + ",Pass";
                                        section1_results.add(lookup_CHEQUE_NUMBER_lookup_meaning);

                                    } else if ((db_lookup_V_PAYMENT_METHOD_fsh_lookup_meaning.equals("Cheque") || db_lookup_V_PAYMENT_METHOD_fsh_lookup_meaning.equals("System Cheque")) && db_CONS_CHEQUE_NUMBER != "null") {
                                        if (db_CONS_CHEQUE_NUMBER.equals(db_STG_CHEQUE_NUMBER)) {
                                            String STG_CHEQUE_NUMBER = ",CHEQUE_NUMBER," + db_STG_CHEQUE_NUMBER + "," + db_CONS_CHEQUE_NUMBER + ",Pass";
                                            section1_results.add(STG_CHEQUE_NUMBER);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CHEQUE_NUMBER" + "," + db_STG_CHEQUE_NUMBER + "," + db_CONS_CHEQUE_NUMBER + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String STG_CHEQUE_NUMBER = ",CHEQUE_NUMBER," + db_STG_CHEQUE_NUMBER + "," + db_CONS_CHEQUE_NUMBER + ",Fail";
                                            section1_results.add(STG_CHEQUE_NUMBER);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CHEQUE_NUMBER" + "," + db_STG_CHEQUE_NUMBER + "," + db_CONS_CHEQUE_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }

                                    } else if (db_lookup_V_PAYMENT_METHOD_fsh_lookup_meaning != "Cheque" || db_lookup_V_PAYMENT_METHOD_fsh_lookup_meaning != "System Cheque") {
                                        SQLResultset = SQLstmt.executeQuery(LandscapeGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'CHEQUE_NUMBER'" + fsh_source);
                                        //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'CHEQUE_NUMBER' and System = 'LAND' and PATTERN = 'GLBilling'");
                                        while (SQLResultset.next()) {
                                            db_lookup_CHEQUE_NUMBER_lookup_meaning = SQLResultset.getString("MEANING");
                                        }

                                        if (db_lookup_CHEQUE_NUMBER_lookup_meaning.equals("null")) {
                                            String lookup_CHEQUE_NUMBER_lookup_meaning = ",CHEQUE_NUMBER LOOKUP," + "LookUp value not found" + "," + db_STG_CHEQUE_NUMBER + ",Fail";
                                            section1_results.add(lookup_CHEQUE_NUMBER_lookup_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CHEQUE_NUMBER LOOKUP" + "," + "LookUp value not found" + "," + db_STG_CHEQUE_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        } else if (db_lookup_CHEQUE_NUMBER_lookup_meaning != null) {
                                            if (db_lookup_CHEQUE_NUMBER_lookup_meaning.equals(db_STG_CHEQUE_NUMBER)) {
                                                String lookup_CHEQUE_NUMBER_lookup_meaning = ",CHEQUE_NUMBER LOOKUP," + db_lookup_CHEQUE_NUMBER_lookup_meaning + "," + db_STG_CHEQUE_NUMBER + ",Pass";
                                                section1_results.add(lookup_CHEQUE_NUMBER_lookup_meaning);
                                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CHEQUE_NUMBER LOOKUP" + "," + db_lookup_CHEQUE_NUMBER_lookup_meaning + "," + db_STG_CHEQUE_NUMBER + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String lookup_CHEQUE_NUMBER_lookup_meaning = ",CHEQUE_NUMBER LOOKUP," + db_lookup_CHEQUE_NUMBER_lookup_meaning + "," + db_STG_CHEQUE_NUMBER + ",Fail";
                                                section1_results.add(lookup_CHEQUE_NUMBER_lookup_meaning);
                                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CHEQUE_NUMBER LOOKUP" + "," + db_lookup_CHEQUE_NUMBER_lookup_meaning + "," + db_STG_CHEQUE_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }
                                        }
                                    }
                                } else {
                                    String lookup_CHEQUE_NUMBER_lookup_meaning = ",CHEQUE_NUMBER - V_PAYMENT_METHOD having a Null value," + db_lookup_V_PAYMENT_METHOD_fsh_lookup_meaning + "," + db_lookup_V_PAYMENT_METHOD_fsh_lookup_meaning + ",Fail";
                                    section1_results.add(lookup_CHEQUE_NUMBER_lookup_meaning);
                                }

                                //------------------------ PAY_IN_SLIP_NUMBER Validation -----------------
                                String db_lookup_V_PAY_IN_SLIP_NUM_REQUIRED_fsh_lookup_meaning = "null";
                                String db_lookup_PAY_IN_SLIP_NUMBER_lookup_meaning = "null";


                                if (db_CONS_CHEQUE_NUMBER != "null") {
                                    db_lookup_V_PAY_IN_SLIP_NUM_REQUIRED_fsh_lookup_meaning = "Y";
                                } else {
                                    db_lookup_V_PAY_IN_SLIP_NUM_REQUIRED_fsh_lookup_meaning = "N";
                                }

                                if (db_CONS_PAY_IN_SLIP_NUMBER == (null) && db_lookup_V_PAY_IN_SLIP_NUM_REQUIRED_fsh_lookup_meaning.equals("Y")) {
                                    db_lookup_PAY_IN_SLIP_NUMBER_lookup_meaning = "Error: Missing <PAY_IN_SLIP_NUMBER> for Cheque Number <CHEQUE_NUMBER> value.";
                                    String lookup_PAY_IN_SLIP_NUMBER_lookup_meaning = ",PAY_IN_SLIP_NUMBER," + db_lookup_PAY_IN_SLIP_NUMBER_lookup_meaning + "," + db_lookup_PAY_IN_SLIP_NUMBER_lookup_meaning + ",Pass";
                                    section1_results.add(lookup_PAY_IN_SLIP_NUMBER_lookup_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAY_IN_SLIP_NUMBER" + "," + db_lookup_PAY_IN_SLIP_NUMBER_lookup_meaning + "," + db_lookup_PAY_IN_SLIP_NUMBER_lookup_meaning + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);

                                } else if (db_CONS_PAY_IN_SLIP_NUMBER == (null) && db_lookup_V_PAY_IN_SLIP_NUM_REQUIRED_fsh_lookup_meaning.equals("N")) {
                                    SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'PAY_IN_SLIP_NUMBER' and System = 'LAND' and pattern = 'GLBilling' ");
                                    while (SQLResultset.next()) {
                                        db_lookup_PAY_IN_SLIP_NUMBER_lookup_meaning = SQLResultset.getString("MEANING");
                                    }

                                    if (db_lookup_PAY_IN_SLIP_NUMBER_lookup_meaning == (null)) {
                                        String lookup_PAY_IN_SLIP_NUMBER_lookup_meaning = ",PAY_IN_SLIP_NUMBER LOOKUP," + "LookUp value not found" + "," + db_STG_PAY_IN_SLIP_NUMBER + ",Fail";
                                        section1_results.add(lookup_PAY_IN_SLIP_NUMBER_lookup_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAY_IN_SLIP_NUMBER LOOKUP" + "," + "LookUp value not found" + "," + db_STG_PAY_IN_SLIP_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_PAY_IN_SLIP_NUMBER_lookup_meaning != null) {
                                        if (db_lookup_PAY_IN_SLIP_NUMBER_lookup_meaning.equals(db_STG_PAY_IN_SLIP_NUMBER)) {
                                            String lookup_PAY_IN_SLIP_NUMBER_lookup_meaning = ",PAY_IN_SLIP_NUMBER LOOKUP," + db_lookup_PAY_IN_SLIP_NUMBER_lookup_meaning + "," + db_STG_PAY_IN_SLIP_NUMBER + ",Pass";
                                            section1_results.add(lookup_PAY_IN_SLIP_NUMBER_lookup_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAY_IN_SLIP_NUMBER LOOKUP" + "," + db_lookup_PAY_IN_SLIP_NUMBER_lookup_meaning + "," + db_STG_PAY_IN_SLIP_NUMBER + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String lookup_PAY_IN_SLIP_NUMBER_lookup_meaning = ",PAY_IN_SLIP_NUMBER LOOKUP," + db_lookup_PAY_IN_SLIP_NUMBER_lookup_meaning + "," + db_STG_PAY_IN_SLIP_NUMBER + ",Fail";
                                            section1_results.add(lookup_PAY_IN_SLIP_NUMBER_lookup_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAY_IN_SLIP_NUMBER LOOKUP" + "," + db_lookup_PAY_IN_SLIP_NUMBER_lookup_meaning + "," + db_STG_PAY_IN_SLIP_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }

                                } else if (db_lookup_PAY_IN_SLIP_NUMBER_lookup_meaning != "null") {
                                    if (db_CONS_PAY_IN_SLIP_NUMBER.equals(db_STG_PAY_IN_SLIP_NUMBER)) {
                                        String STG_PAY_IN_SLIP_NUMBER = ",PAY_IN_SLIP_NUMBER ," + db_CONS_PAY_IN_SLIP_NUMBER + "," + db_STG_PAY_IN_SLIP_NUMBER + ",Pass";
                                        section1_results.add(STG_PAY_IN_SLIP_NUMBER);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAY_IN_SLIP_NUMBER" + "," + db_CONS_PAY_IN_SLIP_NUMBER + "," + db_STG_PAY_IN_SLIP_NUMBER + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String STG_PAY_IN_SLIP_NUMBER = ",PAY_IN_SLIP_NUMBER ," + db_CONS_PAY_IN_SLIP_NUMBER + "," + db_STG_PAY_IN_SLIP_NUMBER + ",Fail";
                                        section1_results.add(STG_PAY_IN_SLIP_NUMBER);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAY_IN_SLIP_NUMBER" + "," + db_CONS_PAY_IN_SLIP_NUMBER + "," + db_STG_PAY_IN_SLIP_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }

                                }


                                //------------------------ CARD_NARRATIVE Validation -----------------
                                String db_lookup_V_CARD_NARRATIVE_REQUIRED_fsh_lookup_meaning = "null";
                                String db_lookup_CARD_NARRATIVE_lookup_meaning = "null";


                                if (db_STG_PAYMENT_METHOD.equalsIgnoreCase("Card")) {
                                    db_lookup_V_CARD_NARRATIVE_REQUIRED_fsh_lookup_meaning = "Y";
                                } else {
                                    db_lookup_V_CARD_NARRATIVE_REQUIRED_fsh_lookup_meaning = "N";
                                }

                                if (db_lookup_V_CARD_NARRATIVE_REQUIRED_fsh_lookup_meaning.equals("Y") && db_CONS_CARD_NARRATIVE == (null)) {
                                    db_lookup_CARD_NARRATIVE_lookup_meaning = "Error: Missing <CARD_NARRATIVE> for payment method <PAYMENT_METHOD> value.";
                                    String lookup_CARD_NARRATIVE_lookup_meaning = ",CARD_NARRATIVE," + db_lookup_CARD_NARRATIVE_lookup_meaning + "," + db_STG_CARD_NARRATIVE + ",Pass";
                                    section1_results.add(lookup_CARD_NARRATIVE_lookup_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CARD_NARRATIVE" + "," + db_lookup_CARD_NARRATIVE_lookup_meaning + "," + db_STG_CARD_NARRATIVE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);

                                } else if (db_lookup_V_CARD_NARRATIVE_REQUIRED_fsh_lookup_meaning.equals("Y") && db_CONS_CARD_NARRATIVE != ("null") && db_CONS_CARD_TYPE != "AM") {

                                    SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_CARD_NARRATIVE + "' and LOOKUP_TYPE = 'CARD_NARRATIVE_NOT_AM' and System = 'LAND' and pattern = 'GLBilling' ");
                                    while (SQLResultset.next()) {
                                        db_lookup_CARD_NARRATIVE_lookup_meaning = SQLResultset.getString("MEANING");
                                    }

                                    if (db_lookup_CARD_NARRATIVE_lookup_meaning == (null)) {
                                        String lookup_CARD_NARRATIVE_lookup_meaning = ",CARD_NARRATIVE LOOKUP," + "LookUp value not found" + "," + db_STG_CARD_NARRATIVE + ",Fail";
                                        section1_results.add(lookup_CARD_NARRATIVE_lookup_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CARD_NARRATIVE LOOKUP" + "," + "LookUp value not found" + "," + db_STG_CARD_NARRATIVE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_CARD_NARRATIVE_lookup_meaning != null) {
                                        if (db_lookup_CARD_NARRATIVE_lookup_meaning.equals(db_STG_CARD_NARRATIVE)) {
                                            String lookup_CARD_NARRATIVE_lookup_meaning = ",CARD_NARRATIVE LOOKUP," + db_lookup_CARD_NARRATIVE_lookup_meaning + "," + db_STG_CARD_NARRATIVE + ",Pass";
                                            section1_results.add(lookup_CARD_NARRATIVE_lookup_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CARD_NARRATIVE LOOKUP" + "," + db_lookup_CARD_NARRATIVE_lookup_meaning + "," + db_STG_CARD_NARRATIVE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String lookup_CARD_NARRATIVE_lookup_meaning = ",CARD_NARRATIVE LOOKUP," + db_lookup_CARD_NARRATIVE_lookup_meaning + "," + db_STG_CARD_NARRATIVE + ",Fail";
                                            section1_results.add(lookup_CARD_NARRATIVE_lookup_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CARD_NARRATIVE LOOKUP" + "," + db_lookup_CARD_NARRATIVE_lookup_meaning + "," + db_STG_CARD_NARRATIVE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }

                                } else if (db_lookup_V_CARD_NARRATIVE_REQUIRED_fsh_lookup_meaning.equals("Y") && db_CONS_CARD_NARRATIVE != ("null") && db_CONS_CARD_TYPE.equals("AM")) {

                                    SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_CARD_NARRATIVE + "' and LOOKUP_TYPE = 'CARD_NARRATIVE_AM' and System = 'LAND' and pattern = 'GLBilling' ");
                                    while (SQLResultset.next()) {
                                        db_lookup_CARD_NARRATIVE_lookup_meaning = SQLResultset.getString("MEANING");
                                    }

                                    if (db_lookup_CARD_NARRATIVE_lookup_meaning == (null)) {
                                        String lookup_CARD_NARRATIVE_lookup_meaning = ",CARD_NARRATIVE LOOKUP," + "LookUp value not found" + "," + db_STG_CARD_NARRATIVE + ",Fail";
                                        section1_results.add(lookup_CARD_NARRATIVE_lookup_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CARD_NARRATIVE LOOKUP" + "," + "LookUp value not found" + "," + db_STG_CARD_NARRATIVE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_CARD_NARRATIVE_lookup_meaning != null) {
                                        if (db_lookup_CARD_NARRATIVE_lookup_meaning.equals(db_STG_CARD_NARRATIVE)) {
                                            String lookup_CARD_NARRATIVE_lookup_meaning = ",CARD_NARRATIVE LOOKUP," + db_lookup_CARD_NARRATIVE_lookup_meaning + "," + db_STG_CARD_NARRATIVE + ",Pass";
                                            section1_results.add(lookup_CARD_NARRATIVE_lookup_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CARD_NARRATIVE LOOKUP" + "," + db_lookup_CARD_NARRATIVE_lookup_meaning + "," + db_STG_CARD_NARRATIVE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String lookup_CARD_NARRATIVE_lookup_meaning = ",CARD_NARRATIVE LOOKUP," + db_lookup_CARD_NARRATIVE_lookup_meaning + "," + db_STG_CARD_NARRATIVE + ",Fail";
                                            section1_results.add(lookup_CARD_NARRATIVE_lookup_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CARD_NARRATIVE LOOKUP" + "," + db_lookup_CARD_NARRATIVE_lookup_meaning + "," + db_STG_CARD_NARRATIVE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }

                                } else if (db_lookup_V_CARD_NARRATIVE_REQUIRED_fsh_lookup_meaning.equals("N") && db_CONS_CARD_NARRATIVE == (null)) {

                                    SQLResultset = SQLstmt.executeQuery(LandscapeGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'CARD_NARRATIVE'" + fsh_source);
                                    //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'CARD_NARRATIVE' and System = 'LAND' and pattern = 'GLBilling' ");
                                    while (SQLResultset.next()) {
                                        db_lookup_CARD_NARRATIVE_lookup_meaning = SQLResultset.getString("MEANING");
                                    }

                                    if (db_lookup_CARD_NARRATIVE_lookup_meaning == (null)) {
                                        String lookup_CARD_NARRATIVE_lookup_meaning = ",CARD_NARRATIVE LOOKUP," + "LookUp value not found" + "," + db_STG_CARD_NARRATIVE + ",Fail";
                                        section1_results.add(lookup_CARD_NARRATIVE_lookup_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CARD_NARRATIVE LOOKUP" + "," + "LookUp value not found" + "," + db_STG_CARD_NARRATIVE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_CARD_NARRATIVE_lookup_meaning != null) {
                                        if (db_lookup_CARD_NARRATIVE_lookup_meaning.equals(db_STG_CARD_NARRATIVE)) {
                                            String lookup_CARD_NARRATIVE_lookup_meaning = ",CARD_NARRATIVE LOOKUP," + db_lookup_CARD_NARRATIVE_lookup_meaning + "," + db_STG_CARD_NARRATIVE + ",Pass";
                                            section1_results.add(lookup_CARD_NARRATIVE_lookup_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CARD_NARRATIVE LOOKUP" + "," + db_lookup_CARD_NARRATIVE_lookup_meaning + "," + db_STG_CARD_NARRATIVE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String lookup_CARD_NARRATIVE_lookup_meaning = ",CARD_NARRATIVE LOOKUP," + db_lookup_CARD_NARRATIVE_lookup_meaning + "," + db_STG_CARD_NARRATIVE + ",Fail";
                                            section1_results.add(lookup_CARD_NARRATIVE_lookup_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CARD_NARRATIVE LOOKUP" + "," + db_lookup_CARD_NARRATIVE_lookup_meaning + "," + db_STG_CARD_NARRATIVE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }

                                }


                                /*//------------------------ PAYMENT_TRANSACTION_TYPE_ID Validation -----------------
                                String db_lookup_PAYMENT_TRANSACTION_TYPE_ID_lookup_meaning = "null";


                                if (db_CONS_PAYMENT_TRANSACTION_TYPE_ID == (null)) {
                                    SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'PAYMENT_TRANSACTION_TYPE_ID' and System = 'LAND' and pattern = 'GLBilling' ");
                                    while (SQLResultset.next()) {
                                        db_lookup_PAYMENT_TRANSACTION_TYPE_ID_lookup_meaning = SQLResultset.getString("MEANING");
                                    }

                                    if (db_lookup_PAYMENT_TRANSACTION_TYPE_ID_lookup_meaning == (null)) {
                                        String lookup_PAYMENT_TRANSACTION_TYPE_ID_lookup_meaning = ",PAYMENT_TRANSACTION_TYPE_ID LOOKUP," + "LookUp value not found" + "," + db_STG_PAYMENT_TRANSACTION_TYPE_ID + ",Fail";
                                        section1_results.add(lookup_PAYMENT_TRANSACTION_TYPE_ID_lookup_meaning);
                                    } else if (db_lookup_PAYMENT_TRANSACTION_TYPE_ID_lookup_meaning != null) {
                                        if (db_lookup_PAYMENT_TRANSACTION_TYPE_ID_lookup_meaning.equals(db_STG_PAYMENT_TRANSACTION_TYPE_ID)) {
                                            String lookup_PAYMENT_TRANSACTION_TYPE_ID_lookup_meaning = ",PAYMENT_TRANSACTION_TYPE_ID LOOKUP," + db_lookup_PAYMENT_TRANSACTION_TYPE_ID_lookup_meaning + "," + db_STG_PAYMENT_TRANSACTION_TYPE_ID + ",Pass";
                                            section1_results.add(lookup_PAYMENT_TRANSACTION_TYPE_ID_lookup_meaning);
                                        } else {
                                            String lookup_PAYMENT_TRANSACTION_TYPE_ID_lookup_meaning = ",PAYMENT_TRANSACTION_TYPE_ID LOOKUP," + db_lookup_PAYMENT_TRANSACTION_TYPE_ID_lookup_meaning + "," + db_STG_PAYMENT_TRANSACTION_TYPE_ID + ",Fail";
                                            section1_results.add(lookup_PAYMENT_TRANSACTION_TYPE_ID_lookup_meaning);
                                        }
                                    }

                                } else {
                                    SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_PAYMENT_TRANSACTION_TYPE_ID + "' and LOOKUP_TYPE = 'PAYMENT_TRANSACTION_TYPE_ID' and System = 'LAND' and pattern = 'GLBilling' ");
                                    while (SQLResultset.next()) {
                                        db_lookup_PAYMENT_TRANSACTION_TYPE_ID_lookup_meaning = SQLResultset.getString("MEANING");
                                    }

                                    if (db_lookup_PAYMENT_TRANSACTION_TYPE_ID_lookup_meaning == (null)) {
                                        String lookup_PAYMENT_TRANSACTION_TYPE_ID_lookup_meaning = ",PAYMENT_TRANSACTION_TYPE_ID LOOKUP," + "LookUp value not found" + "," + db_STG_PAYMENT_TRANSACTION_TYPE_ID + ",Fail";
                                        section1_results.add(lookup_PAYMENT_TRANSACTION_TYPE_ID_lookup_meaning);
                                    } else if (db_lookup_PAYMENT_TRANSACTION_TYPE_ID_lookup_meaning != null) {
                                        if (db_lookup_PAYMENT_TRANSACTION_TYPE_ID_lookup_meaning.equals(db_STG_PAYMENT_TRANSACTION_TYPE_ID)) {
                                            String lookup_PAYMENT_TRANSACTION_TYPE_ID_lookup_meaning = ",PAYMENT_TRANSACTION_TYPE_ID LOOKUP," + db_lookup_PAYMENT_TRANSACTION_TYPE_ID_lookup_meaning + "," + db_STG_PAYMENT_TRANSACTION_TYPE_ID + ",Pass";
                                            section1_results.add(lookup_PAYMENT_TRANSACTION_TYPE_ID_lookup_meaning);
                                        } else {
                                            String lookup_PAYMENT_TRANSACTION_TYPE_ID_lookup_meaning = ",PAYMENT_TRANSACTION_TYPE_ID LOOKUP," + db_lookup_PAYMENT_TRANSACTION_TYPE_ID_lookup_meaning + "," + db_STG_PAYMENT_TRANSACTION_TYPE_ID + ",Fail";
                                            section1_results.add(lookup_PAYMENT_TRANSACTION_TYPE_ID_lookup_meaning);
                                        }
                                    }
                                }*/

                                //------------------------ CURRENCY_AMOUNT Validation -----------------
                                String db_lookup_V_REVERSAL_MULTIPLIER_lookup_meaning = "null";
                                int db_lookup_V_REVERSAL_MULTIPLIER_meaningInInteger = 0;
                                int db_STG_CURRENCY_AMOUNTModifiedInInteger = 0;
                                int db_STG_BASE_CURRENCY_AMOUNTModifiedInInteger = 0;

                                SQLResultset = SQLstmt.executeQuery(LandscapeGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'REVERSAL_MULTIPLIER'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'REVERSAL_MULTIPLIER' and System = 'LAND' and pattern = 'GLBilling' ");
                                while (SQLResultset.next()) {
                                    db_lookup_V_REVERSAL_MULTIPLIER_lookup_meaning = SQLResultset.getString("MEANING");
                                    db_lookup_V_REVERSAL_MULTIPLIER_meaningInInteger = Integer.parseInt(db_lookup_V_REVERSAL_MULTIPLIER_lookup_meaning);
                                }

                                if (db_CONS_REVERSAL_INDICATOR == (null)) {
                                    String db_STG_REVERSAL_INDICATORModified = db_STG_REVERSAL_INDICATOR.replace("null", "N");
                                    String db_STG_CURRENCY_AMOUNTModified = db_STG_CURRENCY_AMOUNT;
                                    db_STG_CURRENCY_AMOUNTModifiedInInteger = Integer.parseInt(db_STG_CURRENCY_AMOUNTModified);
                                } else {
                                    String db_STG_REVERSAL_INDICATORModified = db_STG_REVERSAL_INDICATOR.replace(".*", "Y");
                                    int db_STG_CURRENCY_AMOUNTModified = (db_STG_CURRENCY_AMOUNTModifiedInInteger) * (db_lookup_V_REVERSAL_MULTIPLIER_meaningInInteger);
                                }


                                //------------------------ BASE_CURRENCY_AMOUNT Validation -----------------

                                if (db_CONS_REVERSAL_INDICATOR == (null)) {
                                    String db_STG_REVERSAL_INDICATORModified = db_STG_REVERSAL_INDICATOR.replace("null", "N");
                                    String db_STG_BASE_CURRENCY_AMOUNTModified = db_STG_BASE_CURRENCY_AMOUNT;
                                    db_STG_BASE_CURRENCY_AMOUNTModifiedInInteger = Integer.parseInt(db_STG_BASE_CURRENCY_AMOUNTModified);
                                } else {
                                    String db_STG_REVERSAL_INDICATORModified = db_STG_REVERSAL_INDICATOR.replace(".*", "Y");
                                    int db_STG_BASE_CURRENCY_AMOUNTModified = (db_STG_BASE_CURRENCY_AMOUNTModifiedInInteger) * (db_lookup_V_REVERSAL_MULTIPLIER_meaningInInteger);
                                }


                                //------------------------ PRODUCT_KEY Validation -----------------
                                String db_lookup_V_TRX_SUB_TYPE_LPI_lookup_meaning = "null";
                                String db_lookup_PRODUCT_KEY_lookup_meaning = "null";
                                String db_STG_V_TRX_SUB_TYPE_REQUIRED = "null";

                                SQLResultset = SQLstmt.executeQuery(LandscapeGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_CONS_TRANSACTION_SUBTYPE + "' and LOOKUP_TYPE = 'TRANSACTION_SUBTYPE_LPI'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_TRANSACTION_SUBTYPE + "' and LOOKUP_TYPE = 'TRANSACTION_SUBTYPE_LPI' and System = 'LAND' and pattern = 'GLBilling' ");
                                while (SQLResultset.next()) {
                                    db_lookup_V_TRX_SUB_TYPE_LPI_lookup_meaning = SQLResultset.getString("MEANING");
                                }

                                if (db_lookup_V_TRX_SUB_TYPE_LPI_lookup_meaning != "null") {
                                    db_STG_V_TRX_SUB_TYPE_REQUIRED = "Y";
                                } else {
                                    db_STG_V_TRX_SUB_TYPE_REQUIRED = "N";
                                }

                                if (db_CONS_FSH_ATTRIBUTE_2 != null) {
                                    if (db_CONS_FSH_ATTRIBUTE_2.equals(db_STG_PRODUCT_KEY)) {
                                        String STG_PRODUCT_KEY = ",PRODUCT_KEY ," + db_CONS_FSH_ATTRIBUTE_2 + "," + db_STG_PRODUCT_KEY + ",Pass";
                                        section1_results.add(STG_PRODUCT_KEY);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT_KEY" + "," + db_CONS_FSH_ATTRIBUTE_2 + "," + db_STG_PRODUCT_KEY + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String STG_PRODUCT_KEY = ",PRODUCT_KEY ," + db_CONS_FSH_ATTRIBUTE_2 + "," + db_STG_PRODUCT_KEY + ",Fail";
                                        section1_results.add(STG_PRODUCT_KEY);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT_KEY" + "," + db_CONS_FSH_ATTRIBUTE_2 + "," + db_STG_PRODUCT_KEY + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                } else if (db_STG_V_TRX_SUB_TYPE_REQUIRED.equals("Y") && db_CONS_FSH_ATTRIBUTE_2 == (null)) {
                                    db_lookup_PRODUCT_KEY_lookup_meaning = "Error: Missing <PRODUCT_KEY> for Cheque Number <TRANSACTION_SUBTYPE> value.";
                                    String lookup_PRODUCT_KEY_lookup_meaning = ",PRODUCT_KEY," + db_lookup_PRODUCT_KEY_lookup_meaning + "," + db_lookup_PRODUCT_KEY_lookup_meaning + ",Pass";
                                    section1_results.add(lookup_PRODUCT_KEY_lookup_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT_KEY" + "," + db_lookup_PRODUCT_KEY_lookup_meaning + "," + db_lookup_PRODUCT_KEY_lookup_meaning + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);


                                } else if (db_STG_V_TRX_SUB_TYPE_REQUIRED.equals("N") && db_CONS_FSH_ATTRIBUTE_2 == (null)) {
                                    SQLResultset = SQLstmt.executeQuery(LandscapeGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'PRODUCT_KEY'" + fsh_source);
                                    //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'PRODUCT_KEY' and System = 'LAND' and pattern = 'GLBilling' ");
                                    while (SQLResultset.next()) {
                                        db_lookup_PRODUCT_KEY_lookup_meaning = SQLResultset.getString("MEANING");
                                    }

                                    if (db_lookup_PRODUCT_KEY_lookup_meaning == (null)) {
                                        String lookup_PRODUCT_KEY_lookup_meaning = ",PRODUCT_KEY LOOKUP," + "LookUp value not found" + "," + db_STG_PRODUCT_KEY + ",Fail";
                                        section1_results.add(lookup_PRODUCT_KEY_lookup_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT_KEY" + "," + "LookUp value not found" + "," + db_STG_PRODUCT_KEY + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_PRODUCT_KEY_lookup_meaning != null) {
                                        if (db_lookup_PRODUCT_KEY_lookup_meaning.equals(db_STG_PRODUCT_KEY)) {
                                            String lookup_PRODUCT_KEY_lookup_meaning = ",PRODUCT_KEY LOOKUP," + db_lookup_PRODUCT_KEY_lookup_meaning + "," + db_STG_PRODUCT_KEY + ",Pass";
                                            section1_results.add(lookup_PRODUCT_KEY_lookup_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT_KEY" + "," + db_lookup_PRODUCT_KEY_lookup_meaning + "," + db_STG_PRODUCT_KEY + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String lookup_PRODUCT_KEY_lookup_meaning = ",PRODUCT_KEY LOOKUP," + db_lookup_PRODUCT_KEY_lookup_meaning + "," + db_STG_PRODUCT_KEY + ",Fail";
                                            section1_results.add(lookup_PRODUCT_KEY_lookup_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT_KEY" + "," + db_lookup_PRODUCT_KEY_lookup_meaning + "," + db_STG_PRODUCT_KEY + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }
                                }


                            }
                        }
                    }
                }


                    //----------------- Validate the Over all Status -------------------
                    System.out.println("Looping ++  CONS_flag " + CONS_flag);
                    String Overall_status = null;
                    String Overall_stg_status = null;
                    if (CONS_flag > 0) {
                        CONS_STATUS.add("Fail");
                        Overall_status = "Fail";
                    } else {
                        CONS_STATUS.add("Pass");
                        Overall_status = "Pass";
                    }


                    if (CONS_flag > 0) {
                        OverAllStatus.add("Fail");
                    } else {
                        OverAllStatus.add("Pass");
                    }

                    String tbl_summary_filelist = Source +","+ pattern + ","+file_name +","+ "CONS TO STG " + "," + load_date + ","+ OverAllStatus + "," + btc_BATCH_PKEY;
                    //String tbl_summary_filelist = Source + "," + pattern + "," + file_name + "," + load_dateFormat + "," + "CONST TO STG " + "," + OverAllStatus;
                    summary_results_tbl.add(tbl_summary_filelist);

                    list.addAll(section1_results);
                    list.addAll(section2_results);
                    list.addAll(section3_results);
                    list.addAll(section4_results);

                    // ---------------- HTML Report generation ------------------------
                    report_generation.report_Test1(section1_results, "Header", xml_file_name, "CONSOLIDATION LAYER - STAGING LAYER", "Landscape_GL_Billing", "Landscape_GL_Billing : CONSOLIDATION LAYER - STAGING AGGREGATE LAYER", "");
                    report_generation.report_Test1(section1_results, "Section2", xml_file_name, "CONSOLIDATION LAYER - STAGING LAYER", "Landscape_GL_Billing", "Landscape_GL_Billing : CONSOLIDATION LAYER - STAGING AGGREGATE LAYER", "");
                    report_generation.report_Test1(section2_results, "Mandatory", xml_file_name, "Mandatory_Check_CONS", "Landscape_GL_Billing", "Landscape_GL_Billing : CONSOLIDATION LAYER - STAGING AGGREGATE LAYER", "");
                    report_generation.report_Test1(section4_results, "Mandatory", xml_file_name, "Mandatory_Check_STG", "Landscape_GL_Billing", "Landscape_GL_Billing : CONSOLIDATION LAYER - STAGING AGGREGATE LAYER", "");
                    report_generation.report_Test1(section3_results, "Section3", xml_file_name, "STAGING LAYER - AGGREGATE LAYER", "Landscape_GL_Billing", "Landscape_GL_Billing : CONSOLIDATION LAYER - STAGING AGGREGATE LAYER", "");


                    table_detail_report.detail_report_tbl(section2_results_tbl);
                }
                state_model.section_method(file_list, CONS_STATUS, "N/A", OverAllStatus, "Landscape_GLBilling_Summary");
                table_summary_report.summary_report_tbl(summary_results_tbl );
            }
        }
    }







