package Dashboard_Report;



import Dashboard_Report.HTML_Report_Generation_State_Model_Jenkins;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class SCH_EVO_PC_State_Model_B4C {

    public static HTML_Report_Generation_State_Model_Jenkins report_generation_state = new HTML_Report_Generation_State_Model_Jenkins();
    static List<String> list = new ArrayList<String>();


    public static void section_method (List<String> file_list, List<String> CONS_status, String OverAllStatus, List HeaderStatus,String report_summary_name) throws IOException {

        String Html_teport_name = "C:\\Test\\EVO_Automation\\Results\\" + report_summary_name +"."+"html";
        report_generation_state.clean_report_summary(Html_teport_name);

        String overall_status = null;
        int Overall_count =0;
        int section1_map_row =1;
        String xml_file_name = "null";
        ArrayList<String> section11_results= new ArrayList<>();
        for(int i=0;i<file_list.size();i++) {
            String cons_status = null;
            String newfile = section1_map_row + "," + file_list.get(i) + "," + CONS_status.get(i) + "," + OverAllStatus + "," + HeaderStatus.get(i);
            section1_map_row++;
            section11_results.add(newfile);

        }
        for(String val : CONS_status ){

            if(val.equalsIgnoreCase("Fail")){

                Overall_count+=1;
            }
        }
        if(Overall_count > 0){

            overall_status ="Fail";
        }
        else{
            overall_status ="Pass";

        }

        System.out.println("Summary report name ------" +report_summary_name);

        //--------------------- Summary report ------------------
        if(report_summary_name.equalsIgnoreCase("EVO_PC_Summary")){
            report_generation_state.report_Summary(section11_results, "Section1", xml_file_name, "EVO_PC BATCH TABLE VALIDATION", "EVO_PC_Summary", "EVO_PC SUMMARY", overall_status);
        }else if(report_summary_name.equalsIgnoreCase("EVO_BC_Summary")){
            report_generation_state.report_Summary(section11_results, "Section1", xml_file_name, "EVO_BC BATCH TABLE VALIDATION", "EVO_BC_Summary", "EVO_BC SUMMARY", overall_status);
        }else if(report_summary_name.equalsIgnoreCase("EVO_CC_Summary")){
            report_generation_state.report_Summary(section11_results, "Section1", xml_file_name, "EVO_CC BATCH TABLE VALIDATION", "EVO_CC_Summary", "EVO_CC SUMMARY", overall_status);
        }else if(report_summary_name.equalsIgnoreCase("EVO_ACCRUAL_Summary")){
            report_generation_state.report_Summary(section11_results, "Section1", xml_file_name, "EVO_ACCRUAL BATCH TABLE VALIDATION", "EVO_ACCRUAL_Summary", "EVO_ACCRUAL SUMMARY", overall_status);
        }else if(report_summary_name.equalsIgnoreCase("TRAVEL_PC_Summary")){
            report_generation_state.report_Summary(section11_results, "Section1", xml_file_name, "TRAVEL_PC BATCH TABLE VALIDATION", "TRAVEL_PC_Summary", "EVO_ACCRUAL SUMMARY", overall_status);
        } else if(report_summary_name.equalsIgnoreCase("Travel_GLReserves_Summary")){
            report_generation_state.report_Summary(section11_results, "Section1", xml_file_name, "Travel_GLReserves BATCH TABLE VALIDATION", "Travel_GLReserves_Summary", "Travel_GLReserves SUMMARY", overall_status);
        } else if(report_summary_name.equalsIgnoreCase("Travel_GLBilling_Summary")) {
            report_generation_state.report_Summary(section11_results, "Section1", xml_file_name, "Travel_GLBilling BATCH TABLE VALIDATION", "Travel_GLBilling_Summary", "Travel_GLBilling SUMMARY", overall_status);
        } else if(report_summary_name.equalsIgnoreCase("Landscape_GLBilling_Summary")){
            report_generation_state.report_Summary(section11_results, "Section1", xml_file_name, "Landscape_GLBilling BATCH TABLE VALIDATION", "Landscape_GLBilling_Summary", "Landscape_GLBilling SUMMARY", overall_status);
        } else if(report_summary_name.equalsIgnoreCase("Landscape_GLPremium_Summary")) {
            report_generation_state.report_Summary(section11_results, "Section1", xml_file_name, "Landscape_GLPremium BATCH TABLE VALIDATION", "Landscape_GLPremium_Summary", "Landscape_GLPremium SUMMARY", overall_status);
        } else if(report_summary_name.equalsIgnoreCase("Landscape_GLReserves_Summary")) {
            report_generation_state.report_Summary(section11_results, "Section1", xml_file_name, "Landscape_GLReserves BATCH TABLE VALIDATION", "Landscape_GLReserves_Summary", "Landscape_GLReserves SUMMARY", overall_status);
        } else if(report_summary_name.equalsIgnoreCase("Landscape_GLClaimcash_Summary")) {
            report_generation_state.report_Summary(section11_results, "Section1", xml_file_name, "Landscape_GLClaimcash BATCH TABLE VALIDATION", "Landscape_GLClaimcash_Summary", "Landscape_GLClaimcash SUMMARY", overall_status);
        } else if(report_summary_name.equalsIgnoreCase("BMS_GLAccrual_Summary")) {
            report_generation_state.report_Summary(section11_results, "Section1", xml_file_name, "BMS_GLAccrual BATCH TABLE VALIDATION", "BMS_GLAccrual_Summary", "BMS_GLAccrual SUMMARY", overall_status);
        } else if(report_summary_name.equalsIgnoreCase("CCV5_GLClaimcash_Summary")) {
            report_generation_state.report_Summary(section11_results, "Section1", xml_file_name, "CCV5_GLClaimcash BATCH TABLE VALIDATION", "CCV5_GLClaimcash_Summary", "CCV5_GLClaimcash SUMMARY", overall_status);
        } else if(report_summary_name.equalsIgnoreCase("PULSE_ARReceipts_Summary")) {
            report_generation_state.report_Summary(section11_results, "Section1", xml_file_name, "Pulse_ARReceipts BATCH TABLE VALIDATION", "PULSE_ARReceipts_Summary", "Pulse_ARReceipts SUMMARY", overall_status);
        } else if(report_summary_name.equalsIgnoreCase("BMS_ARReceipts_Summary")) {
            report_generation_state.report_Summary(section11_results, "Section1", xml_file_name, "BMS_ARReceipts BATCH TABLE VALIDATION", "BMS_ARReceipts_Summary", "BMS_ARReceipts SUMMARY", overall_status);
        } else if(report_summary_name.equalsIgnoreCase("PULSE_APInvoice_Summary")) {
            report_generation_state.report_Summary(section11_results, "Section1", xml_file_name, "PULSE_APInvoice BATCH TABLE VALIDATION", "PULSE_APInvoice_Summary", "PULSE_APInvoice SUMMARY", overall_status);
        } else if(report_summary_name.equalsIgnoreCase("BMS_APInvoice_Summary")) {
            report_generation_state.report_Summary(section11_results, "Section1", xml_file_name, "BMS_APInvoice BATCH TABLE VALIDATION", "BMS_APInvoice_Summary", "BMS_APInvoice SUMMARY", overall_status);
        }


    }

}
