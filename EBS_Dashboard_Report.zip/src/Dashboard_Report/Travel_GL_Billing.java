package Dashboard_Report;

import java.io.File;
import java.io.IOException;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONException;

public class Travel_GL_Billing {

    //AQUA_BD14B_20190212005548.XML

    static Statement SQLstmt = null;
    static ResultSet SQLResultset_fsh = null;

    public static HTML_Report_Generation_DB_EVO report_generation;
    public static HTML_Report_Generation_State_Model_B4C report_generation_state;
    public static SCH_EVO_PC_State_Model_B4C state_model;

    public static Table_Detail_Report table_detail_report;
    public static Table_Summary_Report table_summary_report;
    public static connectDatabase connect_db;

    public static void main(String[] args) throws IOException, SQLException, JSONException {

        report_generation = new HTML_Report_Generation_DB_EVO();
        report_generation_state = new HTML_Report_Generation_State_Model_B4C();
        state_model = new SCH_EVO_PC_State_Model_B4C();

        table_detail_report = new Table_Detail_Report();
        table_summary_report = new Table_Summary_Report();
        connect_db = new connectDatabase();

        //----------------------- delete the existing report --------------
        report_generation.clean_report("Travel_GLBilling.html");
        report_generation_state.clean_report_summary("Travel_GLBilling_Summary.html");

        //AQUA_BD14B_20190805150718.XML (positive)
        //AQUA_BD14B_20190805150717.XML (negative)

        //--------------- SIT  database details -------------------
       /* String URL_SIT1 = "jdbc:oracle:thin:@dcn2dcll11z:1521/FSHTSIT1.gwd.grpinf.net";
        String Username_SIT1 = "FSH_ORA_DATA";
        String password_SIT1 = "vMw5HpJaFy3uD6eW";*/

        //--------------- EBS  database details -------------------
       /* String URL_ICSI = "jdbc:oracle:thin:@dcn2ddbx340.gwd.grpinf.net:1618:ICSI";
        String Username_ICSI = "apps";
        String password_ICSI = "apps4icsi";*/

        List<String> file_list = new ArrayList<String>();
        List<String> list = new ArrayList<String>();
        List<String> section1_results = new ArrayList<String>();
        /*List<String> section2_results = new ArrayList<String>();
        List<String> section3_results = new ArrayList<String>();*/
        List<String> section4_results = new ArrayList<String>();

        List<String> OverAllStatus = new ArrayList<String>();
        List<String> CONS_STATUS = new ArrayList<String>();
        List<String> summary_results_tbl = new ArrayList<String>();

        String[] file_lists = null;
        int section1_map_row = 1;

        //--------------------- Decelaring the supporting details for reporting --------------
        String file_name = "null";
        String Source = "AQUA";
        String pattern = "GLBilling";
        String header = "Header";

        //---- Initialiing row count variables -----
        int cons_stg_map_row = 1;
        int stg_line_map_row = 1;
        int cons_mandatory_map_row = 1;

        // Conslidation table  initialisation
        String db_BATCH_PKEY = null;
        String db_FILE_NAME = null;
        String db_CONS_BC_HEADER_ID = null;
        String db_CONS_STATUS = null;
        String db_bc_header_id = "null";
        String db_source = "null";
        String db_account_number = "null";
        String db_policy_number = "null";
        String db_underwriter = "null";
        String db_brand = "null";
        String db_line_of_business = "null";
        String db_channel = "null";
        //String db_summary_flag = "null";
        String db_event_code = "null";
        String db_entity_type_code = "null";
        String db_product_type = "null";
        String db_transaction_reference = "null";
        String db_transaction_date = "null";
        String db_transaction_sub_type = "null";
        String db_transaction_reason = "null";
        String db_payment_method = "null";
        String db_sun_number = "null";
        String db_mid_number = "null";
        String db_ddi_reference = "null";
        String db_pay_in_slip_number = "null";
        String db_cheque_number = "null";
        String db_card_type = "null";
        String db_bacs_narrative = "null";
        String db_card_narrative = "null";
        String db_order_number = "null";
        String db_reversal_indicator = "null";
        String db_currency_code = "null";
        String db_exchange_rate = "null";
        String db_exchange_rate_type = "null";
        String db_base_currency_amount = "null";
        String db_exchange_date = "null";
        String db_cross_reference = "null";
        String db_bc_line_id = "null";
        String db_dr_cr_flag = "null";
        String db_amount = "null";
        String db_line_bc_header_id = "null";
        String load_date = null;
        Date load_dateFormat = null;
        String btc_BATCH_PKEY = null;

        String db_base_interest_amount = "null";
        String db_tax_deductible = "null";
        String db_payment_transaction_type_id = "null";
        String db_currency_amount = "null";
        String db_credit_ind = "null";
        String db_interest_amount = "null";
        String db_interest_currency_code = "null";

        //----------- Staging table variable decleration-------------
        String db_stg_reversal_indicator = "null";
        String db_stg_bc_header_id = "null";
        String db_stg_source = "null";
        String db_stg_brand = "null";
        String db_stg_account_number = "null";
        String db_stg_policy_number = "null";
        String db_stg_underwriter = "null";
        String db_stg_product_type = "null";
        String db_stg_line_of_business = "null";
        String db_stg_transaction_reference = "null";
        String db_stg_transaction_date = "null";
        String db_stg_transaction_sub_type = "null";
        String db_stg_transaction_reason = "null";
        String db_stg_payment_method = "null";
        String db_stg_entity_type_code = "null";
        String db_stg_sun_number = "null";
        String db_stg_mid_number = "null";
        String db_stg_ddi_reference = "null";
        String db_stg_pay_in_slip_number = "null";
        String db_stg_cheque_number = "null";
        String db_stg_card_type = "null";
        String db_stg_bacs_narrative = "null";
        String db_stg_card_narrative = "null";
        String db_stg_channel = "null";
        String db_stg_summary_flag = "null";
        String db_stg_currency_code = "null";
        String db_stg_order_number = "null";
        String db_stg_exchange_rate = "null";
        String db_stg_exchange_rate_type = "null";
        String db_stg_base_currency_amount = "null";
        String db_stg_credit_ind = "null";
        String db_stg_currency_amount = "null";

        String db_stg_base_interest_amount = "null";
        String db_stg_tax_deductible = "null";
        String db_stg_payment_transaction_type_id = "null";
        String db_stg_interest_amount = "null";
        String db_stg_interest_currency_code = "null";
        String db_stg_event_code = "null";
        String db_stg_event_type_code = "null";
        String db_stg_status = "null";
        String db_stg_batch_fkey = "null";
        String db_stg_file_name = "null";
        String STG_HDR_STATUS = "null";
        String db_stg_TOH_id = "null";
        String db_aggregate_toh_id = "null";

        String xmlfile_name = "null";
        String xml_file_name1 = null;


        //-------- Connect to Database --------------
        connect_db.createConnection("SIT2");
        //table_detail_report.detail_report_tbl_delete(connection, Source);


        //------ get the new file from batch control table --------------
        boolean newRecord = true;
        String outSQL = connect_db.executeQuery_DB("BATCH", "GLBilling_batchCtl", "TRAVEL");
        SQLstmt = connect_db.resStatement();

        SQLResultset_fsh = SQLstmt.executeQuery(outSQL);
        while (SQLResultset_fsh.next()) {
            file_list.add(SQLResultset_fsh.getString("FILE_NAME"));
            System.out.println("File name---" + SQLResultset_fsh.getString("FILE_NAME"));
            list.addAll(section1_results);
        }

        // ---------------------------------- Get the batch PKEY ----------------------
        String outSQL_bkey = connect_db.executeQuery_DB("BATCH", "GLBilling_batchCtl_key", "TRAVEL");

        SQLResultset_fsh = SQLstmt.executeQuery(outSQL_bkey);
        while (SQLResultset_fsh.next()) {
            btc_BATCH_PKEY = SQLResultset_fsh.getString("BATCH_PKEY");
        }

        // ---------------------------------- Check the new file ----------------------
        SQLResultset_fsh = SQLstmt.executeQuery(outSQL);
        if (!SQLResultset_fsh.next()) {
            System.out.println("No new Travel_GLReserves files have been received to FSH ");
            newRecord = false;
            String nonewfile = ",FILE_NAME," + "No new Travel_GLReserves files have been received to FSH" + "," + "," + ",Pass";
            section1_results.add(nonewfile);
            list.addAll(section1_results);
        }

        if (newRecord) {

            //------------------------ Section 1 Start Print all the new file in the report-------------------
            for (String num_file : file_list) {
                file_lists = num_file.split(",");
                for (String file_list1 : file_lists) {
                    xml_file_name1 = file_list1;
                    //int section1_map_row = 1;
                    String newfile = section1_map_row + ",FILE_NAME," + xml_file_name1 + "," + xml_file_name1 + ",Pass";
                    section1_map_row++;
                    section1_results.add(newfile);
                }
            }
            list.addAll(section1_results);
            //report_generation.report_Test1(section1_results, "Section1", xml_file_name1, "B4C BC CONS BATCH TABLE VALIDATION", "B4C_SCHBilling", "B4C BC VALIDATION");
            //------------------------ Section 1 End ----------------------------------------------
        }


        List<String> list_header = new ArrayList<String>(); // -- Add all the header id
        if (newRecord) {
            //------------ Split the file names form the list --------------
            for (String xml_file_name : file_list) {
                int section2_map_row = 1;
                int CONS_flag = 0;
                List<String> section2_results = new ArrayList<String>();
                List<String> section3_results = new ArrayList<String>();
                List<String> section2_results_tbl = new ArrayList<String>();

                file_name = xml_file_name;


                /*//--------------------------------- Staging to Staging Aggregate Validations ---------------------------------//
                //----------------------------------Count Validations---------------------------------------------------------//
                boolean sec3flag = true;
                String db_STG_ACTL_RCDS = null;
                Integer db_STG_ACTL_RCDS1 = 0;
                SQLResultset_fsh = SQLstmt.executeQuery("SELECT COUNT(HEADER_ID) as STG_ACTL_RCDS FROM FSH_ORA_DATA.DLG_FSH_STG_COMM_BCCC_HDR WHERE FILE_NAME = '" + xml_file_name + "' and status = 'COMPLETE'");
                while (SQLResultset_fsh.next()) {
                    db_STG_ACTL_RCDS = SQLResultset_fsh.getString("STG_ACTL_RCDS");
                    db_STG_ACTL_RCDS1 = SQLResultset_fsh.getInt("STG_ACTL_RCDS");
                    System.out.println("Staging count ----" + db_STG_ACTL_RCDS);
                }
                if (db_STG_ACTL_RCDS1 == 0) {  //--- Zero record validation
                    sec3flag = false;
                    String pc_stg_header_line = 1 + "," + "STG_ACTL_RCDS DB Does not have any records" + "," + "STG_ACTL_RCDS DB Does not have any records" + "," + "STG_AGG_ACTUAL_HEADER DB Does not have any records" + ",Fail";
                    section3_results.add(pc_stg_header_line);
                }

                SQLResultset_fsh = SQLstmt.executeQuery("SELECT * FROM FSH_ORA_DATA.DLG_FSH_STG_COMM_BCCC_HDR WHERE FILE_NAME = '" + xml_file_name + "'");
                while (SQLResultset_fsh.next()) {
                    db_stg_summary_flag = SQLResultset_fsh.getString("SUMMARY_FLAG");
                    db_stg_reversal_indicator = SQLResultset_fsh.getString("REVERSAL_INDICATOR");
                }

                if (sec3flag) {
                    do {
                        SQLResultset_fsh = SQLstmt.executeQuery("SELECT COUNT(a.HEADER_ID) as STG_EXP_SUM_HDRS \n" +
                                "FROM(\n" +
                                "SELECt HEADER_ID,STATUS,\n" +
                                "row_number() over(partition by SOURCE,UNDERWRITER,PRODUCT_TYPE,LINE_OF_BUSINESS,TRANSACTION_DATE,TRANSACTION_SUB_TYPE,TRANSACTION_REASON,PAYMENT_METHOD,SUN_NUMBER,MID_NUMBER,CARD_TYPE,BACS_NARRATIVE,CHANNEL,REVERSAL_INDICATOR,CURRENCY_CODE,EXCHANGE_RATE,EXCHANGE_RATE_TYPE,CREDIT_IND,BATCH_FKEY,ENTITY_TYPE_CODE,EVENT_CODE,BRAND,INTEREST_CURRENCY_CODE,PAY_IN_SLIP_NUMBER,PAYMENT_TRANSACTION_TYPE_ID,FILE_NAME,CARD_NARRATIVE,SUMMARY_FLAG,BANK_ACC,PRODUCT,PRODUCT_KEY,trunc(LOSS_DATE)\n" +
                                "ORDER BY SOURCE,UNDERWRITER,PRODUCT_TYPE,LINE_OF_BUSINESS,TRANSACTION_DATE,TRANSACTION_SUB_TYPE,TRANSACTION_REASON,PAYMENT_METHOD,SUN_NUMBER,MID_NUMBER,CARD_TYPE,BACS_NARRATIVE,CHANNEL,REVERSAL_INDICATOR,CURRENCY_CODE,EXCHANGE_RATE,EXCHANGE_RATE_TYPE,CREDIT_IND,BATCH_FKEY,ENTITY_TYPE_CODE,EVENT_CODE,BRAND,INTEREST_CURRENCY_CODE,PAY_IN_SLIP_NUMBER,PAYMENT_TRANSACTION_TYPE_ID,FILE_NAME,CARD_NARRATIVE,SUMMARY_FLAG,BANK_ACC,PRODUCT,PRODUCT_KEY,LOSS_DATE) row_1\n" +
                                "FROM FSH_ORA_DATA.DLG_FSH_STG_COMM_BCCC_HDR WHERE FILE_NAME = '" + xml_file_name + "')a \n" +
                                "where a.row_1 = 1\n" +
                                "AND a.STATUS = 'COMPLETE'");

                        while (SQLResultset_fsh.next()) {
                            String STG_EXP_SUM_HDRS = SQLResultset_fsh.getString("STG_EXP_SUM_HDRS");
                            SQLResultset_fsh = SQLstmt.executeQuery("SELECT count(TOH_ID)as STG_AGG_ACTUAL_HEADER FROM FSH_ORA_DATA.DLG_FSH_STG_COMM_BCCC_AGG_HDR WHERE FILE_NAME = '" + xml_file_name + "'");
                            while (SQLResultset_fsh.next()) {
                                String STG_AGG_ACTUAL_HEADER = SQLResultset_fsh.getString("STG_AGG_ACTUAL_HEADER");
                                System.out.println("Staging Aggregate header count ----" + STG_AGG_ACTUAL_HEADER);
                                if (db_stg_reversal_indicator.equals("N") && db_stg_summary_flag.equals("Y")) {
                                    if (STG_EXP_SUM_HDRS.equals(STG_AGG_ACTUAL_HEADER)) {
                                        String pc_stg_header_line = 1 + "," + db_STG_ACTL_RCDS + "," + STG_EXP_SUM_HDRS + "," + STG_AGG_ACTUAL_HEADER + ",Pass";
                                        section3_results.add(pc_stg_header_line);
                                    } else {
                                        String pc_stg_header_line = 1 + "," + db_STG_ACTL_RCDS + "," + STG_EXP_SUM_HDRS + "," + STG_AGG_ACTUAL_HEADER + ",Fail";
                                        section3_results.add(pc_stg_header_line);
                                    }
                                } else if (db_stg_reversal_indicator.equals("Y") || (db_stg_summary_flag.equals("N") && db_stg_reversal_indicator.equals("N"))) {
                                    if (db_STG_ACTL_RCDS.equals(STG_AGG_ACTUAL_HEADER)) {
                                        String pc_stg_header_line = 1 + "," + db_STG_ACTL_RCDS + "," + db_STG_ACTL_RCDS + "," + STG_AGG_ACTUAL_HEADER + ",Pass";
                                        section3_results.add(pc_stg_header_line);
                                    } else {
                                        String pc_stg_header_line = 1 + "," + db_STG_ACTL_RCDS + "," + db_STG_ACTL_RCDS + "," + STG_AGG_ACTUAL_HEADER + ",Fail";
                                        section3_results.add(pc_stg_header_line);
                                    }

                                }
                            }
                        }

                    } while (SQLResultset_fsh.next());
                }*/


                //-------------- Validation Cons to Stag table ----------------
                String TravelGLBilling_consSqlQuery = connect_db.executeQuery_DB("TravelGL", "GLBilling_Cons","TRAVEL");
                SQLResultset_fsh = SQLstmt.executeQuery(TravelGLBilling_consSqlQuery + "'"+file_name+ "'" );
                //SQLResultset_fsh = SQLstmt.executeQuery("SELECT * from DLG_FSH_CONS_AQUA_BC_HDR WHERE FILE_NAME = '" + xml_file_name + "'");
                while (SQLResultset_fsh.next()) {
                    db_CONS_BC_HEADER_ID = SQLResultset_fsh.getString("BC_HEADER_ID");
                    list_header.add(db_CONS_BC_HEADER_ID);
                }

                //-------------- Validation Cons to Stag table ----------------
                for (int i = 0; i < list_header.size(); i++) {
                    SQLResultset_fsh = SQLstmt.executeQuery(TravelGLBilling_consSqlQuery + "'"+file_name+ "' and BC_HEADER_ID = '" + list_header.get(i) + "' " );
                        //SQLResultset_fsh = SQLstmt.executeQuery("SELECT *  from DLG_FSH_CONS_AQUA_BC_HDR WHERE FILE_NAME = '" + xml_file_name + "' and BC_HEADER_ID ='" + list_header.get(i) + "'");
                        while (SQLResultset_fsh.next()) {

                            db_bc_header_id = SQLResultset_fsh.getString("BC_HEADER_ID");
                            db_source = SQLResultset_fsh.getString("SOURCE");
                            db_account_number = SQLResultset_fsh.getString("ACCOUNT_NUMBER");
                            db_policy_number = SQLResultset_fsh.getString("POLICY_NUMBER");
                            db_underwriter = SQLResultset_fsh.getString("UNDERWRITER");
                            db_product_type = SQLResultset_fsh.getString("PRODUCT_TYPE");
                            db_line_of_business = SQLResultset_fsh.getString("LINE_OF_BUSINESS");
                            db_transaction_reference = SQLResultset_fsh.getString("TRANSACTION_REFERENCE");
                            db_transaction_date = SQLResultset_fsh.getString("TRANSACTION_DATE");
                            db_transaction_sub_type = SQLResultset_fsh.getString("TRANSACTION_SUBTYPE");
                            db_transaction_reason = SQLResultset_fsh.getString("TRANSACTION_REASON");
                            db_payment_method = SQLResultset_fsh.getString("PAYMENT_METHOD");
                            db_sun_number = SQLResultset_fsh.getString("SUN_NUMBER");
                            db_mid_number = SQLResultset_fsh.getString("MID_NUMBER");
                            db_ddi_reference = SQLResultset_fsh.getString("DDI_REFERENCE");
                            db_card_type = SQLResultset_fsh.getString("CARD_TYPE");
                            db_bacs_narrative = SQLResultset_fsh.getString("BACS_NARRATIVE");
                            db_channel = SQLResultset_fsh.getString("CHANNEL");
                            db_order_number = SQLResultset_fsh.getString("ORDER_NUMBER");
                            db_currency_code = SQLResultset_fsh.getString("CURRENCY_CD");
                            db_exchange_rate = SQLResultset_fsh.getString("EXCHANGE_RATE");
                            db_exchange_rate_type = SQLResultset_fsh.getString("EXCHANGE_RATE_TYPE");
                            db_base_currency_amount = SQLResultset_fsh.getString("BASE_CURRENCY_AMOUNT");
                            db_currency_amount = SQLResultset_fsh.getString("AMOUNT");
                            db_exchange_date = SQLResultset_fsh.getString("EXCHANGE_DATE");
                            db_cross_reference = SQLResultset_fsh.getString("CROSS_REFERENCE");
                            db_bc_line_id = SQLResultset_fsh.getString("BC_LINE_ID");
                            db_credit_ind = SQLResultset_fsh.getString("DR_CR_FLAG");
                            db_amount = SQLResultset_fsh.getString("AMOUNT");
                            db_BATCH_PKEY = SQLResultset_fsh.getString("BATCH_FKEY");
                            db_FILE_NAME = SQLResultset_fsh.getString("FILE_NAME");
                            db_CONS_STATUS = SQLResultset_fsh.getString("STATUS");
                            //load_date = SQLResultset_fsh.getString("LOAD_DATE");
                            String db_file_name = SQLResultset_fsh.getString("FILE_NAME");


                            //CONS mandatory validations

                            //BC_HEADER_ID - mandatory validation

                            if ((db_bc_header_id == ("null")) && (db_CONS_STATUS != "REVIEW")) {

                                String cons_BASE_CURRENCY_AMOUNT = cons_mandatory_map_row+"," + db_bc_header_id + ",BC_HEADER_ID," + "BC_HEADER_ID : " + db_bc_header_id + "," + "BC_HEADER_ID was not found," + db_CONS_STATUS + "," + "Fail";
                                section2_results.add(cons_BASE_CURRENCY_AMOUNT);
                                cons_mandatory_map_row++;
                            } else {
                                String cons_BASE_CURRENCY_AMOUNT = cons_mandatory_map_row+"," + db_bc_header_id + ",BC_HEADER_ID," + "BC_HEADER_ID : " + db_bc_header_id + "," + "BC_HEADER_ID was found," + db_CONS_STATUS + "," + "Pass";
                                section2_results.add(cons_BASE_CURRENCY_AMOUNT);
                                cons_mandatory_map_row++;
                            }

                            //SOURCE - mandatory validation
                            if ((db_source == ("null")) && (db_CONS_STATUS != "REVIEW")) {

                                String cons_BASE_CURRENCY_AMOUNT = "," +  ",SOURCE," + "SOURCE : " + db_source + "," + "SOURCE was not found," + db_CONS_STATUS + "," + "Fail";
                                section2_results.add(cons_BASE_CURRENCY_AMOUNT);
                            } else {
                                String cons_BASE_CURRENCY_AMOUNT = "," +  ",SOURCE," + "SOURCE : " + db_source + "," + "SOURCE was found," + db_CONS_STATUS + "," + "Pass";
                                section2_results.add(cons_BASE_CURRENCY_AMOUNT);
                            }

                            //ACCOUNT_NUMBER - mandatory validation
                            if ((db_account_number == null) && (db_CONS_STATUS != "REVIEW")) {

                                String cons_BASE_CURRENCY_AMOUNT = "," +  ",ACCOUNT_NUMBER," + "ACCOUNT_NUMBER : " + db_account_number + "," + "ACCOUNT_NUMBER was not found," + db_CONS_STATUS + "," + "Fail";
                                section2_results.add(cons_BASE_CURRENCY_AMOUNT);
                            } else {
                                String cons_BASE_CURRENCY_AMOUNT = "," +  ",ACCOUNT_NUMBER," + "ACCOUNT_NUMBER : " + db_account_number + "," + "ACCOUNT_NUMBER was found," + db_CONS_STATUS + "," + "Pass";
                                section2_results.add(cons_BASE_CURRENCY_AMOUNT);
                            }

                            //POLICY_NUMBER - mandatory validation
                            if ((db_policy_number == null) && (db_CONS_STATUS != "REVIEW")) {

                                String cons_BASE_CURRENCY_AMOUNT = "," +  ",POLICY_NUMBER," + "POLICY_NUMBER : " + db_policy_number + "," + "POLICY_NUMBER was not found," + db_CONS_STATUS + "," + "Fail";
                                section2_results.add(cons_BASE_CURRENCY_AMOUNT);
                            } else {
                                String cons_BASE_CURRENCY_AMOUNT = "," +  ",POLICY_NUMBER," + "POLICY_NUMBER : " + db_policy_number + "," + "POLICY_NUMBER was found," + db_CONS_STATUS + "," + "Pass";
                                section2_results.add(cons_BASE_CURRENCY_AMOUNT);
                            }

                            //UNDERWRITER - mandatory validation
                            if ((db_underwriter == null) && (db_CONS_STATUS != "REVIEW")) {

                                String cons_BASE_CURRENCY_AMOUNT = "," +  ",UNDERWRITER," + "UNDERWRITER : " + db_underwriter + "," + "UNDERWRITER was not found," + db_CONS_STATUS + "," + "Fail";
                                section2_results.add(cons_BASE_CURRENCY_AMOUNT);
                            } else {
                                String cons_BASE_CURRENCY_AMOUNT = "," +  ",UNDERWRITER," + "UNDERWRITER : " + db_underwriter + "," + "UNDERWRITER was found," + db_CONS_STATUS + "," + "Pass";
                                section2_results.add(cons_BASE_CURRENCY_AMOUNT);
                            }

                            //PRODUCT_TYPE - mandatory validation
                            if ((db_product_type == null) && (db_CONS_STATUS != "REVIEW")) {

                                String cons_BASE_CURRENCY_AMOUNT = "," +  ",PRODUCT_TYPE," + "PRODUCT_TYPE : " + db_product_type + "," + "PRODUCT_TYPE was not found," + db_CONS_STATUS + "," + "Fail";
                                section2_results.add(cons_BASE_CURRENCY_AMOUNT);
                            } else {
                                String cons_BASE_CURRENCY_AMOUNT = "," +  ",PRODUCT_TYPE," + "PRODUCT_TYPE : " + db_product_type + "," + "PRODUCT_TYPE was found," + db_CONS_STATUS + "," + "Pass";
                                section2_results.add(cons_BASE_CURRENCY_AMOUNT);
                            }

                            //LINE_OF_BUSINESS - mandatory validation
                            if ((db_line_of_business == null) && (db_CONS_STATUS != "REVIEW")) {

                                String cons_BASE_CURRENCY_AMOUNT = "," +  ",LINE_OF_BUSINESS," + "LINE_OF_BUSINESS : " + db_line_of_business + "," + "LINE_OF_BUSINESS was not found," + db_CONS_STATUS + "," + "Fail";
                                section2_results.add(cons_BASE_CURRENCY_AMOUNT);
                            } else {
                                String cons_BASE_CURRENCY_AMOUNT = "," +  ",LINE_OF_BUSINESS," + "LINE_OF_BUSINESS : " + db_line_of_business + "," + "LINE_OF_BUSINESS was found," + db_CONS_STATUS + "," + "Pass";
                                section2_results.add(cons_BASE_CURRENCY_AMOUNT);
                            }

                            //TRANSACTION_REFERENCE - mandatory validation
                            if ((db_transaction_reference == null) && (db_CONS_STATUS != "REVIEW")) {

                                String cons_BASE_CURRENCY_AMOUNT = "," +  ",TRANSACTION_REFERENCE," + "TRANSACTION_REFERENCE : " + db_transaction_reference + "," + "TRANSACTION_REFERENCE was not found," + db_CONS_STATUS + "," + "Fail";
                                section2_results.add(cons_BASE_CURRENCY_AMOUNT);
                            } else {
                                String cons_BASE_CURRENCY_AMOUNT = "," +  ",TRANSACTION_REFERENCE," + "TRANSACTION_REFERENCE : " + db_transaction_reference + "," + "TRANSACTION_REFERENCE was found," + db_CONS_STATUS + "," + "Pass";
                                section2_results.add(cons_BASE_CURRENCY_AMOUNT);
                            }

                            //TRANSACTION_DATE - mandatory validation
                            if ((db_transaction_date == null) && (db_CONS_STATUS != "REVIEW")) {

                                String cons_BASE_CURRENCY_AMOUNT = "," +  ",TRANSACTION_DATE," + "TRANSACTION_DATE : " + db_transaction_date + "," + "TRANSACTION_DATE was not found," + db_CONS_STATUS + "," + "Fail";
                                section2_results.add(cons_BASE_CURRENCY_AMOUNT);
                            } else {
                                String cons_BASE_CURRENCY_AMOUNT = "," +  ",TRANSACTION_DATE," + "TRANSACTION_DATE : " + db_transaction_date + "," + "TRANSACTION_DATE was found," + db_CONS_STATUS + "," + "Pass";
                                section2_results.add(cons_BASE_CURRENCY_AMOUNT);
                            }

                            //TRANSACTION_SUBTYPE - mandatory validation
                            if ((db_transaction_sub_type == null) && (db_CONS_STATUS != "REVIEW")) {

                                String cons_BASE_CURRENCY_AMOUNT = "," +  ",TRANSACTION_SUBTYPE," + "TRANSACTION_SUBTYPE : " + db_transaction_sub_type + "," + "TRANSACTION_SUBTYPE was not found," + db_CONS_STATUS + "," + "Fail";
                                section2_results.add(cons_BASE_CURRENCY_AMOUNT);
                            } else {
                                String cons_BASE_CURRENCY_AMOUNT = "," +  ",TRANSACTION_SUBTYPE," + "TRANSACTION_SUBTYPE : " + db_transaction_sub_type + "," + "TRANSACTION_SUBTYPE was found," + db_CONS_STATUS + "," + "Pass";
                                section2_results.add(cons_BASE_CURRENCY_AMOUNT);
                            }

                            //TRANSACTION_REASON - mandatory validation
                            if ((db_transaction_reason == null) && (db_CONS_STATUS != "REVIEW")) {

                                String cons_BASE_CURRENCY_AMOUNT = "," +  ",TRANSACTION_REASON," + "TRANSACTION_REASON : " + db_transaction_reason + "," + "TRANSACTION_REASON was not found," + db_CONS_STATUS + "," + "Fail";
                                section2_results.add(cons_BASE_CURRENCY_AMOUNT);
                            } else {
                                String cons_BASE_CURRENCY_AMOUNT = "," +  ",TRANSACTION_REASON," + "TRANSACTION_REASON : " + db_transaction_reason + "," + "TRANSACTION_REASON was found," + db_CONS_STATUS + "," + "Pass";
                                section2_results.add(cons_BASE_CURRENCY_AMOUNT);
                            }

                            //PAYMENT_METHOD - mandatory validation
                            if ((db_payment_method == null) && (db_CONS_STATUS != "REVIEW")) {

                                String cons_BASE_CURRENCY_AMOUNT = "," +  ",PAYMENT_METHOD," + "PAYMENT_METHOD : " + db_payment_method + "," + "PAYMENT_METHOD was not found," + db_CONS_STATUS + "," + "Fail";
                                section2_results.add(cons_BASE_CURRENCY_AMOUNT);
                            } else {
                                String cons_BASE_CURRENCY_AMOUNT = "," +  ",PAYMENT_METHOD," + "PAYMENT_METHOD : " + db_payment_method + "," + "PAYMENT_METHOD was found," + db_CONS_STATUS + "," + "Pass";
                                section2_results.add(cons_BASE_CURRENCY_AMOUNT);
                            }

                            //CHANNEL - mandatory validation
                            if ((db_channel == null) && (db_CONS_STATUS != "REVIEW")) {

                                String cons_BASE_CURRENCY_AMOUNT = "," +  ",CHANNEL," + "CHANNEL : " + db_channel + "," + "CHANNEL was not found," + db_CONS_STATUS + "," + "Fail";
                                section2_results.add(cons_BASE_CURRENCY_AMOUNT);
                            } else {
                                String cons_BASE_CURRENCY_AMOUNT = "," +  ",CHANNEL," + "CHANNEL : " + db_channel + "," + "CHANNEL was found," + db_CONS_STATUS + "," + "Pass";
                                section2_results.add(cons_BASE_CURRENCY_AMOUNT);
                            }

                            //CURRENCY_CD - mandatory validation
                            if ((db_currency_code == null) && (db_CONS_STATUS != "REVIEW")) {

                                String cons_BASE_CURRENCY_AMOUNT = "," +  ",CURRENCY_CD," + "CURRENCY_CD : " + db_currency_code + "," + "CURRENCY_CD was not found," + db_CONS_STATUS + "," + "Fail";
                                section2_results.add(cons_BASE_CURRENCY_AMOUNT);
                            } else {
                                String cons_BASE_CURRENCY_AMOUNT = "," +  ",CURRENCY_CD," + "CURRENCY_CD : " + db_currency_code + "," + "CURRENCY_CD was found," + db_CONS_STATUS + "," + "Pass";
                                section2_results.add(cons_BASE_CURRENCY_AMOUNT);
                            }

                            //EXCHANGE_RATE - mandatory validation
                            if ((db_exchange_rate == null) && (db_CONS_STATUS != "REVIEW")) {

                                String cons_BASE_CURRENCY_AMOUNT = "," +  ",EXCHANGE_RATE," + "EXCHANGE_RATE : " + db_exchange_rate + "," + "EXCHANGE_RATE was not found," + db_CONS_STATUS + "," + "Fail";
                                section2_results.add(cons_BASE_CURRENCY_AMOUNT);
                            } else {
                                String cons_BASE_CURRENCY_AMOUNT = "," +  ",EXCHANGE_RATE," + "EXCHANGE_RATE : " + db_exchange_rate + "," + "EXCHANGE_RATE was found," + db_CONS_STATUS + "," + "Pass";
                                section2_results.add(cons_BASE_CURRENCY_AMOUNT);
                            }

                            //EXCHANGE_RATE_TYPE - mandatory validation
                            if ((db_exchange_rate_type == null) && (db_CONS_STATUS != "REVIEW")) {

                                String cons_BASE_CURRENCY_AMOUNT = "," +  ",EXCHANGE_RATE_TYPE," + "EXCHANGE_RATE_TYPE : " + db_exchange_rate_type + "," + "EXCHANGE_RATE_TYPE was not found," + db_CONS_STATUS + "," + "Fail";
                                section2_results.add(cons_BASE_CURRENCY_AMOUNT);
                            } else {
                                String cons_BASE_CURRENCY_AMOUNT = "," +  ",EXCHANGE_RATE_TYPE," + "EXCHANGE_RATE_TYPE : " + db_exchange_rate_type + "," + "EXCHANGE_RATE_TYPE was found," + db_CONS_STATUS + "," + "Pass";
                                section2_results.add(cons_BASE_CURRENCY_AMOUNT);
                            }

                            //BASE_CURRENCY_AMOUNT - mandatory validation
                            if ((db_base_currency_amount == null) && (db_CONS_STATUS != "REVIEW")) {

                                String cons_BASE_CURRENCY_AMOUNT = "," +  ",BASE_CURRENCY_AMOUNT," + "BASE_CURRENCY_AMOUNT : " + db_base_currency_amount + "," + "BASE_CURRENCY_AMOUNT was not found," + db_CONS_STATUS + "," + "Fail";
                                section2_results.add(cons_BASE_CURRENCY_AMOUNT);
                            } else {
                                String cons_BASE_CURRENCY_AMOUNT = "," +  ",BASE_CURRENCY_AMOUNT," + "BASE_CURRENCY_AMOUNT : " + db_base_currency_amount + "," + "BASE_CURRENCY_AMOUNT was found," + db_CONS_STATUS + "," + "Pass";
                                section2_results.add(cons_BASE_CURRENCY_AMOUNT);
                            }

                            //EXCHANGE_DATE - mandatory validation
                            if ((db_exchange_date == null) && (db_CONS_STATUS != "REVIEW")) {

                                String cons_BASE_CURRENCY_AMOUNT = "," +  ",EXCHANGE_DATE," + "EXCHANGE_DATE : " + db_exchange_date + "," + "EXCHANGE_DATE was not found," + db_CONS_STATUS + "," + "Fail";
                                section2_results.add(cons_BASE_CURRENCY_AMOUNT);
                            } else {
                                String cons_BASE_CURRENCY_AMOUNT = "," +  ",EXCHANGE_DATE," + "EXCHANGE_DATE : " + db_exchange_date + "," + "EXCHANGE_DATE was found," + db_CONS_STATUS + "," + "Pass";
                                section2_results.add(cons_BASE_CURRENCY_AMOUNT);
                            }

                            //CROSS_REFERENCE - mandatory validation
                            if ((db_cross_reference == null) && (db_CONS_STATUS != "REVIEW")) {

                                String cons_BASE_CURRENCY_AMOUNT = "," +  ",CROSS_REFERENCE," + "CROSS_REFERENCE : " + db_cross_reference + "," + "CROSS_REFERENCE was not found," + db_CONS_STATUS + "," + "Fail";
                                section2_results.add(cons_BASE_CURRENCY_AMOUNT);
                            } else {
                                String cons_BASE_CURRENCY_AMOUNT = "," +  ",CROSS_REFERENCE," + "CROSS_REFERENCE : " + db_cross_reference + "," + "CROSS_REFERENCE was found," + db_CONS_STATUS + "," + "Pass";
                                section2_results.add(cons_BASE_CURRENCY_AMOUNT);
                            }

                            //BC_LINE_ID - mandatory validation
                            if ((db_bc_line_id == null) && (db_CONS_STATUS != "REVIEW")) {

                                String cons_BASE_CURRENCY_AMOUNT = "," +  ",BC_LINE_ID," + "BC_LINE_ID : " + db_bc_line_id + "," + "BC_LINE_ID was not found," + db_CONS_STATUS + "," + "Fail";
                                section2_results.add(cons_BASE_CURRENCY_AMOUNT);
                            } else {
                                String cons_BASE_CURRENCY_AMOUNT = "," +  ",BC_LINE_ID," + "BC_LINE_ID : " + db_bc_line_id + "," + "BC_LINE_ID was found," + db_CONS_STATUS + "," + "Pass";
                                section2_results.add(cons_BASE_CURRENCY_AMOUNT);
                            }

                            //DR_CR_FLAG - mandatory validation
                            if ((db_dr_cr_flag == null) && (db_CONS_STATUS != "REVIEW")) {

                                String cons_BASE_CURRENCY_AMOUNT = "," +  ",DR_CR_FLAG," + "DR_CR_FLAG : " + db_dr_cr_flag + "," + "DR_CR_FLAG was not found," + db_CONS_STATUS + "," + "Fail";
                                section2_results.add(cons_BASE_CURRENCY_AMOUNT);
                            } else {
                                String cons_BASE_CURRENCY_AMOUNT = "," +  ",DR_CR_FLAG," + "DR_CR_FLAG : " + db_dr_cr_flag + "," + "DR_CR_FLAG was found," + db_CONS_STATUS + "," + "Pass";
                                section2_results.add(cons_BASE_CURRENCY_AMOUNT);
                            }

                            //AMOUNT - mandatory validation
                            if ((db_amount == null) && (db_CONS_STATUS != "REVIEW")) {

                                String cons_BASE_CURRENCY_AMOUNT = "," +  ",AMOUNT," + "AMOUNT : " + db_amount + "," + "AMOUNT was not found," + db_CONS_STATUS + "," + "Fail";
                                section2_results.add(cons_BASE_CURRENCY_AMOUNT);
                            } else {
                                String cons_BASE_CURRENCY_AMOUNT = "," +  ",AMOUNT," + "AMOUNT : " + db_amount + "," + "AMOUNT was found," + db_CONS_STATUS + "," + "Pass";
                                section2_results.add(cons_BASE_CURRENCY_AMOUNT);
                            }

                            //------------------- Consolidation to Staging ----------------------------------
                            String TravelGLBilling_stgSqlQuery = connect_db.executeQuery_DB("TravelGL", "GLBilling_Stg","TRAVEL");
                            SQLResultset_fsh = SQLstmt.executeQuery(TravelGLBilling_stgSqlQuery + "'"+file_name+ "' and HEADER_ID = '" + list_header.get(i) + "' " );
                            //SQLResultset_fsh = SQLstmt.executeQuery("SELECT *  from DLG_FSH_STG_COMM_BCCC_HDR  WHERE FILE_NAME = '" + xml_file_name + "' and HEADER_ID = '" + list_header.get(i) + "' ");
                            if (!SQLResultset_fsh.next()) {
                                String stg_header_id = section2_map_row + ",HEADER_ID," + "no records available in STG table" + "," + db_bc_header_id + ",Fail";
                                section2_results.add(stg_header_id);
                            } else {
                                SQLResultset_fsh = SQLstmt.executeQuery(TravelGLBilling_stgSqlQuery + "'"+file_name+ "' and HEADER_ID = '" + list_header.get(i) + "' " );
                                while (SQLResultset_fsh.next()) {

                                db_stg_bc_header_id = SQLResultset_fsh.getString("HEADER_ID");
                                db_stg_source = SQLResultset_fsh.getString("SOURCE");
                                db_stg_entity_type_code = SQLResultset_fsh.getString("ENTITY_TYPE_CODE");
                                db_stg_account_number = SQLResultset_fsh.getString("ACCOUNT_NUMBER");
                                db_stg_policy_number = SQLResultset_fsh.getString("POLICY_NUMBER");
                                db_stg_underwriter = SQLResultset_fsh.getString("UNDERWRITER");
                                db_stg_product_type = SQLResultset_fsh.getString("PRODUCT_TYPE");
                                db_stg_line_of_business = SQLResultset_fsh.getString("LINE_OF_BUSINESS");
                                db_stg_transaction_reference = SQLResultset_fsh.getString("TRANSACTION_REFERENCE");
                                db_stg_transaction_date = SQLResultset_fsh.getString("TRANSACTION_DATE");
                                db_stg_transaction_sub_type = SQLResultset_fsh.getString("TRANSACTION_SUB_TYPE");
                                db_stg_transaction_reason = SQLResultset_fsh.getString("TRANSACTION_REASON");
                                db_stg_payment_method = SQLResultset_fsh.getString("PAYMENT_METHOD");
                                db_stg_sun_number = SQLResultset_fsh.getString("SUN_NUMBER");
                                db_stg_mid_number = SQLResultset_fsh.getString("MID_NUMBER");
                                db_stg_ddi_reference = SQLResultset_fsh.getString("DDI_REFERENCE");
                                db_stg_card_type = SQLResultset_fsh.getString("CARD_TYPE");
                                db_stg_bacs_narrative = SQLResultset_fsh.getString("BACS_NARRATIVE");
                                db_stg_channel = SQLResultset_fsh.getString("CHANNEL");
                                db_stg_order_number = SQLResultset_fsh.getString("ORDER_NUMBER");
                                db_stg_reversal_indicator = SQLResultset_fsh.getString("REVERSAL_INDICATOR");
                                db_stg_currency_code = SQLResultset_fsh.getString("CURRENCY_CODE");
                                db_stg_exchange_rate = SQLResultset_fsh.getString("EXCHANGE_RATE");
                                db_stg_exchange_rate_type = SQLResultset_fsh.getString("EXCHANGE_RATE_TYPE");
                                db_stg_base_currency_amount = SQLResultset_fsh.getString("BASE_CURRENCY_AMOUNT");
                                db_stg_credit_ind = SQLResultset_fsh.getString("CREDIT_IND");
                                db_stg_currency_amount = SQLResultset_fsh.getString("CURRENCY_AMOUNT");
                                db_stg_pay_in_slip_number = SQLResultset_fsh.getString("PAY_IN_SLIP_NUMBER");
                                db_stg_cheque_number = SQLResultset_fsh.getString("CHEQUE_NUMBER");
                                db_stg_card_narrative = SQLResultset_fsh.getString("CARD_NARRATIVE");
                                db_stg_base_interest_amount = SQLResultset_fsh.getString("BASE_INTEREST_AMOUNT");
                                db_stg_tax_deductible = SQLResultset_fsh.getString("TAX_DEDUCTIBLE");
                                db_stg_payment_transaction_type_id = SQLResultset_fsh.getString("PAYMENT_TRANSACTION_TYPE_ID");
                                db_stg_event_code = SQLResultset_fsh.getString("EVENT_CODE");
                                db_stg_event_type_code = SQLResultset_fsh.getString("ENTITY_TYPE_CODE");
                                db_stg_status = SQLResultset_fsh.getString("STATUS");
                                db_stg_interest_amount = SQLResultset_fsh.getString("INTEREST_AMOUNT");
                                db_stg_interest_currency_code = SQLResultset_fsh.getString("INTEREST_CURRENCY_CODE");
                                db_stg_batch_fkey = SQLResultset_fsh.getString("BATCH_FKEY");
                                db_stg_file_name = SQLResultset_fsh.getString("FILE_NAME");
                                db_stg_summary_flag = SQLResultset_fsh.getString("SUMMARY_FLAG");
                                STG_HDR_STATUS = SQLResultset_fsh.getString("STATUS");
                                load_date = SQLResultset_fsh.getString("LOAD_DATE");

                                    //Converting Load date format
                                    String load_dateTRIM = load_date.substring(0, 10);
                                    load_dateFormat = Date.valueOf(load_dateTRIM);
                                    System.out.println(load_dateFormat);

                                //Staging mandatory validations

                                    //HEADER_ID - mandatory validation
                                    if ((db_stg_bc_header_id == null) && (STG_HDR_STATUS != "REVIEW")) {

                                        String stg_header_id = stg_line_map_row + "," + db_stg_bc_header_id + ",HEADER_ID," + "HEADER_ID : " + db_stg_bc_header_id + "," + "HEADER_ID was not found," + STG_HDR_STATUS + "," + "Fail";
                                        section4_results.add(stg_header_id);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",HEADER_ID :" + db_stg_bc_header_id +  ",HEADER_ID was not found, " + STG_HDR_STATUS + ",Fail," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        stg_line_map_row++;
                                        CONS_flag++;
                                    } else {
                                        String stg_header_id = stg_line_map_row + "," + db_stg_bc_header_id + ",HEADER_ID," + "HEADER_ID : " + db_stg_bc_header_id + "," + "HEADER_ID was found," + STG_HDR_STATUS + "," + "Pass";
                                        section4_results.add(stg_header_id);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",HEADER_ID :" + db_stg_bc_header_id +  ",HEADER_ID was found, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        stg_line_map_row++;
                                        CONS_flag++;
                                    }



                                    //SOURCE - mandatory validation
                                    if(!STG_HDR_STATUS.equals("DEAD")) {
                                        if ((db_stg_source == null) && (STG_HDR_STATUS != "REVIEW")) {

                                            String stg_header_id = "," + ",SOURCE," + "SOURCE : " + db_stg_source + "," + "SOURCE was not found," + STG_HDR_STATUS + "," + "Fail";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SOURCE :" + db_stg_source +  ",SOURCE was not found, " + STG_HDR_STATUS + ",Fail," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            stg_line_map_row++;
                                            CONS_flag++;
                                        } else {
                                            String stg_header_id = "," + ",SOURCE," + "SOURCE : " + db_stg_source + "," + "SOURCE was found," + STG_HDR_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SOURCE :" + db_stg_source +  ",SOURCE was found, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            stg_line_map_row++;
                                        }
                                    } else {
                                        String stg_header_id = "," + ",ITS A DEAD RECORD - Ignore mandatory validation for SOURCE," + "SOURCE : " + db_stg_source + "," + "SOURCE is not mandatory  as it is DEAD," + STG_HDR_STATUS + "," + "Pass";
                                        section4_results.add(stg_header_id);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SOURCE :" + db_stg_source +  ",SOURCE is not mandatory  as it is DEAD, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        stg_line_map_row++;
                                        CONS_flag++;
                                    }

                                    //ACCOUNT_NUMBER - mandatory validation
                                    if(!STG_HDR_STATUS.equals("DEAD")) {
                                        if ((db_stg_account_number == null) && (STG_HDR_STATUS != "REVIEW")) {

                                            String stg_header_id = "," + ",ACCOUNT_NUMBER," + "ACCOUNT_NUMBER : " + db_stg_account_number + "," + "ACCOUNT_NUMBER was not found," + STG_HDR_STATUS + "," + "Fail";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ACCOUNT_NUMBER :" + db_stg_account_number +  ",ACCOUNT_NUMBER was not found, " + STG_HDR_STATUS + ",Fail," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        } else {
                                            String stg_header_id = "," + ",ACCOUNT_NUMBER," + "ACCOUNT_NUMBER : " + db_stg_account_number + "," + "ACCOUNT_NUMBER was found," + STG_HDR_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ACCOUNT_NUMBER :" + db_stg_account_number +  ",ACCOUNT_NUMBER was found, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        }
                                    } else {
                                        String stg_header_id = "," + ",ITS A DEAD RECORD - Ignore mandatory validation for ACCOUNT_NUMBER," + "ACCOUNT_NUMBER : " + db_stg_account_number + "," + "ACCOUNT_NUMBER is not mandatory  as it is DEAD," + STG_HDR_STATUS + "," + "Pass";
                                        section4_results.add(stg_header_id);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ACCOUNT_NUMBER :" + db_stg_account_number +  ",ACCOUNT_NUMBER is not mandatory  as it is DEAD, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    }

                                    //POLICY_NUMBER - mandatory validation
                                    if(!STG_HDR_STATUS.equals("DEAD")) {
                                        if ((db_stg_policy_number == null) && (STG_HDR_STATUS != "REVIEW")) {

                                            String stg_header_id = "," + ",POLICY_NUMBER," + "POLICY_NUMBER : " + db_stg_policy_number + "," + "POLICY_NUMBER was not found," + STG_HDR_STATUS + "," + "Fail";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",POLICY_NUMBER :" + db_stg_policy_number +  ",POLICY_NUMBER was not found, " + STG_HDR_STATUS + ",Fail," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        } else {
                                            String stg_header_id = "," + ",POLICY_NUMBER," + "POLICY_NUMBER : " + db_stg_policy_number + "," + "POLICY_NUMBER was found," + STG_HDR_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",POLICY_NUMBER :" + db_stg_policy_number +  ",POLICY_NUMBER was found, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        }
                                    } else {
                                        String stg_header_id = "," + ",ITS A DEAD RECORD - Ignore mandatory validation for POLICY_NUMBER," + "POLICY_NUMBER : " + db_stg_policy_number + "," + "POLICY_NUMBER is not mandatory  as it is DEAD," + STG_HDR_STATUS + "," + "Pass";
                                        section4_results.add(stg_header_id);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",POLICY_NUMBER :" + db_stg_policy_number +  ",POLICY_NUMBER is not mandatory  as it is DEAD, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    }

                                    //UNDERWRITER - mandatory validation
                                    if(!STG_HDR_STATUS.equals("DEAD")) {
                                        if ((db_stg_underwriter == null) && (STG_HDR_STATUS != "REVIEW")) {

                                            String stg_header_id = "," + ",UNDERWRITER," + "UNDERWRITER : " + db_stg_underwriter + "," + "UNDERWRITER was not found," + STG_HDR_STATUS + "," + "Fail";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern +  ",UNDERWRITER :" + db_stg_underwriter +  ",UNDERWRITER was not found, " + STG_HDR_STATUS + ",Fail," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        } else {
                                            String stg_header_id = "," + ",UNDERWRITER," + "UNDERWRITER : " + db_stg_underwriter + "," + "UNDERWRITER was found," + STG_HDR_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",UNDERWRITER :" + db_stg_underwriter +  ",UNDERWRITER was found, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        }
                                    } else {
                                        String stg_header_id = "," + ",ITS A DEAD RECORD - Ignore mandatory validation for UNDERWRITER," + "UNDERWRITER : " + db_stg_underwriter + "," + "UNDERWRITER is not mandatory  as it is DEAD," + STG_HDR_STATUS + "," + "Pass";
                                        section4_results.add(stg_header_id);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",UNDERWRITER :" + db_stg_underwriter +  ",UNDERWRITER is not mandatory  as it is DEAD, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    }

                                    //PRODUCT_TYPE - mandatory validation
                                    if(!STG_HDR_STATUS.equals("DEAD")) {
                                        if ((db_stg_product_type == null) && (STG_HDR_STATUS != "REVIEW")) {

                                            String stg_header_id = "," + ",PRODUCT_TYPE," + "PRODUCT_TYPE : " + db_stg_product_type + "," + "PRODUCT_TYPE was not found," + STG_HDR_STATUS + "," + "Fail";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT_TYPE :" + db_stg_product_type +  ",PRODUCT_TYPE was not found, " + STG_HDR_STATUS + ",Fail," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        } else {
                                            String stg_header_id = "," + ",PRODUCT_TYPE," + "PRODUCT_TYPE : " + db_stg_product_type + "," + "PRODUCT_TYPE was found," + STG_HDR_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT_TYPE :" + db_stg_product_type +  ",PRODUCT_TYPE was found, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        }
                                    } else {
                                        String stg_header_id = "," + ",ITS A DEAD RECORD - Ignore mandatory validation for PRODUCT_TYPE," + "PRODUCT_TYPE : " + db_stg_product_type + "," + "PRODUCT_TYPE is not mandatory  as it is DEAD," + STG_HDR_STATUS + "," + "Pass";
                                        section4_results.add(stg_header_id);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT_TYPE :" + db_stg_product_type +  ",PRODUCT_TYPE is not mandatory  as it is DEAD, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    }

                                    //LINE_OF_BUSINESS - mandatory validation
                                    if(!STG_HDR_STATUS.equals("DEAD")) {
                                        if ((db_stg_line_of_business == null) && (STG_HDR_STATUS != "REVIEW")) {

                                            String stg_header_id = "," + ",LINE_OF_BUSINESS," + "LINE_OF_BUSINESS : " + db_stg_line_of_business + "," + "LINE_OF_BUSINESS was not found," + STG_HDR_STATUS + "," + "Fail";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",LINE_OF_BUSINESS :" + db_stg_line_of_business +  ",LINE_OF_BUSINESS was not found, " + STG_HDR_STATUS + ",Fail," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        } else {
                                            String stg_header_id = "," + ",LINE_OF_BUSINESS," + "LINE_OF_BUSINESS : " + db_stg_line_of_business + "," + "LINE_OF_BUSINESS was found," + STG_HDR_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",LINE_OF_BUSINESS :" + db_stg_line_of_business +  ",LINE_OF_BUSINESS was found, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        }
                                    } else {
                                        String stg_header_id = "," + ",ITS A DEAD RECORD - Ignore mandatory validation for LINE_OF_BUSINESS," + "LINE_OF_BUSINESS : " + db_stg_line_of_business + "," + "LINE_OF_BUSINESS is not mandatory  as it is DEAD," + STG_HDR_STATUS + "," + "Pass";
                                        section4_results.add(stg_header_id);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",LINE_OF_BUSINESS :" + db_stg_line_of_business +  ",LINE_OF_BUSINESS is not mandatory  as it is DEAD, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    }

                                    //TRANSACTION_REFERENCE - mandatory validation
                                    if(!STG_HDR_STATUS.equals("DEAD")) {
                                        if ((db_stg_transaction_reference == null) && (STG_HDR_STATUS != "REVIEW")) {

                                            String stg_header_id = "," + ",TRANSACTION_REFERENCE," + "TRANSACTION_REFERENCE : " + db_stg_transaction_reference + "," + "TRANSACTION_REFERENCE was not found," + STG_HDR_STATUS + "," + "Fail";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_REFERENCE :" + db_stg_transaction_reference +  ",TRANSACTION_REFERENCE was not found, " + STG_HDR_STATUS + ",Fail," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        } else {
                                            String stg_header_id = "," + ",TRANSACTION_REFERENCE," + "TRANSACTION_REFERENCE : " + db_stg_transaction_reference + "," + "TRANSACTION_REFERENCE was found," + STG_HDR_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_REFERENCE :" + db_stg_transaction_reference +  ",TRANSACTION_REFERENCE was found, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        }
                                    } else {
                                        String stg_header_id = "," + ",ITS A DEAD RECORD - Ignore mandatory validation for TRANSACTION_REFERENCE," + "TRANSACTION_REFERENCE : " + db_stg_transaction_reference + "," + "TRANSACTION_REFERENCE is not mandatory  as it is DEAD," + STG_HDR_STATUS + "," + "Pass";
                                        section4_results.add(stg_header_id);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_REFERENCE :" + db_stg_transaction_reference +  ",TRANSACTION_REFERENCE is not mandatory  as it is DEAD, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    }

                                    //TRANSACTION_DATE - mandatory validation
                                    if(!STG_HDR_STATUS.equals("DEAD")) {
                                        if ((db_stg_transaction_date == null) && (STG_HDR_STATUS != "REVIEW")) {

                                            String stg_header_id = "," + ",TRANSACTION_DATE," + "TRANSACTION_DATE : " + db_stg_transaction_date + "," + "TRANSACTION_DATE was not found," + STG_HDR_STATUS + "," + "Fail";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE :" + db_stg_transaction_date +  ",TRANSACTION_DATE was not found, " + STG_HDR_STATUS + ",Fail," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        } else {
                                            String stg_header_id = "," + ",TRANSACTION_DATE," + "TRANSACTION_DATE : " + db_stg_transaction_date + "," + "TRANSACTION_DATE was found," + STG_HDR_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE :" + db_stg_transaction_date +  ",TRANSACTION_DATE was found, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        }
                                    } else {
                                        String stg_header_id = "," + ",ITS A DEAD RECORD - Ignore mandatory validation for TRANSACTION_DATE," + "TRANSACTION_DATE : " + db_stg_transaction_date + "," + "TRANSACTION_DATE is not mandatory  as it is DEAD," + STG_HDR_STATUS + "," + "Pass";
                                        section4_results.add(stg_header_id);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE :" + db_stg_transaction_date +  ",TRANSACTION_DATE is not mandatory  as it is DEAD, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    }


                                    //TRANSACTION_SUB_TYPE - mandatory validation
                                    if(!STG_HDR_STATUS.equals("DEAD")) {
                                        if ((db_stg_transaction_sub_type == null) && (STG_HDR_STATUS != "REVIEW")) {

                                            String stg_header_id = "," + ",TRANSACTION_SUB_TYPE," + "TRANSACTION_SUB_TYPE : " + db_stg_transaction_sub_type + "," + "TRANSACTION_SUB_TYPE was not found," + STG_HDR_STATUS + "," + "Fail";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_SUB_TYPE :" + db_stg_transaction_sub_type +  ",TRANSACTION_SUB_TYPE was not found, " + STG_HDR_STATUS + ",Fail," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        } else {
                                            String stg_header_id = "," + ",TRANSACTION_SUB_TYPE," + "TRANSACTION_SUB_TYPE : " + db_stg_transaction_sub_type + "," + "TRANSACTION_SUB_TYPE was found," + STG_HDR_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_SUB_TYPE :" + db_stg_transaction_sub_type +  ",TRANSACTION_SUB_TYPE was found, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        }
                                    } else {
                                        String stg_header_id = "," + ",ITS A DEAD RECORD - Ignore mandatory validation for TRANSACTION_SUB_TYPE," + "TRANSACTION_SUB_TYPE : " + db_stg_transaction_sub_type + "," + "TRANSACTION_SUB_TYPE is not mandatory  as it is DEAD," + STG_HDR_STATUS + "," + "Pass";
                                        section4_results.add(stg_header_id);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_SUB_TYPE :" + db_stg_transaction_sub_type +  ",TRANSACTION_SUB_TYPE is not mandatory  as it is DEAD, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    }

                                    //TRANSACTION_REASON - mandatory validation
                                    if(!STG_HDR_STATUS.equals("DEAD")) {
                                        if ((db_stg_transaction_reason == null) && (STG_HDR_STATUS != "REVIEW")) {

                                            String stg_header_id = "," + ",TRANSACTION_REASON," + "TRANSACTION_REASON : " + db_stg_transaction_reason + "," + "TRANSACTION_REASON was not found," + STG_HDR_STATUS + "," + "Fail";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_REASON :" + db_stg_transaction_reason +  ",TRANSACTION_REASON was not found, " + STG_HDR_STATUS + ",Fail," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        } else {
                                            String stg_header_id = "," + ",TRANSACTION_REASON," + "TRANSACTION_REASON : " + db_stg_transaction_reason + "," + "TRANSACTION_REASON was found," + STG_HDR_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_REASON :" + db_stg_transaction_reason +  ",TRANSACTION_REASON was found, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        }
                                    } else {
                                        String stg_header_id = "," + ",ITS A DEAD RECORD - Ignore mandatory validation for TRANSACTION_REASON," + "TRANSACTION_REASON : " + db_stg_transaction_reason + "," + "TRANSACTION_REASON is not mandatory  as it is DEAD," + STG_HDR_STATUS + "," + "Pass";
                                        section4_results.add(stg_header_id);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_REASON :" + db_stg_transaction_reason +  ",TRANSACTION_REASON is not mandatory  as it is DEAD, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    }

                                    //PAYMENT_METHOD - mandatory validation
                                    if(!STG_HDR_STATUS.equals("DEAD")) {
                                        if ((db_stg_payment_method == null) && (STG_HDR_STATUS != "REVIEW")) {

                                            String stg_header_id = "," + ",PAYMENT_METHOD," + "PAYMENT_METHOD : " + db_stg_payment_method + "," + "PAYMENT_METHOD was not found," + STG_HDR_STATUS + "," + "Fail";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAYMENT_METHOD :" + db_stg_payment_method +  ",PAYMENT_METHOD was not found, " + STG_HDR_STATUS + ",Fail," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        } else {
                                            String stg_header_id = "," + ",PAYMENT_METHOD," + "PAYMENT_METHOD : " + db_stg_payment_method + "," + "PAYMENT_METHOD was found," + STG_HDR_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAYMENT_METHOD :" + db_stg_payment_method +  ",PAYMENT_METHOD was found, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        }
                                    } else {
                                        String stg_header_id = "," + ",ITS A DEAD RECORD - Ignore mandatory validation for PAYMENT_METHOD," + "PAYMENT_METHOD : " + db_stg_payment_method + "," + "PAYMENT_METHOD is not mandatory  as it is DEAD," + STG_HDR_STATUS + "," + "Pass";
                                        section4_results.add(stg_header_id);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAYMENT_METHOD :" + db_stg_payment_method +  ",PAYMENT_METHOD is not mandatory  as it is DEAD, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    }

                                    //SUN_NUMBER - mandatory validation
                                    if(!STG_HDR_STATUS.equals("DEAD")) {
                                        if (db_stg_payment_method.contains("bacs")) {
                                            if ((db_stg_sun_number == null) && (STG_HDR_STATUS != "REVIEW")) {

                                                String stg_header_id = "," + ",SUN_NUMBER," + "SUN_NUMBER : " + db_stg_sun_number + "," + "SUN_NUMBER was not found," + STG_HDR_STATUS + "," + "Fail";
                                                section4_results.add(stg_header_id);
                                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SUN_NUMBER :" + db_stg_sun_number +  ",SUN_NUMBER was not found, " + STG_HDR_STATUS + ",Fail," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            } else {
                                                String stg_header_id = "," + ",SUN_NUMBER," + "SUN_NUMBER : " + db_stg_sun_number + "," + "SUN_NUMBER was found," + STG_HDR_STATUS + "," + "Pass";
                                                section4_results.add(stg_header_id);
                                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SUN_NUMBER :" + db_stg_sun_number +  ",SUN_NUMBER was found, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            }
                                        } else {
                                            String stg_header_id = "," + ",SUN_NUMBER," + "SUN_NUMBER : " + db_stg_sun_number + "," + "SUN_NUMBER is not mandatory  as it is DEAD," + STG_HDR_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SUN_NUMBER :" + db_stg_sun_number +  ",SUN_NUMBER is not mandatory  as it is DEAD, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        }
                                    } else {
                                        String stg_header_id = "," + ",ITS A DEAD RECORD - Ignore mandatory validation for SUN_NUMBER," + "SUN_NUMBER : " + db_stg_sun_number + "," + "SUN_NUMBER is not mandatory  as it is DEAD," + STG_HDR_STATUS + "," + "Pass";
                                        section4_results.add(stg_header_id);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SUN_NUMBER :" + db_stg_sun_number +  ",SUN_NUMBER is not mandatory  as it is DEAD, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    }

                                    //MID_NUMBER - mandatory validation
                                    if(!STG_HDR_STATUS.equals("DEAD")) {
                                        if (db_stg_payment_method.contains("card")) {
                                            if ((db_stg_mid_number == null) && (STG_HDR_STATUS != "REVIEW")) {

                                                String stg_header_id = "," + ",MID_NUMBER," + "MID_NUMBER : " + db_stg_mid_number + "," + "MID_NUMBER was not found," + STG_HDR_STATUS + "," + "Fail";
                                                section4_results.add(stg_header_id);
                                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",MID_NUMBER :" + db_stg_mid_number +  ",MID_NUMBER was not found, " + STG_HDR_STATUS + ",Fail," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            } else {
                                                String stg_header_id = "," + ",MID_NUMBER," + "MID_NUMBER : " + db_stg_mid_number + "," + "MID_NUMBER was found," + STG_HDR_STATUS + "," + "Pass";
                                                section4_results.add(stg_header_id);
                                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",MID_NUMBER :" + db_stg_mid_number +  ",MID_NUMBER was found, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            }
                                        } else {
                                            String stg_header_id = "," + ",MID_NUMBER," + "MID_NUMBER : " + db_stg_mid_number + "," + "MID_NUMBER is not mandatory  as it is DEAD," + STG_HDR_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",MID_NUMBER :" + db_stg_mid_number +  ",MID_NUMBER is not mandatory  as it is DEAD, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        }
                                    } else {
                                        String stg_header_id = "," + ",ITS A DEAD RECORD - Ignore mandatory validation for MID_NUMBER," + "MID_NUMBER : " + db_stg_mid_number + "," + "MID_NUMBER is not mandatory  as it is DEAD," + STG_HDR_STATUS + "," + "Pass";
                                        section4_results.add(stg_header_id);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",MID_NUMBER :" + db_stg_mid_number +  ",MID_NUMBER is not mandatory  as it is DEAD, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    }

                                    //DDI_REFERENCE - mandatory validation
                                    if(!STG_HDR_STATUS.equals("DEAD")) {
                                        if (db_stg_payment_method.contains("bacs")) {
                                            if ((db_stg_ddi_reference == null) && (STG_HDR_STATUS != "REVIEW")) {

                                                String stg_header_id = "," + ",DDI_REFERENCE," + "DDI_REFERENCE : " + db_stg_ddi_reference + "," + "DDI_REFERENCE was not found," + STG_HDR_STATUS + "," + "Fail";
                                                section4_results.add(stg_header_id);
                                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",DDI_REFERENCE :" + db_stg_ddi_reference +  ",DDI_REFERENCE was not found, " + STG_HDR_STATUS + ",Fail," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            } else {
                                                String stg_header_id = "," + ",DDI_REFERENCE," + "DDI_REFERENCE : " + db_stg_ddi_reference + "," + "DDI_REFERENCE was found," + STG_HDR_STATUS + "," + "Pass";
                                                section4_results.add(stg_header_id);
                                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",DDI_REFERENCE :" + db_stg_ddi_reference +  ",DDI_REFERENCE was found, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            }
                                        } else {
                                            String stg_header_id = "," + ",DDI_REFERENCE," + "DDI_REFERENCE : " + db_stg_ddi_reference + "," + "DDI_REFERENCE is not mandatory  as it is DEAD," + STG_HDR_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",DDI_REFERENCE :" + db_stg_ddi_reference +  ",DDI_REFERENCE is not mandatory  as it is DEAD, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        }
                                    } else {
                                        String stg_header_id = "," + ",ITS A DEAD RECORD - Ignore mandatory validation for DDI_REFERENCE," + "DDI_REFERENCE : " + db_stg_ddi_reference + "," + "DDI_REFERENCE is not mandatory  as it is DEAD," + STG_HDR_STATUS + "," + "Pass";
                                        section4_results.add(stg_header_id);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",DDI_REFERENCE :" + db_stg_ddi_reference +  ",DDI_REFERENCE is not mandatory  as it is DEAD, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    }

                                    //CARD_TYPE - mandatory validation
                                    if(!STG_HDR_STATUS.equals("DEAD")) {
                                        if (db_stg_payment_method.contains("card")) {
                                            if ((db_stg_card_type == null) && (STG_HDR_STATUS != "REVIEW")) {

                                                String stg_header_id = "," + ",CARD_TYPE," + "CARD_TYPE : " + db_stg_card_type + "," + "CARD_TYPE was not found," + STG_HDR_STATUS + "," + "Fail";
                                                section4_results.add(stg_header_id);
                                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CARD_TYPE :" + db_stg_source +  ",CARD_TYPE was not found, " + STG_HDR_STATUS + ",Fail," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            } else {
                                                String stg_header_id = "," + ",CARD_TYPE," + "CARD_TYPE : " + db_stg_card_type + "," + "CARD_TYPE was found," + STG_HDR_STATUS + "," + "Pass";
                                                section4_results.add(stg_header_id);
                                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CARD_TYPE :" + db_stg_source +  ",CARD_TYPE was found, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            }
                                        } else {
                                            String stg_header_id = "," + ",CARD_TYPE," + "CARD_TYPE : " + db_stg_card_type + "," + "CARD_TYPE is not mandatory  as it is DEAD," + STG_HDR_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CARD_TYPE :" + db_stg_source +  ",CARD_TYPE is not mandatory  as it is DEAD, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        }
                                    } else {
                                        String stg_header_id = "," + ",ITS A DEAD RECORD - Ignore mandatory validation for CARD_TYPE," + "CARD_TYPE : " + db_stg_card_type + "," + "CARD_TYPE is not mandatory  as it is DEAD," + STG_HDR_STATUS + "," + "Pass";
                                        section4_results.add(stg_header_id);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SOURCE :" + db_stg_source +  ",SOURCE is not mandatory  as it is DEAD, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    }

                                    //BACS_NARRATIVE - mandatory validation
                                    if(!STG_HDR_STATUS.equals("DEAD")) {
                                        if (db_stg_payment_method.contains("bacs")) {
                                            if ((db_stg_bacs_narrative == null) && (STG_HDR_STATUS != "REVIEW")) {

                                                String stg_header_id = "," + ",BACS_NARRATIVE," + "BACS_NARRATIVE : " + db_stg_bacs_narrative + "," + "BACS_NARRATIVE was not found," + STG_HDR_STATUS + "," + "Fail";
                                                section4_results.add(stg_header_id);
                                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BACS_NARRATIVE :" + db_stg_bacs_narrative +  ",BACS_NARRATIVE was not found, " + STG_HDR_STATUS + ",Fail," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            } else {
                                                String stg_header_id = "," + ",BACS_NARRATIVE," + "BACS_NARRATIVE : " + db_stg_bacs_narrative + "," + "BACS_NARRATIVE was found," + STG_HDR_STATUS + "," + "Pass";
                                                section4_results.add(stg_header_id);
                                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern +  ",BACS_NARRATIVE :" + db_stg_bacs_narrative +  ",BACS_NARRATIVE was found, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            }
                                        } else {
                                            String stg_header_id = "," + ",BACS_NARRATIVE," + "BACS_NARRATIVE : " + db_stg_bacs_narrative + "," + "BACS_NARRATIVE is not mandatory  as it is DEAD," + STG_HDR_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BACS_NARRATIVE :" + db_stg_bacs_narrative +  ",BACS_NARRATIVE is not mandatory  as it is DEAD, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        }
                                    } else {
                                        String stg_header_id = "," + ",ITS A DEAD RECORD - Ignore mandatory validation for BACS_NARRATIVE," + "BACS_NARRATIVE : " + db_stg_bacs_narrative + "," + "BACS_NARRATIVE is not mandatory  as it is DEAD," + STG_HDR_STATUS + "," + "Pass";
                                        section4_results.add(stg_header_id);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BACS_NARRATIVE :" + db_stg_bacs_narrative +  ",BACS_NARRATIVE is not mandatory  as it is DEAD, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    }

                                    //ORDER_NUMBER - mandatory validation
                                    if(!STG_HDR_STATUS.equals("DEAD")) {
                                        if (db_stg_payment_method.contains("card")) {
                                            if ((db_stg_order_number == null) && (STG_HDR_STATUS != "REVIEW")) {

                                                String stg_header_id = "," + ",ORDER_NUMBER," + "ORDER_NUMBER : " + db_stg_order_number + "," + "ORDER_NUMBER was not found," + STG_HDR_STATUS + "," + "Fail";
                                                section4_results.add(stg_header_id);
                                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern +  ",ORDER_NUMBER :" + db_stg_order_number +  ",ORDER_NUMBER was not found, " + STG_HDR_STATUS + ",Fail," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            } else {
                                                String stg_header_id = "," + ",ORDER_NUMBER," + "ORDER_NUMBER : " + db_stg_order_number + "," + "ORDER_NUMBER was found," + STG_HDR_STATUS + "," + "Pass";
                                                section4_results.add(stg_header_id);
                                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern +  ",ORDER_NUMBER :" + db_stg_order_number +  ",ORDER_NUMBER was found, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            }
                                        } else {
                                            String stg_header_id = "," + ",ORDER_NUMBER," + "ORDER_NUMBER : " + db_stg_order_number + "," + "ORDER_NUMBER is not a mandatory," + STG_HDR_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ORDER_NUMBER :" + db_stg_order_number +  ",ORDER_NUMBER is not a mandatory, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        }
                                    } else {
                                        String stg_header_id = "," + ",ITS A DEAD RECORD - Ignore mandatory validation for ORDER_NUMBER," + "ORDER_NUMBER : " + db_stg_order_number + "," + "ORDER_NUMBER is not mandatory  as it is DEAD," + STG_HDR_STATUS + "," + "Pass";
                                        section4_results.add(stg_header_id);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern +  ",ORDER_NUMBER :" + db_stg_order_number +  ",ORDER_NUMBER is not mandatory  as it is DEAD, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    }

                                    //CHANNEL - mandatory validation
                                    if(!STG_HDR_STATUS.equals("DEAD")) {
                                        if ((db_stg_channel == null) && (STG_HDR_STATUS != "REVIEW")) {

                                            String stg_header_id = "," + ",CHANNEL," + "CHANNEL : " + db_stg_channel + "," + "CHANNEL was not found," + STG_HDR_STATUS + "," + "Fail";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern +  ",CHANNEL :" + db_stg_channel +  ",CHANNEL was not found, " + STG_HDR_STATUS + ",Fail," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        } else {
                                            String stg_header_id = "," + ",CHANNEL," + "CHANNEL : " + db_stg_channel + "," + "CHANNEL was found," + STG_HDR_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern +  ",CHANNEL :" + db_stg_channel +  ",CHANNEL was found, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        }
                                    } else {
                                        String stg_header_id = "," + ",ITS A DEAD RECORD - Ignore mandatory validation for CHANNEL," + "CHANNEL : " + db_stg_channel + "," + "CHANNEL is not mandatory  as it is DEAD," + STG_HDR_STATUS + "," + "Pass";
                                        section4_results.add(stg_header_id);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CHANNEL :" + db_stg_channel +  ",CHANNEL is not mandatory  as it is DEAD, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    }

                                    //REVERSAL_INDICATOR - mandatory validation
                                    if(!STG_HDR_STATUS.equals("DEAD")) {
                                        if ((db_stg_reversal_indicator == null) && (STG_HDR_STATUS != "REVIEW")) {

                                            String stg_header_id = "," + ",REVERSAL_INDICATOR," + "REVERSAL_INDICATOR : " + db_stg_reversal_indicator + "," + "REVERSAL_INDICATOR was not found," + STG_HDR_STATUS + "," + "Fail";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",REVERSAL_INDICATOR :" + db_stg_reversal_indicator +  ",REVERSAL_INDICATOR was not found, " + STG_HDR_STATUS + ",Fail," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        } else {
                                            String stg_header_id = "," + ",REVERSAL_INDICATOR," + "REVERSAL_INDICATOR : " + db_stg_reversal_indicator + "," + "REVERSAL_INDICATOR was found," + STG_HDR_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",REVERSAL_INDICATOR :" + db_stg_reversal_indicator +  ",REVERSAL_INDICATOR was found, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        }
                                    } else {
                                        String stg_header_id = "," + ",ITS A DEAD RECORD - Ignore mandatory validation for REVERSAL_INDICATOR," + "REVERSAL_INDICATOR : " + db_stg_reversal_indicator + "," + "REVERSAL_INDICATOR is not mandatory  as it is DEAD," + STG_HDR_STATUS + "," + "Pass";
                                        section4_results.add(stg_header_id);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",REVERSAL_INDICATOR :" + db_stg_reversal_indicator +  ",REVERSAL_INDICATOR is not mandatory  as it is DEAD, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    }


                                    //CURRENCY_CODE - mandatory validation
                                    if(!STG_HDR_STATUS.equals("DEAD")) {
                                        if ((db_stg_currency_code == null) && (STG_HDR_STATUS != "REVIEW")) {

                                            String stg_header_id = "," + ",CURRENCY_CODE," + "CURRENCY_CODE : " + db_stg_currency_code + "," + "CURRENCY_CODE was not found," + STG_HDR_STATUS + "," + "Fail";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CURRENCY_CODE :" + db_stg_currency_code +  ",CURRENCY_CODE was not found, " + STG_HDR_STATUS + ",Fail," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        } else {
                                            String stg_header_id = "," + ",CURRENCY_CODE," + "CURRENCY_CODE : " + db_stg_currency_code + "," + "CURRENCY_CODE was found," + STG_HDR_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CURRENCY_CODE :" + db_stg_currency_code +  ",CURRENCY_CODE was found, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        }
                                    } else {
                                        String stg_header_id = "," + ",ITS A DEAD RECORD - Ignore mandatory validation for CURRENCY_CODE," + "CURRENCY_CODE : " + db_stg_currency_code + "," + "CURRENCY_CODE is not mandatory  as it is DEAD," + STG_HDR_STATUS + "," + "Pass";
                                        section4_results.add(stg_header_id);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CURRENCY_CODE :" + db_stg_currency_code +  ",CURRENCY_CODE is not mandatory  as it is DEAD, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    }

                                    //EXCHANGE_RATE - mandatory validation
                                    if(!STG_HDR_STATUS.equals("DEAD")) {
                                        if ((db_stg_exchange_rate == null) && (STG_HDR_STATUS != "REVIEW")) {

                                            String stg_header_id = "," + ",EXCHANGE_RATE," + "EXCHANGE_RATE : " + db_stg_exchange_rate + "," + "EXCHANGE_RATE was not found," + STG_HDR_STATUS + "," + "Fail";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern +  ",EXCHANGE_RATE :" + db_stg_exchange_rate +  ",EXCHANGE_RATE was not found, " + STG_HDR_STATUS + ",Fail," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        } else {
                                            String stg_header_id = "," + ",EXCHANGE_RATE," + "EXCHANGE_RATE : " + db_stg_exchange_rate + "," + "EXCHANGE_RATE was found," + STG_HDR_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern +  ",EXCHANGE_RATE :" + db_stg_exchange_rate +  ",EXCHANGE_RATE was found, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        }
                                    } else {
                                        String stg_header_id = "," + ",ITS A DEAD RECORD - Ignore mandatory validation for EXCHANGE_RATE," + "EXCHANGE_RATE : " + db_stg_exchange_rate + "," + "EXCHANGE_RATE is not mandatory  as it is DEAD," + STG_HDR_STATUS + "," + "Pass";
                                        section4_results.add(stg_header_id);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern +  ",EXCHANGE_RATE :" + db_stg_exchange_rate +  ",EXCHANGE_RATE is not mandatory  as it is DEAD, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    }

                                    //EXCHANGE_RATE_TYPE - mandatory validation
                                    if(!STG_HDR_STATUS.equals("DEAD")) {
                                        if ((db_stg_exchange_rate_type == null) && (STG_HDR_STATUS != "REVIEW")) {

                                            String stg_header_id = "," + ",EXCHANGE_RATE_TYPE," + "EXCHANGE_RATE_TYPE : " + db_stg_exchange_rate_type + "," + "EXCHANGE_RATE_TYPE was not found," + STG_HDR_STATUS + "," + "Fail";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",EXCHANGE_RATE_TYPE :" + db_stg_exchange_rate_type +  ",EXCHANGE_RATE_TYPE was not found, " + STG_HDR_STATUS + ",Fail," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        } else {
                                            String stg_header_id = "," + ",EXCHANGE_RATE_TYPE," + "EXCHANGE_RATE_TYPE : " + db_stg_exchange_rate_type + "," + "EXCHANGE_RATE_TYPE was found," + STG_HDR_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",EXCHANGE_RATE_TYPE :" + db_stg_exchange_rate_type +  ",EXCHANGE_RATE_TYPE was found, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        }
                                    } else {
                                        String stg_header_id = "," + ",ITS A DEAD RECORD - Ignore mandatory validation for EXCHANGE_RATE_TYPE," + "EXCHANGE_RATE_TYPE : " + db_stg_exchange_rate_type + "," + "EXCHANGE_RATE_TYPE is not mandatory  as it is DEAD," + STG_HDR_STATUS + "," + "Pass";
                                        section4_results.add(stg_header_id);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",EXCHANGE_RATE_TYPE :" + db_stg_exchange_rate_type +  ",EXCHANGE_RATE_TYPE is not mandatory  as it is DEAD, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    }

                                    //BASE_CURRENCY_AMOUNT - mandatory validation
                                    if(!STG_HDR_STATUS.equals("DEAD")) {
                                        if ((db_stg_base_currency_amount == null) && (STG_HDR_STATUS != "REVIEW")) {

                                            String stg_header_id = "," + ",BASE_CURRENCY_AMOUNT," + "BASE_CURRENCY_AMOUNT : " + db_stg_base_currency_amount + "," + "BASE_CURRENCY_AMOUNT was not found," + STG_HDR_STATUS + "," + "Fail";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern +  ",BASE_CURRENCY_AMOUNT :" + db_stg_base_currency_amount +  ",BASE_CURRENCY_AMOUNT was not found, " + STG_HDR_STATUS + ",Fail," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        } else {
                                            String stg_header_id = "," + ",BASE_CURRENCY_AMOUNT," + "BASE_CURRENCY_AMOUNT : " + db_stg_base_currency_amount + "," + "BASE_CURRENCY_AMOUNT was found," + STG_HDR_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern +  ",BASE_CURRENCY_AMOUNT :" + db_stg_base_currency_amount +  ",BASE_CURRENCY_AMOUNT was found, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        }
                                    } else {
                                        String stg_header_id = "," + ",ITS A DEAD RECORD - Ignore mandatory validation for BASE_CURRENCY_AMOUNT," + "BASE_CURRENCY_AMOUNT : " + db_stg_base_currency_amount + "," + "BASE_CURRENCY_AMOUNT is not mandatory  as it is DEAD," + STG_HDR_STATUS + "," + "Pass";
                                        section4_results.add(stg_header_id);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BASE_CURRENCY_AMOUNT :" + db_stg_base_currency_amount +  ",BASE_CURRENCY_AMOUNT  is not mandatory  as it is DEAD, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    }

                                    //CREDIT_IND - mandatory validation
                                    if(!STG_HDR_STATUS.equals("DEAD")) {
                                        if ((db_stg_credit_ind == null) && (STG_HDR_STATUS != "REVIEW")) {

                                            String stg_header_id = "," + ",CREDIT_IND," + "CREDIT_IND : " + db_stg_credit_ind + "," + "CREDIT_IND was not found," + STG_HDR_STATUS + "," + "Fail";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CREDIT_IND :" + db_stg_credit_ind +  ",CREDIT_IND was not found, " + STG_HDR_STATUS + ",Fail," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        } else {
                                            String stg_header_id = "," + ",CREDIT_IND," + "CREDIT_IND : " + db_stg_credit_ind + "," + "CREDIT_IND was found," + STG_HDR_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CREDIT_IND :" + db_stg_credit_ind +  ",CREDIT_IND was found, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        }
                                    } else {
                                        String stg_header_id = "," + ",ITS A DEAD RECORD - Ignore mandatory validation for CREDIT_IND," + "CREDIT_IND : " + db_stg_credit_ind + "," + "CREDIT_IND is not mandatory  as it is DEAD," + STG_HDR_STATUS + "," + "Pass";
                                        section4_results.add(stg_header_id);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CREDIT_IND :" + db_stg_credit_ind +  ",CREDIT_IND  is not mandatory  as it is DEAD, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    }

                                    //CURRENCY_AMOUNT - mandatory validation
                                    if(!STG_HDR_STATUS.equals("DEAD")) {
                                        if ((db_stg_currency_amount == null) && (STG_HDR_STATUS != "REVIEW")) {

                                            String stg_header_id = "," + ",CURRENCY_AMOUNT," + "CURRENCY_AMOUNT : " + db_stg_currency_amount + "," + "CURRENCY_AMOUNT was not found," + STG_HDR_STATUS + "," + "Fail";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CURRENCY_AMOUNT :" + db_stg_currency_amount +  ",CURRENCY_AMOUNT was not found, " + STG_HDR_STATUS + ",Fail," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        } else {
                                            String stg_header_id = "," + ",CURRENCY_AMOUNT," + "CURRENCY_AMOUNT : " + db_stg_currency_amount + "," + "CURRENCY_AMOUNT was found," + STG_HDR_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CURRENCY_AMOUNT :" + db_stg_currency_amount +  ",CURRENCY_AMOUNT was found, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        }
                                    } else {
                                        String stg_header_id = "," + ",ITS A DEAD RECORD - Ignore mandatory validation for CURRENCY_AMOUNT," + "CURRENCY_AMOUNT : " + db_stg_currency_amount + "," + "CURRENCY_AMOUNT is not mandatory  as it is DEAD," + STG_HDR_STATUS + "," + "Pass";
                                        section4_results.add(stg_header_id);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern +  ",CURRENCY_AMOUNT :" + db_stg_currency_amount +  ",CURRENCY_AMOUNT  is not mandatory  as it is DEAD, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    }

                                    //ENTITY_TYPE_CODE - mandatory validation
                                    if(!STG_HDR_STATUS.equals("DEAD")) {
                                        if ((db_stg_entity_type_code == null) && (STG_HDR_STATUS != "REVIEW")) {

                                            String stg_header_id = "," + ",ENTITY_TYPE_CODE," + "ENTITY_TYPE_CODE : " + db_stg_entity_type_code + "," + "ENTITY_TYPE_CODE was not found," + STG_HDR_STATUS + "," + "Fail";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ENTITY_TYPE_CODE :" + db_stg_entity_type_code +  ",ENTITY_TYPE_CODE was not found, " + STG_HDR_STATUS + ",Fail," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        } else {
                                            String stg_header_id = "," + ",ENTITY_TYPE_CODE," + "ENTITY_TYPE_CODE : " + db_stg_entity_type_code + "," + "ENTITY_TYPE_CODE was found," + STG_HDR_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern +  ",ENTITY_TYPE_CODE :" + db_stg_entity_type_code +  ",ENTITY_TYPE_CODE was found, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        }
                                    } else {
                                        String stg_header_id = "," + ",ITS A DEAD RECORD - Ignore mandatory validation for ENTITY_TYPE_CODE," + "ENTITY_TYPE_CODE : " + db_stg_entity_type_code + "," + "ENTITY_TYPE_CODE is not mandatory  as it is DEAD," + STG_HDR_STATUS + "," + "Pass";
                                        section4_results.add(stg_header_id);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ENTITY_TYPE_CODE :" + db_stg_entity_type_code +  ",ENTITY_TYPE_CODE  is not mandatory  as it is DEAD, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    }

                                    //EVENT_CODE - mandatory validation
                                    if(!STG_HDR_STATUS.equals("DEAD")) {
                                        if ((db_stg_event_code == null) && (STG_HDR_STATUS != "REVIEW")) {

                                            String stg_header_id = "," + ",EVENT_CODE," + "EVENT_CODE : " + db_stg_event_code + "," + "EVENT_CODE was not found," + STG_HDR_STATUS + "," + "Fail";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",EVENT_CODE :" + db_stg_event_code +  ",EVENT_CODE was not found, " + STG_HDR_STATUS + ",Fail," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;

                                        } else {
                                            String stg_header_id = "," + ",EVENT_CODE," + "EVENT_CODE : " + db_stg_event_code + "," + "EVENT_CODE was found," + STG_HDR_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",EVENT_CODE :" + db_stg_event_code +  ",EVENT_CODE was found, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        }
                                    } else {
                                        String stg_header_id = "," + ",ITS A DEAD RECORD - Ignore mandatory validation for EVENT_CODE," + "EVENT_CODE : " + db_stg_event_code + "," + "EVENT_CODE is not mandatory  as it is DEAD," + STG_HDR_STATUS + "," + "Pass";
                                        section4_results.add(stg_header_id);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",EVENT_CODE :" + db_stg_event_code +  ",EVENT_CODE  is not mandatory  as it is DEAD, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    }

                                    //BRAND - mandatory validation
                                    if(!STG_HDR_STATUS.equals("DEAD")) {
                                        if ((db_stg_brand == null) && (STG_HDR_STATUS != "REVIEW")) {

                                            String stg_header_id = "," + ",BRAND," + "BRAND : " + db_stg_brand + "," + "BRAND was not found," + STG_HDR_STATUS + "," + "Fail";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern +  ",BRAND :" + db_stg_brand +  ",BRAND was not found, " + STG_HDR_STATUS + ",Fail," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        } else {
                                            String stg_header_id = "," + ",BRAND," + "BRAND : " + db_stg_brand + "," + "BRAND was found," + STG_HDR_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BRAND :" + db_stg_brand +  ",BRAND was found, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        }
                                    } else {
                                        String stg_header_id = "," + ",ITS A DEAD RECORD - Ignore mandatory validation for BRAND," + "BRAND : " + db_stg_brand + "," + "BRAND is not mandatory as it is DEAD," + STG_HDR_STATUS + "," + "Pass";
                                        section4_results.add(stg_header_id);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BRAND :" + db_stg_brand +  ",BRAND is not mandatory as it is DEAD, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    }

                                    //SUMMARY_FLAG - mandatory validation
                                    if(!STG_HDR_STATUS.equals("DEAD")) {
                                        if ((db_stg_summary_flag == null) && (STG_HDR_STATUS != "REVIEW")) {

                                            String stg_header_id = "," + ",SUMMARY_FLAG," + "SUMMARY_FLAG : " + db_stg_summary_flag + "," + "SUMMARY_FLAG was not found," + STG_HDR_STATUS + "," + "Fail";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern +  ",SUMMARY_FLAG :" + db_stg_summary_flag +  ",SUMMARY_FLAG was not found, " + STG_HDR_STATUS + ",Fail," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        } else {
                                            String stg_header_id = "," + ",SUMMARY_FLAG," + "SUMMARY_FLAG : " + db_stg_summary_flag + "," + "SUMMARY_FLAG was found," + STG_HDR_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SUMMARY_FLAG :" + db_stg_summary_flag +  ",SUMMARY_FLAG was found, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        }
                                    } else {
                                        String stg_header_id = "," + ",ITS A DEAD RECORD - Ignore mandatory validation for SUMMARY_FLAG," + "SUMMARY_FLAG : " + db_stg_summary_flag + "," + "SUMMARY_FLAG is not mandatory  as it is DEAD," + STG_HDR_STATUS + "," + "Pass";
                                        section4_results.add(stg_header_id);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SUMMARY_FLAG :" + db_stg_summary_flag +  ",SUMMARY_FLAG is not mandatory  as it is DEAD, " + STG_HDR_STATUS + ",Pass," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    }




                                //map validations

                                //------------ validate bc header id ------
                                if (db_bc_header_id.equals(db_stg_bc_header_id)) {
                                    String stg_header_id = cons_stg_map_row + ",BC_HEADER_ID," + db_stg_bc_header_id + "," + db_bc_header_id + ",Pass";
                                    section1_results.add(stg_header_id);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BC_HEADER_ID" + "," + db_stg_bc_header_id + "," + db_bc_header_id + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    cons_stg_map_row++;
                                } else {
                                    String stg_header_id = cons_stg_map_row + ",BC_HEADER_ID," + db_stg_bc_header_id + "," + db_bc_header_id + ",Fail";
                                    section1_results.add(stg_header_id);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BC_HEADER_ID" + "," + db_stg_bc_header_id + "," + db_bc_header_id + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    cons_stg_map_row++;
                                    CONS_flag++;
                                }

                                //------------ validate BATCH KEY -----------------------
                                if (db_BATCH_PKEY.equals(db_stg_batch_fkey)) {
                                    String stg_batch_pkey = ",BATCH_PKEY," + db_stg_batch_fkey + "," + db_BATCH_PKEY + ",Pass";
                                    section1_results.add(stg_batch_pkey);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BATCH_PKEY" + "," + db_stg_batch_fkey + "," + db_BATCH_PKEY + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);

                                } else {
                                    String stg_batch_pkey = ",BATCH_PKEY," + db_stg_batch_fkey + "," + db_BATCH_PKEY + ",Fail";
                                    section1_results.add(stg_batch_pkey);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BATCH_PKEY" + "," + db_stg_batch_fkey + "," + db_BATCH_PKEY + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //------------ validate FILE NAME -----------------------
                                if (db_FILE_NAME.equals(db_stg_file_name)) {
                                    String stg_file_name = ",FILE_NAME," + db_stg_file_name + "," + db_FILE_NAME + ",Pass";
                                    section1_results.add(stg_file_name);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",FILE_NAME" + "," + db_stg_file_name + "," + db_FILE_NAME + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);

                                } else {
                                    String stg_file_name = ",FILE_NAME," + db_stg_file_name + "," + db_FILE_NAME + ",Fail";
                                    section1_results.add(stg_file_name);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",FILE_NAME" + "," + db_stg_file_name + "," + db_FILE_NAME + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //------------ validate source -----------------------
                                if (db_source.equals(db_stg_source)) {
                                    String stg_source = ",SOURCE," + db_stg_source + "," + db_source + ",Pass";
                                    section1_results.add(stg_source);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SOURCE" + "," + db_stg_source + "," + db_source + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String stg_source = ",SOURCE," + db_stg_source + "," + db_source + ",Fail";
                                    section1_results.add(stg_source);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SOURCE" + "," + db_stg_source + "," + db_source + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }


                                //------------ validate POLICY_NUMBER -----------------------
                                if (db_policy_number.equals(db_stg_policy_number)) {
                                    String stg_policy_number = ",POLICY_NUMBER," + db_stg_policy_number + "," + db_policy_number + ",Pass";
                                    section1_results.add(stg_policy_number);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",POLICY_NUMBER" + "," + db_stg_policy_number + "," + db_policy_number + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);

                                } else {
                                    String stg_policy_number = ",POLICY_NUMBER," + db_stg_policy_number + "," + db_policy_number + ",Fail";
                                    section1_results.add(stg_policy_number);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",POLICY_NUMBER" + "," + db_stg_policy_number + "," + db_policy_number + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //------------ validate PRODUCT_TYPE -----------------------
                                if (db_product_type.equals(db_stg_product_type)) {
                                    String stg_product_type = ",PRODUCT_TYPE," + db_stg_product_type + "," + db_product_type + ",Pass";
                                    section1_results.add(stg_product_type);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT_TYPE" + "," + db_stg_product_type + "," + db_product_type + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);

                                } else {
                                    String stg_product_type = ",PRODUCT_TYPE," + db_stg_product_type + "," + db_product_type + ",Fail";
                                    section1_results.add(stg_product_type);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT_TYPE" + "," + db_stg_product_type + "," + db_product_type + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }


                                //------------ validate ACCOUNT_NUMBER -----------------------
                                if (db_account_number.equals(db_stg_account_number)) {
                                    String stg_account_number = ",ACCOUNT_NUMBER," + db_stg_account_number + "," + db_account_number + ",Pass";
                                    section1_results.add(stg_account_number);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ACCOUNT_NUMBER" + "," + db_stg_account_number + "," + db_account_number + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);

                                } else {
                                    String stg_account_number = ",ACCOUNT_NUMBER," + db_stg_account_number + "," + db_account_number + ",Fail";
                                    section1_results.add(stg_account_number);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ACCOUNT_NUMBER" + "," + db_stg_account_number + "," + db_account_number + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //------------ validate LINE_OF_BUSINESS -----------------------
                                if (db_line_of_business.equalsIgnoreCase(db_stg_line_of_business)) {
                                    String stg_line_of_business = ",LINE_OF_BUSINESS," + db_stg_line_of_business + "," + db_line_of_business + ",Pass";
                                    section1_results.add(stg_line_of_business);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",LINE_OF_BUSINESS" + "," + db_stg_line_of_business + "," + db_line_of_business + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);

                                } else {
                                    String stg_line_of_business = ",LINE_OF_BUSINESS," + db_stg_line_of_business + "," + db_line_of_business + ",Fail";
                                    section1_results.add(stg_line_of_business);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",LINE_OF_BUSINESS" + "," + db_stg_line_of_business + "," + db_line_of_business + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //------------ validate  TRANSACTION_DATE-----------------------
                                String db_stg_transaction_dateModified = db_transaction_date.substring(0, 10);
                                String db_transaction_dateModified = db_transaction_date.substring(0, 10);
                                System.out.println(db_stg_transaction_dateModified);
                                System.out.println(db_transaction_dateModified);

                                if (db_stg_transaction_dateModified.equals(db_transaction_dateModified)) {
                                    String stg_transaction_date = ",TRANSACTION_DATE," + db_stg_transaction_dateModified + "," + db_transaction_dateModified + ",Pass";
                                    section1_results.add(stg_transaction_date);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_stg_transaction_dateModified + "," + db_transaction_dateModified + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String stg_transaction_date = ",TRANSACTION_DATE," + db_stg_transaction_dateModified + "," + db_transaction_dateModified + ",Fail";
                                    section1_results.add(stg_transaction_date);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_stg_transaction_dateModified + "," + db_transaction_dateModified + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //------------ validate  TRANSACTION_REFERENCE-----------------------
                                if (db_stg_transaction_reference.equals(db_transaction_reference)) {
                                    String stg_transaction_reference = ",TRANSACTION_REFERENCE," + db_stg_transaction_reference + "," + db_transaction_reference + ",Pass";
                                    section1_results.add(stg_transaction_reference);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_REFERENCE" + "," + db_stg_transaction_reference + "," + db_transaction_reference + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String stg_transaction_reference = ",TRANSACTION_REFERENCE," + db_stg_transaction_reference + "," + db_transaction_reference + ",Fail";
                                    section1_results.add(stg_transaction_reference);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_REFERENCE" + "," + db_stg_transaction_reference + "," + db_transaction_reference + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //------------ validate  TRANSACTION_REASON-----------------------
                                if (db_stg_transaction_reason.equals(db_transaction_reason)) {
                                    String stg_transaction_reason = ",TRANSACTION_REASON," + db_stg_transaction_reason + "," + db_transaction_reason + ",Pass";
                                    section1_results.add(stg_transaction_reason);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_REASON" + "," + db_stg_transaction_reason + "," + db_transaction_reason + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String stg_transaction_reason = ",TRANSACTION_REASON," + db_stg_transaction_reason + "," + db_transaction_reason + ",Fail";
                                    section1_results.add(stg_transaction_reason);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_REASON" + "," + db_stg_transaction_reason + "," + db_transaction_reason + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //------------ validate  TRANSACTION_SUB_TYPE-----------------------
                                if (db_stg_transaction_sub_type.equals(db_transaction_sub_type)) {
                                    String stg_transaction_sub_type = ",TRANSACTION_SUB_TYPE," + db_stg_transaction_sub_type + "," + db_transaction_sub_type + ",Pass";
                                    section1_results.add(stg_transaction_sub_type);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_SUB_TYPE" + "," + db_stg_transaction_sub_type + "," + db_transaction_sub_type + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String stg_transaction_sub_type = ",TRANSACTION_SUB_TYPE," + db_stg_transaction_sub_type + "," + db_transaction_sub_type + ",Fail";
                                    section1_results.add(stg_transaction_sub_type);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_SUB_TYPE" + "," + db_stg_transaction_sub_type + "," + db_transaction_sub_type + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //------------ validate  EXCHANGE_RATE-----------------------
                                if (db_stg_exchange_rate.equals(db_exchange_rate)) {
                                    String stg_exchange_rate = ",EXCHANGE_RATE," + db_stg_exchange_rate + "," + db_exchange_rate + ",Pass";
                                    section1_results.add(stg_exchange_rate);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",EXCHANGE_RATE" + "," + db_stg_exchange_rate + "," + db_exchange_rate + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String stg_exchange_rate = ",EXCHANGE_RATE," + db_stg_exchange_rate + "," + db_exchange_rate + ",Fail";
                                    section1_results.add(stg_exchange_rate);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",EXCHANGE_RATE" + "," + db_stg_exchange_rate + "," + db_exchange_rate + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //------------ validate  EXCHANGE_RATE_TYPE-----------------------
                                if (db_stg_exchange_rate_type.equals(db_exchange_rate_type)) {
                                    String stg_exchange_rate_type = ",EXCHANGE_RATE_TYPE," + db_stg_exchange_rate_type + "," + db_exchange_rate_type + ",Pass";
                                    section1_results.add(stg_exchange_rate_type);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",EXCHANGE_RATE_TYPE" + "," + db_stg_exchange_rate_type + "," + db_exchange_rate_type + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String stg_exchange_rate_type = ",EXCHANGE_RATE_TYPE," + db_stg_exchange_rate_type + "," + db_exchange_rate_type + ",Fail";
                                    section1_results.add(stg_exchange_rate_type);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",EXCHANGE_RATE_TYPE" + "," + db_stg_exchange_rate_type + "," + db_exchange_rate_type + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //------------ validate  PAYMENT_METHOD-----------------------
                                if (db_stg_payment_method.equals(db_payment_method)) {
                                    String stg_payment_method = ",PAYMENT_METHOD," + db_stg_payment_method + "," + db_payment_method + ",Pass";
                                    section1_results.add(stg_payment_method);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAYMENT_METHOD" + "," + db_stg_payment_method + "," + db_payment_method + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String stg_payment_method = ",PAYMENT_METHOD," + db_stg_payment_method + "," + db_payment_method + ",Fail";
                                    section1_results.add(stg_payment_method);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAYMENT_METHOD" + "," + db_stg_payment_method + "," + db_payment_method + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }


                                //------------ validate  SUN_NUMBER-----------------------
                                if (db_stg_sun_number != (null) && db_sun_number != (null)) {
                                    if (db_stg_sun_number.equals(db_sun_number)) {
                                        String stg_sun_number = ",SUN_NUMBER," + db_stg_sun_number + "," + db_sun_number + ",Pass";
                                        section1_results.add(stg_sun_number);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SUN_NUMBER" + "," + db_stg_sun_number + "," + db_sun_number + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String stg_sun_number = ",SUN_NUMBER," + db_stg_sun_number + "," + db_sun_number + ",Fail";
                                        section1_results.add(stg_sun_number);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SUN_NUMBER" + "," + db_stg_sun_number + "," + db_sun_number + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                } else {
                                    String stg_sun_number = ",SUN_NUMBER," + db_stg_sun_number + "," + db_sun_number + ",Pass";
                                    section1_results.add(stg_sun_number);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SUN_NUMBER" + "," + db_stg_sun_number + "," + db_sun_number + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                }

                                //------------ validate  MID_NUMBER-----------------------
                                if (db_stg_mid_number != (null) && db_mid_number != (null)) {
                                    if (db_stg_mid_number.equals(db_mid_number)) {
                                        String stg_mid_number = ",MID_NUMBER," + db_stg_mid_number + "," + db_mid_number + ",Pass";
                                        section1_results.add(stg_mid_number);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",MID_NUMBER" + "," + db_stg_mid_number + "," + db_mid_number + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String stg_mid_number = ",MID_NUMBER," + db_stg_mid_number + "," + db_mid_number + ",Fail";
                                        section1_results.add(stg_mid_number);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",MID_NUMBER" + "," + db_stg_mid_number + "," + db_mid_number + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                } else {
                                    String stg_mid_number = ",MID_NUMBER," + db_stg_mid_number + "," + db_mid_number + ",Pass";
                                    section1_results.add(stg_mid_number);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",MID_NUMBER" + "," + db_stg_mid_number + "," + db_mid_number + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                }

                                //------------ validate  DDI_REFERENCE-----------------------
                                if (db_stg_ddi_reference != ("null") && db_ddi_reference != ("null")) {
                                    if (db_stg_ddi_reference == db_ddi_reference || db_stg_ddi_reference.equals(db_ddi_reference)) {
                                        String stg_ddi_reference = ",DDI_REFERENCE," + db_stg_ddi_reference + "," + db_ddi_reference + ",Pass";
                                        section1_results.add(stg_ddi_reference);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",DDI_REFERENCE" + "," + db_stg_ddi_reference + "," + db_ddi_reference + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String stg_ddi_reference = ",DDI_REFERENCE," + db_stg_ddi_reference + "," + db_ddi_reference + ",Fail";
                                        section1_results.add(stg_ddi_reference);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",DDI_REFERENCE" + "," + db_stg_ddi_reference + "," + db_ddi_reference + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                } else {
                                    String stg_ddi_reference = ",DDI_REFERENCE," + db_stg_ddi_reference + "," + db_ddi_reference + ",Pass";
                                    section1_results.add(stg_ddi_reference);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",DDI_REFERENCE" + "," + db_stg_ddi_reference + "," + db_ddi_reference + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                }

                                //------------ validate  ORDER_NUMBER-----------------------
                                if (db_stg_order_number != ("null") && db_order_number != ("null")) {
                                    if (db_stg_order_number.equals(db_order_number)) {
                                        String stg_order_number = ",ORDER_NUMBER," + db_stg_order_number + "," + db_order_number + ",Pass";
                                        section1_results.add(stg_order_number);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ORDER_NUMBER" + "," + db_stg_order_number + "," + db_order_number + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String stg_order_number = ",ORDER_NUMBER," + db_stg_order_number + "," + db_order_number + ",Fail";
                                        section1_results.add(stg_order_number);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ORDER_NUMBER" + "," + db_stg_order_number + "," + db_order_number + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                } else {
                                    String stg_order_number = ",ORDER_NUMBER," + db_stg_order_number + "," + db_order_number + ",Pass";
                                    section1_results.add(stg_order_number);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ORDER_NUMBER" + "," + db_stg_order_number + "," + db_order_number + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                }


                                //------------ validate  CARD_TYPE-----------------------
                                if (db_stg_card_type != ("null") && db_card_type != ("null")) {
                                    if (db_stg_card_type.equals(db_card_type)) {
                                        String stg_card_type = ",CARD_TYPE," + db_stg_card_type + "," + db_card_type + ",Pass";
                                        section1_results.add(stg_card_type);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CARD_TYPE" + "," + db_stg_card_type + "," + db_card_type + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String stg_card_type = ",CARD_TYPE," + db_stg_card_type + "," + db_card_type + ",Fail";
                                        section1_results.add(stg_card_type);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CARD_TYPE" + "," + db_stg_card_type + "," + db_card_type + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                } else {
                                    String stg_card_type = ",CARD_TYPE," + db_stg_card_type + "," + db_card_type + ",Pass";
                                    section1_results.add(stg_card_type);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CARD_TYPE" + "," + db_stg_card_type + "," + db_card_type + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                }

                                //Descoped as part of Automation
                                //------------ validate  REVERSAL_INDICATOR-----------------------

                                String db_reversal_indicatorModified = "null";
                                if (db_reversal_indicator.contains("null")) {
                                    db_reversal_indicatorModified = db_reversal_indicator.replace("null", "N");
                                } else {
                                    db_reversal_indicatorModified = db_reversal_indicator.replace(".*", "Y");
                                }

                                if (db_stg_reversal_indicator.equals(db_reversal_indicatorModified)) {
                                    String stg_reversal_indicator = ",REVERSAL_INDICATOR," + db_stg_reversal_indicator + "," + db_reversal_indicatorModified + ",Pass";
                                    section1_results.add(stg_reversal_indicator);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",REVERSAL_INDICATOR" + "," + db_stg_reversal_indicator + "," + db_reversal_indicatorModified + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String stg_reversal_indicator = ",REVERSAL_INDICATOR," + db_stg_reversal_indicator + "," + db_reversal_indicatorModified + ",Fail";
                                    section1_results.add(stg_reversal_indicator);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",REVERSAL_INDICATOR" + "," + db_stg_reversal_indicator + "," + db_reversal_indicatorModified + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }


                                // TO BE REVIEWED NOTE : There is No field available in BACS NARRATIVE
                                //------------ validate  BACS_NARRATIVE-----------------------
                                if (db_stg_bacs_narrative != (null) && db_bacs_narrative != (null)) {
                                    if (db_stg_bacs_narrative.equals(db_bacs_narrative)) {
                                        String stg_bacs_narrative = ",BACS_NARRATIVE," + db_stg_bacs_narrative + "," + db_bacs_narrative + ",Pass";
                                        section1_results.add(stg_bacs_narrative);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BACS_NARRATIVE" + "," + db_stg_bacs_narrative + "," + db_bacs_narrative + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String stg_bacs_narrative = ",BACS_NARRATIVE," + db_stg_bacs_narrative + "," + db_bacs_narrative + ",Fail";
                                        section1_results.add(stg_bacs_narrative);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BACS_NARRATIVE" + "," + db_stg_bacs_narrative + "," + db_bacs_narrative + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                } else {
                                    String stg_bacs_narrative = ",BACS_NARRATIVE," + db_stg_bacs_narrative + "," + db_bacs_narrative + ",Pass";
                                    section1_results.add(stg_bacs_narrative);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BACS_NARRATIVE" + "," + db_stg_bacs_narrative + "," + db_bacs_narrative + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                }

                                //------------- Validate CURRENCY_CODE ----------------
                                if ((db_stg_currency_code != ("null")) && (db_currency_code != ("null"))) {
                                    if (db_stg_currency_code.equals(db_currency_code)) {
                                        String stg_line_currency_code = ",CURRENCY_CODE," + db_stg_currency_code + "," + db_currency_code + ",Pass";
                                        section1_results.add(stg_line_currency_code);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CURRENCY_CODE" + "," + db_stg_currency_code + "," + db_currency_code + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String stg_line_currency_code = ",CURRENCY_CODE," + db_stg_currency_code + "," + db_currency_code + ",Fail";
                                        section1_results.add(stg_line_currency_code);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CURRENCY_CODE" + "," + db_stg_currency_code + "," + db_currency_code + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                } else {
                                    String stg_line_currency_code = ",CURRENCY_CODE," + db_stg_currency_code + "," + db_currency_code + ",Pass";
                                    section1_results.add(stg_line_currency_code);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CURRENCY_CODE" + "," + db_stg_currency_code + "," + db_currency_code + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                }

                                //------------- Validate BRAND ----------------
                                if (db_stg_brand != ("null") && db_brand != ("null")) {
                                    String db_brandModified = db_brand.substring(2, 4);
                                    if (db_stg_brand.equals(db_brandModified)) {
                                        String stg_line_currency_code = ",BRAND," + db_stg_brand + "," + db_brandModified + ",Pass";
                                        section1_results.add(stg_line_currency_code);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BRAND" + "," + db_stg_brand + "," + db_brandModified + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String stg_line_currency_code = ",BRAND," + db_stg_brand + "," + db_brandModified + ",Fail";
                                        section1_results.add(stg_line_currency_code);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BRAND" + "," + db_stg_brand + "," + db_brandModified + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                } else {
                                    String stg_line_currency_code = ",BRAND," + db_stg_brand + "," + db_brand + ",Pass";
                                    section1_results.add(stg_line_currency_code);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BRAND" + "," + db_stg_brand + "," + db_brand + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                }

                                //========================== LookUp Validation ==========================

                                //Lookup Validation
                                String db_lookup_underWriter_meaning = "null";
                                String db_lookup_valid_transaction_sub_type_meaning = "null";
                                String db_lookup_valid_transaction_sub_type_exc_meaning = "null";
                                String db_lookup_initialchargetxn_trxsubtype_meaning = "null";
                                String db_lookup_initialchargetxn_cross_ref_rc_meaning = "null";
                                String db_lookup_valid_transaction_reason_meaning = "null";
                                String db_lookup_valid_reversal_multiplier_meaning = "null";
                                String db_lookup_product_type_meaning = "null";
                                String db_lookup_event_code_meaning = "null";
                                String db_lookup_summary_flag_meaning = "null";
                                String db_lookup_line_of_business_meaning = "null";
                                String db_lookup_credit_ind_meaning = "null";
                                String db_lookup_entity_type_code_meaning = null;
                                String db_lookup_transaction_date_meaning = "null";
                                String db_lookup_reversal_indicator_meaning = "null";
                                String db_lookup_transaction_sub_type_meaning = "null";
                                String db_lookup_transaction_reason_meaning = "null";
                                String db_lookup_payment_method_meaning = "null";
                                String db_lookup_channel_meaning = "null";
                                String db_lookup_currency_code_meaning = "null";
                                String db_lookup_brand_meaning = "null";


                                //------------------------ ERROR RECORD Validation -----------------
                                String db_lookup_V_TRANSACTION_REASON_fsh_lookup_meaning = "null";
                                String db_lookup_V_VALID_TRX_SUB_TYPE_fsh_lookup_meaning = "null";
                                String db_lookup_ERRROR_AND_NOTERROR_lookup_meaning = "null";

                                    String TravelGLBilling_fsh_lookup = connect_db.executeQuery_DB("Lookup", "FSH_LOOKUP","TRAVEL");
                                    String TravelGLBilling_fsh_sys_lookup = connect_db.executeQuery_DB("Lookup", "FSH_SYS_LOOKUP","TRAVEL");
                                    String fsh_source = connect_db.executeQuery_DB("Lookup", "FSH_LOOKUP_SOURCE_TravelGLBilling","TRAVEL");


                                //V_TRANSACTION_REASON
                                    SQLResultset_fsh = SQLstmt.executeQuery(TravelGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_transaction_reason + "' and LOOKUP_TYPE = 'TransactionReason'" + fsh_source);
                                //SQLResultset_fsh = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_transaction_reason + "' and LOOKUP_TYPE = 'TransactionReason' and System = 'AQUA'  and PATTERN = 'GLBilling'");
                                while (SQLResultset_fsh.next()) {
                                    db_lookup_V_TRANSACTION_REASON_fsh_lookup_meaning = SQLResultset_fsh.getString("MEANING");
                                }

                                //V_VALID_TRX_SUB_TYPE
                                    SQLResultset_fsh = SQLstmt.executeQuery(TravelGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_transaction_sub_type + "' and LOOKUP_TYPE = 'TransactionSubtype_Reason_EXC'" + fsh_source);
                                    //SQLResultset_fsh = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_transaction_sub_type + "' and LOOKUP_TYPE = 'TransactionSubtype_Reason_EXC' and System = 'AQUA'  and PATTERN = 'GLBilling'");
                                while (SQLResultset_fsh.next()) {
                                    db_lookup_V_VALID_TRX_SUB_TYPE_fsh_lookup_meaning = SQLResultset_fsh.getString("MEANING");
                                }


                                if (db_lookup_V_TRANSACTION_REASON_fsh_lookup_meaning.equals("null") && db_lookup_V_VALID_TRX_SUB_TYPE_fsh_lookup_meaning.equals("null")) {
                                    db_lookup_ERRROR_AND_NOTERROR_lookup_meaning = "Error: Invalid Transaction Reason <TRANSACTION_REASON> and Invalid Transaction Sub Type <TRANSACTION_SUB_TYPE> value.";
                                    String lookup_ERRROR_AND_NOTERROR_lookup_meaning = ",AN ERROR RECORD," + db_lookup_ERRROR_AND_NOTERROR_lookup_meaning + "," + db_lookup_ERRROR_AND_NOTERROR_lookup_meaning + ",Pass";
                                    section1_results.add(lookup_ERRROR_AND_NOTERROR_lookup_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",AN ERROR RECORD" + "," + db_lookup_ERRROR_AND_NOTERROR_lookup_meaning + "," + db_lookup_ERRROR_AND_NOTERROR_lookup_meaning + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);

                                } else {
                                    String lookup_ERRROR_AND_NOTERROR_lookup_meaning = ",NOT AN ERROR RECORD," + db_lookup_V_VALID_TRX_SUB_TYPE_fsh_lookup_meaning + "," + db_lookup_V_VALID_TRX_SUB_TYPE_fsh_lookup_meaning + ",Pass";
                                    section1_results.add(lookup_ERRROR_AND_NOTERROR_lookup_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",NOT AN ERROR RECORD" + "," + db_lookup_V_VALID_TRX_SUB_TYPE_fsh_lookup_meaning + "," + db_lookup_V_VALID_TRX_SUB_TYPE_fsh_lookup_meaning + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                }

                                //------------------------ DEAD_Record Validation -----------------
                                String db_lookup_V_TRX_SUB_TYPE_EXC_fsh_lookup_meaning = "null";
                                String db_lookup_V_INIT_CRG_TRX_SUB_TYPE_fsh_lookup_meaning = "null";
                                String db_lookup_V_INIT_CRG_TRX_XREF_RC_fsh_lookup_meaning = "null";
                                String db_lookup_DEAD_AND_NOTDEAD_lookup_meaning = "null";


                                //V_TRX_SUB_TYPE_EXC
                                    SQLResultset_fsh = SQLstmt.executeQuery(TravelGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_transaction_sub_type + "' and LOOKUP_TYPE = 'TransactionSubtype_EXC'" + fsh_source);
                                //SQLResultset_fsh = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_transaction_sub_type + "' and LOOKUP_TYPE = 'TransactionSubtype_EXC' and System = 'AQUA'  and PATTERN = 'GLBilling'");
                                while (SQLResultset_fsh.next()) {
                                    db_lookup_V_TRX_SUB_TYPE_EXC_fsh_lookup_meaning = SQLResultset_fsh.getString("MEANING");
                                }

                                //V_INIT_CRG_TRX_SUB_TYPE
                                    SQLResultset_fsh = SQLstmt.executeQuery(TravelGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_transaction_sub_type + "' and LOOKUP_TYPE = 'InitialChargeTxn_TrxSubtype'" + fsh_source);
                                //SQLResultset_fsh = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_transaction_sub_type + "' and LOOKUP_TYPE = 'InitialChargeTxn_TrxSubtype' and System = 'AQUA'  and PATTERN = 'GLBilling'");
                                while (SQLResultset_fsh.next()) {
                                    db_lookup_V_INIT_CRG_TRX_SUB_TYPE_fsh_lookup_meaning = SQLResultset_fsh.getString("MEANING");
                                }

                                //V_INIT_CRG_TRX_XREF_RC
                                    SQLResultset_fsh = SQLstmt.executeQuery(TravelGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_transaction_reason + "' and LOOKUP_TYPE = 'InitialChargeTxn_Cross_Ref_RC'" + fsh_source);
                                //SQLResultset_fsh = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_transaction_reason + "' and LOOKUP_TYPE = 'InitialChargeTxn_Cross_Ref_RC' and System = 'AQUA'  and PATTERN = 'GLBilling'");
                                while (SQLResultset_fsh.next()) {
                                    db_lookup_V_INIT_CRG_TRX_XREF_RC_fsh_lookup_meaning = SQLResultset_fsh.getString("MEANING");
                                }


                                if (db_lookup_V_TRX_SUB_TYPE_EXC_fsh_lookup_meaning != ("null") || (db_lookup_V_INIT_CRG_TRX_SUB_TYPE_fsh_lookup_meaning != ("null") && db_lookup_V_INIT_CRG_TRX_XREF_RC_fsh_lookup_meaning != ("null"))) {
                                    //db_lookup_DEAD_AND_NOTDEAD_lookup_meaning = "Record not eligible for processing. Transaction Reason <TRANSACTION_REASON>, Transaction Sub Type <TRANSACTION_SUB_TYPE> ";
                                    db_lookup_DEAD_AND_NOTDEAD_lookup_meaning = "Record not eligible for processing. Transaction Reason and Transaction Sub Type  ";
                                    String lookup_DEAD_AND_NOTDEAD_lookup_meaning = ",A DEAD_Record," + db_lookup_DEAD_AND_NOTDEAD_lookup_meaning + "," + db_lookup_DEAD_AND_NOTDEAD_lookup_meaning + ",Pass";
                                    section1_results.add(lookup_DEAD_AND_NOTDEAD_lookup_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",A DEAD_Record" + "," + db_lookup_DEAD_AND_NOTDEAD_lookup_meaning + "," + db_lookup_DEAD_AND_NOTDEAD_lookup_meaning + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);

                                } else {
                                    String lookup_TRANSACTION_lookup_meaning = ",NOT A DEAD_Record," + db_lookup_V_INIT_CRG_TRX_XREF_RC_fsh_lookup_meaning + "," + db_lookup_V_INIT_CRG_TRX_XREF_RC_fsh_lookup_meaning + ",Pass";
                                    section1_results.add(lookup_TRANSACTION_lookup_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",NOT A DEAD_Record" + "," + db_lookup_V_INIT_CRG_TRX_XREF_RC_fsh_lookup_meaning + "," + db_lookup_V_INIT_CRG_TRX_XREF_RC_fsh_lookup_meaning + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                }


                                //------------------------ BASE_CURRENCY_AMOUNT Validation -----------------
                                String db_lookup_V_REVERSAL_MULTIPLIER_fsh_lookup_meaning = "null";


                                //V_REVERSAL_MULTIPLIER
                                    SQLResultset_fsh = SQLstmt.executeQuery(TravelGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'REVERSAL_MULTIPLIER'" + fsh_source);
                                //SQLResultset_fsh = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'REVERSAL_MULTIPLIER' and System = 'AQUA'  and PATTERN = 'GLBilling'");
                                while (SQLResultset_fsh.next()) {
                                    db_lookup_V_REVERSAL_MULTIPLIER_fsh_lookup_meaning = SQLResultset_fsh.getString("MEANING");
                                }

                                //BASE_CURRENCY_AMOUNT
                                if ((db_stg_base_currency_amount != ("null")) && (db_base_currency_amount != ("null"))) {
                                    if (db_stg_base_currency_amount.contains(".")) {
                                    String[] db_base_currency_amountModified = db_base_currency_amount.split("\\.");
                                    String db_base_currency_amountTransform1 = db_base_currency_amountModified[0];
                                    String db_base_currency_amountTransform2 = db_base_currency_amountModified[1].substring(0, 1);
                                    String db_base_currency_amountConcat = db_base_currency_amountTransform1.concat(".").concat(db_base_currency_amountTransform2);

                                    String[] db_stg_base_currency_amountModified = db_stg_base_currency_amount.split("\\.");
                                    String db_stg_base_currency_amountTransform1 = db_stg_base_currency_amountModified[0];
                                    String db_stg_base_currency_amountTransform2 = db_stg_base_currency_amountModified[1].substring(0, 1);
                                    String db_stg_base_currency_amountConcat = db_stg_base_currency_amountTransform1.concat(".").concat(db_stg_base_currency_amountTransform2);

                                    if (db_stg_reversal_indicator.equals("Y")) {
                                        if ((db_stg_base_currency_amount != ("null")) && (db_base_currency_amount != ("null"))) {
                                            if (db_stg_base_currency_amount.contains(".")) {
                                                if (db_stg_base_currency_amountConcat.equals(db_base_currency_amountConcat)) {
                                                    String stg_line_currency_code = ",BASE_CURRENCY_AMOUNT mapValue," + db_stg_base_currency_amountConcat + "," + db_base_currency_amountConcat + ",Pass";
                                                    section1_results.add(stg_line_currency_code);
                                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BASE_CURRENCY_AMOUNT mapValue" + "," + db_stg_base_currency_amountConcat + "," + db_base_currency_amountConcat + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String stg_line_currency_code = ",BASE_CURRENCY_AMOUNT mapValue," + db_stg_base_currency_amountConcat + "," + db_base_currency_amountConcat + ",Fail";
                                                    section1_results.add(stg_line_currency_code);
                                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BASE_CURRENCY_AMOUNT mapValue" + "," + db_stg_base_currency_amountConcat + "," + db_base_currency_amountConcat + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            }

                                        } else {
                                            if (db_stg_base_currency_amountConcat.equals(db_base_currency_amountConcat)) {
                                                String stg_line_currency_code = ",BASE_CURRENCY_AMOUNT mapValue," + db_stg_base_currency_amountConcat + "," + db_base_currency_amountConcat + ",Pass";
                                                section1_results.add(stg_line_currency_code);
                                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BASE_CURRENCY_AMOUNT mapValue" + "," + db_stg_base_currency_amountConcat + "," + db_base_currency_amountConcat + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String stg_line_currency_code = ",BASE_CURRENCY_AMOUNT mapValue," + db_stg_base_currency_amountConcat + "," + db_base_currency_amountConcat + ",Fail";
                                                section1_results.add(stg_line_currency_code);
                                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BASE_CURRENCY_AMOUNT mapValue" + "," + db_stg_base_currency_amountConcat + "," + db_base_currency_amountConcat + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }
                                        }

                                    } else if (db_stg_reversal_indicator.equals("N")) {
                                        if ((db_stg_base_currency_amountConcat != ("null")) && (db_base_currency_amountConcat != ("null"))) {
                                            if (db_stg_base_currency_amountConcat.equals(db_base_currency_amountConcat)) {
                                                String stg_line_currency_code = ",BASE_CURRENCY_AMOUNT mapValue," + db_stg_base_currency_amountConcat + "," + db_base_currency_amountConcat + ",Pass";
                                                section1_results.add(stg_line_currency_code);
                                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BASE_CURRENCY_AMOUNT mapValue" + "," + db_stg_base_currency_amountConcat + "," + db_base_currency_amountConcat + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String stg_line_currency_code = ",BASE_CURRENCY_AMOUNT mapValue," + db_stg_base_currency_amountConcat + "," + db_base_currency_amountConcat + ",Fail";
                                                section1_results.add(stg_line_currency_code);
                                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BASE_CURRENCY_AMOUNT mapValue" + "," + db_stg_base_currency_amountConcat + "," + db_base_currency_amountConcat + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }
                                        } else {
                                            if (db_stg_base_currency_amountConcat.equals(db_base_currency_amountConcat)) {
                                                String stg_line_currency_code = ",BASE_CURRENCY_AMOUNT mapValue," + db_stg_base_currency_amountConcat + "," + db_base_currency_amountConcat + ",Pass";
                                                section1_results.add(stg_line_currency_code);
                                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BASE_CURRENCY_AMOUNT mapValue" + "," + db_stg_base_currency_amountConcat + "," + db_base_currency_amountConcat + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String stg_line_currency_code = ",BASE_CURRENCY_AMOUNT mapValue," + db_stg_base_currency_amountConcat + "," + db_base_currency_amountConcat + ",Fail";
                                                section1_results.add(stg_line_currency_code);
                                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BASE_CURRENCY_AMOUNT mapValue" + "," + db_stg_base_currency_amountConcat + "," + db_base_currency_amountConcat + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }
                                        }
                                    } else {
                                        if ((db_stg_base_currency_amountConcat != ("null")) && (db_base_currency_amountConcat != ("null"))) {
                                            if (db_stg_base_currency_amountConcat.equals(db_base_currency_amountConcat)) {
                                                String stg_line_currency_code = ",BASE_CURRENCY_AMOUNT mapValue," + db_stg_base_currency_amountConcat + "," + db_base_currency_amountConcat + ",Pass";
                                                section1_results.add(stg_line_currency_code);
                                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BASE_CURRENCY_AMOUNT mapValue" + "," + db_stg_base_currency_amountConcat + "," + db_base_currency_amountConcat + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String stg_line_currency_code = ",BASE_CURRENCY_AMOUNT mapValue," + db_stg_base_currency_amountConcat + "," + db_base_currency_amountConcat + ",Fail";
                                                section1_results.add(stg_line_currency_code);
                                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BASE_CURRENCY_AMOUNT mapValue" + "," + db_stg_base_currency_amountConcat + "," + db_base_currency_amountConcat + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }
                                        } else {
                                            String stg_line_currency_code = ",BASE_CURRENCY_AMOUNT mapValue," + db_stg_base_currency_amountConcat + "," + db_base_currency_amountConcat + ",Pass";
                                            section1_results.add(stg_line_currency_code);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BASE_CURRENCY_AMOUNT mapValue" + "," + db_stg_base_currency_amountConcat + "," + db_base_currency_amountConcat + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        }
                                    }
                                } else {
                                       /* String[] db_base_currency_amountModified = db_base_currency_amount.split("\\.");
                                        String db_base_currency_amountTransform1 = db_base_currency_amountModified[0];
                                        String db_base_currency_amountTransform2 = db_base_currency_amountModified[1].substring(0, 1);
                                        String db_base_currency_amountConcat = db_base_currency_amountTransform1.concat(".").concat(db_base_currency_amountTransform2);

                                        String[] db_stg_base_currency_amountModified = db_stg_base_currency_amount.split("\\.");
                                        String db_stg_base_currency_amountTransform1 = db_stg_base_currency_amountModified[0];
                                        String db_stg_base_currency_amountTransform2 = db_stg_base_currency_amountModified[1].substring(0, 1);
                                        String db_stg_base_currency_amountConcat = db_stg_base_currency_amountTransform1.concat(".").concat(db_stg_base_currency_amountTransform2);*/

                                        if (db_stg_reversal_indicator.equals("Y")) {
                                            if ((db_stg_base_currency_amount != ("null")) && (db_base_currency_amount != ("null"))) {
                                                if (db_stg_base_currency_amount.contains(".")) {
                                                    if (db_stg_base_currency_amount.equals(db_base_currency_amount)) {
                                                        String stg_line_currency_code = ",BASE_CURRENCY_AMOUNT mapValue," + db_stg_base_currency_amount + "," + db_base_currency_amount + ",Pass";
                                                        section1_results.add(stg_line_currency_code);
                                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BASE_CURRENCY_AMOUNT mapValue" + "," + db_stg_base_currency_amount + "," + db_base_currency_amount + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                                        section2_results_tbl.add(tbl_header_id);
                                                    } else {
                                                        String stg_line_currency_code = ",BASE_CURRENCY_AMOUNT mapValue," + db_stg_base_currency_amount + "," + db_base_currency_amount + ",Fail";
                                                        section1_results.add(stg_line_currency_code);
                                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BASE_CURRENCY_AMOUNT mapValue" + "," + db_stg_base_currency_amount + "," + db_base_currency_amount + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                                        section2_results_tbl.add(tbl_header_id);
                                                        CONS_flag++;
                                                    }
                                                }

                                            } else {
                                                if (db_stg_base_currency_amount.equals(db_base_currency_amount)) {
                                                    String stg_line_currency_code = ",BASE_CURRENCY_AMOUNT mapValue," + db_stg_base_currency_amount + "," + db_base_currency_amount + ",Pass";
                                                    section1_results.add(stg_line_currency_code);
                                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BASE_CURRENCY_AMOUNT mapValue" + "," + db_stg_base_currency_amount + "," + db_base_currency_amount + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String stg_line_currency_code = ",BASE_CURRENCY_AMOUNT mapValue," + db_stg_base_currency_amount + "," + db_base_currency_amount + ",Fail";
                                                    section1_results.add(stg_line_currency_code);
                                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BASE_CURRENCY_AMOUNT mapValue" + "," + db_stg_base_currency_amount + "," + db_base_currency_amount + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            }

                                        } else if (db_stg_reversal_indicator.equals("N")) {
                                            if ((db_stg_base_currency_amount != ("null")) && (db_base_currency_amount != ("null"))) {
                                                if (db_stg_base_currency_amount.equals(db_base_currency_amount)) {
                                                    String stg_line_currency_code = ",BASE_CURRENCY_AMOUNT mapValue," + db_stg_base_currency_amount + "," + db_base_currency_amount + ",Pass";
                                                    section1_results.add(stg_line_currency_code);
                                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BASE_CURRENCY_AMOUNT mapValue" + "," + db_stg_base_currency_amount + "," + db_base_currency_amount + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String stg_line_currency_code = ",BASE_CURRENCY_AMOUNT mapValue," + db_stg_base_currency_amount + "," + db_base_currency_amount + ",Fail";
                                                    section1_results.add(stg_line_currency_code);
                                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BASE_CURRENCY_AMOUNT mapValue" + "," + db_stg_base_currency_amount + "," + db_base_currency_amount + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            } else {
                                                if (db_stg_base_currency_amount.equals(db_base_currency_amount)) {
                                                    String stg_line_currency_code = ",BASE_CURRENCY_AMOUNT mapValue," + db_stg_base_currency_amount + "," + db_base_currency_amount + ",Pass";
                                                    section1_results.add(stg_line_currency_code);
                                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BASE_CURRENCY_AMOUNT mapValue" + "," + db_stg_base_currency_amount + "," + db_base_currency_amount + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String stg_line_currency_code = ",BASE_CURRENCY_AMOUNT mapValue," + db_stg_base_currency_amount + "," + db_base_currency_amount + ",Fail";
                                                    section1_results.add(stg_line_currency_code);
                                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BASE_CURRENCY_AMOUNT mapValue" + "," + db_stg_base_currency_amount + "," + db_base_currency_amount + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            }
                                        } else {
                                            if ((db_stg_base_currency_amount != ("null")) && (db_base_currency_amount != ("null"))) {
                                                if (db_stg_base_currency_amount.equals(db_base_currency_amount)) {
                                                    String stg_line_currency_code = ",BASE_CURRENCY_AMOUNT mapValue," + db_stg_base_currency_amount + "," + db_base_currency_amount + ",Pass";
                                                    section1_results.add(stg_line_currency_code);
                                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BASE_CURRENCY_AMOUNT mapValue" + "," + db_stg_base_currency_amount + "," + db_base_currency_amount + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String stg_line_currency_code = ",BASE_CURRENCY_AMOUNT mapValue," + db_stg_base_currency_amount + "," + db_base_currency_amount + ",Fail";
                                                    section1_results.add(stg_line_currency_code);
                                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BASE_CURRENCY_AMOUNT mapValue" + "," + db_stg_base_currency_amount + "," + db_base_currency_amount + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            } else {
                                                String stg_line_currency_code = ",BASE_CURRENCY_AMOUNT mapValue," + db_stg_base_currency_amount + "," + db_base_currency_amount + ",Pass";
                                                section1_results.add(stg_line_currency_code);
                                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BASE_CURRENCY_AMOUNT mapValue" + "," + db_stg_base_currency_amount + "," + db_base_currency_amount + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            }
                                        }
                                    }

                                }


                                //CURRENCY_AMOUNT
                                if (db_stg_reversal_indicator.equals("Y")) {
                                    if ((db_stg_currency_amount != ("null")) && (db_currency_amount != ("null"))) {
                                        if (db_stg_currency_amount.equals(db_currency_amount)) {
                                            String stg_line_currency_code = ",CURRENCY_AMOUNT mapValue," + db_stg_currency_amount + "," + db_currency_amount + ",Pass";
                                            section1_results.add(stg_line_currency_code);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CURRENCY_AMOUNT mapValue" + "," + db_stg_currency_amount + "," + db_currency_amount + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String stg_line_currency_code = ",CURRENCY_AMOUNT mapValue," + db_stg_currency_amount + "," + db_currency_amount + ",Fail";
                                            section1_results.add(stg_line_currency_code);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CURRENCY_AMOUNT mapValue" + "," + db_stg_currency_amount + "," + db_currency_amount + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    } else {
                                        if (db_stg_currency_amount.equals(db_currency_amount)) {
                                            String stg_line_currency_code = ",CURRENCY_AMOUNT mapValue," + db_stg_currency_amount + "," + db_currency_amount + ",Pass";
                                            section1_results.add(stg_line_currency_code);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CURRENCY_AMOUNT mapValue" + "," + db_stg_currency_amount + "," + db_currency_amount + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String stg_line_currency_code = ",CURRENCY_AMOUNT mapValue," + db_stg_currency_amount + "," + db_currency_amount + ",Fail";
                                            section1_results.add(stg_line_currency_code);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CURRENCY_AMOUNT mapValue" + "," + db_stg_currency_amount + "," + db_currency_amount + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }

                                } else if (db_stg_reversal_indicator.equals("N")) {
                                    if ((db_stg_currency_amount != ("null")) && (db_currency_amount != ("null"))) {
                                        if (db_stg_currency_amount.equals(db_currency_amount)) {
                                            String stg_line_currency_code = ",CURRENCY_AMOUNT mapValue," + db_stg_currency_amount + "," + db_currency_amount + ",Pass";
                                            section1_results.add(stg_line_currency_code);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CURRENCY_AMOUNT mapValue" + "," + db_stg_currency_amount + "," + db_currency_amount + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String stg_line_currency_code = ",CURRENCY_AMOUNT mapValue," + db_stg_currency_amount + "," + db_currency_amount + ",Fail";
                                            section1_results.add(stg_line_currency_code);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CURRENCY_AMOUNT mapValue" + "," + db_stg_currency_amount + "," + db_currency_amount + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    } else {
                                        if (db_stg_currency_amount.equals(db_currency_amount)) {
                                            String stg_line_currency_code = ",CURRENCY_AMOUNT mapValue," + db_stg_currency_amount + "," + db_currency_amount + ",Pass";
                                            section1_results.add(stg_line_currency_code);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CURRENCY_AMOUNT mapValue" + "," + db_stg_currency_amount + "," + db_currency_amount + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String stg_line_currency_code = ",CURRENCY_AMOUNT mapValue," + db_stg_currency_amount + "," + db_currency_amount + ",Fail";
                                            section1_results.add(stg_line_currency_code);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CURRENCY_AMOUNT mapValue" + "," + db_stg_currency_amount + "," + db_currency_amount + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }
                                } else {
                                    if ((db_stg_currency_amount != ("null")) && (db_currency_amount != ("null"))) {
                                        if (db_stg_currency_amount.equals(db_currency_amount)) {
                                            String stg_line_currency_code = ",CURRENCY_AMOUNT mapValue," + db_stg_currency_amount + "," + db_currency_amount + ",Pass";
                                            section1_results.add(stg_line_currency_code);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CURRENCY_AMOUNT mapValue" + "," + db_stg_currency_amount + "," + db_currency_amount + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String stg_line_currency_code = ",CURRENCY_AMOUNT mapValue," + db_stg_currency_amount + "," + db_currency_amount + ",Fail";
                                            section1_results.add(stg_line_currency_code);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CURRENCY_AMOUNT mapValue" + "," + db_stg_currency_amount + "," + db_currency_amount + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    } else {
                                        String stg_line_currency_code = ",CURRENCY_AMOUNT mapValue," + db_stg_currency_amount + "," + db_currency_amount + ",Pass";
                                        section1_results.add(stg_line_currency_code);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CURRENCY_AMOUNT mapValue" + "," + db_stg_currency_amount + "," + db_currency_amount + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    }
                                }


                                //------------------------ UnderWriter Validation -----------------
                                if(!db_lookup_DEAD_AND_NOTDEAD_lookup_meaning.equals("Record not eligible for processing. Transaction Reason and Transaction Sub Type  ")) {
                                    SQLResultset_fsh = SQLstmt.executeQuery(TravelGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_underwriter + "' and LOOKUP_TYPE = 'UNDERWRITER'" + fsh_source);
                                    //SQLResultset_fsh = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_underwriter + "' and LOOKUP_TYPE = 'UNDERWRITER' and System = 'AQUA'  and PATTERN = 'GLBilling'");
                                    while (SQLResultset_fsh.next()) {
                                        db_lookup_underWriter_meaning = SQLResultset_fsh.getString("MEANING");
                                    }

                                    if (db_lookup_underWriter_meaning.equals("null")) {
                                        String lookup_underWriter_meaning = ",UNDERWRITER LOOKUP," + "LookUp value not found" + "," + db_stg_underwriter + ",Fail";
                                        section1_results.add(lookup_underWriter_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",UNDERWRITER LOOKUP" + "," + "LookUp value not found" + "," + db_stg_underwriter + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_underWriter_meaning != null) {
                                        if (db_lookup_underWriter_meaning.equals(db_stg_underwriter)) {
                                            String lookup_underWriter_meaning = ",UNDERWRITER LOOKUP," + db_lookup_underWriter_meaning + "," + db_stg_underwriter + ",Pass";
                                            section1_results.add(lookup_underWriter_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",UNDERWRITER LOOKUP" + "," + db_lookup_underWriter_meaning + "," + db_stg_underwriter + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String lookup_underWriter_meaning = ",UNDERWRITER LOOKUP," + db_lookup_underWriter_meaning + "," + db_stg_underwriter + ",Fail";
                                            section1_results.add(lookup_underWriter_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",UNDERWRITER LOOKUP" + "," + db_lookup_underWriter_meaning + "," + db_stg_underwriter + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }
                                } else if(db_lookup_DEAD_AND_NOTDEAD_lookup_meaning.equals("Record not eligible for processing. Transaction Reason and Transaction Sub Type  ")) {
                                    String lookup_underWriter_meaning = ",ITS A DEAD RECORD- Ignore Underwriter validation for this record," + db_lookup_underWriter_meaning + "," + db_stg_underwriter + ",Pass";
                                    section1_results.add(lookup_underWriter_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ITS A DEAD RECORD- Ignore Underwriter validation for this record" + "," + db_lookup_underWriter_meaning + "," + db_stg_underwriter + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                }


                                //------------------------ PRODUCT_TYPE Validation -----------------
                                if(!db_lookup_DEAD_AND_NOTDEAD_lookup_meaning.equals("Record not eligible for processing. Transaction Reason and Transaction Sub Type  ")) {
                                    SQLResultset_fsh = SQLstmt.executeQuery(TravelGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_product_type + "' and LOOKUP_TYPE = 'PRODUCT_TYPE'" + fsh_source);
                                    //SQLResultset_fsh = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_product_type + "' and LOOKUP_TYPE = 'PRODUCT_TYPE' and System = 'AQUA'  and PATTERN = 'GLBilling'");
                                    while (SQLResultset_fsh.next()) {
                                        db_lookup_product_type_meaning = SQLResultset_fsh.getString("MEANING");
                                    }

                                    if (db_lookup_product_type_meaning.equals("null")) {
                                        String lookup_product_type_meaning = ",PRODUCT_TYPE LOOKUP," + "LookUp value not found" + "," + db_stg_product_type + ",Fail";
                                        section1_results.add(lookup_product_type_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT_TYPE LOOKUP" + "," + "LookUp value not found" + "," + db_stg_product_type + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_product_type_meaning != null) {
                                        if (db_lookup_product_type_meaning.equals(db_stg_product_type)) {
                                            String lookup_product_type_meaning = ",PRODUCT_TYPE LOOKUP," + db_lookup_product_type_meaning + "," + db_stg_product_type + ",Pass";
                                            section1_results.add(lookup_product_type_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT_TYPE LOOKUP" + "," + db_lookup_product_type_meaning + "," + db_stg_product_type + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String lookup_product_type_meaning = ",PRODUCT_TYPE LOOKUP," + db_lookup_product_type_meaning + "," + db_stg_product_type + ",Fail";
                                            section1_results.add(lookup_product_type_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT_TYPE LOOKUP" + "," + db_lookup_product_type_meaning + "," + db_stg_product_type + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }
                                } else if(db_lookup_DEAD_AND_NOTDEAD_lookup_meaning.equals("Record not eligible for processing. Transaction Reason and Transaction Sub Type  ")) {
                                    String lookup_underWriter_meaning = ",ITS A DEAD RECORD- Ignore PRODUCT_TYPE validation for this record," + db_lookup_product_type_meaning + "," + db_stg_product_type + ",Pass";
                                    section1_results.add(lookup_underWriter_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ITS A DEAD RECORD- Ignore PRODUCT_TYPE validation for this record" + "," + db_lookup_product_type_meaning + "," + db_stg_product_type + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                }

                                //------------------------ LINE_OF_BUSINESS Validation -----------------
                                if(!db_lookup_DEAD_AND_NOTDEAD_lookup_meaning.equals("Record not eligible for processing. Transaction Reason and Transaction Sub Type  ")) {
                                    SQLResultset_fsh = SQLstmt.executeQuery(TravelGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_line_of_business + "' and LOOKUP_TYPE = 'LINE_OF_BUSINESS'" + fsh_source);
                                    //SQLResultset_fsh = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_line_of_business + "' and LOOKUP_TYPE = 'LINE_OF_BUSINESS' and System = 'AQUA' and pattern = 'GLBilling'");
                                    while (SQLResultset_fsh.next()) {
                                        db_lookup_line_of_business_meaning = SQLResultset_fsh.getString("MEANING");
                                    }

                                    if (db_lookup_line_of_business_meaning.equals("null")) {
                                        String lookup_line_of_business_meaning = ",LINE_OF_BUSINESS LOOKUP," + "LookUp value not found" + "," + db_stg_line_of_business + ",Fail";
                                        section1_results.add(lookup_line_of_business_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",LINE_OF_BUSINESS LOOKUP" + "," + "LookUp value not found" + "," + db_stg_line_of_business + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_line_of_business_meaning != null) {
                                        if (db_lookup_line_of_business_meaning.equals(db_stg_line_of_business)) {
                                            String lookup_line_of_business_meaning = ",LINE_OF_BUSINESS LOOKUP," + db_lookup_line_of_business_meaning + "," + db_stg_line_of_business + ",Pass";
                                            section1_results.add(lookup_line_of_business_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",LINE_OF_BUSINESS LOOKUP" + "," + db_lookup_line_of_business_meaning + "," + db_stg_line_of_business + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String lookup_line_of_business_meaning = ",LINE_OF_BUSINESS LOOKUP," + db_lookup_line_of_business_meaning + "," + db_stg_line_of_business + ",Fail";
                                            section1_results.add(lookup_line_of_business_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",LINE_OF_BUSINESS LOOKUP" + "," + db_lookup_line_of_business_meaning + "," + db_stg_line_of_business + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }
                                } else if(db_lookup_DEAD_AND_NOTDEAD_lookup_meaning.equals("Record not eligible for processing. Transaction Reason and Transaction Sub Type  ")) {
                                    String lookup_underWriter_meaning = ",ITS A DEAD RECORD- Ignore LINE_OF_BUSINESS validation for this record," + db_lookup_line_of_business_meaning + "," + db_stg_line_of_business + ",Pass";
                                    section1_results.add(lookup_underWriter_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ITS A DEAD RECORD- Ignore LINE_OF_BUSINESS validation for this record" + "," + db_lookup_line_of_business_meaning + "," + db_stg_line_of_business + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                }

                                //------------------------ CREDIT_IND Validation -----------------
                                if(!db_lookup_DEAD_AND_NOTDEAD_lookup_meaning.equals("Record not eligible for processing. Transaction Reason and Transaction Sub Type  ")) {
                                    SQLResultset_fsh = SQLstmt.executeQuery(TravelGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_credit_ind + "' and LOOKUP_TYPE = 'CREDIT_INDICATOR'" + fsh_source);
                                    //SQLResultset_fsh = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_credit_ind + "' and LOOKUP_TYPE = 'CREDIT_INDICATOR' and System = 'AQUA' and pattern = 'GLBilling'");
                                    while (SQLResultset_fsh.next()) {
                                        db_lookup_credit_ind_meaning = SQLResultset_fsh.getString("MEANING");
                                    }

                                    if (db_lookup_credit_ind_meaning.equals("null")) {
                                        String lookup_credit_ind_meaning = ",CREDIT_INDICATOR LOOKUP," + "LookUp value not found" + "," + db_stg_credit_ind + ",Fail";
                                        section1_results.add(lookup_credit_ind_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CREDIT_INDICATOR LOOKUP" + "," + "LookUp value not found" + "," + db_stg_credit_ind + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_credit_ind_meaning != null) {
                                        if (db_lookup_credit_ind_meaning.equals(db_stg_credit_ind)) {
                                            String lookup_credit_ind_meaning = ",CREDIT_INDICATOR LOOKUP," + db_lookup_credit_ind_meaning + "," + db_stg_credit_ind + ",Pass";
                                            section1_results.add(lookup_credit_ind_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CREDIT_INDICATOR LOOKUP" + "," + db_lookup_credit_ind_meaning + "," + db_stg_credit_ind + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String lookup_credit_ind_meaning = ",CREDIT_INDICATOR LOOKUP," + db_lookup_credit_ind_meaning + "," + db_stg_credit_ind + ",Fail";
                                            section1_results.add(lookup_credit_ind_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CREDIT_INDICATOR LOOKUP" + "," + db_lookup_credit_ind_meaning + "," + db_stg_credit_ind + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }
                                } else if(db_lookup_DEAD_AND_NOTDEAD_lookup_meaning.equals("Record not eligible for processing. Transaction Reason and Transaction Sub Type  ")) {
                                    String lookup_underWriter_meaning = ",ITS A DEAD RECORD- Ignore CREDIT_INDICATOR validation for this record," + db_lookup_credit_ind_meaning + "," + db_stg_credit_ind + ",Pass";
                                    section1_results.add(lookup_underWriter_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ITS A DEAD RECORD- Ignore CREDIT_INDICATOR validation for this record" + "," + db_stg_credit_ind + "," + db_stg_line_of_business + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                }


                                //------------------------ TRANSACTION_SUBTYPE Validation -----------------
                                if(!db_lookup_DEAD_AND_NOTDEAD_lookup_meaning.equals("Record not eligible for processing. Transaction Reason and Transaction Sub Type  ")) {
                                    SQLResultset_fsh = SQLstmt.executeQuery(TravelGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_transaction_sub_type + "' and Lookup_type IN ('BCTransactionSubtype', 'TransactionSubtype_EXC', 'TransactionSubtype_Reason_EXC')" + fsh_source);
                                    //SQLResultset_fsh = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_transaction_sub_type + "' and Lookup_type IN ('BCTransactionSubtype', 'TransactionSubtype_EXC', 'TransactionSubtype_Reason_EXC') and System = 'AQUA' and pattern = 'GLBilling' ");
                                    while (SQLResultset_fsh.next()) {
                                        db_lookup_transaction_sub_type_meaning = SQLResultset_fsh.getString("MEANING");
                                    }

                                    if (db_lookup_transaction_sub_type_meaning.equals("null")) {
                                        String lookup_transaction_sub_type_meaning = ",TRANSACTION_SUBTYPE LOOKUP," + "LookUp value not found" + "," + db_stg_transaction_sub_type + ",Fail";
                                        section1_results.add(lookup_transaction_sub_type_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_SUBTYPE LOOKUP" + "," + "LookUp value not found" + "," + db_stg_transaction_sub_type + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_transaction_sub_type_meaning != null) {
                                        if (db_lookup_transaction_sub_type_meaning.equals(db_stg_transaction_sub_type)) {
                                            String lookup_transaction_sub_type_meaning = ",TRANSACTION_SUBTYPE LOOKUP," + db_lookup_transaction_sub_type_meaning + "," + db_stg_transaction_sub_type + ",Pass";
                                            section1_results.add(lookup_transaction_sub_type_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_SUBTYPE LOOKUP" + "," + db_lookup_transaction_sub_type_meaning + "," + db_stg_transaction_sub_type + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String lookup_transaction_sub_type_meaning = ",TRANSACTION_SUBTYPE LOOKUP," + db_lookup_transaction_sub_type_meaning + "," + db_stg_transaction_sub_type + ",Fail";
                                            section1_results.add(lookup_transaction_sub_type_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_SUBTYPE LOOKUP" + "," + db_lookup_transaction_sub_type_meaning + "," + db_stg_transaction_sub_type + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }
                                } else if(db_lookup_DEAD_AND_NOTDEAD_lookup_meaning.equals("Record not eligible for processing. Transaction Reason and Transaction Sub Type  ")) {
                                    String lookup_underWriter_meaning = ",ITS A DEAD RECORD- Ignore TRANSACTION_SUBTYPE validation for this record," + db_lookup_transaction_sub_type_meaning + "," + db_stg_transaction_sub_type + ",Pass";
                                    section1_results.add(lookup_underWriter_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ITS A DEAD RECORD- Ignore TRANSACTION_SUBTYPE validation for this record" + "," + db_lookup_transaction_sub_type_meaning + "," + db_stg_transaction_sub_type + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                }

                                //------------------------ TRANSACTION_REASON Validation -----------------
                                if(!db_lookup_DEAD_AND_NOTDEAD_lookup_meaning.equals("Record not eligible for processing. Transaction Reason and Transaction Sub Type  ")) {
                                    SQLResultset_fsh = SQLstmt.executeQuery(TravelGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_transaction_reason + "' and Lookup_type IN ('TRANSACTIONREASON', 'InitialChargeTxn_Cross_Ref_RC')" + fsh_source);
                                    //SQLResultset_fsh = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_transaction_reason + "' and Lookup_type IN ('TransactionReason', 'InitialChargeTxn_Cross_Ref_RC') and System = 'AQUA' and pattern = 'GLBilling'");
                                    while (SQLResultset_fsh.next()) {
                                        db_lookup_transaction_reason_meaning = SQLResultset_fsh.getString("MEANING");
                                    }

                                    if (db_lookup_transaction_reason_meaning.equals("null")) {
                                        String lookup_transaction_reason_meaning = ",TRANSACTION_REASON LOOKUP," + "LookUp value not found" + "," + db_stg_transaction_reason + ",Fail";
                                        section1_results.add(lookup_transaction_reason_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_REASON LOOKUP" + "," + "LookUp value not found" + "," + db_stg_transaction_reason + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_transaction_reason_meaning != null) {
                                        if (db_lookup_transaction_reason_meaning.equals(db_stg_transaction_reason)) {
                                            String lookup_transaction_reason_meaning = ",TRANSACTION_REASON LOOKUP," + db_lookup_transaction_reason_meaning + "," + db_stg_transaction_reason + ",Pass";
                                            section1_results.add(lookup_transaction_reason_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_REASON LOOKUP" + "," + db_lookup_transaction_reason_meaning + "," + db_stg_transaction_reason + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String lookup_transaction_reason_meaning = ",TRANSACTION_REASON LOOKUP," + db_lookup_transaction_reason_meaning + "," + db_stg_transaction_reason + ",Fail";
                                            section1_results.add(lookup_transaction_reason_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_REASON LOOKUP" + "," + db_lookup_transaction_reason_meaning + "," + db_stg_transaction_reason + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }
                                } else if(db_lookup_DEAD_AND_NOTDEAD_lookup_meaning.equals("Record not eligible for processing. Transaction Reason and Transaction Sub Type  ")) {
                                    String lookup_underWriter_meaning = ",ITS A DEAD RECORD- Ignore TRANSACTION_REASON validation for this record," + db_lookup_transaction_reason_meaning + "," + db_stg_transaction_reason + ",Pass";
                                    section1_results.add(lookup_underWriter_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ITS A DEAD RECORD- Ignore TRANSACTION_REASON validation for this record" + "," + db_lookup_transaction_reason_meaning + "," + db_stg_transaction_reason + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                }

                                //------------------------ PAYMENT_METHOD Validation -----------------
                                if(!db_lookup_DEAD_AND_NOTDEAD_lookup_meaning.equals("Record not eligible for processing. Transaction Reason and Transaction Sub Type  ")) {
                                    SQLResultset_fsh = SQLstmt.executeQuery(TravelGLBilling_fsh_lookup + " WHERE UPPER(LOOKUP_CODE) = UPPER('" + db_payment_method + "') and LOOKUP_TYPE = 'PAYMENT METHOD'" + fsh_source);
                                    //SQLResultset_fsh = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE UPPER(LOOKUP_CODE) = UPPER('" + db_payment_method + "') and LOOKUP_TYPE = 'Payment Method' and System = 'AQUA' and pattern = 'GLBilling'");
                                    while (SQLResultset_fsh.next()) {
                                        db_lookup_payment_method_meaning = SQLResultset_fsh.getString("MEANING");
                                    }

                                    if (db_lookup_payment_method_meaning.equals("null")) {
                                        String lookup_payment_method_meaning = ",PAYMENT_METHOD LOOKUP," + "LookUp value not found" + "," + db_stg_payment_method + ",Fail";
                                        section1_results.add(lookup_payment_method_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAYMENT_METHOD LOOKUP" + "," + "LookUp value not found" + "," + db_stg_payment_method + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_payment_method_meaning != null) {
                                        if (db_lookup_payment_method_meaning.equals(db_stg_payment_method)) {
                                            String lookup_payment_method_meaning = ",PAYMENT_METHOD LOOKUP," + db_lookup_payment_method_meaning + "," + db_stg_payment_method + ",Pass";
                                            section1_results.add(lookup_payment_method_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAYMENT_METHOD LOOKUP" + "," + db_lookup_payment_method_meaning + "," + db_stg_payment_method + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String lookup_payment_method_meaning = ",PAYMENT_METHOD LOOKUP," + db_lookup_payment_method_meaning + "," + db_stg_payment_method + ",Fail";
                                            section1_results.add(lookup_payment_method_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAYMENT_METHOD LOOKUP" + "," + db_lookup_payment_method_meaning + "," + db_stg_payment_method + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }
                                } else if(db_lookup_DEAD_AND_NOTDEAD_lookup_meaning.equals("Record not eligible for processing. Transaction Reason and Transaction Sub Type  ")) {
                                    String lookup_underWriter_meaning = ",ITS A DEAD RECORD- Ignore PAYMENT_METHOD validation for this record," + db_lookup_payment_method_meaning + "," + db_stg_payment_method + ",Pass";
                                    section1_results.add(lookup_underWriter_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ITS A DEAD RECORD- Ignore PAYMENT_METHOD validation for this record" + "," + db_lookup_payment_method_meaning + "," + db_stg_payment_method + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                }

                                //------------------------ CHANNEL Validation -----------------
                                if(!db_lookup_DEAD_AND_NOTDEAD_lookup_meaning.equals("Record not eligible for processing. Transaction Reason and Transaction Sub Type  ")) {
                                    SQLResultset_fsh = SQLstmt.executeQuery(TravelGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_channel + "' and LOOKUP_TYPE = 'CHANNEL'" + fsh_source);
                                    //SQLResultset_fsh = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_channel + "' and LOOKUP_TYPE = 'CHANNEL' and System = 'AQUA' and pattern = 'GLBilling'");
                                    while (SQLResultset_fsh.next()) {
                                        db_lookup_channel_meaning = SQLResultset_fsh.getString("MEANING");
                                    }

                                    if (db_lookup_channel_meaning.equals("null")) {
                                        String lookup_channel_meaning = ",CHANNEL LOOKUP," + "LookUp value not found" + "," + db_stg_channel + ",Fail";
                                        section1_results.add(lookup_channel_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CHANNEL LOOKUP" + "," + "LookUp value not found" + "," + db_stg_channel + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_channel_meaning != null) {
                                        if (db_lookup_channel_meaning.equals(db_stg_channel)) {
                                            String lookup_channel_meaning = ",CHANNEL LOOKUP," + db_lookup_channel_meaning + "," + db_stg_channel + ",Pass";
                                            section1_results.add(lookup_channel_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CHANNEL LOOKUP" + "," + db_lookup_channel_meaning + "," + db_stg_channel + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String lookup_channel_meaning = ",CHANNEL LOOKUP," + db_lookup_channel_meaning + "," + db_stg_channel + ",Fail";
                                            section1_results.add(lookup_channel_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CHANNEL LOOKUP" + "," + db_lookup_channel_meaning + "," + db_stg_channel + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }
                                } else if(db_lookup_DEAD_AND_NOTDEAD_lookup_meaning.equals("Record not eligible for processing. Transaction Reason and Transaction Sub Type  ")) {
                                    String lookup_underWriter_meaning = ",ITS A DEAD RECORD- Ignore CHANNEL validation for this record," + db_lookup_channel_meaning + "," + db_stg_channel + ",Pass";
                                    section1_results.add(lookup_underWriter_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ITS A DEAD RECORD- Ignore CHANNEL validation for this record" + "," + db_lookup_channel_meaning + "," + db_stg_channel + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                }

                                //------------------------ ENTITY_TYPE_CODE Validation -----------------
                                if(!db_lookup_DEAD_AND_NOTDEAD_lookup_meaning.equals("Record not eligible for processing. Transaction Reason and Transaction Sub Type  ")) {
                                    SQLResultset_fsh = SQLstmt.executeQuery(TravelGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'ENTITY_TYPE_CODE'" + fsh_source);
                                    //SQLResultset_fsh = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'ENTITY_TYPE_CODE' and System = 'AQUA' and pattern = 'GLBilling'");
                                    while (SQLResultset_fsh.next()) {
                                        db_lookup_entity_type_code_meaning = SQLResultset_fsh.getString("MEANING");
                                    }

                                    if (db_lookup_entity_type_code_meaning.equals("null")) {
                                        String lookup_entity_type_code_meaning = ",ENTITY_TYPE_CODE LOOKUP," + "LookUp value not found" + "," + db_stg_entity_type_code + ",Fail";
                                        section1_results.add(lookup_entity_type_code_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ENTITY_TYPE_CODE LOOKUP" + "," + "LookUp value not found" + "," + db_stg_entity_type_code + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_entity_type_code_meaning != null) {
                                        if (db_lookup_entity_type_code_meaning.equals(db_stg_entity_type_code)) {
                                            String lookup_entity_type_code_meaning = ",ENTITY_TYPE_CODE LOOKUP," + db_lookup_entity_type_code_meaning + "," + db_stg_entity_type_code + ",Pass";
                                            section1_results.add(lookup_entity_type_code_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ENTITY_TYPE_CODE LOOKUP" + "," + db_lookup_entity_type_code_meaning + "," + db_stg_entity_type_code + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String lookup_entity_type_code_meaning = ",ENTITY_TYPE_CODE LOOKUP," + db_lookup_entity_type_code_meaning + "," + db_stg_entity_type_code + ",Fail";
                                            section1_results.add(lookup_entity_type_code_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ENTITY_TYPE_CODE LOOKUP" + "," + db_lookup_entity_type_code_meaning + "," + db_stg_entity_type_code + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }
                                } else if(db_lookup_DEAD_AND_NOTDEAD_lookup_meaning.equals("Record not eligible for processing. Transaction Reason and Transaction Sub Type  ")) {
                                    String lookup_underWriter_meaning = ",ITS A DEAD RECORD- Ignore ENTITY_TYPE_CODE validation for this record," + db_lookup_entity_type_code_meaning + "," + db_stg_entity_type_code + ",Pass";
                                    section1_results.add(lookup_underWriter_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ITS A DEAD RECORD- Ignore ENTITY_TYPE_CODE validation for this record" + "," + db_lookup_entity_type_code_meaning + "," + db_stg_entity_type_code + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                }

                                //------------------------ EVENT_CODE Validation -----------------
                                if(!db_lookup_DEAD_AND_NOTDEAD_lookup_meaning.equals("Record not eligible for processing. Transaction Reason and Transaction Sub Type  ")) {
                                    SQLResultset_fsh = SQLstmt.executeQuery(TravelGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'EVENT_CODE'" + fsh_source);
                                    //SQLResultset_fsh = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'EVENT_CODE' and System = 'AQUA' and pattern = 'GLBilling'");
                                    while (SQLResultset_fsh.next()) {
                                        db_lookup_event_code_meaning = SQLResultset_fsh.getString("MEANING");
                                    }

                                    if (db_lookup_event_code_meaning.equals("null")) {
                                        String lookup_event_code_meaning = ",EVENT_CODE LOOKUP," + "LookUp value not found" + "," + db_stg_event_code + ",Fail";
                                        section1_results.add(lookup_event_code_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",EVENT_CODE LOOKUP" + "," + "LookUp value not found" + "," + db_stg_event_code + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_event_code_meaning != null) {
                                        if (db_lookup_event_code_meaning.equals(db_stg_event_code)) {
                                            String lookup_event_code_meaning = ",EVENT_CODE LOOKUP," + db_lookup_event_code_meaning + "," + db_stg_event_code + ",Pass";
                                            section1_results.add(lookup_event_code_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",EVENT_CODE LOOKUP" + "," + db_lookup_event_code_meaning + "," + db_stg_event_code + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String lookup_event_code_meaning = ",EVENT_CODE LOOKUP," + db_lookup_event_code_meaning + "," + db_stg_event_code + ",Fail";
                                            section1_results.add(lookup_event_code_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",EVENT_CODE LOOKUP" + "," + db_lookup_event_code_meaning + "," + db_stg_event_code + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }
                                } else if(db_lookup_DEAD_AND_NOTDEAD_lookup_meaning.equals("Record not eligible for processing. Transaction Reason and Transaction Sub Type  ")) {
                                    String lookup_underWriter_meaning = ",ITS A DEAD RECORD- Ignore EVENT_CODE validation for this record," + db_lookup_event_code_meaning + "," + db_stg_event_code + ",Pass";
                                    section1_results.add(lookup_underWriter_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ITS A DEAD RECORD- Ignore EVENT_CODE validation for this record" + "," + db_lookup_event_code_meaning + "," + db_stg_event_code + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                }

                                //------------------------ SUMMARY_FLAG Validation -----------------
                                if(!db_lookup_DEAD_AND_NOTDEAD_lookup_meaning.equals("Record not eligible for processing. Transaction Reason and Transaction Sub Type  ")) {
                                    SQLResultset_fsh = SQLstmt.executeQuery(TravelGLBilling_fsh_lookup + " WHERE LOOKUP_CODE = 'AQUAGLBilling' and LOOKUP_TYPE = 'SUMMARISE_DATA_FLAG'" + fsh_source);
                                    //SQLResultset_fsh = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'AQUAGLBilling' and LOOKUP_TYPE = 'SUMMARISE_DATA_FLAG' and System = 'AQUA' and pattern = 'GLBilling'");
                                    while (SQLResultset_fsh.next()) {
                                        db_lookup_summary_flag_meaning = SQLResultset_fsh.getString("MEANING");
                                    }

                                    if (db_lookup_summary_flag_meaning.equals("null")) {
                                        String lookup_summary_flag_meaning = ",SUMMARY_FLAG LOOKUP," + "LookUp value not found" + "," + db_stg_summary_flag + ",Fail";
                                        section1_results.add(lookup_summary_flag_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SUMMARY_FLAG LOOKUP" + "," + "LookUp value not found" + "," + db_stg_summary_flag + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_summary_flag_meaning != null) {
                                        if (db_lookup_summary_flag_meaning.equals(db_stg_summary_flag)) {
                                            String lookup_summary_flag_meaning = ",SUMMARY_FLAG LOOKUP," + db_lookup_summary_flag_meaning + "," + db_stg_summary_flag + ",Pass";
                                            section1_results.add(lookup_summary_flag_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SUMMARY_FLAG LOOKUP" + "," + db_lookup_summary_flag_meaning + "," + db_stg_summary_flag + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String lookup_summary_flag_meaning = ",SUMMARY_FLAG LOOKUP," + db_lookup_summary_flag_meaning + "," + db_stg_summary_flag + ",Fail";
                                            section1_results.add(lookup_summary_flag_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SUMMARY_FLAG LOOKUP" + "," + db_lookup_summary_flag_meaning + "," + db_stg_summary_flag + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }
                                } else if(db_lookup_DEAD_AND_NOTDEAD_lookup_meaning.equals("Record not eligible for processing. Transaction Reason and Transaction Sub Type  ")) {
                                    String lookup_underWriter_meaning = ",ITS A DEAD RECORD- Ignore SUMMARY_FLAG validation for this record," + db_lookup_summary_flag_meaning + "," + db_stg_summary_flag + ",Pass";
                                    section1_results.add(lookup_underWriter_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ITS A DEAD RECORD- Ignore SUMMARY_FLAG validation for this record" + "," + db_lookup_summary_flag_meaning + "," + db_stg_summary_flag + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                }

                                String Record_status = "Actual Record Status in FSH : " + db_stg_status;
                                section1_results.add(Record_status);

                            }

                        }
                    }
                }

                //----------------- Validate the Over all Status -------------------
                System.out.println("Looping ++  CONS_flag " + CONS_flag);
                String Overall_status = null;
                String Overall_stg_status = null;
                if (CONS_flag > 0) {
                    CONS_STATUS.add("Fail");
                    Overall_status = "Fail";
                } else {
                    CONS_STATUS.add("Pass");
                    Overall_status = "Pass";
                }


                if (CONS_flag > 0) {
                    OverAllStatus.add("Fail");
                } else {
                    OverAllStatus.add("Pass");
                }

                String tbl_summary_filelist = Source +","+ pattern + ","+file_name +","+ "CONS TO STG " + "," + load_date + ","+ OverAllStatus + "," + btc_BATCH_PKEY;
                //String tbl_summary_filelist = Source + "," + pattern + "," + file_name + "," + load_dateFormat + "," + "CONST TO STG " + "," + OverAllStatus;
                summary_results_tbl.add(tbl_summary_filelist);

                list.addAll(section1_results);
                list.addAll(section2_results);
                list.addAll(section3_results);
                list.addAll(section4_results);




                // ---------------- HTML Report generation ------------------------
                report_generation.report_Test1(section1_results, "Header", xml_file_name, "CONSOLIDATION LAYER - STAGING LAYER", "Travel_GL_Billing", "Travel_GL_Billing : CONSOLIDATION LAYER - STAGING AGGREGATE LAYER", "");
                report_generation.report_Test1(section1_results, "Section2", xml_file_name, "CONSOLIDATION LAYER - STAGING LAYER", "Travel_GL_Billing", "Travel_GL_Billing : CONSOLIDATION LAYER - STAGING AGGREGATE LAYER", "");
                report_generation.report_Test1(section2_results, "Mandatory", xml_file_name, "Mandatory_Check_CONS", "Travel_GL_Billing", "Travel_GL_Billing : CONSOLIDATION LAYER - STAGING AGGREGATE LAYER", "");
                report_generation.report_Test1(section4_results, "Mandatory", xml_file_name, "Mandatory_Check_STG", "Travel_GL_Billing", "Travel_GL_Billing : CONSOLIDATION LAYER - STAGING AGGREGATE LAYER", "");
                report_generation.report_Test1(section3_results, "Section3", xml_file_name, "STAGING TO AGGREGATE LAYER", "Travel_GL_Billing", "Travel_GL_Billing : CONSOLIDATION LAYER - STAGING AGGREGATE LAYER", "");

                table_detail_report.detail_report_tbl(section2_results_tbl);
            }
            state_model.section_method(file_list, CONS_STATUS, "N/A", OverAllStatus, "Travel_GLBilling_Summary");
            table_summary_report.summary_report_tbl(summary_results_tbl );

        }
    }

}



