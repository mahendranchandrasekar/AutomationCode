package Dashboard_Report;

import org.json.JSONException;

import java.io.IOException;
import java.sql.*;
import java.util.List;

public class Table_Summary_Report{

    static Statement SQLstmt = null;
    static ResultSet SQLResultset = null;
    static Connection connection = null;

    String URL_SIT1 = "jdbc:oracle:thin:@dbs119dev.gwd.grpinf.net:1521/FSHDTST4";
    String Username_SIT1 = "FSH_ORA_DATA";
    String password_SIT1 = "XdbvFm!dm7dVCzWE";

    //Table_Detail_Report table_detail_report = new Table_Detail_Report();

    public void summary_report_tbl(List list) throws IOException, SQLException {
        String query = null;
        Date load_dateFormat = null;

        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            connectDatabase(URL_SIT1, Username_SIT1, password_SIT1);
        }
        catch(Exception e){

            e.printStackTrace();
        }

        query = "INSERT INTO DLG_FSH_AUT_SUMMARY (SOURCE, PATTERN, FILE_NAME,LAYER, LOAD_DATE,STATUS,BATCH_PKEY) VALUES (?,?,?,?,?, ?,?)";
        PreparedStatement preparedStatement = connection.prepareStatement(query);

        for(int i=0; i< list.size(); i++){
            String exp_result1 = (String) list.get(i);
            String[] exp_result = exp_result1.split(",");
            for (int j = 0; j < exp_result.length; j++){

                if(j==4) {
                    //Converting Load date format
                    String load_dateTRIM = exp_result[j].substring(0, 10);
                    load_dateFormat =Date.valueOf(load_dateTRIM);
                    preparedStatement.setDate((j+1), load_dateFormat);
                } else {
                    preparedStatement.setString((j+1), exp_result[j]);
                }
            }
            preparedStatement.execute();
        }
        connection.close();
    }

    public void connectDatabase(String server, String username,String password) throws SQLException, IOException, JSONException {

        System.out.println("Connectdatabase starts");
        connection = DriverManager.getConnection(server,username,password);

    }

}
