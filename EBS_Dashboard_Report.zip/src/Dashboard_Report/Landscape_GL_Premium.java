package Dashboard_Report;

import java.io.IOException;
import java.math.RoundingMode;
import java.sql.*;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.sql.Date;
import java.util.List;
import java.util.*;

import org.json.JSONException;

public class Landscape_GL_Premium {

    static Statement SQLstmt = null;
    static ResultSet SQLResultset = null;

    public static HTML_Report_Generation_DB_EVO report_generation;
    public static HTML_Report_Generation_State_Model_B4C report_generation_state;
    public static SCH_EVO_PC_State_Model_B4C state_model;

    public static Table_Detail_Report table_detail_report;
    public static Table_Summary_Report table_summary_report;
    public static connectDatabase connect_db;

    public static void main(String[] args) throws IOException, SQLException, ParseException, JSONException {
        report_generation = new HTML_Report_Generation_DB_EVO();
        report_generation_state = new HTML_Report_Generation_State_Model_B4C();
        state_model = new SCH_EVO_PC_State_Model_B4C();

        table_detail_report = new Table_Detail_Report();
        table_summary_report = new Table_Summary_Report();
        connect_db = new connectDatabase();

        //----------------------- delete the existing report --------------
        report_generation.clean_report("Landscape_GLPremium.html");
        report_generation_state.clean_report_summary("Landscape_GLPremium_Summary.html");

        /*//--------------- SIT  database details -------------------
        String URL_SIT1 = "jdbc:oracle:thin:@dbs119dev.gwd.grpinf.net:1521/FSHDTST3";
        String Username_SIT1 = "FSH_ORA_DATA";
        String password_SIT1 = "Development_Test3";*/

        //--------------- SIT  database details -------------------
        String URL_SIT1 = "jdbc:oracle:thin:@dcn2dcll11z:1521/FSHTSIT1.gwd.grpinf.net";
        String Username_SIT1 = "FSH_ORA_DATA";
        String password_SIT1 = "vMw5HpJaFy3uD6eW";

        //--------------- EBS  database details -------------------
        String URL_ICSI = "jdbc:oracle:thin:@dcn2ddbx340.gwd.grpinf.net:1618:ICSI";
        String Username_ICSI = "apps";
        String password_ICSI = "apps4icsi";

        List<String> file_list = new ArrayList<String>();
        List<String> list = new ArrayList<String>();
        List<String> section1_results = new ArrayList<String>();
        /*List<String> section2_results = new ArrayList<String>();
        List<String> section3_results = new ArrayList<String>();*/
        List<String> section4_results = new ArrayList<String>();

        List<String> OverAllStatus = new ArrayList<String>();
        List<String> CONS_STATUS = new ArrayList<String>();
        List<String> summary_results_tbl = new ArrayList<String>();

        String[] file_lists = null;
        int section1_map_row = 1;

        //--------------------- Declaring the supporting details for reporting --------------
        String file_name = "null";
        String Source = "LAND";
        String pattern = "GLPremium";
        String header = "Header";
        String line = "Line";


        int cons_stg_map_row = 1;
        int stg_line_map_row = 1;
        int cons_mandatory_map_row = 1;
        int line_mandatory_map_row = 1;
        int line_mandatoryStg_map_row = 1;


        // Consolidation Header table variable
        String db_CONS_STATUS = "null";
        String db_CONS_PC_HEADER_ID = "null";
        String db_CONS_SOURCE = "null";
        String db_CONS_ACCOUNT_NUMBER = "null";
        String db_CONS_POLICY_NUMBER = "null";
        String db_CONS_UNDERWRITER = "null";
        String db_CONS_BRAND = "null";
        String db_CONS_LINE_OF_BUSINESS = "null";
        String db_CONS_PRODUCT_TYPE = "null";
        String db_CONS_CHANNEL = "null";
        String db_CONS_TRANSACTION_DATE = "null";
        String db_CONS_BILLING_INSTRUCTION_TYPE = "null";
        String db_CONS_ON_RISK_DATE = "null";
        String db_CONS_OFF_RISK_DATE = "null";
        String db_CONS_LPI_CODE = "null";
        String db_CONS_BATCH_PKEY = "null";
        String db_CONS_FILE_NAME = "null";
        String load_date = "null";
        Date load_dateFormat = null;
        String btc_BATCH_PKEY = null;


// Consolidation Line table variable
        String db_CONS_LINE_STATUS = "null";
        String db_CONS_LINE_PC_LINE_ID = "null";
        String db_CONS_LINE_PC_HEADER_ID = "null";
        String db_CONS_LINE_PRODUCT = "null";
        String db_CONS_LINE_PREMIUM_AMOUNT = "null";
        String db_CONS_LINE_CURRENCY_CODE = "null";
        String db_CONS_LINE_EXCHANGE_RATE = "null";
        String db_CONS_LINE_EXCHANGE_RATE_TYPE = "null";
        String db_CONS_LINE_BASE_CURRENCY_AMOUNT = "null";
        String db_CONS_LINE_TAX_RATE = "null";
        String db_CONS_LINE_TAX_TYPE = "null";
        String db_CONS_LINE_TAX_REGION_LINE = "null";
        String db_CONS_LINE_GL_STRING = "null";
        String db_CONS_LINE_BATCH_FKEY = "null";
        String db_CONS_LINE_FILE_NAME = "null";


// Staging Header table variable declaration
        String db_STG_STATUS = "null";
        String db_STG_PC_HEADER_ID = "null";
        String db_STG_SOURCE = "null";
        String db_STG_ACCOUNT_NUMBER = "null";
        String db_STG_POLICY_NUMBER = "null";
        String db_STG_UNDERWRITER = "null";
        String db_STG_BRAND = "null";
        String db_STG_LINE_OF_BUSINESS = "null";
        String db_STG_PRODUCT_TYPE = "null";
        String db_STG_CHANNEL = "null";
        String db_STG_TRANSACTION_DATE = "null";
        String db_STG_BILLING_INSTRUCTION_TYPE = "null";
        String db_STG_ON_RISK_DATE = "null";
        String db_STG_OFF_RISK_DATE = "null";
        String db_STG_TAX_REGION = "null";
        String db_STG_PRODUCT_KEY = "null";
        String db_STG_SUMMARY_FLAG = "null";
        String db_STG_UEP_CANCELLATION_FLAG = "null";
        String db_STG_TOH_ID = "null";
        String db_STG_EVENT_CODE = "null";
        String db_STG_ENTITY_TYPE_CODE = "null";
        String db_STG_CREATION_DATE = "null";
        String db_STG_CREATED_BY = "null";
        String db_STG_LAST_UPDATE_DATE = "null";
        String db_STG_LAST_UPDATED_BY = "null";
        String db_STG_PC_SUMMARY_ID = "null";
        String db_STG_BATCH_FKEY = "null";
        String db_STG_FILE_NAME = "null";

// Staging line table variable declaration
        String db_STG_LINE_STATUS = "null";
        String db_STG_LINE_PC_LINE_ID = "null";
        String db_STG_LINE_PC_HEADER_ID = "null";
        String db_STG_LINE_PRODUCT = "null";
        String db_STG_LINE_PREMIUM_AMOUNT = "null";
        String db_STG_LINE_CURRENCY_CODE = "null";
        String db_STG_LINE_EXCHANGE_RATE = "null";
        String db_STG_LINE_EXCHANGE_RATE_TYPE = "null";
        String db_STG_LINE_BASE_CURRENCY_AMOUNT = "null";
        String db_STG_LINE_SUMMARY_FLAG = "null";
        String db_STG_LINE_TAX_RATE = "null";
        String db_STG_LINE_TAX_TYPE = "null";
        String db_STG_LINE_TAX_REGION_LINE = "null";
        String db_STG_LINE_FSH_ATTRIBUTE_01 = "null";
        String db_STG_LINE_DAILY_BASE_CURRENCY_AMOUNT = "null";
        String db_STG_LINE_TOH_ID = "null";
        String db_STG_LINE_TOL_ID = "null";
        String db_STG_LINE_CREATION_DATE = "null";
        String db_STG_LINE_CREATED_BY = "null";
        String db_STG_LINE_LAST_UPDATE_DATE = "null";
        String db_STG_LINE_LAST_UPDATED_BY = "null";
        String db_STG_LINE_PC_SUMMARY_ID = "null";
        String db_STG_LINE_PC_LINE_SUMMARY_ID = "null";
        String db_STG_LINE_BATCH_FKEY = "null";
        String db_STG_LINE_FILE_NAME = "null";

        String xmlfile_name = "null";
        String xml_file_name1 = null;


        //---------------- Line item -------
        String db_stg_line_id = "null";
        String db_stg_INVOICE_ID = "null";


        //--------------- Consolidation variables decleration ---------
        String db_cons_header_id = "null";


        //-------- Connect to Database --------------
        connect_db.createConnection("SIT2");
        //table_detail_report.detail_report_tbl_delete(connection, Source);


        //------ get the new file from batch control table --------------
        boolean newRecord = true;
        //SQLResultset = SQLstmt.executeQuery("Select distinct file_name from DLG_FSH_CTL_BATCH where Trunc(LOAD_DATE) = TRUNC(SYSDATE-1) and system = 'LAND' and pattern = 'GLPREMIUM'"); LANDGLPremium_20191115130012.xml LANDGLPremium_20191106125232.xml
        String outSQL = connect_db.executeQuery_DB("BATCH", "GLPremium_batchCtl", "LANDSCAPE");
        SQLstmt = connect_db.resStatement();

        SQLResultset = SQLstmt.executeQuery(outSQL);
        while (SQLResultset.next()) {
            file_list.add(SQLResultset.getString("FILE_NAME"));
            System.out.println("File name---" + SQLResultset.getString("FILE_NAME"));
            list.addAll(section1_results);
        }


        // ---------------------------------- Get the batch PKEY ----------------------
        String outSQL_bkey = connect_db.executeQuery_DB("BATCH", "GLPremium_batchCtl_key", "LANDSCAPE");

        SQLResultset = SQLstmt.executeQuery(outSQL_bkey);
        while (SQLResultset.next()) {
            btc_BATCH_PKEY = SQLResultset.getString("BATCH_PKEY");
        }

        // ---------------------------------- Check the new file ----------------------
        SQLResultset = SQLstmt.executeQuery(outSQL);
        if (!SQLResultset.next()) {
            System.out.println("No new Landscape_GLPremium files have been received to FSH ");
            newRecord = false;
            String nonewfile = ",FILE_NAME," + "No new Landscape_GLPremium files have been received to FSH" + "," + "," + ",Pass";
            section1_results.add(nonewfile);
            list.addAll(section1_results);
        }

        if (newRecord) {

            //------------------------ Section 1 Start Print all the new file in the report-------------------
            for (String num_file : file_list) {
                file_lists = num_file.split(",");
                for (String file_list1 : file_lists) {
                    xml_file_name1 = file_list1;
                    //int section1_map_row = 1;
                    String newfile = section1_map_row + ",FILE_NAME," + xml_file_name1 + "," + xml_file_name1 + ",Pass";
                    section1_map_row++;
                    section1_results.add(newfile);
                }
            }
            list.addAll(section1_results);
            //report_generation.report_Test1(section1_results, "Section1", xml_file_name1, "B4C BC CONS BATCH TABLE VALIDATION", "B4C_SCHBilling", "B4C BC VALIDATION");
            //------------------------ Section 1 End ----------------------------------------------
        }

        List<String> list_header = new ArrayList<String>(); // -- Add all the header id
        if (newRecord) {
            //------------ Split the file names form the list --------------
            for (String xml_file_name : file_list) {
                int section2_map_row = 1;
                int CONS_flag = 0;
                List<String> section2_results = new ArrayList<String>();
                List<String> section3_results = new ArrayList<String>();
                List<String> section2_results_tbl = new ArrayList<String>();

                file_name = xml_file_name;


                //--------------------------------- Section 3 Start Here ---------------------------------
                boolean sec3flag = true;
                String db_STG_ACTL_RCDS = null;
                Integer db_STG_ACTL_RCDS1 = 0;

                SQLResultset = SQLstmt.executeQuery("SELECT COUNT(PC_HEADER_ID) as STG_ACTL_RCDS FROM FSH_ORA_DATA.DLG_FSH_STG_COMM_PC_HDR WHERE FILE_NAME = '" + xml_file_name + "'");
                while (SQLResultset.next()) {
                    db_STG_ACTL_RCDS = SQLResultset.getString("STG_ACTL_RCDS");
                    db_STG_ACTL_RCDS1 = SQLResultset.getInt("STG_ACTL_RCDS");
                    System.out.println("stag Actual header count ----" + db_STG_ACTL_RCDS);
                }

                if (db_STG_ACTL_RCDS1 == 0) {  //--- Zero record validation
                    sec3flag = false;
                    String pc_stg_header_line = 1 + "," + "STG_ACTL_RCDS DB Does not have any records" + "," + "STG_ACTL_RCDS DB Does not have any records" + "," + "STG_AGG_ACTUAL_HEADER DB Does not have any records" + ",Fail";
                    section3_results.add(pc_stg_header_line);
                }

                SQLResultset = SQLstmt.executeQuery("SELECT SUMMARY_FLAG FROM FSH_ORA_DATA.DLG_FSH_STG_COMM_PC_HDR WHERE FILE_NAME = '" + xml_file_name + "'");
                while (SQLResultset.next()) {
                    db_STG_SUMMARY_FLAG = SQLResultset.getString("SUMMARY_FLAG");
                    System.out.println("stag Summary Flag ----" + db_STG_SUMMARY_FLAG);
                }

                if (sec3flag) {
                    do {

                        SQLResultset = SQLstmt.executeQuery("SELECT COUNT(a.PC_HEADER_ID) as STG_EXP_SUM_HDRS \n" +
                                "FROM(\n" +
                                "SELECt PC_HEADER_ID,STATUS,\n" +
                                "row_number() over(partition by SOURCE,UNDERWRITER,BRAND,LINE_OF_BUSINESS,PRODUCT_TYPE,CHANNEL,TRANSACTION_DATE,BILLING_INSTRUCTION_TYPE,ON_RISK_DATE,OFF_RISK_DATE,TAX_REGION,PRODUCT_KEY,EVENT_CODE,ENTITY_TYPE_CODE,SUMMARY_FLAG,ACCOUNTING_METHOD\n" +
                                "ORDER BY SOURCE,UNDERWRITER,BRAND,LINE_OF_BUSINESS,PRODUCT_TYPE,CHANNEL,TRANSACTION_DATE,BILLING_INSTRUCTION_TYPE,ON_RISK_DATE,OFF_RISK_DATE,TAX_REGION,PRODUCT_KEY,EVENT_CODE,ENTITY_TYPE_CODE,SUMMARY_FLAG,ACCOUNTING_METHOD) row_1\n" +
                                "FROM FSH_ORA_DATA.DLG_FSH_STG_COMM_PC_HDR WHERE FILE_NAME = '" + xml_file_name + "')a \n" +
                                "where a.row_1 = 1\n" +
                                "AND a.STATUS = 'COMPLETE'");

                        while (SQLResultset.next()) {
                            String STG_EXP_SUM_HDRS = SQLResultset.getString("STG_EXP_SUM_HDRS");
                            SQLResultset = SQLstmt.executeQuery("SELECT count(TOH_ID)as STG_AGG_ACTUAL_HEADER FROM FSH_ORA_DATA.DLG_FSH_STG_COMM_PC_AGG_HDR WHERE FILE_NAME = '" + xml_file_name + "'");
                            while (SQLResultset.next()) {
                                String STG_AGG_ACTUAL_HEADER = SQLResultset.getString("STG_AGG_ACTUAL_HEADER");
                                System.out.println("stag Aggregate actual header count ----" + STG_AGG_ACTUAL_HEADER);
                                System.out.println("stag actual header count ----" + db_STG_ACTL_RCDS);
                                System.out.println("stag expected header count ----" + STG_EXP_SUM_HDRS);
                                if (db_STG_SUMMARY_FLAG.equals("Y")) {
                                    if (STG_EXP_SUM_HDRS.equals(STG_AGG_ACTUAL_HEADER)) {
                                        String pc_stg_header_line = 1 + "," + db_STG_ACTL_RCDS + "," + STG_EXP_SUM_HDRS + "," + STG_AGG_ACTUAL_HEADER + ",Pass";
                                        section3_results.add(pc_stg_header_line);
                                    } else {
                                        String pc_stg_header_line = 1 + "," + db_STG_ACTL_RCDS + "," + STG_EXP_SUM_HDRS + "," + STG_AGG_ACTUAL_HEADER + ",Fail";
                                        section3_results.add(pc_stg_header_line);
                                    }
                                } else if (db_STG_SUMMARY_FLAG.equals("N")) {
                                    if (db_STG_ACTL_RCDS.equals(STG_AGG_ACTUAL_HEADER)) {
                                        String pc_stg_header_line = 1 + "," + db_STG_ACTL_RCDS + "," + db_STG_ACTL_RCDS + "," + STG_AGG_ACTUAL_HEADER + ",Pass";
                                        section3_results.add(pc_stg_header_line);
                                    } else {
                                        String pc_stg_header_line = 1 + "," + db_STG_ACTL_RCDS + "," + db_STG_ACTL_RCDS + "," + STG_AGG_ACTUAL_HEADER + ",Fail";
                                        section3_results.add(pc_stg_header_line);
                                    }

                                }
                            }
                        }

                    } while (SQLResultset.next());
                }


                //---------------- LINE Validation --------------------
                boolean sec3_lineflag = true;
                String db_STG_ACTL_RCDS_LINE = null;
                Integer db_STG_ACTL_RCDS1_LINE = 0;

                SQLResultset = SQLstmt.executeQuery("SELECT COUNT(PC_HEADER_ID) as STG_ACTL_RCDS FROM FSH_ORA_DATA.DLG_FSH_STG_COMM_PC_LINE WHERE FILE_NAME = '" + xml_file_name + "'");
                while (SQLResultset.next()) {
                    db_STG_ACTL_RCDS_LINE = SQLResultset.getString("STG_ACTL_RCDS");
                    db_STG_ACTL_RCDS1_LINE = SQLResultset.getInt("STG_ACTL_RCDS");
                }

                if (db_STG_ACTL_RCDS1_LINE == 0) {  //--- Zero record validation
                    sec3_lineflag = false;
                    String pc_stg_header_line = 1 + "," + "STG_ACTL_RCDS DB Does not have any records" + "," + "STG_ACTL_RCDS DB Does not have any records" + "," + "STG_AGG_ACTUAL_HEADER DB Does not have any records" + ",Fail";
                    section3_results.add(pc_stg_header_line);
                }

                SQLResultset = SQLstmt.executeQuery("SELECT SUMMARY_FLAG FROM FSH_ORA_DATA.DLG_FSH_STG_COMM_PC_LINE WHERE FILE_NAME = '" + xml_file_name + "'");
                while (SQLResultset.next()) {
                    db_STG_SUMMARY_FLAG = SQLResultset.getString("SUMMARY_FLAG");
                    System.out.println("stag Summary Flag ----" + db_STG_SUMMARY_FLAG);
                }

                if (sec3_lineflag) {
                    do {

                        SQLResultset = SQLstmt.executeQuery("SELECT COUNT(a.PC_HEADER_ID) as STG_EXP_SUM_HDRS \n" +
                                "FROM(\n" +
                                "SELECt PC_HEADER_ID,STATUS,\n" +
                                "row_number() over(partition by PRODUCT,CURRENCY_CODE,EXCHANGE_RATE,EXCHANGE_RATE_TYPE,TAX_RATE,TAX_TYPE,TAX_REGION_LINE,SUMMARY_FLAG,FINANCIAL_ELEMENT\n" +
                                "ORDER BY PRODUCT,CURRENCY_CODE,EXCHANGE_RATE,EXCHANGE_RATE_TYPE,TAX_RATE,TAX_TYPE,TAX_REGION_LINE,SUMMARY_FLAG,FINANCIAL_ELEMENT) row_1\n" +
                                "FROM FSH_ORA_DATA.DLG_FSH_STG_COMM_PC_LINE WHERE FILE_NAME  = '" + xml_file_name + "')a \n" +
                                "where a.row_1 = 1\n" +
                                "AND a.STATUS = 'COMPLETE'");

                        while (SQLResultset.next()) {
                            String STG_EXP_SUM_HDRS_LINE = SQLResultset.getString("STG_EXP_SUM_HDRS");
                            SQLResultset = SQLstmt.executeQuery("SELECT count(TOH_ID)as STG_AGG_ACTUAL_HEADER FROM FSH_ORA_DATA.DLG_FSH_STG_COMM_PC_AGG_LINE WHERE FILE_NAME = '" + xml_file_name + "'");
                            while (SQLResultset.next()) {
                                String STG_AGG_ACTUAL_HEADER_LINE = SQLResultset.getString("STG_AGG_ACTUAL_HEADER");

                                if (db_STG_SUMMARY_FLAG.equals("Y")) {
                                    if (STG_EXP_SUM_HDRS_LINE.equals(STG_AGG_ACTUAL_HEADER_LINE)) {
                                        String pc_stg_header_line = 1 + "," + db_STG_ACTL_RCDS_LINE + "," + STG_EXP_SUM_HDRS_LINE + "," + STG_AGG_ACTUAL_HEADER_LINE + ",Pass";
                                        section3_results.add(pc_stg_header_line);
                                    } else {
                                        String pc_stg_header_line = 1 + "," + db_STG_ACTL_RCDS_LINE + "," + STG_EXP_SUM_HDRS_LINE + "," + STG_AGG_ACTUAL_HEADER_LINE + ",Fail";
                                        section3_results.add(pc_stg_header_line);
                                    }
                                } else if (db_STG_SUMMARY_FLAG.equals("N")) {
                                    if (db_STG_ACTL_RCDS_LINE.equals(STG_AGG_ACTUAL_HEADER_LINE)) {
                                        String pc_stg_header_line = 1 + "," + db_STG_ACTL_RCDS_LINE + "," + db_STG_ACTL_RCDS_LINE + "," + STG_AGG_ACTUAL_HEADER_LINE + ",Pass";
                                        section3_results.add(pc_stg_header_line);
                                    } else {
                                        String pc_stg_header_line = 1 + "," + db_STG_ACTL_RCDS_LINE + "," + db_STG_ACTL_RCDS_LINE + "," + STG_AGG_ACTUAL_HEADER_LINE + ",Fail";
                                        section3_results.add(pc_stg_header_line);
                                    }

                                }
                            }
                        }

                    } while (SQLResultset.next());
                }

                //-------------- Validation Cons to Stag table ----------------
                String LandscapeGLPremium_consSqlQuery = connect_db.executeQuery_DB("LandscapeGL", "GLPremium_Cons", "LANDSCAPE");
                SQLResultset = SQLstmt.executeQuery(LandscapeGLPremium_consSqlQuery + "'" + file_name + "'");
                //SQLResultset = SQLstmt.executeQuery("SELECT * from DLG_FSH_CONS_LAND_PC_HDR WHERE FILE_NAME = '" + xml_file_name + "'");
                while (SQLResultset.next()) {
                    db_CONS_PC_HEADER_ID = SQLResultset.getString("PC_HEADER_ID");
                    list_header.add(db_CONS_PC_HEADER_ID);
                }


                for (int i = 0; i < list_header.size(); i++) {
                    SQLResultset = SQLstmt.executeQuery(LandscapeGLPremium_consSqlQuery + "'" + file_name + "' and PC_HEADER_ID = '" + list_header.get(i) + "' ");
                    //SQLResultset = SQLstmt.executeQuery("SELECT * from DLG_FSH_CONS_LAND_PC_HDR WHERE FILE_NAME = '" + xml_file_name + "' and PC_HEADER_ID ='" + list_header.get(i) + "'");
                    while (SQLResultset.next()) {
                        db_CONS_PC_HEADER_ID = SQLResultset.getString("PC_HEADER_ID");
                        db_CONS_SOURCE = SQLResultset.getString("SOURCE");
                        db_CONS_ACCOUNT_NUMBER = SQLResultset.getString("ACCOUNT_NUMBER");
                        db_CONS_POLICY_NUMBER = SQLResultset.getString("POLICY_NUMBER");
                        db_CONS_UNDERWRITER = SQLResultset.getString("UNDERWRITER");
                        db_CONS_BRAND = SQLResultset.getString("BRAND");
                        db_CONS_LINE_OF_BUSINESS = SQLResultset.getString("LINE_OF_BUSINESS");
                        db_CONS_PRODUCT_TYPE = SQLResultset.getString("PRODUCT_TYPE");
                        db_CONS_CHANNEL = SQLResultset.getString("CHANNEL");
                        db_CONS_TRANSACTION_DATE = SQLResultset.getString("TRANSACTION_DATE");
                        db_CONS_BILLING_INSTRUCTION_TYPE = SQLResultset.getString("BILLING_INSTRUCTION_TYPE");
                        db_CONS_ON_RISK_DATE = SQLResultset.getString("ON_RISK_DATE");
                        db_CONS_OFF_RISK_DATE = SQLResultset.getString("OFF_RISK_DATE");
                        db_CONS_LPI_CODE = SQLResultset.getString("LPI_CODE");
                        db_CONS_BATCH_PKEY = SQLResultset.getString("BATCH_FKEY");
                        db_CONS_FILE_NAME = SQLResultset.getString("FILE_NAME");
                        db_CONS_STATUS = SQLResultset.getString("STATUS");
                        load_date = SQLResultset.getString("LOAD_DATE");
                        String db_file_name = SQLResultset.getString("FILE_NAME");

                        //Converting Load date format
                        String load_dateTRIM = load_date.substring(0, 10);
                        load_dateFormat = Date.valueOf(load_dateTRIM);
                        System.out.println(load_dateFormat);


                        //Validating mandatory fields in consolidation table
                        //Source - mandatory validation
                        if ((db_CONS_SOURCE == null) && (db_CONS_STATUS != "REVIEW")) {

                            String stg_header_id = "," + db_CONS_PC_HEADER_ID + ",SOURCE," + "SOURCE : " + db_CONS_SOURCE + "," + "SOURCE was not found," + db_CONS_STATUS + "," + "Fail";
                            section2_results.add(stg_header_id);
                            cons_mandatory_map_row++;
                        } else {
                            String stg_header_id = "," + db_CONS_PC_HEADER_ID + ",SOURCE," + "SOURCE : " + db_CONS_SOURCE + "," + "SOURCE was found," + db_CONS_STATUS + "," + "Pass";
                            section2_results.add(stg_header_id);
                            cons_mandatory_map_row++;
                        }

                        //POLICY_NUMBER - mandatory validation
                        if ((db_CONS_POLICY_NUMBER == null) && (db_CONS_STATUS != "REVIEW")) {

                            String stg_header_id = "," + ",POLICY_NUMBER," + "POLICY_NUMBER : " + db_CONS_POLICY_NUMBER + "," + "POLICY_NUMBER was not found," + db_CONS_STATUS + "," + "Fail";
                            section2_results.add(stg_header_id);
                        } else {
                            String stg_header_id = "," + ",POLICY_NUMBER," + "POLICY_NUMBER : " + db_CONS_POLICY_NUMBER + "," + "POLICY_NUMBER was found," + db_CONS_STATUS + "," + "Pass";
                            section2_results.add(stg_header_id);
                        }

                        //BRAND - mandatory validation
                        if ((db_CONS_BRAND == null) && (db_CONS_STATUS != "REVIEW")) {

                            String stg_header_id = "," + ",BRAND," + "BRAND : " + db_CONS_BRAND + "," + "BRAND was not found," + db_CONS_STATUS + "," + "Fail";
                            section2_results.add(stg_header_id);
                        } else {
                            String stg_header_id = "," + ",BRAND," + "BRAND : " + db_CONS_BRAND + "," + "BRAND was found," + db_CONS_STATUS + "," + "Pass";
                            section2_results.add(stg_header_id);
                        }

                        //LINE_OF_BUSINESS - mandatory validation
                        if ((db_CONS_LINE_OF_BUSINESS == null) && (db_CONS_STATUS != "REVIEW")) {

                            String stg_header_id = "," + ",LINE_OF_BUSINESS," + "LINE_OF_BUSINESS : " + db_CONS_LINE_OF_BUSINESS + "," + "LINE_OF_BUSINESS was not found," + db_CONS_STATUS + "," + "Fail";
                            section2_results.add(stg_header_id);
                        } else {
                            String stg_header_id = "," + ",LINE_OF_BUSINESS," + "LINE_OF_BUSINESS : " + db_CONS_LINE_OF_BUSINESS + "," + "LINE_OF_BUSINESS was found," + db_CONS_STATUS + "," + "Pass";
                            section2_results.add(stg_header_id);
                        }

                        //PRODUCT_TYPE - mandatory validation
                        if ((db_CONS_PRODUCT_TYPE == null) && (db_CONS_STATUS != "REVIEW")) {

                            String stg_header_id = "," + ",PRODUCT_TYPE," + "PRODUCT_TYPE : " + db_CONS_PRODUCT_TYPE + "," + "PRODUCT_TYPE was not found," + db_CONS_STATUS + "," + "Fail";
                            section2_results.add(stg_header_id);
                        } else {
                            String stg_header_id = "," + ",PRODUCT_TYPE," + "PRODUCT_TYPE : " + db_CONS_PRODUCT_TYPE + "," + "PRODUCT_TYPE was found," + db_CONS_STATUS + "," + "Pass";
                            section2_results.add(stg_header_id);
                        }

                        //CHANNEL - mandatory validation
                        if ((db_CONS_CHANNEL == null) && (db_CONS_STATUS != "REVIEW")) {

                            String stg_header_id = "," + ",CHANNEL," + "CHANNEL : " + db_CONS_CHANNEL + "," + "CHANNEL was not found," + db_CONS_STATUS + "," + "Fail";
                            section2_results.add(stg_header_id);
                        } else {
                            String stg_header_id = "," + ",CHANNEL," + "CHANNEL : " + db_CONS_CHANNEL + "," + "CHANNEL was found," + db_CONS_STATUS + "," + "Pass";
                            section2_results.add(stg_header_id);
                        }

                        //TRANSACTION_DATE - mandatory validation
                        if ((db_CONS_TRANSACTION_DATE == null) && (db_CONS_STATUS != "REVIEW")) {

                            String stg_header_id = "," + ",TRANSACTION_DATE," + "TRANSACTION_DATE : " + db_CONS_TRANSACTION_DATE + "," + "TRANSACTION_DATE was not found," + db_CONS_STATUS + "," + "Fail";
                            section2_results.add(stg_header_id);
                        } else {
                            String stg_header_id = "," + ",TRANSACTION_DATE," + "TRANSACTION_DATE : " + db_CONS_TRANSACTION_DATE + "," + "TRANSACTION_DATE was found," + db_CONS_STATUS + "," + "Pass";
                            section2_results.add(stg_header_id);
                        }

                        //BILLING_INSTRUCTION_TYPE - mandatory validation
                        if ((db_CONS_BILLING_INSTRUCTION_TYPE == null) && (db_CONS_STATUS != "REVIEW")) {

                            String stg_header_id = "," + ",BILLING_INSTRUCTION_TYPE," + "BILLING_INSTRUCTION_TYPE : " + db_CONS_BILLING_INSTRUCTION_TYPE + "," + "BILLING_INSTRUCTION_TYPE was not found," + db_CONS_STATUS + "," + "Fail";
                            section2_results.add(stg_header_id);
                        } else {
                            String stg_header_id = "," + ",BILLING_INSTRUCTION_TYPE," + "BILLING_INSTRUCTION_TYPE : " + db_CONS_BILLING_INSTRUCTION_TYPE + "," + "BILLING_INSTRUCTION_TYPE was found," + db_CONS_STATUS + "," + "Pass";
                            section2_results.add(stg_header_id);
                        }

                        //ON_RISK_DATE - mandatory validation
                        if ((db_CONS_ON_RISK_DATE == null) && (db_CONS_STATUS != "REVIEW")) {

                            String stg_header_id = "," + ",ON_RISK_DATE," + "ON_RISK_DATE : " + db_CONS_ON_RISK_DATE + "," + "ON_RISK_DATE was not found," + db_CONS_STATUS + "," + "Fail";
                            section2_results.add(stg_header_id);
                        } else {
                            String stg_header_id = "," + ",ON_RISK_DATE," + "ON_RISK_DATE : " + db_CONS_ON_RISK_DATE + "," + "ON_RISK_DATE was found," + db_CONS_STATUS + "," + "Pass";
                            section2_results.add(stg_header_id);
                        }

                        //OFF_RISK_DATE - mandatory validation
                        if ((db_CONS_OFF_RISK_DATE == null) && (db_CONS_STATUS != "REVIEW")) {

                            String stg_header_id = "," + ",OFF_RISK_DATE," + "OFF_RISK_DATE : " + db_CONS_OFF_RISK_DATE + "," + "OFF_RISK_DATE was not found," + db_CONS_STATUS + "," + "Fail";
                            section2_results.add(stg_header_id);
                        } else {
                            String stg_header_id = "," + ",OFF_RISK_DATE," + "OFF_RISK_DATE : " + db_CONS_OFF_RISK_DATE + "," + "OFF_RISK_DATE was found," + db_CONS_STATUS + "," + "Pass";
                            section2_results.add(stg_header_id);
                        }


                        //LPI_CODE - mandatory validation
                        if ((db_CONS_LPI_CODE == null) && (db_CONS_STATUS != "REVIEW")) {

                            String stg_header_id = "," + ",LPI_CODE," + "LPI_CODE : " + db_CONS_LPI_CODE + "," + "LPI_CODE was not found," + db_CONS_STATUS + "," + "Fail";
                            section2_results.add(stg_header_id);
                        } else {
                            String stg_header_id = "," + ",LPI_CODE," + "LPI_CODE : " + db_CONS_LPI_CODE + "," + "LPI_CODE was found," + db_CONS_STATUS + "," + "Pass";
                            section2_results.add(stg_header_id);
                        }

                        //BATCH_PKEY - mandatory validation
                        if ((db_CONS_BATCH_PKEY == null) && (db_CONS_STATUS != "REVIEW")) {

                            String stg_header_id = "," + ",BATCH_PKEY," + "BATCH_PKEY : " + db_CONS_BATCH_PKEY + "," + "BATCH_PKEY was not found," + db_CONS_STATUS + "," + "Fail";
                            section2_results.add(stg_header_id);
                        } else {
                            String stg_header_id = "," + ",BATCH_PKEY," + "BATCH_PKEY : " + db_CONS_BATCH_PKEY + "," + "BATCH_PKEY was found," + db_CONS_STATUS + "," + "Pass";
                            section2_results.add(stg_header_id);
                        }

                        //FILE_NAME - mandatory validation
                        if ((db_CONS_FILE_NAME == null) && (db_CONS_STATUS != "REVIEW")) {

                            String stg_header_id = "," + ",FILE_NAME," + "FILE_NAME : " + db_CONS_FILE_NAME + "," + "FILE_NAME was not found," + db_CONS_STATUS + "," + "Fail";
                            section2_results.add(stg_header_id);
                        } else {
                            String stg_header_id = "," + ",FILE_NAME," + "FILE_NAME : " + db_CONS_FILE_NAME + "," + "FILE_NAME was found," + db_CONS_STATUS + "," + "Pass";
                            section2_results.add(stg_header_id);
                        }


                        //------------------- Consolidation to Staging ----------------------------------
                        String LandscapeGLPremium_stgSqlQuery = connect_db.executeQuery_DB("LandscapeGL", "GLPremium_Stg", "LANDSCAPE");
                        SQLResultset = SQLstmt.executeQuery(LandscapeGLPremium_stgSqlQuery + "'" + file_name + "' and PC_HEADER_ID = '" + list_header.get(i) + "' ");
                        //SQLResultset = SQLstmt.executeQuery("SELECT *  from DLG_FSH_STG_COMM_PC_HDR  WHERE FILE_NAME = '" + xml_file_name + "' and PC_HEADER_ID = '" + list_header.get(i) + "' ");
                        System.out.println("Header id outer ---" + db_CONS_PC_HEADER_ID);
                        if (!SQLResultset.next()) {
                            String stg_header_id = section2_map_row + ",HEADER_ID," + "no records available in STG table" + "," + db_CONS_PC_HEADER_ID + ",Fail";
                            section2_results.add(stg_header_id);
                        } else {
                            SQLResultset = SQLstmt.executeQuery(LandscapeGLPremium_stgSqlQuery + "'" + file_name + "' and PC_HEADER_ID = '" + list_header.get(i) + "' ");
                            //SQLResultset = SQLstmt.executeQuery("SELECT *  from DLG_FSH_STG_COMM_PC_HDR  WHERE FILE_NAME = '" + xml_file_name + "' and PC_HEADER_ID = '" + list_header.get(i) + "' ");
                            while (SQLResultset.next()) {
                                db_STG_PC_HEADER_ID = SQLResultset.getString("PC_HEADER_ID");
                                db_STG_SOURCE = SQLResultset.getString("SOURCE");
                                db_STG_ACCOUNT_NUMBER = SQLResultset.getString("ACCOUNT_NUMBER");
                                db_STG_POLICY_NUMBER = SQLResultset.getString("POLICY_NUMBER");
                                db_STG_UNDERWRITER = SQLResultset.getString("UNDERWRITER");
                                db_STG_BRAND = SQLResultset.getString("BRAND");
                                db_STG_LINE_OF_BUSINESS = SQLResultset.getString("LINE_OF_BUSINESS");
                                db_STG_PRODUCT_TYPE = SQLResultset.getString("PRODUCT_TYPE");
                                db_STG_CHANNEL = SQLResultset.getString("CHANNEL");
                                db_STG_TRANSACTION_DATE = SQLResultset.getString("TRANSACTION_DATE");
                                db_STG_BILLING_INSTRUCTION_TYPE = SQLResultset.getString("BILLING_INSTRUCTION_TYPE");
                                db_STG_ON_RISK_DATE = SQLResultset.getString("ON_RISK_DATE");
                                db_STG_OFF_RISK_DATE = SQLResultset.getString("OFF_RISK_DATE");
                                db_STG_TAX_REGION = SQLResultset.getString("TAX_REGION");
                                db_STG_PRODUCT_KEY = SQLResultset.getString("PRODUCT_KEY");
                                db_STG_SUMMARY_FLAG = SQLResultset.getString("SUMMARY_FLAG");
                                db_STG_UEP_CANCELLATION_FLAG = SQLResultset.getString("UEP_CANCELLATION_FLAG");
                                db_STG_TOH_ID = SQLResultset.getString("TOH_ID");
                                db_STG_EVENT_CODE = SQLResultset.getString("EVENT_CODE");
                                db_STG_ENTITY_TYPE_CODE = SQLResultset.getString("ENTITY_TYPE_CODE");
                                db_STG_CREATION_DATE = SQLResultset.getString("CREATION_DATE");
                                db_STG_CREATED_BY = SQLResultset.getString("CREATED_BY");
                                db_STG_LAST_UPDATE_DATE = SQLResultset.getString("LAST_UPDATE_DATE");
                                db_STG_LAST_UPDATED_BY = SQLResultset.getString("LAST_UPDATED_BY");
                                db_STG_PC_SUMMARY_ID = SQLResultset.getString("PC_SUMMARY_ID");
                                db_STG_BATCH_FKEY = SQLResultset.getString("BATCH_FKEY");
                                db_STG_FILE_NAME = SQLResultset.getString("FILE_NAME");
                                db_STG_STATUS = SQLResultset.getString("STATUS");

                                //Staging mandatory validations
                                //HEADER_ID - mandatory validation
                                if ((db_STG_PC_HEADER_ID == null) && (db_STG_STATUS != "REVIEW")) {

                                    String stg_header_id = stg_line_map_row + "," + db_STG_PC_HEADER_ID + ",PC_HEADER_ID," + "PC_HEADER_ID : " + db_STG_PC_HEADER_ID + "," + "PC_HEADER_ID was not found," + db_STG_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                    stg_line_map_row++;
                                } else {
                                    String stg_header_id = stg_line_map_row + "," + db_STG_PC_HEADER_ID + ",PC_HEADER_ID," + "PC_HEADER_ID : " + db_STG_PC_HEADER_ID + "," + "PC_HEADER_ID was found," + db_STG_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                    stg_line_map_row++;
                                }

                                //SOURCE - mandatory validation
                                if ((db_STG_SOURCE == null) && (db_STG_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",SOURCE," + "SOURCE : " + db_STG_SOURCE + "," + "SOURCE was not found," + db_STG_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",SOURCE," + "SOURCE : " + db_STG_SOURCE + "," + "SOURCE was found," + db_STG_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //ACCOUNT_NUMBER - mandatory validation
                                if ((db_STG_ACCOUNT_NUMBER == null) && (db_STG_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",ACCOUNT_NUMBER," + "ACCOUNT_NUMBER : " + db_STG_ACCOUNT_NUMBER + "," + "ACCOUNT_NUMBER was not found," + db_STG_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",ACCOUNT_NUMBER," + "ACCOUNT_NUMBER : " + db_STG_ACCOUNT_NUMBER + "," + "ACCOUNT_NUMBER was found," + db_STG_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //POLICY_NUMBER - mandatory validation
                                if ((db_STG_POLICY_NUMBER == null) && (db_STG_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",POLICY_NUMBER," + "POLICY_NUMBER : " + db_STG_POLICY_NUMBER + "," + "POLICY_NUMBER was not found," + db_STG_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",POLICY_NUMBER," + "POLICY_NUMBER : " + db_STG_POLICY_NUMBER + "," + "POLICY_NUMBER was found," + db_STG_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //UNDERWRITER - mandatory validation
                                if ((db_STG_UNDERWRITER == null) && (db_STG_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",UNDERWRITER," + "UNDERWRITER : " + db_STG_UNDERWRITER + "," + "UNDERWRITER was not found," + db_STG_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",UNDERWRITER," + "UNDERWRITER : " + db_STG_UNDERWRITER + "," + "UNDERWRITER was found," + db_STG_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //BRAND - mandatory validation
                                if ((db_STG_BRAND == null) && (db_STG_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",BRAND," + "BRAND : " + db_STG_BRAND + "," + "BRAND was not found," + db_STG_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",BRAND," + "BRAND : " + db_STG_BRAND + "," + "BRAND was found," + db_STG_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //LINE_OF_BUSINESS - mandatory validation
                                if ((db_STG_LINE_OF_BUSINESS == null) && (db_STG_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",LINE_OF_BUSINESS," + "LINE_OF_BUSINESS : " + db_STG_LINE_OF_BUSINESS + "," + "LINE_OF_BUSINESS was not found," + db_STG_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",LINE_OF_BUSINESS," + "LINE_OF_BUSINESS : " + db_STG_LINE_OF_BUSINESS + "," + "LINE_OF_BUSINESS was found," + db_STG_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }


                                //PRODUCT_TYPE - mandatory validation
                                if ((db_STG_PRODUCT_TYPE == null) && (db_STG_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",PRODUCT_TYPE," + "PRODUCT_TYPE : " + db_STG_PRODUCT_TYPE + "," + "PRODUCT_TYPE was not found," + db_STG_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",PRODUCT_TYPE," + "PRODUCT_TYPE : " + db_STG_PRODUCT_TYPE + "," + "PRODUCT_TYPE was found," + db_STG_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //CHANNEL - mandatory validation
                                if ((db_STG_CHANNEL == null) && (db_STG_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",CHANNEL," + "CHANNEL : " + db_STG_CHANNEL + "," + "CHANNEL was not found," + db_STG_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",CHANNEL," + "CHANNEL : " + db_STG_CHANNEL + "," + "CHANNEL was found," + db_STG_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //BILLING_INSTRUCTION_TYPE - mandatory validation
                                if ((db_STG_BILLING_INSTRUCTION_TYPE == null) && (db_STG_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",BILLING_INSTRUCTION_TYPE," + "BILLING_INSTRUCTION_TYPE : " + db_STG_BILLING_INSTRUCTION_TYPE + "," + "BILLING_INSTRUCTION_TYPE was not found," + db_STG_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",BILLING_INSTRUCTION_TYPE," + "BILLING_INSTRUCTION_TYPE : " + db_STG_BILLING_INSTRUCTION_TYPE + "," + "BILLING_INSTRUCTION_TYPE was found," + db_STG_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //TAX_REGION - mandatory validation
                                if ((db_STG_TAX_REGION == null) && (db_STG_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",TAX_REGION," + "TAX_REGION : " + db_STG_TAX_REGION + "," + "TAX_REGION was not found," + db_STG_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",TAX_REGION," + "TAX_REGION : " + db_STG_TAX_REGION + "," + "TAX_REGION was found," + db_STG_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //PRODUCT_KEY - mandatory validation
                                if ((db_STG_PRODUCT_KEY == null) && (db_STG_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",PRODUCT_KEY," + "PRODUCT_KEY : " + db_STG_PRODUCT_KEY + "," + "PRODUCT_KEY was not found," + db_STG_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",PRODUCT_KEY," + "PRODUCT_KEY : " + db_STG_PRODUCT_KEY + "," + "PRODUCT_KEY was found," + db_STG_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //UEP_CANCELLATION_FLAG - mandatory validation
                                if ((db_STG_UEP_CANCELLATION_FLAG == null) && (db_STG_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",UEP_CANCELLATION_FLAG," + "UEP_CANCELLATION_FLAG : " + db_STG_UEP_CANCELLATION_FLAG + "," + "UEP_CANCELLATION_FLAG was not found," + db_STG_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",UEP_CANCELLATION_FLAG," + "UEP_CANCELLATION_FLAG : " + db_STG_UEP_CANCELLATION_FLAG + "," + "UEP_CANCELLATION_FLAG was found," + db_STG_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //EVENT_CODE - mandatory validation
                                if ((db_STG_EVENT_CODE == null) && (db_STG_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",EVENT_CODE," + "EVENT_CODE : " + db_STG_EVENT_CODE + "," + "EVENT_CODE was not found," + db_STG_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",EVENT_CODE," + "EVENT_CODE : " + db_STG_EVENT_CODE + "," + "EVENT_CODE was found," + db_STG_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //ENTITY_TYPE_CODE - mandatory validation
                                if ((db_STG_ENTITY_TYPE_CODE == null) && (db_STG_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",ENTITY_TYPE_CODE," + "ENTITY_TYPE_CODE : " + db_STG_ENTITY_TYPE_CODE + "," + "ENTITY_TYPE_CODE was not found," + db_STG_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",ENTITY_TYPE_CODE," + "ENTITY_TYPE_CODE : " + db_STG_ENTITY_TYPE_CODE + "," + "ENTITY_TYPE_CODE was found," + db_STG_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //SUMMARY_FLAG - mandatory validation
                                if ((db_STG_SUMMARY_FLAG == null) && (db_STG_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",SUMMARY_FLAG," + "SUMMARY_FLAG : " + db_STG_SUMMARY_FLAG + "," + "SUMMARY_FLAG was not found," + db_STG_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",SUMMARY_FLAG," + "SUMMARY_FLAG : " + db_STG_SUMMARY_FLAG + "," + "SUMMARY_FLAG was found," + db_STG_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }


                                if (db_CONS_PC_HEADER_ID.equals(db_STG_PC_HEADER_ID)) {
                                    String cons_header_id = cons_stg_map_row + ",HEADER_ID," + db_STG_PC_HEADER_ID + "," + db_CONS_PC_HEADER_ID + ",Pass";
                                    section1_results.add(cons_header_id);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",HEADER_ID" + "," + db_STG_PC_HEADER_ID + "," + db_CONS_PC_HEADER_ID + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    cons_stg_map_row++;
                                } else {
                                    String cons_header_id = cons_stg_map_row + ",HEADER_ID," + db_STG_PC_HEADER_ID + "," + db_CONS_PC_HEADER_ID + ",Fail";
                                    section1_results.add(cons_header_id);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",HEADER_ID" + "," + db_STG_PC_HEADER_ID + "," + db_CONS_PC_HEADER_ID + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    cons_stg_map_row++;
                                    CONS_flag++;
                                }


                                //--------------------  Validation SOURCE ---------------
                                if (db_CONS_SOURCE.equals(db_STG_SOURCE)) {
                                    String cons_source = ",SOURCE," + db_STG_SOURCE + "," + db_CONS_SOURCE + ",Pass";
                                    section1_results.add(cons_source);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SOURCE" + "," + db_STG_SOURCE + "," + db_CONS_SOURCE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_source = ",SOURCE," + db_STG_SOURCE + "," + db_CONS_SOURCE + ",Fail";
                                    section1_results.add(cons_source);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SOURCE" + "," + db_STG_SOURCE + "," + db_CONS_SOURCE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //------------- Validate STATUS ----------------
                                if ((db_STG_STATUS != null) && (db_CONS_STATUS != null)) {
                                    if (db_STG_STATUS.equals(db_CONS_STATUS)) {
                                        String stg_line_status = ",STATUS," + db_STG_STATUS + "," + db_CONS_STATUS + ",Pass";
                                        section1_results.add(stg_line_status);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",STATUS" + "," + db_STG_STATUS + "," + db_CONS_STATUS + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String stg_line_status = ",STATUS," + db_STG_STATUS + "," + db_CONS_STATUS + ",Fail";
                                        section1_results.add(stg_line_status);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",STATUS" + "," + db_STG_STATUS + "," + db_CONS_STATUS + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //--------------------  Validation POLICY_NUMBER ---------------
                                if (db_CONS_POLICY_NUMBER.equals(db_STG_POLICY_NUMBER)) {
                                    String cons_policy_number = ",POLICY_NUMBER," + db_STG_POLICY_NUMBER + "," + db_CONS_POLICY_NUMBER + ",Pass";
                                    section1_results.add(cons_policy_number);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",POLICY_NUMBER" + "," + db_STG_POLICY_NUMBER + "," + db_CONS_POLICY_NUMBER + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_policy_number = ",POLICY_NUMBER," + db_STG_POLICY_NUMBER + "," + db_CONS_POLICY_NUMBER + ",Fail";
                                    section1_results.add(cons_policy_number);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",POLICY_NUMBER" + "," + db_STG_POLICY_NUMBER + "," + db_CONS_POLICY_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                            /*//--------------------  Validation ACCOUNT_NUMBER ---------------
                            if(db_CONS_ACCOUNT_NUMBER.equals(db_STG_ACCOUNT_NUMBER)){
                                String cons_ACCOUNT_NUMBER = ",ACCOUNT_NUMBER," + db_STG_ACCOUNT_NUMBER + "," + db_CONS_ACCOUNT_NUMBER + ",Pass";
                                section1_results.add(cons_ACCOUNT_NUMBER);
                            }else {
                                String cons_ACCOUNT_NUMBER = ",ACCOUNT_NUMBER," + db_STG_ACCOUNT_NUMBER + "," + db_CONS_ACCOUNT_NUMBER + ",Fail";
                                section1_results.add(cons_ACCOUNT_NUMBER);
                            }*/

                                //--------------------  Validation TRANSACTION_DATE ---------------
                                String db_STG_TRANSACTION_DATEModified = db_STG_TRANSACTION_DATE.substring(0, 19);

                                if (db_CONS_TRANSACTION_DATE.equals(db_STG_TRANSACTION_DATEModified)) {
                                    String cons_TRANSACTION_DATE = ",TRANSACTION_DATE," + db_STG_TRANSACTION_DATEModified + "," + db_CONS_TRANSACTION_DATE + ",Pass";
                                    section1_results.add(cons_TRANSACTION_DATE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATEModified + "," + db_CONS_TRANSACTION_DATE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_TRANSACTION_DATE = ",TRANSACTION_DATE," + db_STG_TRANSACTION_DATEModified + "," + db_CONS_TRANSACTION_DATE + ",Fail";
                                    section1_results.add(cons_TRANSACTION_DATE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATEModified + "," + db_CONS_TRANSACTION_DATE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation ON_RISK_DATE ---------------
                                String db_STG_ON_RISK_DATEModified = db_STG_ON_RISK_DATE.substring(0, 10);
                                String db_CONS_ON_RISK_DATEModified = db_CONS_ON_RISK_DATE.substring(0, 10);
                                if (db_CONS_ON_RISK_DATEModified.equals(db_STG_ON_RISK_DATEModified)) {
                                    String cons_ON_RISK_DATE = ",ON_RISK_DATE," + db_STG_ON_RISK_DATEModified + "," + db_CONS_ON_RISK_DATEModified + ",Pass";
                                    section1_results.add(cons_ON_RISK_DATE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ON_RISK_DATE" + "," + db_STG_ON_RISK_DATEModified + "," + db_CONS_ON_RISK_DATEModified + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_ON_RISK_DATE = ",ON_RISK_DATE," + db_STG_ON_RISK_DATEModified + "," + db_CONS_ON_RISK_DATEModified + ",Fail";
                                    section1_results.add(cons_ON_RISK_DATE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ON_RISK_DATE" + "," + db_STG_ON_RISK_DATEModified + "," + db_CONS_ON_RISK_DATEModified + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation OFF_RISK_DATE ---------------
                                String db_STG_OFF_RISK_DATEModified = db_STG_OFF_RISK_DATE.substring(0, 10);
                                String db_CONS_OFF_RISK_DATEModified = db_CONS_OFF_RISK_DATE.substring(0, 10);
                                if (db_CONS_OFF_RISK_DATEModified.equals(db_STG_OFF_RISK_DATEModified)) {
                                    String cons_OFF_RISK_DATE = ",OFF_RISK_DATE," + db_STG_OFF_RISK_DATEModified + "," + db_CONS_OFF_RISK_DATEModified + ",Pass";
                                    section1_results.add(cons_OFF_RISK_DATE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",OFF_RISK_DATE" + "," + db_STG_OFF_RISK_DATEModified + "," + db_CONS_OFF_RISK_DATEModified + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_OFF_RISK_DATE = ",OFF_RISK_DATE," + db_STG_OFF_RISK_DATEModified + "," + db_CONS_OFF_RISK_DATEModified + ",Fail";
                                    section1_results.add(cons_OFF_RISK_DATE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",OFF_RISK_DATE" + "," + db_STG_OFF_RISK_DATEModified + "," + db_CONS_OFF_RISK_DATEModified + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation PRODUCT_KEY     ---------------
                                if (db_CONS_LPI_CODE.equals(db_STG_PRODUCT_KEY)) {
                                    String cons_PRODUCT_KEY = ",PRODUCT_KEY," + db_STG_PRODUCT_KEY + "," + db_CONS_LPI_CODE + ",Pass";
                                    section1_results.add(cons_PRODUCT_KEY);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT_KEY" + "," + db_STG_PRODUCT_KEY + "," + db_CONS_LPI_CODE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_PRODUCT_KEY = ",PRODUCT_KEY," + db_STG_PRODUCT_KEY + "," + db_CONS_LPI_CODE + ",Fail";
                                    section1_results.add(cons_PRODUCT_KEY);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT_KEY" + "," + db_STG_PRODUCT_KEY + "," + db_CONS_LPI_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation BATCH_FKEY     ---------------
                                if (db_CONS_BATCH_PKEY.equals(db_STG_BATCH_FKEY)) {
                                    String cons_BATCH_FKEY = ",BATCH_FKEY," + db_STG_BATCH_FKEY + "," + db_CONS_BATCH_PKEY + ",Pass";
                                    section1_results.add(cons_BATCH_FKEY);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BATCH_FKEY" + "," + db_STG_BATCH_FKEY + "," + db_CONS_BATCH_PKEY + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_BATCH_FKEY = ",BATCH_FKEY," + db_STG_BATCH_FKEY + "," + db_CONS_BATCH_PKEY + ",Fail";
                                    section1_results.add(cons_BATCH_FKEY);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BATCH_FKEY" + "," + db_STG_BATCH_FKEY + "," + db_CONS_BATCH_PKEY + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation FILE_NAME ---------------
                                if (db_CONS_FILE_NAME.equals(db_STG_FILE_NAME)) {
                                    String cons_FILE_NAME = ",FILE_NAME," + db_STG_FILE_NAME + "," + db_CONS_FILE_NAME + ",Pass";
                                    section1_results.add(cons_FILE_NAME);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",FILE_NAME" + "," + db_STG_FILE_NAME + "," + db_CONS_FILE_NAME + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_FILE_NAME = ",FILE_NAME," + db_STG_FILE_NAME + "," + db_CONS_FILE_NAME + ",Fail";
                                    section1_results.add(cons_FILE_NAME);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",FILE_NAME" + "," + db_STG_FILE_NAME + "," + db_CONS_FILE_NAME + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                            /*//--------------------  Validation INVOICE_RECEIVED_DATE ---------------
                            String db_STG_INVOICE_RECEIVED_DATEModified = db_STG_INVOICE_RECEIVED_DATE.substring(0,10);
                            String db_CONS_INVOICE_RECEIVED_DATEModified = db_CONS_INVOICE_RECEIVED_DATE.substring(0,10);
                            if(db_CONS_INVOICE_RECEIVED_DATEModified.equals(db_STG_INVOICE_RECEIVED_DATEModified)){
                                String cons_invoice_recived_date = ",INVOICE_RECEIVED_DATE," + db_STG_INVOICE_RECEIVED_DATEModified + "," + db_CONS_INVOICE_RECEIVED_DATEModified + ",Pass";
                                section1_results.add(cons_invoice_recived_date);
                            }else {
                                String cons_invoice_recived_date = ",INVOICE_RECEIVED_DATE," + db_STG_INVOICE_RECEIVED_DATEModified + "," + db_CONS_INVOICE_RECEIVED_DATEModified + ",Fail";
                                section1_results.add(cons_invoice_recived_date);
                            }*/


                                //----------------------- STANDARDISATION start here -----------------------------
                                String db_lookup_underwriter_meaning = "null";
                                String db_lookup_product_type_meaning = "null";
                                String db_lookup_line_of_business_meaning = "null";
                                String db_lookup_brand_meaning = "null";
                                String db_lookupV_channel_meaning = "null";
                                String db_lookup_billing_instruction_type_meaning = "null";
                                String db_lookup_tax_region_meaning = "null";
                                String db_lookup_event_code_meaning = "null";
                                String db_lookup_entity_type_code_meaning = "null";
                                String db_lookup_summary_flag_meaning = "null";
                                String db_lookup_accountNumber_meaning = "null";
                                String db_lookup__uepCancellationFlag_meaning = "null";


                                //---------------- Validate ACCOUNT_NUMBER -----------------------
                                String LandscapeGLPremium_fsh_lookup = connect_db.executeQuery_DB("Lookup", "FSH_LOOKUP", "LANDSCAPE");
                                String LandscapeGLPremium_fsh_sys_lookup = connect_db.executeQuery_DB("Lookup", "FSH_SYS_LOOKUP", "LANDSCAPE");
                                String fsh_source = connect_db.executeQuery_DB("Lookup", "FSH_LOOKUP_SOURCE_LandscapeGLPremium", "LANDSCAPE");

                                if (db_STG_ACCOUNT_NUMBER.equals("null")) {
                                    SQLResultset = SQLstmt.executeQuery(LandscapeGLPremium_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_CONS_ACCOUNT_NUMBER + "' and LOOKUP_TYPE = 'ACCOUNT_NUMBER'" + fsh_source);
                                    //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_ACCOUNT_NUMBER + "' and LOOKUP_TYPE = 'ACCOUNT_NUMBER' and system = 'LAND' and pattern = 'GLPremium'");
                                    while (SQLResultset.next()) {
                                        db_lookup_accountNumber_meaning = SQLResultset.getString("MEANING");
                                    }
                                    if (db_lookup_accountNumber_meaning.equals("null")) {
                                        String lookup_accountNumber_meaning = ",ACCOUNT_NUMBER lookup," + "LookUp value not found" + "," + db_STG_ACCOUNT_NUMBER + ",Fail";
                                        section1_results.add(lookup_accountNumber_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ACCOUNT_NUMBER lookup" + "," + "LookUp value not found" + "," + db_STG_ACCOUNT_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_accountNumber_meaning != null) {
                                        if (db_lookup_accountNumber_meaning.equals(db_STG_ACCOUNT_NUMBER)) {
                                            String lookup_accountNumber_meaning = ",ACCOUNT_NUMBER lookup," + db_lookup_accountNumber_meaning + "," + db_STG_ACCOUNT_NUMBER + ",Pass";
                                            section1_results.add(lookup_accountNumber_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ACCOUNT_NUMBER lookup" + "," + db_lookup_accountNumber_meaning + "," + db_STG_ACCOUNT_NUMBER + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String lookup_accountNumber_meaning = ",ACCOUNT_NUMBER lookup," + db_lookup_accountNumber_meaning + "," + db_STG_ACCOUNT_NUMBER + ",Fail";
                                            section1_results.add(lookup_accountNumber_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ACCOUNT_NUMBER lookup" + "," + db_lookup_accountNumber_meaning + "," + db_STG_ACCOUNT_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }

                                } else if (db_STG_ACCOUNT_NUMBER != null) {

                                    if (db_CONS_ACCOUNT_NUMBER.equals(db_STG_ACCOUNT_NUMBER)) {
                                        String cons_ACCOUNT_NUMBER = ",ACCOUNT_NUMBER lookup," + db_STG_ACCOUNT_NUMBER + "," + db_CONS_ACCOUNT_NUMBER + ",Pass";
                                        section1_results.add(cons_ACCOUNT_NUMBER);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ACCOUNT_NUMBER lookup" + "," + db_STG_ACCOUNT_NUMBER + "," + db_CONS_ACCOUNT_NUMBER + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String cons_ACCOUNT_NUMBER = ",ACCOUNT_NUMBER lookup," + db_STG_ACCOUNT_NUMBER + "," + db_CONS_ACCOUNT_NUMBER + ",Fail";
                                        section1_results.add(cons_ACCOUNT_NUMBER);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ACCOUNT_NUMBER lookup" + "," + db_STG_ACCOUNT_NUMBER + "," + db_CONS_ACCOUNT_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }


                                //------------------------ UNDERWRITER Validation -----------------
                                db_lookup_underwriter_meaning = "UKI";
                                if (db_STG_UNDERWRITER.equals("null")) {
                                    String lookup_underwriter_meaning = ",UNDERWRITER lookup," + db_lookup_underwriter_meaning + "," + db_STG_UNDERWRITER + ",Fail";
                                    section1_results.add(lookup_underwriter_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",UNDERWRITER lookup" + "," + db_lookup_underwriter_meaning + "," + db_STG_UNDERWRITER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_STG_UNDERWRITER != null) {
                                    String lookup_underwriter_meaning = ",UNDERWRITER lookup," + db_lookup_underwriter_meaning + "," + db_STG_UNDERWRITER + ",Pass";
                                    section1_results.add(lookup_underwriter_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",UNDERWRITER lookup" + "," + db_lookup_underwriter_meaning + "," + db_STG_UNDERWRITER + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);

                                }

                                //------------------------ TAX_REGION Validation -----------------
                                db_lookup_tax_region_meaning = "Multiple";
                                if (db_STG_TAX_REGION.equals("null")) {
                                    String lookup_tax_region_meaning = ",TAX_REGION lookup," + db_lookup_tax_region_meaning + "," + db_STG_TAX_REGION + ",Fail";
                                    section1_results.add(lookup_tax_region_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TAX_REGION lookup" + "," + db_lookup_tax_region_meaning + "," + db_STG_TAX_REGION + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_STG_TAX_REGION != null) {
                                    String lookup_tax_region_meaning = ",TAX_REGION lookup," + db_lookup_tax_region_meaning + "," + db_STG_TAX_REGION + ",Pass";
                                    section1_results.add(lookup_tax_region_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TAX_REGION lookup" + "," + db_lookup_tax_region_meaning + "," + db_STG_TAX_REGION + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                }


                                //------------------------ LINE_OF_BUSINESS Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(LandscapeGLPremium_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_CONS_LINE_OF_BUSINESS + "' and LOOKUP_TYPE = 'LINE_OF_BUSINESS'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_LINE_OF_BUSINESS + "' and LOOKUP_TYPE = 'LINE_OF_BUSINESS' and system = 'LAND' and pattern = 'GLPremium'");
                                while (SQLResultset.next()) {
                                    db_lookup_line_of_business_meaning = SQLResultset.getString("MEANING");
                                }

                                if (db_lookup_line_of_business_meaning.equals("null")) {
                                    String lookup_line_of_business_meaning = ",LINE_OF_BUSINESS lookup," + "LookUp value not found" + "," + db_STG_LINE_OF_BUSINESS + ",Fail";
                                    section1_results.add(lookup_line_of_business_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",LINE_OF_BUSINESS lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_OF_BUSINESS + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_lookup_line_of_business_meaning != null) {
                                    if (db_lookup_line_of_business_meaning.equals(db_STG_LINE_OF_BUSINESS)) {
                                        String lookup_line_of_business_meaning = ",LINE_OF_BUSINESS lookup," + db_lookup_line_of_business_meaning + "," + db_STG_LINE_OF_BUSINESS + ",Pass";
                                        section1_results.add(lookup_line_of_business_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",LINE_OF_BUSINESS lookup" + "," + db_lookup_line_of_business_meaning + "," + db_STG_LINE_OF_BUSINESS + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String lookup_line_of_business_meaning = ",LINE_OF_BUSINESS lookup," + db_lookup_line_of_business_meaning + "," + db_STG_LINE_OF_BUSINESS + ",Fail";
                                        section1_results.add(lookup_line_of_business_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",LINE_OF_BUSINESS lookup" + "," + db_lookup_line_of_business_meaning + "," + db_STG_LINE_OF_BUSINESS + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //------------------------ BRAND Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(LandscapeGLPremium_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_CONS_BRAND + "' and LOOKUP_TYPE = 'BRAND'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_BRAND + "' and LOOKUP_TYPE = 'BRAND' and system = 'LAND' and pattern = 'GLPremium'");
                                while (SQLResultset.next()) {
                                    db_lookup_brand_meaning = SQLResultset.getString("MEANING");
                                }

                                if (db_lookup_brand_meaning.equals("null")) {
                                    String lookup_brand_meaning = ",BRAND lookup," + "LookUp value not found" + "," + db_STG_BRAND + ",Fail";
                                    section1_results.add(lookup_brand_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BRAND lookup" + "," + "LookUp value not found" + "," + db_STG_BRAND + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_lookup_brand_meaning != null) {
                                    if (db_lookup_brand_meaning.equals(db_STG_BRAND)) {
                                        String lookup_brand_meaning = ",BRAND lookup," + db_lookup_brand_meaning + "," + db_STG_BRAND + ",Pass";
                                        section1_results.add(lookup_brand_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BRAND lookup" + "," + db_lookup_brand_meaning + "," + db_STG_BRAND + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String lookup_brand_meaning = ",BRAND lookup," + db_lookup_brand_meaning + "," + db_STG_BRAND + ",Fail";
                                        section1_results.add(lookup_brand_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BRAND lookup" + "," + db_lookup_brand_meaning + "," + db_STG_BRAND + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //------------------------ PRODUCT_TYPE Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(LandscapeGLPremium_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_CONS_PRODUCT_TYPE + "' and LOOKUP_TYPE = 'PRODUCT_TYPE'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT * FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_PRODUCT_TYPE + "' and LOOKUP_TYPE = 'PRODUCT_TYPE' and system = 'LAND' and pattern = 'GLPremium'");
                                while (SQLResultset.next()) {
                                    db_lookup_product_type_meaning = SQLResultset.getString("MEANING");
                                }

                                if (db_lookup_product_type_meaning.equals("null")) {
                                    String lookup_product_type_meaning = ",PRODUCT_TYPE lookup," + "LookUp value not found" + "," + db_STG_PRODUCT_TYPE + ",Fail";
                                    section1_results.add(lookup_product_type_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT_TYPE lookup" + "," + "LookUp value not found" + "," + db_STG_PRODUCT_TYPE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;

                                } else if (db_lookup_product_type_meaning != null) {
                                    if (db_lookup_product_type_meaning.equals(db_STG_PRODUCT_TYPE)) {
                                        String lookup_product_type_meaning = ",PRODUCT_TYPE lookup," + db_lookup_product_type_meaning + "," + db_STG_PRODUCT_TYPE + ",Pass";
                                        section1_results.add(lookup_product_type_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT_TYPE lookup" + "," + db_lookup_product_type_meaning + "," + db_STG_PRODUCT_TYPE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String lookup_product_type_meaning = ",PRODUCT_TYPE lookup," + db_lookup_product_type_meaning + "," + db_STG_PRODUCT_TYPE + ",Fail";
                                        section1_results.add(lookup_product_type_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT_TYPE lookup" + "," + db_lookup_product_type_meaning + "," + db_STG_PRODUCT_TYPE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //------------------------ CHANNEL Validation -----------------
                                //SQLResultset = SQLstmt.executeQuery("SELECT MEANING FROM FSH_ORA_DATA.DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_CHANNEL + "' and LOOKUP_TYPE = 'CHANNEL' and system = 'LAND' and pattern = 'GLPremium'");
                                SQLResultset = SQLstmt.executeQuery(LandscapeGLPremium_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_CONS_CHANNEL + "' and LOOKUP_TYPE = 'CHANNEL' " + fsh_source);
                                while (SQLResultset.next()) {
                                    db_lookupV_channel_meaning = SQLResultset.getString("MEANING");
                                }

                                if (db_lookupV_channel_meaning.equals("null")) {
                                    String lookup_channel_meaning = ",CHANNEL lookup," + "LookUp value not found" + "," + db_STG_CHANNEL + ",Fail";
                                    section1_results.add(lookup_channel_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CHANNEL lookup" + "," + "LookUp value not found" + "," + db_STG_CHANNEL + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_lookupV_channel_meaning != null) {
                                    if (db_lookupV_channel_meaning.equals(db_STG_CHANNEL)) {
                                        String lookup_channel_meaning = ",CHANNEL lookup," + db_lookupV_channel_meaning + "," + db_STG_CHANNEL + ",Pass";
                                        section1_results.add(lookup_channel_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CHANNEL lookup" + "," + db_lookupV_channel_meaning + "," + db_STG_CHANNEL + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String lookup_channel_meaning = ",CHANNEL lookup," + db_lookupV_channel_meaning + "," + db_STG_CHANNEL + ",Fail";
                                        section1_results.add(lookup_channel_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CHANNEL lookup" + "," + db_lookupV_channel_meaning + "," + db_STG_CHANNEL + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //------------------------ UEP_CANCELLATION_FLAG Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(LandscapeGLPremium_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_CONS_BILLING_INSTRUCTION_TYPE + "' and LOOKUP_TYPE = 'BILLING_INSTRUCTION_TYPE'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_BILLING_INSTRUCTION_TYPE + "' and LOOKUP_TYPE = 'BILLING_INSTRUCTION_TYPE' and system = 'LAND' and pattern = 'GLPremium'");
                                while (SQLResultset.next()) {
                                    db_lookup_billing_instruction_type_meaning = SQLResultset.getString("MEANING");
                                }

                                SQLResultset = SQLstmt.executeQuery(LandscapeGLPremium_fsh_lookup + " WHERE LOOKUP_CODE = 'BILLING_INSTRUCTION_TYPE' and LOOKUP_TYPE = 'UEP_CANCELLATION_FLAG'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT * FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'BILLING_INSTRUCTION_TYPE' and LOOKUP_TYPE = 'UEP_CANCELLATION_FLAG' and system = 'LAND' and pattern = 'GLPremium'");
                                while (SQLResultset.next()) {
                                    db_lookup__uepCancellationFlag_meaning = SQLResultset.getString("MEANING");
                                }

                                if(db_lookup_billing_instruction_type_meaning.contains(db_lookup__uepCancellationFlag_meaning)) {
                                    String lookup_uepCancellationFlag = "Y";
                                    if (lookup_uepCancellationFlag.equals(db_STG_UEP_CANCELLATION_FLAG)) {
                                        String lookup_uepCancellationFlag_meaning = ",UEP_CANCELLATION_FLAG lookup," + lookup_uepCancellationFlag + "," + db_STG_UEP_CANCELLATION_FLAG + ",Pass";
                                        section1_results.add(lookup_uepCancellationFlag_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",UEP_CANCELLATION_FLAG lookup" + "," + lookup_uepCancellationFlag + "," + db_STG_UEP_CANCELLATION_FLAG + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String lookup_uepCancellationFlag_meaning = ",UEP_CANCELLATION_FLAG lookup," + lookup_uepCancellationFlag + "," + db_STG_UEP_CANCELLATION_FLAG + ",Fail";
                                        section1_results.add(lookup_uepCancellationFlag_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",UEP_CANCELLATION_FLAG lookup" + "," + lookup_uepCancellationFlag + "," + db_STG_UEP_CANCELLATION_FLAG + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }

                                } else {
                                    String lookup_uepCancellationFlag = "N";
                                    if (lookup_uepCancellationFlag.equals(db_STG_UEP_CANCELLATION_FLAG)) {
                                        String lookup_uepCancellationFlag_meaning = ",UEP_CANCELLATION_FLAG lookup," + lookup_uepCancellationFlag + "," + db_STG_UEP_CANCELLATION_FLAG + ",Pass";
                                        section1_results.add(lookup_uepCancellationFlag_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",UEP_CANCELLATION_FLAG lookup" + "," + lookup_uepCancellationFlag + "," + db_STG_UEP_CANCELLATION_FLAG + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String lookup_uepCancellationFlag_meaning = ",UEP_CANCELLATION_FLAG lookup," + lookup_uepCancellationFlag + "," + db_STG_UEP_CANCELLATION_FLAG + ",Fail";
                                        section1_results.add(lookup_uepCancellationFlag_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",UEP_CANCELLATION_FLAG lookup" + "," + lookup_uepCancellationFlag + "," + db_STG_UEP_CANCELLATION_FLAG + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }


                                /*String uepCancellationFlag = "'Reinstatement', 'Cancellation'";
                                SQLResultset = SQLstmt.executeQuery(LandscapeGLPremium_fsh_lookup + " WHERE LOOKUP_CODE = 'BILLING_INSTRUCTION_TYPE' and LOOKUP_TYPE = 'UEP_CANCELLATION_FLAG'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT * FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'BILLING_INSTRUCTION_TYPE' and LOOKUP_TYPE = 'UEP_CANCELLATION_FLAG' and system = 'LAND' and pattern = 'GLPremium'");
                                while (SQLResultset.next()) {
                                    db_lookup__uepCancellationFlag_meaning = SQLResultset.getString("MEANING");
                                }

                                if (db_lookup__uepCancellationFlag_meaning.equals(uepCancellationFlag)) {
                                    String lookup_uepCancellationFlag = "Y";
                                    if (lookup_uepCancellationFlag.equals(db_STG_UEP_CANCELLATION_FLAG)) {
                                        String lookup_uepCancellationFlag_meaning = ",UEP_CANCELLATION_FLAG lookup," + lookup_uepCancellationFlag + "," + db_STG_UEP_CANCELLATION_FLAG + ",Pass";
                                        section1_results.add(lookup_uepCancellationFlag_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",UEP_CANCELLATION_FLAG lookup" + "," + lookup_uepCancellationFlag + "," + db_STG_UEP_CANCELLATION_FLAG + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String lookup_uepCancellationFlag_meaning = ",UEP_CANCELLATION_FLAG lookup," + lookup_uepCancellationFlag + "," + db_STG_UEP_CANCELLATION_FLAG + ",Fail";
                                        section1_results.add(lookup_uepCancellationFlag_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",UEP_CANCELLATION_FLAG lookup" + "," + lookup_uepCancellationFlag + "," + db_STG_UEP_CANCELLATION_FLAG + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }

                                } else {
                                    String lookup_uepCancellationFlag = "N";
                                    if (lookup_uepCancellationFlag.equals(db_STG_UEP_CANCELLATION_FLAG)) {
                                        String lookup_uepCancellationFlag_meaning = ",UEP_CANCELLATION_FLAG lookup," + lookup_uepCancellationFlag + "," + db_STG_UEP_CANCELLATION_FLAG + ",Pass";
                                        section1_results.add(lookup_uepCancellationFlag_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",UEP_CANCELLATION_FLAG lookup" + "," + lookup_uepCancellationFlag + "," + db_STG_UEP_CANCELLATION_FLAG + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String lookup_uepCancellationFlag_meaning = ",UEP_CANCELLATION_FLAG lookup," + lookup_uepCancellationFlag + "," + db_STG_UEP_CANCELLATION_FLAG + ",Fail";
                                        section1_results.add(lookup_uepCancellationFlag_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",UEP_CANCELLATION_FLAG lookup" + "," + lookup_uepCancellationFlag + "," + db_STG_UEP_CANCELLATION_FLAG + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                *//*String lookup_uepCancellationFlag_meaning = ",UEP_CANCELLATION_FLAG lookup," + lookup_uepCancellationFlag + "," + db_STG_UEP_CANCELLATION_FLAG + ",Fail";
                                section1_results.add(lookup_uepCancellationFlag_meaning);*//*

                                }*/

                                //------------------------ BILLING_INSTRUCTION_TYPE Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(LandscapeGLPremium_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_CONS_BILLING_INSTRUCTION_TYPE + "' and LOOKUP_TYPE = 'BILLING_INSTRUCTION_TYPE'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_BILLING_INSTRUCTION_TYPE + "' and LOOKUP_TYPE = 'BILLING_INSTRUCTION_TYPE' and system = 'LAND' and pattern = 'GLPremium'");
                                while (SQLResultset.next()) {
                                    db_lookup_billing_instruction_type_meaning = SQLResultset.getString("MEANING");
                                }

                                if (db_lookup_billing_instruction_type_meaning.equals("null")) {
                                    String lookup_billing_instruction_type_meaning = ",BILLING_INSTRUCTION_TYPE lookup," + "LookUp value not found" + "," + db_STG_BILLING_INSTRUCTION_TYPE + ",Fail";
                                    section1_results.add(lookup_billing_instruction_type_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BILLING_INSTRUCTION_TYPE lookup" + "," + "LookUp value not found" + "," + db_STG_BILLING_INSTRUCTION_TYPE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else if (db_lookup_billing_instruction_type_meaning != null) {
                                    if (db_lookup_billing_instruction_type_meaning.equals(db_STG_BILLING_INSTRUCTION_TYPE)) {
                                        String lookup_billing_instruction_type_meaning = ",BILLING_INSTRUCTION_TYPE lookup," + db_lookup_billing_instruction_type_meaning + "," + db_STG_BILLING_INSTRUCTION_TYPE + ",Pass";
                                        section1_results.add(lookup_billing_instruction_type_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BILLING_INSTRUCTION_TYPE lookup" + "," + db_lookup_billing_instruction_type_meaning + "," + db_STG_BILLING_INSTRUCTION_TYPE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String lookup_billing_instruction_type_meaning = ",BILLING_INSTRUCTION_TYPE lookup," + db_lookup_billing_instruction_type_meaning + "," + db_STG_BILLING_INSTRUCTION_TYPE + ",Fail";
                                        section1_results.add(lookup_billing_instruction_type_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BILLING_INSTRUCTION_TYPE lookup" + "," + db_lookup_billing_instruction_type_meaning + "," + db_STG_BILLING_INSTRUCTION_TYPE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                            /*//------------------------ TAX_REGION Validation -----------------
                            SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" +db_CONS_TAX_REGION+ "' and LOOKUP_TYPE = 'BRAND' and system = 'LAND' and pattern = 'GLPremium'");
                            while (SQLResultset.next()) {
                                db_lookup_tax_region_meaning = SQLResultset.getString("MEANING");
                            }

                            if (db_lookup_tax_region_meaning.equals("null")) {
                                String lookup_tax_region_meaning = ",TAX_REGION lookup," + "LookUp value not found" + "," + db_STG_TAX_REGION + ",Fail";
                                section1_results.add(lookup_tax_region_meaning);
                            } else if (db_lookup_tax_region_meaning != null) {
                                if (db_lookup_tax_region_meaning.equals(db_STG_TAX_REGION)) {
                                    String lookup_tax_region_meaning = ",TAX_REGION lookup," + db_lookup_tax_region_meaning + "," + db_STG_TAX_REGION + ",Pass";
                                    section1_results.add(lookup_tax_region_meaning);
                                } else {
                                    String lookup_tax_region_meaning = ",TAX_REGION lookup," + db_lookup_tax_region_meaning + "," + db_STG_TAX_REGION + ",Fail";
                                    section1_results.add(lookup_tax_region_meaning);
                                }
                            }*/

                                //------------------------ EVENT_CODE Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(LandscapeGLPremium_fsh_sys_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'EVENT_CODE'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT * FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'EVENT_CODE' and system = 'LAND' and pattern = 'GLPremium'");
                                while (SQLResultset.next()) {
                                    db_lookup_event_code_meaning = SQLResultset.getString("MEANING");
                                }

                                if (db_lookup_event_code_meaning.equals("null")) {
                                    String lookup_event_code_meaning = ",EVENT_CODE lookup," + "LookUp value not found" + "," + db_STG_EVENT_CODE + ",Fail";
                                    section1_results.add(lookup_event_code_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",EVENT_CODE lookup" + "," + "LookUp value not found" + "," + db_STG_EVENT_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;

                                } else if (db_lookup_event_code_meaning != null) {
                                    if (db_lookup_event_code_meaning.equals(db_STG_EVENT_CODE)) {
                                        String lookup_event_code_meaning = ",EVENT_CODE lookup," + db_lookup_event_code_meaning + "," + db_STG_EVENT_CODE + ",Pass";
                                        section1_results.add(lookup_event_code_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",EVENT_CODE lookup" + "," + db_lookup_event_code_meaning + "," + db_STG_EVENT_CODE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else {
                                        String lookup_event_code_meaning = ",EVENT_CODE lookup," + db_lookup_event_code_meaning + "," + db_STG_EVENT_CODE + ",Fail";
                                        section1_results.add(lookup_event_code_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",EVENT_CODE lookup" + "," + db_lookup_event_code_meaning + "," + db_STG_EVENT_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //------------------------ ENTITY_TYPE_CODE Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(LandscapeGLPremium_fsh_sys_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'ENTITY_TYPE_CODE'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'ENTITY_TYPE_CODE' and system = 'LAND' and pattern = 'GLPremium'");
                                while (SQLResultset.next()) {
                                    db_lookup_entity_type_code_meaning = SQLResultset.getString("MEANING");
                                }

                                if (db_lookup_entity_type_code_meaning.equals("null")) {
                                    String lookup_entity_type_code_meaning = ",ENTITY_TYPE_CODE lookup," + "LookUp value not found" + "," + db_STG_ENTITY_TYPE_CODE + ",Fail";
                                    section1_results.add(lookup_entity_type_code_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ENTITY_TYPE_CODE lookup" + "," + "LookUp value not found" + "," + db_STG_ENTITY_TYPE_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_lookup_entity_type_code_meaning != null) {
                                    if (db_lookup_entity_type_code_meaning.equals(db_STG_ENTITY_TYPE_CODE)) {
                                        String lookup_entity_type_code_meaning = ",ENTITY_TYPE_CODE lookup," + db_lookup_entity_type_code_meaning + "," + db_STG_ENTITY_TYPE_CODE + ",Pass";
                                        section1_results.add(lookup_entity_type_code_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ENTITY_TYPE_CODE lookup" + "," + db_lookup_entity_type_code_meaning + "," + db_STG_ENTITY_TYPE_CODE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String lookup_entity_type_code_meaning = ",ENTITY_TYPE_CODE lookup," + db_lookup_entity_type_code_meaning + "," + db_STG_ENTITY_TYPE_CODE + ",Fail";
                                        section1_results.add(lookup_entity_type_code_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ENTITY_TYPE_CODE lookup" + "," + db_lookup_entity_type_code_meaning + "," + db_STG_ENTITY_TYPE_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }


                                //------------------------ SUMMARY_FLAG Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(LandscapeGLPremium_fsh_lookup + " WHERE LOOKUP_CODE = 'LANDGLPremium' and LOOKUP_TYPE = 'SUMMARISE_DATA_FLAG'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT * FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'LANDGLPremium' and LOOKUP_TYPE = 'SUMMARISE_DATA_FLAG' and system = 'LAND' and pattern = 'GLPremium'");
                                while (SQLResultset.next()) {
                                    db_lookup_summary_flag_meaning = SQLResultset.getString("MEANING");
                                }

                                if (db_lookup_summary_flag_meaning.equals("null")) {
                                    String lookup_summary_flag_meaning = ",SUMMARY_FLAG lookup," + "LookUp value not found" + "," + db_STG_SUMMARY_FLAG + ",Fail";
                                    section1_results.add(lookup_summary_flag_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SUMMARY_FLAG lookup" + "," + "LookUp value not found" + "," + db_STG_SUMMARY_FLAG + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_lookup_summary_flag_meaning != null) {
                                    if (db_lookup_summary_flag_meaning.equals(db_STG_SUMMARY_FLAG)) {
                                        String lookup_summary_flag_meaning = ",SUMMARY_FLAG lookup," + db_lookup_summary_flag_meaning + "," + db_STG_SUMMARY_FLAG + ",Pass";
                                        section1_results.add(lookup_summary_flag_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SUMMARY_FLAG lookup" + "," + db_lookup_summary_flag_meaning + "," + db_STG_SUMMARY_FLAG + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String lookup_summary_flag_meaning = ",SUMMARY_FLAG lookup," + db_lookup_summary_flag_meaning + "," + db_STG_SUMMARY_FLAG + ",Fail";
                                        section1_results.add(lookup_summary_flag_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SUMMARY_FLAG lookup" + "," + db_lookup_summary_flag_meaning + "," + db_STG_SUMMARY_FLAG + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }

                                }


                                //------------------------  Line Item variable Declaration -----------------------------


                                //------------------------  Line Item validation -----------------------------
                                int line_count = 0;
                                ArrayList<String> list_line_id = new ArrayList<String>();
                                String LandscapeGLPremium_stglineSqlQuery = connect_db.executeQuery_DB("LandscapeGL", "GLPremium_Stg_line", "LANDSCAPE");
                                SQLResultset = SQLstmt.executeQuery(LandscapeGLPremium_stglineSqlQuery + "WHERE PC_HEADER_ID = '" + db_STG_PC_HEADER_ID + "' ");
                                //SQLResultset = SQLstmt.executeQuery("SELECT * FROM  DLG_FSH_STG_COMM_PC_LINE WHERE  PC_HEADER_ID = '" + db_STG_PC_HEADER_ID + "'");
                                while (SQLResultset.next()) {
                                    list_line_id.add(SQLResultset.getString("PC_LINE_ID"));
                                }

                                for (int i_count = 0; i_count <= list_line_id.size() - 1; i_count++) {
                                    int stg_sub_indent = i_count;
                                    int sub_tag_line = 0;
                                    System.out.println("Line id ---> " + list_line_id.get(i_count));
                                    SQLResultset = SQLstmt.executeQuery(LandscapeGLPremium_stglineSqlQuery + "WHERE PC_HEADER_ID = '" + db_STG_PC_HEADER_ID + "' and PC_LINE_ID = '" + list_line_id.get(i_count) + "' ");
                                    //SQLResultset = SQLstmt.executeQuery("SELECT * FROM  DLG_FSH_STG_COMM_PC_LINE WHERE  PC_HEADER_ID = '" + db_STG_PC_HEADER_ID + "' and PC_LINE_ID = '" + list_line_id.get(i_count) + "'");
                                    while (SQLResultset.next()) {
                                        db_STG_LINE_PC_LINE_ID = SQLResultset.getString("PC_LINE_ID");
                                        db_STG_LINE_PC_HEADER_ID = SQLResultset.getString("PC_HEADER_ID");
                                        db_STG_LINE_PRODUCT = SQLResultset.getString("PRODUCT");
                                        db_STG_LINE_PREMIUM_AMOUNT = SQLResultset.getString("PREMIUM_AMOUNT");
                                        db_STG_LINE_CURRENCY_CODE = SQLResultset.getString("CURRENCY_CODE");
                                        db_STG_LINE_EXCHANGE_RATE = SQLResultset.getString("EXCHANGE_RATE");
                                        db_STG_LINE_EXCHANGE_RATE_TYPE = SQLResultset.getString("EXCHANGE_RATE_TYPE");
                                        db_STG_LINE_BASE_CURRENCY_AMOUNT = SQLResultset.getString("BASE_CURRENCY_AMOUNT");
                                        db_STG_LINE_TAX_RATE = SQLResultset.getString("TAX_RATE");
                                        db_STG_LINE_TAX_TYPE = SQLResultset.getString("TAX_TYPE");
                                        db_STG_LINE_TAX_REGION_LINE = SQLResultset.getString("TAX_REGION_LINE");
                                        db_STG_LINE_FSH_ATTRIBUTE_01 = SQLResultset.getString("FSH_ATTRIBUTE_01");
                                        db_STG_LINE_DAILY_BASE_CURRENCY_AMOUNT = SQLResultset.getString("DAILY_BASE_CURRENCY_AMOUNT");
                                        db_STG_LINE_TOH_ID = SQLResultset.getString("TOH_ID");
                                        db_STG_LINE_TOL_ID = SQLResultset.getString("TOL_ID");
                                        db_STG_LINE_SUMMARY_FLAG = SQLResultset.getString("SUMMARY_FLAG");
                                        db_STG_LINE_STATUS = SQLResultset.getString("STATUS");
                                        db_STG_LINE_BATCH_FKEY = SQLResultset.getString("BATCH_FKEY");
                                        db_STG_LINE_FILE_NAME = SQLResultset.getString("FILE_NAME");

                                        //Validating mandatory fields in consolidation table
                                        //PC_LINE_ID - mandatory validation
                                        if ((db_STG_LINE_PC_LINE_ID == null) && (db_STG_LINE_STATUS != "REVIEW")) {

                                            String stg_header_id = line_mandatoryStg_map_row + "," + db_STG_LINE_PC_LINE_ID + ",LINE PC_LINE_ID," + "LINE PC_LINE_ID : " + db_STG_LINE_PC_LINE_ID + "," + "LINE PC_LINE_ID was not found," + db_STG_LINE_STATUS + "," + "Fail";
                                            section4_results.add(stg_header_id);
                                            line_mandatoryStg_map_row++;
                                        } else {
                                            String stg_header_id = line_mandatoryStg_map_row + "," + db_STG_LINE_PC_LINE_ID + ",LINE PC_LINE_ID," + "LINE PC_LINE_ID : " + db_STG_LINE_PC_LINE_ID + "," + "LINE PC_LINE_ID was found," + db_STG_LINE_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                            line_mandatoryStg_map_row++;
                                        }

                                        //PC_HEADER_ID - mandatory validation
                                        if ((db_STG_LINE_PC_HEADER_ID == null) && (db_STG_LINE_STATUS != "REVIEW")) {

                                            String stg_header_id = "," + ",LINE PC_HEADER_ID," + "LINE PC_HEADER_ID : " + db_STG_LINE_PC_HEADER_ID + "," + "LINE PC_HEADER_ID was not found," + db_STG_LINE_STATUS + "," + "Fail";
                                            section4_results.add(stg_header_id);
                                        } else {
                                            String stg_header_id = "," + ",LINE PC_HEADER_ID," + "LINE PC_HEADER_ID : " + db_STG_LINE_PC_HEADER_ID + "," + "LINE PC_HEADER_ID was found," + db_STG_LINE_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                        }

                                        //PRODUCT - mandatory validation
                                        if ((db_STG_LINE_PRODUCT == null) && (db_STG_LINE_STATUS != "REVIEW")) {

                                            String stg_header_id = "," + ",LINE PRODUCT," + "LINE PRODUCT : " + db_STG_LINE_PRODUCT + "," + "LINE PRODUCT was not found," + db_STG_LINE_STATUS + "," + "Fail";
                                            section4_results.add(stg_header_id);
                                        } else {
                                            String stg_header_id = "," + ",LINE PRODUCT," + "LINE PRODUCT : " + db_STG_LINE_PRODUCT + "," + "LINE PRODUCT was found," + db_STG_LINE_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                        }

                                        //PREMIUM_AMOUNT - mandatory validation
                                        if ((db_STG_LINE_PREMIUM_AMOUNT == null) && (db_STG_LINE_STATUS != "REVIEW")) {

                                            String stg_header_id = "," + ",LINE PREMIUM_AMOUNT," + "LINE PREMIUM_AMOUNT : " + db_STG_LINE_PREMIUM_AMOUNT + "," + "LINE PREMIUM_AMOUNT was not found," + db_STG_LINE_STATUS + "," + "Fail";
                                            section4_results.add(stg_header_id);
                                        } else {
                                            String stg_header_id = "," + ",LINE PREMIUM_AMOUNT," + "LINE PREMIUM_AMOUNT : " + db_STG_LINE_PREMIUM_AMOUNT + "," + "LINE PREMIUM_AMOUNT was found," + db_STG_LINE_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                        }

                                        //CURRENCY_CODE - mandatory validation
                                        if ((db_STG_LINE_CURRENCY_CODE == null) && (db_STG_LINE_STATUS != "REVIEW")) {

                                            String stg_header_id = "," + ",LINE CURRENCY_CODE," + "LINE CURRENCY_CODE : " + db_STG_LINE_CURRENCY_CODE + "," + "LINE CURRENCY_CODE was not found," + db_STG_LINE_STATUS + "," + "Fail";
                                            section4_results.add(stg_header_id);
                                        } else {
                                            String stg_header_id = "," + ",LINE CURRENCY_CODE," + "LINE CURRENCY_CODE : " + db_STG_LINE_CURRENCY_CODE + "," + "LINE CURRENCY_CODE was found," + db_STG_LINE_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                        }

                                        //BASE_CURRENCY_AMOUNT - mandatory validation
                                        if ((db_STG_LINE_BASE_CURRENCY_AMOUNT == null) && (db_STG_LINE_STATUS != "REVIEW")) {

                                            String stg_header_id = "," + ",LINE BASE_CURRENCY_AMOUNT," + "LINE BASE_CURRENCY_AMOUNT : " + db_STG_LINE_BASE_CURRENCY_AMOUNT + "," + "LINE BASE_CURRENCY_AMOUNT was not found," + db_STG_LINE_STATUS + "," + "Fail";
                                            section4_results.add(stg_header_id);
                                        } else {
                                            String stg_header_id = "," + ",LINE BASE_CURRENCY_AMOUNT," + "LINE BASE_CURRENCY_AMOUNT : " + db_STG_LINE_BASE_CURRENCY_AMOUNT + "," + "LINE BASE_CURRENCY_AMOUNT was found," + db_STG_LINE_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                        }

                                        //TAX_REGION_LINE - mandatory validation
                                        if ((db_STG_LINE_TAX_REGION_LINE == null) && (db_STG_LINE_STATUS != "REVIEW")) {

                                            String stg_header_id = "," + ",LINE TAX_REGION_LINE," + "LINE TAX_REGION_LINE : " + db_STG_LINE_TAX_REGION_LINE + "," + "LINE TAX_REGION_LINE was not found," + db_STG_LINE_STATUS + "," + "Fail";
                                            section4_results.add(stg_header_id);
                                        } else {
                                            String stg_header_id = "," + ",LINE TAX_REGION_LINE," + "LINE TAX_REGION_LINE : " + db_STG_LINE_TAX_REGION_LINE + "," + "LINE TAX_REGION_LINE was found," + db_STG_LINE_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                        }


                                        //DAILY_BASE_CURRENCY_AMOUNT - mandatory validation
                                        if ((db_STG_LINE_DAILY_BASE_CURRENCY_AMOUNT == null) && (db_STG_LINE_STATUS != "REVIEW")) {

                                            String stg_header_id = "," + ",LINE DAILY_BASE_CURRENCY_AMOUNT," + "LINE DAILY_BASE_CURRENCY_AMOUNT : " + db_STG_LINE_DAILY_BASE_CURRENCY_AMOUNT + "," + "LINE DAILY_BASE_CURRENCY_AMOUNT was not found," + db_STG_LINE_STATUS + "," + "Fail";
                                            section4_results.add(stg_header_id);
                                        } else {
                                            String stg_header_id = "," + ",LINE DAILY_BASE_CURRENCY_AMOUNT," + "LINE DAILY_BASE_CURRENCY_AMOUNT : " + db_STG_LINE_DAILY_BASE_CURRENCY_AMOUNT + "," + "LINE DAILY_BASE_CURRENCY_AMOUNT was found," + db_STG_LINE_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                        }


                                        //SUMMARY_FLAG - mandatory validation
                                        if ((db_STG_LINE_SUMMARY_FLAG == null) && (db_STG_LINE_STATUS != "REVIEW")) {

                                            String stg_header_id = "," + ",LINE SUMMARY_FLAG," + "LINE SUMMARY_FLAG : " + db_STG_LINE_SUMMARY_FLAG + "," + "LINE SUMMARY_FLAG was not found," + db_STG_LINE_STATUS + "," + "Fail";
                                            section4_results.add(stg_header_id);
                                        } else {
                                            String stg_header_id = "," + ",LINE SUMMARY_FLAG," + "LINE SUMMARY_FLAG : " + db_STG_LINE_SUMMARY_FLAG + "," + "LINE SUMMARY_FLAG was found," + db_STG_LINE_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                        }


                                        //EXCHANGE_RATE - mandatory validation
                                        if (db_STG_LINE_CURRENCY_CODE.equals("GBP")) {
                                            String stg_header_id = "," + ",LINE EXCHANGE_RATE," + "LINE EXCHANGE_RATE : " + db_STG_LINE_EXCHANGE_RATE + "," + "LINE EXCHANGE_RATE is NOT mandatory hence it can be NULL," + db_STG_LINE_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                        } else if ((db_STG_LINE_EXCHANGE_RATE == null) && (db_STG_LINE_STATUS != "REVIEW")) {
                                            String stg_header_id = "," + ",LINE EXCHANGE_RATE," + "LINE EXCHANGE_RATE : " + db_STG_LINE_EXCHANGE_RATE + "," + "LINE EXCHANGE_RATE was not found," + db_STG_LINE_STATUS + "," + "Fail";
                                            section4_results.add(stg_header_id);
                                        } else {
                                            String stg_header_id = "," + ",LINE EXCHANGE_RATE," + "LINE EXCHANGE_RATE : " + db_STG_LINE_EXCHANGE_RATE + "," + "LINE EXCHANGE_RATE was found," + db_STG_LINE_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                        }

                                        //EXCHANGE_RATE_TYPE - mandatory validation
                                        if (db_STG_LINE_CURRENCY_CODE.equals("GBP")) {
                                            String stg_header_id = "," + ",LINE EXCHANGE_RATE_TYPE," + "LINE EXCHANGE_RATE_TYPE : " + db_STG_LINE_EXCHANGE_RATE_TYPE + "," + "LINE EXCHANGE_RATE_TYPE is NOT mandatory hence it can be NULL," + db_STG_LINE_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                        } else if ((db_STG_LINE_EXCHANGE_RATE_TYPE == null) && (db_STG_LINE_STATUS != "REVIEW")) {
                                            String stg_header_id = "," + ",LINE EXCHANGE_RATE_TYPE," + "LINE EXCHANGE_RATE_TYPE : " + db_STG_LINE_EXCHANGE_RATE_TYPE + "," + "LINE EXCHANGE_RATE_TYPE was not found," + db_STG_LINE_STATUS + "," + "Fail";
                                            section4_results.add(stg_header_id);
                                        } else {
                                            String stg_header_id = "," + ",LINE EXCHANGE_RATE_TYPE," + "LINE EXCHANGE_RATE_TYPE : " + db_STG_LINE_EXCHANGE_RATE_TYPE + "," + "LINE EXCHANGE_RATE_TYPE was found," + db_STG_LINE_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                        }


                                        String LandscapeGLPremium_conslineSqlQuery = connect_db.executeQuery_DB("LandscapeGL", "GLPremium_Cons_line", "LANDSCAPE");
                                        SQLResultset = SQLstmt.executeQuery(LandscapeGLPremium_conslineSqlQuery + "WHERE PC_HEADER_ID = '" + db_STG_LINE_PC_HEADER_ID + "' and PC_LINE_ID = '" + list_line_id.get(i_count) + "' ");
                                        //SQLResultset = SQLstmt.executeQuery("SELECT * FROM DLG_FSH_CONS_LAND_PC_LINE WHERE PC_HEADER_ID = '" + db_STG_LINE_PC_HEADER_ID + "' and PC_LINE_ID = '" + list_line_id.get(i_count) + "'  ");
                                        while (SQLResultset.next()) {
                                            db_CONS_LINE_PC_LINE_ID = SQLResultset.getString("PC_LINE_ID");
                                            db_CONS_LINE_PC_HEADER_ID = SQLResultset.getString("PC_HEADER_ID");
                                            db_CONS_LINE_PRODUCT = SQLResultset.getString("PRODUCT");
                                            db_CONS_LINE_PREMIUM_AMOUNT = SQLResultset.getString("PREMIUM_AMOUNT");
                                            db_CONS_LINE_CURRENCY_CODE = SQLResultset.getString("CURRENCY_CODE");
                                            db_CONS_LINE_EXCHANGE_RATE = SQLResultset.getString("EXCHANGE_RATE");
                                            db_CONS_LINE_EXCHANGE_RATE_TYPE = SQLResultset.getString("EXCHANGE_RATE_TYPE");
                                            db_CONS_LINE_BASE_CURRENCY_AMOUNT = SQLResultset.getString("BASE_CURRENCY_AMOUNT");
                                            db_CONS_LINE_TAX_RATE = SQLResultset.getString("TAX_RATE");
                                            db_CONS_LINE_TAX_TYPE = SQLResultset.getString("TAX_TYPE");
                                            db_CONS_LINE_TAX_REGION_LINE = SQLResultset.getString("TAX_REGION_LINE");
                                            db_CONS_LINE_GL_STRING = SQLResultset.getString("GL_STRING");
                                            db_CONS_LINE_BATCH_FKEY = SQLResultset.getString("BATCH_FKEY");
                                            db_CONS_LINE_FILE_NAME = SQLResultset.getString("FILE_NAME");
                                            db_CONS_LINE_STATUS = SQLResultset.getString("STATUS");

                                            //Validating mandatory fields in consolidation table
                                            //PRODUCT - mandatory validation
                                            if ((db_CONS_LINE_PRODUCT == null) && (db_CONS_LINE_STATUS != "REVIEW")) {

                                                String stg_header_id = line_mandatory_map_row + "," + db_CONS_LINE_PC_LINE_ID + ",LINE PRODUCT," + "LINE PRODUCT : " + db_CONS_LINE_PRODUCT + "," + "LINE PRODUCT was not found," + db_CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(stg_header_id);
                                                line_mandatory_map_row++;
                                            } else {
                                                String stg_header_id = line_mandatory_map_row + "," + db_CONS_LINE_PC_LINE_ID + ",LINE PRODUCT," + "LINE PRODUCT : " + db_CONS_LINE_PRODUCT + "," + "LINE PRODUCT was found," + db_CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(stg_header_id);
                                                line_mandatory_map_row++;
                                            }

                                            //PREMIUM_AMOUNT - mandatory validation
                                            if ((db_CONS_LINE_PREMIUM_AMOUNT == null) && (db_CONS_LINE_STATUS != "REVIEW")) {

                                                String stg_header_id = "," + ",LINE PREMIUM_AMOUNT," + "LINE PREMIUM_AMOUNT : " + db_CONS_LINE_PREMIUM_AMOUNT + "," + "LINE PREMIUM_AMOUNT was not found," + db_CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(stg_header_id);
                                            } else {
                                                String stg_header_id = "," + ",LINE PREMIUM_AMOUNT," + "LINE PREMIUM_AMOUNT : " + db_CONS_LINE_PREMIUM_AMOUNT + "," + "LINE PREMIUM_AMOUNT was found," + db_CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(stg_header_id);
                                            }

                                            //CURRENCY_CODE - mandatory validation
                                            if ((db_CONS_LINE_CURRENCY_CODE == null) && (db_CONS_LINE_STATUS != "REVIEW")) {

                                                String stg_header_id = "," + ",LINE CURRENCY_CODE," + "LINE CURRENCY_CODE : " + db_CONS_LINE_CURRENCY_CODE + "," + "LINE CURRENCY_CODE was not found," + db_CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(stg_header_id);
                                            } else {
                                                String stg_header_id = "," + ",LINE CURRENCY_CODE," + "LINE CURRENCY_CODE : " + db_CONS_LINE_CURRENCY_CODE + "," + "LINE CURRENCY_CODE was found," + db_CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(stg_header_id);
                                            }

                                            //EXCHANGE_RATE - mandatory validation
                                            if ((db_CONS_LINE_EXCHANGE_RATE == null) && (db_CONS_LINE_STATUS != "REVIEW")) {

                                                String stg_header_id = "," + ",LINE EXCHANGE_RATE," + "LINE EXCHANGE_RATE : " + db_CONS_LINE_EXCHANGE_RATE + "," + "LINE EXCHANGE_RATE was not found," + db_CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(stg_header_id);
                                            } else {
                                                String stg_header_id = "," + ",LINE EXCHANGE_RATE," + "LINE EXCHANGE_RATE : " + db_CONS_LINE_EXCHANGE_RATE + "," + "LINE EXCHANGE_RATE was found," + db_CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(stg_header_id);
                                            }


                                            //EXCHANGE_RATE_TYPE - mandatory validation
                                            if ((db_CONS_LINE_EXCHANGE_RATE_TYPE == null) && (db_CONS_LINE_STATUS != "REVIEW")) {

                                                String stg_header_id = "," + ",LINE EXCHANGE_RATE_TYPE," + "LINE EXCHANGE_RATE_TYPE : " + db_CONS_LINE_EXCHANGE_RATE_TYPE + "," + "LINE EXCHANGE_RATE_TYPE was not found," + db_CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(stg_header_id);
                                            } else {
                                                String stg_header_id = "," + ",LINE EXCHANGE_RATE_TYPE," + "LINE EXCHANGE_RATE_TYPE : " + db_CONS_LINE_EXCHANGE_RATE_TYPE + "," + "LINE EXCHANGE_RATE_TYPE was found," + db_CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(stg_header_id);
                                            }

                                            //BASE_CURRENCY_AMOUNT - mandatory validation
                                            if ((db_CONS_LINE_BASE_CURRENCY_AMOUNT == null) && (db_CONS_LINE_STATUS != "REVIEW")) {

                                                String stg_header_id = "," + ",LINE BASE_CURRENCY_AMOUNT," + "LINE BASE_CURRENCY_AMOUNT : " + db_CONS_LINE_BASE_CURRENCY_AMOUNT + "," + "LINE BASE_CURRENCY_AMOUNT was not found," + db_CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(stg_header_id);
                                            } else {
                                                String stg_header_id = "," + ",LINE BASE_CURRENCY_AMOUNT," + "LINE BASE_CURRENCY_AMOUNT : " + db_CONS_LINE_BASE_CURRENCY_AMOUNT + "," + "LINE BASE_CURRENCY_AMOUNT was found," + db_CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(stg_header_id);
                                            }


                                            //TAX_REGION_LINE - mandatory validation
                                            if ((db_CONS_LINE_TAX_REGION_LINE == null) && (db_CONS_LINE_STATUS != "REVIEW")) {

                                                String stg_header_id = "," + ",LINE TAX_REGION_LINE," + "LINE TAX_REGION_LINE : " + db_CONS_LINE_TAX_REGION_LINE + "," + "LINE TAX_REGION_LINE was not found," + db_CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(stg_header_id);
                                            } else {
                                                String stg_header_id = "," + ",LINE TAX_REGION_LINE," + "LINE TAX_REGION_LINE : " + db_CONS_LINE_TAX_REGION_LINE + "," + "LINE TAX_REGION_LINE was found," + db_CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(stg_header_id);
                                            }


                                            //GL_STRING - mandatory validation
                                            if ((db_CONS_LINE_GL_STRING == null) && (db_CONS_LINE_STATUS != "REVIEW")) {

                                                String stg_header_id = "," + ",LINE GL_STRING," + "LINE GL_STRING : " + db_CONS_LINE_GL_STRING + "," + "LINE GL_STRING was not found," + db_CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(stg_header_id);
                                            } else {
                                                String stg_header_id = "," + ",LINE GL_STRING," + "LINE GL_STRING : " + db_CONS_LINE_GL_STRING + "," + "LINE GL_STRING was found," + db_CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(stg_header_id);
                                            }

                                            //BATCH_PKEY - mandatory validation
                                            if ((db_CONS_LINE_BATCH_FKEY == null) && (db_CONS_LINE_STATUS != "REVIEW")) {

                                                String stg_header_id = "," + ",LINE BATCH_PKEY," + "LINE BATCH_PKEY : " + db_CONS_LINE_BATCH_FKEY + "," + "LINE BATCH_PKEY was not found," + db_CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(stg_header_id);
                                            } else {
                                                String stg_header_id = "," + ",LINE BATCH_PKEY," + "LINE BATCH_PKEY : " + db_CONS_LINE_BATCH_FKEY + "," + "LINE BATCH_PKEY was found," + db_CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(stg_header_id);
                                            }

                                            //FILE_NAME - mandatory validation
                                            if ((db_CONS_LINE_FILE_NAME == null) && (db_CONS_LINE_STATUS != "REVIEW")) {

                                                String stg_header_id = "," + ",LINE FILE_NAME," + "LINE FILE_NAME : " + db_CONS_LINE_FILE_NAME + "," + "LINE FILE_NAME was not found," + db_CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(stg_header_id);
                                            } else {
                                                String stg_header_id = "," + ",LINE FILE_NAME," + "LINE FILE_NAME : " + db_CONS_LINE_FILE_NAME + "," + "LINE FILE_NAME was found," + db_CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(stg_header_id);
                                            }


                                            String tbl_line = stg_line_map_row + "." + stg_sub_indent;

                                            // Additional variable declaration
                                            String db_STG_LINE_TAX_REGION_LINEModified = "null";

                                            //------------- Validate LINE_ID ----------------
                                            if (db_STG_LINE_PC_LINE_ID.equals(db_CONS_LINE_PC_LINE_ID)) {
                                                String stg_line_pc_line_id = stg_line_map_row + "." + stg_sub_indent + ",LINE LINE_ID," + db_STG_LINE_PC_LINE_ID + "," + db_CONS_LINE_PC_LINE_ID + ",Pass";
                                                section1_results.add(stg_line_pc_line_id);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE LINE_ID" + "," + db_STG_LINE_PC_LINE_ID + "," + db_CONS_LINE_PC_LINE_ID + ",Pass" + "," + load_dateFormat + "," + db_file_name;
                                                section2_results_tbl.add(tbl_header_id);
                                                stg_sub_indent++;
                                            } else {
                                                String stg_line_pc_line_id = stg_line_map_row + "." + stg_sub_indent + ",LINE LINE_ID," + db_STG_LINE_PC_LINE_ID + "," + db_CONS_LINE_PC_LINE_ID + ",Fail";
                                                section1_results.add(stg_line_pc_line_id);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE LINE_ID" + "," + db_STG_LINE_PC_LINE_ID + "," + db_CONS_LINE_PC_LINE_ID + ",Fail" + "," + load_dateFormat + "," + db_file_name;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                                stg_sub_indent++;
                                            }

                                            //------------- Validate Line HEADER_ID ----------------
                                            if (db_STG_LINE_PC_HEADER_ID.equals(db_CONS_LINE_PC_HEADER_ID)) {
                                                String stg_line_pc_header_id = ",LINE HEADER_ID," + db_STG_LINE_PC_HEADER_ID + "," + db_CONS_LINE_PC_HEADER_ID + ",Pass";
                                                section1_results.add(stg_line_pc_header_id);
                                                String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE HEADER_ID" + "," + db_STG_LINE_PC_HEADER_ID + "," + db_CONS_LINE_PC_HEADER_ID + ",Pass" + "," + load_date + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_line_pc_header_id);
                                            } else {
                                                String stg_line_pc_header_id = ",LINE HEADER_ID," + db_STG_LINE_PC_HEADER_ID + "," + db_CONS_LINE_PC_HEADER_ID + ",Fail";
                                                section1_results.add(stg_line_pc_header_id);
                                                String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE HEADER_ID" + "," + db_STG_LINE_PC_HEADER_ID + "," + db_CONS_LINE_PC_HEADER_ID + ",Fail" + "," + load_date + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_line_pc_header_id);
                                                CONS_flag++;
                                            }

                                        /*//------------- Validate Line HEADER_ID ----------------
                                        if (db_STG_LINE_PC_HEADER_ID.equals(db_CONS_LINE_PC_HEADER_ID)) {
                                            String stg_line_pc_header_id = stg_line_map_row + "." + stg_sub_indent +",LINE HEADER_ID," + db_STG_LINE_PC_HEADER_ID + "," + db_CONS_LINE_PC_HEADER_ID + ",Pass";
                                            section1_results.add(stg_line_pc_header_id);
                                            //stg_sub_indent++;
                                        } else {
                                            String stg_line_pc_header_id = stg_line_map_row + "." + stg_sub_indent +",LINE HEADER_ID," + db_STG_LINE_PC_HEADER_ID + "," + db_CONS_LINE_PC_HEADER_ID + ",Fail";
                                            section1_results.add(stg_line_pc_header_id);
                                            //stg_sub_indent++;
                                        }*/

                                            //------------- Validate LINE PRODUCT ----------------
                                            if ((db_STG_LINE_STATUS != null) && (db_CONS_LINE_STATUS != null)) {
                                                if (db_STG_LINE_STATUS.equals(db_CONS_LINE_STATUS)) {
                                                    String stg_line_status = ",LINE STATUS," + db_STG_LINE_STATUS + "," + db_CONS_LINE_STATUS + ",Pass";
                                                    section1_results.add(stg_line_status);
                                                    String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE STATUS" + "," + db_STG_LINE_STATUS + "," + db_CONS_LINE_STATUS + ",Pass" + "," + load_date + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_line_pc_header_id);
                                                } else {
                                                    String stg_line_status = ",LINE STATUS," + db_STG_LINE_STATUS + "," + db_CONS_LINE_STATUS + ",Fail";
                                                    section1_results.add(stg_line_status);
                                                    String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE STATUS" + "," + db_STG_LINE_STATUS + "," + db_CONS_LINE_STATUS + ",Fail" + "," + load_date + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_line_pc_header_id);
                                                    CONS_flag++;
                                                }
                                            }

                                            //------------- Validate LINE PRODUCT ----------------
                                            if ((db_STG_LINE_PRODUCT != null) && (db_CONS_LINE_PRODUCT != null)) {
                                                if (db_STG_LINE_PRODUCT.equals(db_CONS_LINE_PRODUCT)) {
                                                    String stg_line_product = ",LINE PRODUCT," + db_STG_LINE_PRODUCT + "," + db_CONS_LINE_PRODUCT + ",Pass";
                                                    section1_results.add(stg_line_product);
                                                    String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE PRODUCT" + "," + db_STG_LINE_PRODUCT + "," + db_CONS_LINE_PRODUCT + ",Pass" + "," + load_date + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_line_pc_header_id);
                                                } else {
                                                    String stg_line_product = ",LINE PRODUCT," + db_STG_LINE_PRODUCT + "," + db_CONS_LINE_PRODUCT + ",Fail";
                                                    section1_results.add(stg_line_product);
                                                    String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE PRODUCT" + "," + db_STG_LINE_PRODUCT + "," + db_CONS_LINE_PRODUCT + ",Fail" + "," + load_date + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_line_pc_header_id);
                                                    CONS_flag++;
                                                }
                                            }

                                            //------------- Validate LINE PREMIUM_AMOUNT ----------------
                                            if (db_STG_LINE_PREMIUM_AMOUNT.equals(db_CONS_LINE_PREMIUM_AMOUNT)) {
                                                String stg_line_product_amount = ",LINE PREMIUM_AMOUNT," + db_STG_LINE_PREMIUM_AMOUNT + "," + db_CONS_LINE_PREMIUM_AMOUNT + ",Pass";
                                                section1_results.add(stg_line_product_amount);
                                                String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE PREMIUM_AMOUNT" + "," + db_STG_LINE_PREMIUM_AMOUNT + "," + db_CONS_LINE_PREMIUM_AMOUNT + ",Fail" + "," + load_date + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_line_pc_header_id);
                                            } else {
                                                String stg_line_product_amount = ",LINE PREMIUM_AMOUNT," + db_STG_LINE_PREMIUM_AMOUNT + "," + db_CONS_LINE_PREMIUM_AMOUNT + ",Fail";
                                                section1_results.add(stg_line_product_amount);
                                                String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE PREMIUM_AMOUNT" + "," + db_STG_LINE_PREMIUM_AMOUNT + "," + db_CONS_LINE_PREMIUM_AMOUNT + ",Fail" + "," + load_date + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_line_pc_header_id);
                                                CONS_flag++;
                                            }

                                            //------------- Validate Line CURRENCY_CODE ----------------
                                            if ((db_STG_LINE_CURRENCY_CODE != null) && (db_CONS_LINE_CURRENCY_CODE != null)) {
                                                if (db_STG_LINE_CURRENCY_CODE.equals(db_CONS_LINE_CURRENCY_CODE)) {
                                                    String stg_line_currency_code = ",LINE CURRENCY_CODE," + db_STG_LINE_CURRENCY_CODE + "," + db_CONS_LINE_CURRENCY_CODE + ",Pass";
                                                    section1_results.add(stg_line_currency_code);
                                                    String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE CURRENCY_CODE" + "," + db_STG_LINE_CURRENCY_CODE + "," + db_CONS_LINE_CURRENCY_CODE + ",Pass" + "," + load_date + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_line_pc_header_id);
                                                } else {
                                                    String stg_line_currency_code = ",LINE CURRENCY_CODE," + db_STG_LINE_CURRENCY_CODE + "," + db_CONS_LINE_CURRENCY_CODE + ",Fail";
                                                    section1_results.add(stg_line_currency_code);
                                                    String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE CURRENCY_CODE" + "," + db_STG_LINE_CURRENCY_CODE + "," + db_CONS_LINE_CURRENCY_CODE + ",Fail" + "," + load_date + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_line_pc_header_id);
                                                    CONS_flag++;
                                                }
                                            }

                                            //------------- Validate Line EXCHANGE_RATE ----------------
                                            if (db_STG_LINE_EXCHANGE_RATE.equals(db_CONS_LINE_EXCHANGE_RATE)) {
                                                String stg_line_exchange_rate = ",LINE EXCHANGE_RATE," + db_STG_LINE_EXCHANGE_RATE + "," + db_CONS_LINE_EXCHANGE_RATE + ",Pass";
                                                section1_results.add(stg_line_exchange_rate);
                                                String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE EXCHANGE_RATE" + "," + db_STG_LINE_EXCHANGE_RATE + "," + db_CONS_LINE_EXCHANGE_RATE + ",Pass" + "," + load_date + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_line_pc_header_id);
                                            } else {
                                                String stg_line_exchange_rate = ",LINE EXCHANGE_RATE," + db_STG_LINE_EXCHANGE_RATE + "," + db_CONS_LINE_EXCHANGE_RATE + ",Fail";
                                                section1_results.add(stg_line_exchange_rate);
                                                String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE EXCHANGE_RATE" + "," + db_STG_LINE_EXCHANGE_RATE + "," + db_CONS_LINE_EXCHANGE_RATE + ",Fail" + "," + load_date + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_line_pc_header_id);
                                                CONS_flag++;
                                            }


                                            //------------- Validate EXCHANGE_RATE_TYPE ----------------
                                            if ((db_STG_LINE_EXCHANGE_RATE_TYPE != null) && (db_CONS_LINE_EXCHANGE_RATE_TYPE != null)) {
                                                if (db_STG_LINE_EXCHANGE_RATE_TYPE.equals(db_CONS_LINE_EXCHANGE_RATE_TYPE)) {
                                                    String stg_line_exchange_rate_type = ",LINE_EXCHANGE_RATE_TYPE," + db_STG_LINE_EXCHANGE_RATE_TYPE + "," + db_CONS_LINE_EXCHANGE_RATE_TYPE + ",Pass";
                                                    section1_results.add(stg_line_exchange_rate_type);
                                                    String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_EXCHANGE_RATE_TYPE" + "," + db_STG_LINE_EXCHANGE_RATE_TYPE + "," + db_CONS_LINE_EXCHANGE_RATE_TYPE + ",Pass" + "," + load_date + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_line_pc_header_id);
                                                } else {
                                                    String stg_line_exchange_rate_type = ",LINE_EXCHANGE_RATE_TYPE," + db_STG_LINE_EXCHANGE_RATE_TYPE + "," + db_CONS_LINE_EXCHANGE_RATE_TYPE + ",Fail";
                                                    section1_results.add(stg_line_exchange_rate_type);
                                                    String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_EXCHANGE_RATE_TYPE" + "," + db_STG_LINE_EXCHANGE_RATE_TYPE + "," + db_CONS_LINE_EXCHANGE_RATE_TYPE + ",Fail" + "," + load_date + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_line_pc_header_id);
                                                    CONS_flag++;
                                                }
                                            }

                                            //------------- Validate LINE BASE_CURRENCY_AMOUNT ----------------
                                            if (db_STG_LINE_BASE_CURRENCY_AMOUNT.equals(db_CONS_LINE_BASE_CURRENCY_AMOUNT)) {
                                                String stg_line_base_currency_amount = ",LINE BASE_CURRENCY_AMOUNT," + db_STG_LINE_BASE_CURRENCY_AMOUNT + "," + db_CONS_LINE_BASE_CURRENCY_AMOUNT + ",Pass";
                                                section1_results.add(stg_line_base_currency_amount);
                                                String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE BASE_CURRENCY_AMOUNT" + "," + db_STG_LINE_BASE_CURRENCY_AMOUNT + "," + db_CONS_LINE_BASE_CURRENCY_AMOUNT + ",Pass" + "," + load_date + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_line_pc_header_id);
                                            } else {
                                                String stg_line_base_currency_amount = ",LINE BASE_CURRENCY_AMOUNT," + db_STG_LINE_BASE_CURRENCY_AMOUNT + "," + db_CONS_LINE_BASE_CURRENCY_AMOUNT + ",Fail";
                                                section1_results.add(stg_line_base_currency_amount);
                                                String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE BASE_CURRENCY_AMOUNT" + "," + db_STG_LINE_BASE_CURRENCY_AMOUNT + "," + db_CONS_LINE_BASE_CURRENCY_AMOUNT + ",Fail" + "," + load_date + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_line_pc_header_id);
                                                CONS_flag++;
                                            }

                                            //------------- Validate LINE FSH_ATTRIBUTE_01 ----------------
                                            if (db_STG_LINE_FSH_ATTRIBUTE_01.equals(db_CONS_LINE_GL_STRING)) {
                                                String stg_line_fsh_attribute_01 = ",LINE FSH_ATTRIBUTE_01," + db_STG_LINE_FSH_ATTRIBUTE_01 + "," + db_CONS_LINE_GL_STRING + ",Pass";
                                                section1_results.add(stg_line_fsh_attribute_01);
                                                String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE FSH_ATTRIBUTE_01" + "," + db_STG_LINE_FSH_ATTRIBUTE_01 + "," + db_CONS_LINE_GL_STRING + ",Pass" + "," + load_date + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_line_pc_header_id);
                                            } else {
                                                String stg_line_fsh_attribute_01 = ",LINE FSH_ATTRIBUTE_01," + db_STG_LINE_FSH_ATTRIBUTE_01 + "," + db_CONS_LINE_GL_STRING + ",Fail";
                                                section1_results.add(stg_line_fsh_attribute_01);
                                                String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE FSH_ATTRIBUTE_01" + "," + db_STG_LINE_FSH_ATTRIBUTE_01 + "," + db_CONS_LINE_GL_STRING + ",Fail" + "," + load_date + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_line_pc_header_id);
                                                CONS_flag++;
                                            }

                                            //------------- Validate LINE TAX_REGION_LINE ----------------
                                            if (db_CONS_LINE_TAX_REGION_LINE.startsWith("IM")) {
                                                db_STG_LINE_TAX_REGION_LINEModified = "Isle of Man";
                                            } else if (db_CONS_LINE_TAX_REGION_LINE.startsWith("JE")) {
                                                db_STG_LINE_TAX_REGION_LINEModified = "Jersey";
                                            } else if (db_CONS_LINE_TAX_REGION_LINE.startsWith("GY")) {
                                                db_STG_LINE_TAX_REGION_LINEModified = "Guernsey";
                                            } else {
                                                db_STG_LINE_TAX_REGION_LINEModified = "UK Mainland";
                                                //String stg_line_TAX_REGION_LINE = ",LINE TAX_REGION_LINE," + db_STG_LINE_TAX_REGION_LINEModified + "," + db_STG_LINE_TAX_REGION_LINE + ",Pass";
                                                //section1_results.add(stg_line_TAX_REGION_LINE);
                                            }
                                            if (db_STG_LINE_TAX_REGION_LINEModified.equals(db_STG_LINE_TAX_REGION_LINE)) {
                                                String stg_line_TAX_REGION_LINE = ",LINE TAX_REGION_LINE," + db_STG_LINE_TAX_REGION_LINEModified + "," + db_STG_LINE_TAX_REGION_LINE + ",Pass";
                                                section1_results.add(stg_line_TAX_REGION_LINE);
                                                String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE TAX_REGION_LINE" + "," + db_STG_LINE_TAX_REGION_LINEModified + "," + db_STG_LINE_TAX_REGION_LINE + ",Pass" + "," + load_date + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_line_pc_header_id);
                                            } else {
                                                String stg_line_TAX_REGION_LINE = ",LINE TAX_REGION_LINE," + db_STG_LINE_TAX_REGION_LINEModified + "," + db_STG_LINE_TAX_REGION_LINE + ",Fail";
                                                section1_results.add(stg_line_TAX_REGION_LINE);
                                                String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE TAX_REGION_LINE" + "," + db_STG_LINE_TAX_REGION_LINEModified + "," + db_STG_LINE_TAX_REGION_LINE + ",Fail" + "," + load_date + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_line_pc_header_id);
                                                CONS_flag++;
                                            }

                                            //------------- Validate LINE DAILY_BASE_CURRENCY_AMOUNT ----------------
                                            //double roundOff_LINE_DAILY_BASE_CURRENCY = 0;

                                            double db_STG_LINE_DAILY_BASE_CURRENCY_AMOUNTModified = Double.parseDouble(db_STG_LINE_DAILY_BASE_CURRENCY_AMOUNT);
                                            double round_db_STG_LINE_DAILY_BASE_CURRENCY_AMOUNT = Math.round(db_STG_LINE_DAILY_BASE_CURRENCY_AMOUNTModified * 10000) / 10000.0;

                                            DecimalFormat df1 = new DecimalFormat("#.#");
                                            df1.setRoundingMode(RoundingMode.FLOOR);
                                            double roundOff_db_STG_LINE_DAILY_BASE_CURRENCY_AMOUNT = new Double(df1.format(round_db_STG_LINE_DAILY_BASE_CURRENCY_AMOUNT));
                                            System.out.println(roundOff_db_STG_LINE_DAILY_BASE_CURRENCY_AMOUNT);


                                            String db_STG_OFF_RISK_DATETRIM = db_STG_OFF_RISK_DATE.substring(0, 10);
                                            String db_STG_ON_RISK_DATETRIM = db_STG_ON_RISK_DATE.substring(0, 10);
                                            DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
                                            java.util.Date conDateFrom = df.parse(db_STG_OFF_RISK_DATETRIM);
                                            java.util.Date conDateTo = df.parse(db_STG_ON_RISK_DATETRIM);

                                        /*Date conDateFrom = df.parse(db_STG_OFF_RISK_DATETRIM);
                                        Date conDateTo = df.parse(db_STG_ON_RISK_DATETRIM);*/

                                            long diff = conDateFrom.getTime() - conDateTo.getTime();
                                            int diffDays = (int) (diff / (1000 * 60 * 60 * 24));
                                            double diffDaysPlusOne = diffDays + 1;


                                            //System.out.println("days---------" + diffDaysPlusOne);
                                            if (db_STG_LINE_BASE_CURRENCY_AMOUNT.contains("-")) {
                                                double icalc = Double.parseDouble(db_STG_LINE_BASE_CURRENCY_AMOUNT);
                                                double LINE_DAILY_BASE_CURRENCY = (icalc / diffDaysPlusOne);
                                                double round_LINE_DAILY_BASE_CURRENCY = Math.round(LINE_DAILY_BASE_CURRENCY * 10000) / 10000.0;

                                                DecimalFormat df2 = new DecimalFormat("#.#");
                                                df2.setRoundingMode(RoundingMode.FLOOR);
                                                double roundOff_LINE_DAILY_BASE_CURRENCY = new Double(df2.format(round_LINE_DAILY_BASE_CURRENCY));
                                                System.out.println(roundOff_LINE_DAILY_BASE_CURRENCY);
                                                if (roundOff_db_STG_LINE_DAILY_BASE_CURRENCY_AMOUNT == (roundOff_LINE_DAILY_BASE_CURRENCY)) {
                                                    String stg_line_DAILY_BASE_CURRENCY_AMOUNT = ",LINE DAILY_BASE_CURRENCY_AMOUNT," + roundOff_db_STG_LINE_DAILY_BASE_CURRENCY_AMOUNT + "," + roundOff_LINE_DAILY_BASE_CURRENCY + ",Pass";
                                                    section1_results.add(stg_line_DAILY_BASE_CURRENCY_AMOUNT);
                                                    String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE DAILY_BASE_CURRENCY_AMOUNT" + "," + roundOff_db_STG_LINE_DAILY_BASE_CURRENCY_AMOUNT + "," + roundOff_LINE_DAILY_BASE_CURRENCY + ",Pass" + "," + load_date + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_line_pc_header_id);
                                                } else {
                                                    String stg_line_DAILY_BASE_CURRENCY_AMOUNT = ",LINE DAILY_BASE_CURRENCY_AMOUNT," + roundOff_db_STG_LINE_DAILY_BASE_CURRENCY_AMOUNT + "," + roundOff_LINE_DAILY_BASE_CURRENCY + ",Fail";
                                                    section1_results.add(stg_line_DAILY_BASE_CURRENCY_AMOUNT);
                                                    String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE DAILY_BASE_CURRENCY_AMOUNT" + "," + roundOff_db_STG_LINE_DAILY_BASE_CURRENCY_AMOUNT + "," + roundOff_LINE_DAILY_BASE_CURRENCY + ",Fail" + "," + load_date + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_line_pc_header_id);
                                                    CONS_flag++;
                                                }

                                            } else {
                                                double icalc = Double.parseDouble(db_STG_LINE_BASE_CURRENCY_AMOUNT);
                                                double LINE_DAILY_BASE_CURRENCY = (icalc / diffDaysPlusOne);
                                                double round_LINE_DAILY_BASE_CURRENCY = Math.round(LINE_DAILY_BASE_CURRENCY * 10000) / 10000.0;

                                                DecimalFormat df2 = new DecimalFormat("#.#");
                                                df2.setRoundingMode(RoundingMode.FLOOR);
                                                double roundOff_LINE_DAILY_BASE_CURRENCY = new Double(df2.format(round_LINE_DAILY_BASE_CURRENCY));
                                                System.out.println(roundOff_LINE_DAILY_BASE_CURRENCY);
                                                if (roundOff_db_STG_LINE_DAILY_BASE_CURRENCY_AMOUNT == (roundOff_LINE_DAILY_BASE_CURRENCY)) {
                                                    String stg_line_DAILY_BASE_CURRENCY_AMOUNT = ",LINE DAILY_BASE_CURRENCY_AMOUNT," + roundOff_db_STG_LINE_DAILY_BASE_CURRENCY_AMOUNT + "," + roundOff_LINE_DAILY_BASE_CURRENCY + ",Pass";
                                                    section1_results.add(stg_line_DAILY_BASE_CURRENCY_AMOUNT);
                                                    String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE DAILY_BASE_CURRENCY_AMOUNT" + "," + roundOff_db_STG_LINE_DAILY_BASE_CURRENCY_AMOUNT + "," + roundOff_LINE_DAILY_BASE_CURRENCY + ",Pass" + "," + load_date + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_line_pc_header_id);
                                                } else {
                                                    String stg_line_DAILY_BASE_CURRENCY_AMOUNT = ",LINE DAILY_BASE_CURRENCY_AMOUNT," + roundOff_db_STG_LINE_DAILY_BASE_CURRENCY_AMOUNT + "," + roundOff_LINE_DAILY_BASE_CURRENCY + ",Fail";
                                                    section1_results.add(stg_line_DAILY_BASE_CURRENCY_AMOUNT);
                                                    String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE DAILY_BASE_CURRENCY_AMOUNT" + "," + roundOff_db_STG_LINE_DAILY_BASE_CURRENCY_AMOUNT + "," + roundOff_LINE_DAILY_BASE_CURRENCY + ",Fail" + "," + load_date + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_line_pc_header_id);
                                                    CONS_flag++;
                                                }

                                            }
                                            //double icalc =Double.parseDouble(db_STG_LINE_BASE_CURRENCY_AMOUNT);
                                            //double LINE_DAILY_BASE_CURRENCY = (icalc / diffDaysPlusOne);
                                            //System.out.println(LINE_DAILY_BASE_CURRENCY);
                                        /*double round_LINE_DAILY_BASE_CURRENCY = Math.round(LINE_DAILY_BASE_CURRENCY * 10000)/10000.0;

                                        DecimalFormat df2 = new DecimalFormat("#.##");
                                        df2.setRoundingMode(RoundingMode.FLOOR);
                                        double roundOff_LINE_DAILY_BASE_CURRENCY = new Double(df2.format(round_LINE_DAILY_BASE_CURRENCY));
                                        System.out.println(roundOff_LINE_DAILY_BASE_CURRENCY);*/


                                            //------------- Validate LINE_BATCH_FKEY ----------------
                                            if (db_STG_LINE_BATCH_FKEY.equals(db_CONS_LINE_BATCH_FKEY)) {
                                                String stg_line_batch_fkey = ",LINE_BATCH_FKEY," + db_STG_LINE_BATCH_FKEY + "," + db_CONS_LINE_BATCH_FKEY + ",Pass";
                                                section1_results.add(stg_line_batch_fkey);
                                                String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_BATCH_FKEY" + "," + db_STG_LINE_BATCH_FKEY + "," + db_CONS_LINE_BATCH_FKEY + ",Pass" + "," + load_date + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_line_pc_header_id);
                                            } else {
                                                String stg_line_batch_fkey = ",LINE_BATCH_FKEY," + db_STG_LINE_BATCH_FKEY + "," + db_CONS_LINE_BATCH_FKEY + ",Fail";
                                                section1_results.add(stg_line_batch_fkey);
                                                String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_BATCH_FKEY" + "," + db_STG_LINE_BATCH_FKEY + "," + db_CONS_LINE_BATCH_FKEY + ",Fail" + "," + load_date + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_line_pc_header_id);
                                                CONS_flag++;
                                            }

                                            //------------- Validate LINE_FILE_NAME ----------------
                                            if (db_STG_LINE_FILE_NAME.equals(db_CONS_LINE_FILE_NAME)) {
                                                String stg_line_file_name = ",LINE_FILE_NAME," + db_STG_LINE_FILE_NAME + "," + db_CONS_LINE_FILE_NAME + ",Pass";
                                                section1_results.add(stg_line_file_name);
                                                String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_FILE_NAME" + "," + db_STG_LINE_FILE_NAME + "," + db_CONS_LINE_FILE_NAME + ",Pass" + "," + load_date + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_line_pc_header_id);
                                            } else {
                                                String stg_line_file_name = ",LINE_FILE_NAME," + db_STG_LINE_FILE_NAME + "," + db_CONS_LINE_FILE_NAME + ",Fail";
                                                section1_results.add(stg_line_file_name);
                                                String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_FILE_NAME" + "," + db_STG_LINE_FILE_NAME + "," + db_CONS_LINE_FILE_NAME + ",Fail" + "," + load_date + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_line_pc_header_id);
                                                CONS_flag++;
                                            }

                                            //----------------------- LINE STANDARDISATION start here -----------------------------
                                            String db_lookup_line_summary_flag_meaning = "null";
                                            String db_lookup_line_tax_rate_meaning = "null";
                                            String db_lookup_line_tax_type_meaning = "null";


                                            //---------------- Validate LINE SUMMARY_FLAG -----------------------
                                            SQLResultset = SQLstmt.executeQuery(LandscapeGLPremium_fsh_lookup + " WHERE LOOKUP_CODE = 'LANDGLPremium' and LOOKUP_TYPE = 'SUMMARISE_DATA_FLAG'" + fsh_source);
                                            //SQLResultset = SQLstmt.executeQuery("SELECT * FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'LANDGLPremium' and LOOKUP_TYPE = 'SUMMARISE_DATA_FLAG' and system = 'LAND' and pattern = 'GLPremium'");
                                            while (SQLResultset.next()) {
                                                db_lookup_line_summary_flag_meaning = SQLResultset.getString("MEANING");
                                            }
                                            if (db_lookup_line_summary_flag_meaning.equals("null")) {
                                                String lookup_summary_flag_meaning = ",LINE SUMMARY_FLAG lookup," + "LookUp value not found" + "," + db_STG_LINE_SUMMARY_FLAG + ",Fail";
                                                section1_results.add(lookup_summary_flag_meaning);
                                                String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SUMMARY_FLAG lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_SUMMARY_FLAG + ",Fail" + "," + load_date + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_line_pc_header_id);
                                                CONS_flag++;
                                            } else if (db_lookup_line_summary_flag_meaning != null) {
                                                if (db_lookup_line_summary_flag_meaning.equals(db_STG_LINE_SUMMARY_FLAG)) {
                                                    String lookup_summary_flag_meaning = ",LINE SUMMARY_FLAG lookup," + db_lookup_line_summary_flag_meaning + "," + db_STG_LINE_SUMMARY_FLAG + ",Pass";
                                                    section1_results.add(lookup_summary_flag_meaning);
                                                    String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SUMMARY_FLAG lookup" + "," + db_lookup_line_summary_flag_meaning + "," + db_STG_LINE_SUMMARY_FLAG + ",Pass" + "," + load_date + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_line_pc_header_id);
                                                } else {
                                                    String lookup_summary_flag_meaning = ",LINE SUMMARY_FLAG lookup," + db_lookup_line_summary_flag_meaning + "," + db_STG_LINE_SUMMARY_FLAG + ",Fail";
                                                    section1_results.add(lookup_summary_flag_meaning);
                                                    String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SUMMARY_FLAG lookup" + "," + db_lookup_line_summary_flag_meaning + "," + db_STG_LINE_SUMMARY_FLAG + ",Fail" + "," + load_date + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_line_pc_header_id);
                                                    CONS_flag++;
                                                }
                                            }

                                            //---------------- Validate LINE_TAX_RATE -----------------------
                                            if (db_STG_SUMMARY_FLAG.equals("Y")) {
                                                SQLResultset = SQLstmt.executeQuery(LandscapeGLPremium_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'TAX_RATE'" + fsh_source);
                                                //SQLResultset = SQLstmt.executeQuery("SELECT * FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'TAX_RATE' and system = 'LAND' and pattern = 'GLPremium'");
                                                while (SQLResultset.next()) {
                                                    db_lookup_line_tax_rate_meaning = SQLResultset.getString("MEANING");
                                                }
                                                if (db_lookup_line_tax_rate_meaning.equals("null")) {
                                                    String lookup_line_tax_rate_meaning = ",LINE_TAX_RATE lookup," + "LookUp value not found" + "," + db_STG_LINE_TAX_RATE + ",Fail";
                                                    section1_results.add(lookup_line_tax_rate_meaning);
                                                    String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_TAX_RATE lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_TAX_RATE + ",Fail" + "," + load_date + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_line_pc_header_id);
                                                    CONS_flag++;
                                                } else if (db_lookup_line_tax_rate_meaning != null) {
                                                    if (db_lookup_line_tax_rate_meaning.equals(db_STG_LINE_TAX_RATE)) {
                                                        String lookup_line_tax_rate_meaning = ",LINE_TAX_RATE lookup," + db_lookup_line_tax_rate_meaning + "," + db_STG_LINE_TAX_RATE + ",Pass";
                                                        section1_results.add(lookup_line_tax_rate_meaning);
                                                        String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_TAX_RATE lookup" + "," + db_lookup_line_tax_rate_meaning + "," + db_STG_LINE_TAX_RATE + ",Pass" + "," + load_date + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                        section2_results_tbl.add(tbl_line_pc_header_id);
                                                    } else {
                                                        String lookup_line_tax_rate_meaning = ",LINE_TAX_RATE lookup," + db_lookup_line_tax_rate_meaning + "," + db_STG_LINE_TAX_RATE + ",Fail";
                                                        section1_results.add(lookup_line_tax_rate_meaning);
                                                        String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_TAX_RATE lookup" + "," + db_lookup_line_tax_rate_meaning + "," + db_STG_LINE_TAX_RATE + ",Fail" + "," + load_date + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                        section2_results_tbl.add(tbl_line_pc_header_id);
                                                        CONS_flag++;
                                                    }
                                                }
                                            } else {
                                                if (db_STG_LINE_TAX_RATE != null && db_CONS_LINE_TAX_RATE != null) {
                                                    if (db_STG_LINE_TAX_RATE.equals(db_CONS_LINE_TAX_RATE)) {
                                                        String stg_line_tax_rate = ",LINE_TAX_RATE lookup," + db_STG_LINE_TAX_RATE + "," + db_CONS_LINE_TAX_RATE + ",Pass";
                                                        section1_results.add(stg_line_tax_rate);
                                                        String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_TAX_RATE lookup" + "," + db_STG_LINE_TAX_RATE + "," + db_CONS_LINE_TAX_RATE + ",Pass" + "," + load_date + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                        section2_results_tbl.add(tbl_line_pc_header_id);
                                                    } else {
                                                        String stg_line_tax_rate = ",LINE_TAX_RATE lookup," + db_STG_LINE_TAX_RATE + "," + db_CONS_LINE_TAX_RATE + ",Fail";
                                                        section1_results.add(stg_line_tax_rate);
                                                        String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_TAX_RATE lookup" + "," + db_STG_LINE_TAX_RATE + "," + db_CONS_LINE_TAX_RATE + ",Fail" + "," + load_date + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                        section2_results_tbl.add(tbl_line_pc_header_id);
                                                        CONS_flag++;
                                                    }

                                                } else {
                                                    String stg_line_tax_rate = ",LINE_TAX_RATE lookup," + db_STG_LINE_TAX_RATE + "," + db_CONS_LINE_TAX_RATE + ",Pass";
                                                    section1_results.add(stg_line_tax_rate);
                                                    String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_TAX_RATE lookup" + "," + db_STG_LINE_TAX_RATE + "," + db_CONS_LINE_TAX_RATE + ",Pass" + "," + load_date + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_line_pc_header_id);
                                                }
                                            }

                                            //---------------- Validate LINE_TAX_TYPE -----------------------
                                            if (db_STG_SUMMARY_FLAG.equals("Y")) {
                                                SQLResultset = SQLstmt.executeQuery(LandscapeGLPremium_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'TAX_TYPE'" + fsh_source);
                                                //SQLResultset = SQLstmt.executeQuery("SELECT * FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'TAX_TYPE' and system = 'LAND' and pattern = 'GLPremium'");
                                                while (SQLResultset.next()) {
                                                    db_lookup_line_tax_type_meaning = SQLResultset.getString("MEANING");
                                                }
                                                if (db_lookup_line_tax_type_meaning.equals("null")) {
                                                    String lookup_line_tax_type_meaning = ",LINE_TAX_TYPE lookup," + "LookUp value not found" + "," + db_STG_LINE_TAX_TYPE + ",Fail";
                                                    section1_results.add(lookup_line_tax_type_meaning);
                                                    String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_TAX_TYPE lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_TAX_TYPE + ",Fail" + "," + load_date + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_line_pc_header_id);
                                                    CONS_flag++;
                                                } else if (db_lookup_line_tax_type_meaning != null) {
                                                    if (db_lookup_line_tax_type_meaning.equals(db_STG_LINE_TAX_TYPE)) {
                                                        String lookup_line_tax_type_meaning = ",LINE_TAX_TYPE lookup," + db_lookup_line_tax_type_meaning + "," + db_STG_LINE_TAX_TYPE + ",Pass";
                                                        section1_results.add(lookup_line_tax_type_meaning);
                                                        String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_TAX_TYPE lookup" + "," + db_lookup_line_tax_type_meaning + "," + db_STG_LINE_TAX_TYPE + ",Pass" + "," + load_date + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                        section2_results_tbl.add(tbl_line_pc_header_id);
                                                    } else {
                                                        String lookup_line_tax_type_meaning = ",LINE_TAX_TYPE lookup," + db_lookup_line_tax_type_meaning + "," + db_STG_LINE_TAX_TYPE + ",Fail";
                                                        section1_results.add(lookup_line_tax_type_meaning);
                                                        String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_TAX_TYPE lookup" + "," + db_lookup_line_tax_type_meaning + "," + db_STG_LINE_TAX_TYPE + ",Fail" + "," + load_date + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                        section2_results_tbl.add(tbl_line_pc_header_id);
                                                        CONS_flag++;
                                                    }
                                                }
                                            } else {
                                                if (db_STG_LINE_TAX_TYPE != null && db_CONS_LINE_TAX_TYPE != null) {
                                                    if (db_STG_LINE_TAX_TYPE.equals(db_CONS_LINE_TAX_TYPE)) {
                                                        String stg_line_tax_type = ",LINE_TAX_TYPE lookup," + db_STG_LINE_TAX_TYPE + "," + db_CONS_LINE_TAX_TYPE + ",Pass";
                                                        section1_results.add(stg_line_tax_type);
                                                        String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_TAX_TYPE lookup" + "," + db_STG_LINE_TAX_TYPE + "," + db_CONS_LINE_TAX_TYPE + ",Pass" + "," + load_date + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                        section2_results_tbl.add(tbl_line_pc_header_id);
                                                    } else {
                                                        String stg_line_tax_type = ",LINE_TAX_TYPE lookup," + db_STG_LINE_TAX_TYPE + "," + db_CONS_LINE_TAX_TYPE + ",Fail";
                                                        section1_results.add(stg_line_tax_type);
                                                        String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_TAX_TYPE lookup" + "," + db_STG_LINE_TAX_TYPE + "," + db_CONS_LINE_TAX_TYPE + ",Fail" + "," + load_date + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                        section2_results_tbl.add(tbl_line_pc_header_id);
                                                        CONS_flag++;
                                                    }
                                                } else {
                                                    String stg_line_tax_type = ",LINE_TAX_TYPE lookup," + db_STG_LINE_TAX_TYPE + "," + db_CONS_LINE_TAX_TYPE + ",Pass";
                                                    section1_results.add(stg_line_tax_type);
                                                    String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_TAX_TYPE lookup" + "," + db_STG_LINE_TAX_TYPE + "," + db_CONS_LINE_TAX_TYPE + ",Pass" + "," + load_date + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_line_pc_header_id);
                                                }
                                            }


                                        /*SQLResultset = SQLstmt.executeQuery("SELECT * FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'LANDGLPremium' and LOOKUP_TYPE = 'SUMMARISE_DATA_FLAG' and system = 'LAND' and pattern = 'GLPremium'");
                                        while (SQLResultset.next()) {
                                            db_lookup_line_tax_rate_meaning = SQLResultset.getString("MEANING");
                                        }
                                        if (db_lookup_line_tax_rate_meaning.equals("null")) {
                                            String lookup_line_tax_rate_meaning = ",LINE_TAX_RATE lookup," + "LookUp value not found" + "," + db_STG_LINE_TAX_RATE + ",Fail";
                                            section1_results.add(lookup_line_tax_rate_meaning);
                                        } else if (db_lookup_line_tax_rate_meaning != null) {
                                            if (db_lookup_line_tax_rate_meaning.equals(db_STG_LINE_TAX_RATE)) {
                                                String lookup_line_tax_rate_meaning = ",LINE_TAX_RATE lookup," + db_lookup_line_tax_rate_meaning + "," + db_STG_LINE_TAX_RATE + ",Pass";
                                                section1_results.add(lookup_line_tax_rate_meaning);
                                            } else {
                                                String lookup_line_tax_rate_meaning = ",LINE_TAX_RATE lookup," + db_lookup_line_tax_rate_meaning + "," + db_STG_LINE_TAX_RATE + ",Fail";
                                                section1_results.add(lookup_line_tax_rate_meaning);
                                            }
                                        }*/


                                        }


                                    }
                                    //stg_sub_indent++;
                                }
                                //stg_line_map_row++;

                            }

                        }
                    }
                }

                //----------------- Validate the Over all Status -------------------
                System.out.println("Looping ++  CONS_flag " + CONS_flag);
                String Overall_status = null;
                String Overall_stg_status = null;
                if (CONS_flag > 0) {
                    CONS_STATUS.add("Fail");
                    Overall_status = "Fail";
                } else {
                    CONS_STATUS.add("Pass");
                    Overall_status = "Pass";
                }


                if (CONS_flag > 0) {
                    OverAllStatus.add("Fail");
                } else {
                    OverAllStatus.add("Pass");
                }

                String tbl_summary_filelist = Source + "," + pattern + "," + file_name + "," + "CONS TO STG " + "," + load_date + "," + OverAllStatus + "," + btc_BATCH_PKEY;
                //String tbl_summary_filelist = Source + "," + pattern + "," + file_name + "," + load_dateFormat + "," + "CONST TO STG " + "," + OverAllStatus;
                summary_results_tbl.add(tbl_summary_filelist);


                list.addAll(section1_results);
                list.addAll(section2_results);
                list.addAll(section3_results);
                list.addAll(section4_results);

                // ---------------- HTML Report generation ------------------------
                report_generation.report_Test1(section1_results, "Header", xml_file_name, "CONSOLIDATION LAYER - STAGING LAYER", "Landscape_GLPremium", "Landscape_GLPremium : CONSOLIDATION LAYER - STAGING AGGREGATE LAYER", "");
                report_generation.report_Test1(section1_results, "Section2", xml_file_name, "CONSOLIDATION LAYER - STAGING LAYER", "Landscape_GLPremium", "Landscape_GLPremium : CONSOLIDATION LAYER - STAGING AGGREGATE LAYER", "");
                report_generation.report_Test1(section2_results, "Mandatory", xml_file_name, "Mandatory_Check_CONS", "Landscape_GLPremium", "Landscape_GLPremium : CONSOLIDATION LAYER - STAGING AGGREGATE LAYER", "");
                report_generation.report_Test1(section4_results, "Mandatory", xml_file_name, "Mandatory_Check_STG", "Landscape_GLPremium", "Landscape_GLPremium : CONSOLIDATION LAYER - STAGING AGGREGATE LAYER", "");
                report_generation.report_Test1(section3_results, "Section3", xml_file_name, "STAGING LAYER - AGGREGATE LAYER", "Landscape_GLPremium", "Landscape_GLPremium : CONSOLIDATION LAYER - STAGING AGGREGATE LAYER", "");


                table_detail_report.detail_report_tbl(section2_results_tbl);
            }
            state_model.section_method(file_list, CONS_STATUS, "N/A", OverAllStatus, "Landscape_GLPremium_Summary");
            table_summary_report.summary_report_tbl(summary_results_tbl);
        }


    }


}
