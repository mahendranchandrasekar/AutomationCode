
package Dashboard_Report;

import java.io.IOException;
import java.sql.*;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONException;

public class PULSE_AP_Invoice {

    static Statement SQLstmt = null;
    static ResultSet SQLResultset = null;

    public static HTML_Report_Generation_DB_EVO report_generation;
    public static HTML_Report_Generation_State_Model_B4C report_generation_state;
    public static SCH_EVO_PC_State_Model_B4C state_model;

    public static Table_Detail_Report table_detail_report;
    public static Table_Summary_Report table_summary_report;
    public static connectDatabase connect_db;

    public static void main(String[] args) throws IOException, SQLException, JSONException, ParseException {
        report_generation = new HTML_Report_Generation_DB_EVO();
        report_generation_state = new HTML_Report_Generation_State_Model_B4C();
        state_model = new SCH_EVO_PC_State_Model_B4C();

        table_detail_report = new Table_Detail_Report();
        table_summary_report = new Table_Summary_Report();
        connect_db = new connectDatabase();

        //----------------------- delete the existing report --------------
        report_generation.clean_report("PULSE_AP_Invoice.html");
        report_generation_state.clean_report_summary("PULSE_AP_Invoice.html");


        /*//--------------- SIT  database details -------------------
        String URL_SIT1 = "jdbc:oracle:thin:@dbs119dev.gwd.grpinf.net:1521/FSHDTST3";
        String Username_SIT1 = "FSH_ORA_DATA";
        String password_SIT1 = "Development_Test3";*/

        //--------------- SIT  database details -------------------
        String URL_SIT1 = "jdbc:oracle:thin:@dbs119dev.gwd.grpinf.net:1521/FSHDTST4";
        String Username_SIT1 = "FSH_ORA_DATA";
        String password_SIT1 = "XdbvFm!dm7dVCzWE";

        //--------------- EBS  database details -------------------
        String URL_ICSI = "jdbc:oracle:thin:@dcn2ddbx340.gwd.grpinf.net:1618:ICSI";
        String Username_ICSI = "apps";
        String password_ICSI = "apps4icsi";

        List<String> file_list = new ArrayList<String>();
        List<String> list = new ArrayList<String>();
        List<String> section1_results = new ArrayList<String>();
        //List<String> section2_results = new ArrayList<String>();
        List<String> section4_results = new ArrayList<String>();

        List<String> OverAllStatus = new ArrayList<String>();
        List<String> CONS_STATUS = new ArrayList<String>();
        List<String> summary_results_tbl = new ArrayList<String>();

        String[] file_lists = null;
        int section1_map_row = 1;

        //--------------------- Declaring the supporting details for reporting --------------
        String file_name = "null";
        String Source = "PULS";
        String pattern = "APInvoice";
        String header = "Header";
        String line = "Line";

        int cons_stg_map_row = 1;
        int stg_line_map_row = 1;
        int cons_mandatory_map_row = 1;
        int stg_mandatory_map_row = 1;

        //--------------- Consolidation variables decleration ---------

        String CONS_HDR_STATUS = "null";
        String db_CONS_SOURCE = "null";
        String db_CONS_CURRENCY_CODE = "null";
        String db_CONS_AP_SOURCE = "null";
        String db_CONS_HEADER_ID = "null";
        String db_CONS_GL_DATE = "null";
        String db_CONS_ATTRIBUTE15 = "null";
        String db_CONS_ATTRIBUTE13 = "null";
        String db_CONS_INVOICE_CURRENCY_CODE = "null";
        String db_CONS_INVOICE_AMOUNT = "null";
        String db_CONS_EXCHANGE_RATE = "null";
        String db_CONS_EXCHANGE_EFFECTIVE_DATE = "null";
        String db_CONS_EXCHANGE_RATE_TYPE = "null";
        String db_CONS_EXCHANGE_DATE = "null";
        String db_CONS_ATTRIBUTE8 = "null";
        String db_CONS_VENDOR_NAME = "null";
        String db_CONS_VENDOR_SITE_CODE = "null";
        String db_CONS_VENDOR_SITE_ID = "null";
        String db_CONS_VENDOR_ID = "null";
        String db_CONS_INVOICE_NUM = "null";
        String db_CONS_DESCRIPTION = "null";
        String db_CONS_BANK_SORT_CODE = "null";
        String db_CONS_INVOICE_DATE = "null";
        String db_CONS_CREATION_DATE = "null";
        String db_CONS_ATTRIBUTE1 = "null";
        String db_CONS_ATTRIBUTE2 = "null";
        String db_CONS_ATTRIBUTE3 = "null";
        String db_CONS_ATTRIBUTE4 = "null";
        String db_CONS_ATTRIBUTE5 = "null";
        String db_CONS_ATTRIBUTE6 = "null";
        String db_CONS_ATTRIBUTE7 = "null";
        String db_CONS_ATTRIBUTE_CATEGORY = "null";
        String db_CONS_ATTRIBUTE9 = "null";
        String db_CONS_ATTRIBUTE10 = "null";
        String db_CONS_ATTRIBUTE11 = "null";
        String db_CONS_ATTRIBUTE12 = "null";
        String db_CONS_CALC_TAX_DURING_IMPORT_FLAG = "null";
        String db_CONS_SUBJECT_REV_CHARGE = "null";
        String db_CONS_ORG_ID = "null";
        String db_CONS_LOAD_DATE = "null";
        String db_CONS_BATCH_FKEY = "null";
        String db_CONS_FILE_NAME = "null";
        String load_date = "null";
        Date load_dateFormat = null;
        String btc_BATCH_PKEY = null;


        String db_CONS_LINE_ID = "null";
        String db_CONS_LINE_NUMBER = "null";
        String db_CONS_LINE_SOURCE = "null";
        String db_CONS_LINE_HEADER_ID = "null";
        String db_CONS_LINE_LINE_ID = "null";
        String db_CONS_LINE_AP_SOURCE = "null";
        String db_CONS_LINE_INVOICE_NUM = "null";
        String db_CONS_LINE_LINE_TYPE_LOOKUP_CODE = "null";
        String db_CONS_LINE_LINE_NUMBER = "null";
        String db_CONS_LINE_LINE_GROUP_NUMBER = "null";
        String db_CONS_LINE_CATEGORY = "null";
        String db_CONS_LINE_CURRENCY_CODE = "null";
        String db_CONS_LINE_AMOUNT = "null";
        String db_CONS_LINE_TAX_RECOVERABLE_FLAG = "null";
        String db_CONS_LINE_TAX_RATE_CODE = "null";
        String CONS_LINE_STATUS = "null";
        String db_CONS_LINE_DESCRIPTION = "null";
        //String db_CONS_LINE_LINE_GROUP_NUMBER = "null";
        String db_CONS_LINE_AMOUNT_INCLUDES_TAX_FLAG = "null";
        String db_CONS_LINE_PRORATE_ACROSS_FLAG = "null";
        String db_CONS_LINE_DIST_CODE_CONCATENATED = "null";
        String db_CONS_LINE_SUBJECT_REV_CHARGE = "null";


        String db_STG_HEADER_ID = "null";
        String db_STG_SOURCE = "null";
        String db_STG_INVOICE_ID = "null";
        String db_STG_TRANSACTION_DATE = "null";
        String db_STG_POLICY_NUMBER = "null";
        String db_STG_ATTRIBUTE15 = "null";
        String db_STG_UNDERWRITER = "null";
        String db_STG_BRAND = "null";
        String db_STG_LINE_OF_BUSINESS = "null";
        String db_STG_PRODUCT_TYPE = "null";
        String db_STG_CHANNEL = "null";
        String db_STG_INVOICE_CURRENCY_CODE = "null";
        String db_STG_INVOICE_AMOUNT = "null";
        String db_STG_EXCHANGE_RATE = "null";
        String db_STG_EXCHANGE_RATE_TYPE = "null";
        String db_STG_EXCHANGE_EFFECTIVE_DATE = "null";
        String db_STG_ATTRIBUTE8 = "null";
        String db_STG_PAYMENT_METHOD_CODE = "null";
        String db_STG_PAYMENT_TERMS = "null";
        String db_STG_CHEQUE_DELIVERY = "null";
        String db_STG_VENDOR_NAME = "null";
        String db_STG_VENDOR_SITE_CODE = "null";
        String db_STG_VENDOR_SITE_CD = "null";
        String db_STG_VENDOR_SITE_ID = "null";
        String db_STG_VENDOR_ID = "null";
        String db_STG_GLOBAL_ATTRIBUTE1 = "null";
        String db_STG_INVOICE_NUM = "null";
        String db_STG_DESCRIPTION = "null";
        String db_STG_INVOICE_DATE = "null";
        String db_STG_INVOICE_RECEIVED_DATE = "null";
        String db_STG_ATTRIBUTE1 = "null";
        String db_STG_LOSS_DATE = "null";
        String db_STG_THIRD_PARTY_REF = "null";
        String db_STG_PAYEE_TYPE = "null";
        String db_STG_PAY_GROUP_LOOKUP_CODE = "null";
        String db_STG_ATTRIBUTE2 = "null";
        String db_STG_ATTRIBUTE3 = "null";
        String db_STG_ATTRIBUTE4 = "null";
        String db_STG_ATTRIBUTE5 = "null";
        String db_STG_ATTRIBUTE6 = "null";
        String db_STG_ATTRIBUTE7 = "null";
        String db_STG_PAYEE_COUNTY = "null";
        String db_STG_ACCOUNT_NUMBER = "null";
        String db_STG_ATTRIBUTE9 = "null";
        String db_STG_ATTRIBUTE10 = "null";
        String db_STG_ATTRIBUTE11 = "null";
        String db_STG_SORT_CODE = "null";
        String db_STG_PAYEE_COUNTRY = "null";
        String db_STG_PAYMENT_COUNTRY = "null";
        String db_STG_ATTRIBUTE_CATEGORY = "null";
        String db_STG_ATTRIBUTE13 = "null";
        //String db_STG_GLOBAL_ATTRIBUTE1 = "null";
        String db_STG_CALC_TAX_DURING_IMPORT_FLAG = "null";
        String db_STG_BUSINESS_UNIT = "null";
        String db_STG_GLOBAL_ATTRIBUTE2 = "null";
        String db_STG_GLOBAL_ATTRIBUTE3 = "null";
        String db_STG_ORG_ID = "null";
        String db_STG_LOAD_DATE = "null";
        String STG_HDR_STATUS = "null";
        String db_STG_BATCH_FKEY = "null";
        String db_STG_FILE_NAME = "null";
        String db_STG_LINE_TYPE_LOOKUP_CODE = "null";
        String db_STG_LOAD_TIME = "null";
        String db_STG_FSH_ATTRIBUTE_07 = "null";

        String db_STG_LINE_SOURCE = "null";
        String db_STG_LINE_HEADER_ID = "null";
        String db_STG_LINE_LINE_ID = "null";
        String db_STG_LINE_AP_SOURCE = "null";
        String db_STG_LINE_INVOICE_NUM = "null";
        String db_STG_LINE_INVOICE_ID = "null";
        String db_STG_LINE_LINE_NUMBER = "null";
        String db_STG_LINE_LINE_TYPE_LOOKUP_CODE = "null";
        String db_STG_LINE_LINE_GROUP_NUMBER = "null";
        String db_STG_LINE_CATEGORY = "null";
        String db_STG_LINE_CURRENCY_CODE = "null";
        String db_STG_LINE_TYPE_LINE_LOOKUP_CODE = "null";
        String db_STG_LINE_AMOUNT = "null";
        String db_STG_LINE_LINE_ITEM_AMOUNT = "null";
        String db_STG_LINE_BASE_LINE_ITEM_AMOUNT = "null";
        String db_STG_LINE_TAX_RATE_CODE = "null";
        String STG_LINE_STATUS = "null";
        String db_STG_LINE_TAX_CODE = "null";
        String db_STG_LINE_DESCRIPTION = "null";
        String db_STG_LINE_SEGMENT6 = "null";
        String db_STG_LINE_AMOUNT_INCLUDES_TAX_FLAG = "null";
        String db_STG_LINE_PRORATE_ACROSS_FLAG = "null";
        String db_STG_LINE_DIST_CODE_CONCATENATED = "null";
        String db_STG_LINE_SEGMENT1 = "null";
        String db_STG_LINE_SEGMENT2 = "null";
        String db_STG_LINE_SEGMENT3 = "null";
        String db_STG_LINE_SEGMENT4 = "null";
        String db_STG_LINE_SEGMENT5 = "null";
        String db_STG_LINE_SEGMENT7 = "null";
        String db_STG_LINE_SEGMENT8 = "null";
        String db_STG_LINE_SEGMENT9 = "null";
        String db_STG_LINE_SEGMENT10 = "null";
        String db_STG_LINE_ORG_ID = "null";
        String db_STG_LINE_BUSINESS_UNIT = "null";
        String db_STG_LINE_CATEGORY_DERIVED = "null";
        String db_STG_LINE_SUBJECT_REV_CHARGE = "null";

        String xmlfile_name = "null";
        String xml_file_name1 = null;

        //---------------- Line item -------
        String db_stg_line_id = "null";
        String db_stg_INVOICE_ID = "null";


        //-------- Connect to Database --------------
        connect_db.createConnection("SIT2");
        //table_detail_report.detail_report_tbl_delete(connection, Source);


        //------ get the new file from batch control table --------------
        boolean newRecord = true;
        //SQLResultset = SQLstmt.executeQuery("Select distinct file_name from DLG_FSH_CTL_BATCH where Trunc(LOAD_DATE) = TRUNC(SYSDATE-1) and system = 'LAND' and pattern = 'GLPREMIUM'"); LANDGLPremium_20191115130012.xml LANDGLPremium_20191106125232.xml
        String outSQL = connect_db.executeQuery_DB("BATCH", "APInvoice_batchCtl", "PULSE");
        SQLstmt = connect_db.resStatement();

        SQLResultset = SQLstmt.executeQuery(outSQL);
        while (SQLResultset.next()) {
            file_list.add(SQLResultset.getString("FILE_NAME"));
            System.out.println("File name---" + SQLResultset.getString("FILE_NAME"));
            list.addAll(section1_results);
        }


        // ---------------------------------- Get the batch PKEY ----------------------
        String outSQL_bkey = connect_db.executeQuery_DB("BATCH", "APInvoice_batchCtl_key", "PULSE");

        SQLResultset = SQLstmt.executeQuery(outSQL_bkey);
        while (SQLResultset.next()) {
            btc_BATCH_PKEY = SQLResultset.getString("BATCH_PKEY");
        }

        // ---------------------------------- Check the new file ----------------------
        SQLResultset = SQLstmt.executeQuery(outSQL);
        if (!SQLResultset.next()) {
            System.out.println("No new Pulse_APInvoice files have been received to FSH ");
            newRecord = false;
            String nonewfile = ",FILE_NAME," + "No new Pulse_APInvoice files have been received to FSH" + "," + "," + ",Pass";
            section1_results.add(nonewfile);
            list.addAll(section1_results);
        }

        if (newRecord) {

            //------------------------ Section 1 Start Print all the new file in the report-------------------
            for (String num_file : file_list) {
                file_lists = num_file.split(",");
                for (String file_list1 : file_lists) {
                    xml_file_name1 = file_list1;
                    //int section1_map_row = 1;
                    String newfile = section1_map_row + ",FILE_NAME," + xml_file_name1 + "," + xml_file_name1 + ",Pass";
                    section1_map_row++;
                    section1_results.add(newfile);
                }
            }
            list.addAll(section1_results);
            //report_generation.report_Test1(section1_results, "Section1", xml_file_name1, "B4C BC CONS BATCH TABLE VALIDATION", "B4C_SCHBilling", "B4C BC VALIDATION");
            //------------------------ Section 1 End ----------------------------------------------
        }

        List<String> list_header = new ArrayList<String>(); // -- Add all the header id
        if (newRecord) {
            //------------ Split the file names form the list --------------
            for (String xml_file_name : file_list) {
                int section2_map_row = 1;
                int CONS_flag = 0;
                List<String> section2_results = new ArrayList<String>();
                List<String> section3_results = new ArrayList<String>();
                List<String> section2_results_tbl = new ArrayList<String>();

                file_name = xml_file_name;

        /*//------ get the new file from batch control table --------------
        boolean newRecord = true;
        //SQLResultset = SQLstmt.executeQuery("Select distinct file_name from DLG_FSH_CTL_BATCH where Trunc(LOAD_DATE) = TRUNC(SYSDATE-1) and system = 'ECLI' and pattern = 'PULS_APINVOICE_68867_20191122'");
        SQLResultset = SQLstmt.executeQuery("Select distinct file_name from DLG_FSH_CTL_BATCH where file_name = 'PULS_APINVOICE_70837_20191203'");
        while (SQLResultset.next()) {
            file_list.add(SQLResultset.getString("FILE_NAME"));
            System.out.println("File name---" + SQLResultset.getString("FILE_NAME"));
            list.addAll(section1_results);
        }

        //------------------ validate no new files -----------------------
        String xmlfile_name = "null";
        //SQLResultset = SQLstmt.executeQuery("Select distinct file_name from DLG_FSH_CTL_BATCH where Trunc(LOAD_DATE) = TRUNC(SYSDATE-1) and system = 'ECLI' and pattern = 'APInvoice' ");
        SQLResultset = SQLstmt.executeQuery("Select distinct file_name from DLG_FSH_CTL_BATCH where file_name = 'PULS_APINVOICE_70837_20191203'");
        if (!SQLResultset.next()) {
            System.out.println("No new BMS AP INVOICE files have been received to FSH ");
            newRecord = false;
            String nonewfile = ",FILE_NAME," + "No new BMS AP INVOICE files have been received to FSH" + "," + "," + ",Pass";
        }

        List<String> list_header = new ArrayList<String>(); // -- Add all the header id
        if (newRecord) {
            //------------ Split the file names form the list --------------
            for (String xml_file_name : file_list) {
                int CONS_flag = 0;
                int STG_flag = 0;
                String stgFlag = "Pass";
                String toFlag = "Pass";
                //int cons_stg_map_row = 1;
                int section2_line_map_row = 1;
                int section4_map_row = 1;*/

                //-------------- Validation Cons to Stag table ----------------
                String PulseAPInvoice_consSqlQuery = connect_db.executeQuery_DB("PULSE_AP", "APInvoice_Cons", "PULSE");
                SQLResultset = SQLstmt.executeQuery(PulseAPInvoice_consSqlQuery + "'" + file_name + "'");
                //SQLResultset = SQLstmt.executeQuery("SELECT * from DLG_FSH_CONS_PULS_API_HDR WHERE FILE_NAME = '" + xml_file_name + "'");
                while (SQLResultset.next()) {
                    db_CONS_HEADER_ID = SQLResultset.getString("HEADER_ID");
                    list_header.add(db_CONS_HEADER_ID);
                }

                for (int i = 0; i < list_header.size(); i++) {
                    SQLResultset = SQLstmt.executeQuery(PulseAPInvoice_consSqlQuery + "'" + file_name + "' and HEADER_ID = '" + list_header.get(i) + "' ");
                    //SQLResultset = SQLstmt.executeQuery("SELECT * from DLG_FSH_CONS_PULS_API_HDR WHERE FILE_NAME = '" + xml_file_name + "' and HEADER_ID ='" + list_header.get(i) + "'");
                    while (SQLResultset.next()) {
                        db_CONS_HEADER_ID = SQLResultset.getString("HEADER_ID");
                        db_CONS_AP_SOURCE = SQLResultset.getString("AP_SOURCE");
                        db_CONS_BATCH_FKEY = SQLResultset.getString("BATCH_FKEY");
                        db_CONS_SOURCE = SQLResultset.getString("SOURCE");
                        db_CONS_GL_DATE = SQLResultset.getString("GL_DATE");
                        db_CONS_ATTRIBUTE15 = SQLResultset.getString("ATTRIBUTE15");
                        db_CONS_ATTRIBUTE13 = SQLResultset.getString("ATTRIBUTE13");
                        db_CONS_INVOICE_CURRENCY_CODE = SQLResultset.getString("INVOICE_CURRENCY_CODE");
                        db_CONS_INVOICE_AMOUNT = SQLResultset.getString("INVOICE_AMOUNT");
                        db_CONS_EXCHANGE_RATE = SQLResultset.getString("EXCHANGE_RATE");
                        db_CONS_EXCHANGE_RATE_TYPE = SQLResultset.getString("EXCHANGE_RATE_TYPE");
                        db_CONS_EXCHANGE_DATE = SQLResultset.getString("EXCHANGE_DATE");
                        db_CONS_ATTRIBUTE8 = SQLResultset.getString("ATTRIBUTE8");
                        db_CONS_VENDOR_NAME = SQLResultset.getString("VENDOR_NAME");
                        db_CONS_VENDOR_SITE_CODE = SQLResultset.getString("VENDOR_SITE_CODE");
                        db_CONS_VENDOR_SITE_ID = SQLResultset.getString("VENDOR_SITE_ID");
                        db_CONS_VENDOR_ID = SQLResultset.getString("VENDOR_ID");
                        db_CONS_INVOICE_NUM = SQLResultset.getString("INVOICE_NUM");
                        db_CONS_DESCRIPTION = SQLResultset.getString("DESCRIPTION");
                        db_CONS_INVOICE_DATE = SQLResultset.getString("INVOICE_DATE");
                        db_CONS_ATTRIBUTE1 = SQLResultset.getString("ATTRIBUTE1");
                        db_CONS_ATTRIBUTE2 = SQLResultset.getString("ATTRIBUTE2");
                        db_CONS_ATTRIBUTE3 = SQLResultset.getString("ATTRIBUTE3");
                        db_CONS_ATTRIBUTE4 = SQLResultset.getString("ATTRIBUTE4");
                        db_CONS_ATTRIBUTE5 = SQLResultset.getString("ATTRIBUTE5");
                        db_CONS_ATTRIBUTE6 = SQLResultset.getString("ATTRIBUTE6");
                        db_CONS_ATTRIBUTE7 = SQLResultset.getString("ATTRIBUTE7");
                        db_CONS_ATTRIBUTE9 = SQLResultset.getString("ATTRIBUTE9");
                        db_CONS_ATTRIBUTE10 = SQLResultset.getString("ATTRIBUTE10");
                        db_CONS_ATTRIBUTE11 = SQLResultset.getString("ATTRIBUTE11");
                        db_CONS_ATTRIBUTE12 = SQLResultset.getString("ATTRIBUTE12");
                        db_CONS_ATTRIBUTE13 = SQLResultset.getString("ATTRIBUTE13");
                        db_CONS_ATTRIBUTE_CATEGORY = SQLResultset.getString("ATTRIBUTE_CATEGORY");
                        db_CONS_CALC_TAX_DURING_IMPORT_FLAG = SQLResultset.getString("CALC_TAX_DURING_IMPORT_FLAG");
                        db_CONS_SUBJECT_REV_CHARGE = SQLResultset.getString("SUBJECT_REV_CHARGE");
                        //db_CONS_ORG_ID = SQLResultset.getString("ORG_ID");
                        db_CONS_LOAD_DATE = SQLResultset.getString("LOAD_DATE");
                        CONS_HDR_STATUS = SQLResultset.getString("STATUS");
                        db_CONS_FILE_NAME = SQLResultset.getString("FILE_NAME");
                        load_date = SQLResultset.getString("LOAD_DATE");
                        String db_file_name = SQLResultset.getString("FILE_NAME");

                        //Converting Load date format
                        String load_dateTRIM = load_date.substring(0, 10);
                        load_dateFormat = Date.valueOf(load_dateTRIM);
                        System.out.println(load_dateFormat);

                        //Validating mandatory fields in consolidation table
                        //HEADER_ID - mandatory validation
                        if ((db_CONS_HEADER_ID == null) && (CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_HEADER_ID = cons_mandatory_map_row + "," + db_CONS_HEADER_ID + ",HEADER_ID," + "HEADER_ID : " + db_CONS_HEADER_ID + "," + "HEADER_ID was not found," + CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_HEADER_ID);
                            cons_mandatory_map_row++;
                        } else {
                            String CONS_HEADER_ID = cons_mandatory_map_row + "," + db_CONS_HEADER_ID + ",HEADER_ID," + "HEADER_ID : " + db_CONS_HEADER_ID + "," + "HEADER_ID was found," + CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_HEADER_ID);
                            cons_mandatory_map_row++;
                        }


                        //AP_SOURCE - mandatory validation
                        if ((db_CONS_AP_SOURCE == null) && (CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_AP_SOURCE = "," + ",AP_SOURCE," + "AP_SOURCE : " + db_CONS_AP_SOURCE + "," + "AP_SOURCE was not found," + CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_AP_SOURCE);
                        } else {
                            String CONS_AP_SOURCE = "," + ",AP_SOURCE," + "AP_SOURCE : " + db_CONS_AP_SOURCE + "," + "AP_SOURCE was found," + CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_AP_SOURCE);
                        }

                        //INVOICE_AMOUNT - mandatory validation
                        if ((db_CONS_INVOICE_AMOUNT == null) && (CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_INVOICE_AMOUNT = "," + ",INVOICE_AMOUNT," + "INVOICE_AMOUNT : " + db_CONS_INVOICE_AMOUNT + "," + "INVOICE_AMOUNT was not found," + CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_INVOICE_AMOUNT);
                        } else {
                            String CONS_INVOICE_AMOUNT = "," + ",INVOICE_AMOUNT," + "INVOICE_AMOUNT : " + db_CONS_INVOICE_AMOUNT + "," + "INVOICE_AMOUNT was found," + CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_INVOICE_AMOUNT);
                        }

                        //VENDOR_NAME - mandatory validation
                        if ((db_CONS_VENDOR_NAME == null) && (CONS_HDR_STATUS != "REVIEW")) {

                            String stg_INVOICE_NET_AMOUNT = "," + ",VENDOR_NAME," + "VENDOR_NAME : " + db_CONS_VENDOR_NAME + "," + "VENDOR_NAME was not found," + CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(stg_INVOICE_NET_AMOUNT);
                        } else {
                            String stg_INVOICE_NET_AMOUNT = "," + ",VENDOR_NAME," + "VENDOR_NAME : " + db_CONS_VENDOR_NAME + "," + "VENDOR_NAME was found," + CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(stg_INVOICE_NET_AMOUNT);
                        }

                        //VENDOR_SITE_CODE - mandatory validation
                        if ((db_CONS_VENDOR_SITE_CODE == null) && (CONS_HDR_STATUS != "REVIEW")) {

                            String stg_INVOICE_VAT_AMOUNT = "," + ",VENDOR_SITE_CODE," + "VENDOR_SITE_CODE : " + db_CONS_VENDOR_SITE_CODE + "," + "VENDOR_SITE_CODE was not found," + CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(stg_INVOICE_VAT_AMOUNT);
                        } else {
                            String stg_INVOICE_VAT_AMOUNT = "," + ",VENDOR_SITE_CODE," + "VENDOR_SITE_CODE : " + db_CONS_VENDOR_SITE_CODE + "," + "VENDOR_SITE_CODE was found," + CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(stg_INVOICE_VAT_AMOUNT);
                        }

                        //INVOICE_NUM - mandatory validation
                        if ((db_CONS_INVOICE_NUM == null) && (CONS_HDR_STATUS != "REVIEW")) {

                            String stg_INVOICE_GROSS_AMOUNT = "," + ",INVOICE_NUM," + "INVOICE_NUM : " + db_CONS_INVOICE_NUM + "," + "INVOICE_NUM was not found," + CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(stg_INVOICE_GROSS_AMOUNT);
                        } else {
                            String stg_INVOICE_GROSS_AMOUNT = "," + ",INVOICE_NUM," + "INVOICE_NUM : " + db_CONS_INVOICE_NUM + "," + "INVOICE_NUM was found," + CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(stg_INVOICE_GROSS_AMOUNT);
                        }

                        //DESCRIPTION - mandatory validation
                        if ((db_CONS_DESCRIPTION == null) && (CONS_HDR_STATUS != "REVIEW")) {

                            String stg_INVOICE_NUM = "," + ",DESCRIPTION," + "DESCRIPTION : " + db_CONS_DESCRIPTION + "," + "DESCRIPTION was not found," + CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(stg_INVOICE_NUM);
                        } else {
                            String stg_INVOICE_NUM = "," + ",DESCRIPTION," + "DESCRIPTION : " + db_CONS_DESCRIPTION + "," + "DESCRIPTION was found," + CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(stg_INVOICE_NUM);
                        }

                        //INVOICE_DATE - mandatory validation
                        if ((db_CONS_INVOICE_DATE == null) && (CONS_HDR_STATUS != "REVIEW")) {

                            String stg_INVOICE_DATE = "," + ",INVOICE_DATE," + "INVOICE_DATE : " + db_CONS_INVOICE_DATE + "," + "INVOICE_DATE was not found," + CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(stg_INVOICE_DATE);
                        } else {
                            String stg_INVOICE_DATE = "," + ",INVOICE_DATE," + "INVOICE_DATE : " + db_CONS_INVOICE_DATE + "," + "INVOICE_DATE was found," + CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(stg_INVOICE_DATE);
                        }

                        //------------------- Consolidation to Staging ----------------------------------
                        String PulseAPInvoice_stgSqlQuery = connect_db.executeQuery_DB("PULSE_AP", "APInvoice_Stg", "PULSE");
                        SQLResultset = SQLstmt.executeQuery(PulseAPInvoice_stgSqlQuery + "'" + file_name + "' and HEADER_ID = '" + list_header.get(i) + "' ");
                        //SQLResultset = SQLstmt.executeQuery("SELECT * from DLG_FSH_STG_COMM_API_HDR WHERE FILE_NAME = '" + xml_file_name + "' and HEADER_ID ='" + list_header.get(i) + "'");
                        System.out.println("Header id outer ---" + db_CONS_HEADER_ID);
                        if (!SQLResultset.next()) {
                            String stg_header_id = section2_map_row + ",HEADER_ID," + "no records available in STG table" + "," + db_CONS_HEADER_ID + ",Fail";
                            section2_results.add(stg_header_id);
                        } else {
                            SQLResultset = SQLstmt.executeQuery(PulseAPInvoice_stgSqlQuery + "'" + file_name + "' and HEADER_ID = '" + list_header.get(i) + "' ");
                            while (SQLResultset.next()) {
                                db_STG_HEADER_ID = SQLResultset.getString("HEADER_ID");
                                STG_HDR_STATUS = SQLResultset.getString("STATUS");
                                db_STG_BATCH_FKEY = SQLResultset.getString("BATCH_FKEY");
                                db_STG_SOURCE = SQLResultset.getString("SOURCE");
                                db_STG_INVOICE_ID = SQLResultset.getString("INVOICE_ID");
                                db_STG_TRANSACTION_DATE = SQLResultset.getString("TRANSACTION_DATE");
                                db_STG_POLICY_NUMBER = SQLResultset.getString("POLICY_NUMBER");
                                db_STG_ATTRIBUTE15 = SQLResultset.getString("ATTRIBUTE15");
                                //db_STG_UNDERWRITER = SQLResultset.getString("UNDERWRITER");
                                db_STG_BRAND = SQLResultset.getString("BRAND");
                                db_STG_LINE_OF_BUSINESS = SQLResultset.getString("LINE_OF_BUSINESS");
                                db_STG_PRODUCT_TYPE = SQLResultset.getString("PRODUCT_TYPE");
                                db_STG_CHANNEL = SQLResultset.getString("CHANNEL");
                                db_STG_INVOICE_CURRENCY_CODE = SQLResultset.getString("INVOICE_CURRENCY_CODE");
                                db_STG_INVOICE_AMOUNT = SQLResultset.getString("INVOICE_AMOUNT");
                                db_STG_EXCHANGE_RATE = SQLResultset.getString("EXCHANGE_RATE");
                                db_STG_EXCHANGE_RATE_TYPE = SQLResultset.getString("EXCHANGE_RATE_TYPE");
                                //db_STG_EXCHANGE_EFFECTIVE_DATE = SQLResultset.getString("EXCHANGE_EFFECTIVE_DATE ");
                                db_STG_ATTRIBUTE8 = SQLResultset.getString("ATTRIBUTE8");
                                db_STG_PAYMENT_METHOD_CODE = SQLResultset.getString("PAYMENT_METHOD_CODE");
                                db_STG_PAYMENT_TERMS = SQLResultset.getString("PAYMENT_TERMS");
                                //db_STG_CHEQUE_DELIVERY = SQLResultset.getString("CHEQUE_DELIVERY");
                                db_STG_VENDOR_NAME = SQLResultset.getString("VENDOR_NAME");
                                db_STG_VENDOR_SITE_CODE = SQLResultset.getString("VENDOR_SITE_CODE");
                                db_STG_VENDOR_SITE_ID = SQLResultset.getString("VENDOR_SITE_ID");
                                db_STG_VENDOR_ID = SQLResultset.getString("VENDOR_ID");
                                db_STG_GLOBAL_ATTRIBUTE1 = SQLResultset.getString("GLOBAL_ATTRIBUTE1");
                                db_STG_INVOICE_NUM = SQLResultset.getString("INVOICE_NUM");
                                db_STG_DESCRIPTION = SQLResultset.getString("DESCRIPTION");
                                db_STG_INVOICE_DATE = SQLResultset.getString("INVOICE_DATE");
                                db_STG_INVOICE_RECEIVED_DATE = SQLResultset.getString("INVOICE_RECEIVED_DATE");
                                db_STG_ATTRIBUTE1 = SQLResultset.getString("ATTRIBUTE1");
                                db_STG_PAYEE_TYPE = SQLResultset.getString("PAYEE_TYPE");
                                db_STG_ATTRIBUTE2 = SQLResultset.getString("ATTRIBUTE2");
                                db_STG_ATTRIBUTE3 = SQLResultset.getString("ATTRIBUTE3");
                                db_STG_ATTRIBUTE4 = SQLResultset.getString("ATTRIBUTE4");
                                db_STG_ATTRIBUTE5 = SQLResultset.getString("ATTRIBUTE5");
                                db_STG_ATTRIBUTE6 = SQLResultset.getString("ATTRIBUTE6");
                                db_STG_ATTRIBUTE7 = SQLResultset.getString("ATTRIBUTE7");
                                db_STG_ATTRIBUTE9 = SQLResultset.getString("ATTRIBUTE9");
                                db_STG_ATTRIBUTE10 = SQLResultset.getString("ATTRIBUTE10");
                                db_STG_ATTRIBUTE11 = SQLResultset.getString("ATTRIBUTE11");
                                db_STG_ATTRIBUTE13 = SQLResultset.getString("ATTRIBUTE13");
                                db_STG_ATTRIBUTE_CATEGORY = SQLResultset.getString("ATTRIBUTE_CATEGORY");
                                db_STG_CALC_TAX_DURING_IMPORT_FLAG = SQLResultset.getString("CALC_TAX_DURING_IMPORT_FLAG");
                                db_STG_GLOBAL_ATTRIBUTE1 = SQLResultset.getString("GLOBAL_ATTRIBUTE1");
                                db_STG_CALC_TAX_DURING_IMPORT_FLAG = SQLResultset.getString("CALC_TAX_DURING_IMPORT_FLAG");
                                db_STG_ORG_ID = SQLResultset.getString("ORG_ID");
                                db_STG_GLOBAL_ATTRIBUTE2 = SQLResultset.getString("GLOBAL_ATTRIBUTE2");
                                db_STG_GLOBAL_ATTRIBUTE3 = SQLResultset.getString("GLOBAL_ATTRIBUTE3");
                                db_STG_BUSINESS_UNIT = SQLResultset.getString("BUSINESS_UNIT");
                                db_STG_LOAD_DATE = SQLResultset.getString("LOAD_DATE");
                                db_STG_LINE_TYPE_LOOKUP_CODE = SQLResultset.getString("LINE_TYPE_LOOKUP_CODE");
                                db_STG_FILE_NAME = SQLResultset.getString("FILE_NAME");
                                db_CONS_CREATION_DATE = SQLResultset.getString("CREATION_DATE");
                                db_STG_PAY_GROUP_LOOKUP_CODE = SQLResultset.getString("PAY_GROUP_LOOKUP_CODE");
                                db_STG_FSH_ATTRIBUTE_07 = SQLResultset.getString("FSH_ATTRIBUTE_07");


                                if (db_CONS_HEADER_ID.equals(db_STG_HEADER_ID)) {
                                    String cons_header_id = cons_stg_map_row + ",HEADER_ID," + db_CONS_HEADER_ID + "," + db_STG_HEADER_ID + ",Pass";
                                    section1_results.add(cons_header_id);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",HEADER_ID" + "," + db_CONS_HEADER_ID + "," + db_STG_HEADER_ID + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    cons_stg_map_row++;
                                } else {
                                    String cons_header_id = cons_stg_map_row + ",HEADER_ID," + db_CONS_HEADER_ID + "," + db_STG_HEADER_ID + ",Fail";
                                    section1_results.add(cons_header_id);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",HEADER_ID" + "," + db_CONS_HEADER_ID + "," + db_STG_HEADER_ID + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    cons_stg_map_row++;
                                    CONS_flag++;
                                }

                                //--------------------  Validation TRANSACTION_DATE ---------------
                                if (db_CONS_GL_DATE == null) {
                                    String db_STG_SysDate = db_STG_LOAD_DATE.substring(0, 10);
                                    String db_STG_TRANSACTION_DATEModified = db_STG_TRANSACTION_DATE.substring(0, 10);
                                    if (db_STG_SysDate.equals(db_STG_TRANSACTION_DATEModified)) {
                                        String cons_trans_date = ",TRANSACTION_DATE," + db_STG_SysDate + "," + db_STG_TRANSACTION_DATEModified + ",Pass";
                                        section1_results.add(cons_trans_date);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_SysDate + "," + db_STG_TRANSACTION_DATEModified + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String cons_trans_date = ",TRANSACTION_DATE," + db_CONS_GL_DATE + "," + db_STG_TRANSACTION_DATEModified + ",Fail";
                                        section1_results.add(cons_trans_date);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_CONS_GL_DATE + "," + db_STG_TRANSACTION_DATEModified + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }

                                } else {
                                    String cons_trans_date = ",TRANSACTION_DATE," + db_CONS_GL_DATE + "," + db_STG_TRANSACTION_DATE + ",Fail";
                                    section1_results.add(cons_trans_date);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_CONS_GL_DATE + "," + db_STG_TRANSACTION_DATE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation ATTRIBUTE15 ---------------

                                if (db_CONS_ATTRIBUTE15 != null && db_STG_ATTRIBUTE15 != null) {
                                    if (db_CONS_ATTRIBUTE15.equals(db_STG_ATTRIBUTE15)) {
                                        String cons_trans_date = ",ATTRIBUTE15," + db_CONS_ATTRIBUTE15 + "," + db_STG_ATTRIBUTE15 + ",Pass";
                                        section1_results.add(cons_trans_date);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ATTRIBUTE15" + "," + db_CONS_ATTRIBUTE15 + "," + db_STG_ATTRIBUTE15 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String cons_trans_date = ",ATTRIBUTE15," + db_CONS_ATTRIBUTE15 + "," + db_STG_ATTRIBUTE15 + ",Fail";
                                        section1_results.add(cons_trans_date);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ATTRIBUTE15" + "," + db_CONS_ATTRIBUTE15 + "," + db_STG_ATTRIBUTE15 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                } else if (db_CONS_ATTRIBUTE15 == null) {
                                    if (db_CONS_INVOICE_NUM.equals(db_STG_ATTRIBUTE15)) {
                                        String cons_trans_date = ",ATTRIBUTE15," + db_CONS_INVOICE_NUM + "," + db_STG_ATTRIBUTE15 + ",Pass";
                                        section1_results.add(cons_trans_date);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ATTRIBUTE15" + "," + db_CONS_ATTRIBUTE15 + "," + db_STG_ATTRIBUTE15 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String cons_trans_date = ",ATTRIBUTE15," + db_CONS_INVOICE_NUM + "," + db_STG_ATTRIBUTE15 + ",Fail";
                                        section1_results.add(cons_trans_date);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ATTRIBUTE15" + "," + db_CONS_ATTRIBUTE15 + "," + db_STG_ATTRIBUTE15 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                } else {
                                    String cons_trans_date = ",ATTRIBUTE15," + db_CONS_ATTRIBUTE15 + "," + db_STG_ATTRIBUTE15 + ",Pass";
                                    section1_results.add(cons_trans_date);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ATTRIBUTE15" + "," + db_CONS_ATTRIBUTE15 + "," + db_STG_ATTRIBUTE15 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                }

                                //--------------------  Validation INVOICE_AMOUNT ---------------
                                if (db_CONS_INVOICE_AMOUNT.equals(db_STG_INVOICE_AMOUNT)) {
                                    String cons_trans_date = ",INVOICE_AMOUNT," + db_CONS_INVOICE_AMOUNT + "," + db_STG_INVOICE_AMOUNT + ",Pass";
                                    section1_results.add(cons_trans_date);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",INVOICE_AMOUNT" + "," + db_CONS_INVOICE_AMOUNT + "," + db_STG_INVOICE_AMOUNT + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_trans_date = ",INVOICE_AMOUNT," + db_CONS_INVOICE_AMOUNT + "," + db_STG_INVOICE_AMOUNT + ",Fail";
                                    section1_results.add(cons_trans_date);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",INVOICE_AMOUNT" + "," + db_CONS_INVOICE_AMOUNT + "," + db_STG_INVOICE_AMOUNT + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation ORG_ID ---------------
                               if(db_CONS_ORG_ID != null && db_STG_ORG_ID !=null) {
                                   if (db_CONS_ORG_ID.equals(db_STG_ORG_ID)) {
                                       String cons_trans_date = ",ORG_ID," + db_CONS_ORG_ID + "," + db_STG_ORG_ID + ",Pass";
                                       section1_results.add(cons_trans_date);
                                       String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ORG_ID" + "," + db_CONS_ORG_ID + "," + db_STG_ORG_ID + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                       section2_results_tbl.add(tbl_header_id);
                                   } else {
                                       String cons_trans_date = ",ORG_ID," + db_CONS_ORG_ID + "," + db_STG_ORG_ID + ",Fail";
                                       section1_results.add(cons_trans_date);
                                       String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ORG_ID" + "," + db_CONS_ORG_ID + "," + db_STG_ORG_ID + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                       section2_results_tbl.add(tbl_header_id);
                                       CONS_flag++;
                                   }
                               } else if(db_CONS_ORG_ID == null && db_STG_ORG_ID == null){
                                   String cons_trans_date = ",ORG_ID," + db_CONS_ORG_ID + "," + db_STG_ORG_ID + ",Pass";
                                   section1_results.add(cons_trans_date);
                                   String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ORG_ID" + "," + db_CONS_ORG_ID + "," + db_STG_ORG_ID + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                   section2_results_tbl.add(tbl_header_id);
                               }

                                //TODO Defect
                                //--------------------  Validation ATTRIBUTE8 ---------------
                                if ((db_STG_PAYMENT_METHOD_CODE != null) && (db_STG_ATTRIBUTE8 != null)) {
                                    if (db_STG_PAYMENT_METHOD_CODE.equals(db_STG_ATTRIBUTE8)) {
                                        String cons_INVOICE_CURRENCY_CODE = ",ATTRIBUTE8," + db_STG_PAYMENT_METHOD_CODE + "," + db_STG_ATTRIBUTE8 + ",Pass";
                                        section1_results.add(cons_INVOICE_CURRENCY_CODE);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ATTRIBUTE8" + "," + db_STG_PAYMENT_METHOD_CODE + "," + db_STG_ATTRIBUTE8 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String cons_INVOICE_CURRENCY_CODE = ",ATTRIBUTE8," + db_STG_PAYMENT_METHOD_CODE + "," + db_STG_ATTRIBUTE8 + ",Fail";
                                        section1_results.add(cons_INVOICE_CURRENCY_CODE);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ATTRIBUTE8" + "," + db_STG_PAYMENT_METHOD_CODE + "," + db_STG_ATTRIBUTE8 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                } else {
                                    String cons_INVOICE_CURRENCY_CODE = ",ATTRIBUTE8," + db_STG_PAYMENT_METHOD_CODE + "," + db_STG_ATTRIBUTE8 + ",Fail";
                                    section1_results.add(cons_INVOICE_CURRENCY_CODE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ATTRIBUTE8" + "," + db_STG_PAYMENT_METHOD_CODE + "," + db_STG_ATTRIBUTE8 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation VENDOR_NAME ---------------
                                if (db_CONS_VENDOR_NAME.equals(db_STG_VENDOR_NAME)) {
                                    String cons_TRANSACTION_TYPE = ",VENDOR_NAME," + db_CONS_VENDOR_NAME + "," + db_STG_VENDOR_NAME + ",Pass";
                                    section1_results.add(cons_TRANSACTION_TYPE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",VENDOR_NAME" + "," + db_CONS_VENDOR_NAME + "," + db_STG_VENDOR_NAME + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_TRANSACTION_TYPE = ",VENDOR_NAME," + db_CONS_VENDOR_NAME + "," + db_STG_VENDOR_NAME + ",Fail";
                                    section1_results.add(cons_TRANSACTION_TYPE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",VENDOR_NAME" + "," + db_CONS_VENDOR_NAME + "," + db_STG_VENDOR_NAME + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation VENDOR_SITE_CODE ---------------
                                if (db_CONS_VENDOR_SITE_CODE.equals(db_STG_VENDOR_SITE_CODE)) {
                                    String cons_TXN_REFERENCE1 = ",VENDOR_SITE_CODE," + db_CONS_VENDOR_SITE_CODE + "," + db_STG_VENDOR_SITE_CODE + ",Pass";
                                    section1_results.add(cons_TXN_REFERENCE1);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",VENDOR_SITE_CODE" + "," + db_CONS_VENDOR_SITE_CODE + "," + db_STG_VENDOR_SITE_CODE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_TXN_REFERENCE1 = ",VENDOR_SITE_CODE," + db_CONS_VENDOR_SITE_CODE + "," + db_STG_VENDOR_SITE_CODE + ",Fail";
                                    section1_results.add(cons_TXN_REFERENCE1);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",VENDOR_SITE_CODE" + "," + db_CONS_VENDOR_SITE_CODE + "," + db_STG_VENDOR_SITE_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation VENDOR_SITE_ID  ---------------
                                if (db_CONS_VENDOR_SITE_ID.equals(db_STG_VENDOR_SITE_ID)) {
                                    String cons_trans_date = ",VENDOR_SITE_ID," + db_CONS_VENDOR_SITE_ID + "," + db_STG_VENDOR_SITE_ID + ",Pass";
                                    section1_results.add(cons_trans_date);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",VENDOR_SITE_ID" + "," + db_CONS_VENDOR_SITE_ID + "," + db_STG_VENDOR_SITE_ID + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_trans_date = ",VENDOR_SITE_ID," + db_CONS_VENDOR_SITE_ID + "," + db_STG_VENDOR_SITE_ID + ",Fail";
                                    section1_results.add(cons_trans_date);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",VENDOR_SITE_ID" + "," + db_CONS_VENDOR_SITE_ID + "," + db_STG_VENDOR_SITE_ID + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }


                                //--------------------  Validation VENDOR_ID ---------------
                                if (db_CONS_VENDOR_ID.equals(db_STG_VENDOR_ID)) {
                                    String cons_channel = ",VENDOR_ID," + db_CONS_VENDOR_ID + "," + db_STG_VENDOR_ID + ",Pass";
                                    section1_results.add(cons_channel);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",VENDOR_ID" + "," + db_CONS_VENDOR_ID + "," + db_STG_VENDOR_ID + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_channel = ",VENDOR_ID," + db_CONS_VENDOR_ID + "," + db_STG_VENDOR_ID + ",Fail";
                                    section1_results.add(cons_channel);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",VENDOR_ID" + "," + db_CONS_VENDOR_ID + "," + db_STG_VENDOR_ID + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation INVOICE_NUM ---------------
                                if (db_CONS_INVOICE_NUM.equals(db_STG_INVOICE_NUM)) {
                                    String cons_third_claim_ref = ",INVOICE_NUM," + db_CONS_INVOICE_NUM + "," + db_STG_INVOICE_NUM + ",Pass";
                                    section1_results.add(cons_third_claim_ref);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",INVOICE_NUM" + "," + db_CONS_INVOICE_NUM + "," + db_STG_INVOICE_NUM + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_third_claim_ref = ",INVOICE_NUM," + db_CONS_INVOICE_NUM + "," + db_STG_INVOICE_NUM + ",Fail";
                                    section1_results.add(cons_third_claim_ref);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",INVOICE_NUM" + "," + db_CONS_INVOICE_NUM + "," + db_STG_INVOICE_NUM + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation DESCRIPTION ---------------
                                if (db_CONS_DESCRIPTION.equals(db_STG_DESCRIPTION)) {
                                    String cons_Payee_type = ",DESCRIPTION," + db_CONS_DESCRIPTION + "," + db_STG_DESCRIPTION + ",Pass";
                                    section1_results.add(cons_Payee_type);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",DESCRIPTION" + "," + db_CONS_DESCRIPTION + "," + db_STG_DESCRIPTION + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_Payee_type = ",DESCRIPTION," + db_CONS_DESCRIPTION + "," + db_STG_DESCRIPTION + ",Fail";
                                    section1_results.add(cons_Payee_type);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",DESCRIPTION" + "," + db_CONS_DESCRIPTION + "," + db_STG_DESCRIPTION + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation INVOICE_DATE ---------------
                                String db_CONS_INVOICE_DATEModified = db_CONS_INVOICE_DATE.substring(0, 10);
                                String db_STG_INVOICE_DATEModified = db_STG_INVOICE_DATE.substring(0, 10);
                                if (db_CONS_INVOICE_DATEModified.equals(db_STG_INVOICE_DATEModified)) {
                                    String cons_payment_method = ",INVOICE_DATE," + db_CONS_INVOICE_DATEModified + "," + db_STG_INVOICE_DATEModified + ",Pass";
                                    section1_results.add(cons_payment_method);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",INVOICE_DATE" + "," + db_CONS_INVOICE_DATEModified + "," + db_STG_INVOICE_DATEModified + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_payment_method = ",INVOICE_DATE," + db_CONS_INVOICE_DATEModified + "," + db_STG_INVOICE_DATEModified + ",Fail";
                                    section1_results.add(cons_payment_method);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",INVOICE_DATE" + "," + db_CONS_INVOICE_DATEModified + "," + db_STG_INVOICE_DATEModified + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation INVOICE_RECEIVED_DATE ---------------
                                if (db_CONS_CREATION_DATE != null && db_STG_INVOICE_RECEIVED_DATE != null) {
                                    String db_CONS_CREATION_DATEModified = db_CONS_CREATION_DATE.substring(0, 10);
                                    String db_STG_INVOICE_RECEIVED_DATEModified = db_STG_INVOICE_RECEIVED_DATE.substring(0, 10);
                                    if (db_CONS_CREATION_DATEModified.equals(db_STG_INVOICE_RECEIVED_DATEModified)) {
                                        String cons_payment_terms = ",INVOICE_RECEIVED_DATE," + db_CONS_CREATION_DATEModified + "," + db_STG_INVOICE_RECEIVED_DATEModified + ",Pass";
                                        section1_results.add(cons_payment_terms);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",INVOICE_RECEIVED_DATE" + "," + db_CONS_CREATION_DATEModified + "," + db_STG_INVOICE_RECEIVED_DATEModified + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String cons_payment_terms = ",INVOICE_RECEIVED_DATE," + db_CONS_CREATION_DATEModified + "," + db_STG_INVOICE_RECEIVED_DATEModified + ",Fail";
                                        section1_results.add(cons_payment_terms);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",INVOICE_RECEIVED_DATE" + "," + db_CONS_CREATION_DATEModified + "," + db_STG_INVOICE_RECEIVED_DATEModified + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                } else {
                                    String cons_payment_terms = ",INVOICE_RECEIVED_DATE," + db_CONS_CREATION_DATE + "," + db_STG_INVOICE_RECEIVED_DATE + ",Fail";
                                    section1_results.add(cons_payment_terms);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",INVOICE_RECEIVED_DATE" + "," + db_CONS_CREATION_DATE + "," + db_STG_INVOICE_RECEIVED_DATE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation BATCH_FKEY ---------------
                                if (db_CONS_BATCH_FKEY.equals(db_STG_BATCH_FKEY)) {
                                    String cons_invoice_number = ",BATCH_FKEY," + db_CONS_BATCH_FKEY + "," + db_STG_BATCH_FKEY + ",Pass";
                                    section1_results.add(cons_invoice_number);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BATCH_FKEY" + "," + db_CONS_BATCH_FKEY + "," + db_STG_BATCH_FKEY + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_invoice_number = ",BATCH_FKEY," + db_CONS_BATCH_FKEY + "," + db_STG_BATCH_FKEY + ",Fail";
                                    section1_results.add(cons_invoice_number);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BATCH_FKEY" + "," + db_CONS_BATCH_FKEY + "," + db_STG_BATCH_FKEY + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation FILE_NAME ---------------
                                if (db_CONS_FILE_NAME.equals(db_STG_FILE_NAME)) {
                                    String cons_invoice_number = ",FILE_NAME," + db_CONS_FILE_NAME + "," + db_STG_FILE_NAME + ",Pass";
                                    section1_results.add(cons_invoice_number);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",FILE_NAME" + "," + db_CONS_FILE_NAME + "," + db_STG_FILE_NAME + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_invoice_number = ",FILE_NAME," + db_CONS_FILE_NAME + "," + db_STG_FILE_NAME + ",Fail";
                                    section1_results.add(cons_invoice_number);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",FILE_NAME" + "," + db_CONS_FILE_NAME + "," + db_STG_FILE_NAME + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation ATTRIBUTE10 ---------------
                                if (db_CONS_ATTRIBUTE10 == null && db_STG_PAYMENT_METHOD_CODE.equals("CHECK")) {
                                    if (db_CONS_ATTRIBUTE15.equals(db_STG_ATTRIBUTE15)) {
                                        String cons_invoice_number = ",ATTRIBUTE15," + db_CONS_ATTRIBUTE15 + "," + db_STG_ATTRIBUTE15 + ",Pass";
                                        section1_results.add(cons_invoice_number);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ATTRIBUTE15" + "," + db_CONS_ATTRIBUTE15 + "," + db_STG_ATTRIBUTE15 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String cons_invoice_number = ",ATTRIBUTE15," + db_CONS_ATTRIBUTE15 + "," + db_STG_ATTRIBUTE15 + ",Fail";
                                        section1_results.add(cons_invoice_number);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ATTRIBUTE15" + "," + db_CONS_ATTRIBUTE15 + "," + db_STG_ATTRIBUTE15 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                } else {
                                    if ((db_CONS_ATTRIBUTE10 != null) && (db_STG_ATTRIBUTE10 != null)) {
                                        if (db_CONS_ATTRIBUTE10.equals(db_STG_ATTRIBUTE10)) {
                                            String cons_invoice_number = ",ATTRIBUTE10," + db_CONS_ATTRIBUTE10 + "," + db_STG_ATTRIBUTE10 + ",Pass";
                                            section1_results.add(cons_invoice_number);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ATTRIBUTE10" + "," + db_CONS_ATTRIBUTE10 + "," + db_STG_ATTRIBUTE10 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String cons_invoice_number = ",ATTRIBUTE10," + db_CONS_ATTRIBUTE10 + "," + db_STG_ATTRIBUTE10 + ",Fail";
                                            section1_results.add(cons_invoice_number);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ATTRIBUTE10" + "," + db_CONS_ATTRIBUTE10 + "," + db_STG_ATTRIBUTE10 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    } else {
                                        String cons_invoice_number = ",ATTRIBUTE10," + db_CONS_ATTRIBUTE10 + "," + db_STG_ATTRIBUTE10 + ",Pass";
                                        section1_results.add(cons_invoice_number);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ATTRIBUTE10" + "," + db_CONS_ATTRIBUTE10 + "," + db_STG_ATTRIBUTE10 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    }
                                }


                                //------------------------Reference table validation---------------------

                                String db_transform_PAYMENT_METHOD_CODE_meaning = "null";
                                String db_transform_V_PAYEE_TYPE_meaning = "null";
                                String db_transform_PAY_GROUP_LOOKUP_CODE_meaning = "null";
                                String db_lookup_CHECK_meaning = "null";
                                String db_lookup_EFT_meaning = "null";
                                String db_lookup_WIRE_meaning = "null";
                                String db_lookup_ATTRIBUTE_CATEGORY_meaning = "null";

                                String RefAPSupplier_paymentMethodCode = connect_db.executeQuery_DB("Reference", "APInvoice_REF_SUPPL_PAYMENTMETHODCODE", "PULSE");
                                String RefAPSupplier_status = connect_db.executeQuery_DB("Reference", "APInvoice_REF_SUPPL_STATUS", "PULSE");
                                String RefAPSupplier_smallBusinessFlag = connect_db.executeQuery_DB("Reference", "APInvoice_REF_SUPPL_SMALLBUSINESSFLAG", "PULSE");
                                String RefAPSupplier_payGroupLookupCode = connect_db.executeQuery_DB("Reference", "APInvoice_REF_SUPPL_PAYGROUPLOOKUPCODE", "PULSE");

                                String PulseAPInvoice_fsh_lookup = connect_db.executeQuery_DB("Lookup", "FSH_LOOKUP", "PULSE");
                                String PulseAPInvoice_fsh_sys_lookup = connect_db.executeQuery_DB("Lookup", "FSH_SYS_LOOKUP", "PULSE");
                                String fsh_source = connect_db.executeQuery_DB("Lookup", "FSH_LOOKUP_SOURCE_PulseAPInvoice", "PULSE");
                                String common_fsh_source = connect_db.executeQuery_DB("Lookup", "COMMON_FSH_LOOKUP_SOURCE_PulseAPInvoice", "PULSE");

                                //---------------- Validate PAYMENT_METHOD_CODE -----------------------
                                SQLResultset = SQLstmt.executeQuery(RefAPSupplier_paymentMethodCode + " WHERE SUPPLIER_SITE = '" + db_STG_VENDOR_SITE_CODE + "' and " + RefAPSupplier_status);
                                //SQLResultset = SQLstmt.executeQuery("Select PAYMENT_METHOD_CODE as paymentMethodCode from DLG_FSH_REF_AP_SUPPLIER where SUPPLIER_SITE = '" + db_STG_VENDOR_SITE_CODE + "' and SUPPLIER_STATUS ='Active' and SUPPLIER_SITE_STATUS='Active'");
                                while (SQLResultset.next()) {
                                    db_transform_PAYMENT_METHOD_CODE_meaning = SQLResultset.getString("paymentMethodCode");
                                    System.out.println("stag count ----" + db_transform_PAYMENT_METHOD_CODE_meaning);
                                }

                                if (db_transform_PAYMENT_METHOD_CODE_meaning.equals("null")) {
                                    String transform_PAYMENT_METHOD_CODE_meaning = ",PAYMENT_METHOD_CODE Ref_Transformation," + "Transformation value not found" + "," + db_STG_PAYMENT_METHOD_CODE + ",Fail";
                                    section1_results.add(transform_PAYMENT_METHOD_CODE_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAYMENT_METHOD_CODE Ref_Transformation" + "," + "Transformation value not found" + "," + db_STG_PAYMENT_METHOD_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_transform_PAYMENT_METHOD_CODE_meaning != null) {
                                    if (db_transform_PAYMENT_METHOD_CODE_meaning.equals(db_STG_PAYMENT_METHOD_CODE)) {
                                        String transform_PAYMENT_METHOD_CODE_meaning = ",PAYMENT_METHOD_CODE Ref_Transformation," + db_transform_PAYMENT_METHOD_CODE_meaning + "," + db_STG_PAYMENT_METHOD_CODE + ",Pass";
                                        section1_results.add(transform_PAYMENT_METHOD_CODE_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAYMENT_METHOD_CODE Ref_Transformation" + "," + db_transform_PAYMENT_METHOD_CODE_meaning + "," + db_STG_PAYMENT_METHOD_CODE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String transform_PAYMENT_METHOD_CODE_meaning = ",PAYMENT_METHOD_CODE Ref_Transformation," + db_transform_PAYMENT_METHOD_CODE_meaning + "," + db_STG_PAYMENT_METHOD_CODE + ",Fail";
                                        section1_results.add(transform_PAYMENT_METHOD_CODE_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAYMENT_METHOD_CODE Ref_Transformation" + "," + db_transform_PAYMENT_METHOD_CODE_meaning + "," + db_STG_PAYMENT_METHOD_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //---------------- Validate ATTRIBUTE_CATEGORY -----------------------
                                if (db_CONS_ATTRIBUTE_CATEGORY != null) {
                                    SQLResultset = SQLstmt.executeQuery(RefAPSupplier_paymentMethodCode + " WHERE SUPPLIER_SITE = '" + db_STG_VENDOR_SITE_CODE + "' and " + RefAPSupplier_status);
                                    //SQLResultset = SQLstmt.executeQuery("Select PAYMENT_METHOD_CODE as paymentMethodCode from DLG_FSH_REF_AP_SUPPLIER where SUPPLIER_SITE = '" + db_STG_VENDOR_SITE_CODE + "' and SUPPLIER_STATUS ='Active' and SUPPLIER_SITE_STATUS='Active'");
                                    while (SQLResultset.next()) {
                                        db_transform_PAYMENT_METHOD_CODE_meaning = SQLResultset.getString("paymentMethodCode");
                                        System.out.println("stag count ----" + db_transform_PAYMENT_METHOD_CODE_meaning);
                                    }

                                    if (db_transform_PAYMENT_METHOD_CODE_meaning.equals("CHECK")) {
                                        SQLResultset = SQLstmt.executeQuery(PulseAPInvoice_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_transform_PAYMENT_METHOD_CODE_meaning + "' and LOOKUP_TYPE = 'ATTRIBUTE_CATEGORY_ERP'" + fsh_source);
                                        //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_transform_PAYMENT_METHOD_CODE_meaning + "' and LOOKUP_TYPE = 'ATTRIBUTE_CATEGORY_ERP' and system = 'PULS' and pattern = 'APInvoice'");
                                        while (SQLResultset.next()) {
                                            db_lookup_CHECK_meaning = SQLResultset.getString("MEANING");
                                        }
                                        if (db_lookup_CHECK_meaning.equals("null")) {
                                            String lookup_source_meaning = ",ATTRIBUTE_CATEGORY lookup_Ref," + "lookup_Ref value not found" + "," + db_STG_ATTRIBUTE_CATEGORY + ",Fail";
                                            section1_results.add(lookup_source_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ATTRIBUTE_CATEGORY Ref_Transformation" + "," + "lookup_Ref value not found" + "," + db_STG_ATTRIBUTE_CATEGORY + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        } else if (db_lookup_CHECK_meaning != null) {
                                            if (db_lookup_CHECK_meaning.equals(db_STG_ATTRIBUTE_CATEGORY)) {
                                                String lookup_source_meaning = ",ATTRIBUTE_CATEGORY lookup_Ref," + db_lookup_CHECK_meaning + "," + db_STG_ATTRIBUTE_CATEGORY + ",Pass";
                                                section1_results.add(lookup_source_meaning);
                                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ATTRIBUTE_CATEGORY Ref_Transformation" + "," + db_lookup_CHECK_meaning + "," + db_STG_ATTRIBUTE_CATEGORY + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String lookup_source_meaning = ",ATTRIBUTE_CATEGORY lookup_Ref," + db_lookup_CHECK_meaning + "," + db_STG_ATTRIBUTE_CATEGORY + ",Fail";
                                                section1_results.add(lookup_source_meaning);
                                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ATTRIBUTE_CATEGORY Ref_Transformation" + "," + db_lookup_CHECK_meaning + "," + db_STG_ATTRIBUTE_CATEGORY + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }
                                        }

                                    } else if (db_transform_PAYMENT_METHOD_CODE_meaning.equals("WIRE")) {
                                        SQLResultset = SQLstmt.executeQuery(PulseAPInvoice_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_transform_PAYMENT_METHOD_CODE_meaning + "' and LOOKUP_TYPE = 'ATTRIBUTE_CATEGORY_ERP'" + fsh_source);
                                        //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_transform_PAYMENT_METHOD_CODE_meaning + "' and LOOKUP_TYPE = 'ATTRIBUTE_CATEGORY' and system = 'PULS' and pattern = 'APInvoice'");
                                        while (SQLResultset.next()) {
                                            db_lookup_WIRE_meaning = SQLResultset.getString("MEANING");
                                        }
                                        if (db_lookup_WIRE_meaning.equals("null")) {
                                            String lookup_source_meaning = ",ATTRIBUTE_CATEGORY lookup_Ref," + "lookup_Ref value not found" + "," + db_STG_ATTRIBUTE_CATEGORY + ",Fail";
                                            section1_results.add(lookup_source_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ATTRIBUTE_CATEGORY Ref_Transformation" + "," + "lookup_Ref value not found" + "," + db_STG_ATTRIBUTE_CATEGORY + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        } else if (db_lookup_WIRE_meaning != null) {
                                            if (db_lookup_WIRE_meaning.equals(db_STG_ATTRIBUTE_CATEGORY)) {
                                                String lookup_source_meaning = ",ATTRIBUTE_CATEGORY lookup_Ref," + db_lookup_WIRE_meaning + "," + db_STG_ATTRIBUTE_CATEGORY + ",Pass";
                                                section1_results.add(lookup_source_meaning);
                                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ATTRIBUTE_CATEGORY Ref_Transformation" + "," + db_lookup_WIRE_meaning + "," + db_STG_ATTRIBUTE_CATEGORY + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String lookup_source_meaning = ",ATTRIBUTE_CATEGORY lookup_Ref," + db_lookup_WIRE_meaning + "," + db_STG_ATTRIBUTE_CATEGORY + ",Fail";
                                                section1_results.add(lookup_source_meaning);
                                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ATTRIBUTE_CATEGORY Ref_Transformation" + "," + db_lookup_WIRE_meaning + "," + db_STG_ATTRIBUTE_CATEGORY + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }
                                        }

                                    } else if (db_transform_PAYMENT_METHOD_CODE_meaning.equals("EFT")) {
                                        SQLResultset = SQLstmt.executeQuery(PulseAPInvoice_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_transform_PAYMENT_METHOD_CODE_meaning + "' and LOOKUP_TYPE = 'ATTRIBUTE_CATEGORY_ERP'" + fsh_source);
                                        //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_transform_PAYMENT_METHOD_CODE_meaning + "' and LOOKUP_TYPE = 'ATTRIBUTE_CATEGORY' and system = 'PULS' and pattern = 'APInvoice'");
                                        while (SQLResultset.next()) {
                                            db_lookup_EFT_meaning = SQLResultset.getString("MEANING");
                                        }
                                        if (db_lookup_EFT_meaning.equals("null")) {
                                            String lookup_source_meaning = ",ATTRIBUTE_CATEGORY lookup_Ref," + "lookup_Ref value not found" + "," + db_STG_ATTRIBUTE_CATEGORY + ",Fail";
                                            section1_results.add(lookup_source_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ATTRIBUTE_CATEGORY Ref_Transformation" + "," + "lookup_Ref value not found" + "," + db_STG_ATTRIBUTE_CATEGORY + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        } else if (db_lookup_EFT_meaning != null) {
                                            if (db_lookup_EFT_meaning.equals(db_STG_ATTRIBUTE_CATEGORY)) {
                                                String lookup_source_meaning = ",ATTRIBUTE_CATEGORY lookup_Ref," + db_lookup_EFT_meaning + "," + db_STG_ATTRIBUTE_CATEGORY + ",Pass";
                                                section1_results.add(lookup_source_meaning);
                                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ATTRIBUTE_CATEGORY Ref_Transformation" + "," + db_lookup_EFT_meaning + "," + db_STG_ATTRIBUTE_CATEGORY + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String lookup_source_meaning = ",ATTRIBUTE_CATEGORY lookup_Ref," + db_lookup_EFT_meaning + "," + db_STG_ATTRIBUTE_CATEGORY + ",Fail";
                                                section1_results.add(lookup_source_meaning);
                                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ATTRIBUTE_CATEGORY Ref_Transformation" + "," + db_lookup_EFT_meaning + "," + db_STG_ATTRIBUTE_CATEGORY + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }
                                        }

                                    } else {
                                        SQLResultset = SQLstmt.executeQuery(PulseAPInvoice_fsh_sys_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'ATTRIBUTE_CATEGORY_ERP'" + fsh_source);
                                        //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'ATTRIBUTE_CATEGORY' and system = 'PULS' and pattern = 'APInvoice'");
                                        while (SQLResultset.next()) {
                                            db_lookup_ATTRIBUTE_CATEGORY_meaning = SQLResultset.getString("MEANING");
                                        }
                                        if (db_lookup_ATTRIBUTE_CATEGORY_meaning.equals("null")) {
                                            String lookup_source_meaning = ",ATTRIBUTE_CATEGORY lookup_Ref," + "lookup_Ref value not found" + "," + db_STG_ATTRIBUTE_CATEGORY + ",Fail";
                                            section1_results.add(lookup_source_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ATTRIBUTE_CATEGORY Ref_Transformation" + "," + "lookup_Ref value not found" + "," + db_STG_ATTRIBUTE_CATEGORY + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        } else if (db_lookup_ATTRIBUTE_CATEGORY_meaning != null) {
                                            if (db_lookup_ATTRIBUTE_CATEGORY_meaning.equals(db_STG_ATTRIBUTE_CATEGORY)) {
                                                String lookup_source_meaning = ",ATTRIBUTE_CATEGORY lookup_Ref," + db_lookup_ATTRIBUTE_CATEGORY_meaning + "," + db_STG_ATTRIBUTE_CATEGORY + ",Pass";
                                                section1_results.add(lookup_source_meaning);
                                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ATTRIBUTE_CATEGORY Ref_Transformation" + "," + db_lookup_ATTRIBUTE_CATEGORY_meaning + "," + db_STG_ATTRIBUTE_CATEGORY + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String lookup_source_meaning = ",ATTRIBUTE_CATEGORY lookup_Ref," + db_lookup_ATTRIBUTE_CATEGORY_meaning + "," + db_STG_ATTRIBUTE_CATEGORY + ",Fail";
                                                section1_results.add(lookup_source_meaning);
                                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ATTRIBUTE_CATEGORY Ref_Transformation" + "," + db_lookup_ATTRIBUTE_CATEGORY_meaning + "," + db_STG_ATTRIBUTE_CATEGORY + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }
                                        }

                                    }
                                } else {
                                    if (db_CONS_ATTRIBUTE_CATEGORY != null && db_STG_ATTRIBUTE_CATEGORY != null) {
                                        if (db_CONS_ATTRIBUTE_CATEGORY.equals(db_STG_ATTRIBUTE_CATEGORY)) {
                                            String cons_invoice_number = ",ATTRIBUTE_CATEGORY," + db_CONS_ATTRIBUTE_CATEGORY + "," + db_STG_ATTRIBUTE_CATEGORY + ",Pass";
                                            section1_results.add(cons_invoice_number);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ATTRIBUTE_CATEGORY" + "," + db_CONS_ATTRIBUTE_CATEGORY + "," + db_STG_ATTRIBUTE_CATEGORY + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String cons_invoice_number = ",ATTRIBUTE_CATEGORY," + db_CONS_ATTRIBUTE_CATEGORY + "," + db_STG_ATTRIBUTE_CATEGORY + ",Fail";
                                            section1_results.add(cons_invoice_number);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ATTRIBUTE_CATEGORY" + "," + db_CONS_ATTRIBUTE_CATEGORY + "," + db_STG_ATTRIBUTE_CATEGORY + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    } else {
                                        String cons_invoice_number = ",ATTRIBUTE_CATEGORY," + db_CONS_ATTRIBUTE_CATEGORY + "," + db_STG_ATTRIBUTE_CATEGORY + ",Pass";
                                        section1_results.add(cons_invoice_number);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ATTRIBUTE_CATEGORY" + "," + db_CONS_ATTRIBUTE_CATEGORY + "," + db_STG_ATTRIBUTE_CATEGORY + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    }
                                }

                                //TODO Defect - V_PAYEE_TYPE is not available in Staging table

                                //---------------- Validate V_PAYEE_TYPE -----------------------
                                String db_transform_smallBusinessFlag_meaning = "null";
                                String db_transform_source_meaning = "null";


                                SQLResultset = SQLstmt.executeQuery(RefAPSupplier_smallBusinessFlag + " WHERE SUPPLIER_SITE = '" + db_STG_VENDOR_SITE_CODE + "' and " + RefAPSupplier_status);
                                //SQLResultset = SQLstmt.executeQuery("Select SMALL_BUSINESS_FLAG as smallBusinessFlag from DLG_FSH_REF_AP_SUPPLIER where SUPPLIER_SITE = '" + db_STG_VENDOR_SITE_CODE + "' and SUPPLIER_STATUS ='Active' and SUPPLIER_SITE_STATUS='Active'");
                                while (SQLResultset.next()) {
                                    db_transform_smallBusinessFlag_meaning = SQLResultset.getString("smallBusinessFlag");
                                    //System.out.println(db_transform_smallBusinessFlag_meaning);
                                }
                                String PulseAPInvoice_source = connect_db.executeQuery_DB("Lookup", "FSH_LOOKUP_PulseAPInvoice_source", "PULSE");
                                SQLResultset = SQLstmt.executeQuery(PulseAPInvoice_source + " WHERE FILE_NAME = '" + xml_file_name + "' and HEADER_ID ='" + list_header.get(i) + "'");
                                //SQLResultset = SQLstmt.executeQuery("Select SOURCE as source from DLG_FSH_STG_COMM_API_HDR WHERE FILE_NAME = '" + xml_file_name + "' and HEADER_ID ='" + list_header.get(i) + "'");
                                while (SQLResultset.next()) {
                                    db_transform_source_meaning = SQLResultset.getString("source");
                                    //System.out.println(db_transform_source_meaning);
                                }
                                db_transform_V_PAYEE_TYPE_meaning = db_transform_source_meaning.concat("-").concat(db_transform_smallBusinessFlag_meaning);

                                if (db_transform_V_PAYEE_TYPE_meaning.equals("null")) {
                                    String transform_V_PAYEE_TYPE_meaning = ",V_PAYEE_TYPE Ref_Transformation," + "Transformation value not found" + "," + db_transform_V_PAYEE_TYPE_meaning + ",Fail";
                                    section1_results.add(transform_V_PAYEE_TYPE_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",V_PAYEE_TYPE Ref_Transformation" + "," + "Transformation value not found" + "," + db_transform_V_PAYEE_TYPE_meaning + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_transform_V_PAYEE_TYPE_meaning != null) {
                                    if (db_transform_V_PAYEE_TYPE_meaning.equals(db_transform_V_PAYEE_TYPE_meaning)) {
                                        String transform_V_PAYEE_TYPE_meaning = ",V_PAYEE_TYPE Ref_Transformation," + db_transform_V_PAYEE_TYPE_meaning + "," + db_transform_V_PAYEE_TYPE_meaning + ",Pass";
                                        section1_results.add(transform_V_PAYEE_TYPE_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",V_PAYEE_TYPE Ref_Transformation" + "," + db_transform_V_PAYEE_TYPE_meaning + "," + db_transform_V_PAYEE_TYPE_meaning + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String transform_V_PAYEE_TYPE_meaning = ",V_PAYEE_TYPE Ref_Transformation," + db_transform_V_PAYEE_TYPE_meaning + "," + db_transform_V_PAYEE_TYPE_meaning + ",Fail";
                                        section1_results.add(transform_V_PAYEE_TYPE_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",V_PAYEE_TYPE Ref_Transformation" + "," + db_transform_V_PAYEE_TYPE_meaning + "," + db_transform_V_PAYEE_TYPE_meaning + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //---------------- Validate PAY_GROUP_LOOKUP_CODE -----------------------

                                SQLResultset = SQLstmt.executeQuery(RefAPSupplier_payGroupLookupCode + " WHERE SUPPLIER_SITE = '" + db_STG_VENDOR_SITE_CODE + "' and " + RefAPSupplier_status);
                                //SQLResultset = SQLstmt.executeQuery("Select PAY_GROUP_LOOKUP_CODE as payGroupLookupCode from DLG_FSH_REF_AP_SUPPLIER where SUPPLIER_SITE = '" + db_STG_VENDOR_SITE_CODE + "' and SUPPLIER_STATUS ='Active' and SUPPLIER_SITE_STATUS='Active'");
                                while (SQLResultset.next()) {
                                    db_transform_PAY_GROUP_LOOKUP_CODE_meaning = SQLResultset.getString("payGroupLookupCode");
                                }
                                if (db_transform_PAY_GROUP_LOOKUP_CODE_meaning.equals("null")) {
                                    String transform_GLOBAL_ATTRIBUTE1_meaning = ",PAY_GROUP_LOOKUP_CODE Ref_Transformation," + "Transformation value not found" + "," + db_STG_PAY_GROUP_LOOKUP_CODE + ",Fail";
                                    section1_results.add(transform_GLOBAL_ATTRIBUTE1_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAY_GROUP_LOOKUP_CODE Ref_Transformation" + "," + "Transformation value not found" + "," + db_STG_PAY_GROUP_LOOKUP_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_transform_PAY_GROUP_LOOKUP_CODE_meaning != null) {
                                    if (db_transform_PAY_GROUP_LOOKUP_CODE_meaning.equals(db_STG_PAY_GROUP_LOOKUP_CODE)) {
                                        String transform_GLOBAL_ATTRIBUTE1_meaning = ",PAY_GROUP_LOOKUP_CODE Ref_Transformation," + db_transform_PAY_GROUP_LOOKUP_CODE_meaning + "," + db_STG_PAY_GROUP_LOOKUP_CODE + ",Pass";
                                        section1_results.add(transform_GLOBAL_ATTRIBUTE1_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAY_GROUP_LOOKUP_CODE Ref_Transformation" + "," + db_transform_PAY_GROUP_LOOKUP_CODE_meaning + "," + db_STG_PAY_GROUP_LOOKUP_CODE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String transform_GLOBAL_ATTRIBUTE1_meaning = ",PAY_GROUP_LOOKUP_CODE Ref_Transformation," + db_transform_PAY_GROUP_LOOKUP_CODE_meaning + "," + db_STG_PAY_GROUP_LOOKUP_CODE + ",Fail";
                                        section1_results.add(transform_GLOBAL_ATTRIBUTE1_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAY_GROUP_LOOKUP_CODE Ref_Transformation" + "," + db_transform_PAY_GROUP_LOOKUP_CODE_meaning + "," + db_STG_PAY_GROUP_LOOKUP_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }


                                //----------------------- STANDARDISATION start here -----------------------------
                                String db_lookup_source_meaning = "null";
                                String db_lookup_GLOBAL_ATTRIBUTE2_meaning = "null";
                                String db_lookup_GLOBAL_ATTRIBUTE3_meaning = "null";
                                String db_lookup_BRAND_meaning = "null";
                                String db_lookup_INVOICE_CURRENCY_CODE_meaning = "null";
                                String db_lookup_ATTRIBUTE11_meaning = "null";
                                String db_lookup_EXCHANGE_RATE_TYPE_meaning = "null";
                                String db_lookup_exchange_rate_type_meaning = "null";
                                String db_lookup_group_lookup_code_meaning = "null";
                                String db_lookup_org_id_meaning = "null";
                                String db_lookup_PAYEE_TYPE_type_meaning = "null";
                                String db_lookup_calc_tax_import_flag_meaning = "null";
                                String db_lookup_underwriter_meaning = "null";
                                String db_lookup_product_meaning = "null";
                                String db_lookup_business_unit_meaning = "null";
                                String db_lookup_brand_meaning = "null";
                                String db_lookup_pay_group_lookup_code_meaning = "null";
                                String db_lookup_attribute13_meaning = "null";


                                //---------------- Validate SOURCE -----------------------
                                SQLResultset = SQLstmt.executeQuery(PulseAPInvoice_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_CONS_AP_SOURCE + "' and LOOKUP_TYPE = 'APSOURCE'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_AP_SOURCE + "' and LOOKUP_TYPE = 'APSOURCE' and system = 'PULS' and pattern = 'APInvoice'");
                                while (SQLResultset.next()) {
                                    db_lookup_source_meaning = SQLResultset.getString("MEANING");
                                }
                                if (db_lookup_source_meaning.equals("null")) {
                                    String lookup_source_meaning = ",SOURCE lookup," + "LookUp value not found" + "," + db_STG_SOURCE + ",Fail";
                                    section1_results.add(lookup_source_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SOURCE lookup" + "," + "LookUp value not found" + "," + db_STG_SOURCE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_lookup_source_meaning != null) {
                                    if (db_lookup_source_meaning.equals(db_STG_SOURCE)) {
                                        String lookup_source_meaning = ",SOURCE lookup," + db_lookup_source_meaning + "," + db_STG_SOURCE + ",Pass";
                                        section1_results.add(lookup_source_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SOURCE lookup" + "," + db_lookup_source_meaning + "," + db_STG_SOURCE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String lookup_source_meaning = ",SOURCE lookup," + db_lookup_source_meaning + "," + db_STG_SOURCE + ",Fail";
                                        section1_results.add(lookup_source_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SOURCE lookup" + "," + db_lookup_source_meaning + "," + db_STG_SOURCE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //TODO defect -  in cons Attribute13- Green Flag Ltd - done
                                //------------------------ BRAND Validation -----------------
                                if (db_CONS_ATTRIBUTE13 == (null)) {
                                    SQLResultset = SQLstmt.executeQuery(PulseAPInvoice_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_CONS_AP_SOURCE + "' and LOOKUP_TYPE = 'BRAND'" + fsh_source);
                                    //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_AP_SOURCE + "' and LOOKUP_TYPE = 'BRAND' and system = 'PULS' and pattern = 'APInvoice'");
                                    while (SQLResultset.next()) {
                                        db_lookup_BRAND_meaning = SQLResultset.getString("MEANING");
                                    }

                                    if (db_lookup_BRAND_meaning.equals("null")) {
                                        String lookup_line_of_business_meaning = ",BRAND lookup," + "LookUp value not found" + "," + db_STG_ATTRIBUTE13 + ",Fail";
                                        section1_results.add(lookup_line_of_business_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BRAND lookup" + "," + "LookUp value not found" + "," + db_STG_ATTRIBUTE13 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_BRAND_meaning != null) {
                                        if (db_lookup_BRAND_meaning.equals(db_STG_ATTRIBUTE13)) {
                                            String lookup_line_of_business_meaning = ",BRAND lookup," + db_lookup_BRAND_meaning + "," + db_STG_ATTRIBUTE13 + ",Pass";
                                            section1_results.add(lookup_line_of_business_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BRAND lookup" + "," + db_lookup_BRAND_meaning + "," + db_STG_ATTRIBUTE13 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String lookup_line_of_business_meaning = ",BRAND lookup," + db_lookup_BRAND_meaning + "," + db_STG_ATTRIBUTE13 + ",Fail";
                                            section1_results.add(lookup_line_of_business_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BRAND lookup" + "," + db_lookup_BRAND_meaning + "," + db_STG_ATTRIBUTE13 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }
                                } else {
                                    if (db_CONS_ATTRIBUTE13 != null && db_STG_ATTRIBUTE13 != null) {
                                        if (db_CONS_ATTRIBUTE13.equals(db_STG_ATTRIBUTE13)) {
                                            String cons_invoice_number = ",ATTRIBUTE13," + db_CONS_ATTRIBUTE13 + "," + db_STG_ATTRIBUTE13 + ",Pass";
                                            section1_results.add(cons_invoice_number);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ATTRIBUTE13" + "," + db_CONS_ATTRIBUTE13 + "," + db_STG_ATTRIBUTE13 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String cons_invoice_number = ",ATTRIBUTE13," + db_CONS_ATTRIBUTE13 + "," + db_STG_ATTRIBUTE13 + ",Fail";
                                            section1_results.add(cons_invoice_number);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ATTRIBUTE13" + "," + db_CONS_ATTRIBUTE13 + "," + db_STG_ATTRIBUTE13 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }
                                }


                                //------------------------ INVOICE_CURRENCY_CODE Validation -----------------
                                if (db_CONS_INVOICE_CURRENCY_CODE == (null)) {
                                    SQLResultset = SQLstmt.executeQuery(PulseAPInvoice_fsh_sys_lookup + " WHERE LOOKUP_CODE = '" + db_CONS_AP_SOURCE + "' and LOOKUP_TYPE = 'INVOICE_CURRENCY_CODE'" + fsh_source);
                                    //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_AP_SOURCE + "' and LOOKUP_TYPE = 'INVOICE_CURRENCY_CODE' and system = 'PULS' and pattern = 'APInvoice'");
                                    while (SQLResultset.next()) {
                                        db_lookup_INVOICE_CURRENCY_CODE_meaning = SQLResultset.getString("MEANING");
                                    }

                                    if (db_lookup_INVOICE_CURRENCY_CODE_meaning.equals("null")) {
                                        String lookup_brand_meaning = ",INVOICE_CURRENCY_CODE lookup," + "LookUp value not found" + "," + db_STG_INVOICE_CURRENCY_CODE + ",Fail";
                                        section1_results.add(lookup_brand_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",INVOICE_CURRENCY_CODE lookup" + "," + "LookUp value not found" + "," + db_STG_INVOICE_CURRENCY_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_INVOICE_CURRENCY_CODE_meaning != null) {
                                        if (db_lookup_INVOICE_CURRENCY_CODE_meaning.equals(db_STG_INVOICE_CURRENCY_CODE)) {
                                            String lookup_brand_meaning = ",INVOICE_CURRENCY_CODE lookup," + db_lookup_INVOICE_CURRENCY_CODE_meaning + "," + db_STG_INVOICE_CURRENCY_CODE + ",Pass";
                                            section1_results.add(lookup_brand_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",INVOICE_CURRENCY_CODE lookup" + "," + db_lookup_INVOICE_CURRENCY_CODE_meaning + "," + db_STG_INVOICE_CURRENCY_CODE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String lookup_brand_meaning = ",INVOICE_CURRENCY_CODE lookup," + db_lookup_INVOICE_CURRENCY_CODE_meaning + "," + db_STG_INVOICE_CURRENCY_CODE + ",Fail";
                                            section1_results.add(lookup_brand_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",INVOICE_CURRENCY_CODE lookup" + "," + db_lookup_INVOICE_CURRENCY_CODE_meaning + "," + db_STG_INVOICE_CURRENCY_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }
                                } else {
                                    String cons_sort_code = ",INVOICE_CURRENCY_CODE lookup," + db_CONS_INVOICE_CURRENCY_CODE + "," + db_STG_INVOICE_CURRENCY_CODE + ",Pass";
                                    section1_results.add(cons_sort_code);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",INVOICE_CURRENCY_CODE lookup" + "," + db_CONS_INVOICE_CURRENCY_CODE + "," + db_STG_INVOICE_CURRENCY_CODE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                }

                                //------------------------ EXCHANGE_RATE_TYPE Validation -----------------

                                if (db_CONS_EXCHANGE_RATE_TYPE != null) {
                                    SQLResultset = SQLstmt.executeQuery(PulseAPInvoice_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_CONS_EXCHANGE_RATE_TYPE + "' and LOOKUP_TYPE = 'EXCHANGE_RATE_TYPE'" + fsh_source);
                                    //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_EXCHANGE_RATE_TYPE + "' and LOOKUP_TYPE = 'EXCHANGE_RATE_TYPE' and system = 'PULS' and pattern = 'APInvoice'");
                                    while (SQLResultset.next()) {
                                        db_lookup_EXCHANGE_RATE_TYPE_meaning = SQLResultset.getString("MEANING");
                                    }

                                    if (db_lookup_EXCHANGE_RATE_TYPE_meaning.equals("null")) {
                                        String lookup_line_payee_type_meaning = ",EXCHANGE_RATE_TYPE lookup," + "LookUp value not found" + "," + db_STG_EXCHANGE_RATE_TYPE + ",Fail";
                                        section1_results.add(lookup_line_payee_type_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",EXCHANGE_RATE_TYPE lookup" + "," + "LookUp value not found" + "," + db_STG_EXCHANGE_RATE_TYPE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_EXCHANGE_RATE_TYPE_meaning != null) {
                                        if (db_lookup_EXCHANGE_RATE_TYPE_meaning.equals(db_STG_EXCHANGE_RATE_TYPE)) {
                                            String lookup_line_payee_type_meaning = ",EXCHANGE_RATE_TYPE lookup," + db_lookup_EXCHANGE_RATE_TYPE_meaning + "," + db_STG_EXCHANGE_RATE_TYPE + ",Pass";
                                            section1_results.add(lookup_line_payee_type_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",EXCHANGE_RATE_TYPE lookup" + "," + db_lookup_EXCHANGE_RATE_TYPE_meaning + "," + db_STG_EXCHANGE_RATE_TYPE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String lookup_line_payee_type_meaning = ",EXCHANGE_RATE_TYPE lookup," + db_lookup_EXCHANGE_RATE_TYPE_meaning + "," + db_STG_EXCHANGE_RATE_TYPE + ",Fail";
                                            section1_results.add(lookup_line_payee_type_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",EXCHANGE_RATE_TYPE lookup" + "," + db_lookup_EXCHANGE_RATE_TYPE_meaning + "," + db_STG_EXCHANGE_RATE_TYPE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }
                                } else if (db_CONS_EXCHANGE_RATE_TYPE == null) {
                                    String lookup_brand_meaning = ",EXCHANGE_RATE_TYPE lookup," + db_lookup_EXCHANGE_RATE_TYPE_meaning + "," + db_STG_EXCHANGE_RATE_TYPE + ",Pass";
                                    section1_results.add(lookup_brand_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",EXCHANGE_RATE_TYPE lookup" + "," + db_lookup_EXCHANGE_RATE_TYPE_meaning + "," + db_STG_EXCHANGE_RATE_TYPE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                }

                                //TODO defect - PAYEE_TYPE does not have value in CONS table - done
                                //------------------------ PAYEE_TYPE Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(PulseAPInvoice_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_transform_V_PAYEE_TYPE_meaning + "' and LOOKUP_TYPE = 'PAYEE_TYPE'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_transform_V_PAYEE_TYPE_meaning + "' and LOOKUP_TYPE = 'PAYEE_TYPE' and system = 'PULS' and pattern = 'APInvoice'");
                                while (SQLResultset.next()) {
                                    db_lookup_PAYEE_TYPE_type_meaning = SQLResultset.getString("MEANING");
                                }

                                if (db_lookup_PAYEE_TYPE_type_meaning.equals("null")) {
                                    String lookup_line_payee_type_meaning = ",PAYEE_TYPE lookup," + "LookUp value not found" + "," + db_STG_PAYEE_TYPE + ",Fail";
                                    section1_results.add(lookup_line_payee_type_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAYEE_TYPE lookup" + "," + "LookUp value not found" + "," + db_STG_PAYEE_TYPE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_lookup_PAYEE_TYPE_type_meaning != null) {
                                    if (db_lookup_PAYEE_TYPE_type_meaning.equals(db_STG_PAYEE_TYPE)) {
                                        String lookup_line_payee_type_meaning = ",PAYEE_TYPE lookup," + db_lookup_PAYEE_TYPE_type_meaning + "," + db_STG_PAYEE_TYPE + ",Pass";
                                        section1_results.add(lookup_line_payee_type_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAYEE_TYPE lookup" + "," + db_lookup_PAYEE_TYPE_type_meaning + "," + db_STG_PAYEE_TYPE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String lookup_line_payee_type_meaning = ",PAYEE_TYPE lookup," + db_lookup_PAYEE_TYPE_type_meaning + "," + db_STG_PAYEE_TYPE + ",Fail";
                                        section1_results.add(lookup_line_payee_type_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAYEE_TYPE lookup" + "," + db_lookup_PAYEE_TYPE_type_meaning + "," + db_STG_PAYEE_TYPE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //------------------------ ATTRIBUTE11 Validation -----------------
                                if (db_CONS_ATTRIBUTE11 == null && db_STG_PAYMENT_METHOD_CODE.equals("CHECK")) {
                                    SQLResultset = SQLstmt.executeQuery(PulseAPInvoice_fsh_sys_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'CHEQUE_DELIVERY'" + fsh_source);
                                    //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'CHEQUE_DELIVERY' and system = 'PULS' and pattern = 'APInvoice'");
                                    while (SQLResultset.next()) {
                                        db_lookup_ATTRIBUTE11_meaning = SQLResultset.getString("MEANING");
                                    }

                                    if (db_lookup_ATTRIBUTE11_meaning.equals("null")) {
                                        String lookup_line_product_meaning = ",ATTRIBUTE11 lookup," + "LookUp value not found" + "," + db_STG_ATTRIBUTE11 + ",Fail";
                                        section1_results.add(lookup_line_product_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ATTRIBUTE11 lookup" + "," + "LookUp value not found" + "," + db_STG_ATTRIBUTE11 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_lookup_ATTRIBUTE11_meaning != null) {
                                        if (db_lookup_ATTRIBUTE11_meaning.equals(db_STG_ATTRIBUTE11)) {
                                            String lookup_line_product_meaning = ",ATTRIBUTE11 lookup," + db_lookup_ATTRIBUTE11_meaning + "," + db_STG_ATTRIBUTE11 + ",Pass";
                                            section1_results.add(lookup_line_product_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ATTRIBUTE11 lookup" + "," + db_lookup_ATTRIBUTE11_meaning + "," + db_STG_ATTRIBUTE11 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String lookup_line_product_meaning = ",ATTRIBUTE11 lookup," + db_lookup_ATTRIBUTE11_meaning + "," + db_STG_ATTRIBUTE11 + ",Fail";
                                            section1_results.add(lookup_line_product_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ATTRIBUTE11 lookup" + "," + db_lookup_ATTRIBUTE11_meaning + "," + db_STG_ATTRIBUTE11 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }
                                } else {
                                    if (db_CONS_ATTRIBUTE11 != null && db_STG_ATTRIBUTE11 != null) {
                                        if (db_CONS_ATTRIBUTE11.equals(db_STG_ATTRIBUTE11)) {
                                            String cons_invoice_number = ",ATTRIBUTE11," + db_CONS_ATTRIBUTE11 + "," + db_STG_ATTRIBUTE11 + ",Pass";
                                            section1_results.add(cons_invoice_number);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ATTRIBUTE11" + "," + db_CONS_ATTRIBUTE11 + "," + db_STG_ATTRIBUTE11 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String cons_invoice_number = ",ATTRIBUTE11," + db_CONS_ATTRIBUTE11 + "," + db_STG_ATTRIBUTE11 + ",Fail";
                                            section1_results.add(cons_invoice_number);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ATTRIBUTE11" + "," + db_CONS_ATTRIBUTE11 + "," + db_STG_ATTRIBUTE11 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    } else {
                                        String cons_invoice_number = ",ATTRIBUTE11," + db_CONS_ATTRIBUTE11 + "," + db_STG_ATTRIBUTE11 + ",Pass";
                                        section1_results.add(cons_invoice_number);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ATTRIBUTE11" + "," + db_CONS_ATTRIBUTE11 + "," + db_STG_ATTRIBUTE11 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    }
                                }

                                //------------------------ CALC_TAX_DURING_IMPORT_FLAG Validation -----------------
                                int db_STG_FSH_ATTRIBUTE_07_update =Integer.parseInt(db_STG_FSH_ATTRIBUTE_07);

                                if(db_STG_FSH_ATTRIBUTE_07_update >= 1) {
                                    SQLResultset = SQLstmt.executeQuery(PulseAPInvoice_fsh_sys_lookup + " WHERE LOOKUP_CODE = 'YES' and LOOKUP_TYPE = 'CALC_TAX_DURING_IMPORT_FLAG'" + common_fsh_source);
                                    //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'CALC_TAX_DURING_IMPORT_FLAG' and system = 'COMMON' and pattern = 'APInvoice'");
                                    while (SQLResultset.next()) {
                                        db_lookup_calc_tax_import_flag_meaning = SQLResultset.getString("MEANING");
                                    }
                                } else {
                                    SQLResultset = SQLstmt.executeQuery(PulseAPInvoice_fsh_sys_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'CALC_TAX_DURING_IMPORT_FLAG'" + fsh_source);
                                    //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'CALC_TAX_DURING_IMPORT_FLAG' and system = 'PULS' and pattern = 'APInvoice'");
                                    while (SQLResultset.next()) {
                                        db_lookup_calc_tax_import_flag_meaning = SQLResultset.getString("MEANING");
                                    }
                                }

                                if (db_lookup_calc_tax_import_flag_meaning.equals("null")) {
                                    String lookup_calc_tax_import_flag_meaning = ",CALC_TAX_DURING_IMPORT_FLAG lookup," + "LookUp value not found" + "," + db_STG_CALC_TAX_DURING_IMPORT_FLAG + ",Fail";
                                    section1_results.add(lookup_calc_tax_import_flag_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CALC_TAX_DURING_IMPORT_FLAG lookup" + "," + "LookUp value not found" + "," + db_STG_CALC_TAX_DURING_IMPORT_FLAG + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_lookup_calc_tax_import_flag_meaning != null) {
                                    if (db_lookup_calc_tax_import_flag_meaning.equals(db_STG_CALC_TAX_DURING_IMPORT_FLAG)) {
                                        String lookup_calc_tax_import_flag_meaning = ",CALC_TAX_DURING_IMPORT_FLAG lookup," + db_lookup_calc_tax_import_flag_meaning + "," + db_STG_CALC_TAX_DURING_IMPORT_FLAG + ",Pass";
                                        section1_results.add(lookup_calc_tax_import_flag_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CALC_TAX_DURING_IMPORT_FLAG lookup" + "," + db_lookup_calc_tax_import_flag_meaning + "," + db_STG_CALC_TAX_DURING_IMPORT_FLAG + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String lookup_calc_tax_import_flag_meaning = ",CALC_TAX_DURING_IMPORT_FLAG lookup," + db_lookup_calc_tax_import_flag_meaning + "," + db_STG_CALC_TAX_DURING_IMPORT_FLAG + ",Fail";
                                        section1_results.add(lookup_calc_tax_import_flag_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CALC_TAX_DURING_IMPORT_FLAG lookup" + "," + db_lookup_calc_tax_import_flag_meaning + "," + db_STG_CALC_TAX_DURING_IMPORT_FLAG + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }


                                /*//------------------------ ORG_ID Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(PulseAPInvoice_fsh_sys_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'ORG_ID'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'ORG_ID' and system = 'PULS' and pattern = 'APInvoice'");
                                while (SQLResultset.next()) {
                                    db_lookup_org_id_meaning = SQLResultset.getString("MEANING");
                                }

                                if (db_lookup_org_id_meaning.equals("null")) {
                                    String lookup_org_id_meaning = ",ORG_ID lookup," + "LookUp value not found" + "," + db_STG_ORG_ID + ",Fail";
                                    section1_results.add(lookup_org_id_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ORG_ID lookup" + "," + "LookUp value not found" + "," + db_STG_ORG_ID + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_lookup_org_id_meaning != null) {
                                    if (db_lookup_org_id_meaning.equals(db_STG_ORG_ID)) {
                                        String lookup_org_id_meaning = ",ORG_ID lookup," + db_lookup_org_id_meaning + "," + db_STG_ORG_ID + ",Pass";
                                        section1_results.add(lookup_org_id_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ORG_ID lookup" + "," + db_lookup_org_id_meaning + "," + db_STG_ORG_ID + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String lookup_org_id_meaning = ",ORG_ID lookup," + db_lookup_org_id_meaning + "," + db_STG_ORG_ID + ",Fail";
                                        section1_results.add(lookup_org_id_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ORG_ID lookup" + "," + db_lookup_org_id_meaning + "," + db_STG_ORG_ID + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }*/

                                //------------------------ BUSINESS_UNIT Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(PulseAPInvoice_fsh_sys_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'BUSINESS_UNIT'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'BUSINESS_UNIT' and system = 'PULS' and pattern = 'APInvoice'");
                                while (SQLResultset.next()) {
                                    db_lookup_business_unit_meaning = SQLResultset.getString("MEANING");
                                }

                                if (db_lookup_business_unit_meaning.equals("null")) {
                                    String lookup_business_unit_meaning = ",BUSINESS_UNIT lookup," + "LookUp value not found" + "," + db_STG_BUSINESS_UNIT + ",Fail";
                                    section1_results.add(lookup_business_unit_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BUSINESS_UNIT lookup" + "," + "LookUp value not found" + "," + db_STG_BUSINESS_UNIT + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_lookup_business_unit_meaning != null) {
                                    if (db_lookup_business_unit_meaning.equals(db_STG_BUSINESS_UNIT)) {
                                        String lookup_business_unit_meaning = ",BUSINESS_UNIT lookup," + db_lookup_business_unit_meaning + "," + db_STG_BUSINESS_UNIT + ",Pass";
                                        section1_results.add(lookup_business_unit_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BUSINESS_UNIT lookup" + "," + db_lookup_business_unit_meaning + "," + db_STG_BUSINESS_UNIT + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String lookup_business_unit_meaning = ",BUSINESS_UNIT lookup," + db_lookup_business_unit_meaning + "," + db_STG_BUSINESS_UNIT + ",Fail";
                                        section1_results.add(lookup_business_unit_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BUSINESS_UNIT lookup" + "," + db_lookup_business_unit_meaning + "," + db_STG_BUSINESS_UNIT + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }


                                //------------------------ GLOBAL_ATTRIBUTE2 Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(PulseAPInvoice_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_CONS_AP_SOURCE + "' and LOOKUP_TYPE = 'UNDERWRITER'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_AP_SOURCE + "' and LOOKUP_TYPE = 'UNDERWRITER' and system = 'PULS' and pattern = 'APInvoice'");
                                while (SQLResultset.next()) {
                                    db_lookup_GLOBAL_ATTRIBUTE2_meaning = SQLResultset.getString("MEANING");
                                }

                                if (db_lookup_GLOBAL_ATTRIBUTE2_meaning.equals("null")) {
                                    String lookup_GLOBAL_ATTRIBUTE2_meaning = ",GLOBAL_ATTRIBUTE2 lookup," + "LookUp value not found" + "," + db_STG_GLOBAL_ATTRIBUTE2 + ",Fail";
                                    section1_results.add(lookup_GLOBAL_ATTRIBUTE2_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",GLOBAL_ATTRIBUTE2 lookup" + "," + "LookUp value not found" + "," + db_STG_GLOBAL_ATTRIBUTE2 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_lookup_GLOBAL_ATTRIBUTE2_meaning != null) {
                                    if (db_lookup_GLOBAL_ATTRIBUTE2_meaning.equals(db_STG_GLOBAL_ATTRIBUTE2)) {
                                        String lookup_GLOBAL_ATTRIBUTE2_meaning = ",GLOBAL_ATTRIBUTE2 lookup," + db_lookup_GLOBAL_ATTRIBUTE2_meaning + "," + db_STG_GLOBAL_ATTRIBUTE2 + ",Pass";
                                        section1_results.add(lookup_GLOBAL_ATTRIBUTE2_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",GLOBAL_ATTRIBUTE2 lookup" + "," + db_lookup_GLOBAL_ATTRIBUTE2_meaning + "," + db_STG_GLOBAL_ATTRIBUTE2 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String lookup_GLOBAL_ATTRIBUTE2_meaning = ",GLOBAL_ATTRIBUTE2 lookup," + db_lookup_GLOBAL_ATTRIBUTE2_meaning + "," + db_STG_GLOBAL_ATTRIBUTE2 + ",Fail";
                                        section1_results.add(lookup_GLOBAL_ATTRIBUTE2_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",GLOBAL_ATTRIBUTE2 lookup" + "," + db_lookup_GLOBAL_ATTRIBUTE2_meaning + "," + db_STG_GLOBAL_ATTRIBUTE2 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //------------------------ GLOBAL_ATTRIBUTE3 Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(PulseAPInvoice_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_CONS_AP_SOURCE + "' and LOOKUP_TYPE = 'PRODUCT'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_AP_SOURCE + "' and LOOKUP_TYPE = 'PRODUCT' and system = 'PULS' and pattern = 'APInvoice'");
                                while (SQLResultset.next()) {
                                    db_lookup_GLOBAL_ATTRIBUTE3_meaning = SQLResultset.getString("MEANING");
                                }

                                if (db_lookup_GLOBAL_ATTRIBUTE3_meaning.equals("null")) {
                                    String lookup_GLOBAL_ATTRIBUTE3_meaning = ",GLOBAL_ATTRIBUTE3 lookup," + "LookUp value not found" + "," + db_STG_GLOBAL_ATTRIBUTE3 + ",Fail";
                                    section1_results.add(lookup_GLOBAL_ATTRIBUTE3_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",GLOBAL_ATTRIBUTE3 lookup" + "," + "LookUp value not found" + "," + db_STG_GLOBAL_ATTRIBUTE3 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_lookup_GLOBAL_ATTRIBUTE3_meaning != null) {
                                    if (db_lookup_GLOBAL_ATTRIBUTE3_meaning.equals(db_STG_GLOBAL_ATTRIBUTE3)) {
                                        String lookup_GLOBAL_ATTRIBUTE3_meaning = ",GLOBAL_ATTRIBUTE3 lookup," + db_lookup_GLOBAL_ATTRIBUTE3_meaning + "," + db_STG_GLOBAL_ATTRIBUTE3 + ",Pass";
                                        section1_results.add(lookup_GLOBAL_ATTRIBUTE3_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",GLOBAL_ATTRIBUTE3 lookup" + "," + db_lookup_GLOBAL_ATTRIBUTE3_meaning + "," + db_STG_GLOBAL_ATTRIBUTE3 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String lookup_GLOBAL_ATTRIBUTE3_meaning = ",GLOBAL_ATTRIBUTE3 lookup," + db_lookup_GLOBAL_ATTRIBUTE3_meaning + "," + db_STG_GLOBAL_ATTRIBUTE3 + ",Fail";
                                        section1_results.add(lookup_GLOBAL_ATTRIBUTE3_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",GLOBAL_ATTRIBUTE3 lookup" + "," + db_lookup_GLOBAL_ATTRIBUTE3_meaning + "," + db_STG_GLOBAL_ATTRIBUTE3 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }


                                //------------------------  Line Item variable Declaration -----------------------------
                                //------------------------  Line Item validation -----------------------------
                                int line_count = 0;
                                ArrayList<String> list_line_id = new ArrayList<String>();
                                String PulseAPInvoice_stglineSqlQuery = connect_db.executeQuery_DB("PULSE_AP", "APInvoice_Stg_line", "PULSE");
                                SQLResultset = SQLstmt.executeQuery(PulseAPInvoice_stglineSqlQuery + "WHERE HEADER_ID = '" + db_STG_HEADER_ID + "' ");
                                //SQLResultset = SQLstmt.executeQuery("SELECT * FROM  DLG_FSH_STG_COMM_API_LIN WHERE  HEADER_ID = '" + db_STG_HEADER_ID + "'");
                                while (SQLResultset.next()) {
                                    list_line_id.add(SQLResultset.getString("LINE_NUMBER"));
                                }

                                for (int i_count = 0; i_count <= list_line_id.size() - 1; i_count++) {
                                    int stg_sub_indent = i_count;
                                    int sub_tag_line = 0;
                                    System.out.println("Line id ---> " + list_line_id.get(i_count));
                                    SQLResultset = SQLstmt.executeQuery(PulseAPInvoice_stglineSqlQuery + "WHERE HEADER_ID = '" + db_STG_HEADER_ID + "' and LINE_NUMBER = '" + list_line_id.get(i_count) + "' ");
                                    //SQLResultset = SQLstmt.executeQuery("SELECT * FROM  DLG_FSH_STG_COMM_API_LIN WHERE  HEADER_ID = '" + db_STG_HEADER_ID + "' and LINE_NUMBER = '" + list_line_id.get(i_count) + "'");
                                    while (SQLResultset.next()) {
                                        db_STG_LINE_SOURCE = SQLResultset.getString("SOURCE");
                                        db_STG_LINE_HEADER_ID = SQLResultset.getString("HEADER_ID");
                                        db_STG_LINE_LINE_ID = SQLResultset.getString("LINE_ID");
                                        //db_STG_LINE_AP_SOURCE = SQLResultset.getString("AP_SOURCE");
                                        db_STG_LINE_INVOICE_ID = SQLResultset.getString("INVOICE_ID");
                                        db_STG_LINE_LINE_NUMBER = SQLResultset.getString("LINE_NUMBER");
                                        db_STG_LINE_LINE_ITEM_AMOUNT = SQLResultset.getString("LINE_ITEM_AMOUNT");
                                        db_STG_LINE_LINE_TYPE_LOOKUP_CODE = SQLResultset.getString("LINE_TYPE_LOOKUP_CODE");
                                        db_STG_LINE_LINE_GROUP_NUMBER = SQLResultset.getString("LINE_GROUP_NUMBER");
                                        db_STG_LINE_CATEGORY = SQLResultset.getString("CATEGORY");
                                        db_STG_LINE_CURRENCY_CODE = SQLResultset.getString("CURRENCY_CODE");
                                        db_STG_LINE_BASE_LINE_ITEM_AMOUNT = SQLResultset.getString("BASE_LINE_ITEM_AMOUNT");
                                        db_STG_LINE_TAX_RATE_CODE = SQLResultset.getString("TAX_RATE_CODE");
                                        STG_LINE_STATUS = SQLResultset.getString("STATUS");
                                        db_STG_LINE_TAX_CODE = SQLResultset.getString("TAX_CODE");
                                        db_STG_LINE_DESCRIPTION = SQLResultset.getString("DESCRIPTION");
                                        db_STG_LINE_AMOUNT_INCLUDES_TAX_FLAG = SQLResultset.getString("AMOUNT_INCLUDES_TAX_FLAG");
                                        //db_STG_LINE_PRORATE_ACROSS_FLAG = SQLResultset.getString("PRORATE_ACROSS_FLAG ");
                                        db_STG_LINE_DIST_CODE_CONCATENATED = SQLResultset.getString("DIST_CODE_CONCATENATED");
                                        db_STG_LINE_BUSINESS_UNIT = SQLResultset.getString("BUSINESS_UNIT");
                                        db_STG_LINE_SUBJECT_REV_CHARGE = SQLResultset.getString("BUSINESS_UNIT");
                                        db_STG_LINE_SEGMENT1 = SQLResultset.getString("SEGMENT1");
                                        db_STG_LINE_SEGMENT2 = SQLResultset.getString("SEGMENT2");
                                        db_STG_LINE_SEGMENT3 = SQLResultset.getString("SEGMENT3");
                                        db_STG_LINE_SEGMENT4 = SQLResultset.getString("SEGMENT4");
                                        db_STG_LINE_SEGMENT5 = SQLResultset.getString("SEGMENT5");
                                        db_STG_LINE_SEGMENT6 = SQLResultset.getString("SEGMENT6");
                                        db_STG_LINE_SEGMENT7 = SQLResultset.getString("SEGMENT7");
                                        db_STG_LINE_SEGMENT8 = SQLResultset.getString("SEGMENT8");
                                        db_STG_LINE_SEGMENT9 = SQLResultset.getString("SEGMENT9");
                                        db_STG_LINE_SEGMENT10 = SQLResultset.getString("SEGMENT10");
                                        db_STG_LINE_ORG_ID = SQLResultset.getString("ORG_ID");
                                        db_STG_LINE_CURRENCY_CODE = SQLResultset.getString("CURRENCY_CODE");
                                        db_STG_LINE_CATEGORY_DERIVED = SQLResultset.getString("CATEGORY_DERIVED");
                                        db_STG_LINE_SUBJECT_REV_CHARGE = SQLResultset.getString("SUBJECT_REV_CHARGE");
                                        db_STG_LINE_LINE_TYPE_LOOKUP_CODE = SQLResultset.getString("LINE_TYPE_LOOKUP_CODE");

                                        String PulseAPInvoice_conslineSqlQuery = connect_db.executeQuery_DB("PULSE_AP", "APInvoice_Cons_line", "PULSE");
                                        SQLResultset = SQLstmt.executeQuery(PulseAPInvoice_conslineSqlQuery + "WHERE HEADER_ID = '" + db_STG_LINE_HEADER_ID + "' and LINE_NUMBER = '" + db_STG_LINE_LINE_NUMBER + "' ");
                                        //SQLResultset = SQLstmt.executeQuery("SELECT * FROM DLG_FSH_CONS_PULS_API_LIN WHERE HEADER_ID = '" + db_STG_LINE_HEADER_ID + "' and LINE_NUMBER = '" + db_STG_LINE_LINE_NUMBER + "'  ");
                                        while (SQLResultset.next()) {
                                            db_CONS_LINE_SOURCE = SQLResultset.getString("SOURCE");
                                            db_CONS_LINE_HEADER_ID = SQLResultset.getString("HEADER_ID");
                                            db_CONS_LINE_LINE_ID = SQLResultset.getString("LINE_ID");
                                            db_CONS_LINE_AP_SOURCE = SQLResultset.getString("AP_SOURCE");
                                            db_CONS_LINE_INVOICE_NUM = SQLResultset.getString("INVOICE_NUM");
                                            db_CONS_LINE_LINE_NUMBER = SQLResultset.getString("LINE_NUMBER");
                                            db_CONS_LINE_LINE_TYPE_LOOKUP_CODE = SQLResultset.getString("LINE_TYPE_LOOKUP_CODE");
                                            db_CONS_LINE_HEADER_ID = SQLResultset.getString("HEADER_ID");
                                            //db_CONS_CATEGORY = SQLResultset.getString("CATEGORY");
                                            db_CONS_LINE_DESCRIPTION = SQLResultset.getString("INVOICE_NUM");
                                            db_CONS_LINE_INVOICE_NUM = SQLResultset.getString("INVOICE_NUM");
                                            db_CONS_LINE_LINE_GROUP_NUMBER = SQLResultset.getString("LINE_GROUP_NUMBER");
                                            //db_CONS_LINE_CATEGORY = SQLResultset.getString("CATEGORY");
                                            db_CONS_LINE_CURRENCY_CODE = SQLResultset.getString("CURRENCY_CODE");
                                            db_CONS_LINE_AMOUNT = SQLResultset.getString("AMOUNT");
                                            db_CONS_LINE_TAX_RATE_CODE = SQLResultset.getString("TAX_RATE_CODE");
                                            CONS_LINE_STATUS = SQLResultset.getString("STATUS");
                                            db_CONS_LINE_DESCRIPTION = SQLResultset.getString("DESCRIPTION");
                                            db_CONS_LINE_LINE_GROUP_NUMBER = SQLResultset.getString("LINE_GROUP_NUMBER");
                                            db_CONS_LINE_AMOUNT_INCLUDES_TAX_FLAG = SQLResultset.getString("AMOUNT_INCLUDES_TAX_FLAG");
                                            //db_CONS_LINE_PRORATE_ACROSS_FLAG = SQLResultset.getString("PRORATE_ACROSS_FLAG ");
                                            db_CONS_LINE_DIST_CODE_CONCATENATED = SQLResultset.getString("DIST_CODE_CONCATENATED");
                                            //db_CONS_LINE_SUBJECT_REV_CHARGE = SQLResultset.getString("SUBJECT_REV_CHARGE");

                                            //Validating mandatory fields in LINE consolidation table
                                            //HEADER_ID - mandatory validation
                                            if ((db_CONS_LINE_HEADER_ID == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String stg_INVOICE_NUM = stg_mandatory_map_row + "," + db_CONS_LINE_LINE_NUMBER + ",LINE HEADER_ID," + "LINE HEADER_ID : " + db_CONS_LINE_HEADER_ID + "," + "LINE HEADER_ID was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section4_results.add(stg_INVOICE_NUM);
                                                stg_mandatory_map_row++;
                                            } else {
                                                String stg_INVOICE_NUM = stg_mandatory_map_row + "," + db_CONS_LINE_LINE_NUMBER + ",LINE HEADER_ID," + "LINE HEADER_ID : " + db_CONS_LINE_HEADER_ID + "," + "LINE HEADER_ID was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section4_results.add(stg_INVOICE_NUM);
                                                stg_mandatory_map_row++;
                                            }

                                            //LINE_NUMBER - mandatory validation
                                            if ((db_CONS_LINE_LINE_NUMBER == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String stg_LINE_NUMBER = "," + ",LINE LINE_NUMBER," + "LINE LINE_NUMBER : " + db_CONS_LINE_LINE_NUMBER + "," + "LINE LINE_NUMBER was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section4_results.add(stg_LINE_NUMBER);
                                            } else {
                                                String stg_LINE_NUMBER = "," + ",LINE LINE_NUMBER," + "LINE LINE_NUMBER : " + db_CONS_LINE_LINE_NUMBER + "," + "LINE LINE_NUMBER was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section4_results.add(stg_LINE_NUMBER);
                                            }


                                            //LINE_ID - mandatory validation
                                            if ((db_CONS_LINE_LINE_ID == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String stg_VENDOR_SITE_ID = "," + ",LINE LINE_ID," + "LINE LINE_ID : " + db_CONS_LINE_LINE_ID + "," + "LINE LINE_ID was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section4_results.add(stg_VENDOR_SITE_ID);
                                            } else {
                                                String stg_VENDOR_SITE_ID = "," + ",LINE LINE_ID," + "LINE LINE_ID : " + db_CONS_LINE_LINE_ID + "," + "LINE LINE_ID was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section4_results.add(stg_VENDOR_SITE_ID);
                                            }


                                            //AP_SOURCE - mandatory validation
                                            if ((db_CONS_LINE_AP_SOURCE == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String stg_CATEGORY = "," + ",LINE AP_SOURCE," + "LINE AP_SOURCE : " + db_CONS_LINE_AP_SOURCE + "," + "LINE AP_SOURCE was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section4_results.add(stg_CATEGORY);
                                            } else {
                                                String stg_CATEGORY = "," + ",LINE AP_SOURCE," + "LINE AP_SOURCE : " + db_CONS_LINE_AP_SOURCE + "," + "LINE AP_SOURCE was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section4_results.add(stg_CATEGORY);
                                            }


                                            //INVOICE_NUM - mandatory validation
                                            if ((db_CONS_LINE_INVOICE_NUM == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String stg_LINE_ITEM_AMOUNT = "," + ",LINE INVOICE_NUM," + "LINE INVOICE_NUM : " + db_CONS_LINE_INVOICE_NUM + "," + "LINE INVOICE_NUM was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section4_results.add(stg_LINE_ITEM_AMOUNT);
                                            } else {
                                                String stg_LINE_ITEM_AMOUNT = "," + ",LINE INVOICE_NUM," + "LINE INVOICE_NUM : " + db_CONS_LINE_INVOICE_NUM + "," + "LINE INVOICE_NUM was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section4_results.add(stg_LINE_ITEM_AMOUNT);
                                            }

                                            //LINE_TYPE_LOOKUP_CODE - mandatory validation
                                            if ((db_CONS_LINE_LINE_TYPE_LOOKUP_CODE == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String stg_CATEGORY = "," + ",LINE LINE_TYPE_LOOKUP_CODE," + "LINE LINE_TYPE_LOOKUP_CODE : " + db_CONS_LINE_LINE_TYPE_LOOKUP_CODE + "," + "LINE LINE_TYPE_LOOKUP_CODE was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section4_results.add(stg_CATEGORY);
                                            } else {
                                                String stg_CATEGORY = "," + ",LINE LINE_TYPE_LOOKUP_CODE," + "LINE LINE_TYPE_LOOKUP_CODE : " + db_CONS_LINE_LINE_TYPE_LOOKUP_CODE + "," + "LINE LINE_TYPE_LOOKUP_CODE was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section4_results.add(stg_CATEGORY);
                                            }


                                            //AMOUNT - mandatory validation
                                            if ((db_CONS_LINE_AMOUNT == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String stg_LINE_ITEM_AMOUNT = "," + ",LINE AMOUNT," + "LINE AMOUNT : " + db_CONS_LINE_AMOUNT + "," + "LINE AMOUNT was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section4_results.add(stg_LINE_ITEM_AMOUNT);
                                            } else {
                                                String stg_LINE_ITEM_AMOUNT = "," + ",LINE AMOUNT," + "LINE AMOUNT : " + db_CONS_LINE_AMOUNT + "," + "LINE AMOUNT was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section4_results.add(stg_LINE_ITEM_AMOUNT);
                                            }

                                            String tbl_line = stg_line_map_row + "." + stg_sub_indent;

                                            //------------- Validate Line HEADER_ID ----------------
                                            if (db_STG_LINE_HEADER_ID.equals(db_CONS_LINE_HEADER_ID)) {
                                                String stg_line_pc_header_id = stg_line_map_row + "." + stg_sub_indent + ",LINE HEADER_ID mapValue," + db_CONS_LINE_HEADER_ID + "," + db_STG_LINE_HEADER_ID + ",Pass";
                                                section1_results.add(stg_line_pc_header_id);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE HEADER_ID mapValue" + "," + db_CONS_LINE_HEADER_ID + "," + db_STG_LINE_HEADER_ID + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                stg_sub_indent++;
                                            } else {
                                                String stg_line_pc_header_id = stg_line_map_row + "." + stg_sub_indent + ",LINE HEADER_ID mapValue," + db_CONS_LINE_HEADER_ID + "," + db_CONS_LINE_HEADER_ID + ",Fail";
                                                section1_results.add(stg_line_pc_header_id);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE HEADER_ID mapValue" + "," + db_CONS_LINE_HEADER_ID + "," + db_STG_LINE_HEADER_ID + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                stg_sub_indent++;
                                                CONS_flag++;
                                            }

                                            //------------- Validate LINE_NUMBER ----------------
                                            if (db_STG_LINE_LINE_NUMBER.equals(db_CONS_LINE_LINE_NUMBER)) {
                                                String stg_line_number = ",LINE_NUMBER mapValue," + db_CONS_LINE_LINE_NUMBER + "," + db_STG_LINE_LINE_NUMBER + ",Pass";
                                                section1_results.add(stg_line_number);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_NUMBER mapValue" + "," + db_CONS_LINE_LINE_NUMBER + "," + db_STG_LINE_LINE_NUMBER + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String stg_line_number = ",LINE_NUMBER mapValue," + db_CONS_LINE_LINE_NUMBER + "," + db_STG_LINE_LINE_NUMBER + ",Fail";
                                                section1_results.add(stg_line_number);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_NUMBER mapValue" + "," + db_CONS_LINE_LINE_NUMBER + "," + db_STG_LINE_LINE_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }

                                            //------------- Validate LINE_ID ----------------
                                            //String[] db_CONS_line_idModified = db_CONS_line_id.split("~");
                                            if (db_STG_LINE_LINE_ID.equals(db_CONS_LINE_LINE_ID)) {
                                                String stg_line_id = ",LINE_ID mapValue," + db_CONS_LINE_LINE_ID + "," + db_STG_LINE_LINE_ID + ",Pass";
                                                section1_results.add(stg_line_id);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_ID mapValue" + "," + db_CONS_LINE_LINE_ID + "," + db_STG_LINE_LINE_ID + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String stg_line_id = ",LINE_ID mapValue," + db_CONS_LINE_LINE_ID + "," + db_STG_LINE_LINE_ID + ",Fail";
                                                section1_results.add(stg_line_id);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_ID mapValue" + "," + db_CONS_LINE_LINE_ID + "," + db_STG_LINE_LINE_ID + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }


                                            //------------- Validate LINE_TYPE_LOOKUP_CODE ----------------
                                            if (db_STG_LINE_CATEGORY.equals(db_CONS_LINE_LINE_TYPE_LOOKUP_CODE)) {
                                                String stg_line_description = ",LINE CATEGORY mapValue," + db_CONS_LINE_LINE_TYPE_LOOKUP_CODE + "," + db_STG_LINE_CATEGORY + ",Pass";
                                                section1_results.add(stg_line_description);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE CATEGORY mapValue" + "," + db_CONS_LINE_LINE_TYPE_LOOKUP_CODE + "," + db_STG_LINE_CATEGORY + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String stg_line_description = ",LINE CATEGORY mapValue," + db_CONS_LINE_LINE_TYPE_LOOKUP_CODE + "," + db_STG_LINE_CATEGORY + ",Fail";
                                                section1_results.add(stg_line_description);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE CATEGORY mapValue" + "," + db_CONS_LINE_LINE_TYPE_LOOKUP_CODE + "," + db_STG_LINE_CATEGORY + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }

                                            //------------- Validate LINE_ITEM_AMOUNT ----------------
                                            if (db_STG_LINE_LINE_ITEM_AMOUNT.equals(db_CONS_LINE_AMOUNT)) {
                                                String stg_line_amount = ",LINE LINE_ITEM_AMOUNT mapValue," + db_CONS_LINE_AMOUNT + "," + db_STG_LINE_LINE_ITEM_AMOUNT + ",Pass";
                                                section1_results.add(stg_line_amount);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE LINE_ITEM_AMOUNT mapValue" + "," + db_CONS_LINE_AMOUNT + "," + db_STG_LINE_LINE_ITEM_AMOUNT + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String stg_line_amount = ",LINE LINE_ITEM_AMOUNT mapValue," + db_CONS_LINE_AMOUNT + "," + db_STG_LINE_LINE_ITEM_AMOUNT + ",Fail";
                                                section1_results.add(stg_line_amount);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE LINE_ITEM_AMOUNT mapValue" + "," + db_CONS_LINE_AMOUNT + "," + db_STG_LINE_LINE_ITEM_AMOUNT + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }

                                            //------------- Validate DESCRIPTION ----------------
                                            if (db_STG_LINE_DESCRIPTION.equals(db_CONS_LINE_DESCRIPTION)) {
                                                String stg_base_line_amount = ",LINE DESCRIPTION mapValue," + db_CONS_LINE_DESCRIPTION + "," + db_STG_LINE_DESCRIPTION + ",Pass";
                                                section1_results.add(stg_base_line_amount);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE DESCRIPTION mapValue" + "," + db_CONS_LINE_DESCRIPTION + "," + db_STG_LINE_DESCRIPTION + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String stg_base_line_amount = ",LINE DESCRIPTION mapValue," + db_CONS_LINE_DESCRIPTION + "," + db_STG_LINE_DESCRIPTION + ",Fail";
                                                section1_results.add(stg_base_line_amount);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE DESCRIPTION mapValue" + "," + db_CONS_LINE_DESCRIPTION + "," + db_STG_LINE_DESCRIPTION + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }


                                            //------------- Validate PRORATE_ACROSS_FLAG ----------------
                                            if (db_STG_LINE_PRORATE_ACROSS_FLAG.equals(db_CONS_LINE_PRORATE_ACROSS_FLAG)) {
                                                String stg_line_partition_id = ",LINE_PRORATE_ACROSS_FLAG mapValue," + db_STG_LINE_PRORATE_ACROSS_FLAG + "," + db_CONS_LINE_PRORATE_ACROSS_FLAG + ",Pass";
                                                section1_results.add(stg_line_partition_id);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_PRORATE_ACROSS_FLAG mapValue" + "," + db_STG_LINE_PRORATE_ACROSS_FLAG + "," + db_CONS_LINE_PRORATE_ACROSS_FLAG + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String stg_line_partition_id = ",LINE_PRORATE_ACROSS_FLAG mapValue," + db_STG_LINE_PRORATE_ACROSS_FLAG + "," + db_CONS_LINE_PRORATE_ACROSS_FLAG + ",Fail";
                                                section1_results.add(stg_line_partition_id);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_PRORATE_ACROSS_FLAG mapValue" + "," + db_STG_LINE_PRORATE_ACROSS_FLAG + "," + db_CONS_LINE_PRORATE_ACROSS_FLAG + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }


                                            //----------------------- LINE STANDARDISATION start here -----------------------------
                                            String db_lookup_LINE_CURRENCY_CODE_meaning = "null";
                                            String db_lookup_LINE_LINE_GROUP_NUMBER_meaning = "null";
                                            String db_lookup_LINE_LINE_TYPE_LOOKUP_CODE_meaning = "null";
                                            String db_lookup_LINE_TAX_RATE_CODE_meaning = "null";
                                            String db_lookup_LINE_DIST_CODE_CONCATENATED_meaning = "null";
                                            String db_lookup_LINE_BUSINESS_UNIT_meaning = "null";
                                            String db_lookup_LINE_ORG_ID_meaning = "null";
                                            String db_lookup_LINE_SEPARATOR_meaning = "null";
                                            String db_lookup_line_segment_meaning = "null";
                                            String db_lookup_line_category_meaning = "null";
                                            String db_lookup_line_tax_code_meaning = "null";
                                            String db_lookup_line_tax_rate_code_meaning = "null";
                                            String db_lookup_LINE_TYPE_LOOKUP_CODE1_meaning = "null";
                                            String db_lookup_LINE_TYPE_LOOKUP_CODE2_meaning = "null";
                                            String db_lookup_line_cost_centre_meaning = "null";
                                            String db_lookup_line_account_code_meaning = "null";

                                            //---------------- Validate LINE CURRENCY_CODE -----------------------
                                            if (db_CONS_LINE_CURRENCY_CODE == null) {
                                                SQLResultset = SQLstmt.executeQuery(PulseAPInvoice_fsh_sys_lookup + " WHERE LOOKUP_CODE = '" + db_CONS_LINE_AP_SOURCE + "' and LOOKUP_TYPE = 'INVOICE_CURRENCY_CODE'" + fsh_source);
                                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_LINE_AP_SOURCE + "' and LOOKUP_TYPE = 'INVOICE_CURRENCY_CODE' and system = 'PULS' and pattern = 'APInvoice'");
                                                while (SQLResultset.next()) {
                                                    db_lookup_LINE_CURRENCY_CODE_meaning = SQLResultset.getString("MEANING");
                                                }
                                                if (db_lookup_LINE_CURRENCY_CODE_meaning.equals("null")) {
                                                    String lookup_org_id_meaning = ",LINE_CURRENCY_CODE lookup," + "LookUp value not found" + "," + db_STG_LINE_CURRENCY_CODE + ",Fail";
                                                    section1_results.add(lookup_org_id_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_CURRENCY_CODE lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_CURRENCY_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                } else if (db_lookup_LINE_CURRENCY_CODE_meaning != null) {
                                                    if (db_lookup_LINE_CURRENCY_CODE_meaning.equals(db_STG_LINE_CURRENCY_CODE)) {
                                                        String lookup_org_id_meaning = ",LINE_CURRENCY_CODE lookup," + db_lookup_LINE_CURRENCY_CODE_meaning + "," + db_STG_LINE_CURRENCY_CODE + ",Pass";
                                                        section1_results.add(lookup_org_id_meaning);
                                                        String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_CURRENCY_CODE lookup" + "," + db_lookup_LINE_CURRENCY_CODE_meaning + "," + db_STG_LINE_CURRENCY_CODE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                        section2_results_tbl.add(tbl_header_id);
                                                    } else {
                                                        String lookup_org_id_meaning = ",LINE_CURRENCY_CODE lookup," + db_lookup_LINE_CURRENCY_CODE_meaning + "," + db_STG_LINE_CURRENCY_CODE + ",Fail";
                                                        section1_results.add(lookup_org_id_meaning);
                                                        String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_CURRENCY_CODE lookup" + "," + db_lookup_LINE_CURRENCY_CODE_meaning + "," + db_STG_LINE_CURRENCY_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                        section2_results_tbl.add(tbl_header_id);
                                                        CONS_flag++;
                                                    }
                                                }
                                            } else if (db_CONS_LINE_CURRENCY_CODE != null) {
                                                if (db_STG_LINE_CURRENCY_CODE.equals(db_CONS_LINE_CURRENCY_CODE)) {
                                                    String stg_line_partition_id = ",LINE_CURRENCY_CODE lookup," + db_CONS_LINE_CURRENCY_CODE + "," + db_STG_LINE_CURRENCY_CODE + ",Pass";
                                                    section1_results.add(stg_line_partition_id);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_CURRENCY_CODE lookup" + "," + db_CONS_LINE_CURRENCY_CODE + "," + db_STG_LINE_CURRENCY_CODE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String stg_line_partition_id = ",LINE_CURRENCY_CODE lookup," + db_CONS_LINE_CURRENCY_CODE + "," + db_STG_LINE_CURRENCY_CODE + ",Fail";
                                                    section1_results.add(stg_line_partition_id);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_CURRENCY_CODE lookup" + "," + db_CONS_LINE_CURRENCY_CODE + "," + db_STG_LINE_CURRENCY_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            }

                                            //TODO Defect - Logic is not clear - done
                                            //---------------- Validate LINE LINE_GROUP_NUMBER -----------------------
                                            if (db_CONS_LINE_LINE_GROUP_NUMBER == null) {
                                                SQLResultset = SQLstmt.executeQuery(PulseAPInvoice_fsh_sys_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'TAX_CODE_PREFIX'" + fsh_source);
                                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'TAX_CODE_PREFIX' and system = 'PULS' and pattern = 'APInvoice'");
                                                while (SQLResultset.next()) {
                                                    db_lookup_LINE_LINE_GROUP_NUMBER_meaning = SQLResultset.getString("MEANING");
                                                }
                                                if (db_lookup_LINE_LINE_GROUP_NUMBER_meaning.equals("null")) {
                                                    String lookup_org_id_meaning = ",LINE_TAX_CODE lookup," + "LookUp value not found" + "," + db_STG_LINE_TAX_CODE + ",Fail";
                                                    section1_results.add(lookup_org_id_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_TAX_CODE lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_TAX_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                } else if (db_lookup_LINE_LINE_GROUP_NUMBER_meaning != null) {
                                                    if (db_lookup_LINE_LINE_GROUP_NUMBER_meaning.equals(db_STG_LINE_TAX_CODE)) {
                                                        String lookup_org_id_meaning = ",LINE_TAX_CODE lookup," + db_lookup_LINE_LINE_GROUP_NUMBER_meaning + "," + db_STG_LINE_TAX_CODE + ",Pass";
                                                        section1_results.add(lookup_org_id_meaning);
                                                        String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_TAX_CODE lookup" + "," + db_lookup_LINE_LINE_GROUP_NUMBER_meaning + "," + db_STG_LINE_TAX_CODE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                        section2_results_tbl.add(tbl_header_id);
                                                    } else {
                                                        String lookup_org_id_meaning = ",LINE_TAX_CODE lookup," + db_lookup_LINE_LINE_GROUP_NUMBER_meaning + "," + db_STG_LINE_TAX_CODE + ",Fail";
                                                        section1_results.add(lookup_org_id_meaning);
                                                        String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_TAX_CODE lookup" + "," + db_lookup_LINE_LINE_GROUP_NUMBER_meaning + "," + db_STG_LINE_TAX_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                        section2_results_tbl.add(tbl_header_id);
                                                        CONS_flag++;
                                                    }
                                                }
                                            } else {
                                                if (db_CONS_LINE_LINE_GROUP_NUMBER != null) {
                                                    SQLResultset = SQLstmt.executeQuery(PulseAPInvoice_fsh_sys_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'TAX_CODE_PREFIX'" + fsh_source);
                                                    //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'TAX_CODE_PREFIX' and system = 'PULS' and pattern = 'APInvoice'");
                                                    while (SQLResultset.next()) {
                                                        db_lookup_LINE_LINE_GROUP_NUMBER_meaning = SQLResultset.getString("MEANING");
                                                    }
                                                    String db_STG_LINE_TAX_CODEModified = db_lookup_LINE_LINE_GROUP_NUMBER_meaning.concat("_").concat(db_CONS_LINE_LINE_GROUP_NUMBER);
                                                    if (db_STG_LINE_TAX_CODEModified.equals("null")) {
                                                        String lookup_org_id_meaning = ",LINE_TAX_CODE lookup," + "LookUp with Additional value not found" + "," + db_STG_LINE_TAX_CODE + ",Fail";
                                                        section1_results.add(lookup_org_id_meaning);
                                                        String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE LINE_TAX_CODE mapvalue" + "," + "LookUp with Additional value not found" + "," + db_STG_LINE_CURRENCY_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                        section2_results_tbl.add(tbl_header_id);
                                                        CONS_flag++;
                                                    } else if (db_STG_LINE_TAX_CODEModified != null) {
                                                        if (db_STG_LINE_TAX_CODEModified.equals(db_STG_LINE_TAX_CODE)) {
                                                            String stg_line_partition_id = ",LINE_TAX_CODE mapvalue," + db_STG_LINE_TAX_CODEModified + "," + db_STG_LINE_TAX_CODE + ",Pass";
                                                            section1_results.add(stg_line_partition_id);
                                                            String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE LINE_TAX_CODE mapvalue" + "," + db_STG_LINE_TAX_CODEModified + "," + db_STG_LINE_TAX_CODE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                            section2_results_tbl.add(tbl_header_id);
                                                        } else {
                                                            String stg_line_partition_id = ",LINE_TAX_CODE mapvalue," + db_STG_LINE_TAX_CODEModified + "," + db_STG_LINE_TAX_CODE + ",Fail";
                                                            section1_results.add(stg_line_partition_id);
                                                            String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE LINE_TAX_CODE mapvalue" + "," + db_STG_LINE_TAX_CODEModified + "," + db_STG_LINE_TAX_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                            section2_results_tbl.add(tbl_header_id);
                                                            CONS_flag++;
                                                        }
                                                    }
                                                }
                                            }

                                            //---------------- Validate LINE LINE_TYPE_LOOKUP_CODE  -----------------------
                                            SQLResultset = SQLstmt.executeQuery(PulseAPInvoice_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_CONS_LINE_LINE_TYPE_LOOKUP_CODE + "' and LOOKUP_TYPE = 'LINE_TYPE_LOOKUP_CODE'" + fsh_source);
                                            //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_LINE_LINE_TYPE_LOOKUP_CODE + "' and LOOKUP_TYPE = 'LINE_TYPE_LOOKUP_CODE' and system = 'PULS' and pattern = 'APInvoice'");
                                            while (SQLResultset.next()) {
                                                db_lookup_LINE_LINE_TYPE_LOOKUP_CODE_meaning = SQLResultset.getString("MEANING");
                                            }
                                            if (db_lookup_LINE_LINE_TYPE_LOOKUP_CODE_meaning.equals("null")) {
                                                String lookup_org_id_meaning = ",LINE LINE_TYPE_LOOKUP_CODE  lookup," + "LookUp value not found" + "," + db_STG_LINE_LINE_TYPE_LOOKUP_CODE + ",Fail";
                                                section1_results.add(lookup_org_id_meaning);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE LINE_TYPE_LOOKUP_CODE lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_LINE_TYPE_LOOKUP_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            } else if (db_lookup_LINE_LINE_TYPE_LOOKUP_CODE_meaning != null) {
                                                if (db_lookup_LINE_LINE_TYPE_LOOKUP_CODE_meaning.equals(db_STG_LINE_LINE_TYPE_LOOKUP_CODE)) {
                                                    String lookup_org_id_meaning = ",LINE LINE_TYPE_LOOKUP_CODE  lookup," + db_lookup_LINE_LINE_TYPE_LOOKUP_CODE_meaning + "," + db_STG_LINE_LINE_TYPE_LOOKUP_CODE + ",Pass";
                                                    section1_results.add(lookup_org_id_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE LINE_TYPE_LOOKUP_CODE lookup" + "," + db_lookup_LINE_LINE_TYPE_LOOKUP_CODE_meaning + "," + db_STG_LINE_LINE_TYPE_LOOKUP_CODE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String lookup_org_id_meaning = ",LINE LINE_TYPE_LOOKUP_CODE  lookup," + db_lookup_LINE_LINE_TYPE_LOOKUP_CODE_meaning + "," + db_STG_LINE_LINE_TYPE_LOOKUP_CODE + ",Fail";
                                                    section1_results.add(lookup_org_id_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE LINE_TYPE_LOOKUP_CODE lookup" + "," + db_lookup_LINE_LINE_TYPE_LOOKUP_CODE_meaning + "," + db_STG_LINE_LINE_TYPE_LOOKUP_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            }

                                            //TODO defect - logic is getting failed because in CONS(EXEMPT VAT), STG(EXEMPT VAT)
                                            //---------------- Validate LINE TAX_RATE_CODE -----------------------
                                            int db_STG_LINE_SUBJECT_REV_CHARGE_update = Integer.parseInt(db_STG_LINE_SUBJECT_REV_CHARGE);
                                            if (db_CONS_LINE_LINE_TYPE_LOOKUP_CODE.equals("TAX")) {
                                                SQLResultset = SQLstmt.executeQuery(PulseAPInvoice_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_CONS_LINE_TAX_RATE_CODE + "' and LOOKUP_TYPE = 'TAX_RATE_CODE'" + fsh_source);
                                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_LINE_TAX_RATE_CODE + "' and LOOKUP_TYPE = 'TAX_RATE_CODE' and system = 'PULS' and pattern = 'APInvoice'");
                                                while (SQLResultset.next()) {
                                                    db_lookup_LINE_TAX_RATE_CODE_meaning = SQLResultset.getString("MEANING");
                                                }
                                                if (db_lookup_LINE_TAX_RATE_CODE_meaning.equals("null")) {
                                                    String lookup_org_id_meaning = ",LINE TAX_RATE_CODE lookup," + "LookUp value not found" + "," + db_STG_LINE_TAX_RATE_CODE + ",Fail";
                                                    section1_results.add(lookup_org_id_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE TAX_RATE_CODE lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_TAX_RATE_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                } else if (db_lookup_LINE_TAX_RATE_CODE_meaning != null) {
                                                    if (db_lookup_LINE_TAX_RATE_CODE_meaning.equals(db_STG_LINE_TAX_RATE_CODE)) {
                                                        String lookup_org_id_meaning = ",LINE TAX_RATE_CODE lookup," + db_lookup_LINE_TAX_RATE_CODE_meaning + "," + db_STG_LINE_TAX_RATE_CODE + ",Pass";
                                                        section1_results.add(lookup_org_id_meaning);
                                                        String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE TAX_RATE_CODE lookup" + "," + db_lookup_LINE_TAX_RATE_CODE_meaning + "," + db_STG_LINE_TAX_RATE_CODE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                        section2_results_tbl.add(tbl_header_id);
                                                    } else {
                                                        String lookup_org_id_meaning = ",LINE TAX_RATE_CODE lookup," + db_lookup_LINE_TAX_RATE_CODE_meaning + "," + db_STG_LINE_TAX_RATE_CODE + ",Fail";
                                                        section1_results.add(lookup_org_id_meaning);
                                                        String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE TAX_RATE_CODE lookup" + "," + db_lookup_LINE_TAX_RATE_CODE_meaning + "," + db_STG_LINE_TAX_RATE_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                        section2_results_tbl.add(tbl_header_id);
                                                        CONS_flag++;
                                                    }
                                                }
                                            } else if (db_CONS_LINE_LINE_TYPE_LOOKUP_CODE.equals("ITEM") && db_STG_LINE_SUBJECT_REV_CHARGE_update >= 1) {
                                                SQLResultset = SQLstmt.executeQuery(PulseAPInvoice_fsh_sys_lookup + " WHERE LOOKUP_CODE = '" + db_STG_FSH_ATTRIBUTE_07 + "' and LOOKUP_TYPE = 'SUBJECT_REV_CHARGE' " + common_fsh_source);
                                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_STG_FSH_ATTRIBUTE_07 + "' and LOOKUP_TYPE = 'SUBJECT_REV_CHARGE' and system = 'PULS' and pattern = 'APInvoice'");
                                                while (SQLResultset.next()) {
                                                    db_lookup_LINE_TAX_RATE_CODE_meaning = SQLResultset.getString("MEANING");
                                                }
                                                if (db_lookup_LINE_TAX_RATE_CODE_meaning.equals("null")) {
                                                    String lookup_org_id_meaning = ",LINE TAX_RATE_CODE lookup," + "LookUp value not found" + "," + db_STG_LINE_TAX_RATE_CODE + ",Fail";
                                                    section1_results.add(lookup_org_id_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE TAX_RATE_CODE lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_TAX_RATE_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                } else if (db_lookup_LINE_TAX_RATE_CODE_meaning != null) {
                                                    if (db_lookup_LINE_TAX_RATE_CODE_meaning.equals(db_STG_LINE_TAX_RATE_CODE)) {
                                                        String lookup_org_id_meaning = ",LINE TAX_RATE_CODE lookup," + db_lookup_LINE_TAX_RATE_CODE_meaning + "," + db_STG_LINE_TAX_RATE_CODE + ",Pass";
                                                        section1_results.add(lookup_org_id_meaning);
                                                        String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE TAX_RATE_CODE lookup" + "," + db_lookup_LINE_TAX_RATE_CODE_meaning + "," + db_STG_LINE_TAX_RATE_CODE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                        section2_results_tbl.add(tbl_header_id);
                                                    } else {
                                                        String lookup_org_id_meaning = ",LINE TAX_RATE_CODE lookup," + db_lookup_LINE_TAX_RATE_CODE_meaning + "," + db_STG_LINE_TAX_RATE_CODE + ",Fail";
                                                        section1_results.add(lookup_org_id_meaning);
                                                        String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE TAX_RATE_CODE lookup" + "," + db_lookup_LINE_TAX_RATE_CODE_meaning + "," + db_STG_LINE_TAX_RATE_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                        section2_results_tbl.add(tbl_header_id);
                                                        CONS_flag++;
                                                    }
                                                }
                                            }
                                            else {
                                                if (db_STG_LINE_TAX_RATE_CODE != null && db_CONS_LINE_TAX_RATE_CODE != null) {
                                                    if (db_STG_LINE_TAX_RATE_CODE.equals(db_CONS_LINE_TAX_RATE_CODE)) {
                                                        String stg_line_partition_id = ",LINE TAX_RATE_CODE mapValue," + db_CONS_LINE_TAX_RATE_CODE + "," + db_STG_LINE_TAX_RATE_CODE + ",Pass";
                                                        section1_results.add(stg_line_partition_id);
                                                        String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE TAX_RATE_CODE mapValue" + "," + db_CONS_LINE_TAX_RATE_CODE + "," + db_STG_LINE_TAX_RATE_CODE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                        section2_results_tbl.add(tbl_header_id);
                                                    } else {
                                                        String stg_line_partition_id = ",LINE TAX_RATE_CODE mapValue," + db_CONS_LINE_TAX_RATE_CODE + "," + db_STG_LINE_TAX_RATE_CODE + ",Fail";
                                                        section1_results.add(stg_line_partition_id);
                                                        String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE TAX_RATE_CODE mapValue" + "," + db_CONS_LINE_TAX_RATE_CODE + "," + db_STG_LINE_TAX_RATE_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                        section2_results_tbl.add(tbl_header_id);
                                                        CONS_flag++;
                                                    }
                                                } else {
                                                    String stg_line_partition_id = ",LINE TAX_RATE_CODE mapValue," + db_CONS_LINE_TAX_RATE_CODE + "," + db_STG_LINE_TAX_RATE_CODE + ",Pass";
                                                    section1_results.add(stg_line_partition_id);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE TAX_RATE_CODE mapValue" + "," + db_CONS_LINE_TAX_RATE_CODE + "," + db_STG_LINE_TAX_RATE_CODE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                }
                                            }

                                            //---------------- Validate LINE DIST_CODE_CONCATENATED -----------------------
                                            if (db_CONS_LINE_LINE_TYPE_LOOKUP_CODE.equals("TAX") && db_CONS_LINE_DIST_CODE_CONCATENATED == null) {
                                                SQLResultset = SQLstmt.executeQuery(PulseAPInvoice_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_CONS_LINE_AP_SOURCE + "' and LOOKUP_TYPE = 'DIST_CODE_CONCATENATED'" + fsh_source);
                                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_LINE_AP_SOURCE + "' and LOOKUP_TYPE = 'DIST_CODE_CONCATENATED' and system = 'PULS' and pattern = 'APInvoice'");
                                                while (SQLResultset.next()) {
                                                    db_lookup_LINE_DIST_CODE_CONCATENATED_meaning = SQLResultset.getString("MEANING");
                                                }
                                                if (db_lookup_LINE_DIST_CODE_CONCATENATED_meaning.equals("null")) {
                                                    String lookup_org_id_meaning = ",LINE DIST_CODE_CONCATENATED lookup," + "LookUp value not found" + "," + db_STG_LINE_DIST_CODE_CONCATENATED + ",Fail";
                                                    section1_results.add(lookup_org_id_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE DIST_CODE_CONCATENATED lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_DIST_CODE_CONCATENATED + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                } else if (db_lookup_LINE_DIST_CODE_CONCATENATED_meaning != null) {
                                                    if (db_lookup_LINE_DIST_CODE_CONCATENATED_meaning.equals(db_STG_LINE_DIST_CODE_CONCATENATED)) {
                                                        String lookup_org_id_meaning = ",LINE DIST_CODE_CONCATENATED lookup," + db_lookup_LINE_DIST_CODE_CONCATENATED_meaning + "," + db_STG_LINE_DIST_CODE_CONCATENATED + ",Pass";
                                                        section1_results.add(lookup_org_id_meaning);
                                                        String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE DIST_CODE_CONCATENATED lookup" + "," + db_lookup_LINE_DIST_CODE_CONCATENATED_meaning + "," + db_STG_LINE_DIST_CODE_CONCATENATED + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                        section2_results_tbl.add(tbl_header_id);
                                                    } else {
                                                        String lookup_org_id_meaning = ",LINE DIST_CODE_CONCATENATED lookup," + db_lookup_LINE_DIST_CODE_CONCATENATED_meaning + "," + db_STG_LINE_DIST_CODE_CONCATENATED + ",Fail";
                                                        section1_results.add(lookup_org_id_meaning);
                                                        String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE DIST_CODE_CONCATENATED lookup" + "," + db_lookup_LINE_DIST_CODE_CONCATENATED_meaning + "," + db_STG_LINE_DIST_CODE_CONCATENATED + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                        section2_results_tbl.add(tbl_header_id);
                                                        CONS_flag++;
                                                    }
                                                }


                                            } else {
                                                if (db_STG_LINE_DIST_CODE_CONCATENATED != null && db_CONS_LINE_DIST_CODE_CONCATENATED != null) {
                                                    if (db_STG_LINE_DIST_CODE_CONCATENATED.equals(db_CONS_LINE_DIST_CODE_CONCATENATED)) {
                                                        String stg_line_partition_id = ",DIST_CODE_CONCATENATED lookup," + db_CONS_LINE_DIST_CODE_CONCATENATED + "," + db_STG_LINE_DIST_CODE_CONCATENATED + ",Pass";
                                                        section1_results.add(stg_line_partition_id);
                                                        String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",DIST_CODE_CONCATENATED lookup" + "," + db_CONS_LINE_DIST_CODE_CONCATENATED + "," + db_STG_LINE_DIST_CODE_CONCATENATED + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                        section2_results_tbl.add(tbl_header_id);
                                                    } else {
                                                        String stg_line_partition_id = ",DIST_CODE_CONCATENATED lookup," + db_CONS_LINE_DIST_CODE_CONCATENATED + "," + db_STG_LINE_DIST_CODE_CONCATENATED + ",Fail";
                                                        section1_results.add(stg_line_partition_id);
                                                        String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",DIST_CODE_CONCATENATED lookup" + "," + db_CONS_LINE_DIST_CODE_CONCATENATED + "," + db_STG_LINE_DIST_CODE_CONCATENATED + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                        section2_results_tbl.add(tbl_header_id);
                                                        CONS_flag++;
                                                    }
                                                } else {
                                                    String stg_line_partition_id = ",DIST_CODE_CONCATENATED lookup," + db_CONS_LINE_DIST_CODE_CONCATENATED + "," + db_STG_LINE_DIST_CODE_CONCATENATED + ",Pass";
                                                    section1_results.add(stg_line_partition_id);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",DIST_CODE_CONCATENATED lookup" + "," + db_CONS_LINE_DIST_CODE_CONCATENATED + "," + db_STG_LINE_DIST_CODE_CONCATENATED + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                }
                                            }

                                            //---------------- Validate LINE SEGMENT1 -----------------------
                                            String[] db_lookup_line_segmentSplit_meaning = new String[10];
                                            SQLResultset = SQLstmt.executeQuery(PulseAPInvoice_fsh_sys_lookup + " WHERE LOOKUP_CODE = 'Seperator' and LOOKUP_TYPE = 'DIST_CODE_CONCATENATED'" + fsh_source);
                                            //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Seperator' and LOOKUP_TYPE = 'DIST_CODE_CONCATENATED' and system = 'PULS' and pattern = 'APInvoice'");
                                            while (SQLResultset.next()) {
                                                db_lookup_LINE_SEPARATOR_meaning = SQLResultset.getString("MEANING");
                                            }

                                            if (db_CONS_LINE_LINE_TYPE_LOOKUP_CODE.equals("TAX")) {
                                                SQLResultset = SQLstmt.executeQuery(PulseAPInvoice_fsh_lookup + " WHERE LOOKUP_TYPE = 'DIST_CODE_CONCATENATED' and Lookup_code='" + db_CONS_AP_SOURCE + "'" + fsh_source);
                                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE  LOOKUP_TYPE = 'DIST_CODE_CONCATENATED' and Lookup_code='" + db_CONS_AP_SOURCE + "' and system = 'PULS' and pattern = 'APInvoice'");
                                                while (SQLResultset.next()) {
                                                    db_lookup_line_segment_meaning = SQLResultset.getString("MEANING");
                                                    db_lookup_line_segmentSplit_meaning = db_lookup_line_segment_meaning.trim().split("\\.");
                                                }

                                            } else if (db_CONS_LINE_LINE_TYPE_LOOKUP_CODE.equals("ITEM")) {
                                                String PulseAPInvoice_distCodeConcatenated = connect_db.executeQuery_DB("Lookup", "FSH_LOOKUP_PulseAPInvoice_distCodeConcatenated", "PULSE");
                                                SQLResultset = SQLstmt.executeQuery(PulseAPInvoice_distCodeConcatenated + " WHERE LINE_TYPE_LOOKUP_CODE='ITEM' and HEADER_ID = '" + db_STG_LINE_HEADER_ID + "'");
                                                //SQLResultset = SQLstmt.executeQuery("SELECT DIST_CODE_CONCATENATED as distCodeConcatenated FROM DLG_FSH_CONS_PULS_API_LIN WHERE  LINE_TYPE_LOOKUP_CODE='ITEM' and HEADER_ID = '" + db_STG_LINE_HEADER_ID + "'");
                                                while (SQLResultset.next()) {
                                                    db_lookup_line_segment_meaning = SQLResultset.getString("distCodeConcatenated");
                                                    db_lookup_line_segmentSplit_meaning = db_lookup_line_segment_meaning.trim().split("\\.");
                                                }

                                            }

                                            if (db_lookup_line_segmentSplit_meaning[0].equals("null")) {
                                                String lookup_segment2_meaning = ",LINE SEGMENT1 lookup," + "LookUp value not found" + "," + db_STG_LINE_SEGMENT1 + ",Fail";
                                                section1_results.add(lookup_segment2_meaning);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT1 lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_SEGMENT1 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            } else if (db_lookup_line_segmentSplit_meaning[0] != null) {
                                                if (db_lookup_line_segmentSplit_meaning[0].equals(db_STG_LINE_SEGMENT1)) {
                                                    String lookup_segment2_meaning = ",LINE SEGMENT1 lookup," + db_lookup_line_segmentSplit_meaning[0] + "," + db_STG_LINE_SEGMENT1 + ",Pass";
                                                    section1_results.add(lookup_segment2_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT1 lookup" + "," + db_lookup_line_segmentSplit_meaning[0] + "," + db_STG_LINE_SEGMENT1 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String lookup_segment2_meaning = ",LINE SEGMENT1 lookup," + db_lookup_line_segmentSplit_meaning[0] + "," + db_STG_LINE_SEGMENT1 + ",Fail";
                                                    section1_results.add(lookup_segment2_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT1 lookup" + "," + db_lookup_line_segmentSplit_meaning[0] + "," + db_STG_LINE_SEGMENT1 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            }

                                            //TODO defect - lookup value(00000) and STG(141099)

                                            //---------------- Validate LINE SEGMENT2 -----------------------

                                            if (db_lookup_line_segmentSplit_meaning[1].equals("null")) {
                                                String lookup_segment2_meaning = ",LINE SEGMENT2 lookup," + "LookUp value not found" + "," + db_STG_LINE_SEGMENT2 + ",Fail";
                                                section1_results.add(lookup_segment2_meaning);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT2 lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_SEGMENT2 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            } else if (db_lookup_line_segmentSplit_meaning[1] != null) {
                                                if (db_lookup_line_segmentSplit_meaning[1].equals(db_STG_LINE_SEGMENT2)) {
                                                    String lookup_segment2_meaning = ",LINE SEGMENT2 lookup," + db_lookup_line_segmentSplit_meaning[1] + "," + db_STG_LINE_SEGMENT2 + ",Pass";
                                                    section1_results.add(lookup_segment2_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT2 lookup" + "," + db_lookup_line_segmentSplit_meaning[1] + "," + db_STG_LINE_SEGMENT2 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String lookup_segment2_meaning = ",LINE SEGMENT2 lookup," + db_lookup_line_segmentSplit_meaning[1] + "," + db_STG_LINE_SEGMENT2 + ",Fail";
                                                    section1_results.add(lookup_segment2_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT2 lookup" + "," + db_lookup_line_segmentSplit_meaning[1] + "," + db_STG_LINE_SEGMENT2 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            }

                                            //TODO defect - lookup value(00000) and STG(23040)

                                            //---------------- Validate LINE SEGMENT3 -----------------------

                                            if (db_lookup_line_segmentSplit_meaning[2].equals("null")) {
                                                String lookup_segment3_meaning = ",LINE SEGMENT3 lookup," + "LookUp value not found" + "," + db_STG_LINE_SEGMENT3 + ",Fail";
                                                section1_results.add(lookup_segment3_meaning);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT3 lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_SEGMENT3 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            } else if (db_lookup_line_segmentSplit_meaning[2] != null) {
                                                if (db_lookup_line_segmentSplit_meaning[2].equals(db_STG_LINE_SEGMENT3)) {
                                                    String lookup_segment3_meaning = ",LINE SEGMENT3 lookup," + db_lookup_line_segmentSplit_meaning[2] + "," + db_STG_LINE_SEGMENT3 + ",Pass";
                                                    section1_results.add(lookup_segment3_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT3 lookup" + "," + db_lookup_line_segmentSplit_meaning[2] + "," + db_STG_LINE_SEGMENT3 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String lookup_segment3_meaning = ",LINE SEGMENT3 lookup," + db_lookup_line_segmentSplit_meaning[2] + "," + db_STG_LINE_SEGMENT3 + ",Fail";
                                                    section1_results.add(lookup_segment3_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT3 lookup" + "," + db_lookup_line_segmentSplit_meaning[2] + "," + db_STG_LINE_SEGMENT3 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            }

                                            //TODO defect - lookup value(00000) and STG(707)

                                            //---------------- Validate LINE SEGMENT4 -----------------------

                                            if (db_lookup_line_segmentSplit_meaning[3].equals("null")) {
                                                String lookup_segment4_meaning = ",LINE SEGMENT4 lookup," + "LookUp value not found" + "," + db_STG_LINE_SEGMENT4 + ",Fail";
                                                section1_results.add(lookup_segment4_meaning);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT4 lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_SEGMENT4 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            } else if (db_lookup_line_segmentSplit_meaning[3] != null) {
                                                if (db_lookup_line_segmentSplit_meaning[3].equals(db_STG_LINE_SEGMENT4)) {
                                                    String lookup_segment4_meaning = ",LINE SEGMENT4 lookup," + db_lookup_line_segmentSplit_meaning[3] + "," + db_STG_LINE_SEGMENT4 + ",Pass";
                                                    section1_results.add(lookup_segment4_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT4 lookup" + "," + db_lookup_line_segmentSplit_meaning[3] + "," + db_STG_LINE_SEGMENT4 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String lookup_segment4_meaning = ",LINE SEGMENT4 lookup," + db_lookup_line_segmentSplit_meaning[3] + "," + db_STG_LINE_SEGMENT4 + ",Fail";
                                                    section1_results.add(lookup_segment4_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT4 lookup" + "," + db_lookup_line_segmentSplit_meaning[3] + "," + db_STG_LINE_SEGMENT4 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            }

                                            //TODO defect - lookup value(00000) and STG(GFL01)

                                            //---------------- Validate LINE SEGMENT5 -----------------------

                                            if (db_lookup_line_segmentSplit_meaning[4].equals("null")) {
                                                String lookup_segment5_meaning = ",LINE SEGMENT5 lookup," + "LookUp value not found" + "," + db_STG_LINE_SEGMENT5 + ",Fail";
                                                section1_results.add(lookup_segment5_meaning);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT5 lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_SEGMENT5 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            } else if (db_lookup_line_segmentSplit_meaning[4] != null) {
                                                if (db_lookup_line_segmentSplit_meaning[4].equals(db_STG_LINE_SEGMENT5)) {
                                                    String lookup_segment5_meaning = ",LINE SEGMENT5 lookup," + db_lookup_line_segmentSplit_meaning[4] + "," + db_STG_LINE_SEGMENT5 + ",Pass";
                                                    section1_results.add(lookup_segment5_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT5 lookup" + "," + db_lookup_line_segmentSplit_meaning[4] + "," + db_STG_LINE_SEGMENT5 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String lookup_segment5_meaning = ",LINE SEGMENT5 lookup," + db_lookup_line_segmentSplit_meaning[4] + "," + db_STG_LINE_SEGMENT5 + ",Fail";
                                                    section1_results.add(lookup_segment5_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT5 lookup" + "," + db_lookup_line_segmentSplit_meaning[4] + "," + db_STG_LINE_SEGMENT5 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            }

                                            //TODO defect - lookup value(00000) and STG(OTH00)

                                            //---------------- Validate LINE SEGMENT6 -----------------------

                                            if (db_lookup_line_segmentSplit_meaning[5].equals("null")) {
                                                String lookup_segment6_meaning = ",LINE SEGMENT6 lookup," + "LookUp value not found" + "," + db_STG_LINE_SEGMENT6 + ",Fail";
                                                section1_results.add(lookup_segment6_meaning);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT6 lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_SEGMENT6 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            } else if (db_lookup_line_segmentSplit_meaning[5] != null) {
                                                if (db_lookup_line_segmentSplit_meaning[5].equals(db_STG_LINE_SEGMENT6)) {
                                                    String lookup_segment6_meaning = ",LINE SEGMENT6 lookup," + db_lookup_line_segmentSplit_meaning[5] + "," + db_STG_LINE_SEGMENT6 + ",Pass";
                                                    section1_results.add(lookup_segment6_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT6 lookup" + "," + db_lookup_line_segmentSplit_meaning[5] + "," + db_STG_LINE_SEGMENT6 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String lookup_segment6_meaning = ",LINE SEGMENT6 lookup," + db_lookup_line_segmentSplit_meaning[5] + "," + db_STG_LINE_SEGMENT6 + ",Fail";
                                                    section1_results.add(lookup_segment6_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT6 lookup" + "," + db_lookup_line_segmentSplit_meaning[5] + "," + db_STG_LINE_SEGMENT6 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            }

                                            //---------------- Validate LINE SEGMENT7 -----------------------

                                            if (db_lookup_line_segmentSplit_meaning[6].equals("null")) {
                                                String lookup_segment7_meaning = ",LINE SEGMENT7 lookup," + "LookUp value not found" + "," + db_STG_LINE_SEGMENT7 + ",Fail";
                                                section1_results.add(lookup_segment7_meaning);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT7 lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_SEGMENT7 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            } else if (db_lookup_line_segmentSplit_meaning[6] != null) {
                                                if (db_lookup_line_segmentSplit_meaning[6].equals(db_STG_LINE_SEGMENT7)) {
                                                    String lookup_segment7_meaning = ",LINE SEGMENT7 lookup," + db_lookup_line_segmentSplit_meaning[6] + "," + db_STG_LINE_SEGMENT7 + ",Pass";
                                                    section1_results.add(lookup_segment7_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT7 lookup" + "," + db_lookup_line_segmentSplit_meaning[6] + "," + db_STG_LINE_SEGMENT7 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String lookup_segment7_meaning = ",LINE SEGMENT7 lookup," + db_lookup_line_segmentSplit_meaning[6] + "," + db_STG_LINE_SEGMENT7 + ",Fail";
                                                    section1_results.add(lookup_segment7_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT7 lookup" + "," + db_lookup_line_segmentSplit_meaning[6] + "," + db_STG_LINE_SEGMENT7 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            }

                                            //---------------- Validate LINE SEGMENT8 -----------------------

                                            if (db_lookup_line_segmentSplit_meaning[7].equals("null")) {
                                                String lookup_segment8_meaning = ",LINE SEGMENT8 lookup," + "LookUp value not found" + "," + db_STG_LINE_SEGMENT8 + ",Fail";
                                                section1_results.add(lookup_segment8_meaning);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT8 lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_SEGMENT8 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            } else if (db_lookup_line_segmentSplit_meaning[7] != null) {
                                                if (db_lookup_line_segmentSplit_meaning[7].equals(db_STG_LINE_SEGMENT8)) {
                                                    String lookup_segment8_meaning = ",LINE SEGMENT8 lookup," + db_lookup_line_segmentSplit_meaning[7] + "," + db_STG_LINE_SEGMENT8 + ",Pass";
                                                    section1_results.add(lookup_segment8_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT8 lookup" + "," + db_lookup_line_segmentSplit_meaning[7] + "," + db_STG_LINE_SEGMENT8 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String lookup_segment8_meaning = ",LINE SEGMENT8 lookup," + db_lookup_line_segmentSplit_meaning[7] + "," + db_STG_LINE_SEGMENT8 + ",Fail";
                                                    section1_results.add(lookup_segment8_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT8 lookup" + "," + db_lookup_line_segmentSplit_meaning[7] + "," + db_STG_LINE_SEGMENT8 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            }

                                            //---------------- Validate LINE SEGMENT9 -----------------------

                                            if (db_lookup_line_segmentSplit_meaning[8].equals("null")) {
                                                String lookup_segment9_meaning = ",LINE SEGMENT9 lookup," + "LookUp value not found" + "," + db_STG_LINE_SEGMENT9 + ",Fail";
                                                section1_results.add(lookup_segment9_meaning);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT9 lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_SEGMENT9 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            } else if (db_lookup_line_segmentSplit_meaning[8] != null) {
                                                if (db_lookup_line_segmentSplit_meaning[8].equals(db_STG_LINE_SEGMENT9)) {
                                                    String lookup_segment9_meaning = ",LINE SEGMENT9 lookup," + db_lookup_line_segmentSplit_meaning[8] + "," + db_STG_LINE_SEGMENT9 + ",Pass";
                                                    section1_results.add(lookup_segment9_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT9 lookup" + "," + db_lookup_line_segmentSplit_meaning[8] + "," + db_STG_LINE_SEGMENT9 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String lookup_segment9_meaning = ",LINE SEGMENT9 lookup," + db_lookup_line_segmentSplit_meaning[8] + "," + db_STG_LINE_SEGMENT9 + ",Fail";
                                                    section1_results.add(lookup_segment9_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT9 lookup" + "," + db_lookup_line_segmentSplit_meaning[8] + "," + db_STG_LINE_SEGMENT9 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            }

                                            //---------------- Validate LINE SEGMENT10 -----------------------

                                            if (db_lookup_line_segmentSplit_meaning[9].equals("null")) {
                                                String lookup_segment10_meaning = ",LINE SEGMENT10 lookup," + "LookUp value not found" + "," + db_STG_LINE_SEGMENT10 + ",Fail";
                                                section1_results.add(lookup_segment10_meaning);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT10 lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_SEGMENT10 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            } else if (db_lookup_line_segmentSplit_meaning[9] != null) {
                                                if (db_lookup_line_segmentSplit_meaning[9].equals(db_STG_LINE_SEGMENT10)) {
                                                    String lookup_segment10_meaning = ",LINE SEGMENT10 lookup," + db_lookup_line_segmentSplit_meaning[9] + "," + db_STG_LINE_SEGMENT10 + ",Pass";
                                                    section1_results.add(lookup_segment10_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT10 lookup" + "," + db_lookup_line_segmentSplit_meaning[9] + "," + db_STG_LINE_SEGMENT10 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String lookup_segment10_meaning = ",LINE SEGMENT10 lookup," + db_lookup_line_segmentSplit_meaning[9] + "," + db_STG_LINE_SEGMENT10 + ",Fail";
                                                    section1_results.add(lookup_segment10_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT10 lookup" + "," + db_lookup_line_segmentSplit_meaning[9] + "," + db_STG_LINE_SEGMENT10 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            }

                                            //---------------- Validate  LINE_SEGMENT1_to_SGMENT10  -----------------------
                                            String LINE_SEGMENT1ToSGMENT10 = (db_STG_LINE_SEGMENT1 + "." + db_STG_LINE_SEGMENT2 + "." + db_STG_LINE_SEGMENT3 + "." + db_STG_LINE_SEGMENT4 + "." + db_STG_LINE_SEGMENT5 + "." + db_STG_LINE_SEGMENT6 + "." + db_STG_LINE_SEGMENT7 + "." + db_STG_LINE_SEGMENT8 + "." + db_STG_LINE_SEGMENT9 + "." + db_STG_LINE_SEGMENT10);

                                            if (LINE_SEGMENT1ToSGMENT10.equals("null")) {
                                                String lookup_LINE_SEGMENT1ToSGMENT10 = ",LINE_SEGMENT1_to_SGMENT10 lookup," + "LookUp value not found" + "," + db_STG_LINE_DIST_CODE_CONCATENATED + ",Fail";
                                                section1_results.add(lookup_LINE_SEGMENT1ToSGMENT10);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE LINE_SEGMENT1_to_SGMENT10 lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_DIST_CODE_CONCATENATED + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            } else if (LINE_SEGMENT1ToSGMENT10 != null) {
                                                if (LINE_SEGMENT1ToSGMENT10.equals(db_STG_LINE_DIST_CODE_CONCATENATED)) {
                                                    String lookup_LINE_SEGMENT1ToSGMENT10 = ",LINE_SEGMENT1_to_SGMENT10 lookup," + LINE_SEGMENT1ToSGMENT10 + "," + db_STG_LINE_DIST_CODE_CONCATENATED + ",Pass";
                                                    section1_results.add(lookup_LINE_SEGMENT1ToSGMENT10);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE LINE_SEGMENT1_to_SGMENT10 lookup" + "," + LINE_SEGMENT1ToSGMENT10 + "," + db_STG_LINE_DIST_CODE_CONCATENATED + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String lookup_LINE_SEGMENT1ToSGMENT10 = ",LINE_SEGMENT1_to_SGMENT10 lookup," + LINE_SEGMENT1ToSGMENT10 + "," + db_STG_LINE_DIST_CODE_CONCATENATED + ",Fail";
                                                    section1_results.add(lookup_LINE_SEGMENT1ToSGMENT10);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE LINE_SEGMENT1_to_SGMENT10 lookup" + "," + LINE_SEGMENT1ToSGMENT10 + "," + db_STG_LINE_DIST_CODE_CONCATENATED + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            }

                                           /* //---------------- Validate LINE ORG_ID -----------------------
                                            SQLResultset = SQLstmt.executeQuery(PulseAPInvoice_fsh_sys_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'ORG_ID'" + fsh_source);
                                            //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'ORG_ID' and system = 'PULS' and pattern = 'APInvoice'");
                                            while (SQLResultset.next()) {
                                                db_lookup_LINE_ORG_ID_meaning = SQLResultset.getString("MEANING");
                                            }
                                            if (db_lookup_LINE_ORG_ID_meaning.equals("null")) {
                                                String lookup_line_cost_centre_meaning = ",LINE ORG_ID lookup," + "LookUp value not found" + "," + db_STG_LINE_ORG_ID + ",Fail";
                                                section1_results.add(lookup_line_cost_centre_meaning);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE ORG_ID lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_ORG_ID + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            } else if (db_lookup_LINE_ORG_ID_meaning != null) {
                                                if (db_lookup_LINE_ORG_ID_meaning.equals(db_STG_LINE_ORG_ID)) {
                                                    String lookup_line_cost_centre_meaning = ",LINE ORG_ID lookup," + db_lookup_LINE_ORG_ID_meaning + "," + db_STG_LINE_ORG_ID + ",Pass";
                                                    section1_results.add(lookup_line_cost_centre_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE ORG_ID lookup" + "," + db_lookup_LINE_ORG_ID_meaning + "," + db_STG_LINE_ORG_ID + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String lookup_line_cost_centre_meaning = ",LINE ORG_ID lookup," + db_lookup_LINE_ORG_ID_meaning + "," + db_STG_LINE_ORG_ID + ",Fail";
                                                    section1_results.add(lookup_line_cost_centre_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE ORG_ID lookup" + "," + db_lookup_LINE_ORG_ID_meaning + "," + db_STG_LINE_ORG_ID + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            }*/

                                            //---------------- Validate LINE BUSINESS_UNIT -----------------------
                                            SQLResultset = SQLstmt.executeQuery(PulseAPInvoice_fsh_sys_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'BUSINESS_UNIT'" + fsh_source);
                                            //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'BUSINESS_UNIT' and system = 'PULS' and pattern = 'APInvoice'");
                                            while (SQLResultset.next()) {
                                                db_lookup_LINE_BUSINESS_UNIT_meaning = SQLResultset.getString("MEANING");
                                            }
                                            if (db_lookup_LINE_BUSINESS_UNIT_meaning.equals("null")) {
                                                String lookup_line_account_code_meaning = ",LINE BUSINESS_UNIT lookup," + "LookUp value not found" + "," + db_STG_LINE_BUSINESS_UNIT + ",Fail";
                                                section1_results.add(lookup_line_account_code_meaning);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE BUSINESS_UNIT lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_BUSINESS_UNIT + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            } else if (db_lookup_LINE_BUSINESS_UNIT_meaning != null) {
                                                if (db_lookup_LINE_BUSINESS_UNIT_meaning.equals(db_STG_LINE_BUSINESS_UNIT)) {
                                                    String lookup_line_account_code_meaning = ",LINE BUSINESS_UNIT lookup," + db_lookup_LINE_BUSINESS_UNIT_meaning + "," + db_STG_LINE_BUSINESS_UNIT + ",Pass";
                                                    section1_results.add(lookup_line_account_code_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE BUSINESS_UNIT lookup" + "," + db_lookup_LINE_BUSINESS_UNIT_meaning + "," + db_STG_LINE_BUSINESS_UNIT + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String lookup_line_account_code_meaning = ",LINE BUSINESS_UNIT lookup," + db_lookup_LINE_BUSINESS_UNIT_meaning + "," + db_STG_LINE_BUSINESS_UNIT + ",Fail";
                                                    section1_results.add(lookup_line_account_code_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE BUSINESS_UNIT lookup" + "," + db_lookup_LINE_BUSINESS_UNIT_meaning + "," + db_STG_LINE_BUSINESS_UNIT + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            }


                                        }


                                    }

                                }


                            }

                        }
                    }
                }

                //----------------- Validate the Over all Status -------------------
                System.out.println("Looping ++  CONS_flag " + CONS_flag);
                String Overall_status = null;
                String Overall_stg_status = null;
                if (CONS_flag > 0) {
                    CONS_STATUS.add("Fail");
                    Overall_status = "Fail";
                } else {
                    CONS_STATUS.add("Pass");
                    Overall_status = "Pass";
                }


                if (CONS_flag > 0) {
                    OverAllStatus.add("Fail");
                } else {
                    OverAllStatus.add("Pass");
                }

                String tbl_summary_filelist = Source + "," + pattern + "," + file_name + "," + "CONS TO STG " + "," + load_date + "," + OverAllStatus + "," + btc_BATCH_PKEY;
                //String tbl_summary_filelist = Source + "," + pattern + "," + file_name + "," + load_dateFormat + "," + "CONST TO STG " + "," + OverAllStatus;
                summary_results_tbl.add(tbl_summary_filelist);


                list.addAll(section1_results);
                list.addAll(section2_results);
                list.addAll(section4_results);


                // ---------------- HTML Report generation ------------------------
                report_generation.report_Test1(section1_results, "Header", xml_file_name, "CONSOLIDATION LAYER - STAGING LAYER", "PULSE_AP_Invoice", "PULSE_AP_Invoice : CONSOLIDATION LAYER - STAGING LAYER", "");
                report_generation.report_Test1(section1_results, "Section2", xml_file_name, "CONSOLIDATION LAYER - STAGING LAYER", "PULSE_AP_Invoice", "PULSE_AP_Invoice : CONSOLIDATION LAYER - STAGING LAYER", "");
                report_generation.report_Test1(section2_results, "Mandatory", xml_file_name, "Mandatory_Check_CONS", "PULSE_AP_Invoice", "PULSE_AP_Invoice : CONSOLIDATION LAYER - STAGING LAYER", "");
                report_generation.report_Test1(section4_results, "Mandatory", xml_file_name, "Mandatory_Check_STG", "PULSE_AP_Invoice", "PULSE_AP_Invoice : CONSOLIDATION LAYER - STAGING LAYER", "");

                table_detail_report.detail_report_tbl(section2_results_tbl);
            }

            state_model.section_method(file_list, CONS_STATUS, "N/A", OverAllStatus, "PULSE_APInvoice_Summary");
            table_summary_report.summary_report_tbl(summary_results_tbl);
        }


    }

}



