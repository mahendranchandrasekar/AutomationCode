package Dashboard_Report;

import java.io.IOException;
import java.sql.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONException;

public class BMS_AR_Receipts {

    static Statement SQLstmt = null;
    static ResultSet SQLResultset = null;

    public static HTML_Report_Generation_DB_EVO report_generation;
    public static HTML_Report_Generation_State_Model_B4C report_generation_state;
    public static SCH_EVO_PC_State_Model_B4C state_model;

    public static Table_Detail_Report table_detail_report;
    public static Table_Summary_Report table_summary_report;
    public static connectDatabase connect_db;

    public static void main(String[] args) throws IOException, SQLException, ParseException, JSONException {
        report_generation = new HTML_Report_Generation_DB_EVO();
        report_generation_state = new HTML_Report_Generation_State_Model_B4C();
        state_model = new SCH_EVO_PC_State_Model_B4C();

        table_detail_report = new Table_Detail_Report();
        table_summary_report = new Table_Summary_Report();
        connect_db = new connectDatabase();

        //----------------------- delete the existing report --------------
        report_generation.clean_report("BMS_ARReceipts.html");
        report_generation_state.clean_report_summary("BMS_ARReceipts_Summary.html");

        //--------------- SIT  database details -------------------
        String URL_SIT1 = "jdbc:oracle:thin:@dcn2dcll11z:1521/FSHTSIT1.gwd.grpinf.net";
        String Username_SIT1 = "FSH_ORA_DATA";
        String password_SIT1 = "vMw5HpJaFy3uD6eW";

        //--------------- EBS  database details -------------------
        String URL_ICSI = "jdbc:oracle:thin:@dcn2ddbx340.gwd.grpinf.net:1618:ICSI";
        String Username_ICSI = "apps";
        String password_ICSI = "apps4icsi";

        List<String> file_list = new ArrayList<String>();
        List<String> list = new ArrayList<String>();
        List<String> section1_results = new ArrayList<String>();
        //List<String> section2_results = new ArrayList<String>();

        List<String> OverAllStatus = new ArrayList<String>();
        List<String> CONS_STATUS = new ArrayList<String>();
        List<String> summary_results_tbl = new ArrayList<String>();

        String[] file_lists = null;
        int section1_map_row = 1;

        //--------------------- Declaring the supporting details for reporting --------------
        String file_name = "null";
        String Source = "ECLI";
        String pattern = "ARReceipts";
        String header = "Header";
        String line = "Line";

        int cons_stg_map_row = 1;
        int stg_line_map_row = 1;
        int cons_mandatory_map_row = 1;
        int line_mandatory_map_row = 1;
        int stg_mandatory_map_row = 1;


        // Consolidation Header table variable
        String db_CONS_INTERFACE_HEADER_PKEY = "null";
        String db_CONS_Batch_Pkey = "null";
        String db_CONS_STATUS = "null";
        String db_CONS_File_Name = "null";
        String db_CONS_SOURCE = "null";
        String db_CONS_BATCH_REF = "null";
        String db_CONS_BATCH_HDR = "null";
        String db_CONS_RECORD_TYPE = "null";
        String db_CONS_FILE_DATE = "null";
        String db_CONS_FILE_SEQ = "null";
        String db_CONS_BATCH_TRL_REF = "null";
        String db_CONS_BATCH_VALUE = "null";
        String db_CONS_BATCH_RECORD_COUNT = "null";
        String load_date = "null";

        Date load_dateFormat = null;
        String btc_BATCH_PKEY = null;

        // Consolidation Line table variable
        String db_CONS_INTERFACE_LINE_PKEY = "null";
        String db_CONS_LINE_INTERFACE_HEADER_FKEY = "null";
        String db_CONS_LINE_Batch_Pkey = "null";
        String db_CONS_LINE_File_Name = "null";
        String db_CONS_LINE_SOURCE = "null";
        String db_CONS_LINE_BATCH_REF = "null";
        String db_CONS_LINE_RECORD_TYPE = "null";
        String db_CONS_LINE_BANKED_DT = "null";
        String db_CONS_LINE_CURRENCY_CODE = "null";
        String db_CONS_LINE_AMOUNT_RECEIVED = "null";
        String db_STG_LINE_CUSTOMER_NUMBER = "null";
        String db_CONS_LINE_PAYMENT_REFERENCE = "null";
        String db_CONS_LINE_INVOICE_REF = "null";
        String db_CONS_LINE_JOB_LINK = "null";
        String db_CONS_LINE_SEQUENCE = "null";
        String db_CONS_LINE_PAYMENT_METHOD = "null";
        String db_CONS_LINE_SITE_REF = "null";
        String db_CONS_LINE_RECEIVED_DT = "null";
        String CONS_LINE_STATUS = "null";


        // Staging Header table variable declaration
        String db_STG_Batch_Pkey = "null";
        String db_STG_ARREC_HEADER_ID = "null";
        String db_STG_INTERFACE_HEADER_FKEY = "null";
        String db_STG_File_Name = "null";
        String db_STG_SOURCE = "null";
        String db_STG_BATCH_SOURCE_NAME = "null";
        String db_STG_SET_OF_BOOKS_ID = "null";
        String db_STG_ORG_ID = "null";
        String db_STG_TRANSMISSION_RECORD_ID = "null";
        String db_STG_TRANSMISSION_HEADER_ID = "null";
        String db_STG_CREATION_DATE = "null";
        String db_STG_LAST_UPDATE_DATE = "null";
        String db_STG_RECORD_TYPE = "null";
        String db_STG_STATUS = "null";
        String db_STG_DESTINATION_ACCOUNT = "null";
        String db_STG_ORIGINATION = "null";
        String db_STG_DEPOSIT_DATE = "null";
        String db_STG_LOCKBOX_NUMBER = "null";


        // Staging line table variable declaration
        String db_STG_LINE_BATCH_FKEY = "null";
        String db_STG_LINE_FILE_NAME = "null";
        String db_STG_LINE_SOURCE = "null";
        String db_STG_LINE_TRANSMISSION_HEADER_ID = "null";
        String db_STG_LINE_RECORD_TYPE = "null";
        String db_STG_LINE_DEPOSIT_DATE = "null";
        String db_STG_LINE_CURRENCY_CODE = "null";
        String db_STG_LINE_REMITTANCE_AMOUNT = "null";
        String db_STG_LINE_CHECK_NUMBER = "null";
        String db_STG_LINE_INVOICE1 = "null";
        String db_STG_LINE_RECEIPT_DATE = "null";
        String db_STG_LINE_ATTRIBUTE1 = "null";
        String db_STG_LINE_ATTRIBUTE2 = "null";
        String db_STG_LINE_RECEIPT_METHOD = "null";
        String db_STG_LINE_BILL_TO_LOCATION = "null";
        String db_STG_LINE_BATCH_AMOUNT = "null";
        String db_STG_LINE_BATCH_RECORD_COUNT = "null";
        String db_STG_LINE_BATCH_NAME = "null";

        String xmlfile_name = "null";
        String xml_file_name1 = null;

        //---------------- Line item -------
        String db_stg_line_id = "null";
        String db_stg_INVOICE_ID = "null";


        //--------------- Consolidation variables decleration ---------
        String db_cons_header_id = "null";


        //-------- Connect to Database --------------
        connect_db.createConnection("DEVTEST4");
        //table_detail_report.detail_report_tbl_delete(connection, Source);


        //------ get the new file from batch control table --------------
        boolean newRecord = true;
        //SQLResultset = SQLstmt.executeQuery("Select distinct file_name from DLG_FSH_CTL_BATCH where Trunc(LOAD_DATE) = TRUNC(SYSDATE-1) and system = 'LAND' and pattern = 'GLPREMIUM'"); LANDGLPremium_20191115130012.xml LANDGLPremium_20191106125232.xml
        String outSQL = connect_db.executeQuery_DB("BATCH", "ARReceipts_batchCtl", "BMS");
        SQLstmt = connect_db.resStatement();

        SQLResultset = SQLstmt.executeQuery(outSQL);
        while (SQLResultset.next()) {
            file_list.add(SQLResultset.getString("FILE_NAME"));
            System.out.println("File name---" + SQLResultset.getString("FILE_NAME"));
            list.addAll(section1_results);
        }


        // ---------------------------------- Get the batch PKEY ----------------------
        String outSQL_bkey = connect_db.executeQuery_DB("BATCH", "ARReceipts_batchCtl_key", "BMS");

        SQLResultset = SQLstmt.executeQuery(outSQL_bkey);
        while (SQLResultset.next()) {
            btc_BATCH_PKEY = SQLResultset.getString("BATCH_PKEY");
        }

        // ---------------------------------- Check the new file ----------------------
        SQLResultset = SQLstmt.executeQuery(outSQL);
        if (!SQLResultset.next()) {
            System.out.println("No new BMS_ARReceipts files have been received to FSH ");
            newRecord = false;
            String nonewfile = ",FILE_NAME," + "No new BMS_ARReceipts files have been received to FSH" + "," + "," + ",Pass";
            section1_results.add(nonewfile);
            list.addAll(section1_results);
        }

        if (newRecord) {

            //------------------------ Section 1 Start Print all the new file in the report-------------------
            for (String num_file : file_list) {
                file_lists = num_file.split(",");
                for (String file_list1 : file_lists) {
                    xml_file_name1 = file_list1;
                    //int section1_map_row = 1;
                    String newfile = section1_map_row + ",FILE_NAME," + xml_file_name1 + "," + xml_file_name1 + ",Pass";
                    section1_map_row++;
                    section1_results.add(newfile);
                }
            }
            list.addAll(section1_results);
            //report_generation.report_Test1(section1_results, "Section1", xml_file_name1, "B4C BC CONS BATCH TABLE VALIDATION", "B4C_SCHBilling", "B4C BC VALIDATION");
            //------------------------ Section 1 End ----------------------------------------------
        }

        List<String> list_header = new ArrayList<String>(); // -- Add all the header id
        if (newRecord) {
            //------------ Split the file names form the list --------------
            for (String xml_file_name : file_list) {
                int section2_map_row = 1;
                int CONS_flag = 0;
                List<String> section2_results = new ArrayList<String>();
                List<String> section3_results = new ArrayList<String>();
                List<String> section2_results_tbl = new ArrayList<String>();

                file_name = xml_file_name;


        /*//------ get the new file from batch control table --------------
        boolean newRecord = true;
        //SQLResultset = SQLstmt.executeQuery("Select distinct file_name from DLG_FSH_CTL_BATCH where Trunc(LOAD_DATE) = TRUNC(SYSDATE-1) and system = 'LAND' and pattern = 'GLPREMIUM'");
        SQLResultset = SQLstmt.executeQuery("Select distinct file_name from DLG_FSH_CTL_BATCH where file_name = 'ECLIARR1910001520191019125900_test8.SL'");
        while (SQLResultset.next()) {
            file_list.add(SQLResultset.getString("FILE_NAME"));
            System.out.println("File name---" + SQLResultset.getString("FILE_NAME"));
            list.addAll(section1_results);
        }

        //------------------ validate no new files -----------------------
        String xmlfile_name = "null";
        //SQLResultset = SQLstmt.executeQuery("Select distinct file_name from DLG_FSH_CTL_BATCH where Trunc(LOAD_DATE) = TRUNC(SYSDATE-1) and system = 'ECLI' and pattern = 'APInvoice' ");
        SQLResultset = SQLstmt.executeQuery("Select distinct file_name from DLG_FSH_CTL_BATCH where file_name = 'ECLIARR1910001520191019125900_test8.SL'");
        if (!SQLResultset.next()) {
            System.out.println("No new BMS AR Receipts files have been received to FSH ");
            newRecord = false;
            String nonewfile = ",FILE_NAME," + "No new BMS AR Receipts files have been received to FSH" + "," + "," + ",Pass";
        }

        List<String> list_header = new ArrayList<String>();
        List<String> list_header1 = new ArrayList<String>();// -- Add all the header id
        if (newRecord) {
            //------------ Split the file names form the list --------------
            for (String xml_file_name : file_list) { */


                //-------------- Validation Cons to Stag table ----------------
                String BMSARReceipts_consSqlQuery = connect_db.executeQuery_DB("BMS_AR", "ARReceipts_Cons", "BMS");
                SQLResultset = SQLstmt.executeQuery(BMSARReceipts_consSqlQuery + "'" + file_name + "'");
                //SQLResultset = SQLstmt.executeQuery("SELECT * from DLG_FSH_CONS_ECLI_ARREC_HDR WHERE FILE_NAME = '" + xml_file_name + "'");
                while (SQLResultset.next()) {
                    db_CONS_BATCH_HDR = SQLResultset.getString("BATCH_HDR");
                    list_header.add(db_CONS_BATCH_HDR);
                }

                for (int i = 0; i < list_header.size(); i++) {
                    SQLResultset = SQLstmt.executeQuery(BMSARReceipts_consSqlQuery + "'" + file_name + "' and BATCH_HDR = '" + list_header.get(i) + "' ");
                    //SQLResultset = SQLstmt.executeQuery("SELECT * from DLG_FSH_CONS_ECLI_ARREC_HDR WHERE FILE_NAME = '" + xml_file_name + "' and INTERFACE_HEADER_PKEY ='" + list_header.get(i) + "'");
                    while (SQLResultset.next()) {
                        db_CONS_INTERFACE_HEADER_PKEY = SQLResultset.getString("INTERFACE_HEADER_PKEY");
                        db_CONS_Batch_Pkey = SQLResultset.getString("Batch_Fkey");
                        db_CONS_STATUS = SQLResultset.getString("STATUS");
                        db_CONS_File_Name = SQLResultset.getString("File_Name");
                        db_CONS_SOURCE = SQLResultset.getString("SOURCE");
                        db_CONS_BATCH_REF = SQLResultset.getString("BATCH_REF");
                        db_CONS_BATCH_HDR = SQLResultset.getString("BATCH_HDR");
                        db_CONS_RECORD_TYPE = SQLResultset.getString("RECORD_TYPE");
                        db_CONS_FILE_DATE = SQLResultset.getString("FILE_DATE");
                        db_CONS_FILE_SEQ = SQLResultset.getString("FILE_SEQ");
                        db_CONS_BATCH_TRL_REF = SQLResultset.getString("BATCH_TRL_REF");
                        db_CONS_BATCH_VALUE = SQLResultset.getString("BATCH_VALUE");
                        db_CONS_BATCH_RECORD_COUNT = SQLResultset.getString("BATCH_RECORD_COUNT");
                        load_date = SQLResultset.getString("LOAD_DATE");
                        String db_file_name = SQLResultset.getString("FILE_NAME");

                        //Converting Load date format
                        String load_dateTRIM = load_date.substring(0, 10);
                        load_dateFormat = Date.valueOf(load_dateTRIM);
                        System.out.println(load_dateFormat);


                        //Validating mandatory fields in consolidation table
                        //Batch_Pkey - mandatory validation
                        if ((db_CONS_Batch_Pkey == null) && (db_CONS_STATUS != "REVIEW")) {

                            String cons_Batch_Pkey = cons_mandatory_map_row + "," + db_CONS_INTERFACE_HEADER_PKEY + ",Batch_Pkey," + "Batch_Pkey : " + db_CONS_Batch_Pkey + "," + "Batch_Pkey was not found," + db_CONS_STATUS + "," + "Fail";
                            section2_results.add(cons_Batch_Pkey);
                            cons_mandatory_map_row++;
                        } else {
                            String cons_Batch_Pkey = cons_mandatory_map_row + "," + db_CONS_INTERFACE_HEADER_PKEY + ",Batch_Pkey," + "Batch_Pkey : " + db_CONS_Batch_Pkey + "," + "Batch_Pkey was found," + db_CONS_STATUS + "," + "Pass";
                            section2_results.add(cons_Batch_Pkey);
                            cons_mandatory_map_row++;
                        }

                        //File_Name - mandatory validation
                        if ((db_CONS_File_Name == null) && (db_CONS_STATUS != "REVIEW")) {

                            String CONS_File_Name = "," + ",File_Name," + "File_Name : " + db_CONS_File_Name + "," + "File_Name was not found," + db_CONS_STATUS + "," + "Fail";
                            section2_results.add(CONS_File_Name);
                        } else {
                            String CONS_File_Name = "," + ",File_Name," + "File_Name : " + db_CONS_File_Name + "," + "File_Name was found," + db_CONS_STATUS + "," + "Pass";
                            section2_results.add(CONS_File_Name);
                        }

                        //SOURCE - mandatory validation
                        if ((db_CONS_SOURCE == null) && (db_CONS_STATUS != "REVIEW")) {

                            String CONS_SOURCE = "," + ",SOURCE," + "SOURCE : " + db_CONS_SOURCE + "," + "SOURCE was not found," + db_CONS_STATUS + "," + "Fail";
                            section2_results.add(CONS_SOURCE);
                        } else {
                            String CONS_SOURCE = "," + ",SOURCE," + "SOURCE : " + db_CONS_SOURCE + "," + "SOURCE was found," + db_CONS_STATUS + "," + "Pass";
                            section2_results.add(CONS_SOURCE);
                        }

                        //BATCH_REF - mandatory validation
                        if ((db_CONS_BATCH_REF == null) && (db_CONS_STATUS != "REVIEW")) {

                            String CONS_BATCH_REF = "," + ",BATCH_REF," + "BATCH_REF : " + db_CONS_BATCH_REF + "," + "BATCH_REF was not found," + db_CONS_STATUS + "," + "Fail";
                            section2_results.add(CONS_BATCH_REF);
                        } else {
                            String CONS_BATCH_REF = "," + ",BATCH_REF," + "BATCH_REF : " + db_CONS_BATCH_REF + "," + "BATCH_REF was found," + db_CONS_STATUS + "," + "Pass";
                            section2_results.add(CONS_BATCH_REF);
                        }

                        //BATCH_HDR - mandatory validation
                        if ((db_CONS_BATCH_HDR == null) && (db_CONS_STATUS != "REVIEW")) {

                            String CONS_BATCH_HDR = "," + ",BATCH_HDR," + "BATCH_HDR : " + db_CONS_BATCH_HDR + "," + "BATCH_HDR was not found," + db_CONS_STATUS + "," + "Fail";
                            section2_results.add(CONS_BATCH_HDR);
                        } else {
                            String CONS_BATCH_HDR = "," + ",BATCH_HDR," + "BATCH_HDR : " + db_CONS_BATCH_HDR + "," + "BATCH_HDR was found," + db_CONS_STATUS + "," + "Pass";
                            section2_results.add(CONS_BATCH_HDR);
                        }

                        //RECORD_TYPE - mandatory validation
                        if ((db_CONS_RECORD_TYPE == null) && (db_CONS_STATUS != "REVIEW")) {

                            String CONS_RECORD_TYPE = "," + ",RECORD_TYPE," + "RECORD_TYPE : " + db_CONS_RECORD_TYPE + "," + "RECORD_TYPE was not found," + db_CONS_STATUS + "," + "Fail";
                            section2_results.add(CONS_RECORD_TYPE);
                        } else {
                            String CONS_RECORD_TYPE = "," + ",RECORD_TYPE," + "RECORD_TYPE : " + db_CONS_RECORD_TYPE + "," + "RECORD_TYPE was found," + db_CONS_STATUS + "," + "Pass";
                            section2_results.add(CONS_RECORD_TYPE);
                        }

                        //FILE_DATE - mandatory validation
                        if ((db_CONS_FILE_DATE == null) && (db_CONS_STATUS != "REVIEW")) {

                            String CONS_FILE_DATE = "," + ",FILE_DATE," + "FILE_DATE : " + db_CONS_FILE_DATE + "," + "FILE_DATE was not found," + db_CONS_STATUS + "," + "Fail";
                            section2_results.add(CONS_FILE_DATE);
                        } else {
                            String CONS_FILE_DATE = "," + ",FILE_DATE," + "FILE_DATE : " + db_CONS_FILE_DATE + "," + "FILE_DATE was found," + db_CONS_STATUS + "," + "Pass";
                            section2_results.add(CONS_FILE_DATE);
                        }

                        //FILE_SEQ - mandatory validation
                        if ((db_CONS_FILE_SEQ == null) && (db_CONS_STATUS != "REVIEW")) {

                            String CONS_FILE_SEQ = "," + ",FILE_SEQ," + "FILE_SEQ : " + db_CONS_FILE_SEQ + "," + "FILE_SEQ was not found," + db_CONS_STATUS + "," + "Fail";
                            section2_results.add(CONS_FILE_SEQ);
                        } else {
                            String CONS_FILE_SEQ = "," + ",FILE_SEQ," + "FILE_SEQ : " + db_CONS_FILE_SEQ + "," + "FILE_SEQ was found," + db_CONS_STATUS + "," + "Pass";
                            section2_results.add(CONS_FILE_SEQ);
                        }

                        //BATCH_TRL_REF - mandatory validation
                        if ((db_CONS_BATCH_TRL_REF == null) && (db_CONS_STATUS != "REVIEW")) {

                            String CONS_BATCH_TRL_REF = "," + ",BATCH_TRL_REF," + "BATCH_TRL_REF : " + db_CONS_BATCH_TRL_REF + "," + "BATCH_TRL_REF was not found," + db_CONS_STATUS + "," + "Fail";
                            section2_results.add(CONS_BATCH_TRL_REF);
                        } else {
                            String CONS_BATCH_TRL_REF = "," + ",BATCH_TRL_REF," + "BATCH_TRL_REF : " + db_CONS_BATCH_TRL_REF + "," + "BATCH_TRL_REF was found," + db_CONS_STATUS + "," + "Pass";
                            section2_results.add(CONS_BATCH_TRL_REF);
                        }

                        //BATCH_VALUE - mandatory validation
                        if ((db_CONS_BATCH_VALUE == null) && (db_CONS_STATUS != "REVIEW")) {

                            String CONS_BATCH_VALUE = "," + ",BATCH_VALUE," + "BATCH_VALUE : " + db_CONS_BATCH_VALUE + "," + "BATCH_VALUE was not found," + db_CONS_STATUS + "," + "Fail";
                            section2_results.add(CONS_BATCH_VALUE);
                        } else {
                            String CONS_BATCH_VALUE = "," + ",BATCH_VALUE," + "BATCH_VALUE : " + db_CONS_BATCH_VALUE + "," + "BATCH_VALUE was found," + db_CONS_STATUS + "," + "Pass";
                            section2_results.add(CONS_BATCH_VALUE);
                        }


                        //BATCH_RECORD_COUNT - mandatory validation
                        if ((db_CONS_BATCH_RECORD_COUNT == null) && (db_CONS_STATUS != "REVIEW")) {

                            String CONS_BATCH_RECORD_COUNT = "," + ",BATCH_RECORD_COUNT," + "BATCH_RECORD_COUNT : " + db_CONS_BATCH_RECORD_COUNT + "," + "BATCH_RECORD_COUNT was not found," + db_CONS_STATUS + "," + "Fail";
                            section2_results.add(CONS_BATCH_RECORD_COUNT);
                        } else {
                            String CONS_BATCH_RECORD_COUNT = "," + ",BATCH_RECORD_COUNT," + "BATCH_RECORD_COUNT : " + db_CONS_BATCH_RECORD_COUNT + "," + "BATCH_RECORD_COUNT was found," + db_CONS_STATUS + "," + "Pass";
                            section2_results.add(CONS_BATCH_RECORD_COUNT);
                        }

                        //------------------- Consolidation to Staging ----------------------------------
                        String BMSARReceipts_stgSqlQuery = connect_db.executeQuery_DB("BMS_AR", "ARReceipts_Stg", "BMS");
                        SQLResultset = SQLstmt.executeQuery(BMSARReceipts_stgSqlQuery + "'" + file_name + "' and TRANSMISSION_HEADER_ID = '" + list_header.get(i) + "' ");

                        //SQLResultset = SQLstmt.executeQuery("SELECT * from DLG_FSH_STG_COMM_ARRECEIPTS_HDR WHERE FILE_NAME = '" + xml_file_name + "' and ARREC_HEADER_ID = '" + list_header1.get(i) + "' ");
                        System.out.println("Header id outer ---" + db_CONS_BATCH_HDR);
                        if (!SQLResultset.next()) {
                            String stg_header_id = section2_map_row + ",HEADER_ID," + "no records available in STG table" + "," + db_CONS_BATCH_HDR + ",Fail";
                            section2_results.add(stg_header_id);
                        } else {
                            SQLResultset = SQLstmt.executeQuery(BMSARReceipts_stgSqlQuery + "'" + file_name + "' and TRANSMISSION_HEADER_ID = '" + list_header.get(i) + "' ");
                            while (SQLResultset.next()) {

                                db_STG_STATUS = SQLResultset.getString("STATUS");
                                db_STG_ARREC_HEADER_ID = SQLResultset.getString("ARREC_HEADER_ID");
                                db_STG_Batch_Pkey = SQLResultset.getString("Batch_Fkey");
                                db_STG_File_Name = SQLResultset.getString("File_Name");
                                db_STG_SOURCE = SQLResultset.getString("SOURCE");
                                db_STG_SET_OF_BOOKS_ID = SQLResultset.getString("SET_OF_BOOKS_ID");
                                db_STG_ORG_ID = SQLResultset.getString("ORG_ID");
                                db_STG_TRANSMISSION_RECORD_ID = SQLResultset.getString("TRANSMISSION_RECORD_ID");
                                db_STG_TRANSMISSION_HEADER_ID = SQLResultset.getString("TRANSMISSION_HEADER_ID");
                                db_STG_RECORD_TYPE = SQLResultset.getString("RECORD_TYPE");
                                db_STG_DESTINATION_ACCOUNT = SQLResultset.getString("DESTINATION_ACCOUNT");
                                db_STG_ORIGINATION = SQLResultset.getString("ORIGINATION");
                                db_STG_DEPOSIT_DATE = SQLResultset.getString("DEPOSIT_DATE");
                                db_STG_LOCKBOX_NUMBER = SQLResultset.getString("LOCKBOX_NUMBER");
                                //TODO Regression findings
                                //db_STG_BATCH_NAME = SQLResultset.getString("BATCH_NAME");
                                //db_STG_BATCH_AMOUNT = SQLResultset.getString("BATCH_AMOUNT");
                                //db_STG_BATCH_RECORD_COUNT = SQLResultset.getString("BATCH_RECORD_COUNT");



                           /* if (db_CONS_INTERFACE_HEADER_PKEY.equals(db_STG_INTERFACE_HEADER_FKEY)) {
                                String cons_header_id = cons_stg_map_row + ",LOCKBOX_NUMBER," + db_STG_INTERFACE_HEADER_FKEY + "," + db_CONS_INTERFACE_HEADER_PKEY + ",Pass";
                                section1_results.add(cons_header_id);
                                cons_stg_map_row++;
                            } else {
                                String cons_header_id = cons_stg_map_row + ",LOCKBOX_NUMBER," + db_STG_INTERFACE_HEADER_FKEY + "," + db_CONS_INTERFACE_HEADER_PKEY + ",Fail";
                                section1_results.add(cons_header_id);
                                cons_stg_map_row++;
                            }*/


                                if (db_CONS_FILE_SEQ.equals(db_STG_LOCKBOX_NUMBER)) {
                                    String cons_header_id = cons_stg_map_row + ",LOCKBOX_NUMBER," + db_STG_LOCKBOX_NUMBER + "," + db_CONS_FILE_SEQ + ",Pass";
                                    section1_results.add(cons_header_id);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",LOCKBOX_NUMBER" + "," + db_STG_LOCKBOX_NUMBER + "," + db_CONS_FILE_SEQ + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    cons_stg_map_row++;
                                } else {
                                    String cons_header_id = cons_stg_map_row + ",LOCKBOX_NUMBER," + db_STG_LOCKBOX_NUMBER + "," + db_CONS_FILE_SEQ + ",Fail";
                                    section1_results.add(cons_header_id);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",LOCKBOX_NUMBER" + "," + db_STG_LOCKBOX_NUMBER + "," + db_CONS_FILE_SEQ + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                    cons_stg_map_row++;
                                }


                                if (db_CONS_BATCH_HDR.equals(db_STG_TRANSMISSION_HEADER_ID)) {
                                    String cons_header_id = ",TRANSMISSION_HEADER_ID," + db_STG_TRANSMISSION_HEADER_ID + "," + db_CONS_BATCH_HDR + ",Pass";
                                    section1_results.add(cons_header_id);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSMISSION_HEADER_ID" + "," + db_STG_TRANSMISSION_HEADER_ID + "," + db_CONS_BATCH_HDR + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_header_id = ",TRANSMISSION_HEADER_ID," + db_STG_TRANSMISSION_HEADER_ID + "," + db_CONS_BATCH_HDR + ",Fail";
                                    section1_results.add(cons_header_id);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSMISSION_HEADER_ID" + "," + db_STG_TRANSMISSION_HEADER_ID + "," + db_CONS_BATCH_HDR + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation Batch_Pkey ---------------
                                if (db_CONS_Batch_Pkey.equals(db_STG_Batch_Pkey)) {
                                    String STG_Batch_Pkey = ",Batch_key," + db_STG_Batch_Pkey + "," + db_CONS_Batch_Pkey + ",Pass";
                                    section1_results.add(STG_Batch_Pkey);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",Batch_key" + "," + db_STG_Batch_Pkey + "," + db_CONS_Batch_Pkey + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_Batch_Pkey = ",Batch_key," + db_STG_Batch_Pkey + "," + db_CONS_Batch_Pkey + ",Fail";
                                    section1_results.add(STG_Batch_Pkey);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",Batch_key" + "," + db_STG_Batch_Pkey + "," + db_CONS_Batch_Pkey + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation file_name ---------------
                                if (db_CONS_File_Name.equals(db_STG_File_Name)) {
                                    String STG_File_Name = ",file_name," + db_STG_File_Name + "," + db_CONS_File_Name + ",Pass";
                                    section1_results.add(STG_File_Name);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",file_name" + "," + db_STG_File_Name + "," + db_CONS_File_Name + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_File_Name = ",file_name," + db_STG_File_Name + "," + db_CONS_File_Name + ",Fail";
                                    section1_results.add(STG_File_Name);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",file_name" + "," + db_STG_File_Name + "," + db_CONS_File_Name + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //------------- Validate SOURCE ----------------
                                if ((db_STG_SOURCE != null) && (db_CONS_SOURCE != null)) {
                                    if (db_STG_SOURCE.equals(db_CONS_SOURCE)) {
                                        String STG_SOURCE = ",SOURCE," + db_STG_SOURCE + "," + db_CONS_SOURCE + ",Pass";
                                        section1_results.add(STG_SOURCE);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SOURCE" + "," + db_STG_SOURCE + "," + db_CONS_SOURCE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String STG_SOURCE = ",SOURCE," + db_STG_SOURCE + "," + db_CONS_SOURCE + ",Fail";
                                        section1_results.add(STG_SOURCE);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SOURCE" + "," + db_STG_SOURCE + "," + db_CONS_SOURCE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //--------------------  Validation TRANSMISSION_RECORD_ID ---------------
                                if (db_CONS_BATCH_REF.equals(db_STG_TRANSMISSION_RECORD_ID)) {
                                    String STG_TRANSMISSION_RECORD_ID = ",TRANSMISSION_RECORD_ID," + db_STG_TRANSMISSION_RECORD_ID + "," + db_CONS_BATCH_REF + ",Pass";
                                    section1_results.add(STG_TRANSMISSION_RECORD_ID);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSMISSION_RECORD_ID" + "," + db_STG_TRANSMISSION_RECORD_ID + "," + db_CONS_BATCH_REF + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_TRANSMISSION_RECORD_ID = ",TRANSMISSION_RECORD_ID," + db_STG_TRANSMISSION_RECORD_ID + "," + db_CONS_BATCH_REF + ",Fail";
                                    section1_results.add(STG_TRANSMISSION_RECORD_ID);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSMISSION_RECORD_ID" + "," + db_STG_TRANSMISSION_RECORD_ID + "," + db_CONS_BATCH_REF + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation TRANSMISSION_HEADER_ID ---------------
                                if (db_CONS_BATCH_HDR.equals(db_STG_TRANSMISSION_HEADER_ID)) {
                                    String STG_TRANSMISSION_HEADER_ID = ",TRANSMISSION_HEADER_ID," + db_STG_TRANSMISSION_HEADER_ID + "," + db_CONS_BATCH_HDR + ",Pass";
                                    section1_results.add(STG_TRANSMISSION_HEADER_ID);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSMISSION_HEADER_ID" + "," + db_STG_TRANSMISSION_HEADER_ID + "," + db_CONS_BATCH_HDR + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_TRANSMISSION_HEADER_ID = ",TRANSMISSION_HEADER_ID," + db_STG_TRANSMISSION_HEADER_ID + "," + db_CONS_BATCH_HDR + ",Fail";
                                    section1_results.add(STG_TRANSMISSION_HEADER_ID);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSMISSION_HEADER_ID" + "," + db_STG_TRANSMISSION_HEADER_ID + "," + db_CONS_BATCH_HDR + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //------------- Validate RECORD_TYPE ----------------
                                if ((db_STG_RECORD_TYPE != null) && (db_CONS_RECORD_TYPE != null)) {
                                    if (db_STG_RECORD_TYPE.equals(db_CONS_RECORD_TYPE)) {
                                        String STG_RECORD_TYPE = ",RECORD_TYPE," + db_STG_RECORD_TYPE + "," + db_CONS_RECORD_TYPE + ",Pass";
                                        section1_results.add(STG_RECORD_TYPE);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",RECORD_TYPE" + "," + db_STG_RECORD_TYPE + "," + db_CONS_RECORD_TYPE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String STG_RECORD_TYPE = ",RECORD_TYPE," + db_STG_RECORD_TYPE + "," + db_CONS_RECORD_TYPE + ",Fail";
                                        section1_results.add(STG_RECORD_TYPE);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",RECORD_TYPE" + "," + db_STG_RECORD_TYPE + "," + db_CONS_RECORD_TYPE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //--------------------  Validation DEPOSIT_DATE ---------------
                                if (db_CONS_FILE_DATE.equals(db_STG_DEPOSIT_DATE)) {
                                    String STG_DEPOSIT_DATE = ",DEPOSIT_DATE," + db_STG_DEPOSIT_DATE + "," + db_CONS_FILE_DATE + ",Pass";
                                    section1_results.add(STG_DEPOSIT_DATE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",DEPOSIT_DATE" + "," + db_STG_DEPOSIT_DATE + "," + db_CONS_FILE_DATE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_DEPOSIT_DATE = ",DEPOSIT_DATE," + db_STG_DEPOSIT_DATE + "," + db_CONS_FILE_DATE + ",Fail";
                                    section1_results.add(STG_DEPOSIT_DATE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",DEPOSIT_DATE" + "," + db_STG_DEPOSIT_DATE + "," + db_CONS_FILE_DATE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                            /*//--------------------  Validation LOCKBOX_NUMBER ---------------
                            if (db_CONS_FILE_SEQ.equals(db_STG_LOCKBOX_NUMBER)) {
                                String STG_LOCKBOX_NUMBER = ",LOCKBOX_NUMBER," + db_STG_LOCKBOX_NUMBER + "," + db_CONS_FILE_SEQ + ",Pass";
                                section1_results.add(STG_LOCKBOX_NUMBER);
                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",LOCKBOX_NUMBER" + "," + db_STG_LOCKBOX_NUMBER + "," + db_CONS_FILE_SEQ + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                section2_results_tbl.add(tbl_header_id);
                            } else {
                                String STG_LOCKBOX_NUMBER = ",LOCKBOX_NUMBER," + db_STG_LOCKBOX_NUMBER + "," + db_CONS_FILE_SEQ + ",Fail";
                                section1_results.add(STG_LOCKBOX_NUMBER);
                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",LOCKBOX_NUMBER" + "," + db_STG_LOCKBOX_NUMBER + "," + db_CONS_FILE_SEQ + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                section2_results_tbl.add(tbl_header_id);
                                CONS_flag++;
                            }*/


                                //----------------------- Business validation - Reference data table validation -----------------------------
                                String db_ref_DESTINATION_ACCOUNT_meaning = "null";
                                String db_ref_ORIGINATION_meaning = "null";

                                String PulseARReceipts_fsh_refARLockbox_accNumber = connect_db.executeQuery_DB("Reference", "ARReceipts_REF_ARLOCKBOX_ACCOUNT_NUMBER", "BMS");
                                String PulseARReceipts_fsh_refARLockbox_bankNumber = connect_db.executeQuery_DB("Reference", "ARReceipts_REF_ARLOCKBOX_BANK_NUMBER", "BMS");

                                //------------------------------DESTINATION_ACCOUNT-------------------------------
                                SQLResultset = SQLstmt.executeQuery(PulseARReceipts_fsh_refARLockbox_accNumber + " WHERE BANK_ACCOUNT_NUMBER='" + db_STG_DESTINATION_ACCOUNT + "'");
                                //SQLResultset = SQLstmt.executeQuery("select BANK_ACCOUNT_NUMBER as bankAccountNumber from DLG_FSH_REF_AR_LOCKBOX where BANK_ACCOUNT_NUMBER='" + db_STG_DESTINATION_ACCOUNT + "'");
                                while (SQLResultset.next()) {
                                    db_ref_DESTINATION_ACCOUNT_meaning = SQLResultset.getString("bankAccountNumber");
                                }
                                if (db_ref_DESTINATION_ACCOUNT_meaning.equals("null")) {
                                    String ref_DESTINATION_ACCOUNT_meaning = ",DESTINATION_ACCOUNT Reference_Table," + "Transformation value not found" + "," + db_STG_DESTINATION_ACCOUNT + ",Fail";
                                    section1_results.add(ref_DESTINATION_ACCOUNT_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",DESTINATION_ACCOUNT Reference_Table" + "," + "Transformation value not found" + "," + db_STG_DESTINATION_ACCOUNT + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_ref_DESTINATION_ACCOUNT_meaning != null) {
                                    if (db_ref_DESTINATION_ACCOUNT_meaning.equals(db_STG_DESTINATION_ACCOUNT)) {
                                        String ref_DESTINATION_ACCOUNT_meaning = ",DESTINATION_ACCOUNT Reference_Table," + db_ref_DESTINATION_ACCOUNT_meaning + "," + db_STG_DESTINATION_ACCOUNT + ",Pass";
                                        section1_results.add(ref_DESTINATION_ACCOUNT_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",DESTINATION_ACCOUNT Reference_Table" + "," + db_ref_DESTINATION_ACCOUNT_meaning + "," + db_STG_DESTINATION_ACCOUNT + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String ref_DESTINATION_ACCOUNT_meaning = ",DESTINATION_ACCOUNT Reference_Table," + db_ref_DESTINATION_ACCOUNT_meaning + "," + db_STG_DESTINATION_ACCOUNT + ",Fail";
                                        section1_results.add(ref_DESTINATION_ACCOUNT_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",DESTINATION_ACCOUNT Reference_Table" + "," + db_ref_DESTINATION_ACCOUNT_meaning + "," + db_STG_DESTINATION_ACCOUNT + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //------------------------------ORIGINATION-------------------------------
                                SQLResultset = SQLstmt.executeQuery(PulseARReceipts_fsh_refARLockbox_bankNumber + " WHERE BANK_NUM='" + db_STG_ORIGINATION + "'");
                                //SQLResultset = SQLstmt.executeQuery("select BANK_NUM as bankNumber from DLG_FSH_REF_AR_LOCKBOX where BANK_NUM='" + db_STG_ORIGINATION + "'");
                                while (SQLResultset.next()) {
                                    db_ref_ORIGINATION_meaning = SQLResultset.getString("bankNumber");
                                }
                                if (db_ref_ORIGINATION_meaning.equals("null")) {
                                    String ref_DESTINATION_ACCOUNT_meaning = ",ORIGINATION Reference_Table," + "Transformation value not found" + "," + db_STG_ORIGINATION + ",Fail";
                                    section1_results.add(ref_DESTINATION_ACCOUNT_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ORIGINATION Reference_Table" + "," + "Transformation value not found" + "," + db_STG_ORIGINATION + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_ref_ORIGINATION_meaning != null) {
                                    if (db_ref_ORIGINATION_meaning.equals(db_STG_ORIGINATION)) {
                                        String ref_DESTINATION_ACCOUNT_meaning = ",ORIGINATION Reference_Table," + db_ref_ORIGINATION_meaning + "," + db_STG_ORIGINATION + ",Pass";
                                        section1_results.add(ref_DESTINATION_ACCOUNT_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ORIGINATION Reference_Table" + "," + db_ref_ORIGINATION_meaning + "," + db_STG_ORIGINATION + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String ref_DESTINATION_ACCOUNT_meaning = ",ORIGINATION Reference_Table," + db_ref_ORIGINATION_meaning + "," + db_STG_ORIGINATION + ",Fail";
                                        section1_results.add(ref_DESTINATION_ACCOUNT_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ORIGINATION Reference_Table" + "," + db_ref_ORIGINATION_meaning + "," + db_STG_ORIGINATION + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }


                                //----------------------- Lookup table validation  -----------------------------
                                String db_lookup_SET_OF_BOOKS_ID_meaning = "null";
                                String db_lookup_Org_ID_meaning = "null";
                                String db_lookup_DESTINATION_ACCOUNT_meaning = "null";
                                String db_lookup_ORIGINATION_meaning = "null";

                                String BMSARReceipts_fsh_lookup = connect_db.executeQuery_DB("Lookup", "FSH_LOOKUP", "BMS");
                                String BMSARReceipts_fsh_sys_lookup = connect_db.executeQuery_DB("Lookup", "FSH_SYS_LOOKUP", "BMS");
                                String fsh_source = connect_db.executeQuery_DB("Lookup", "FSH_LOOKUP_SOURCE_BMS_ARReceipts", "BMS");

                                //------------------------ SET_OF_BOOKS_ID Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(BMSARReceipts_fsh_sys_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'SET_OF_BOOKS_ID'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'SET_OF_BOOKS_ID' and system = 'ECLI' and pattern = 'ARReceipts'");
                                while (SQLResultset.next()) {
                                    db_lookup_SET_OF_BOOKS_ID_meaning = SQLResultset.getString("MEANING");
                                }

                                if (db_lookup_SET_OF_BOOKS_ID_meaning.equals("null")) {
                                    String lookup_SET_OF_BOOKS_ID_meaning = ",SET_OF_BOOKS_ID lookup," + "LookUp value not found" + "," + db_STG_SET_OF_BOOKS_ID + ",Fail";
                                    section1_results.add(lookup_SET_OF_BOOKS_ID_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SET_OF_BOOKS_ID lookup" + "," + "LookUp value not found" + "," + db_STG_SET_OF_BOOKS_ID + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_lookup_SET_OF_BOOKS_ID_meaning != null) {
                                    if (db_lookup_SET_OF_BOOKS_ID_meaning.equals(db_STG_SET_OF_BOOKS_ID)) {
                                        String lookup_SET_OF_BOOKS_ID_meaning = ",SET_OF_BOOKS_ID lookup," + db_lookup_SET_OF_BOOKS_ID_meaning + "," + db_STG_SET_OF_BOOKS_ID + ",Pass";
                                        section1_results.add(lookup_SET_OF_BOOKS_ID_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SET_OF_BOOKS_ID lookup" + "," + db_lookup_SET_OF_BOOKS_ID_meaning + "," + db_STG_SET_OF_BOOKS_ID + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String lookup_SET_OF_BOOKS_ID_meaning = ",SET_OF_BOOKS_ID lookup," + db_lookup_SET_OF_BOOKS_ID_meaning + "," + db_STG_SET_OF_BOOKS_ID + ",Fail";
                                        section1_results.add(lookup_SET_OF_BOOKS_ID_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SET_OF_BOOKS_ID lookup" + "," + db_lookup_SET_OF_BOOKS_ID_meaning + "," + db_STG_SET_OF_BOOKS_ID + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //------------------------ Org_ID Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(BMSARReceipts_fsh_sys_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'ORG_ID'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'ORG_ID' and system = 'ECLI' and pattern = 'ARReceipts'");
                                while (SQLResultset.next()) {
                                    db_lookup_Org_ID_meaning = SQLResultset.getString("MEANING");
                                }

                                if (db_lookup_Org_ID_meaning.equals("null")) {
                                    String lookup_Org_ID_meaning = ",Org_ID lookup," + "LookUp value not found" + "," + db_STG_ORG_ID + ",Fail";
                                    section1_results.add(lookup_Org_ID_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",Org_ID lookup" + "," + "LookUp value not found" + "," + db_STG_ORG_ID + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_lookup_Org_ID_meaning != null) {
                                    if (db_lookup_Org_ID_meaning.equals(db_STG_ORG_ID)) {
                                        String lookup_Org_ID_meaning = ",Org_ID lookup," + db_lookup_Org_ID_meaning + "," + db_STG_ORG_ID + ",Pass";
                                        section1_results.add(lookup_Org_ID_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",Org_ID lookup" + "," + db_lookup_Org_ID_meaning + "," + db_STG_ORG_ID + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String lookup_Org_ID_meaning = ",Org_ID lookup," + db_lookup_Org_ID_meaning + "," + db_STG_ORG_ID + ",Fail";
                                        section1_results.add(lookup_Org_ID_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",Org_ID lookup" + "," + db_lookup_Org_ID_meaning + "," + db_STG_ORG_ID + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //------------------------ DESTINATION_ACCOUNT Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(BMSARReceipts_fsh_sys_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'DESTINATION_ACCOUNT'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'DESTINATION_ACCOUNT' and system = 'ECLI' and pattern = 'ARReceipts'");
                                while (SQLResultset.next()) {
                                    db_lookup_DESTINATION_ACCOUNT_meaning = SQLResultset.getString("MEANING");
                                }

                                if (db_lookup_DESTINATION_ACCOUNT_meaning.equals("null")) {
                                    String lookup_DESTINATION_ACCOUNT_meaning = ",DESTINATION_ACCOUNT lookup," + "LookUp value not found" + "," + db_STG_DESTINATION_ACCOUNT + ",Fail";
                                    section1_results.add(lookup_DESTINATION_ACCOUNT_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",DESTINATION_ACCOUNT lookup" + "," + "LookUp value not found" + "," + db_STG_DESTINATION_ACCOUNT + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_lookup_DESTINATION_ACCOUNT_meaning != null) {
                                    if (db_lookup_DESTINATION_ACCOUNT_meaning.equals(db_STG_DESTINATION_ACCOUNT)) {
                                        String lookup_DESTINATION_ACCOUNT_meaning = ",DESTINATION_ACCOUNT lookup," + db_lookup_DESTINATION_ACCOUNT_meaning + "," + db_STG_DESTINATION_ACCOUNT + ",Pass";
                                        section1_results.add(lookup_DESTINATION_ACCOUNT_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",DESTINATION_ACCOUNT lookup" + "," + db_lookup_DESTINATION_ACCOUNT_meaning + "," + db_STG_DESTINATION_ACCOUNT + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String lookup_DESTINATION_ACCOUNT_meaning = ",DESTINATION_ACCOUNT lookup," + db_lookup_DESTINATION_ACCOUNT_meaning + "," + db_STG_DESTINATION_ACCOUNT + ",Fail";
                                        section1_results.add(lookup_DESTINATION_ACCOUNT_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",DESTINATION_ACCOUNT lookup" + "," + db_lookup_DESTINATION_ACCOUNT_meaning + "," + db_STG_DESTINATION_ACCOUNT + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //------------------------ ORIGINATION Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(BMSARReceipts_fsh_sys_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'ORIGINATION'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'ORIGINATION' and system = 'ECLI' and pattern = 'ARReceipts'");
                                while (SQLResultset.next()) {
                                    db_lookup_ORIGINATION_meaning = SQLResultset.getString("MEANING");
                                }

                                if (db_lookup_ORIGINATION_meaning.equals("null")) {
                                    String lookup_ORIGINATION_meaning = ",ORIGINATION lookup," + "LookUp value not found" + "," + db_STG_ORIGINATION + ",Fail";
                                    section1_results.add(lookup_ORIGINATION_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ORIGINATION lookup" + "," + "LookUp value not found" + "," + db_STG_ORIGINATION + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_lookup_ORIGINATION_meaning != null) {
                                    if (db_lookup_ORIGINATION_meaning.equals(db_STG_ORIGINATION)) {
                                        String lookup_ORIGINATION_meaning = ",ORIGINATION lookup," + db_lookup_ORIGINATION_meaning + "," + db_STG_ORIGINATION + ",Pass";
                                        section1_results.add(lookup_ORIGINATION_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ORIGINATION lookup" + "," + db_lookup_ORIGINATION_meaning + "," + db_STG_ORIGINATION + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String lookup_ORIGINATION_meaning = ",ORIGINATION lookup," + db_lookup_ORIGINATION_meaning + "," + db_STG_ORIGINATION + ",Fail";
                                        section1_results.add(lookup_ORIGINATION_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ORIGINATION lookup" + "," + db_lookup_ORIGINATION_meaning + "," + db_STG_ORIGINATION + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }


                                //------------------------  Line Item variable Declaration -----------------------------

                                //------------------------  Line Item validation -----------------------------
                                int line_count = 0;
                                ArrayList<String> list_line_id = new ArrayList<String>();
                                String BMSARReceipts_stglineSqlQuery = connect_db.executeQuery_DB("BMS_AR", "ARReceipts_Stg_line", "BMS");
                                SQLResultset = SQLstmt.executeQuery(BMSARReceipts_stglineSqlQuery + "'" + file_name + "' and TRANSMISSION_HEADER_ID = '" + db_STG_TRANSMISSION_HEADER_ID + "' ");
                                //SQLResultset = SQLstmt.executeQuery("SELECT * FROM  DLG_FSH_STG_COMM_ARRECEIPTS_LIN WHERE  ARREC_HEADER_ID = '" + db_STG_ARREC_HEADER_ID + "'");

                                while (SQLResultset.next()) {
                                    list_line_id.add(SQLResultset.getString("INVOICE1"));
                                }

                                for (int i_count = 0; i_count <= list_line_id.size() - 1; i_count++) {
                                    int stg_sub_indent = i_count;
                                    int sub_tag_line = 0;
                                    System.out.println("Line id ---> " + list_line_id.get(i_count));
                                    SQLResultset = SQLstmt.executeQuery(BMSARReceipts_stglineSqlQuery + "'" + file_name + "' and TRANSMISSION_HEADER_ID = '" + db_STG_TRANSMISSION_HEADER_ID + "' and INVOICE1 = '" + list_line_id.get(i_count) + "' ");
                                    //SQLResultset = SQLstmt.executeQuery("SELECT * FROM  DLG_FSH_STG_COMM_ARRECEIPTS_LIN WHERE  ARREC_HEADER_ID = '" + db_STG_ARREC_HEADER_ID + "' and INVOICE1='" + list_line_id.get(i_count) + "'");
                                    while (SQLResultset.next()) {
                                        //db_STG_line_id = SQLResultset.getString("LINE_ID");
                                        //db_STG_LINE_NUMBER = SQLResultset.getString("LINE_NUMBER");
                                        db_STG_LINE_BATCH_FKEY = SQLResultset.getString("BATCH_FKEY");
                                        db_STG_LINE_FILE_NAME = SQLResultset.getString("FILE_NAME");
                                        db_STG_LINE_SOURCE = SQLResultset.getString("SOURCE");
                                        db_STG_LINE_TRANSMISSION_HEADER_ID = SQLResultset.getString("TRANSMISSION_HEADER_ID");
                                        db_STG_LINE_RECORD_TYPE = SQLResultset.getString("RECORD_TYPE");
                                        db_STG_LINE_DEPOSIT_DATE = SQLResultset.getString("DEPOSIT_DATE");
                                        db_STG_LINE_CURRENCY_CODE = SQLResultset.getString("CURRENCY_CODE");
                                        db_STG_LINE_REMITTANCE_AMOUNT = SQLResultset.getString("REMITTANCE_AMOUNT");
                                        db_STG_LINE_CHECK_NUMBER = SQLResultset.getString("CHECK_NUMBER");
                                        db_STG_LINE_INVOICE1 = SQLResultset.getString("INVOICE1");
                                        db_STG_LINE_ATTRIBUTE1 = SQLResultset.getString("ATTRIBUTE1");
                                        db_STG_LINE_ATTRIBUTE2 = SQLResultset.getString("ATTRIBUTE2");
                                        db_STG_LINE_RECEIPT_METHOD = SQLResultset.getString("RECEIPT_METHOD");
                                        db_STG_LINE_BILL_TO_LOCATION = SQLResultset.getString("BILL_TO_LOCATION");
                                        db_STG_LINE_RECEIPT_DATE = SQLResultset.getString("RECEIPT_DATE");
                                        db_STG_LINE_BATCH_NAME = SQLResultset.getString("BATCH_NAME");
                                        db_STG_LINE_BATCH_AMOUNT = SQLResultset.getString("BATCH_AMOUNT");
                                        db_STG_LINE_BATCH_RECORD_COUNT = SQLResultset.getString("BATCH_RECORD_COUNT");
                                        db_STG_LINE_CUSTOMER_NUMBER = SQLResultset.getString("CUSTOMER_NUMBER");
                                        //SQLResultset = SQLstmt.executeQuery(BMSARReceipts_stgSqlQuery + "'" + file_name + "' and TRANSMISSION_HEADER_ID = '" + list_header.get(i) + "' ");

                                        String BMSARReceipts_conslineSqlQuery = connect_db.executeQuery_DB("BMS_AR", "ARReceipts_Cons_line", "BMS");
                                        SQLResultset = SQLstmt.executeQuery(BMSARReceipts_conslineSqlQuery + "'" + file_name + "' and INVOICE_REF = '" + db_STG_LINE_INVOICE1 + "' ");
                                        //SQLResultset = SQLstmt.executeQuery("SELECT * FROM DLG_FSH_CONS_ECLI_ARREC_LIN WHERE INVOICE_REF = '" + db_STG_LINE_INVOICE1 + "' ");
                                        while (SQLResultset.next()) {
                                            //db_CONS_line_id = SQLResultset.getString("LINE_ID");
                                            //db_CONS_LINE_NUMBER = SQLResultset.getString("LINE_NUMBER");
                                            //db_CONS_LINE_INTERFACE_HEADER_FKEY = SQLResultset.getString("INTERFACE_LINE_PKEY");
                                            db_CONS_LINE_INTERFACE_HEADER_FKEY = SQLResultset.getString("INTERFACE_HEADER_FKEY");
                                            db_CONS_LINE_Batch_Pkey = SQLResultset.getString("Batch_Fkey");
                                            db_CONS_LINE_File_Name = SQLResultset.getString("File_Name");
                                            db_CONS_LINE_SOURCE = SQLResultset.getString("SOURCE");
                                            db_CONS_LINE_BATCH_REF = SQLResultset.getString("BATCH_REF");
                                            db_CONS_LINE_RECORD_TYPE = SQLResultset.getString("RECORD_TYPE");
                                            db_CONS_LINE_BANKED_DT = SQLResultset.getString("BANKED_DT");
                                            db_CONS_LINE_CURRENCY_CODE = SQLResultset.getString("CURRENCY_CODE");
                                            db_CONS_LINE_AMOUNT_RECEIVED = SQLResultset.getString("AMOUNT_RECEIVED");
                                            //TODO customer_number is not available
                                            //db_STG_LINE_CUSTOMER_NUMBER = SQLResultset.getString("CUSTOMER_NUMBER");

                                            db_CONS_LINE_PAYMENT_REFERENCE = SQLResultset.getString("PAYMENT_REFERENCE");
                                            db_CONS_LINE_INVOICE_REF = SQLResultset.getString("INVOICE_REF");
                                            db_CONS_LINE_JOB_LINK = SQLResultset.getString("JOB_LINK");
                                            db_CONS_LINE_SEQUENCE = SQLResultset.getString("SEQUENCE");
                                            db_CONS_LINE_PAYMENT_METHOD = SQLResultset.getString("PAYMENT_METHOD");
                                            db_CONS_LINE_SITE_REF = SQLResultset.getString("SITE_REF");
                                            db_CONS_LINE_RECEIVED_DT = SQLResultset.getString("RECEIVED_DT");
                                            CONS_LINE_STATUS = SQLResultset.getString("STATUS");

                                            //Validating mandatory fields in LINE consolidation table
                                            //Batch_Pkey - mandatory validation
                                            if ((db_CONS_LINE_Batch_Pkey == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String CONS_LINE_NUMBER = stg_mandatory_map_row + "," + db_CONS_LINE_INVOICE_REF + ",LINE Batch_Pkey," + "LINE Batch_Pkey : " + db_CONS_LINE_Batch_Pkey + "," + "LINE Batch_Pkey was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(CONS_LINE_NUMBER);
                                                stg_mandatory_map_row++;
                                            } else {
                                                String CONS_LINE_NUMBER = stg_mandatory_map_row + "," + db_CONS_LINE_INVOICE_REF + ",LINE Batch_Pkey," + "LINE Batch_Pkey : " + db_CONS_LINE_Batch_Pkey + "," + "LINE Batch_Pkey was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(CONS_LINE_NUMBER);
                                                stg_mandatory_map_row++;
                                            }

                                            //File_Name - mandatory validation
                                            if ((db_CONS_LINE_File_Name == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String stg_LINE_NUMBER = "," + ",LINE File_Name," + "LINE File_Name : " + db_CONS_LINE_File_Name + "," + "LINE File_Name was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(stg_LINE_NUMBER);
                                            } else {
                                                String stg_LINE_NUMBER = "," + ",LINE File_Name," + "LINE File_Name : " + db_CONS_LINE_File_Name + "," + "LINE File_Name was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(stg_LINE_NUMBER);
                                            }


                                            //SOURCE - mandatory validation
                                            if ((db_CONS_LINE_SOURCE == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String stg_VENDOR_SITE_ID = "," + ",LINE SOURCE," + "LINE SOURCE : " + db_CONS_LINE_SOURCE + "," + "LINE SOURCE was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(stg_VENDOR_SITE_ID);
                                            } else {
                                                String stg_VENDOR_SITE_ID = "," + ",LINE SOURCE," + "LINE SOURCE : " + db_CONS_LINE_SOURCE + "," + "LINE SOURCE was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(stg_VENDOR_SITE_ID);
                                            }


                                            //BATCH_REF - mandatory validation
                                            if ((db_CONS_LINE_BATCH_REF == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String stg_CATEGORY = "," + ",LINE BATCH_REF," + "LINE BATCH_REF : " + db_CONS_LINE_BATCH_REF + "," + "LINE BATCH_REF was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(stg_CATEGORY);
                                            } else {
                                                String stg_CATEGORY = "," + ",LINE BATCH_REF," + "LINE BATCH_REF : " + db_CONS_LINE_BATCH_REF + "," + "LINE BATCH_REF was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(stg_CATEGORY);
                                            }


                                            //RECORD_TYPE - mandatory validation
                                            if ((db_CONS_LINE_RECORD_TYPE == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String stg_LINE_ITEM_AMOUNT = "," + ",LINE RECORD_TYPE," + "LINE RECORD_TYPE : " + db_CONS_LINE_RECORD_TYPE + "," + "LINE RECORD_TYPE was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(stg_LINE_ITEM_AMOUNT);
                                            } else {
                                                String stg_LINE_ITEM_AMOUNT = "," + ",LINE RECORD_TYPE," + "LINE RECORD_TYPE : " + db_CONS_LINE_RECORD_TYPE + "," + "LINE RECORD_TYPE was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(stg_LINE_ITEM_AMOUNT);
                                            }

                                            //BANKED_DT - mandatory validation
                                            if ((db_CONS_LINE_BANKED_DT == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String stg_VENDOR_SITE_ID = "," + ",LINE BANKED_DT," + "LINE BANKED_DT : " + db_CONS_LINE_BANKED_DT + "," + "LINE BANKED_DT was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(stg_VENDOR_SITE_ID);
                                            } else {
                                                String stg_VENDOR_SITE_ID = "," + ",LINE BANKED_DT," + "LINE BANKED_DT : " + db_CONS_LINE_BANKED_DT + "," + "LINE BANKED_DT was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(stg_VENDOR_SITE_ID);
                                            }


                                            //CURRENCY_CODE - mandatory validation
                                            if ((db_CONS_LINE_CURRENCY_CODE == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String stg_CATEGORY = "," + ",LINE CURRENCY_CODE," + "LINE CURRENCY_CODE : " + db_CONS_LINE_CURRENCY_CODE + "," + "LINE CURRENCY_CODE was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(stg_CATEGORY);
                                            } else {
                                                String stg_CATEGORY = "," + ",LINE CURRENCY_CODE," + "LINE CURRENCY_CODE : " + db_CONS_LINE_CURRENCY_CODE + "," + "LINE CURRENCY_CODE was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(stg_CATEGORY);
                                            }


                                            //AMOUNT_RECEIVED - mandatory validation
                                            if ((db_CONS_LINE_AMOUNT_RECEIVED == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String stg_LINE_ITEM_AMOUNT = "," + ",LINE AMOUNT_RECEIVED," + "LINE AMOUNT_RECEIVED : " + db_CONS_LINE_AMOUNT_RECEIVED + "," + "LINE AMOUNT_RECEIVED was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(stg_LINE_ITEM_AMOUNT);
                                            } else {
                                                String stg_LINE_ITEM_AMOUNT = "," + ",LINE AMOUNT_RECEIVED," + "LINE AMOUNT_RECEIVED : " + db_CONS_LINE_AMOUNT_RECEIVED + "," + "LINE AMOUNT_RECEIVED was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(stg_LINE_ITEM_AMOUNT);
                                            }

                                            //PAYMENT_REFERENCE - mandatory validation
                                            if ((db_CONS_LINE_PAYMENT_REFERENCE == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String stg_CATEGORY = "," + ",LINE PAYMENT_REFERENCE," + "LINE PAYMENT_REFERENCE : " + db_CONS_LINE_PAYMENT_REFERENCE + "," + "LINE PAYMENT_REFERENCE was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(stg_CATEGORY);
                                            } else {
                                                String stg_CATEGORY = "," + ",LINE PAYMENT_REFERENCE," + "LINE PAYMENT_REFERENCE : " + db_CONS_LINE_PAYMENT_REFERENCE + "," + "LINE PAYMENT_REFERENCE was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(stg_CATEGORY);
                                            }


                                            //JOB_LINK - mandatory validation
                                            if ((db_CONS_LINE_JOB_LINK == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String stg_LINE_ITEM_AMOUNT = "," + ",LINE JOB_LINK," + "LINE JOB_LINK : " + db_CONS_LINE_JOB_LINK + "," + "LINE JOB_LINK was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(stg_LINE_ITEM_AMOUNT);
                                            } else {
                                                String stg_LINE_ITEM_AMOUNT = "," + ",LINE JOB_LINK," + "LINE JOB_LINK : " + db_CONS_LINE_JOB_LINK + "," + "LINE JOB_LINK was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(stg_LINE_ITEM_AMOUNT);
                                            }


                                            //SEQUENCE - mandatory validation
                                            if ((db_CONS_LINE_SEQUENCE == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String stg_CATEGORY = "," + ",LINE SEQUENCE," + "LINE SEQUENCE : " + db_CONS_LINE_SEQUENCE + "," + "LINE SEQUENCE was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(stg_CATEGORY);
                                            } else {
                                                String stg_CATEGORY = "," + ",LINE SEQUENCE," + "LINE SEQUENCE : " + db_CONS_LINE_SEQUENCE + "," + "LINE SEQUENCE was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(stg_CATEGORY);
                                            }


                                            //PAYMENT_METHOD - mandatory validation
                                            if ((db_CONS_LINE_PAYMENT_METHOD == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String stg_LINE_ITEM_AMOUNT = "," + ",LINE PAYMENT_METHOD," + "LINE PAYMENT_METHOD : " + db_CONS_LINE_PAYMENT_METHOD + "," + "LINE PAYMENT_METHOD was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(stg_LINE_ITEM_AMOUNT);
                                            } else {
                                                String stg_LINE_ITEM_AMOUNT = "," + ",LINE PAYMENT_METHOD," + "LINE PAYMENT_METHOD : " + db_CONS_LINE_PAYMENT_METHOD + "," + "LINE PAYMENT_METHOD was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(stg_LINE_ITEM_AMOUNT);
                                            }

                                            //SITE_REF - mandatory validation
                                            if ((db_CONS_LINE_SITE_REF == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String stg_CATEGORY = "," + ",LINE SITE_REF," + "LINE SITE_REF : " + db_CONS_LINE_SITE_REF + "," + "LINE SITE_REF was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(stg_CATEGORY);
                                            } else {
                                                String stg_CATEGORY = "," + ",LINE SITE_REF," + "LINE SITE_REF : " + db_CONS_LINE_SITE_REF + "," + "LINE SITE_REF was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(stg_CATEGORY);
                                            }

                                            //RECEIVED_DT - mandatory validation
                                            if ((db_CONS_LINE_RECEIVED_DT == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String stg_CATEGORY = "," + ",LINE RECEIVED_DT," + "LINE RECEIVED_DT : " + db_CONS_LINE_RECEIVED_DT + "," + "LINE RECEIVED_DT was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(stg_CATEGORY);
                                            } else {
                                                String stg_CATEGORY = "," + ",LINE RECEIVED_DT," + "LINE RECEIVED_DT : " + db_CONS_LINE_RECEIVED_DT + "," + "LINE RECEIVED_DT was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(stg_CATEGORY);
                                            }


                                            String tbl_line = stg_line_map_row + "." + stg_sub_indent;

                                            //------------- Validate Line HEADER_ID ----------------
                                            if (db_STG_LINE_INVOICE1.equals(db_CONS_LINE_INVOICE_REF)) {
                                                String stg_line_pc_header_id = stg_line_map_row + "." + stg_sub_indent + ",LINE HEADER_ID," + db_STG_LINE_INVOICE1 + "," + db_CONS_LINE_INVOICE_REF + ",Pass";
                                                section1_results.add(stg_line_pc_header_id);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE HEADER_ID" + "," + db_STG_LINE_INVOICE1 + "," + db_CONS_LINE_INVOICE_REF + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                stg_sub_indent++;
                                            } else {
                                                String stg_line_pc_header_id = stg_line_map_row + "." + stg_sub_indent + ",LINE HEADER_ID," + db_STG_LINE_INVOICE1 + "," + db_CONS_LINE_INVOICE_REF + ",Fail";
                                                section1_results.add(stg_line_pc_header_id);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE HEADER_ID" + "," + db_STG_LINE_INVOICE1 + "," + db_CONS_LINE_INVOICE_REF + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                stg_sub_indent++;
                                                CONS_flag++;
                                            }

                                            //------------- Validate LINE_NUMBER ----------------
                                            if (db_STG_LINE_TRANSMISSION_HEADER_ID.equals(db_CONS_LINE_BATCH_REF)) {
                                                String stg_line_number = ",LINE_NUMBER," + db_STG_LINE_TRANSMISSION_HEADER_ID + "," + db_CONS_LINE_BATCH_REF + ",Pass";
                                                section1_results.add(stg_line_number);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_NUMBER" + "," + db_STG_LINE_TRANSMISSION_HEADER_ID + "," + db_CONS_LINE_BATCH_REF + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String stg_line_number = ",LINE_NUMBER," + db_STG_LINE_TRANSMISSION_HEADER_ID + "," + db_CONS_LINE_BATCH_REF + ",Fail";
                                                section1_results.add(stg_line_number);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_NUMBER" + "," + db_STG_LINE_TRANSMISSION_HEADER_ID + "," + db_CONS_LINE_BATCH_REF + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }

                                            //------------- Validate BATCH_FKEY ----------------
                                            if (db_STG_LINE_BATCH_FKEY.equals(db_CONS_LINE_Batch_Pkey)) {
                                                String STG_LINE_BATCH_FKEY = ",LINE BATCH_FKEY," + db_STG_LINE_BATCH_FKEY + "," + db_CONS_LINE_Batch_Pkey + ",Pass";
                                                section1_results.add(STG_LINE_BATCH_FKEY);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE BATCH_FKEY" + "," + db_STG_LINE_BATCH_FKEY + "," + db_CONS_LINE_Batch_Pkey + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String STG_LINE_BATCH_FKEY = ",LINE BATCH_FKEY," + db_STG_LINE_BATCH_FKEY + "," + db_CONS_LINE_Batch_Pkey + ",Fail";
                                                section1_results.add(STG_LINE_BATCH_FKEY);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE BATCH_FKEY" + "," + db_STG_LINE_BATCH_FKEY + "," + db_CONS_LINE_Batch_Pkey + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }

                                            //------------- Validate FILE_NAME ----------------
                                            if (db_STG_LINE_FILE_NAME.equals(db_CONS_LINE_File_Name)) {
                                                String STG_LINE_FILE_NAME = ",LINE FILE_NAME," + db_STG_LINE_FILE_NAME + "," + db_CONS_LINE_File_Name + ",Pass";
                                                section1_results.add(STG_LINE_FILE_NAME);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE FILE_NAME" + "," + db_STG_LINE_FILE_NAME + "," + db_CONS_LINE_File_Name + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String STG_LINE_FILE_NAME = ",LINE FILE_NAME," + db_STG_LINE_FILE_NAME + "," + db_CONS_LINE_File_Name + ",Fail";
                                                section1_results.add(STG_LINE_FILE_NAME);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE FILE_NAME" + "," + db_STG_LINE_FILE_NAME + "," + db_CONS_LINE_File_Name + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }

                                            //------------- Validate Line SOURCE ----------------
                                            if (db_STG_LINE_SOURCE.equals(db_CONS_LINE_SOURCE)) {
                                                String STG_LINE_SOURCE = ",LINE SOURCE," + db_STG_LINE_SOURCE + "," + db_CONS_LINE_SOURCE + ",Pass";
                                                section1_results.add(STG_LINE_SOURCE);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SOURCE" + "," + db_STG_LINE_SOURCE + "," + db_CONS_LINE_SOURCE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String STG_LINE_SOURCE = ",LINE SOURCE," + db_STG_LINE_SOURCE + "," + db_CONS_LINE_SOURCE + ",Fail";
                                                section1_results.add(STG_LINE_SOURCE);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SOURCE" + "," + db_STG_LINE_SOURCE + "," + db_CONS_LINE_SOURCE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }

                                            //------------- Validate RECORD_TYPE ----------------
                                            if (db_STG_LINE_RECORD_TYPE.equals(db_CONS_LINE_RECORD_TYPE)) {
                                                String STG_LINE_RECORD_TYPE = ",LINE RECORD_TYPE," + db_STG_LINE_RECORD_TYPE + "," + db_CONS_LINE_RECORD_TYPE + ",Pass";
                                                section1_results.add(STG_LINE_RECORD_TYPE);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE RECORD_TYPE" + "," + db_STG_LINE_RECORD_TYPE + "," + db_CONS_LINE_RECORD_TYPE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String STG_LINE_RECORD_TYPE = ",LINE RECORD_TYPE," + db_STG_LINE_RECORD_TYPE + "," + db_CONS_LINE_RECORD_TYPE + ",Fail";
                                                section1_results.add(STG_LINE_RECORD_TYPE);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE RECORD_TYPE" + "," + db_STG_LINE_RECORD_TYPE + "," + db_CONS_LINE_RECORD_TYPE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }

                                            //------------- Validate LINE_DEPOSIT_DATE ----------------
                                            if (db_STG_LINE_DEPOSIT_DATE.equals(db_CONS_LINE_BANKED_DT)) {
                                                String STG_LINE_DEPOSIT_DATE = ",LINE DEPOSIT_DATE," + db_STG_LINE_DEPOSIT_DATE + "," + db_CONS_LINE_BANKED_DT + ",Pass";
                                                section1_results.add(STG_LINE_DEPOSIT_DATE);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE DEPOSIT_DATE" + "," + db_STG_LINE_DEPOSIT_DATE + "," + db_CONS_LINE_BANKED_DT + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String STG_LINE_DEPOSIT_DATE = ",LINE DEPOSIT_DATE," + db_STG_LINE_DEPOSIT_DATE + "," + db_CONS_LINE_BANKED_DT + ",Fail";
                                                section1_results.add(STG_LINE_DEPOSIT_DATE);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE DEPOSIT_DATE" + "," + db_STG_LINE_DEPOSIT_DATE + "," + db_CONS_LINE_BANKED_DT + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }

                                            //------------- Validate CURRENCY_CODE ----------------
                                            if (db_STG_LINE_CURRENCY_CODE.equals(db_CONS_LINE_CURRENCY_CODE)) {
                                                String STG_LINE_CURRENCY_CODE = ",LINE CURRENCY_CODE," + db_STG_LINE_CURRENCY_CODE + "," + db_CONS_LINE_CURRENCY_CODE + ",Pass";
                                                section1_results.add(STG_LINE_CURRENCY_CODE);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE CURRENCY_CODE" + "," + db_STG_LINE_CURRENCY_CODE + "," + db_CONS_LINE_CURRENCY_CODE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String STG_LINE_CURRENCY_CODE = ",LINE CURRENCY_CODE," + db_STG_LINE_CURRENCY_CODE + "," + db_CONS_LINE_CURRENCY_CODE + ",Fail";
                                                section1_results.add(STG_LINE_CURRENCY_CODE);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE CURRENCY_CODE" + "," + db_STG_LINE_CURRENCY_CODE + "," + db_CONS_LINE_CURRENCY_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }

                                            //------------- Validate REMITTANCE_AMOUNT ----------------
                                            if (db_STG_LINE_REMITTANCE_AMOUNT.equals(db_CONS_LINE_AMOUNT_RECEIVED)) {
                                                String STG_LINE_REMITTANCE_AMOUNT = ",LINE REMITTANCE_AMOUNT," + db_STG_LINE_REMITTANCE_AMOUNT + "," + db_CONS_LINE_AMOUNT_RECEIVED + ",Pass";
                                                section1_results.add(STG_LINE_REMITTANCE_AMOUNT);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE REMITTANCE_AMOUNT" + "," + db_STG_LINE_REMITTANCE_AMOUNT + "," + db_CONS_LINE_AMOUNT_RECEIVED + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String STG_LINE_REMITTANCE_AMOUNT = ",LINE REMITTANCE_AMOUNT," + db_STG_LINE_REMITTANCE_AMOUNT + "," + db_CONS_LINE_AMOUNT_RECEIVED + ",Fail";
                                                section1_results.add(STG_LINE_REMITTANCE_AMOUNT);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE REMITTANCE_AMOUNT" + "," + db_STG_LINE_REMITTANCE_AMOUNT + "," + db_CONS_LINE_AMOUNT_RECEIVED + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }

                                            //------------- Validate LINE ATTRIBUTE1 ----------------
                                            if (db_STG_LINE_ATTRIBUTE1.equals(db_CONS_LINE_JOB_LINK)) {
                                                String STG_LINE_ATTRIBUTE1 = ",LINE ATTRIBUTE1," + db_STG_LINE_ATTRIBUTE1 + "," + db_CONS_LINE_JOB_LINK + ",Pass";
                                                section1_results.add(STG_LINE_ATTRIBUTE1);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE ATTRIBUTE1" + "," + db_STG_LINE_ATTRIBUTE1 + "," + db_CONS_LINE_JOB_LINK + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String STG_LINE_ATTRIBUTE1 = ",LINE ATTRIBUTE1," + db_STG_LINE_ATTRIBUTE1 + "," + db_CONS_LINE_JOB_LINK + ",Fail";
                                                section1_results.add(STG_LINE_ATTRIBUTE1);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE ATTRIBUTE1" + "," + db_STG_LINE_ATTRIBUTE1 + "," + db_CONS_LINE_JOB_LINK + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }

                                            //------------- Validate LINE ATTRIBUTE2 ----------------
                                            String db_STG_LINE_ATTRIBUTE2Modified = db_STG_LINE_ATTRIBUTE2.replaceAll("\\.0*$", "");
                                            if (db_STG_LINE_ATTRIBUTE2Modified.equals(db_CONS_LINE_SEQUENCE)) {
                                                String STG_LINE_ATTRIBUTE2 = ",LINE ATTRIBUTE2," + db_STG_LINE_ATTRIBUTE2Modified + "," + db_CONS_LINE_SEQUENCE + ",Pass";
                                                section1_results.add(STG_LINE_ATTRIBUTE2);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE ATTRIBUTE2" + "," + db_STG_LINE_ATTRIBUTE2Modified + "," + db_CONS_LINE_SEQUENCE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String STG_LINE_ATTRIBUTE2 = ",LINE ATTRIBUTE2," + db_STG_LINE_ATTRIBUTE2Modified + "," + db_CONS_LINE_SEQUENCE + ",Fail";
                                                section1_results.add(STG_LINE_ATTRIBUTE2);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE ATTRIBUTE2" + "," + db_STG_LINE_ATTRIBUTE2Modified + "," + db_CONS_LINE_SEQUENCE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }

                                            //------------- Validate LINE RECEIPT_DATE ----------------
                                            if (db_STG_LINE_RECEIPT_DATE.equals(db_CONS_LINE_RECEIVED_DT)) {
                                                String STG_LINE_RECEIPT_DATE = ",LINE RECEIPT_DATE," + db_STG_LINE_RECEIPT_DATE + "," + db_CONS_LINE_RECEIVED_DT + ",Pass";
                                                section1_results.add(STG_LINE_RECEIPT_DATE);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE RECEIPT_DATE" + "," + db_STG_LINE_RECEIPT_DATE + "," + db_CONS_LINE_RECEIVED_DT + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String STG_LINE_RECEIPT_DATE = ",LINE RECEIPT_DATE," + db_STG_LINE_RECEIPT_DATE + "," + db_CONS_LINE_RECEIVED_DT + ",Fail";
                                                section1_results.add(STG_LINE_RECEIPT_DATE);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE RECEIPT_DATE" + "," + db_STG_LINE_RECEIPT_DATE + "," + db_CONS_LINE_RECEIVED_DT + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }

                                            //--------------------  Validation BATCH_NAME ---------------
                                            if (db_CONS_BATCH_TRL_REF.equals(db_STG_LINE_BATCH_NAME)) {
                                                String STG_BATCH_NAME = ",BATCH_NAME," + db_STG_LINE_BATCH_NAME + "," + db_CONS_BATCH_TRL_REF + ",Pass";
                                                section1_results.add(STG_BATCH_NAME);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",BATCH_NAME" + "," + db_STG_LINE_BATCH_NAME + "," + db_CONS_BATCH_TRL_REF + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String STG_BATCH_NAME = ",BATCH_NAME," + db_STG_LINE_BATCH_NAME + "," + db_CONS_BATCH_TRL_REF + ",Fail";
                                                section1_results.add(STG_BATCH_NAME);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",BATCH_NAME" + "," + db_STG_LINE_BATCH_NAME + "," + db_CONS_BATCH_TRL_REF + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }

                                            //------------- Validate BATCH_AMOUNT ----------------
                                            if ((db_STG_LINE_BATCH_AMOUNT != null) && (db_CONS_BATCH_VALUE != null)) {
                                                if (db_STG_LINE_BATCH_AMOUNT.equals(db_CONS_BATCH_VALUE)) {
                                                    String STG_BATCH_AMOUNT = ",BATCH_AMOUNT," + db_STG_LINE_BATCH_AMOUNT + "," + db_CONS_BATCH_VALUE + ",Pass";
                                                    section1_results.add(STG_BATCH_AMOUNT);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",BATCH_AMOUNT" + "," + db_STG_LINE_BATCH_AMOUNT + "," + db_CONS_BATCH_VALUE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String STG_BATCH_AMOUNT = ",BATCH_AMOUNT," + db_STG_LINE_BATCH_AMOUNT + "," + db_CONS_BATCH_VALUE + ",Fail";
                                                    section1_results.add(STG_BATCH_AMOUNT);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",BATCH_AMOUNT" + "," + db_STG_LINE_BATCH_AMOUNT + "," + db_CONS_BATCH_VALUE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            }

                                            //--------------------  Validation BATCH_RECORD_COUNT ---------------
                                            if (db_CONS_BATCH_RECORD_COUNT.equals(db_STG_LINE_BATCH_RECORD_COUNT)) {
                                                String STG_BATCH_RECORD_COUNT = ",BATCH_RECORD_COUNT," + db_STG_LINE_BATCH_RECORD_COUNT + "," + db_CONS_BATCH_RECORD_COUNT + ",Pass";
                                                section1_results.add(STG_BATCH_RECORD_COUNT);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",BATCH_RECORD_COUNT" + "," + db_STG_LINE_BATCH_RECORD_COUNT + "," + db_CONS_BATCH_RECORD_COUNT + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String STG_BATCH_RECORD_COUNT = ",BATCH_RECORD_COUNT," + db_STG_LINE_BATCH_RECORD_COUNT + "," + db_CONS_BATCH_RECORD_COUNT + ",Fail";
                                                section1_results.add(STG_BATCH_RECORD_COUNT);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",BATCH_RECORD_COUNT" + "," + db_STG_LINE_BATCH_RECORD_COUNT + "," + db_CONS_BATCH_RECORD_COUNT + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }


                                            //----------------------- LINE Reference table  -----------------------------
                                            String db_ref_line_CUSTOMER_NUMBER_meaning = "null";
                                            String db_ref_line_RECEIPT_METHOD_meaning = "null";
                                            String db_ref_line_BILL_TO_LOCATION_meaning = "null";

                                            String PulseARReceipts_refARLockbox_accNumber = connect_db.executeQuery_DB("Reference", "ARReceipts_REF_CUST_ACCOUNT_NUMBER", "BMS");
                                            String PulseARReceipts_refARLockbox_location = connect_db.executeQuery_DB("Reference", "ARReceipts_REF_CUST_LOCATION", "BMS");
                                            String PulseARReceipts_refARLockbox_receiptName = connect_db.executeQuery_DB("Reference", "ARReceipts_REF_ARLOCKBOX_RECEIPT_NAME", "BMS");

                                            //------------------------------LINE_CUSTOMER_NUMBER-------------------------------
                                            SQLResultset = SQLstmt.executeQuery(PulseARReceipts_refARLockbox_accNumber + " WHERE ACCOUNT_NUMBER='" + db_STG_LINE_CUSTOMER_NUMBER + "' and LOCATION='" + db_STG_LINE_BILL_TO_LOCATION + "'");
                                            //SQLResultset = SQLstmt.executeQuery("select ACCOUNT_NUMBER as accountNumber from DLG_FSH_REF_CUST where ACCOUNT_NUMBER='" + db_STG_LINE_CUSTOMER_NUMBER + "' and LOCATION='" + db_STG_LINE_BILL_TO_LOCATION + "'");
                                            while (SQLResultset.next()) {
                                                db_ref_line_CUSTOMER_NUMBER_meaning = SQLResultset.getString("accountNumber");
                                            }
                                            if (db_ref_line_CUSTOMER_NUMBER_meaning.equals("null")) {
                                                String ref_DESTINATION_ACCOUNT_meaning = ",LINE_CUSTOMER_NUMBER Reference_Table," + "Transformation value not found" + "," + db_STG_LINE_CUSTOMER_NUMBER + ",Fail";
                                                section1_results.add(ref_DESTINATION_ACCOUNT_meaning);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_CUSTOMER_NUMBER Reference_Table" + "," + "Transformation value not found" + "," + db_STG_LINE_CUSTOMER_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            } else if (db_ref_line_CUSTOMER_NUMBER_meaning != null) {
                                                if (db_ref_line_CUSTOMER_NUMBER_meaning.equals(db_STG_LINE_CUSTOMER_NUMBER)) {
                                                    String ref_DESTINATION_ACCOUNT_meaning = ",LINE_CUSTOMER_NUMBER Reference_Table," + db_ref_line_CUSTOMER_NUMBER_meaning + "," + db_STG_LINE_CUSTOMER_NUMBER + ",Pass";
                                                    section1_results.add(ref_DESTINATION_ACCOUNT_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_CUSTOMER_NUMBER Reference_Table" + "," + db_ref_line_CUSTOMER_NUMBER_meaning + "," + db_STG_LINE_CUSTOMER_NUMBER + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String ref_DESTINATION_ACCOUNT_meaning = ",LINE_CUSTOMER_NUMBER Reference_Table," + db_ref_line_CUSTOMER_NUMBER_meaning + "," + db_STG_LINE_CUSTOMER_NUMBER + ",Fail";
                                                    section1_results.add(ref_DESTINATION_ACCOUNT_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_CUSTOMER_NUMBER Reference_Table" + "," + db_ref_line_CUSTOMER_NUMBER_meaning + "," + db_STG_LINE_CUSTOMER_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            }

                                            //------------------------------LINE_RECEIPT_METHOD-------------------------------
                                            SQLResultset = SQLstmt.executeQuery(PulseARReceipts_refARLockbox_receiptName + " WHERE RECEIPT_METHOD_NAME='" + db_STG_LINE_RECEIPT_METHOD + "'");
                                            //SQLResultset = SQLstmt.executeQuery("select RECEIPT_METHOD_NAME as receiptMethod from DLG_FSH_REF_AR_LOCKBOX where RECEIPT_METHOD_NAME='" + db_STG_LINE_RECEIPT_METHOD + "'");
                                            while (SQLResultset.next()) {
                                                db_ref_line_RECEIPT_METHOD_meaning = SQLResultset.getString("receiptMethod");
                                                System.out.println(db_ref_line_RECEIPT_METHOD_meaning);
                                            }
                                            if (db_ref_line_RECEIPT_METHOD_meaning.equals("null")) {
                                                String ref_DESTINATION_ACCOUNT_meaning = ",LINE_RECEIPT_METHOD Reference_Table," + "Transformation value not found" + "," + db_STG_LINE_RECEIPT_METHOD + ",Fail";
                                                section1_results.add(ref_DESTINATION_ACCOUNT_meaning);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_RECEIPT_METHOD Reference_Table" + "," + "Transformation value not found" + "," + db_STG_LINE_RECEIPT_METHOD + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            } else if (db_ref_line_RECEIPT_METHOD_meaning != null) {
                                                if (db_ref_line_RECEIPT_METHOD_meaning.equals(db_STG_LINE_RECEIPT_METHOD)) {
                                                    String ref_DESTINATION_ACCOUNT_meaning = ",LINE_RECEIPT_METHOD Reference_Table," + db_ref_line_RECEIPT_METHOD_meaning + "," + db_STG_LINE_RECEIPT_METHOD + ",Pass";
                                                    section1_results.add(ref_DESTINATION_ACCOUNT_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_RECEIPT_METHOD Reference_Table" + "," + db_ref_line_RECEIPT_METHOD_meaning + "," + db_STG_LINE_RECEIPT_METHOD + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String ref_DESTINATION_ACCOUNT_meaning = ",LINE_RECEIPT_METHOD Reference_Table," + db_ref_line_RECEIPT_METHOD_meaning + "," + db_STG_LINE_RECEIPT_METHOD + ",Fail";
                                                    section1_results.add(ref_DESTINATION_ACCOUNT_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_RECEIPT_METHOD Reference_Table" + "," + db_ref_line_RECEIPT_METHOD_meaning + "," + db_STG_LINE_RECEIPT_METHOD + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            }


                                            //------------------------------LINE_BILL_TO_LOCATION-------------------------------
                                            SQLResultset = SQLstmt.executeQuery(PulseARReceipts_refARLockbox_location + " WHERE ACCOUNT_NUMBER='" + db_STG_LINE_CUSTOMER_NUMBER + "' and LOCATION='" + db_STG_LINE_BILL_TO_LOCATION + "'");
                                            //SQLResultset = SQLstmt.executeQuery("select LOCATION as location from DLG_FSH_REF_CUST where ACCOUNT_NUMBER='" + db_STG_LINE_CUSTOMER_NUMBER + "' and LOCATION='" + db_STG_LINE_BILL_TO_LOCATION + "'");
                                            while (SQLResultset.next()) {
                                                db_ref_line_BILL_TO_LOCATION_meaning = SQLResultset.getString("location");
                                            }
                                            if (db_ref_line_BILL_TO_LOCATION_meaning.equals("null")) {
                                                String ref_DESTINATION_ACCOUNT_meaning = ",LINE_BILL_TO_LOCATION Reference_Table," + "Transformation value not found" + "," + db_STG_LINE_BILL_TO_LOCATION + ",Fail";
                                                section1_results.add(ref_DESTINATION_ACCOUNT_meaning);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_BILL_TO_LOCATION Reference_Table" + "," + "Transformation value not found" + "," + db_STG_LINE_BILL_TO_LOCATION + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            } else if (db_ref_line_BILL_TO_LOCATION_meaning != null) {
                                                if (db_ref_line_BILL_TO_LOCATION_meaning.equals(db_STG_LINE_BILL_TO_LOCATION)) {
                                                    String ref_DESTINATION_ACCOUNT_meaning = ",LINE_BILL_TO_LOCATION Reference_Table," + db_ref_line_BILL_TO_LOCATION_meaning + "," + db_STG_LINE_BILL_TO_LOCATION + ",Pass";
                                                    section1_results.add(ref_DESTINATION_ACCOUNT_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_BILL_TO_LOCATION Reference_Table" + "," + db_ref_line_BILL_TO_LOCATION_meaning + "," + db_STG_LINE_BILL_TO_LOCATION + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String ref_DESTINATION_ACCOUNT_meaning = ",LINE_BILL_TO_LOCATION Reference_Table," + db_ref_line_BILL_TO_LOCATION_meaning + "," + db_STG_LINE_BILL_TO_LOCATION + ",Fail";
                                                    section1_results.add(ref_DESTINATION_ACCOUNT_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_BILL_TO_LOCATION Reference_Table" + "," + db_ref_line_BILL_TO_LOCATION_meaning + "," + db_STG_LINE_BILL_TO_LOCATION + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            }


                                            //----------------------- LINE STANDARDISATION start here -----------------------------

                                            //---------------- LOOKUP validation table -----------------------

                                            String db_lookup_line_CUSTOMER_NUMBER_meaning = "null";
                                            String db_lookup_line_RECEIPT_METHOD_meaning = "null";
                                            String db_lookup_line_BILL_TO_LOCATION_meaning = "null";

                                            //---------------- Validate LINE CUSTOMER_NUMBER -----------------------
                                            SQLResultset = SQLstmt.executeQuery(BMSARReceipts_fsh_sys_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'CUSTOMER_NUMBER'" + fsh_source);
                                            //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'CUSTOMER_NUMBER' and system = 'ECLI' and pattern = 'ARReceipts'");
                                            while (SQLResultset.next()) {
                                                db_lookup_line_CUSTOMER_NUMBER_meaning = SQLResultset.getString("MEANING");
                                            }
                                            if (db_lookup_line_CUSTOMER_NUMBER_meaning.equals("null")) {
                                                String lookup_line_CUSTOMER_NUMBER_meaning = ",LINE CUSTOMER_NUMBER lookup," + "LookUp value not found" + "," + db_lookup_line_CUSTOMER_NUMBER_meaning + ",Fail";
                                                section1_results.add(lookup_line_CUSTOMER_NUMBER_meaning);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE CUSTOMER_NUMBER lookup" + "," + "LookUp value not found" + "," + db_lookup_line_CUSTOMER_NUMBER_meaning + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            } else if (db_lookup_line_CUSTOMER_NUMBER_meaning != null) {
                                                if (db_lookup_line_CUSTOMER_NUMBER_meaning.equals(db_lookup_line_CUSTOMER_NUMBER_meaning)) {
                                                    String lookup_line_CUSTOMER_NUMBER_meaning = ",LINE CUSTOMER_NUMBER lookup," + db_lookup_line_CUSTOMER_NUMBER_meaning + "," + db_lookup_line_CUSTOMER_NUMBER_meaning + ",Pass";
                                                    section1_results.add(lookup_line_CUSTOMER_NUMBER_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE CUSTOMER_NUMBER lookup" + "," + db_lookup_line_CUSTOMER_NUMBER_meaning + "," + db_lookup_line_CUSTOMER_NUMBER_meaning + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String lookup_line_CUSTOMER_NUMBER_meaning = ",LINE CUSTOMER_NUMBER lookup," + db_lookup_line_CUSTOMER_NUMBER_meaning + "," + db_lookup_line_CUSTOMER_NUMBER_meaning + ",Fail";
                                                    section1_results.add(lookup_line_CUSTOMER_NUMBER_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE CUSTOMER_NUMBER lookup" + "," + db_lookup_line_CUSTOMER_NUMBER_meaning + "," + db_lookup_line_CUSTOMER_NUMBER_meaning + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            }

                                            //---------------- Validate LINE RECEIPT_METHOD -----------------------
                                            SQLResultset = SQLstmt.executeQuery(BMSARReceipts_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_CONS_LINE_PAYMENT_METHOD + "' and LOOKUP_TYPE = 'RECEIPT_METHOD'" + fsh_source);
                                            //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_LINE_PAYMENT_METHOD + "' and LOOKUP_TYPE = 'RECEIPT_METHOD' and system = 'ECLI' and pattern = 'ARReceipts'");
                                            while (SQLResultset.next()) {
                                                db_lookup_line_RECEIPT_METHOD_meaning = SQLResultset.getString("MEANING");
                                            }
                                            if (db_lookup_line_RECEIPT_METHOD_meaning.equals("null")) {
                                                String lookup_line_RECEIPT_METHOD_meaning = ",LINE RECEIPT_METHOD lookup," + "LookUp value not found" + "," + db_STG_LINE_RECEIPT_METHOD + ",Fail";
                                                section1_results.add(lookup_line_RECEIPT_METHOD_meaning);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE RECEIPT_METHOD lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_RECEIPT_METHOD + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            } else if (db_lookup_line_RECEIPT_METHOD_meaning != null) {
                                                if (db_lookup_line_RECEIPT_METHOD_meaning.equals(db_STG_LINE_RECEIPT_METHOD)) {
                                                    String lookup_line_RECEIPT_METHOD_meaning = ",LINE RECEIPT_METHOD lookup," + db_lookup_line_RECEIPT_METHOD_meaning + "," + db_STG_LINE_RECEIPT_METHOD + ",Pass";
                                                    section1_results.add(lookup_line_RECEIPT_METHOD_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE RECEIPT_METHOD lookup" + "," + db_lookup_line_RECEIPT_METHOD_meaning + "," + db_STG_LINE_RECEIPT_METHOD + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String lookup_line_RECEIPT_METHOD_meaning = ",LINE RECEIPT_METHOD lookup," + db_lookup_line_RECEIPT_METHOD_meaning + "," + db_STG_LINE_RECEIPT_METHOD + ",Fail";
                                                    section1_results.add(lookup_line_RECEIPT_METHOD_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE RECEIPT_METHOD lookup" + "," + db_lookup_line_RECEIPT_METHOD_meaning + "," + db_STG_LINE_RECEIPT_METHOD + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            }

                                            //---------------- Validate LINE BILL_TO_LOCATION -----------------------
                                            SQLResultset = SQLstmt.executeQuery(BMSARReceipts_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_CONS_LINE_SITE_REF + "' and LOOKUP_TYPE = 'SITE_REF'" + fsh_source);
                                            //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_LINE_SITE_REF + "' and LOOKUP_TYPE = 'SITE_REF' and system = 'ECLI' and pattern = 'ARReceipts'");
                                            while (SQLResultset.next()) {
                                                db_lookup_line_BILL_TO_LOCATION_meaning = SQLResultset.getString("MEANING");
                                            }
                                            if (db_lookup_line_BILL_TO_LOCATION_meaning.equals("null")) {
                                                String lookup_line_BILL_TO_LOCATION_meaning = ",LINE BILL_TO_LOCATION lookup," + "LookUp value not found" + "," + db_STG_LINE_BILL_TO_LOCATION + ",Fail";
                                                section1_results.add(lookup_line_BILL_TO_LOCATION_meaning);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE BILL_TO_LOCATION lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_BILL_TO_LOCATION + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            } else if (db_lookup_line_BILL_TO_LOCATION_meaning != null) {
                                                if (db_lookup_line_BILL_TO_LOCATION_meaning.equals(db_STG_LINE_BILL_TO_LOCATION)) {
                                                    String lookup_line_BILL_TO_LOCATION_meaning = ",LINE BILL_TO_LOCATION lookup," + db_lookup_line_BILL_TO_LOCATION_meaning + "," + db_STG_LINE_BILL_TO_LOCATION + ",Pass";
                                                    section1_results.add(lookup_line_BILL_TO_LOCATION_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE BILL_TO_LOCATION lookup" + "," + db_lookup_line_BILL_TO_LOCATION_meaning + "," + db_STG_LINE_BILL_TO_LOCATION + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String lookup_line_BILL_TO_LOCATION_meaning = ",LINE BILL_TO_LOCATION lookup," + db_lookup_line_BILL_TO_LOCATION_meaning + "," + db_STG_LINE_BILL_TO_LOCATION + ",Fail";
                                                    section1_results.add(lookup_line_BILL_TO_LOCATION_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE BILL_TO_LOCATION lookup" + "," + db_lookup_line_BILL_TO_LOCATION_meaning + "," + db_STG_LINE_BILL_TO_LOCATION + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            }

                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                //----------------- Validate the Over all Status -------------------
                System.out.println("Looping ++  CONS_flag " + CONS_flag);
                String Overall_status = null;
                String Overall_stg_status = null;
                if (CONS_flag > 0) {
                    CONS_STATUS.add("Fail");
                    Overall_status = "Fail";
                } else {
                    CONS_STATUS.add("Pass");
                    Overall_status = "Pass";
                }


                if (CONS_flag > 0) {
                    OverAllStatus.add("Fail");
                } else {
                    OverAllStatus.add("Pass");
                }

                String tbl_summary_filelist = Source + "," + pattern + "," + file_name + "," + "CONS TO STG " + "," + load_date + "," + OverAllStatus + "," + btc_BATCH_PKEY;
                //String tbl_summary_filelist = Source + "," + pattern + "," + file_name + "," + load_dateFormat + "," + "CONST TO STG " + "," + OverAllStatus;
                summary_results_tbl.add(tbl_summary_filelist);

                list.addAll(section1_results);
                list.addAll(section2_results);

                // ---------------- HTML Report generation ------------------------
                report_generation.report_Test1(section1_results, "Header", xml_file_name, "CONSOLIDATION LAYER - STAGING LAYER", "BMS_AR_Receipts", "BMS_AR_Receipts CONSOLIDATION LAYER - STAGING LAYER", "");
                report_generation.report_Test1(section1_results, "Section2", xml_file_name, "CONSOLIDATION LAYER - STAGING LAYER", "BMS_AR_Receipts", "BMS_AR_Receipts CONSOLIDATION LAYER - STAGING LAYER", "");
                report_generation.report_Test1(section2_results, "Mandatory", xml_file_name, "Mandatory Check", "BMS_AR_Receipts", "BMS_AR_Receipts CONSOLIDATION LAYER - STAGING LAYER", "");

                table_detail_report.detail_report_tbl(section2_results_tbl);
            }

            state_model.section_method(file_list, CONS_STATUS, "N/A", OverAllStatus, "BMS_ARReceipts_Summary");
            table_summary_report.summary_report_tbl(summary_results_tbl);
        }


    }

}