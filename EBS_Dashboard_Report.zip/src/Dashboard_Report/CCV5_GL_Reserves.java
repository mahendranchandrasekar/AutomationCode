package Dashboard_Report;

import java.io.File;
import java.io.IOException;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONException;

public class CCV5_GL_Reserves {

    static Statement SQLstmt = null;
    static ResultSet SQLResultset_fsh = null;

    public static HTML_Report_Generation_DB_EVO report_generation;
    public static HTML_Report_Generation_State_Model_B4C report_generation_state;
    public static SCH_EVO_PC_State_Model_B4C state_model;

    public static Table_Detail_Report table_detail_report;
    public static Table_Summary_Report table_summary_report;
    public static connectDatabase connect_db;

    public static void main(String[] args) throws IOException, SQLException, JSONException {
        report_generation = new HTML_Report_Generation_DB_EVO();
        report_generation_state = new HTML_Report_Generation_State_Model_B4C();
        state_model = new SCH_EVO_PC_State_Model_B4C();

        table_detail_report = new Table_Detail_Report();
        table_summary_report = new Table_Summary_Report();
        connect_db = new connectDatabase();

        //----------------------- delete the existing report --------------
        report_generation.clean_report("CCV5_GLReserves.html");
        report_generation_state.clean_report_summary("CCV5_GLReserves_Summary.html");

        /*//--------------- SIT  database details -------------------
        String URL_SIT1 = "jdbc:oracle:thin:@dbs119dev.gwd.grpinf.net:1521/FSHDTST3";
        String Username_SIT1 = "FSH_ORA_DATA";
        String password_SIT1 = "Development_Test3";*/

        //--------------- SIT  database details -------------------
        /*String URL_SIT1 = "jdbc:oracle:thin:@dbs119dev.gwd.grpinf.net:1521/FSHDTST4";
        String Username_SIT1 = "FSH_ORA_DATA";
        String password_SIT1 = "XdbvFm!dm7dVCzWE";


        //--------------- EBS  database details -------------------
        String URL_ICSI = "jdbc:oracle:thin:@dcn2ddbx340.gwd.grpinf.net:1618:ICSI";
        String Username_ICSI = "apps";
        String password_ICSI = "apps4icsi";*/

        List<String> file_list = new ArrayList<String>();
        List<String> list = new ArrayList<String>();
        List<String> section1_results = new ArrayList<String>();
        //List<String> section1_results = new ArrayList<String>();
        //List<String> section2_results = new ArrayList<String>();
        List<String> section4_results = new ArrayList<String>();

        List<String> OverAllStatus = new ArrayList<String>();
        List<String> CONS_STATUS = new ArrayList<String>();
        List<String> summary_results_tbl = new ArrayList<String>();

        String[] file_lists = null;
        int section1_map_row = 1;

        //--------------------- Decelaring the supporting details for reporting --------------
        String file_name = "null";
        String Source = "CCV5";
        String pattern = "GLReserves";
        String header = "Header";

        //---- Initialiing row count variables -----
        int cons_stg_map_row = 1;
        int stg_line_map_row = 1;
        int cons_mandatory_map_row = 1;

        String db_ctrl_batch_LOAD_DATE = "null";
        String db_ctrl_batch_SOURCE = "null";
        String db_ctrl_batch_STATUS = "null";


        //String file_name = "null";
        String db_cons_header_id = "null";
        String db_CONS_ID = "null";
        String db_CONS_STATUS = "null";
        String db_CONS_SOURCE = "null";
        String db_CONS_EVENT_ID = "null";
        String db_CONS_UNDERWRITER = "null";
        String db_CONS_BRAND = "null";
        String db_CONS_PRODUCT_TYPE = "null";
        String db_CONS_PRODUCT = "null";
        String db_CONS_CHANNEL = "null";
        String db_CONS_TRANSACTION_DATE = "null";
        String db_CONS_CURRENCY = "null";
        String db_CONS_LOSS_DATE = "null";
        String db_CONS_EXCHANGE_RATE = "null";
        String db_CONS_EXCHANGE_RATE_TYPE = "null";
        String db_CONS_TRANSACTION_AMOUNT = "null";
        String db_CONS_BASE_CURRENCY_AMOUNT = "null";
        String db_CONS_CLAIM_NUMBER = "null";
        String db_CONS_DTI_CLASS = "null";
        String db_CONS_CLASS_OF_BUSINESS = "null";
        String db_CONS_POLICY_NUMBER = "null";
        String db_CONS_DEBTOR_NAME = "null";
        String db_CONS_LINE_OF_BUSINESS = "null";
        String db_CONS_DEBTOR_REFERENCE = "null";
        String STG_HDR_STATUS = "null";
        String load_date = null;
        Date load_dateFormat = null;
        String btc_BATCH_PKEY = null;


        String db_STG_CC_HEADER_ID = "null";
        String db_STG_SOURCE = "null";
        String db_STG_SOURCE_EVENT_ID = "null";
        String db_STG_UNDERWRITER = "null";
        String db_STG_SUMMARY_FLAG = "null";
        String db_STG_BRAND = "null";
        String db_STG_PRODUCT_TYPE = "null";
        String db_STG_PRODUCT = "null";
        String db_STG_CHANNEL = "null";
        String db_STG_TRANSACTION_DATE = "null";
        String db_STG_CURRENCY_CODE = "null";
        String db_STG_RESERVES_FLAG = "null";
        String db_STG_PRODUCT_KEY = "null";
        String db_STG_LOSS_DATE = "null";
        String db_STG_EXCHANGE_RATE_TYPE = "null";
        String db_STG_EXCHANGE_RATE = "null";
        String db_STG_TRANSACTION_AMOUNT = "null";
        String db_STG_BASE_CURRENCY_AMOUNT = "null";
        String db_STG_CLAIM_NUMBER = "null";
        String db_STG_FSH_ATTRIBUTE2 = "null";
        String db_STG_FSH_ATTRIBUTE3 = "null";
        String db_STG_POLICY_NUMBER = "null";
        String db_STG_LINE_OF_BUSINESS = "null";
        String db_STG_DEBTOR_NAME = "null";
        String db_STG_DEBTOR_REFERENCE = "null";
        String db_STG_ENTITY_TYPE_CODE = "null";
        String db_STG_EVENT_CODE = "null";

        String xmlfile_name = "null";
        String xml_file_name1 = null;

        //-------- Connect to Database --------------
        connect_db.createConnection("SIT2");
        //table_detail_report.detail_report_tbl_delete(connection, Source);


        //------ get the new file from batch control table --------------
        boolean newRecord = true;
        String outSQL = connect_db.executeQuery_DB("BATCH", "GLReserves_batchCtl", "CCV5");
        SQLstmt = connect_db.resStatement();

        SQLResultset_fsh = SQLstmt.executeQuery(outSQL);
        while (SQLResultset_fsh.next()) {
            file_list.add(SQLResultset_fsh.getString("FILE_NAME"));
            System.out.println("File name---" + SQLResultset_fsh.getString("FILE_NAME"));
            list.addAll(section1_results);
        }

        // ---------------------------------- Get the batch PKEY ----------------------
        String outSQL_bkey = connect_db.executeQuery_DB("BATCH", "GLReserves_batchCtl", "CCV5");

        SQLResultset_fsh = SQLstmt.executeQuery(outSQL_bkey);
        while (SQLResultset_fsh.next()) {
            btc_BATCH_PKEY = SQLResultset_fsh.getString("BATCH_PKEY");
        }


        // ---------------------------------- Check the new file ----------------------
        SQLResultset_fsh = SQLstmt.executeQuery(outSQL);
        if (!SQLResultset_fsh.next()) {
            System.out.println("No new Travel_GLReserves files have been received to FSH ");
            newRecord = false;
            String nonewfile = ",FILE_NAME," + "No new Travel_GLReserves files have been received to FSH" + "," + "," + ",Pass";
            section1_results.add(nonewfile);
            list.addAll(section1_results);
        }

        if (newRecord) {

            //------------------------ Section 1 Start Print all the new file in the report-------------------
            for (String num_file : file_list) {
                file_lists = num_file.split(",");
                for (String file_list1 : file_lists) {
                    xml_file_name1 = file_list1;
                    //int section1_map_row = 1;
                    String newfile = section1_map_row + ",FILE_NAME," + xml_file_name1 + "," + xml_file_name1 + ",Pass";
                    section1_map_row++;
                    section1_results.add(newfile);
                }
            }
            list.addAll(section1_results);
            //report_generation.report_Test1(section1_results, "Section1", xml_file_name1, "B4C BC CONS BATCH TABLE VALIDATION", "B4C_SCHBilling", "B4C BC VALIDATION");
            //------------------------ Section 1 End ----------------------------------------------
        }

        List<String> list_header = new ArrayList<String>(); // -- Add all the header id
        if (newRecord) {
            //------------ Split the file names form the list --------------
            for (String xml_file_name : file_list) {
                int section2_map_row = 1;
                int CONS_flag = 0;
                List<String> section2_results = new ArrayList<String>();
                List<String> section3_results = new ArrayList<String>();
                List<String> section2_results_tbl = new ArrayList<String>();

                file_name = xml_file_name;
                //CCV5_GLRESERVES_65024_20191105

                //-------------- Validation Cons to Stag table ----------------
                String CCV5GLReserves_consSqlQuery = connect_db.executeQuery_DB("CCV5GL", "GLReserves_Cons","CCV5");
                SQLResultset_fsh = SQLstmt.executeQuery(CCV5GLReserves_consSqlQuery + "'"+file_name+ "'" );
                //SQLResultset_fsh = SQLstmt.executeQuery("SELECT * from DLG_FSH_CONS_CCV5_GL_RES_HDR WHERE FILE_NAME = '" + xml_file_name + "'");
                while (SQLResultset_fsh.next()) {
                    db_CONS_ID = SQLResultset_fsh.getString("ID");
                    list_header.add(db_CONS_ID);
                }

                for (int i = 0; i < list_header.size(); i++) {
                    SQLResultset_fsh = SQLstmt.executeQuery(CCV5GLReserves_consSqlQuery + "'"+file_name+ "' and ID = '" + list_header.get(i) + "' " );
                      //SQLResultset_fsh = SQLstmt.executeQuery("SELECT * from DLG_FSH_CONS_CCV5_GL_RES_HDR WHERE FILE_NAME = '" + xml_file_name + "' and ID ='" + list_header.get(i) + "'");
                        while (SQLResultset_fsh.next()) {
                            db_CONS_ID = SQLResultset_fsh.getString("ID");
                            db_CONS_STATUS = SQLResultset_fsh.getString("STATUS");
                            db_CONS_SOURCE = SQLResultset_fsh.getString("SOURCE");
                            db_CONS_EVENT_ID = SQLResultset_fsh.getString("EVENT_ID");
                            db_CONS_UNDERWRITER = SQLResultset_fsh.getString("UNDERWRITER");
                            db_CONS_BRAND = SQLResultset_fsh.getString("BRAND");
                            db_CONS_PRODUCT = SQLResultset_fsh.getString("PRODUCT");
                            db_CONS_PRODUCT_TYPE = SQLResultset_fsh.getString("PRODUCT_TYPE");
                            db_CONS_CHANNEL = SQLResultset_fsh.getString("CHANNEL");
                            db_CONS_TRANSACTION_DATE = SQLResultset_fsh.getString("TRANSACTION_DATE");
                            db_CONS_CURRENCY = SQLResultset_fsh.getString("CURRENCY");
                            db_CONS_LOSS_DATE = SQLResultset_fsh.getString("LOSS_DATE");
                            db_CONS_EXCHANGE_RATE = SQLResultset_fsh.getString("EXCHANGE_RATE");
                            db_CONS_EXCHANGE_RATE_TYPE = SQLResultset_fsh.getString("EXCHANGE_RATE_TYPE");
                            db_CONS_TRANSACTION_AMOUNT = SQLResultset_fsh.getString("TRANSACTION_AMOUNT");
                            db_CONS_BASE_CURRENCY_AMOUNT = SQLResultset_fsh.getString("BASE_CURRENCY_AMOUNT");
                            db_CONS_CLAIM_NUMBER = SQLResultset_fsh.getString("CLAIM_NUMBER");
                            db_CONS_DTI_CLASS = SQLResultset_fsh.getString("DTI_CLASS");
                            db_CONS_CLASS_OF_BUSINESS = SQLResultset_fsh.getString("CLASS_OF_BUSINESS");
                            db_CONS_POLICY_NUMBER = SQLResultset_fsh.getString("POLICY_NUMBER");
                            db_CONS_LINE_OF_BUSINESS = SQLResultset_fsh.getString("LINE_OF_BUSINESS");
                            //db_CONS_DEBTOR_NAME = SQLResultset_fsh.getString("DEBTOR_NAME");
                            //db_CONS_DEBTOR_REFERENCE = SQLResultset_fsh.getString("DEBTOR_REFERENCE");
                            STG_HDR_STATUS = SQLResultset_fsh.getString("STATUS");
                            String db_file_name = SQLResultset_fsh.getString("FILE_NAME");


                            //Mandatory validation
                            //ID - mandatory validation
                            if ((db_CONS_ID == null) && (db_CONS_STATUS != "REVIEW")) {

                                String cons_ID = cons_mandatory_map_row+ "," + db_CONS_ID + ",ID," + "ID : " + db_CONS_ID + "," + "ID was not found," + db_CONS_STATUS + "," + "Fail";
                                section2_results.add(cons_ID);
                                cons_mandatory_map_row++;
                            } else {
                                String cons_ID = cons_mandatory_map_row+"," + db_CONS_ID + ",ID," + "ID : " + db_CONS_ID + "," + "ID was found," + db_CONS_STATUS + "," + "Pass";
                                section2_results.add(cons_ID);
                                cons_mandatory_map_row++;
                            }

                            //SOURCE_EVENT_ID - mandatory validation
                            if ((db_STG_SOURCE_EVENT_ID == null) && (STG_HDR_STATUS != "REVIEW")) {

                                String stg_header_id = "," + ",SOURCE_EVENT_ID," + "SOURCE_EVENT_ID : " + db_STG_SOURCE_EVENT_ID + "," + "SOURCE_EVENT_ID was not found," + STG_HDR_STATUS + "," + "Fail";
                                section2_results.add(stg_header_id);
                            } else {
                                String stg_header_id = "," + ",SOURCE_EVENT_ID," + "SOURCE_EVENT_ID : " + db_STG_SOURCE_EVENT_ID + "," + "SOURCE_EVENT_ID was found," + STG_HDR_STATUS + "," + "Pass";
                                section2_results.add(stg_header_id);
                            }


                            //UNDERWRITER - mandatory validation
                            if ((db_STG_UNDERWRITER == null) && (STG_HDR_STATUS != "REVIEW")) {

                                String stg_header_id = "," +  ",UNDERWRITER," + "UNDERWRITER : " + db_STG_UNDERWRITER + "," + "UNDERWRITER was not found," + STG_HDR_STATUS + "," + "Fail";
                                section2_results.add(stg_header_id);
                            } else {
                                String stg_header_id = "," +  ",UNDERWRITER," + "UNDERWRITER : " + db_STG_UNDERWRITER + "," + "UNDERWRITER was found," + STG_HDR_STATUS + "," + "Pass";
                                section2_results.add(stg_header_id);
                            }

                            //SOURCE - mandatory validation(BATCH)
                            if ((db_CONS_SOURCE == null) && (db_CONS_STATUS != "REVIEW")) {

                                String stg_header_id = "," + ",SOURCE," + "SOURCE : " + db_CONS_SOURCE + "," + "SOURCE was not found," + db_CONS_STATUS + "," + "Fail";
                                section2_results.add(stg_header_id);
                            } else {
                                String stg_header_id = "," + ",SOURCE," + "SOURCE : " + db_CONS_SOURCE + "," + "SOURCE was found," + db_CONS_STATUS + "," + "Pass";
                                section2_results.add(stg_header_id);
                            }

                            //EVENT_ID - mandatory validation(BATCH)
                            if ((db_CONS_EVENT_ID == null) && (db_ctrl_batch_STATUS != "REVIEW")) {

                                String CONS_EVENT_ID = "," + ",EVENT_ID," + "EVENT_ID : " + db_CONS_EVENT_ID + "," + "EVENT_ID was not found," + db_CONS_STATUS + "," + "Fail";
                                section2_results.add(CONS_EVENT_ID);
                            } else {
                                String CONS_EVENT_ID = "," + ",EVENT_ID," + "EVENT_ID : " + db_CONS_EVENT_ID + "," + "EVENT_ID was found," + db_CONS_STATUS + "," + "Pass";
                                section2_results.add(CONS_EVENT_ID);
                            }

                            //BRAND - mandatory validation
                            if ((db_CONS_BRAND == null) && (db_CONS_STATUS != "REVIEW")) {

                                String cons_BRAND = "," + ",BRAND," + "BRAND : " + db_CONS_BRAND + "," + "BRAND was not found," + db_CONS_STATUS + "," + "Fail";
                                section2_results.add(cons_BRAND);
                            } else {
                                String cons_BRAND = "," + ",BRAND," + "BRAND : " + db_CONS_BRAND + "," + "BRAND was found," + db_CONS_STATUS + "," + "Pass";
                                section2_results.add(cons_BRAND);
                            }

                            //UNDERWRITER - mandatory validation
                            if ((db_CONS_UNDERWRITER == null) && (db_CONS_STATUS != "REVIEW")) {

                                String CONS_UNDERWRITER = "," + ",UNDERWRITER," + "UNDERWRITER : " + db_CONS_UNDERWRITER + "," + "UNDERWRITER was not found," + db_CONS_STATUS + "," + "Fail";
                                section2_results.add(CONS_UNDERWRITER);
                            } else {
                                String CONS_UNDERWRITER = "," + ",UNDERWRITER," + "UNDERWRITER : " + db_CONS_UNDERWRITER + "," + "UNDERWRITER was found," + db_CONS_STATUS + "," + "Pass";
                                section2_results.add(CONS_UNDERWRITER);
                            }

                            //PRODUCT - mandatory validation
                            if ((db_CONS_PRODUCT == null) && (db_CONS_STATUS != "REVIEW")) {

                                String cons_PRODUCT = "," + ",PRODUCT," + "PRODUCT : " + db_CONS_PRODUCT + "," + "PRODUCT was not found," + db_CONS_STATUS + "," + "Fail";
                                section2_results.add(cons_PRODUCT);
                            } else {
                                String cons_PRODUCT = "," + ",PRODUCT," + "PRODUCT : " + db_CONS_PRODUCT + "," + "PRODUCT was found," + db_CONS_STATUS + "," + "Pass";
                                section2_results.add(cons_PRODUCT);
                            }

                            //PRODUCT_TYPE - mandatory validation
                            if ((db_CONS_PRODUCT_TYPE == null) && (db_CONS_STATUS != "REVIEW")) {

                                String cons_PRODUCT_TYPE = "," + ",PRODUCT_TYPE," + "PRODUCT_TYPE : " + db_CONS_PRODUCT_TYPE + "," + "PRODUCT_TYPE was not found," + db_CONS_STATUS + "," + "Fail";
                                section2_results.add(cons_PRODUCT_TYPE);
                            } else {
                                String cons_PRODUCT_TYPE = "," + ",PRODUCT_TYPE," + "PRODUCT_TYPE : " + db_CONS_PRODUCT_TYPE + "," + "PRODUCT_TYPE was found," + db_CONS_STATUS + "," + "Pass";
                                section2_results.add(cons_PRODUCT_TYPE);
                            }

                            //CHANNEL - mandatory validation
                            if ((db_CONS_CHANNEL == null) && (db_CONS_STATUS != "REVIEW")) {

                                String CONS_CHANNEL = "," + ",CHANNEL," + "CHANNEL : " + db_CONS_CHANNEL + "," + "CHANNEL was not found," + db_CONS_STATUS + "," + "Fail";
                                section2_results.add(CONS_CHANNEL);
                            } else {
                                String CONS_CHANNEL = "," + ",CHANNEL," + "CHANNEL : " + db_CONS_CHANNEL + "," + "CHANNEL was found," + db_CONS_STATUS + "," + "Pass";
                                section2_results.add(CONS_CHANNEL);
                            }

                            //TRANSACTION_DATE - mandatory validation
                            if ((db_CONS_TRANSACTION_DATE == null) && (db_CONS_STATUS != "REVIEW")) {

                                String cons_TRANSACTION_DATE = "," + db_CONS_ID + ",TRANSACTION_DATE," + "TRANSACTION_DATE : " + db_CONS_TRANSACTION_DATE + "," + "TRANSACTION_DATE was not found," + db_CONS_STATUS + "," + "Fail";
                                section2_results.add(cons_TRANSACTION_DATE);
                            } else {
                                String cons_TRANSACTION_DATE = "," + db_CONS_ID + ",TRANSACTION_DATE," + "TRANSACTION_DATE : " + db_CONS_TRANSACTION_DATE + "," + "TRANSACTION_DATE was found," + db_CONS_STATUS + "," + "Pass";
                                section2_results.add(cons_TRANSACTION_DATE);
                            }


                            //LOSS_DATE - mandatory validation
                            if ((db_CONS_LOSS_DATE == null) && (db_CONS_STATUS != "REVIEW")) {

                                String CONS_LOSS_DATE = "," + ",LOSS_DATE," + "LOSS_DATE : " + db_CONS_LOSS_DATE + "," + "LOSS_DATE was not found," + db_CONS_STATUS + "," + "Fail";
                                section2_results.add(CONS_LOSS_DATE);
                            } else {
                                String CONS_LOSS_DATE = "," + ",LOSS_DATE," + "LOSS_DATE : " + db_CONS_LOSS_DATE + "," + "LOSS_DATE was found," + db_CONS_STATUS + "," + "Pass";
                                section2_results.add(CONS_LOSS_DATE);
                            }

                            //CURRENCY - mandatory validation
                            if ((db_CONS_CURRENCY == null) && (db_CONS_STATUS != "REVIEW")) {

                                String cons_CURRENCY = "," + ",CURRENCY," + "CURRENCY : " + db_CONS_CURRENCY + "," + "CURRENCY was not found," + db_CONS_STATUS + "," + "Fail";
                                section2_results.add(cons_CURRENCY);
                            } else {
                                String cons_CURRENCY = "," + ",CURRENCY," + "CURRENCY : " + db_CONS_CURRENCY + "," + "CURRENCY was found," + db_CONS_STATUS + "," + "Pass";
                                section2_results.add(cons_CURRENCY);
                            }


                            //EXCHANGE_RATE - mandatory validation
                            if ((db_CONS_EXCHANGE_RATE == null) && (db_CONS_STATUS != "REVIEW")) {

                                String CONS_EXCHANGE_RATE = "," + ",EXCHANGE_RATE," + "EXCHANGE_RATE : " + db_CONS_EXCHANGE_RATE + "," + "EXCHANGE_RATE was not found," + db_CONS_STATUS + "," + "Fail";
                                section2_results.add(CONS_EXCHANGE_RATE);
                            } else {
                                String CONS_EXCHANGE_RATE = "," + ",EXCHANGE_RATE," + "EXCHANGE_RATE : " + db_CONS_EXCHANGE_RATE + "," + "EXCHANGE_RATE was found," + db_CONS_STATUS + "," + "Pass";
                                section2_results.add(CONS_EXCHANGE_RATE);
                            }

                            //EXCHANGE_RATE_TYPE - mandatory validation
                            if ((db_CONS_EXCHANGE_RATE_TYPE == null) && (db_CONS_STATUS != "REVIEW")) {

                                String cons_EXCHANGE_RATE_TYPE = "," + ",EXCHANGE_RATE_TYPE," + "EXCHANGE_RATE_TYPE : " + db_CONS_EXCHANGE_RATE_TYPE + "," + "EXCHANGE_RATE_TYPE was not found," + db_CONS_STATUS + "," + "Fail";
                                section2_results.add(cons_EXCHANGE_RATE_TYPE);
                            } else {
                                String cons_EXCHANGE_RATE_TYPE = "," + ",EXCHANGE_RATE_TYPE," + "EXCHANGE_RATE_TYPE : " + db_CONS_EXCHANGE_RATE_TYPE + "," + "EXCHANGE_RATE_TYPE was found," + db_CONS_STATUS + "," + "Pass";
                                section2_results.add(cons_EXCHANGE_RATE_TYPE);
                            }

                            //TRANSACTION_AMOUNT - mandatory validation
                            if ((db_CONS_TRANSACTION_AMOUNT == null) && (db_CONS_STATUS != "REVIEW")) {

                                String cons_TRANSACTION_AMOUNT = "," + ",TRANSACTION_AMOUNT," + "TRANSACTION_AMOUNT : " + db_CONS_TRANSACTION_AMOUNT + "," + "TRANSACTION_AMOUNT was not found," + db_CONS_STATUS + "," + "Fail";
                                section2_results.add(cons_TRANSACTION_AMOUNT);
                            } else {
                                String cons_TRANSACTION_AMOUNT = "," + ",TRANSACTION_AMOUNT," + "TRANSACTION_AMOUNT : " + db_CONS_TRANSACTION_AMOUNT + "," + "TRANSACTION_AMOUNT was found," + db_CONS_STATUS + "," + "Pass";
                                section2_results.add(cons_TRANSACTION_AMOUNT);
                            }

                            //BASE_CURRENCY_AMOUNT - mandatory validation
                            if ((db_CONS_BASE_CURRENCY_AMOUNT == null) && (db_CONS_STATUS != "REVIEW")) {

                                String CONS_BASE_CURRENCY_AMOUNT = "," + ",BASE_CURRENCY_AMOUNT," + "BASE_CURRENCY_AMOUNT : " + db_CONS_BASE_CURRENCY_AMOUNT + "," + "BASE_CURRENCY_AMOUNT was not found," + db_CONS_STATUS + "," + "Fail";
                                section2_results.add(CONS_BASE_CURRENCY_AMOUNT);
                            } else {
                                String CONS_BASE_CURRENCY_AMOUNT = "," + db_CONS_ID + ",BASE_CURRENCY_AMOUNT," + "BASE_CURRENCY_AMOUNT : " + db_CONS_BASE_CURRENCY_AMOUNT + "," + "BASE_CURRENCY_AMOUNT was found," + db_CONS_STATUS + "," + "Pass";
                                section2_results.add(CONS_BASE_CURRENCY_AMOUNT);
                            }

                            //CLAIM_NUMBER - mandatory validation
                            if ((db_CONS_CLAIM_NUMBER == null) && (db_CONS_STATUS != "REVIEW")) {

                                String CONS_CLAIM_NUMBER = "," + ",CLAIM_NUMBER," + "CLAIM_NUMBER : " + db_CONS_CLAIM_NUMBER + "," + "CLAIM_NUMBER was not found," + db_CONS_STATUS + "," + "Fail";
                                section2_results.add(CONS_CLAIM_NUMBER);
                            } else {
                                String CONS_CLAIM_NUMBER = "," + ",CLAIM_NUMBER," + "CLAIM_NUMBER : " + db_CONS_CLAIM_NUMBER + "," + "CLAIM_NUMBER was found," + db_CONS_STATUS + "," + "Pass";
                                section2_results.add(CONS_CLAIM_NUMBER);
                            }

                            //LINE_OF_BUSINESS - mandatory validation
                            if ((db_CONS_LINE_OF_BUSINESS == null) && (db_CONS_STATUS != "REVIEW")) {

                                String cons_LINE_OF_BUSINESS = "," + ",LINE_OF_BUSINESS," + "LINE_OF_BUSINESS : " + db_CONS_LINE_OF_BUSINESS + "," + "LINE_OF_BUSINESS was not found," + db_CONS_STATUS + "," + "Fail";
                                section2_results.add(cons_LINE_OF_BUSINESS);
                            } else {
                                String cons_LINE_OF_BUSINESS = "," + ",LINE_OF_BUSINESS," + "LINE_OF_BUSINESS : " + db_CONS_LINE_OF_BUSINESS + "," + "LINE_OF_BUSINESS was found," + db_CONS_STATUS + "," + "Pass";
                                section2_results.add(cons_LINE_OF_BUSINESS);
                            }

                            //DEBTOR_NAME - mandatory validation
                            if ((db_CONS_DEBTOR_NAME == null) && (db_CONS_STATUS != "REVIEW")) {

                                String CONS_DEBTOR_NAME = "," + ",DEBTOR_NAME," + "DEBTOR_NAME : " + db_CONS_DEBTOR_NAME + "," + "DEBTOR_NAME was not found," + db_CONS_STATUS + "," + "Fail";
                                section2_results.add(CONS_DEBTOR_NAME);
                            } else {
                                String CONS_DEBTOR_NAME = "," + ",DEBTOR_NAME," + "DEBTOR_NAME : " + db_CONS_DEBTOR_NAME + "," + "DEBTOR_NAME was found," + db_CONS_STATUS + "," + "Pass";
                                section2_results.add(CONS_DEBTOR_NAME);
                            }

                            //DEBTOR_REFERENCE - mandatory validation
                            if ((db_CONS_DEBTOR_REFERENCE == null) && (db_CONS_STATUS != "REVIEW")) {

                                String CONS_DEBTOR_REFERENCE = "," + ",DEBTOR_REFERENCE," + "DEBTOR_REFERENCE : " + db_CONS_DEBTOR_REFERENCE + "," + "DEBTOR_REFERENCE was not found," + db_CONS_STATUS + "," + "Fail";
                                section2_results.add(CONS_DEBTOR_REFERENCE);
                            } else {
                                String CONS_DEBTOR_REFERENCE = "," + ",DEBTOR_REFERENCE," + "DEBTOR_REFERENCE : " + db_CONS_DEBTOR_REFERENCE + "," + "DEBTOR_REFERENCE was found," + db_CONS_STATUS + "," + "Pass";
                                section2_results.add(CONS_DEBTOR_REFERENCE);
                            }



                            //------------------- Consolidation to Staging ----------------------------------
                            String CCV5GLReserves_stgSqlQuery = connect_db.executeQuery_DB("CCV5GL", "GLReserves_Stg","CCV5");
                            SQLResultset_fsh = SQLstmt.executeQuery(CCV5GLReserves_stgSqlQuery + "'"+file_name+ "' and CC_HEADER_ID = '" + list_header.get(i) + "' " );
                            //SQLResultset_fsh = SQLstmt.executeQuery("SELECT * from DLG_FSH_STG_COMM_CC_HDR WHERE FILE_NAME = '" + xml_file_name + "' and CC_HEADER_ID ='" + list_header.get(i) + "'");
                            if (!SQLResultset_fsh.next()) {
                                String stg_header_id = section2_map_row + ",CC_HEADER_ID," + "no records available in STG table" + "," + db_CONS_ID + ",Fail";
                                section2_results.add(stg_header_id);
                            } else {
                                SQLResultset_fsh = SQLstmt.executeQuery(CCV5GLReserves_stgSqlQuery + "'"+file_name+ "' and CC_HEADER_ID = '" + list_header.get(i) + "' " );
                            while (SQLResultset_fsh.next()) {
                                db_STG_CC_HEADER_ID = SQLResultset_fsh.getString("CC_HEADER_ID");
                                db_STG_SOURCE = SQLResultset_fsh.getString("SOURCE");
                                db_STG_SOURCE_EVENT_ID = SQLResultset_fsh.getString("SOURCE_EVENT_ID");
                                db_STG_UNDERWRITER = SQLResultset_fsh.getString("UNDERWRITER");
                                db_STG_BRAND = SQLResultset_fsh.getString("BRAND");
                                db_STG_PRODUCT = SQLResultset_fsh.getString("PRODUCT");
                                db_STG_PRODUCT_TYPE = SQLResultset_fsh.getString("PRODUCT_TYPE");
                                db_STG_CHANNEL = SQLResultset_fsh.getString("CHANNEL");
                                db_STG_TRANSACTION_DATE = SQLResultset_fsh.getString("TRANSACTION_DATE");
                                db_STG_RESERVES_FLAG = SQLResultset_fsh.getString("RESERVES_FLAG");
                                db_STG_PRODUCT_KEY = SQLResultset_fsh.getString("PRODUCT_KEY");
                                db_STG_LOSS_DATE = SQLResultset_fsh.getString("LOSS_DATE");
                                db_STG_CURRENCY_CODE = SQLResultset_fsh.getString("CURRENCY_CODE");
                                db_STG_EXCHANGE_RATE = SQLResultset_fsh.getString("EXCHANGE_RATE");
                                db_STG_EXCHANGE_RATE_TYPE = SQLResultset_fsh.getString("EXCHANGE_RATE_TYPE");
                                db_STG_TRANSACTION_AMOUNT = SQLResultset_fsh.getString("TRANSACTION_AMOUNT");
                                db_STG_BASE_CURRENCY_AMOUNT = SQLResultset_fsh.getString("BASE_CURRENCY_AMOUNT");
                                db_STG_CLAIM_NUMBER = SQLResultset_fsh.getString("CLAIM_NUMBER");
                                db_STG_FSH_ATTRIBUTE2 = SQLResultset_fsh.getString("FSH_ATTRIBUTE_02");
                                db_STG_FSH_ATTRIBUTE3 = SQLResultset_fsh.getString("FSH_ATTRIBUTE_03");
                                //db_STG_CLASS_OF_BUSINESS = SQLResultset_fsh.getString("CLASS_OF_BUSINESS");
                                db_STG_POLICY_NUMBER = SQLResultset_fsh.getString("POLICY_NUMBER");
                                db_STG_LINE_OF_BUSINESS = SQLResultset_fsh.getString("LINE_OF_BUSINESS");
                                db_STG_DEBTOR_NAME = SQLResultset_fsh.getString("DEBTOR_NAME");
                                db_STG_DEBTOR_REFERENCE = SQLResultset_fsh.getString("DEBTOR_REFERENCE");
                                /*db_STG_SUMMARY_FLAG = SQLResultset_fsh.getString("SUMMARY_FLAG");
                                db_STG_ENTITY_TYPE_CODE = SQLResultset_fsh.getString("ENTITY_TYPE_CODE");
                                db_STG_EVENT_CODE = SQLResultset_fsh.getString("EVENT_CODE");*/


                                //Mandatory validation
                                //CC_HEADER_ID - mandatory validation
                                if ((db_STG_CC_HEADER_ID == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = stg_line_map_row + "," + db_STG_CC_HEADER_ID + ",CC_HEADER_ID," + "CC_HEADER_ID : " + db_STG_CC_HEADER_ID + "," + "CC_HEADER_ID was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section2_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = stg_line_map_row + "," + db_STG_CC_HEADER_ID + ",CC_HEADER_ID," + "CC_HEADER_ID : " + db_STG_CC_HEADER_ID + "," + "CC_HEADER_ID was found," + STG_HDR_STATUS + "," + "Pass";
                                    section2_results.add(stg_header_id);
                                }


                                //SOURCE - mandatory validation
                                if ((db_STG_SOURCE == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",SOURCE," + "SOURCE : " + db_STG_SOURCE + "," + "SOURCE was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section2_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",SOURCE," + "SOURCE : " + db_STG_SOURCE + "," + "SOURCE was found," + STG_HDR_STATUS + "," + "Pass";
                                    section2_results.add(stg_header_id);
                                }

                                //SOURCE_EVENT_ID - mandatory validation
                                if ((db_STG_SOURCE_EVENT_ID == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",SOURCE_EVENT_ID," + "SOURCE_EVENT_ID : " + db_STG_SOURCE_EVENT_ID + "," + "SOURCE_EVENT_ID was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section2_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",SOURCE_EVENT_ID," + "SOURCE_EVENT_ID : " + db_STG_SOURCE_EVENT_ID + "," + "SOURCE_EVENT_ID was found," + STG_HDR_STATUS + "," + "Pass";
                                    section2_results.add(stg_header_id);
                                }

                                //UNDERWRITER - mandatory validation
                                if ((db_STG_UNDERWRITER == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",UNDERWRITER," + "UNDERWRITER : " + db_STG_UNDERWRITER + "," + "UNDERWRITER was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section2_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",UNDERWRITER," + "UNDERWRITER : " + db_STG_UNDERWRITER + "," + "UNDERWRITER was found," + STG_HDR_STATUS + "," + "Pass";
                                    section2_results.add(stg_header_id);
                                }

                                //BRAND - mandatory validation
                                if ((db_STG_BRAND == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",BRAND," + "BRAND : " + db_STG_BRAND + "," + "BRAND was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section2_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",BRAND," + "BRAND : " + db_STG_BRAND + "," + "BRAND was found," + STG_HDR_STATUS + "," + "Pass";
                                    section2_results.add(stg_header_id);
                                }

                                //PRODUCT - mandatory validation
                                if ((db_STG_PRODUCT == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",PRODUCT," + "PRODUCT : " + db_STG_PRODUCT + "," + "PRODUCT was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section2_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",PRODUCT," + "PRODUCT : " + db_STG_PRODUCT + "," + "PRODUCT was found," + STG_HDR_STATUS + "," + "Pass";
                                    section2_results.add(stg_header_id);
                                }

                                //PRODUCT_TYPE - mandatory validation
                                if ((db_STG_PRODUCT_TYPE == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",PRODUCT_TYPE," + "PRODUCT_TYPE : " + db_STG_PRODUCT_TYPE + "," + "PRODUCT_TYPE was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section2_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",PRODUCT_TYPE," + "PRODUCT_TYPE : " + db_STG_PRODUCT_TYPE + "," + "PRODUCT_TYPE was found," + STG_HDR_STATUS + "," + "Pass";
                                    section2_results.add(stg_header_id);
                                }

                                //CHANNEL - mandatory validation
                                if ((db_STG_CHANNEL == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",CHANNEL," + "CHANNEL : " + db_STG_CHANNEL + "," + "CHANNEL was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section2_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",CHANNEL," + "CHANNEL : " + db_STG_CHANNEL + "," + "CHANNEL was found," + STG_HDR_STATUS + "," + "Pass";
                                    section2_results.add(stg_header_id);
                                }

                                //TRANSACTION_DATE - mandatory validation
                                if ((db_STG_TRANSACTION_DATE == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",TRANSACTION_DATE," + "TRANSACTION_DATE : " + db_STG_TRANSACTION_DATE + "," + "TRANSACTION_DATE was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section2_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",TRANSACTION_DATE," + "TRANSACTION_DATE : " + db_STG_TRANSACTION_DATE + "," + "TRANSACTION_DATE was found," + STG_HDR_STATUS + "," + "Pass";
                                    section2_results.add(stg_header_id);
                                }

                                //CURRENCY_CODE - mandatory validation
                                if ((db_STG_CURRENCY_CODE == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",CURRENCY_CODE," + "CURRENCY_CODE : " + db_STG_CURRENCY_CODE + "," + "CURRENCY_CODE was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section2_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",CURRENCY_CODE," + "CURRENCY_CODE : " + db_STG_CURRENCY_CODE + "," + "CURRENCY_CODE was found," + STG_HDR_STATUS + "," + "Pass";
                                    section2_results.add(stg_header_id);
                                }

                                //EXCHANGE_RATE - mandatory validation
                                if ((db_STG_EXCHANGE_RATE == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",EXCHANGE_RATE," + "EXCHANGE_RATE : " + db_STG_EXCHANGE_RATE + "," + "EXCHANGE_RATE was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section2_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",EXCHANGE_RATE," + "EXCHANGE_RATE : " + db_STG_EXCHANGE_RATE + "," + "EXCHANGE_RATE was found," + STG_HDR_STATUS + "," + "Pass";
                                    section2_results.add(stg_header_id);
                                }

                                //EXCHANGE_RATE_TYPE - mandatory validation
                                if ((db_STG_EXCHANGE_RATE_TYPE == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",EXCHANGE_RATE_TYPE," + "EXCHANGE_RATE_TYPE : " + db_STG_EXCHANGE_RATE_TYPE + "," + "EXCHANGE_RATE_TYPE was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section2_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",EXCHANGE_RATE_TYPE," + "EXCHANGE_RATE_TYPE : " + db_STG_EXCHANGE_RATE_TYPE + "," + "EXCHANGE_RATE_TYPE was found," + STG_HDR_STATUS + "," + "Pass";
                                    section2_results.add(stg_header_id);
                                }


                                //TRANSACTION_AMOUNT - mandatory validation
                                if ((db_STG_TRANSACTION_AMOUNT == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",TRANSACTION_AMOUNT," + "TRANSACTION_AMOUNT : " + db_STG_TRANSACTION_AMOUNT + "," + "TRANSACTION_AMOUNT was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section2_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",TRANSACTION_AMOUNT," + "TRANSACTION_AMOUNT : " + db_STG_TRANSACTION_AMOUNT + "," + "TRANSACTION_AMOUNT was found," + STG_HDR_STATUS + "," + "Pass";
                                    section2_results.add(stg_header_id);
                                }

                                //BASE_CURRENCY_AMOUNT - mandatory validation
                                if ((db_STG_BASE_CURRENCY_AMOUNT == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",BASE_CURRENCY_AMOUNT," + "BASE_CURRENCY_AMOUNT : " + db_STG_BASE_CURRENCY_AMOUNT + "," + "BASE_CURRENCY_AMOUNT was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section2_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",BASE_CURRENCY_AMOUNT," + "BASE_CURRENCY_AMOUNT : " + db_STG_BASE_CURRENCY_AMOUNT + "," + "BASE_CURRENCY_AMOUNT was found," + STG_HDR_STATUS + "," + "Pass";
                                    section2_results.add(stg_header_id);
                                }


                                //CLAIM_NUMBER - mandatory validation
                                if ((db_STG_CLAIM_NUMBER == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",CLAIM_NUMBER," + "CLAIM_NUMBER : " + db_STG_CLAIM_NUMBER + "," + "CLAIM_NUMBER was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section2_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",CLAIM_NUMBER," + "CLAIM_NUMBER : " + db_STG_CLAIM_NUMBER + "," + "CLAIM_NUMBER was found," + STG_HDR_STATUS + "," + "Pass";
                                    section2_results.add(stg_header_id);
                                }

                                //EVENT_CODE - mandatory validation
                                if ((db_STG_EVENT_CODE == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",EVENT_CODE," + "EVENT_CODE : " + db_STG_EVENT_CODE + "," + "EVENT_CODE was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section2_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",EVENT_CODE," + "EVENT_CODE : " + db_STG_EVENT_CODE + "," + "EVENT_CODE was found," + STG_HDR_STATUS + "," + "Pass";
                                    section2_results.add(stg_header_id);
                                }

                                //ENTITY_TYPE_CODE - mandatory validation
                                if ((db_STG_ENTITY_TYPE_CODE == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",ENTITY_TYPE_CODE," + "ENTITY_TYPE_CODE : " + db_STG_ENTITY_TYPE_CODE + "," + "ENTITY_TYPE_CODE was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section2_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",ENTITY_TYPE_CODE," + "ENTITY_TYPE_CODE : " + db_STG_ENTITY_TYPE_CODE + "," + "ENTITY_TYPE_CODE was found," + STG_HDR_STATUS + "," + "Pass";
                                    section2_results.add(stg_header_id);
                                }

                                //RESERVES_FLAG - mandatory validation
                                if ((db_STG_RESERVES_FLAG == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",RESERVES_FLAG," + "RESERVES_FLAG : " + db_STG_RESERVES_FLAG + "," + "RESERVES_FLAG was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section2_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",RESERVES_FLAG," + "RESERVES_FLAG : " + db_STG_RESERVES_FLAG + "," + "RESERVES_FLAG was found," + STG_HDR_STATUS + "," + "Pass";
                                    section2_results.add(stg_header_id);
                                }

                                //PRODUCT_KEY - mandatory validation
                                if ((db_STG_PRODUCT_KEY == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",PRODUCT_KEY," + "PRODUCT_KEY : " + db_STG_PRODUCT_KEY + "," + "PRODUCT_KEY was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section2_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",PRODUCT_KEY," + "PRODUCT_KEY : " + db_STG_PRODUCT_KEY + "," + "PRODUCT_KEY was found," + STG_HDR_STATUS + "," + "Pass";
                                    section2_results.add(stg_header_id);
                                }

                                //LOSS_DATE - mandatory validation
                                if ((db_STG_LOSS_DATE == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",LOSS_DATE," + "LOSS_DATE : " + db_STG_LOSS_DATE + "," + "LOSS_DATE was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section2_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",LOSS_DATE," + "LOSS_DATE : " + db_STG_LOSS_DATE + "," + "LOSS_DATE was found," + STG_HDR_STATUS + "," + "Pass";
                                    section2_results.add(stg_header_id);
                                }

                                //SUMMARY_FLAG - mandatory validation
                                if ((db_STG_SUMMARY_FLAG == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",SUMMARY_FLAG," + "SUMMARY_FLAG : " + db_STG_SUMMARY_FLAG + "," + "SUMMARY_FLAG was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section2_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",SUMMARY_FLAG," + "SUMMARY_FLAG : " + db_STG_SUMMARY_FLAG + "," + "SUMMARY_FLAG was found," + STG_HDR_STATUS + "," + "Pass";
                                    section2_results.add(stg_header_id);
                                }

                                //LINE_OF_BUSINESS - mandatory validation
                                if ((db_STG_LINE_OF_BUSINESS == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",LINE_OF_BUSINESS," + "LINE_OF_BUSINESS : " + db_STG_LINE_OF_BUSINESS + "," + "LINE_OF_BUSINESS was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section2_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",LINE_OF_BUSINESS," + "LINE_OF_BUSINESS : " + db_STG_LINE_OF_BUSINESS + "," + "LINE_OF_BUSINESS was found," + STG_HDR_STATUS + "," + "Pass";
                                    section2_results.add(stg_header_id);
                                }

                                //POLICY_NUMBER - mandatory validation
                                if ((db_STG_POLICY_NUMBER == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",POLICY_NUMBER," + "POLICY_NUMBER : " + db_STG_POLICY_NUMBER + "," + "POLICY_NUMBER was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section2_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",POLICY_NUMBER," + "POLICY_NUMBER : " + db_STG_POLICY_NUMBER + "," + "POLICY_NUMBER was found," + STG_HDR_STATUS + "," + "Pass";
                                    section2_results.add(stg_header_id);
                                }

                                /*//SUMMARY_FLAG - mandatory validation
                                if ((db_STG_SUMMARY_FLAG == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + db_STG_CC_HEADER_ID + ",SUMMARY_FLAG," + "SUMMARY_FLAG : " + db_STG_SUMMARY_FLAG + "," + "SUMMARY_FLAG was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section2_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + db_STG_CC_HEADER_ID + ",SUMMARY_FLAG," + "SUMMARY_FLAG : " + db_STG_SUMMARY_FLAG + "," + "SUMMARY_FLAG was found," + STG_HDR_STATUS + "," + "Pass";
                                    section2_results.add(stg_header_id);
                                }*/

                                //--------------------  Validation CC_HEADER_ID ---------------
                                if (db_CONS_ID.equals(db_STG_CC_HEADER_ID)) {
                                    String cons_header_id = cons_stg_map_row + ",HEADER_ID," + db_STG_CC_HEADER_ID + "," + db_CONS_ID + ",Pass";
                                    section1_results.add(cons_header_id);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",HEADER_ID" + "," + db_STG_CC_HEADER_ID + "," + db_CONS_ID + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    cons_stg_map_row++;
                                } else {
                                    String cons_header_id = cons_stg_map_row + ",HEADER_ID," + db_STG_CC_HEADER_ID + "," + db_CONS_ID + ",Fail";
                                    section1_results.add(cons_header_id);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",HEADER_ID" + "," + db_STG_CC_HEADER_ID + "," + db_CONS_ID + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    cons_stg_map_row++;
                                    CONS_flag++;
                                }

                                //--------------------  Validation SOURCE ---------------
                                if (db_CONS_SOURCE.equals(db_STG_SOURCE)) {
                                    String cons_source = ",SOURCE," + db_CONS_SOURCE + "," + db_STG_SOURCE + ",Pass";
                                    section1_results.add(cons_source);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SOURCE" + "," + db_CONS_SOURCE + "," + db_STG_SOURCE + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_source = ",SOURCE," + db_CONS_SOURCE + "," + db_STG_SOURCE + ",Fail";
                                    section1_results.add(cons_source);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SOURCE" + "," + db_CONS_SOURCE + "," + db_STG_SOURCE + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation PRODUCT_KEY ---------------

                                String db_STG_PRODUCT_KEYConcat = db_STG_BRAND.concat("_").concat(db_STG_PRODUCT_TYPE);
                                if (db_STG_PRODUCT_KEY != null) {
                                    if (db_STG_PRODUCT_KEY.equalsIgnoreCase(db_STG_PRODUCT_KEYConcat)) {
                                        String STG_SOURCE_EVENT_ID = ",PRODUCT_KEY," + db_STG_PRODUCT_KEY + "," + db_STG_PRODUCT_KEYConcat + ",Pass";
                                        section1_results.add(STG_SOURCE_EVENT_ID);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT_KEY" + "," + db_STG_PRODUCT_KEY + "," + db_STG_PRODUCT_KEYConcat + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String STG_SOURCE_EVENT_ID = ",PRODUCT_KEY," + db_STG_PRODUCT_KEY + "," + db_STG_PRODUCT_KEYConcat + ",Fail";
                                        section1_results.add(STG_SOURCE_EVENT_ID);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT_KEY" + "," + db_STG_PRODUCT_KEY + "," + db_STG_PRODUCT_KEYConcat + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                } else {
                                    String STG_SOURCE_EVENT_ID = ",PRODUCT_KEY," + db_STG_PRODUCT_KEY + "," + db_STG_PRODUCT_KEYConcat + ",Fail";
                                    section1_results.add(STG_SOURCE_EVENT_ID);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT_KEY" + "," + db_STG_PRODUCT_KEY + "," + db_STG_PRODUCT_KEYConcat + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                /*//--------------------  Validation UNDERWRITER ---------------
                                if (db_CONS_UNDERWRITER.equals(db_STG_UNDERWRITER)) {
                                    String STG_UNDERWRITER = ",UNDERWRITER," + db_CONS_UNDERWRITER + "," + db_STG_UNDERWRITER + ",Pass";
                                    section1_results.add(STG_UNDERWRITER);
                                } else {
                                    String STG_UNDERWRITER = ",UNDERWRITER," + db_CONS_UNDERWRITER + "," + db_STG_UNDERWRITER + ",Fail";
                                    section1_results.add(STG_UNDERWRITER);
                                }*/

                                //--------------------  Validation BRAND ---------------
                                if (db_CONS_BRAND.equals(db_STG_BRAND)) {
                                    String cons_BRAND = ",BRAND," + db_CONS_BRAND + "," + db_STG_BRAND + ",Pass";
                                    section1_results.add(cons_BRAND);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BRAND" + "," + db_CONS_BRAND + "," + db_STG_BRAND + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_BRAND = ",BRAND," + db_CONS_BRAND + "," + db_STG_BRAND + ",Fail";
                                    section1_results.add(cons_BRAND);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BRAND" + "," + db_CONS_BRAND + "," + db_STG_BRAND + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation PRODUCT ---------------
                                if (db_CONS_PRODUCT.equals(db_STG_PRODUCT)) {
                                    String cons_PRODUCT = ",PRODUCT," + db_CONS_PRODUCT + "," + db_STG_PRODUCT + ",Pass";
                                    section1_results.add(cons_PRODUCT);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT" + "," + db_CONS_PRODUCT + "," + db_STG_PRODUCT + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_PRODUCT = ",PRODUCT," + db_CONS_PRODUCT + "," + db_STG_PRODUCT + ",Fail";
                                    section1_results.add(cons_PRODUCT);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT" + "," + db_CONS_PRODUCT + "," + db_STG_PRODUCT + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation PRODUCT_TYPE ---------------
                                if (db_CONS_PRODUCT_TYPE.equals(db_STG_PRODUCT_TYPE)) {
                                    String cons_PRODUCT_TYPE = ",PRODUCT_TYPE," + db_CONS_PRODUCT_TYPE + "," + db_STG_PRODUCT_TYPE + ",Pass";
                                    section1_results.add(cons_PRODUCT_TYPE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT_TYPE" + "," + db_CONS_PRODUCT_TYPE + "," + db_STG_PRODUCT_TYPE + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_PRODUCT_TYPE = ",PRODUCT_TYPE," + db_CONS_PRODUCT_TYPE + "," + db_STG_PRODUCT_TYPE + ",Fail";
                                    section1_results.add(cons_PRODUCT_TYPE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT_TYPE" + "," + db_CONS_PRODUCT_TYPE + "," + db_STG_PRODUCT_TYPE + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation CHANNEL ---------------
                                if (db_CONS_CHANNEL.equals(db_STG_CHANNEL)) {
                                    String STG_CHANNEL = ",CHANNEL," + db_CONS_CHANNEL + "," + db_STG_CHANNEL + ",Pass";
                                    section1_results.add(STG_CHANNEL);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CHANNEL" + "," + db_CONS_CHANNEL + "," + db_STG_CHANNEL + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_CHANNEL = ",CHANNEL," + db_CONS_CHANNEL + "," + db_STG_CHANNEL + ",Fail";
                                    section1_results.add(STG_CHANNEL);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CHANNEL" + "," + db_CONS_CHANNEL + "," + db_STG_CHANNEL + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation TRANSACTION_AMOUNT ---------------
                                if (db_CONS_TRANSACTION_AMOUNT.equals(db_STG_TRANSACTION_AMOUNT)) {
                                    String cons_TRANSACTION_AMOUNT = ",TRANSACTION_AMOUNT," + db_CONS_TRANSACTION_AMOUNT + "," + db_STG_TRANSACTION_AMOUNT + ",Pass";
                                    section1_results.add(cons_TRANSACTION_AMOUNT);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_AMOUNT" + "," + db_CONS_TRANSACTION_AMOUNT + "," + db_STG_TRANSACTION_AMOUNT + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_TRANSACTION_AMOUNT = ",TRANSACTION_AMOUNT," + db_CONS_TRANSACTION_AMOUNT + "," + db_STG_TRANSACTION_AMOUNT + ",Fail";
                                    section1_results.add(cons_TRANSACTION_AMOUNT);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_AMOUNT" + "," + db_CONS_TRANSACTION_AMOUNT + "," + db_STG_TRANSACTION_AMOUNT + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation TRANSACTION_DATE ---------------
                                String db_STG_TRANSACTION_DATEModified = db_STG_TRANSACTION_DATE.substring(0, 10);
                                String db_CONS_TRANSACTION_DATEModified = db_CONS_TRANSACTION_DATE.substring(0, 10);
                                if (db_CONS_TRANSACTION_DATEModified.equals(db_STG_TRANSACTION_DATEModified)) {
                                    String cons_TRANSACTION_DATE = ",TRANSACTION_DATE," + db_STG_TRANSACTION_DATEModified + "," + db_CONS_TRANSACTION_DATEModified + ",Pass";
                                    section1_results.add(cons_TRANSACTION_DATE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATEModified + "," + db_CONS_TRANSACTION_DATEModified + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_TRANSACTION_DATE = ",TRANSACTION_DATE," + db_STG_TRANSACTION_DATEModified + "," + db_CONS_TRANSACTION_DATEModified + ",Fail";
                                    section1_results.add(cons_TRANSACTION_DATE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATEModified + "," + db_CONS_TRANSACTION_DATEModified + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation LOSS_DATE ---------------
                                String partialDate= "01-JAN-";
                                String db_CONS_LOSS_DATEModified1= db_CONS_LOSS_DATE.substring(2,4);
                                String db_CONS_LOSS_DATEModified2= partialDate.concat(db_CONS_LOSS_DATEModified1);

                                String db_STG_LOSS_DATEModified = db_STG_LOSS_DATE.substring(0, 10);
                                if (db_CONS_LOSS_DATEModified2.equals(db_STG_LOSS_DATEModified)) {
                                    String STG_RESERVES_FLAG = ",LOSS_DATE," + db_CONS_LOSS_DATEModified2 + "," + db_STG_LOSS_DATEModified + ",Pass";
                                    section1_results.add(STG_RESERVES_FLAG);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",LOSS_DATE" + "," + db_CONS_LOSS_DATEModified2 + "," + db_STG_LOSS_DATEModified + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_RESERVES_FLAG = ",LOSS_DATE," + db_CONS_LOSS_DATEModified2 + "," + db_STG_LOSS_DATEModified + ",Fail";
                                    section1_results.add(STG_RESERVES_FLAG);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",LOSS_DATE" + "," + db_CONS_LOSS_DATEModified2 + "," + db_STG_LOSS_DATEModified + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                               /* //--------------------  Validation RESERVES_FLAG ---------------
                                if (db_CONS_LOSS_DATE.equals(db_STG_RESERVES_FLAG)) {
                                    String STG_RESERVES_FLAG = ",RESERVES_FLAG," + db_CONS_LOSS_DATE + "," + db_STG_RESERVES_FLAG + ",Pass";
                                    section1_results.add(STG_RESERVES_FLAG);
                                } else {
                                    String STG_RESERVES_FLAG = ",RESERVES_FLAG," + db_CONS_LOSS_DATE + "," + db_STG_RESERVES_FLAG + ",Fail";
                                    section1_results.add(STG_RESERVES_FLAG);
                                }*/

                                //--------------------  Validation CURRENCY_CODE ---------------.
                                if (db_CONS_CURRENCY.equalsIgnoreCase(db_STG_CURRENCY_CODE)) {
                                    String cons_CURRENCY_CODE = ",CURRENCY_CODE," + db_STG_CURRENCY_CODE + "," + db_CONS_CURRENCY + ",Pass";
                                    section1_results.add(cons_CURRENCY_CODE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CURRENCY_CODE" + "," + db_STG_CURRENCY_CODE + "," + db_CONS_CURRENCY + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_CURRENCY_CODE = ",CURRENCY_CODE," + db_STG_CURRENCY_CODE + "," + db_CONS_CURRENCY + ",Fail";
                                    section1_results.add(cons_CURRENCY_CODE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CURRENCY_CODE" + "," + db_STG_CURRENCY_CODE + "," + db_CONS_CURRENCY + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation EXCHANGE_RATE ---------------
                                if (db_CONS_EXCHANGE_RATE.equals(db_STG_EXCHANGE_RATE)) {
                                    String cons_EXCHANGE_RATE = ",EXCHANGE_RATE," + db_STG_EXCHANGE_RATE + "," + db_CONS_EXCHANGE_RATE + ",Pass";
                                    section1_results.add(cons_EXCHANGE_RATE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",EXCHANGE_RATE" + "," + db_STG_EXCHANGE_RATE + "," + db_CONS_EXCHANGE_RATE + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_EXCHANGE_RATE = ",EXCHANGE_RATE," + db_STG_EXCHANGE_RATE + "," + db_CONS_EXCHANGE_RATE + ",Fail";
                                    section1_results.add(cons_EXCHANGE_RATE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",EXCHANGE_RATE" + "," + db_STG_EXCHANGE_RATE + "," + db_CONS_EXCHANGE_RATE + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation EXCHANGE_RATE_TYPE ---------------
                                if (db_CONS_EXCHANGE_RATE_TYPE.equals(db_STG_EXCHANGE_RATE_TYPE)) {
                                    String cons_EXCHANGE_RATE_TYPE = ",EXCHANGE_RATE_TYPE," + db_STG_EXCHANGE_RATE_TYPE + "," + db_CONS_EXCHANGE_RATE_TYPE + ",Pass";
                                    section1_results.add(cons_EXCHANGE_RATE_TYPE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",EXCHANGE_RATE_TYPE" + "," + db_STG_EXCHANGE_RATE_TYPE + "," + db_CONS_EXCHANGE_RATE_TYPE + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_EXCHANGE_RATE_TYPE = ",EXCHANGE_RATE_TYPE," + db_STG_EXCHANGE_RATE_TYPE + "," + db_CONS_EXCHANGE_RATE_TYPE + ",Fail";
                                    section1_results.add(cons_EXCHANGE_RATE_TYPE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",EXCHANGE_RATE_TYPE" + "," + db_STG_EXCHANGE_RATE_TYPE + "," + db_CONS_EXCHANGE_RATE_TYPE + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation BASE_CURRENCY_AMOUNT ---------------
                                if (db_CONS_BASE_CURRENCY_AMOUNT.equals(db_STG_BASE_CURRENCY_AMOUNT)) {
                                    String cons_FSH_ATTRIBUTE_03 = ",BASE_CURRENCY_AMOUNT," + db_CONS_BASE_CURRENCY_AMOUNT + "," + db_STG_BASE_CURRENCY_AMOUNT + ",Pass";
                                    section1_results.add(cons_FSH_ATTRIBUTE_03);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BASE_CURRENCY_AMOUNT" + "," + db_CONS_BASE_CURRENCY_AMOUNT + "," + db_STG_BASE_CURRENCY_AMOUNT + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_FSH_ATTRIBUTE_03 = ",BASE_CURRENCY_AMOUNT," + db_CONS_BASE_CURRENCY_AMOUNT + "," + db_STG_BASE_CURRENCY_AMOUNT + ",Fail";
                                    section1_results.add(cons_FSH_ATTRIBUTE_03);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BASE_CURRENCY_AMOUNT" + "," + db_CONS_BASE_CURRENCY_AMOUNT + "," + db_STG_BASE_CURRENCY_AMOUNT + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation CLAIM_NUMBER ---------------
                                if (db_CONS_CLAIM_NUMBER.equals(db_STG_CLAIM_NUMBER)) {
                                    String cons_SOURCE_EVENT_ID = ",CLAIM_NUMBER," + db_CONS_CLAIM_NUMBER + "," + db_STG_CLAIM_NUMBER + ",Pass";
                                    section1_results.add(cons_SOURCE_EVENT_ID);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CLAIM_NUMBER" + "," + db_CONS_CLAIM_NUMBER + "," + db_STG_CLAIM_NUMBER + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_SOURCE_EVENT_ID = ",CLAIM_NUMBER," + db_CONS_CLAIM_NUMBER + "," + db_STG_CLAIM_NUMBER + ",Fail";
                                    section1_results.add(cons_SOURCE_EVENT_ID);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CLAIM_NUMBER" + "," + db_CONS_CLAIM_NUMBER + "," + db_STG_CLAIM_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }


                                //--------------------  Validation FSH_ATTRIBUTE2 ---------------
                                if ((db_CONS_DTI_CLASS != null) && (db_STG_FSH_ATTRIBUTE2 != null)) {
                                    if (db_CONS_DTI_CLASS.equals(db_STG_FSH_ATTRIBUTE2)) {
                                        String STG_FSH_ATTRIBUTE2 = ",FSH_ATTRIBUTE2," + db_CONS_DTI_CLASS + "," + db_STG_FSH_ATTRIBUTE2 + ",Pass";
                                        section1_results.add(STG_FSH_ATTRIBUTE2);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",FSH_ATTRIBUTE2" + "," + db_CONS_DTI_CLASS + "," + db_STG_FSH_ATTRIBUTE2 + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String STG_FSH_ATTRIBUTE2 = ",FSH_ATTRIBUTE2," + db_CONS_DTI_CLASS + "," + db_STG_FSH_ATTRIBUTE2 + ",Fail";
                                        section1_results.add(STG_FSH_ATTRIBUTE2);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",FSH_ATTRIBUTE2" + "," + db_CONS_DTI_CLASS + "," + db_STG_FSH_ATTRIBUTE2 + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                } else {
                                    String STG_FSH_ATTRIBUTE2 = ",FSH_ATTRIBUTE2," + db_CONS_DTI_CLASS + "," + db_STG_FSH_ATTRIBUTE2 + ",Pass";
                                    section1_results.add(STG_FSH_ATTRIBUTE2);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",FSH_ATTRIBUTE2" + "," + db_CONS_DTI_CLASS + "," + db_STG_FSH_ATTRIBUTE2 + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                }

                                //--------------------  Validation FSH_ATTRIBUTE3 ---------------
                                if (db_CONS_CLASS_OF_BUSINESS.equals(db_STG_FSH_ATTRIBUTE3)) {
                                    String STG_FSH_ATTRIBUTE3 = ",FSH_ATTRIBUTE3," + db_CONS_CLASS_OF_BUSINESS + "," + db_STG_FSH_ATTRIBUTE3 + ",Pass";
                                    section1_results.add(STG_FSH_ATTRIBUTE3);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",FSH_ATTRIBUTE3" + "," + db_CONS_CLASS_OF_BUSINESS + "," + db_STG_FSH_ATTRIBUTE3 + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_FSH_ATTRIBUTE3 = ",FSH_ATTRIBUTE3," + db_CONS_CLASS_OF_BUSINESS + "," + db_STG_FSH_ATTRIBUTE3 + ",Fail";
                                    section1_results.add(STG_FSH_ATTRIBUTE3);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",FSH_ATTRIBUTE3" + "," + db_CONS_CLASS_OF_BUSINESS + "," + db_STG_FSH_ATTRIBUTE3 + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation POLICY_NUMBER ---------------

                                if (db_CONS_POLICY_NUMBER.equals(db_STG_POLICY_NUMBER)) {
                                    String cons_POLICY_NUMBER = ",POLICY_NUMBER," + db_STG_POLICY_NUMBER + "," + db_CONS_POLICY_NUMBER + ",Pass";
                                    section1_results.add(cons_POLICY_NUMBER);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",POLICY_NUMBER" + "," + db_STG_POLICY_NUMBER + "," + db_CONS_POLICY_NUMBER + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_POLICY_NUMBER = ",POLICY_NUMBER," + db_STG_POLICY_NUMBER + "," + db_CONS_POLICY_NUMBER + ",Fail";
                                    section1_results.add(cons_POLICY_NUMBER);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",POLICY_NUMBER" + "," + db_STG_POLICY_NUMBER + "," + db_CONS_POLICY_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                /*//--------------------  Validation LINE_OF_BUSINESS ---------------
                                if (db_CONS_LINE_OF_BUSINESS.equals(db_STG_LINE_OF_BUSINESS)) {
                                    String cons_LINE_OF_BUSINESS = ",LINE_OF_BUSINESS," + db_STG_LINE_OF_BUSINESS + "," + db_CONS_LINE_OF_BUSINESS + ",Pass";
                                    section1_results.add(cons_LINE_OF_BUSINESS);
                                } else {
                                    String cons_LINE_OF_BUSINESS = ",LINE_OF_BUSINESS," + db_STG_LINE_OF_BUSINESS + "," + db_CONS_LINE_OF_BUSINESS + ",Fail";
                                    section1_results.add(cons_LINE_OF_BUSINESS);
                                }*/

                                /*//--------------------  Validation DEBTOR_NAME ---------------
                                if (db_CONS_DEBTOR_NAME.equals(db_STG_DEBTOR_NAME)) {
                                    String STG_DEBTOR_NAME = ",DEBTOR_NAME," + db_CONS_DEBTOR_NAME + "," + db_STG_DEBTOR_NAME + ",Pass";
                                    section1_results.add(STG_DEBTOR_NAME);
                                } else {
                                    String STG_DEBTOR_NAME = ",DEBTOR_NAME," + db_CONS_DEBTOR_NAME + "," + db_STG_DEBTOR_NAME + ",Fail";
                                    section1_results.add(STG_DEBTOR_NAME);
                                }

                                //--------------------  Validation DEBTOR_REFERENCE ---------------
                                if (db_CONS_DEBTOR_REFERENCE.equals(db_STG_DEBTOR_REFERENCE)) {
                                    String STG_DEBTOR_REFERENCE = ",DEBTOR_REFERENCE," + db_CONS_DEBTOR_REFERENCE + "," + db_STG_DEBTOR_REFERENCE + ",Pass";
                                    section1_results.add(STG_DEBTOR_REFERENCE);
                                } else {
                                    String STG_DEBTOR_REFERENCE = ",DEBTOR_REFERENCE," + db_CONS_DEBTOR_REFERENCE + "," + db_STG_DEBTOR_REFERENCE + ",Fail";
                                    section1_results.add(STG_DEBTOR_REFERENCE);
                                }*/

                                //--------------------  Validation RESERVES_FLAG ---------------
                                String db_CONS_RESERVES_FLAGTransform ="null";
                                String db_CONS_TRANSACTION_DATEUpdated = db_CONS_TRANSACTION_DATE.substring(0, 4);
                                int db_CONS_TRANSACTION_DATETransform = Integer.parseInt(db_CONS_TRANSACTION_DATEUpdated);

                                String db_CONS_LOSS_DATEUpdated = db_CONS_LOSS_DATE.substring(0, 4);
                                int db_CONS_LOSS_DATETransform = Integer.parseInt(db_CONS_LOSS_DATEUpdated);

                                if(db_CONS_TRANSACTION_DATETransform <= db_CONS_LOSS_DATETransform) {
                                    db_CONS_RESERVES_FLAGTransform = "CY";
                                } else {
                                    //if(db_CONS_TRANSACTION_DATETransform == db_CONS_LOSS_DATETransform){
                                    db_CONS_RESERVES_FLAGTransform = "PY";
                                }

                                if (db_CONS_RESERVES_FLAGTransform.equals(db_STG_RESERVES_FLAG) || (db_CONS_RESERVES_FLAGTransform == db_STG_RESERVES_FLAG) ) {
                                    String cons_RESERVES_FLAG = ",RESERVES_FLAG," + db_CONS_RESERVES_FLAGTransform + "," + db_STG_RESERVES_FLAG + ",Pass";
                                    section1_results.add(cons_RESERVES_FLAG);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",RESERVES_FLAG" + "," + db_CONS_RESERVES_FLAGTransform + "," + db_STG_RESERVES_FLAG + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_RESERVES_FLAG = ",RESERVES_FLAG," + db_CONS_RESERVES_FLAGTransform + "," + db_STG_RESERVES_FLAG + ",Fail";
                                    section1_results.add(cons_RESERVES_FLAG);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",RESERVES_FLAG" + "," + db_CONS_RESERVES_FLAGTransform + "," + db_STG_RESERVES_FLAG + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }


                                //----------------------- STANDARDISATION start here -----------------------------
                                String db_lookup_EVENT_CODE_meaning = "null";
                                String db_lookup_SOURCE_EVENT_ID_meaning = "null";
                                String db_lookup_ENTITY_TYPE_CODE_meaning = "null";
                                String db_lookup_exchange_rate_meaning = "null";
                                String db_lookup_exchange_rate_type_meaning = "null";
                                String db_lookup_currency_code_meaning = "null";
                                String db_lookup_product_type_meaning = "null";
                                String db_lookup_claim_number_meaning = "null";
                                String db_lookup_underwriter_meaning = "null";
                                String db_lookup_LINE_OF_BUSINESS_meaning = "null";
                                String db_lookup_reserves_flag_meaning = "null";
                                String db_lookup_brand_meaning = "null";
                                String db_lookup_product_key_meaning = "null";
                                String db_lookup_SUMMARY_FLAG_meaning = "null";

                                //------------------------ SOURCE_EVENT_ID Validation -----------------
                                SQLResultset_fsh = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '"+db_CONS_EVENT_ID+"' and LOOKUP_TYPE = 'GLEVENTS' and system = 'CCV5' and pattern = 'GLReserves'");
                                while (SQLResultset_fsh.next()) {
                                    db_lookup_SOURCE_EVENT_ID_meaning = SQLResultset_fsh.getString("MEANING");
                                }

                                if (db_lookup_SOURCE_EVENT_ID_meaning.equals("null")) {
                                    String lookup_SOURCE_EVENT_ID_meaning = ",SOURCE_EVENT_ID lookup," + "LookUp value not found" + "," + db_STG_SOURCE_EVENT_ID + ",Fail";
                                    section1_results.add(lookup_SOURCE_EVENT_ID_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",RESERVES_FLAG" + "," + db_CONS_RESERVES_FLAGTransform + "," + db_STG_RESERVES_FLAG + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_lookup_SOURCE_EVENT_ID_meaning != null) {
                                    if (db_lookup_SOURCE_EVENT_ID_meaning.equals(db_STG_SOURCE_EVENT_ID)) {
                                        String lookup_SOURCE_EVENT_ID_meaning = ",SOURCE_EVENT_ID lookup," + db_lookup_SOURCE_EVENT_ID_meaning + "," + db_STG_SOURCE_EVENT_ID + ",Pass";
                                        section1_results.add(lookup_SOURCE_EVENT_ID_meaning);
                                    } else {
                                        String lookup_SOURCE_EVENT_ID_meaning = ",SOURCE_EVENT_ID lookup," + db_lookup_SOURCE_EVENT_ID_meaning + "," + db_STG_SOURCE_EVENT_ID + ",Fail";
                                        section1_results.add(lookup_SOURCE_EVENT_ID_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",RESERVES_FLAG" + "," + db_CONS_RESERVES_FLAGTransform + "," + db_STG_RESERVES_FLAG + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //---------------- Validate UNDERWRITER -----------------------
                                SQLResultset_fsh = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_UNDERWRITER + "' and LOOKUP_TYPE = 'UNDERWRITER' and system = 'CCV5' and pattern = 'GLReserves'");
                                while (SQLResultset_fsh.next()) {
                                    db_lookup_underwriter_meaning = SQLResultset_fsh.getString("MEANING");
                                }
                                if (db_lookup_underwriter_meaning.equals("null")) {
                                    String lookup_underwriter_meaning = ",UNDERWRITER lookup," + "LookUp value not found" + "," + db_STG_UNDERWRITER + ",Fail";
                                    section1_results.add(lookup_underwriter_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",RESERVES_FLAG" + "," + db_CONS_RESERVES_FLAGTransform + "," + db_STG_RESERVES_FLAG + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_lookup_underwriter_meaning != null) {
                                    if (db_lookup_underwriter_meaning.equals(db_STG_UNDERWRITER)) {
                                        String lookup_underwriter_meaning = ",UNDERWRITER lookup," + db_lookup_underwriter_meaning + "," + db_STG_UNDERWRITER + ",Pass";
                                        section1_results.add(lookup_underwriter_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",RESERVES_FLAG" + "," + db_CONS_RESERVES_FLAGTransform + "," + db_STG_RESERVES_FLAG + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String lookup_underwriter_meaning = ",UNDERWRITER lookup," + db_lookup_underwriter_meaning + "," + db_STG_UNDERWRITER + ",Fail";
                                        section1_results.add(lookup_underwriter_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",RESERVES_FLAG" + "," + db_CONS_RESERVES_FLAGTransform + "," + db_STG_RESERVES_FLAG + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //------------------------ SUMMARY_FLAG Validation -----------------
                                SQLResultset_fsh = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '"+db_CONS_SOURCE+"' and LOOKUP_TYPE = 'SUMMARISE_DATA_FLAG' and system = 'CCV5' and pattern = 'GLReserves'");
                                while (SQLResultset_fsh.next()) {
                                    db_lookup_SUMMARY_FLAG_meaning = SQLResultset_fsh.getString("MEANING");
                                }

                                if (db_lookup_SUMMARY_FLAG_meaning.equals("null")) {
                                    String lookup_channel_meaning = ",SUMMARY_FLAG lookup," + "LookUp value not found" + "," + db_STG_SUMMARY_FLAG + ",Fail";
                                    section1_results.add(lookup_channel_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",RESERVES_FLAG" + "," + db_CONS_RESERVES_FLAGTransform + "," + db_STG_RESERVES_FLAG + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_lookup_SUMMARY_FLAG_meaning != null) {
                                    if (db_lookup_SUMMARY_FLAG_meaning.equals(db_STG_SUMMARY_FLAG)) {
                                        String lookup_channel_meaning = ",SUMMARY_FLAG lookup," + db_lookup_SUMMARY_FLAG_meaning + "," + db_STG_SUMMARY_FLAG + ",Pass";
                                        section1_results.add(lookup_channel_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",RESERVES_FLAG" + "," + db_CONS_RESERVES_FLAGTransform + "," + db_STG_RESERVES_FLAG + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String lookup_channel_meaning = ",SUMMARY_FLAG lookup," + db_lookup_SUMMARY_FLAG_meaning + "," + db_STG_SUMMARY_FLAG + ",Fail";
                                        section1_results.add(lookup_channel_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",RESERVES_FLAG" + "," + db_CONS_RESERVES_FLAGTransform + "," + db_STG_RESERVES_FLAG + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }


                                //------------------------ ENTITY_TYPE_CODE Validation -----------------
                                SQLResultset_fsh = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '"+db_CONS_EVENT_ID+"' and LOOKUP_TYPE = 'ENTITY_TYPE_CODE' and system = 'CCV5' and pattern = 'GLReserves'");
                                while (SQLResultset_fsh.next()) {
                                    db_lookup_ENTITY_TYPE_CODE_meaning = SQLResultset_fsh.getString("MEANING");
                                }

                                if (db_lookup_ENTITY_TYPE_CODE_meaning.equals("null")) {
                                    String lookup_currency_code_meaning = ",ENTITY_TYPE_CODE lookup," + "LookUp value not found" + "," + db_STG_ENTITY_TYPE_CODE + ",Fail";
                                    section1_results.add(lookup_currency_code_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",RESERVES_FLAG" + "," + db_CONS_RESERVES_FLAGTransform + "," + db_STG_RESERVES_FLAG + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_lookup_ENTITY_TYPE_CODE_meaning != null) {
                                    if (db_lookup_ENTITY_TYPE_CODE_meaning.equals(db_STG_ENTITY_TYPE_CODE)) {
                                        String lookup_currency_code_meaning = ",ENTITY_TYPE_CODE lookup," + db_lookup_ENTITY_TYPE_CODE_meaning + "," + db_STG_ENTITY_TYPE_CODE + ",Pass";
                                        section1_results.add(lookup_currency_code_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",RESERVES_FLAG" + "," + db_CONS_RESERVES_FLAGTransform + "," + db_STG_RESERVES_FLAG + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String lookup_currency_code_meaning = ",ENTITY_TYPE_CODE lookup," + db_lookup_ENTITY_TYPE_CODE_meaning + "," + db_STG_ENTITY_TYPE_CODE + ",Fail";
                                        section1_results.add(lookup_currency_code_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",RESERVES_FLAG" + "," + db_CONS_RESERVES_FLAGTransform + "," + db_STG_RESERVES_FLAG + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //------------------------ EVENT_CODE Validation -----------------
                                SQLResultset_fsh = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '"+db_CONS_EVENT_ID+"' and LOOKUP_TYPE = 'GLEVENTS' and system = 'CCV5' and pattern = 'GLReserves'");
                                while (SQLResultset_fsh.next()) {
                                    db_lookup_EVENT_CODE_meaning = SQLResultset_fsh.getString("MEANING");
                                }

                                if (db_lookup_EVENT_CODE_meaning.equals("null")) {
                                    String lookup_currency_code_meaning = ",EVENT_CODE lookup," + "LookUp value not found" + "," + db_STG_EVENT_CODE + ",Fail";
                                    section1_results.add(lookup_currency_code_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",RESERVES_FLAG" + "," + db_CONS_RESERVES_FLAGTransform + "," + db_STG_RESERVES_FLAG + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_lookup_EVENT_CODE_meaning != null) {
                                    if (db_lookup_EVENT_CODE_meaning.equals(db_STG_EVENT_CODE)) {
                                        String lookup_currency_code_meaning = ",EVENT_CODE lookup," + db_lookup_EVENT_CODE_meaning + "," + db_STG_EVENT_CODE + ",Pass";
                                        section1_results.add(lookup_currency_code_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",RESERVES_FLAG" + "," + db_CONS_RESERVES_FLAGTransform + "," + db_STG_RESERVES_FLAG + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String lookup_currency_code_meaning = ",EVENT_CODE lookup," + db_lookup_EVENT_CODE_meaning + "," + db_STG_EVENT_CODE + ",Fail";
                                        section1_results.add(lookup_currency_code_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",RESERVES_FLAG" + "," + db_CONS_RESERVES_FLAGTransform + "," + db_STG_RESERVES_FLAG + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //------------------------ LINE_OF_BUSINESS Validation -----------------
                                SQLResultset_fsh = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '"+db_CONS_LINE_OF_BUSINESS+"' and LOOKUP_TYPE = 'LINE_OF_BUSINESS' and system = 'CCV5' and pattern = 'GLReserves'");
                                while (SQLResultset_fsh.next()) {
                                    db_lookup_LINE_OF_BUSINESS_meaning = SQLResultset_fsh.getString("MEANING");
                                }

                                if (db_lookup_LINE_OF_BUSINESS_meaning.equals("null")) {
                                    String lookup_entity_type_code_meaning = ",LINE_OF_BUSINESS lookup," + "LookUp value not found" + "," + db_STG_LINE_OF_BUSINESS + ",Fail";
                                    section1_results.add(lookup_entity_type_code_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",RESERVES_FLAG" + "," + db_CONS_RESERVES_FLAGTransform + "," + db_STG_RESERVES_FLAG + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_lookup_LINE_OF_BUSINESS_meaning != null) {
                                    if (db_lookup_LINE_OF_BUSINESS_meaning.equals(db_STG_LINE_OF_BUSINESS)) {
                                        String lookup_entity_type_code_meaning = ",LINE_OF_BUSINESS lookup," + db_lookup_LINE_OF_BUSINESS_meaning + "," + db_STG_LINE_OF_BUSINESS + ",Pass";
                                        section1_results.add(lookup_entity_type_code_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",RESERVES_FLAG" + "," + db_CONS_RESERVES_FLAGTransform + "," + db_STG_RESERVES_FLAG + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String lookup_entity_type_code_meaning = ",LINE_OF_BUSINESS lookup," + db_lookup_LINE_OF_BUSINESS_meaning + "," + db_STG_LINE_OF_BUSINESS + ",Fail";
                                        section1_results.add(lookup_entity_type_code_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",RESERVES_FLAG" + "," + db_CONS_RESERVES_FLAGTransform + "," + db_STG_RESERVES_FLAG + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                               /* String Record_status = "Actual Record Status in FSH : " + db_stg_status;
                                section1_results.add(Record_status);*/
                            }

                        }
                    }
                }
                //----------------- Validate the Over all Status -------------------
                System.out.println("Looping ++  CONS_flag " + CONS_flag);
                String Overall_status = null;
                String Overall_stg_status = null;
                if (CONS_flag > 0) {
                    CONS_STATUS.add("Fail");
                    Overall_status = "Fail";
                } else {
                    CONS_STATUS.add("Pass");
                    Overall_status = "Pass";
                }


                if (CONS_flag > 0) {
                    OverAllStatus.add("Fail");
                } else {
                    OverAllStatus.add("Pass");
                }

                String tbl_summary_filelist = Source +","+ pattern + ","+file_name +","+ "CONS TO STG " + "," + load_date + ","+ OverAllStatus + "," + btc_BATCH_PKEY;
                //String tbl_summary_filelist = Source + "," + pattern + "," + file_name + "," + load_dateFormat + "," + "CONST TO STG " + "," + OverAllStatus;
                summary_results_tbl.add(tbl_summary_filelist);

                list.addAll(section1_results);
                list.addAll(section2_results);
                list.addAll(section3_results);
                list.addAll(section4_results);

                // ---------------- HTML Report generation ------------------------
                report_generation.report_Test1(section1_results, "Header", xml_file_name, "CONSOLIDATION LAYER - STAGING LAYER", "CCV5_GL_Reserves", "CCV5_GL_Reserves : CONSOLIDATION LAYER - STAGING AGGREGATE LAYER", "");
                report_generation.report_Test1(section1_results, "Section2", xml_file_name, "CONSOLIDATION LAYER - STAGING LAYER", "CCV5_GL_Reserves", "CCV5_GL_Reserves : CONSOLIDATION LAYER - STAGING AGGREGATE LAYER", "");
                report_generation.report_Test1(section2_results, "Mandatory", xml_file_name, "Mandatory_Check_CONS", "CCV5_GL_Reserves", "CCV5_GL_Reserves : CONSOLIDATION LAYER - STAGING AGGREGATE LAYER", "");
                report_generation.report_Test1(section4_results, "Mandatory", xml_file_name, "Mandatory_Check_STG", "CCV5_GL_Reserves", "CCV5_GL_Reserves : CONSOLIDATION LAYER - STAGING AGGREGATE LAYER", "");
                report_generation.report_Test1(section3_results, "Section3", xml_file_name, "STAGING TO AGGREGATE LAYER", "CCV5_GL_Reserves", "CCV5_GL_Reserves : CONSOLIDATION LAYER - STAGING AGGREGATE LAYER", "");

                table_detail_report.detail_report_tbl(section2_results_tbl);
            }

            state_model.section_method(file_list, CONS_STATUS, "N/A", OverAllStatus, "CCV5_GLReserves_Summary");
            table_summary_report.summary_report_tbl(summary_results_tbl );
        }


    }

}
