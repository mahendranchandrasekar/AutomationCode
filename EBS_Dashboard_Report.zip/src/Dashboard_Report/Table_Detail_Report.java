package Dashboard_Report;

import org.json.JSONException;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.*;
import java.util.List;



public class Table_Detail_Report {

    String URL_SIT1 = "jdbc:oracle:thin:@dbs119dev.gwd.grpinf.net:1521/FSHDTST4";
    String Username_SIT1 = "FSH_ORA_DATA";
    String password_SIT1 = "XdbvFm!dm7dVCzWE";

    static Statement SQLstmt = null;
    static ResultSet SQLResultset = null;
    static Connection connection = null;




    public void detail_report_tbl_delete(Connection connection, String sourceName) throws IOException, SQLException {
        String query = null;

        query = "DELETE DLG_FSH_AUT_DETAILS where Trunc(LOAD_DATE) = TRUNC(SYSDATE-5) and SOURCE='"+sourceName+"'";
        PreparedStatement preparedStmt = connection.prepareStatement(query);
        preparedStmt.setString(1, sourceName);
        preparedStmt.execute();

    }


    public void detail_report_tbl(List list) throws IOException, SQLException {
        String query = null;
        Date load_dateFormat = null;

        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            connectDatabase(URL_SIT1, Username_SIT1, password_SIT1);
        }
        catch(Exception e){

            e.printStackTrace();
        }


        query = "INSERT INTO DLG_FSH_AUT_DETAILS (S_NO, HEADER_LINE, SOURCE, PATTERN, COLUMN_NAME,ACTUAL_IN_DB, EXPECTED_VALUE, STATUS, LOAD_DATE, FILE_NAME,BATCH_PKEY) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)";
        PreparedStatement preparedStatement = connection.prepareStatement(query);
        System.out.println("List size ----" + list.size());

        for(int i=0; i< list.size(); i++){
            String exp_result1 = (String) list.get(i);
            String[] exp_result = exp_result1.split(",");
            for (int j = 0; j < exp_result.length; j++){
                if(j==8) {
                    //Converting Load date format
                    String load_dateTRIM = exp_result[j].substring(0, 10);
                    load_dateFormat =Date.valueOf(load_dateTRIM);
                    preparedStatement.setDate((j+1), load_dateFormat);
                } else {
                    preparedStatement.setString((j+1), exp_result[j]);
                }
            }
            preparedStatement.execute();
        }

        connection.close();
    }



    public void connectDatabase(String server, String username,String password) throws SQLException, IOException, JSONException {

        System.out.println("Connectdatabase starts");
        connection = DriverManager.getConnection(server,username,password);
        //SQLstmt = connection.createStatement();


    }


}
