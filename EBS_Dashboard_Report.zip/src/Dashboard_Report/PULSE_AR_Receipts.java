package Dashboard_Report;

import java.io.IOException;
import java.sql.*;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONException;

public class PULSE_AR_Receipts {

    static Statement SQLstmt = null;
    static ResultSet SQLResultset = null;

    public static HTML_Report_Generation_DB_EVO report_generation;
    public static HTML_Report_Generation_State_Model_B4C report_generation_state;
    public static SCH_EVO_PC_State_Model_B4C state_model;

    public static Table_Detail_Report table_detail_report;
    public static Table_Summary_Report table_summary_report;
    public static connectDatabase connect_db;

    public static void main(String[] args) throws IOException, SQLException, ParseException, JSONException {
        report_generation = new HTML_Report_Generation_DB_EVO();
        report_generation_state = new HTML_Report_Generation_State_Model_B4C();
        state_model = new SCH_EVO_PC_State_Model_B4C();

        table_detail_report = new Table_Detail_Report();
        table_summary_report = new Table_Summary_Report();
        connect_db = new connectDatabase();

        //----------------------- delete the existing report --------------
        report_generation.clean_report("PULSE_ARReceipts.html");
        report_generation_state.clean_report_summary("PULSE_ARReceipts_Summary.html");

        /*//--------------- SIT  database details -------------------
        String URL_SIT1 = "jdbc:oracle:thin:@dbs119dev.gwd.grpinf.net:1521/FSHDTST3";
        String Username_SIT1 = "FSH_ORA_DATA";
        String password_SIT1 = "Development_Test3";*/

        //--------------- SIT  database details -------------------
        String URL_SIT1 = "jdbc:oracle:thin:@dbs119dev.gwd.grpinf.net:1521/FSHDTST4";
        String Username_SIT1 = "FSH_ORA_DATA";
        String password_SIT1 = "XdbvFm!dm7dVCzWE";

        //--------------- EBS  database details -------------------
        String URL_ICSI = "jdbc:oracle:thin:@dcn2ddbx340.gwd.grpinf.net:1618:ICSI";
        String Username_ICSI = "apps";
        String password_ICSI = "apps4icsi";

        List<String> file_list = new ArrayList<String>();
        List<String> list = new ArrayList<String>();
        List<String> section1_results = new ArrayList<String>();
        //List<String> section2_results = new ArrayList<String>();

        List<String> OverAllStatus = new ArrayList<String>();
        List<String> CONS_STATUS = new ArrayList<String>();
        List<String> summary_results_tbl = new ArrayList<String>();

        String[] file_lists = null;
        int section1_map_row = 1;

        //--------------------- Declaring the supporting details for reporting --------------
        String file_name = "null";
        String Source = "PULS";
        String pattern = "ARReceipts";
        String header = "Header";
        String line = "Line";

        int cons_stg_map_row = 1;
        int stg_line_map_row = 1;
        int cons_mandatory_map_row = 1;
        int line_mandatory_map_row = 1;
        int stg_mandatory_map_row = 1;


        // Consolidation Header table variable
        String db_CONS_INTERFACE_HEADER_PKEY = "null";
        String db_CONS_Batch_Pkey = "null";
        String db_CONS_STATUS = "null";
        String db_CONS_File_Name = "null";
        String db_CONS_SOURCE = "null";
        String db_CONS_LOCKBOX_BATCH_COUNT = "null";
        String db_CONS_TRANSMISSION_RECORD_ID = "null";
        String db_CONS_TRANSMISSION_HEADER_ID = "null";
        String db_CONS_TRAILER_TRANSMISSION_RECORD_ID = "null";
        String db_CONS_RECORD_TYPE = "null";
        String db_CONS_BATCH_ID = "null";
        String db_CONS_SOURCE_STATUS = "null";
        String db_CONS_BATCH_NAME  = "null";
        String db_CONS_ITEM_NUMBER  = "null";
        String db_CONS_REMITTANCE_AMOUNT = "null";
        String db_CONS_CURRENCY_CODE = "null";
        String db_CONS_DESTINATION_ACCOUNT = "null";
        String db_CONS_ORIGINATION = "null";
        String db_CONS_PRINT_STS = "null";
        String db_CONS_LOCKBOX_NUMBER = "null";
        String db_CONS_LOCKBOX_RECORD_COUNT = "null";
        String db_CONS_LOCKBOX_AMOUNT = "null";
        String db_CONS_PROCESS_TYPE = "null";
        String CONS_HDR_STATUS = "null";
        String load_date = "null";
        Date load_dateFormat = null;
        String btc_BATCH_PKEY = null;

        // Consolidation Line table variable
        String db_CONS_INTERFACE_LINE_PKEY = "null";
        String db_CONS_LINE_INTERFACE_HEADER_FKEY = "null";
        String db_CONS_LINE_Batch_Pkey = "null";
        String db_CONS_LINE_File_Name = "null";
        String db_CONS_LINE_SOURCE = "null";
        String db_CONS_LINE_TRANSMISSION_RECORD_ID = "null";
        String db_CONS_LINE_TRANSMISSION_HEADER_ID = "null";
        String db_CONS_LINE_TRANSMISSION_LINE_ID = "null";
        String db_CONS_LINE_RECORD_TYPE = "null";
        String db_CONS_LINE_SOURCE_STATUS = "null";
        String db_CONS_LINE_DEPOSIT_DATE = "null";
        String db_STG_LINE_TRANSMISSION_REQUEST_ID = "null";
        String db_CONS_LINE_TRANSMISSION_RECORD_COUNT = "null";
        String db_CONS_LINE_TRANSMISSION_AMOUNT = "null";
        String db_CONS_LINE_LOCKBOX_NUMBER = "null";
        String db_CONS_LINE_BATCH_NAME = "null";
        String db_CONS_LINE_ITEM_NUMBER = "null";
        String db_CONS_LINE_CURRENCY_CODE = "null";
        String db_CONS_LINE_REMITTANCE_AMOUNT = "null";
        String CONS_LINE_STATUS = "null";
        String db_CONS_LINE_CHECK_NUMBER = "null";
        String db_CONS_LINE_CUSTOMER_NUMBER = "null";
        String db_CONS_LINE_INVOICE1 = "null";
        String db_CONS_LINE_RECEIPT_METHOD = "null";
        String db_CONS_LINE_BILL_TO_LOCATION = "null";
        String db_CONS_LINE_RECEIPT_DATE = "null";
        String db_CONS_LINE_CUSTOMER_BANK_NAME = "null";
        String db_CONS_LINE_CUSTOMER_BANK_BRANCH_NAME = "null";
        String db_CONS_LINE_PROCESS_TYPE = "null";
        String db_CONS_LINE_PRINT_STS = "null";
        String db_CONS_LINE_ATTRIBUTE1 = "null";
        String db_CONS_LINE_ATTRIBUTE2 = "null";
        String db_CONS_LINE_ATTRIBUTE3 = "null";



        // Staging Header table variable declaration
        String db_STG_Batch_Pkey = "null";
        String db_STG_ARREC_HEADER_ID = "null";
        String db_STG_STATUS = "null";
        String db_STG_BATCH_NAME  = "null";
        String db_STG_ITEM_NUMBER  = "null";
        String db_STG_File_Name = "null";
        String db_STG_SOURCE = "null";
        String db_STG_CURRENCY_CODE = "null";
        String db_STG_REMITTANCE_AMOUNT = "null";
        String db_STG_BATCH_SOURCE_NAME = "null";
        String db_STG_SET_OF_BOOKS_ID = "null";
        String db_STG_ORG_ID = "null";
        String db_STG_BATCH_ID = "null";
        String db_STG_LOCKBOX_BATCH_COUNT = "null";
        String db_STG_TRANSMISSION_RECORD_ID = "null";
        String db_STG_TRAILER_TRANSMISSION_RECORD_ID = "null";
        String db_STG_RECORD_TYPE = "null";
        String db_STG_TRANSMISSION_HEADER_ID = "null";
        String db_STG_SOURCE_STATUS = "null";
        String db_STG_DESTINATION_ACCOUNT = "null";
        String db_STG_ORIGINATION = "null";
        String db_STG_DEPOSIT_DATE = "null";
        String db_STG_LOCKBOX_NUMBER = "null";
        String db_STG_LOCKBOX_RECORD_COUNT = "null";
        String db_STG_LOCKBOX_AMOUNT = "null";
        String db_STG_PROCESS_TYPE = "null";
        String db_STG_PRINT_STS = "null";
        String STG_HDR_STATUS = "null";



        // Staging line table variable declaration
        String db_STG_LINE_BATCH_FKEY = "null";
        String db_STG_LINE_FILE_NAME = "null";
        String db_STG_LINE_SOURCE = "null";
        String db_STG_LINE_TRANSMISSION_RECORD_ID = "null";
        String db_STG_LINE_TRANSMISSION_HEADER_ID = "null";
        String db_STG_LINE_TRANSMISSION_LINE_ID= "null";
        String db_STG_LINE_RECORD_TYPE = "null";
        String db_STG_LINE_SOURCE_STATUS = "null";
        String db_STG_LINE_LOCKBOX_NUMBER = "null";
        String db_STG_LINE_BATCH_NAME = "null";
        String db_STG_LINE_BATCH_AMOUNT = "null";
        String db_STG_LINE_BATCH_RECORD_COUNT = "null";
        String db_STG_LINE_ITEM_NUMBER= "null";
        String db_STG_LINE_CURRENCY_CODE = "null";
        String db_STG_LINE_REMITTANCE_AMOUNT = "null";
        String db_STG_LINE_CUSTOMER_NUMBER = "null";
        String db_STG_LINE_CHECK_NUMBER = "null";
        String db_STG_LINE_INVOICE1 = "null";
        String db_STG_LINE_RECEIPT_DATE = "null";
        String db_STG_LINE_CUSTOMER_BANK_NAME = "null";
        String db_STG_LINE_CUSTOMER_BANK_BRANCH_NAME = "null";
        String db_STG_LINE_RECEIPT_METHOD = "null";
        String db_STG_LINE_BILL_TO_LOCATION = "null";
        String db_STG_LINE_PROCESS_TYPE = "null";
        String db_STG_LINE_PRINT_STS = "null";
        String STG_LINE_STATUS = "null";
        String db_STG_LINE_ATTRIBUTE1 = "null";
        String db_STG_LINE_ATTRIBUTE2 = "null";
        String db_STG_LINE_ATTRIBUTE3 = "null";

        String xmlfile_name = "null";
        String xml_file_name1 = null;


        //---------------- Line item -------
        String db_stg_line_id = "null";
        String db_stg_INVOICE_ID = "null";


        //--------------- Consolidation variables decleration ---------
        String db_cons_header_id = "null";


        //-------- Connect to Database --------------
        connect_db.createConnection("DEVTEST4");
        //table_detail_report.detail_report_tbl_delete(connection, Source);


        //------ get the new file from batch control table --------------
        boolean newRecord = true;
        String outSQL = connect_db.executeQuery_DB("BATCH", "ARReceipts_batchCtl", "PULSE");
        SQLstmt = connect_db.resStatement();

        SQLResultset = SQLstmt.executeQuery(outSQL);
        while (SQLResultset.next()) {
            file_list.add(SQLResultset.getString("FILE_NAME"));
            System.out.println("File name---" + SQLResultset.getString("FILE_NAME"));
            list.addAll(section1_results);
        }


        // ---------------------------------- Get the batch PKEY ----------------------
        String outSQL_bkey = connect_db.executeQuery_DB("BATCH", "ARReceipts_batchCtl_key", "PULSE");

        SQLResultset = SQLstmt.executeQuery(outSQL_bkey);
        while (SQLResultset.next()) {
            btc_BATCH_PKEY = SQLResultset.getString("BATCH_PKEY");
        }

        // ---------------------------------- Check the new file ----------------------
        SQLResultset = SQLstmt.executeQuery(outSQL);
        if (!SQLResultset.next()) {
            System.out.println("No new PULSE_ARReceipts files have been received to FSH ");
            newRecord = false;
            String nonewfile = ",FILE_NAME," + "No new PULSE_ARReceipts files have been received to FSH" + "," + "," + ",Pass";
            section1_results.add(nonewfile);
            list.addAll(section1_results);
        }

        if (newRecord) {

            //------------------------ Section 1 Start Print all the new file in the report-------------------
            for (String num_file : file_list) {
                file_lists = num_file.split(",");
                for (String file_list1 : file_lists) {
                    xml_file_name1 = file_list1;
                    //int section1_map_row = 1;
                    String newfile = section1_map_row + ",FILE_NAME," + xml_file_name1 + "," + xml_file_name1 + ",Pass";
                    section1_map_row++;
                    section1_results.add(newfile);
                }
            }
            list.addAll(section1_results);
            //report_generation.report_Test1(section1_results, "Section1", xml_file_name1, "B4C BC CONS BATCH TABLE VALIDATION", "B4C_SCHBilling", "B4C BC VALIDATION");
            //------------------------ Section 1 End ----------------------------------------------
        }

        List<String> list_header = new ArrayList<String>(); // -- Add all the header id
        if (newRecord) {
            //------------ Split the file names form the list --------------
            for (String xml_file_name : file_list) {
                int section2_map_row = 1;
                int CONS_flag = 0;
                List<String> section2_results = new ArrayList<String>();
                List<String> section3_results = new ArrayList<String>();
                List<String> section2_results_tbl = new ArrayList<String>();

                file_name = xml_file_name;


        /*//------ get the new file from batch control table --------------
        boolean newRecord = true;
        //SQLResultset = SQLstmt.executeQuery("Select distinct file_name from DLG_FSH_CTL_BATCH where Trunc(LOAD_DATE) = TRUNC(SYSDATE-1) and system = 'PULS' and pattern = 'ARReceipts'");
        SQLResultset = SQLstmt.executeQuery("Select distinct file_name from DLG_FSH_CTL_BATCH where file_name = 'PULS_ARReciepts_68282_20191120'");
        while (SQLResultset.next()) {
            file_list.add(SQLResultset.getString("FILE_NAME"));
            System.out.println("File name---" + SQLResultset.getString("FILE_NAME"));
            list.addAll(section1_results);
        }

        //------------------ validate no new files -----------------------
        String xmlfile_name = "null";
        //SQLResultset = SQLstmt.executeQuery("Select distinct file_name from DLG_FSH_CTL_BATCH where Trunc(LOAD_DATE) = TRUNC(SYSDATE-1) and system = 'PULS' and pattern = 'ARReceipts' ");
        SQLResultset = SQLstmt.executeQuery("Select distinct file_name from DLG_FSH_CTL_BATCH where file_name = 'PULS_ARReciepts_68282_20191120'");
        if (!SQLResultset.next()) {
            System.out.println("No new PULSE AR Receipts files have been received to FSH ");
            newRecord = false;
            String nonewfile = ",FILE_NAME," + "No new PULSE AR Receipts files have been received to FSH" + "," + "," + ",Pass";
        }

        List<String> list_header = new ArrayList<String>();
        List<String> list_header1 = new ArrayList<String>();// -- Add all the header id
        if (newRecord) {
            //------------ Split the file names form the list --------------
            for (String xml_file_name : file_list) {

                int CONS_flag = 0;
                int STG_flag = 0;
                String stgFlag = "Pass";
                String toFlag = "Pass";
                //int cons_stg_map_row = 1;
                int section2_line_map_row = 1;
                int section4_map_row = 1;*/

                //-------------- Cons table - HEADER ----------------
                String PulseARReceipts_consSqlQuery = connect_db.executeQuery_DB("PULSE_AR", "ARReceipts_Cons", "PULSE");
                SQLResultset = SQLstmt.executeQuery(PulseARReceipts_consSqlQuery + "'" + file_name + "'");
                //SQLResultset = SQLstmt.executeQuery("SELECT * from DLG_FSH_CONS_PULS_ARREC_HDR WHERE FILE_NAME = '" + xml_file_name + "'");
                while (SQLResultset.next()) {
                    db_CONS_TRANSMISSION_HEADER_ID = SQLResultset.getString("TRANSMISSION_HEADER_ID");
                    list_header.add(db_CONS_TRANSMISSION_HEADER_ID);
                }


                for (int i = 0; i < list_header.size(); i++) {
                    SQLResultset = SQLstmt.executeQuery(PulseARReceipts_consSqlQuery + "'" + file_name + "' and TRANSMISSION_HEADER_ID = '" + list_header.get(i) + "' ");
                    //SQLResultset = SQLstmt.executeQuery("SELECT * from DLG_FSH_CONS_PULS_ARREC_HDR WHERE FILE_NAME = '" + xml_file_name + "' and TRANSMISSION_HEADER_ID ='" + list_header.get(i) + "'") ;
                    while (SQLResultset.next()) {
                        db_CONS_TRANSMISSION_HEADER_ID = SQLResultset.getString("TRANSMISSION_HEADER_ID");
                        db_CONS_Batch_Pkey = SQLResultset.getString("Batch_Fkey");
                        db_CONS_STATUS = SQLResultset.getString("STATUS");
                        db_CONS_File_Name = SQLResultset.getString("File_Name");
                        db_CONS_SOURCE = SQLResultset.getString("SOURCE");
                        db_CONS_BATCH_ID = SQLResultset.getString("BATCH_ID");
                        db_CONS_LOCKBOX_BATCH_COUNT = SQLResultset.getString("LOCKBOX_BATCH_COUNT");
                        db_CONS_TRANSMISSION_RECORD_ID = SQLResultset.getString("TRANSMISSION_RECORD_ID");
                        db_CONS_TRAILER_TRANSMISSION_RECORD_ID = SQLResultset.getString("TRAILER_TRANSMISSION_RECORD_ID");
                        db_CONS_RECORD_TYPE = SQLResultset.getString("RECORD_TYPE");
                        db_CONS_SOURCE_STATUS = SQLResultset.getString("SOURCE_STATUS");
                        db_CONS_DESTINATION_ACCOUNT = SQLResultset.getString("DESTINATION_ACCOUNT");
                        db_CONS_ORIGINATION = SQLResultset.getString("ORIGINATION");
                        db_CONS_LOCKBOX_NUMBER = SQLResultset.getString("LOCKBOX_NUMBER");
                        db_CONS_LOCKBOX_RECORD_COUNT = SQLResultset.getString("LOCKBOX_RECORD_COUNT");
                        db_CONS_LOCKBOX_AMOUNT = SQLResultset.getString("LOCKBOX_AMOUNT");
                        db_CONS_PROCESS_TYPE = SQLResultset.getString("PROCESS_TYPE");
                        db_CONS_PRINT_STS = SQLResultset.getString("PRINT_STS");
                        load_date = SQLResultset.getString("LOAD_DATE");
                        String db_file_name = SQLResultset.getString("FILE_NAME");

                        //Converting Load date format
                        String load_dateTRIM = load_date.substring(0, 10);
                        load_dateFormat = Date.valueOf(load_dateTRIM);
                        System.out.println(load_dateFormat);


                        //Validating mandatory fields in consolidation table
                        //Batch_Pkey - mandatory validation
                        if ((db_CONS_Batch_Pkey == null) && (CONS_HDR_STATUS != "REVIEW")) {

                            String cons_Batch_Pkey = cons_mandatory_map_row + "," + db_CONS_TRANSMISSION_HEADER_ID + ",Batch_key," + "Batch_key : " + db_CONS_Batch_Pkey + "," + "Batch_key was not found," + CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(cons_Batch_Pkey);
                            cons_mandatory_map_row++;
                        } else {
                            String cons_Batch_Pkey = cons_mandatory_map_row + "," + db_CONS_TRANSMISSION_HEADER_ID + ",Batch_key," + "Batch_key : " + db_CONS_Batch_Pkey + "," + "Batch_key was found," + CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(cons_Batch_Pkey);
                            cons_mandatory_map_row++;
                        }

                        //File_Name - mandatory validation
                        if ((db_CONS_File_Name == null) && (CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_File_Name = "," + ",File_Name," + "File_Name : " + db_CONS_File_Name + "," + "File_Name was not found," + CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_File_Name);
                        } else {
                            String CONS_File_Name = "," + ",File_Name," + "File_Name : " + db_CONS_File_Name + "," + "File_Name was found," + CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_File_Name);
                        }

                        //PROCESS_TYPE - mandatory validation
                        if ((db_CONS_PROCESS_TYPE == null) && (CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_PROCESS_TYPE = "," + ",PROCESS_TYPE," + "PROCESS_TYPE : " + db_CONS_PROCESS_TYPE + "," + "PROCESS_TYPE was not found," + CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_PROCESS_TYPE);
                        } else {
                            String CONS_PROCESS_TYPE = "," + ",PROCESS_TYPE," + "PROCESS_TYPE : " + db_CONS_PROCESS_TYPE + "," + "PROCESS_TYPE was found," + CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_PROCESS_TYPE);
                        }

                        //SOURCE - mandatory validation
                        if ((db_CONS_SOURCE == null) && (CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_SOURCE = "," + ",SOURCE," + "SOURCE : " + db_CONS_SOURCE + "," + "SOURCE was not found," + CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_SOURCE);
                        } else {
                            String CONS_SOURCE = "," + ",SOURCE," + "SOURCE : " + db_CONS_SOURCE + "," + "SOURCE was found," + CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_SOURCE);
                        }

                        //TRANSMISSION_RECORD_ID - mandatory validation
                        if ((db_CONS_TRANSMISSION_RECORD_ID == null) && (CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_TRANSMISSION_RECORD_ID = "," + ",TRANSMISSION_RECORD_ID," + "TRANSMISSION_RECORD_ID : " + db_CONS_TRANSMISSION_RECORD_ID + "," + "TRANSMISSION_RECORD_ID was not found," + CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_TRANSMISSION_RECORD_ID);
                        } else {
                            String CONS_TRANSMISSION_RECORD_ID = "," + ",TRANSMISSION_RECORD_ID," + "TRANSMISSION_RECORD_ID : " + db_CONS_TRANSMISSION_RECORD_ID + "," + "TRANSMISSION_RECORD_ID was found," + CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_TRANSMISSION_RECORD_ID);
                        }

                        //TRANSMISSION_HEADER_ID - mandatory validation
                        if ((db_CONS_TRANSMISSION_HEADER_ID == null) && (CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_TRANSMISSION_HEADER_ID = "," + ",TRANSMISSION_HEADER_ID," + "TRANSMISSION_HEADER_ID : " + "," + "TRANSMISSION_HEADER_ID was not found," + CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_TRANSMISSION_HEADER_ID);
                        } else {
                            String CONS_TRANSMISSION_HEADER_ID = "," + ",TRANSMISSION_HEADER_ID," + "TRANSMISSION_HEADER_ID : " + "," + "TRANSMISSION_HEADER_ID was found," + CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_TRANSMISSION_HEADER_ID);
                        }

                        //RECORD_TYPE - mandatory validation
                        if ((db_CONS_RECORD_TYPE == null) && (CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_RECORD_TYPE = "," + ",RECORD_TYPE," + "RECORD_TYPE : " + db_CONS_RECORD_TYPE + "," + "RECORD_TYPE was not found," + CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_RECORD_TYPE);
                        } else {
                            String CONS_RECORD_TYPE = "," + ",RECORD_TYPE," + "RECORD_TYPE : " + db_CONS_RECORD_TYPE + "," + "RECORD_TYPE was found," + CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_RECORD_TYPE);
                        }

                        //SOURCE_STATUS - mandatory validation
                        if ((db_CONS_SOURCE_STATUS == null) && (CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_SOURCE_STATUS = "," + ",SOURCE_STATUS," + "SOURCE_STATUS : " + db_CONS_SOURCE_STATUS + "," + "SOURCE_STATUS was not found," + CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_SOURCE_STATUS);
                        } else {
                            String CONS_SOURCE_STATUS = "," + ",SOURCE_STATUS," + "SOURCE_STATUS : " + db_CONS_SOURCE_STATUS + "," + "SOURCE_STATUS was found," + CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_SOURCE_STATUS);
                        }

                        //LOCKBOX_NUMBER - mandatory validation
                        if ((db_CONS_LOCKBOX_NUMBER == null) && (CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_LOCKBOX_NUMBER = "," + ",LOCKBOX_NUMBER," + "LOCKBOX_NUMBER : " + db_CONS_LOCKBOX_NUMBER + "," + "LOCKBOX_NUMBER was not found," + CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_LOCKBOX_NUMBER);
                        } else {
                            String CONS_LOCKBOX_NUMBER = "," + ",LOCKBOX_NUMBER," + "LOCKBOX_NUMBER : " + db_CONS_LOCKBOX_NUMBER + "," + "LOCKBOX_NUMBER was found," + CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_LOCKBOX_NUMBER);
                        }

                        //LOCKBOX_RECORD_COUNT - mandatory validation
                        if ((db_CONS_LOCKBOX_RECORD_COUNT == null) && (CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_LOCKBOX_RECORD_COUNT = "," + ",LOCKBOX_RECORD_COUNT," + "LOCKBOX_RECORD_COUNT : " + db_CONS_LOCKBOX_RECORD_COUNT + "," + "LOCKBOX_RECORD_COUNT was not found," + CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_LOCKBOX_RECORD_COUNT);
                        } else {
                            String CONS_LOCKBOX_RECORD_COUNT = "," + ",LOCKBOX_RECORD_COUNT," + "LOCKBOX_RECORD_COUNT : " + db_CONS_LOCKBOX_RECORD_COUNT + "," + "LOCKBOX_RECORD_COUNT was found," + CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_LOCKBOX_RECORD_COUNT);
                        }

                        //LOCKBOX_AMOUNT - mandatory validation
                        if ((db_CONS_LOCKBOX_AMOUNT == null) && (CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_LOCKBOX_AMOUNT = "," + ",LOCKBOX_AMOUNT," + "LOCKBOX_AMOUNT : " + db_CONS_LOCKBOX_AMOUNT + "," + "LOCKBOX_AMOUNT was not found," + CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_LOCKBOX_AMOUNT);
                        } else {
                            String CONS_LOCKBOX_AMOUNT = "," + ",LOCKBOX_AMOUNT," + "LOCKBOX_AMOUNT : " + db_CONS_LOCKBOX_AMOUNT + "," + "LOCKBOX_AMOUNT was found," + CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_LOCKBOX_AMOUNT);
                        }


                        //PROCESS_TYPE - mandatory validation
                        if ((db_CONS_PROCESS_TYPE == null) && (CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_PROCESS_TYPE = "," + ",PROCESS_TYPE," + "PROCESS_TYPE : " + db_CONS_PROCESS_TYPE + "," + "PROCESS_TYPE was not found," + CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_PROCESS_TYPE);
                        } else {
                            String CONS_PROCESS_TYPE = "," + ",PROCESS_TYPE," + "PROCESS_TYPE : " + db_CONS_PROCESS_TYPE + "," + "PROCESS_TYPE was found," + CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_PROCESS_TYPE);
                        }

                        //------------------- Consolidation to Staging ----------------------------------
                        String PulseARReceipts_stgSqlQuery = connect_db.executeQuery_DB("PULSE_AR", "ARReceipts_Stg", "PULSE");
                        SQLResultset = SQLstmt.executeQuery(PulseARReceipts_stgSqlQuery + "'" + file_name + "' and TRANSMISSION_HEADER_ID = '" + list_header.get(i) + "' ");
                        System.out.println("Header id outer ---" + db_CONS_TRANSMISSION_HEADER_ID);
                        if (!SQLResultset.next()) {
                            String stg_header_id = section2_map_row + ",HEADER_ID," + "no records available in STG table" + "," + db_CONS_TRANSMISSION_HEADER_ID + ",Fail";
                            section2_results.add(stg_header_id);
                        } else {
                            SQLResultset = SQLstmt.executeQuery(PulseARReceipts_stgSqlQuery + "'" + file_name + "' and TRANSMISSION_HEADER_ID = '" + list_header.get(i) + "' ");
                            //SQLResultset = SQLstmt.executeQuery("SELECT * from DLG_FSH_STG_COMM_ARRECEIPTS_HDR WHERE FILE_NAME = '" + xml_file_name + "' and TRANSMISSION_HEADER_ID = '" + list_header1.get(i) + "' ");
                            while (SQLResultset.next()) {

                                STG_HDR_STATUS = SQLResultset.getString("STATUS");
                                db_STG_TRANSMISSION_HEADER_ID = SQLResultset.getString("TRANSMISSION_HEADER_ID");
                                db_STG_Batch_Pkey = SQLResultset.getString("Batch_Fkey");
                                db_STG_File_Name = SQLResultset.getString("File_Name");
                                db_STG_SOURCE = SQLResultset.getString("SOURCE");
                                db_STG_SOURCE_STATUS = SQLResultset.getString("SOURCE_STATUS");
                                db_STG_SET_OF_BOOKS_ID = SQLResultset.getString("SET_OF_BOOKS_ID");
                                db_STG_ORG_ID = SQLResultset.getString("ORG_ID");
                                db_STG_TRANSMISSION_RECORD_ID = SQLResultset.getString("TRANSMISSION_RECORD_ID");
                                db_STG_TRANSMISSION_HEADER_ID = SQLResultset.getString("TRANSMISSION_HEADER_ID");
                                db_STG_TRAILER_TRANSMISSION_RECORD_ID = SQLResultset.getString("TRAILER_TRANSMISSION_RECORD_ID");
                                db_STG_RECORD_TYPE = SQLResultset.getString("RECORD_TYPE");
                                db_STG_DESTINATION_ACCOUNT = SQLResultset.getString("DESTINATION_ACCOUNT");
                                db_STG_ORIGINATION = SQLResultset.getString("ORIGINATION");
                                db_STG_DEPOSIT_DATE = SQLResultset.getString("DEPOSIT_DATE");
                                db_STG_LOCKBOX_NUMBER = SQLResultset.getString("LOCKBOX_NUMBER");
                                db_STG_LOCKBOX_RECORD_COUNT = SQLResultset.getString("LOCKBOX_RECORD_COUNT");
                                db_STG_LOCKBOX_AMOUNT = SQLResultset.getString("LOCKBOX_AMOUNT");
                                db_STG_PROCESS_TYPE = SQLResultset.getString("PROCESS_TYPE");
                                db_STG_BATCH_SOURCE_NAME = SQLResultset.getString("BATCH_SOURCE_NAME");
                                db_STG_BATCH_ID = SQLResultset.getString("BATCH_ID");
                                db_STG_LOCKBOX_BATCH_COUNT = SQLResultset.getString("LOCKBOX_BATCH_COUNT");
                                db_STG_PRINT_STS = SQLResultset.getString("PRINT_STS");



                           /* if (db_CONS_INTERFACE_HEADER_PKEY.equals(db_STG_INTERFACE_HEADER_FKEY)) {
                                String cons_header_id = cons_stg_map_row + ",LOCKBOX_NUMBER," + db_STG_INTERFACE_HEADER_FKEY + "," + db_CONS_INTERFACE_HEADER_PKEY + ",Pass";
                                section1_results.add(cons_header_id);
                                cons_stg_map_row++;
                            } else {
                                String cons_header_id = cons_stg_map_row + ",LOCKBOX_NUMBER," + db_STG_INTERFACE_HEADER_FKEY + "," + db_CONS_INTERFACE_HEADER_PKEY + ",Fail";
                                section1_results.add(cons_header_id);
                                cons_stg_map_row++;
                            }*/


                                if (db_CONS_Batch_Pkey.equals(db_STG_Batch_Pkey)) {
                                    String STG_Batch_Pkey = cons_stg_map_row + ",Batch_Pkey," + db_CONS_Batch_Pkey + "," + db_STG_Batch_Pkey + ",Pass";
                                    section1_results.add(STG_Batch_Pkey);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",Batch_key" + "," + db_CONS_Batch_Pkey + "," + db_STG_Batch_Pkey + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    cons_stg_map_row++;
                                } else {
                                    String STG_Batch_Pkey = cons_stg_map_row + ",Batch_Pkey," + db_CONS_Batch_Pkey + "," + db_STG_Batch_Pkey + ",Fail";
                                    section1_results.add(STG_Batch_Pkey);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",Batch_key" + "," + db_CONS_Batch_Pkey + "," + db_STG_Batch_Pkey + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    cons_stg_map_row++;
                                    CONS_flag++;
                                }


                                if (db_CONS_File_Name.equals(db_STG_File_Name)) {
                                    String STG_File_Name = ",File_Name," + db_CONS_File_Name + "," + db_STG_File_Name + ",Pass";
                                    section1_results.add(STG_File_Name);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",File_Name" + "," + db_CONS_File_Name + "," + db_STG_File_Name + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_File_Name = ",File_Name," + db_CONS_File_Name + "," + db_STG_File_Name + ",Fail";
                                    section1_results.add(STG_File_Name);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",File_Name" + "," + db_CONS_File_Name + "," + db_STG_File_Name + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }


                                //------------- Validate SOURCE ----------------
                                if ((db_STG_SOURCE != null) && (db_CONS_SOURCE != null)) {
                                    if (db_STG_SOURCE.equals(db_CONS_SOURCE)) {
                                        String STG_SOURCE = ",SOURCE," + db_CONS_SOURCE + "," + db_STG_SOURCE + ",Pass";
                                        section1_results.add(STG_SOURCE);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SOURCE" + "," + db_CONS_SOURCE + "," + db_STG_SOURCE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String STG_SOURCE = ",SOURCE," + db_CONS_SOURCE + "," + db_STG_SOURCE + ",Fail";
                                        section1_results.add(STG_SOURCE);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SOURCE" + "," + db_CONS_SOURCE + "," + db_STG_SOURCE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                } else {
                                    String STG_SOURCE = ",SOURCE," + db_CONS_SOURCE + "," + db_STG_SOURCE + ",Pass";
                                    section1_results.add(STG_SOURCE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SOURCE" + "," + db_CONS_SOURCE + "," + db_STG_SOURCE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                }

                                //--------------------  Validation BATCH_ID ---------------
                                if (db_CONS_BATCH_ID.equals(db_STG_BATCH_ID)) {
                                    String STG_BATCH_ID = ",BATCH_ID," + db_CONS_BATCH_ID + "," + db_STG_BATCH_ID + ",Pass";
                                    section1_results.add(STG_BATCH_ID);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BATCH_ID" + "," + db_CONS_BATCH_ID + "," + db_STG_BATCH_ID + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_BATCH_ID = ",BATCH_ID," + db_CONS_BATCH_ID + "," + db_STG_BATCH_ID + ",Fail";
                                    section1_results.add(STG_BATCH_ID);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BATCH_ID" + "," + db_CONS_BATCH_ID + "," + db_STG_BATCH_ID + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                            /*//--------------------  Validation LOCKBOX_BATCH_COUNT ---------------
                            if (db_CONS_LOCKBOX_BATCH_COUNT.equals(db_STG_LOCKBOX_BATCH_COUNT)) {
                                String STG_LOCKBOX_BATCH_COUNT = ",LOCKBOX_BATCH_COUNT," + db_CONS_LOCKBOX_BATCH_COUNT + "," + db_STG_LOCKBOX_BATCH_COUNT + ",Pass";
                                section1_results.add(STG_LOCKBOX_BATCH_COUNT);
                            } else {
                                String STG_LOCKBOX_BATCH_COUNT = ",LOCKBOX_BATCH_COUNT," + db_CONS_LOCKBOX_BATCH_COUNT + "," + db_STG_LOCKBOX_BATCH_COUNT + ",Fail";
                                section1_results.add(STG_LOCKBOX_BATCH_COUNT);
                            }*/

                                //------------- Validate TRANSMISSION_RECORD_ID ----------------
                                if ((db_STG_TRANSMISSION_RECORD_ID != null) && (db_CONS_TRANSMISSION_RECORD_ID != null)) {
                                    if (db_STG_TRANSMISSION_RECORD_ID.equals(db_CONS_TRANSMISSION_RECORD_ID)) {
                                        String STG_TRANSMISSION_RECORD_ID = ",TRANSMISSION_RECORD_ID," + db_CONS_TRANSMISSION_RECORD_ID + "," + db_STG_TRANSMISSION_RECORD_ID + ",Pass";
                                        section1_results.add(STG_TRANSMISSION_RECORD_ID);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSMISSION_RECORD_ID" + "," + db_CONS_TRANSMISSION_RECORD_ID + "," + db_STG_TRANSMISSION_RECORD_ID + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String STG_TRANSMISSION_RECORD_ID = ",TRANSMISSION_RECORD_ID," + db_CONS_TRANSMISSION_RECORD_ID + "," + db_STG_TRANSMISSION_RECORD_ID + ",Fail";
                                        section1_results.add(STG_TRANSMISSION_RECORD_ID);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSMISSION_RECORD_ID" + "," + db_CONS_TRANSMISSION_RECORD_ID + "," + db_STG_TRANSMISSION_RECORD_ID + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                } else {
                                    String STG_TRANSMISSION_RECORD_ID = ",TRANSMISSION_RECORD_ID," + db_CONS_TRANSMISSION_RECORD_ID + "," + db_STG_TRANSMISSION_RECORD_ID + ",Pass";
                                    section1_results.add(STG_TRANSMISSION_RECORD_ID);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSMISSION_RECORD_ID" + "," + db_CONS_TRANSMISSION_RECORD_ID + "," + db_STG_TRANSMISSION_RECORD_ID + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                }

                                //--------------------  Validation TRANSMISSION_HEADER_ID ---------------
                                if (db_CONS_TRANSMISSION_HEADER_ID.equals(db_STG_TRANSMISSION_HEADER_ID)) {
                                    String STG_TRANSMISSION_HEADER_ID = ",TRANSMISSION_HEADER_ID," + db_CONS_TRANSMISSION_HEADER_ID + "," + db_STG_TRANSMISSION_HEADER_ID + ",Pass";
                                    section1_results.add(STG_TRANSMISSION_HEADER_ID);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSMISSION_HEADER_ID" + "," + db_CONS_TRANSMISSION_HEADER_ID + "," + db_STG_TRANSMISSION_HEADER_ID + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_TRANSMISSION_HEADER_ID = ",TRANSMISSION_HEADER_ID," + db_CONS_TRANSMISSION_HEADER_ID + "," + db_STG_TRANSMISSION_HEADER_ID + ",Fail";
                                    section1_results.add(STG_TRANSMISSION_HEADER_ID);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSMISSION_HEADER_ID" + "," + db_CONS_TRANSMISSION_HEADER_ID + "," + db_STG_TRANSMISSION_HEADER_ID + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation TRAILER_TRANSMISSION_RECORD_ID ---------------
                                if ((db_CONS_TRAILER_TRANSMISSION_RECORD_ID != null) && (db_STG_TRAILER_TRANSMISSION_RECORD_ID != null)) {
                                    if (db_CONS_TRAILER_TRANSMISSION_RECORD_ID.equals(db_STG_TRAILER_TRANSMISSION_RECORD_ID)) {
                                        String STG_TRANSMISSION_HEADER_ID = ",TRAILER_TRANSMISSION_RECORD_ID," + db_CONS_TRAILER_TRANSMISSION_RECORD_ID + "," + db_STG_TRAILER_TRANSMISSION_RECORD_ID + ",Pass";
                                        section1_results.add(STG_TRANSMISSION_HEADER_ID);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRAILER_TRANSMISSION_RECORD_ID" + "," + db_CONS_TRAILER_TRANSMISSION_RECORD_ID + "," + db_STG_TRAILER_TRANSMISSION_RECORD_ID + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String STG_TRANSMISSION_HEADER_ID = ",TRAILER_TRANSMISSION_RECORD_ID," + db_CONS_TRAILER_TRANSMISSION_RECORD_ID + "," + db_STG_TRAILER_TRANSMISSION_RECORD_ID + ",Fail";
                                        section1_results.add(STG_TRANSMISSION_HEADER_ID);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRAILER_TRANSMISSION_RECORD_ID" + "," + db_CONS_TRAILER_TRANSMISSION_RECORD_ID + "," + db_STG_TRAILER_TRANSMISSION_RECORD_ID + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                } else {
                                    String STG_TRANSMISSION_HEADER_ID = ",TRAILER_TRANSMISSION_RECORD_ID," + db_CONS_TRAILER_TRANSMISSION_RECORD_ID + "," + db_STG_TRAILER_TRANSMISSION_RECORD_ID + ",Pass";
                                    section1_results.add(STG_TRANSMISSION_HEADER_ID);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRAILER_TRANSMISSION_RECORD_ID" + "," + db_CONS_TRAILER_TRANSMISSION_RECORD_ID + "," + db_STG_TRAILER_TRANSMISSION_RECORD_ID + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                }

                                //--------------------  Validation RECORD_TYPE ---------------
                                if (db_CONS_RECORD_TYPE.equals(db_STG_RECORD_TYPE)) {
                                    String STG_RECORD_TYPE = ",RECORD_TYPE," + db_CONS_RECORD_TYPE + "," + db_STG_RECORD_TYPE + ",Pass";
                                    section1_results.add(STG_RECORD_TYPE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",RECORD_TYPE" + "," + db_CONS_RECORD_TYPE + "," + db_STG_RECORD_TYPE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_RECORD_TYPE = ",RECORD_TYPE," + db_CONS_RECORD_TYPE + "," + db_STG_RECORD_TYPE + ",Fail";
                                    section1_results.add(STG_RECORD_TYPE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",RECORD_TYPE" + "," + db_CONS_RECORD_TYPE + "," + db_STG_RECORD_TYPE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation SOURCE_STATUS ---------------
                                if (db_CONS_SOURCE_STATUS.equals(db_STG_SOURCE_STATUS)) {
                                    String STG_SOURCE_STATUS = ",SOURCE_STATUS," + db_CONS_SOURCE_STATUS + "," + db_STG_SOURCE_STATUS + ",Pass";
                                    section1_results.add(STG_SOURCE_STATUS);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SOURCE_STATUS" + "," + db_CONS_SOURCE_STATUS + "," + db_STG_SOURCE_STATUS + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_SOURCE_STATUS = ",SOURCE_STATUS," + db_CONS_SOURCE_STATUS + "," + db_STG_SOURCE_STATUS + ",Fail";
                                    section1_results.add(STG_SOURCE_STATUS);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SOURCE_STATUS" + "," + db_CONS_SOURCE_STATUS + "," + db_STG_SOURCE_STATUS + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                }

                                //--------------------  Validation DESTINATION_ACCOUNT ---------------
                                if ((db_STG_DESTINATION_ACCOUNT != null) && (db_CONS_DESTINATION_ACCOUNT != null)) {
                                    if (db_CONS_DESTINATION_ACCOUNT.equals(db_STG_DESTINATION_ACCOUNT)) {
                                        String STG_DESTINATION_ACCOUNT = ",DESTINATION_ACCOUNT," + db_CONS_DESTINATION_ACCOUNT + "," + db_STG_DESTINATION_ACCOUNT + ",Pass";
                                        section1_results.add(STG_DESTINATION_ACCOUNT);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",DESTINATION_ACCOUNT" + "," + db_CONS_DESTINATION_ACCOUNT + "," + db_STG_DESTINATION_ACCOUNT + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String STG_DESTINATION_ACCOUNT = ",DESTINATION_ACCOUNT," + db_CONS_DESTINATION_ACCOUNT + "," + db_STG_DESTINATION_ACCOUNT + ",Fail";
                                        section1_results.add(STG_DESTINATION_ACCOUNT);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",DESTINATION_ACCOUNT" + "," + db_CONS_DESTINATION_ACCOUNT + "," + db_STG_DESTINATION_ACCOUNT + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                } else {
                                    String STG_DESTINATION_ACCOUNT = ",DESTINATION_ACCOUNT," + db_CONS_DESTINATION_ACCOUNT + "," + db_STG_DESTINATION_ACCOUNT + ",Pass";
                                    section1_results.add(STG_DESTINATION_ACCOUNT);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",DESTINATION_ACCOUNT" + "," + db_CONS_DESTINATION_ACCOUNT + "," + db_STG_DESTINATION_ACCOUNT + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                }

                                //------------- Validate ORIGINATION ----------------
                                if ((db_STG_ORIGINATION != null) && (db_CONS_ORIGINATION != null)) {
                                    if (db_STG_ORIGINATION.equals(db_CONS_ORIGINATION)) {
                                        String STG_ORIGINATION = ",ORIGINATION," + db_CONS_ORIGINATION + "," + db_STG_ORIGINATION + ",Pass";
                                        section1_results.add(STG_ORIGINATION);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ORIGINATION" + "," + db_CONS_ORIGINATION + "," + db_STG_ORIGINATION + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String STG_ORIGINATION = ",ORIGINATION," + db_CONS_ORIGINATION + "," + db_STG_ORIGINATION + ",Fail";
                                        section1_results.add(STG_ORIGINATION);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ORIGINATION" + "," + db_CONS_ORIGINATION + "," + db_STG_ORIGINATION + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                } else {
                                    String STG_ORIGINATION = ",ORIGINATION," + db_CONS_ORIGINATION + "," + db_STG_ORIGINATION + ",Pass";
                                    section1_results.add(STG_ORIGINATION);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ORIGINATION" + "," + db_CONS_ORIGINATION + "," + db_STG_ORIGINATION + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                }

                                //--------------------  Validation LOCKBOX_NUMBER ---------------
                                String db_CONS_LOCKBOX_NUMBERModified = db_CONS_LOCKBOX_NUMBER.trim();
                                if (db_CONS_LOCKBOX_NUMBERModified.equals(db_STG_LOCKBOX_NUMBER)) {
                                    String STG_LOCKBOX_NUMBER = ",LOCKBOX_NUMBER," + db_CONS_LOCKBOX_NUMBERModified + "," + db_STG_LOCKBOX_NUMBER + ",Pass";
                                    section1_results.add(STG_LOCKBOX_NUMBER);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",LOCKBOX_NUMBER" + "," + db_CONS_LOCKBOX_NUMBERModified + "," + db_STG_LOCKBOX_NUMBER + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_LOCKBOX_NUMBER = ",LOCKBOX_NUMBER," + db_CONS_LOCKBOX_NUMBERModified + "," + db_STG_LOCKBOX_NUMBER + ",Fail";
                                    section1_results.add(STG_LOCKBOX_NUMBER);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",LOCKBOX_NUMBER" + "," + db_CONS_LOCKBOX_NUMBERModified + "," + db_STG_LOCKBOX_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation LOCKBOX_RECORD_COUNT ---------------
                                if (db_CONS_LOCKBOX_RECORD_COUNT.equals(db_STG_LOCKBOX_RECORD_COUNT)) {
                                    String STG_LOCKBOX_RECORD_COUNT = ",LOCKBOX_RECORD_COUNT," + db_CONS_LOCKBOX_RECORD_COUNT + "," + db_STG_LOCKBOX_RECORD_COUNT + ",Pass";
                                    section1_results.add(STG_LOCKBOX_RECORD_COUNT);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",LOCKBOX_RECORD_COUNT" + "," + db_CONS_LOCKBOX_RECORD_COUNT + "," + db_STG_LOCKBOX_RECORD_COUNT + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_LOCKBOX_RECORD_COUNT = ",LOCKBOX_RECORD_COUNT," + db_CONS_LOCKBOX_RECORD_COUNT + "," + db_STG_LOCKBOX_RECORD_COUNT + ",Fail";
                                    section1_results.add(STG_LOCKBOX_RECORD_COUNT);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",LOCKBOX_RECORD_COUNT" + "," + db_CONS_LOCKBOX_RECORD_COUNT + "," + db_STG_LOCKBOX_RECORD_COUNT + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation LOCKBOX_AMOUNT ---------------
                                if (db_CONS_LOCKBOX_AMOUNT.equals(db_STG_LOCKBOX_AMOUNT)) {
                                    String STG_LOCKBOX_AMOUNT = ",LOCKBOX_AMOUNT," + db_CONS_LOCKBOX_AMOUNT + "," + db_STG_LOCKBOX_AMOUNT + ",Pass";
                                    section1_results.add(STG_LOCKBOX_AMOUNT);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",LOCKBOX_AMOUNT" + "," + db_CONS_LOCKBOX_AMOUNT + "," + db_STG_LOCKBOX_AMOUNT + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_LOCKBOX_AMOUNT = ",LOCKBOX_AMOUNT," + db_CONS_LOCKBOX_AMOUNT + "," + db_STG_LOCKBOX_AMOUNT + ",Fail";
                                    section1_results.add(STG_LOCKBOX_AMOUNT);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",LOCKBOX_AMOUNT" + "," + db_CONS_LOCKBOX_AMOUNT + "," + db_STG_LOCKBOX_AMOUNT + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation PROCESS_TYPE ---------------
                                if (db_CONS_PROCESS_TYPE.equals(db_STG_PROCESS_TYPE)) {
                                    String STG_PROCESS_TYPE = ",PROCESS_TYPE," + db_CONS_PROCESS_TYPE + "," + db_STG_PROCESS_TYPE + ",Pass";
                                    section1_results.add(STG_PROCESS_TYPE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PROCESS_TYPE" + "," + db_CONS_PROCESS_TYPE + "," + db_STG_PROCESS_TYPE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_PROCESS_TYPE = ",PROCESS_TYPE," + db_CONS_PROCESS_TYPE + "," + db_STG_PROCESS_TYPE + ",Fail";
                                    section1_results.add(STG_PROCESS_TYPE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PROCESS_TYPE" + "," + db_CONS_PROCESS_TYPE + "," + db_STG_PROCESS_TYPE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //------------- Validate PRINT_STS ----------------
                                if ((db_STG_PRINT_STS != null) && (db_CONS_PRINT_STS != null)) {
                                    if (db_STG_PRINT_STS.equals(db_CONS_PRINT_STS)) {
                                        String STG_PRINT_STS = ",PRINT_STS," + db_CONS_PRINT_STS + "," + db_STG_PRINT_STS + ",Pass";
                                        section1_results.add(STG_PRINT_STS);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRINT_STS" + "," + db_CONS_PRINT_STS + "," + db_STG_PRINT_STS + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String STG_PRINT_STS = ",PRINT_STS," + db_CONS_PRINT_STS + "," + db_STG_PRINT_STS + ",Fail";
                                        section1_results.add(STG_PRINT_STS);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRINT_STS" + "," + db_CONS_PRINT_STS + "," + db_STG_PRINT_STS + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                } else {
                                    String STG_PRINT_STS = ",PRINT_STS," + db_CONS_PRINT_STS + "," + db_STG_PRINT_STS + ",Pass";
                                    section1_results.add(STG_PRINT_STS);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRINT_STS" + "," + db_CONS_PRINT_STS + "," + db_STG_PRINT_STS + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                }

                                //----------------------- Business validation - Reference data table validation -----------------------------
                                String db_ref_DESTINATION_ACCOUNT_meaning = "null";
                                String db_ref_ORIGINATION_meaning = "null";

                                String PulseARReceipts_fsh_refARLockbox_accNumber = connect_db.executeQuery_DB("Reference", "ARReceipts_REF_ARLOCKBOX_ACCOUNT_NUMBER", "PULSE");
                                String PulseARReceipts_fsh_refARLockbox_bankNumber = connect_db.executeQuery_DB("Reference", "ARReceipts_REF_ARLOCKBOX_BANK_NUMBER", "PULSE");

                                //------------------------------DESTINATION_ACCOUNT-------------------------------
                                //SQLResultset = SQLstmt.executeQuery("select BANK_ACCOUNT_NUMBER as bankAccountNumber from DLG_FSH_REF_AR_LOCKBOX where BANK_ACCOUNT_NUMBER='" + db_STG_DESTINATION_ACCOUNT + "' and BANK_ACCOUNT_NAME like '%UKAARC%'");
                                //SQLResultset = SQLstmt.executeQuery("select BANK_ACCOUNT_NUMBER as bankAccountNumber from DLG_FSH_REF_AR_LOCKBOX where BANK_ACCOUNT_NUMBER='"+db_STG_DESTINATION_ACCOUNT+"'");

                                if (db_STG_DESTINATION_ACCOUNT != null) {
                                    String db_STG_DESTINATION_ACCOUNTModified = db_STG_DESTINATION_ACCOUNT.trim();
                                    SQLResultset = SQLstmt.executeQuery(PulseARReceipts_fsh_refARLockbox_accNumber + " WHERE BANK_ACCOUNT_NUMBER = '" + db_STG_DESTINATION_ACCOUNTModified + "'");
                                    //SQLResultset = SQLstmt.executeQuery("select BANK_ACCOUNT_NUMBER as bankAccountNumber from DLG_FSH_REF_AR_LOCKBOX where BANK_ACCOUNT_NUMBER='" + db_STG_DESTINATION_ACCOUNTModified + "'");
                                    while (SQLResultset.next()) {
                                        db_ref_DESTINATION_ACCOUNT_meaning = SQLResultset.getString("bankAccountNumber");
                                    }
                                    if (db_ref_DESTINATION_ACCOUNT_meaning.equals("null")) {
                                        String ref_DESTINATION_ACCOUNT_meaning = ",DESTINATION_ACCOUNT Reference_Table," + "Transformation value not found" + "," + db_STG_DESTINATION_ACCOUNTModified + ",Fail";
                                        section1_results.add(ref_DESTINATION_ACCOUNT_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",DESTINATION_ACCOUNT Reference_Table" + "," + "Transformation value not found" + "," + db_STG_DESTINATION_ACCOUNTModified + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_ref_DESTINATION_ACCOUNT_meaning != null) {
                                        if (db_ref_DESTINATION_ACCOUNT_meaning.equals(db_STG_DESTINATION_ACCOUNTModified)) {
                                            String ref_DESTINATION_ACCOUNT_meaning = ",DESTINATION_ACCOUNT Reference_Table," + db_ref_DESTINATION_ACCOUNT_meaning + "," + db_STG_DESTINATION_ACCOUNTModified + ",Pass";
                                            section1_results.add(ref_DESTINATION_ACCOUNT_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",DESTINATION_ACCOUNT Reference_Table" + "," + db_ref_DESTINATION_ACCOUNT_meaning + "," + db_STG_DESTINATION_ACCOUNTModified + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String ref_DESTINATION_ACCOUNT_meaning = ",DESTINATION_ACCOUNT Reference_Table," + db_ref_DESTINATION_ACCOUNT_meaning + "," + db_STG_DESTINATION_ACCOUNTModified + ",Fail";
                                            section1_results.add(ref_DESTINATION_ACCOUNT_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",DESTINATION_ACCOUNT Reference_Table" + "," + db_ref_DESTINATION_ACCOUNT_meaning + "," + db_STG_DESTINATION_ACCOUNTModified + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }
                                } else {
                                    String ref_DESTINATION_ACCOUNT_meaning = ",DESTINATION_ACCOUNT has null value in Staging/Consolidation," + db_STG_DESTINATION_ACCOUNT + "," + db_STG_DESTINATION_ACCOUNT + ",Fail";
                                    section1_results.add(ref_DESTINATION_ACCOUNT_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",DESTINATION_ACCOUNT has null value in Staging/Consolidation" + "," + db_STG_DESTINATION_ACCOUNT + "," + db_STG_DESTINATION_ACCOUNT + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //------------------------------ORIGINATION-------------------------------
                                if (db_STG_ORIGINATION != null) {
                                    String db_STG_ORIGINATIONModified = db_STG_ORIGINATION.trim();
                                    SQLResultset = SQLstmt.executeQuery(PulseARReceipts_fsh_refARLockbox_bankNumber + " WHERE BANK_ACCOUNT_NUMBER = '" + db_STG_ORIGINATIONModified + "'");
                                    //SQLResultset = SQLstmt.executeQuery("select BANK_NUM as bankNumber from DLG_FSH_REF_AR_LOCKBOX where BANK_NUM='" + db_STG_ORIGINATIONModified + "'");
                                    while (SQLResultset.next()) {
                                        db_ref_ORIGINATION_meaning = SQLResultset.getString("bankNumber");
                                    }
                                    if (db_ref_ORIGINATION_meaning.equals("null")) {
                                        String ref_DESTINATION_ACCOUNT_meaning = ",ORIGINATION Reference_Table," + "Transformation value not found" + "," + db_STG_ORIGINATIONModified + ",Fail";
                                        section1_results.add(ref_DESTINATION_ACCOUNT_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ORIGINATION Reference_Table" + "," + "Transformation value not found" + "," + db_STG_ORIGINATIONModified + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    } else if (db_ref_ORIGINATION_meaning != null) {
                                        if (db_ref_ORIGINATION_meaning.equals(db_STG_ORIGINATIONModified)) {
                                            String ref_DESTINATION_ACCOUNT_meaning = ",ORIGINATION Reference_Table," + db_ref_ORIGINATION_meaning + "," + db_STG_ORIGINATIONModified + ",Pass";
                                            section1_results.add(ref_DESTINATION_ACCOUNT_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ORIGINATION Reference_Table" + "," + db_ref_ORIGINATION_meaning + "," + db_STG_ORIGINATIONModified + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                        } else {
                                            String ref_DESTINATION_ACCOUNT_meaning = ",ORIGINATION Reference_Table," + db_ref_ORIGINATION_meaning + "," + db_STG_ORIGINATIONModified + ",Fail";
                                            section1_results.add(ref_DESTINATION_ACCOUNT_meaning);
                                            String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ORIGINATION Reference_Table" + "," + db_ref_ORIGINATION_meaning + "," + db_STG_ORIGINATIONModified + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_header_id);
                                            CONS_flag++;
                                        }
                                    }
                                } else {
                                    String ref_DESTINATION_ACCOUNT_meaning = ",ORIGINATION has null value in Staging/Consolidation," + db_STG_ORIGINATION + "," + db_STG_ORIGINATION + ",Fail";
                                    section1_results.add(ref_DESTINATION_ACCOUNT_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ORIGINATION Reference_Table" + "," + db_STG_ORIGINATION + "," + db_STG_ORIGINATION + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }


                                //----------------------- STANDARDISATION start here -----------------------------
                                //----------------------- Lookup table validation start here -----------------------------
                                String db_lookup_SET_OF_BOOKS_ID_meaning = "null";
                                String db_lookup_Org_ID_meaning = "null";

                                //------------------------ SET_OF_BOOKS_ID Validation -----------------
                                String PulseARReceipts_fsh_lookup = connect_db.executeQuery_DB("Lookup", "FSH_LOOKUP", "PULSE");
                                String PulseARReceipts_fsh_sys_lookup = connect_db.executeQuery_DB("Lookup", "FSH_SYS_LOOKUP", "PULSE");
                                String fsh_source = connect_db.executeQuery_DB("Lookup", "FSH_LOOKUP_SOURCE_PulseARReceipts", "PULSE");

                                SQLResultset = SQLstmt.executeQuery(PulseARReceipts_fsh_sys_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'SET_OF_BOOKS_ID'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'SET_OF_BOOKS_ID' and system = 'PULS' and pattern = 'ARReceipts'");
                                while (SQLResultset.next()) {
                                    db_lookup_SET_OF_BOOKS_ID_meaning = SQLResultset.getString("MEANING");
                                }

                                if (db_lookup_SET_OF_BOOKS_ID_meaning.equals("null")) {
                                    String lookup_SET_OF_BOOKS_ID_meaning = ",SET_OF_BOOKS_ID lookup," + "LookUp value not found" + "," + db_STG_SET_OF_BOOKS_ID + ",Fail";
                                    section1_results.add(lookup_SET_OF_BOOKS_ID_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SET_OF_BOOKS_ID lookup" + "," + "LookUp value not found" + "," + db_STG_SET_OF_BOOKS_ID + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_lookup_SET_OF_BOOKS_ID_meaning != null) {
                                    if (db_lookup_SET_OF_BOOKS_ID_meaning.equals(db_STG_SET_OF_BOOKS_ID)) {
                                        String lookup_SET_OF_BOOKS_ID_meaning = ",SET_OF_BOOKS_ID lookup," + db_lookup_SET_OF_BOOKS_ID_meaning + "," + db_STG_SET_OF_BOOKS_ID + ",Pass";
                                        section1_results.add(lookup_SET_OF_BOOKS_ID_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SET_OF_BOOKS_ID lookup" + "," + db_lookup_SET_OF_BOOKS_ID_meaning + "," + db_STG_SET_OF_BOOKS_ID + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String lookup_SET_OF_BOOKS_ID_meaning = ",SET_OF_BOOKS_ID lookup," + db_lookup_SET_OF_BOOKS_ID_meaning + "," + db_STG_SET_OF_BOOKS_ID + ",Fail";
                                        section1_results.add(lookup_SET_OF_BOOKS_ID_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SET_OF_BOOKS_ID lookup" + "," + db_lookup_SET_OF_BOOKS_ID_meaning + "," + db_STG_SET_OF_BOOKS_ID + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //------------------------ Org_ID Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(PulseARReceipts_fsh_sys_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'ORG_ID'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'ORG_ID' and system = 'PULS' and pattern = 'ARReceipts'");
                                while (SQLResultset.next()) {
                                    db_lookup_Org_ID_meaning = SQLResultset.getString("MEANING");
                                }

                                if (db_lookup_Org_ID_meaning.equals("null")) {
                                    String lookup_Org_ID_meaning = ",Org_ID lookup," + "LookUp value not found" + "," + db_STG_ORG_ID + ",Fail";
                                    section1_results.add(lookup_Org_ID_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",Org_ID lookup" + "," + "LookUp value not found" + "," + db_STG_ORG_ID + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_lookup_Org_ID_meaning != null) {
                                    if (db_lookup_Org_ID_meaning.equals(db_STG_ORG_ID)) {
                                        String lookup_Org_ID_meaning = ",Org_ID lookup," + db_lookup_Org_ID_meaning + "," + db_STG_ORG_ID + ",Pass";
                                        section1_results.add(lookup_Org_ID_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",Org_ID lookup" + "," + db_lookup_Org_ID_meaning + "," + db_STG_ORG_ID + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String lookup_Org_ID_meaning = ",Org_ID lookup," + db_lookup_Org_ID_meaning + "," + db_STG_ORG_ID + ",Fail";
                                        section1_results.add(lookup_Org_ID_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",Org_ID lookup" + "," + db_lookup_Org_ID_meaning + "," + db_STG_ORG_ID + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //------------------------  Line Item variable Declaration -----------------------------

                                //------------------------  Line Item validation -----------------------------
                                int line_count = 0;
                                ArrayList<String> list_line_id = new ArrayList<String>();
                                String PulseARReceipts_stglineSqlQuery = connect_db.executeQuery_DB("PULSE_AR", "ARReceipts_Stg_line", "PULSE");
                                SQLResultset = SQLstmt.executeQuery(PulseARReceipts_stglineSqlQuery + "WHERE TRANSMISSION_HEADER_ID = '" + db_STG_TRANSMISSION_HEADER_ID + "' ");
                                //SQLResultset = SQLstmt.executeQuery("SELECT * FROM  DLG_FSH_STG_COMM_ARRECEIPTS_LIN WHERE  TRANSMISSION_HEADER_ID = '" + db_STG_TRANSMISSION_HEADER_ID + "'");
                                while (SQLResultset.next()) {
                                    list_line_id.add(SQLResultset.getString("TRANSMISSION_LINE_ID"));
                                }

                                for (int i_count = 0; i_count <= list_line_id.size() - 1; i_count++) {
                                    int stg_sub_indent = i_count;
                                    int sub_tag_line = 0;
                                    System.out.println("Line id ---> " + list_line_id.get(i_count));
                                    SQLResultset = SQLstmt.executeQuery(PulseARReceipts_stglineSqlQuery + "WHERE TRANSMISSION_HEADER_ID = '" + db_STG_TRANSMISSION_HEADER_ID + "' and TRANSMISSION_LINE_ID = '" + list_line_id.get(i_count) + "' ");
                                    //SQLResultset = SQLstmt.executeQuery("SELECT * FROM  DLG_FSH_STG_COMM_ARRECEIPTS_LIN WHERE  TRANSMISSION_HEADER_ID = '" + db_STG_TRANSMISSION_HEADER_ID + "' and TRANSMISSION_LINE_ID='" + list_line_id.get(i_count) + "'");
                                    while (SQLResultset.next()) {
                                        db_STG_LINE_BATCH_FKEY = SQLResultset.getString("BATCH_FKEY");
                                        db_STG_LINE_FILE_NAME = SQLResultset.getString("FILE_NAME");
                                        db_STG_LINE_SOURCE = SQLResultset.getString("SOURCE");
                                        db_STG_LINE_TRANSMISSION_HEADER_ID = SQLResultset.getString("TRANSMISSION_HEADER_ID");
                                        db_STG_LINE_TRANSMISSION_RECORD_ID = SQLResultset.getString("TRANSMISSION_RECORD_ID");
                                        db_STG_LINE_TRANSMISSION_LINE_ID = SQLResultset.getString("TRANSMISSION_LINE_ID");
                                        db_STG_LINE_RECORD_TYPE = SQLResultset.getString("RECORD_TYPE");
                                        db_STG_LINE_SOURCE_STATUS = SQLResultset.getString("SOURCE_STATUS");
                                        db_STG_LINE_LOCKBOX_NUMBER = SQLResultset.getString("LOCKBOX_NUMBER");
                                        db_STG_LINE_BATCH_NAME = SQLResultset.getString("BATCH_NAME");
                                        db_STG_LINE_ITEM_NUMBER = SQLResultset.getString("ITEM_NUMBER");
                                        db_STG_LINE_CURRENCY_CODE = SQLResultset.getString("CURRENCY_CODE");
                                        db_STG_LINE_REMITTANCE_AMOUNT = SQLResultset.getString("REMITTANCE_AMOUNT");
                                        db_STG_LINE_CHECK_NUMBER = SQLResultset.getString("CHECK_NUMBER");
                                        db_STG_LINE_INVOICE1 = SQLResultset.getString("INVOICE1");
                                        db_STG_LINE_CUSTOMER_NUMBER = SQLResultset.getString("CUSTOMER_NUMBER");
                                        db_STG_LINE_RECEIPT_METHOD = SQLResultset.getString("RECEIPT_METHOD");
                                        db_STG_LINE_BILL_TO_LOCATION = SQLResultset.getString("BILL_TO_LOCATION");
                                        db_STG_LINE_RECEIPT_DATE = SQLResultset.getString("RECEIPT_DATE");
                                        db_STG_LINE_CUSTOMER_BANK_NAME = SQLResultset.getString("CUSTOMER_BANK_NAME");
                                        db_STG_LINE_CUSTOMER_BANK_BRANCH_NAME = SQLResultset.getString("CUSTOMER_BANK_BRANCH_NAME");
                                        db_STG_LINE_PROCESS_TYPE = SQLResultset.getString("PROCESS_TYPE");
                                        db_STG_LINE_PRINT_STS = SQLResultset.getString("PRINT_STS");
                                        STG_LINE_STATUS = SQLResultset.getString("STATUS");
                                        db_STG_LINE_ATTRIBUTE1 = SQLResultset.getString("ATTRIBUTE1");
                                        db_STG_LINE_ATTRIBUTE2 = SQLResultset.getString("ATTRIBUTE2");
                                        db_STG_LINE_ATTRIBUTE3 = SQLResultset.getString("ATTRIBUTE3");


                                        String PulseARReceipts_conslineSqlQuery = connect_db.executeQuery_DB("PULSE_AR", "ARReceipts_Cons_line", "PULSE");
                                        SQLResultset = SQLstmt.executeQuery(PulseARReceipts_conslineSqlQuery + "WHERE TRANSMISSION_HEADER_ID = '" + db_STG_TRANSMISSION_HEADER_ID + "' and TRANSMISSION_LINE_ID = '" + db_STG_LINE_TRANSMISSION_LINE_ID + "' ");
                                        //SQLResultset = SQLstmt.executeQuery("SELECT * FROM DLG_FSH_CONS_PULS_ARREC_LIN WHERE TRANSMISSION_HEADER_ID = '" + db_STG_TRANSMISSION_HEADER_ID + "' and TRANSMISSION_LINE_ID = '" + db_STG_LINE_TRANSMISSION_LINE_ID + "' ");
                                        while (SQLResultset.next()) {
                                            //db_CONS_line_id = SQLResultset.getString("LINE_ID");
                                            //db_CONS_LINE_NUMBER = SQLResultset.getString("LINE_NUMBER");
                                            db_CONS_LINE_Batch_Pkey = SQLResultset.getString("BATCH_FKEY");
                                            db_CONS_LINE_File_Name = SQLResultset.getString("FILE_NAME");
                                            db_CONS_LINE_SOURCE = SQLResultset.getString("SOURCE");
                                            db_CONS_LINE_TRANSMISSION_HEADER_ID = SQLResultset.getString("TRANSMISSION_HEADER_ID");
                                            db_CONS_LINE_TRANSMISSION_RECORD_ID = SQLResultset.getString("TRANSMISSION_RECORD_ID");
                                            db_CONS_LINE_TRANSMISSION_LINE_ID = SQLResultset.getString("TRANSMISSION_LINE_ID");
                                            db_CONS_LINE_RECORD_TYPE = SQLResultset.getString("RECORD_TYPE");
                                            db_CONS_LINE_DEPOSIT_DATE = SQLResultset.getString("DEPOSIT_DATE");
                                            db_CONS_LINE_SOURCE_STATUS = SQLResultset.getString("SOURCE_STATUS");
                                            db_CONS_LINE_LOCKBOX_NUMBER = SQLResultset.getString("LOCKBOX_NUMBER");
                                            db_CONS_LINE_BATCH_NAME = SQLResultset.getString("BATCH_NAME");
                                            db_CONS_LINE_ITEM_NUMBER = SQLResultset.getString("ITEM_NUMBER");
                                            db_CONS_LINE_CURRENCY_CODE = SQLResultset.getString("CURRENCY_CODE");
                                            db_CONS_LINE_REMITTANCE_AMOUNT = SQLResultset.getString("REMITTANCE_AMOUNT");
                                            db_CONS_LINE_CHECK_NUMBER = SQLResultset.getString("CHECK_NUMBER");
                                            db_CONS_LINE_INVOICE1 = SQLResultset.getString("INVOICE1");
                                            db_CONS_LINE_CUSTOMER_NUMBER = SQLResultset.getString("CUSTOMER_NUMBER");
                                            db_CONS_LINE_RECEIPT_METHOD = SQLResultset.getString("RECEIPT_METHOD");
                                            db_CONS_LINE_BILL_TO_LOCATION = SQLResultset.getString("BILL_TO_LOCATION");
                                            db_CONS_LINE_RECEIPT_DATE = SQLResultset.getString("RECEIPT_DATE");
                                            db_CONS_LINE_CUSTOMER_BANK_NAME = SQLResultset.getString("CUSTOMER_BANK_NAME");
                                            db_CONS_LINE_CUSTOMER_BANK_BRANCH_NAME = SQLResultset.getString("CUSTOMER_BANK_BRANCH_NAME");
                                            db_CONS_LINE_PROCESS_TYPE = SQLResultset.getString("PROCESS_TYPE");
                                            db_CONS_LINE_PRINT_STS = SQLResultset.getString("PRINT_STS");
                                            CONS_LINE_STATUS = SQLResultset.getString("STATUS");
                                            db_CONS_LINE_ATTRIBUTE1 = SQLResultset.getString("ATTRIBUTE1");
                                            db_CONS_LINE_ATTRIBUTE2 = SQLResultset.getString("ATTRIBUTE2");
                                            db_CONS_LINE_ATTRIBUTE3 = SQLResultset.getString("ATTRIBUTE3");


                                            //Validating mandatory fields in LINE consolidation table
                                            //Batch_Pkey - mandatory validation
                                            if ((db_CONS_LINE_Batch_Pkey == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String CONS_LINE_Batch_Pkey = stg_mandatory_map_row + "," + db_CONS_LINE_TRANSMISSION_LINE_ID + ",LINE Batch_Pkey," + "LINE Batch_Pkey : " + db_CONS_LINE_Batch_Pkey + "," + "LINE Batch_Pkey was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(CONS_LINE_Batch_Pkey);
                                                stg_mandatory_map_row++;
                                            } else {
                                                String CONS_LINE_Batch_Pkey = stg_mandatory_map_row + "," + db_CONS_LINE_TRANSMISSION_LINE_ID + ",LINE Batch_Pkey," + "LINE Batch_Pkey : " + db_CONS_LINE_Batch_Pkey + "," + "LINE Batch_Pkey was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(CONS_LINE_Batch_Pkey);
                                                stg_mandatory_map_row++;
                                            }

                                            //File_Name - mandatory validation
                                            if ((db_CONS_LINE_File_Name == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String CONS_LINE_File_Name = "," + ",LINE File_Name," + "LINE File_Name : " + db_CONS_LINE_File_Name + "," + "LINE File_Name was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(CONS_LINE_File_Name);
                                            } else {
                                                String CONS_LINE_File_Name = "," + ",LINE File_Name," + "LINE File_Name : " + db_CONS_LINE_File_Name + "," + "LINE File_Name was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(CONS_LINE_File_Name);
                                            }


                                            //SOURCE - mandatory validation
                                            if ((db_CONS_LINE_SOURCE == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String CONS_LINE_SOURCE = "," + ",LINE SOURCE," + "LINE SOURCE : " + db_CONS_LINE_SOURCE + "," + "LINE SOURCE was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(CONS_LINE_SOURCE);
                                            } else {
                                                String CONS_LINE_SOURCE = "," + ",LINE SOURCE," + "LINE SOURCE : " + db_CONS_LINE_SOURCE + "," + "LINE SOURCE was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(CONS_LINE_SOURCE);
                                            }


                                            //TRANSMISSION_RECORD_ID - mandatory validation
                                            if ((db_CONS_LINE_TRANSMISSION_RECORD_ID == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String CONS_LINE_TRANSMISSION_RECORD_ID = "," + ",LINE BATCH_REF," + "LINE TRANSMISSION_RECORD_ID : " + db_CONS_LINE_TRANSMISSION_RECORD_ID + "," + "LINE TRANSMISSION_RECORD_ID was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(CONS_LINE_TRANSMISSION_RECORD_ID);
                                            } else {
                                                String CONS_LINE_TRANSMISSION_RECORD_ID = "," + ",LINE BATCH_REF," + "LINE TRANSMISSION_RECORD_ID : " + db_CONS_LINE_TRANSMISSION_RECORD_ID + "," + "LINE TRANSMISSION_RECORD_ID was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(CONS_LINE_TRANSMISSION_RECORD_ID);
                                            }


                                            //TRANSMISSION_HEADER_ID - mandatory validation
                                            if ((db_CONS_LINE_TRANSMISSION_HEADER_ID == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String CONS_LINE_TRANSMISSION_HEADER_ID = "," + ",LINE TRANSMISSION_HEADER_ID," + "LINE TRANSMISSION_HEADER_ID : " + db_CONS_LINE_TRANSMISSION_HEADER_ID + "," + "LINE TRANSMISSION_HEADER_ID was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(CONS_LINE_TRANSMISSION_HEADER_ID);
                                            } else {
                                                String CONS_LINE_TRANSMISSION_HEADER_ID = "," + ",LINE TRANSMISSION_HEADER_ID," + "LINE TRANSMISSION_HEADER_ID : " + db_CONS_LINE_TRANSMISSION_HEADER_ID + "," + "LINE TRANSMISSION_HEADER_ID was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(CONS_LINE_TRANSMISSION_HEADER_ID);
                                            }

                                            //RECORD_TYPE - mandatory validation
                                            if ((db_CONS_LINE_RECORD_TYPE == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String stg_VENDOR_SITE_ID = "," + ",LINE RECORD_TYPE," + "LINE RECORD_TYPE : " + db_CONS_LINE_RECORD_TYPE + "," + "LINE RECORD_TYPE was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(stg_VENDOR_SITE_ID);
                                            } else {
                                                String stg_VENDOR_SITE_ID = "," + ",LINE RECORD_TYPE," + "LINE RECORD_TYPE : " + db_CONS_LINE_RECORD_TYPE + "," + "LINE RECORD_TYPE was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(stg_VENDOR_SITE_ID);
                                            }


                                            //SOURCE_STATUS - mandatory validation
                                            if ((db_CONS_LINE_SOURCE_STATUS == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String stg_CATEGORY = "," + ",LINE SOURCE_STATUS," + "LINE SOURCE_STATUS : " + db_CONS_LINE_SOURCE_STATUS + "," + "LINE SOURCE_STATUS was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(stg_CATEGORY);
                                            } else {
                                                String stg_CATEGORY = "," + ",LINE SOURCE_STATUS," + "LINE SOURCE_STATUS : " + db_CONS_LINE_SOURCE_STATUS + "," + "LINE SOURCE_STATUS was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(stg_CATEGORY);
                                            }


                                            //DEPOSIT_DATE - mandatory validation
                                            if ((db_CONS_LINE_DEPOSIT_DATE == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String CONS_LINE_DEPOSIT_DATE = "," + ",LINE DEPOSIT_DATE," + "LINE DEPOSIT_DATE : " + db_CONS_LINE_DEPOSIT_DATE + "," + "LINE DEPOSIT_DATE was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(CONS_LINE_DEPOSIT_DATE);
                                            } else {
                                                String CONS_LINE_DEPOSIT_DATE = "," + ",LINE DEPOSIT_DATE," + "LINE DEPOSIT_DATE : " + db_CONS_LINE_DEPOSIT_DATE + "," + "LINE DEPOSIT_DATE was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(CONS_LINE_DEPOSIT_DATE);
                                            }

                                            //LOCKBOX_NUMBER - mandatory validation
                                            if ((db_CONS_LINE_LOCKBOX_NUMBER == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String CONS_LINE_LOCKBOX_NUMBER = "," + ",LINE LOCKBOX_NUMBER," + "LINE LOCKBOX_NUMBER : " + db_CONS_LINE_LOCKBOX_NUMBER + "," + "LINE LOCKBOX_NUMBER was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(CONS_LINE_LOCKBOX_NUMBER);
                                            } else {
                                                String CONS_LINE_LOCKBOX_NUMBER = "," + ",LINE LOCKBOX_NUMBER," + "LINE LOCKBOX_NUMBER : " + db_CONS_LINE_LOCKBOX_NUMBER + "," + "LINE LOCKBOX_NUMBER was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(CONS_LINE_LOCKBOX_NUMBER);
                                            }


                                            //BATCH_NAME - mandatory validation
                                            if ((db_CONS_LINE_BATCH_NAME == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String CONS_LINE_BATCH_NAME = "," + ",LINE BATCH_NAME," + "LINE BATCH_NAME : " + db_CONS_LINE_BATCH_NAME + "," + "LINE BATCH_NAME was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(CONS_LINE_BATCH_NAME);
                                            } else {
                                                String CONS_LINE_BATCH_NAME = "," + ",LINE BATCH_NAME," + "LINE BATCH_NAME : " + db_CONS_LINE_BATCH_NAME + "," + "LINE BATCH_NAME was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(CONS_LINE_BATCH_NAME);
                                            }


                                            //ITEM_NUMBER - mandatory validation
                                            if ((db_CONS_LINE_ITEM_NUMBER == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String CONS_LINE_ITEM_NUMBER = "," + ",LINE ITEM_NUMBER," + "LINE ITEM_NUMBER : " + db_CONS_LINE_ITEM_NUMBER + "," + "LINE ITEM_NUMBER was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(CONS_LINE_ITEM_NUMBER);
                                            } else {
                                                String CONS_LINE_ITEM_NUMBER = "," + ",LINE ITEM_NUMBER," + "LINE ITEM_NUMBER : " + db_CONS_LINE_ITEM_NUMBER + "," + "LINE ITEM_NUMBER was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(CONS_LINE_ITEM_NUMBER);
                                            }


                                            //CURRENCY_CODE - mandatory validation
                                            if ((db_CONS_LINE_CURRENCY_CODE == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String stg_LINE_ITEM_AMOUNT = "," + ",LINE CURRENCY_CODE," + "LINE CURRENCY_CODE : " + db_CONS_LINE_CURRENCY_CODE + "," + "LINE CURRENCY_CODE was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(stg_LINE_ITEM_AMOUNT);
                                            } else {
                                                String stg_LINE_ITEM_AMOUNT = "," + ",LINE CURRENCY_CODE," + "LINE CURRENCY_CODE : " + db_CONS_LINE_CURRENCY_CODE + "," + "LINE CURRENCY_CODE was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(stg_LINE_ITEM_AMOUNT);
                                            }

                                            //REMITTANCE_AMOUNT - mandatory validation
                                            if ((db_CONS_LINE_REMITTANCE_AMOUNT == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String CONS_LINE_REMITTANCE_AMOUNT = "," + ",LINE REMITTANCE_AMOUNT," + "LINE REMITTANCE_AMOUNT : " + db_CONS_LINE_REMITTANCE_AMOUNT + "," + "LINE REMITTANCE_AMOUNT was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(CONS_LINE_REMITTANCE_AMOUNT);
                                            } else {
                                                String CONS_LINE_REMITTANCE_AMOUNT = "," + ",LINE REMITTANCE_AMOUNT," + "LINE REMITTANCE_AMOUNT : " + db_CONS_LINE_REMITTANCE_AMOUNT + "," + "LINE REMITTANCE_AMOUNT was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(CONS_LINE_REMITTANCE_AMOUNT);
                                            }

                                            //CHECK_NUMBER - mandatory validation
                                            if ((db_CONS_LINE_CHECK_NUMBER == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String stg_CATEGORY = "," + ",LINE CHECK_NUMBER," + "LINE CHECK_NUMBER : " + db_CONS_LINE_CHECK_NUMBER + "," + "LINE CHECK_NUMBER was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(stg_CATEGORY);
                                            } else {
                                                String stg_CATEGORY = "," + ",LINE CHECK_NUMBER," + "LINE CHECK_NUMBER : " + db_CONS_LINE_CHECK_NUMBER + "," + "LINE CHECK_NUMBER was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(stg_CATEGORY);
                                            }

                                            //CUSTOMER_NUMBER - mandatory validation
                                            if ((db_CONS_LINE_CUSTOMER_NUMBER == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String CONS_LINE_CUSTOMER_NUMBER = "," + ",LINE CUSTOMER_NUMBER," + "LINE CUSTOMER_NUMBER : " + db_CONS_LINE_CUSTOMER_NUMBER + "," + "LINE CUSTOMER_NUMBER was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(CONS_LINE_CUSTOMER_NUMBER);
                                            } else {
                                                String CONS_LINE_CUSTOMER_NUMBER = "," + ",LINE CUSTOMER_NUMBER," + "LINE CUSTOMER_NUMBER : " + db_CONS_LINE_CUSTOMER_NUMBER + "," + "LINE CUSTOMER_NUMBER was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(CONS_LINE_CUSTOMER_NUMBER);
                                            }

                                            //RECEIPT_METHOD - mandatory validation
                                            if ((db_CONS_LINE_RECEIPT_METHOD == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String CONS_LINE_RECEIPT_METHOD = "," + ",LINE RECEIPT_METHOD," + "LINE RECEIPT_METHOD : " + db_CONS_LINE_RECEIPT_METHOD + "," + "LINE RECEIPT_METHOD was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(CONS_LINE_RECEIPT_METHOD);
                                            } else {
                                                String CONS_LINE_RECEIPT_METHOD = "," + ",LINE RECEIPT_METHOD," + "LINE RECEIPT_METHOD : " + db_CONS_LINE_RECEIPT_METHOD + "," + "LINE RECEIPT_METHOD was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(CONS_LINE_RECEIPT_METHOD);
                                            }

                                            //BILL_TO_LOCATION - mandatory validation
                                            if ((db_CONS_LINE_BILL_TO_LOCATION == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String CONS_LINE_BILL_TO_LOCATION = "," + ",LINE BILL_TO_LOCATION," + "LINE BILL_TO_LOCATION : " + db_CONS_LINE_BILL_TO_LOCATION + "," + "LINE BILL_TO_LOCATION was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(CONS_LINE_BILL_TO_LOCATION);
                                            } else {
                                                String CONS_LINE_BILL_TO_LOCATION = "," + ",LINE BILL_TO_LOCATION," + "LINE BILL_TO_LOCATION : " + db_CONS_LINE_BILL_TO_LOCATION + "," + "LINE BILL_TO_LOCATION was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(CONS_LINE_BILL_TO_LOCATION);
                                            }

                                            //RECEIPT_DATE - mandatory validation
                                            if ((db_CONS_LINE_RECEIPT_DATE == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String CONS_LINE_RECEIPT_DATE = "," + ",LINE RECEIPT_DATE," + "LINE RECEIPT_DATE : " + db_CONS_LINE_RECEIPT_DATE + "," + "LINE RECEIPT_DATE was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(CONS_LINE_RECEIPT_DATE);
                                            } else {
                                                String CONS_LINE_RECEIPT_DATE = "," + ",LINE RECEIPT_DATE," + "LINE RECEIPT_DATE : " + db_CONS_LINE_RECEIPT_DATE + "," + "LINE RECEIPT_DATE was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(CONS_LINE_RECEIPT_DATE);
                                            }

                                            //CUSTOMER_BANK_NAME - mandatory validation
                                            if ((db_CONS_LINE_CUSTOMER_BANK_NAME == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String CONS_LINE_CUSTOMER_BANK_NAME = "," + ",LINE CUSTOMER_BANK_NAME," + "LINE CUSTOMER_BANK_NAME : " + db_CONS_LINE_CUSTOMER_BANK_NAME + "," + "LINE CUSTOMER_BANK_NAME was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(CONS_LINE_CUSTOMER_BANK_NAME);
                                            } else {
                                                String CONS_LINE_CUSTOMER_BANK_NAME = "," + ",LINE CUSTOMER_BANK_NAME," + "LINE CUSTOMER_BANK_NAME : " + db_CONS_LINE_CUSTOMER_BANK_NAME + "," + "LINE CUSTOMER_BANK_NAME was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(CONS_LINE_CUSTOMER_BANK_NAME);
                                            }

                                            //CUSTOMER_BANK_BRANCH_NAME - mandatory validation
                                            if ((db_CONS_LINE_CUSTOMER_BANK_BRANCH_NAME == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String CONS_LINE_CUSTOMER_BANK_BRANCH_NAME = "," + ",LINE CUSTOMER_BANK_BRANCH_NAME," + "LINE CUSTOMER_BANK_BRANCH_NAME : " + db_CONS_LINE_CUSTOMER_BANK_BRANCH_NAME + "," + "LINE CUSTOMER_BANK_BRANCH_NAME was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(CONS_LINE_CUSTOMER_BANK_BRANCH_NAME);
                                            } else {
                                                String CONS_LINE_CUSTOMER_BANK_BRANCH_NAME = "," + ",LINE CUSTOMER_BANK_BRANCH_NAME," + "LINE CUSTOMER_BANK_BRANCH_NAME : " + db_CONS_LINE_CUSTOMER_BANK_BRANCH_NAME + "," + "LINE CUSTOMER_BANK_BRANCH_NAME was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(CONS_LINE_CUSTOMER_BANK_BRANCH_NAME);
                                            }

                                            //PROCESS_TYPE - mandatory validation
                                            if ((db_CONS_LINE_PROCESS_TYPE == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String CONS_LINE_PROCESS_TYPE = "," + ",LINE PROCESS_TYPE," + "LINE PROCESS_TYPE : " + db_CONS_LINE_PROCESS_TYPE + "," + "LINE PROCESS_TYPE was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(CONS_LINE_PROCESS_TYPE);
                                            } else {
                                                String CONS_LINE_PROCESS_TYPE = "," + ",LINE PROCESS_TYPE," + "LINE PROCESS_TYPE : " + db_CONS_LINE_PROCESS_TYPE + "," + "LINE PROCESS_TYPE was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(CONS_LINE_PROCESS_TYPE);
                                            }

                                            String tbl_line = stg_line_map_row + "." + stg_sub_indent;

                                            //------------- Validate Line TRANSMISSION_HEADER_ID ----------------
                                            if (db_STG_LINE_TRANSMISSION_HEADER_ID.equals(db_CONS_LINE_TRANSMISSION_HEADER_ID)) {
                                                String STG_LINE_TRANSMISSION_HEADER_ID = stg_line_map_row + "." + stg_sub_indent + ",LINE TRANSMISSION_HEADER_ID," + db_CONS_LINE_TRANSMISSION_HEADER_ID + "," + db_STG_LINE_TRANSMISSION_HEADER_ID + ",Pass";
                                                section1_results.add(STG_LINE_TRANSMISSION_HEADER_ID);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE TRANSMISSION_HEADER_ID" + "," + db_CONS_LINE_TRANSMISSION_HEADER_ID + "," + db_STG_LINE_TRANSMISSION_HEADER_ID + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                stg_sub_indent++;
                                            } else {
                                                String STG_LINE_TRANSMISSION_HEADER_ID = stg_line_map_row + "." + stg_sub_indent + ",LINE TRANSMISSION_HEADER_ID," + db_CONS_LINE_TRANSMISSION_HEADER_ID + "," + db_STG_LINE_TRANSMISSION_HEADER_ID + ",Fail";
                                                section1_results.add(STG_LINE_TRANSMISSION_HEADER_ID);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE TRANSMISSION_HEADER_ID" + "," + db_CONS_LINE_TRANSMISSION_HEADER_ID + "," + db_STG_LINE_TRANSMISSION_HEADER_ID + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                stg_sub_indent++;
                                                CONS_flag++;
                                            }

                                            //------------- Validate LINE TRANSMISSION_LINE_ID ----------------
                                            if (db_STG_LINE_TRANSMISSION_LINE_ID.equals(db_CONS_LINE_TRANSMISSION_LINE_ID)) {
                                                String STG_LINE_TRANSMISSION_LINE_ID = ",LINE TRANSMISSION_LINE_ID," + db_CONS_LINE_TRANSMISSION_LINE_ID + "," + db_STG_LINE_TRANSMISSION_LINE_ID + ",Pass";
                                                section1_results.add(STG_LINE_TRANSMISSION_LINE_ID);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE TRANSMISSION_LINE_ID" + "," + db_CONS_LINE_TRANSMISSION_LINE_ID + "," + db_STG_LINE_TRANSMISSION_LINE_ID + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String STG_LINE_TRANSMISSION_LINE_ID = ",LINE TRANSMISSION_LINE_ID," + db_CONS_LINE_TRANSMISSION_LINE_ID + "," + db_STG_LINE_TRANSMISSION_LINE_ID + ",Fail";
                                                section1_results.add(STG_LINE_TRANSMISSION_LINE_ID);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE TRANSMISSION_LINE_ID" + "," + db_CONS_LINE_TRANSMISSION_LINE_ID + "," + db_STG_LINE_TRANSMISSION_LINE_ID + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }

                                            //------------- Validate LINE TRANSMISSION_RECORD_ID ----------------
                                            if (db_STG_LINE_TRANSMISSION_RECORD_ID.equals(db_CONS_LINE_TRANSMISSION_RECORD_ID)) {
                                                String STG_LINE_TRANSMISSION_LINE_ID = ",LINE TRANSMISSION_RECORD_ID," + db_CONS_LINE_TRANSMISSION_RECORD_ID + "," + db_STG_LINE_TRANSMISSION_RECORD_ID + ",Pass";
                                                section1_results.add(STG_LINE_TRANSMISSION_LINE_ID);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE TRANSMISSION_RECORD_ID" + "," + db_CONS_LINE_TRANSMISSION_RECORD_ID + "," + db_STG_LINE_TRANSMISSION_RECORD_ID + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String STG_LINE_TRANSMISSION_LINE_ID = ",LINE TRANSMISSION_RECORD_ID," + db_CONS_LINE_TRANSMISSION_RECORD_ID + "," + db_STG_LINE_TRANSMISSION_RECORD_ID + ",Fail";
                                                section1_results.add(STG_LINE_TRANSMISSION_LINE_ID);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE TRANSMISSION_RECORD_ID" + "," + db_CONS_LINE_TRANSMISSION_RECORD_ID + "," + db_STG_LINE_TRANSMISSION_RECORD_ID + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }


                                            //--------------------  Validation SOURCE_STATUS ---------------
                                            if (db_CONS_LINE_SOURCE_STATUS.equals(db_STG_LINE_SOURCE_STATUS)) {
                                                String STG_LINE_SOURCE_STATUS = ",LINE SOURCE_STATUS," + db_CONS_LINE_SOURCE_STATUS + "," + db_STG_LINE_SOURCE_STATUS + ",Pass";
                                                section1_results.add(STG_LINE_SOURCE_STATUS);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SOURCE_STATUS" + "," + db_CONS_LINE_SOURCE_STATUS + "," + db_STG_LINE_SOURCE_STATUS + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String STG_LINE_SOURCE_STATUS = ",LINE SOURCE_STATUS," + db_CONS_LINE_SOURCE_STATUS + "," + db_STG_LINE_SOURCE_STATUS + ",Fail";
                                                section1_results.add(STG_LINE_SOURCE_STATUS);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SOURCE_STATUS" + "," + db_CONS_LINE_SOURCE_STATUS + "," + db_STG_LINE_SOURCE_STATUS + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }

                                            //--------------------  Validation LOCKBOX_NUMBER ---------------
                                            String db_CONS_LINE_LOCKBOX_NUMBERModified = db_CONS_LINE_LOCKBOX_NUMBER.trim();
                                            if (db_CONS_LINE_LOCKBOX_NUMBERModified.equals(db_STG_LINE_LOCKBOX_NUMBER)) {
                                                String STG_LOCKBOX_NUMBER = ",LINE LOCKBOX_NUMBER," + db_CONS_LINE_LOCKBOX_NUMBERModified + "," + db_STG_LINE_LOCKBOX_NUMBER + ",Pass";
                                                section1_results.add(STG_LOCKBOX_NUMBER);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE LOCKBOX_NUMBER" + "," + db_CONS_LINE_LOCKBOX_NUMBERModified + "," + db_STG_LINE_LOCKBOX_NUMBER + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String STG_LOCKBOX_NUMBER = ",LINE LOCKBOX_NUMBER," + db_CONS_LINE_LOCKBOX_NUMBERModified + "," + db_STG_LINE_LOCKBOX_NUMBER + ",Fail";
                                                section1_results.add(STG_LOCKBOX_NUMBER);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE LOCKBOX_NUMBER" + "," + db_CONS_LINE_LOCKBOX_NUMBERModified + "," + db_STG_LINE_LOCKBOX_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            }

                                            //------------- Validate BATCH_NAME ----------------
                                            if ((db_STG_LINE_BATCH_NAME != null) && (db_CONS_LINE_BATCH_NAME != null)) {
                                                if (db_STG_LINE_BATCH_NAME.equals(db_CONS_LINE_BATCH_NAME)) {
                                                    String STG_BATCH_NAME = ",LINE BATCH_NAME," + db_CONS_LINE_BATCH_NAME + "," + db_STG_LINE_BATCH_NAME + ",Pass";
                                                    section1_results.add(STG_BATCH_NAME);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE BATCH_NAME" + "," + db_CONS_LINE_BATCH_NAME + "," + db_STG_LINE_BATCH_NAME + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String STG_BATCH_NAME = ",LINE BATCH_NAME," + db_CONS_LINE_BATCH_NAME + "," + db_STG_LINE_BATCH_NAME + ",Fail";
                                                    section1_results.add(STG_BATCH_NAME);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE BATCH_NAME" + "," + db_CONS_LINE_BATCH_NAME + "," + db_STG_LINE_BATCH_NAME + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            } else {
                                                String STG_BATCH_NAME = ",LINE BATCH_NAME," + db_CONS_LINE_BATCH_NAME + "," + db_STG_LINE_BATCH_NAME + ",Pass";
                                                section1_results.add(STG_BATCH_NAME);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE TRANSMISSION_LINE_ID" + "," + db_CONS_LINE_TRANSMISSION_LINE_ID + "," + db_STG_LINE_TRANSMISSION_LINE_ID + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            }

                                            //--------------------  Validation ITEM_NUMBER ---------------
                                            if (db_CONS_LINE_ITEM_NUMBER.equals(db_STG_LINE_ITEM_NUMBER)) {
                                                String STG_ITEM_NUMBER = ",LINE ITEM_NUMBER," + db_CONS_LINE_ITEM_NUMBER + "," + db_STG_LINE_ITEM_NUMBER + ",Pass";
                                                section1_results.add(STG_ITEM_NUMBER);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE ITEM_NUMBER" + "," + db_CONS_LINE_ITEM_NUMBER + "," + db_STG_LINE_ITEM_NUMBER + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String STG_ITEM_NUMBER = ",LINE ITEM_NUMBER," + db_CONS_LINE_ITEM_NUMBER + "," + db_STG_LINE_ITEM_NUMBER + ",Fail";
                                                section1_results.add(STG_ITEM_NUMBER);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE ITEM_NUMBER" + "," + db_CONS_LINE_ITEM_NUMBER + "," + db_STG_LINE_ITEM_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }

                                            //--------------------  Validation CURRENCY_CODE ---------------
                                            if (db_CONS_LINE_CURRENCY_CODE.equals(db_STG_LINE_CURRENCY_CODE)) {
                                                String STG_CURRENCY_CODE = ",LINE CURRENCY_CODE," + db_CONS_LINE_CURRENCY_CODE + "," + db_STG_LINE_CURRENCY_CODE + ",Pass";
                                                section1_results.add(STG_CURRENCY_CODE);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE CURRENCY_CODE" + "," + db_CONS_LINE_CURRENCY_CODE + "," + db_STG_LINE_CURRENCY_CODE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String STG_CURRENCY_CODE = ",LINE CURRENCY_CODE," + db_CONS_LINE_CURRENCY_CODE + "," + db_STG_LINE_CURRENCY_CODE + ",Fail";
                                                section1_results.add(STG_CURRENCY_CODE);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE CURRENCY_CODE" + "," + db_CONS_LINE_CURRENCY_CODE + "," + db_STG_LINE_CURRENCY_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }

                                            //------------- Validate REMITTANCE_AMOUNT ----------------
                                            if ((db_STG_LINE_REMITTANCE_AMOUNT != null) && (db_CONS_LINE_REMITTANCE_AMOUNT != null)) {
                                                if (db_STG_LINE_REMITTANCE_AMOUNT.equals(db_CONS_LINE_REMITTANCE_AMOUNT)) {
                                                    String STG_REMITTANCE_AMOUNT = ",LINE REMITTANCE_AMOUNT," + db_CONS_LINE_REMITTANCE_AMOUNT + "," + db_STG_LINE_REMITTANCE_AMOUNT + ",Pass";
                                                    section1_results.add(STG_REMITTANCE_AMOUNT);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE REMITTANCE_AMOUNT" + "," + db_CONS_LINE_REMITTANCE_AMOUNT + "," + db_STG_LINE_REMITTANCE_AMOUNT + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String STG_REMITTANCE_AMOUNT = ",LINE REMITTANCE_AMOUNT," + db_CONS_LINE_REMITTANCE_AMOUNT + "," + db_STG_LINE_REMITTANCE_AMOUNT + ",Fail";
                                                    section1_results.add(STG_REMITTANCE_AMOUNT);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE REMITTANCE_AMOUNT" + "," + db_CONS_LINE_REMITTANCE_AMOUNT + "," + db_STG_LINE_REMITTANCE_AMOUNT + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            } else {
                                                String STG_REMITTANCE_AMOUNT = ",LINE REMITTANCE_AMOUNT," + db_CONS_LINE_REMITTANCE_AMOUNT + "," + db_STG_LINE_REMITTANCE_AMOUNT + ",Pass";
                                                section1_results.add(STG_REMITTANCE_AMOUNT);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE REMITTANCE_AMOUNT" + "," + db_CONS_LINE_REMITTANCE_AMOUNT + "," + db_STG_LINE_REMITTANCE_AMOUNT + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            }

                                            //--------------------  Validation CHECK_NUMBER ---------------
                                            if (db_CONS_LINE_CHECK_NUMBER.equals(db_STG_LINE_CHECK_NUMBER)) {
                                                String STG_LINE_SOURCE_STATUS = ",LINE CHECK_NUMBER," + db_CONS_LINE_CHECK_NUMBER + "," + db_STG_LINE_CHECK_NUMBER + ",Pass";
                                                section1_results.add(STG_LINE_SOURCE_STATUS);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE CHECK_NUMBER" + "," + db_CONS_LINE_CHECK_NUMBER + "," + db_STG_LINE_CHECK_NUMBER + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String STG_LINE_SOURCE_STATUS = ",LINE CHECK_NUMBER," + db_CONS_LINE_CHECK_NUMBER + "," + db_STG_LINE_CHECK_NUMBER + ",Fail";
                                                section1_results.add(STG_LINE_SOURCE_STATUS);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE CHECK_NUMBER" + "," + db_CONS_LINE_CHECK_NUMBER + "," + db_STG_LINE_CHECK_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }

                                            //--------------------  Validation CUSTOMER_NUMBER ---------------
                                            if (db_CONS_LINE_CUSTOMER_NUMBER.equals(db_STG_LINE_CUSTOMER_NUMBER)) {
                                                String STG_LINE_CUSTOMER_NUMBER = ",LINE CUSTOMER_NUMBER," + db_CONS_LINE_CUSTOMER_NUMBER + "," + db_STG_LINE_CUSTOMER_NUMBER + ",Pass";
                                                section1_results.add(STG_LINE_CUSTOMER_NUMBER);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE CUSTOMER_NUMBER" + "," + db_CONS_LINE_CUSTOMER_NUMBER + "," + db_STG_LINE_CUSTOMER_NUMBER + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String STG_LINE_CUSTOMER_NUMBER = ",LINE CUSTOMER_NUMBER," + db_CONS_LINE_CUSTOMER_NUMBER + "," + db_STG_LINE_CUSTOMER_NUMBER + ",Fail";
                                                section1_results.add(STG_LINE_CUSTOMER_NUMBER);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE CUSTOMER_NUMBER" + "," + db_CONS_LINE_CUSTOMER_NUMBER + "," + db_STG_LINE_CUSTOMER_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }

                                            //------------- Validate INVOICE1 ----------------
                                            if ((db_STG_LINE_INVOICE1 != null) && (db_CONS_LINE_INVOICE1 != null)) {
                                                if (db_STG_LINE_INVOICE1.equals(db_CONS_LINE_INVOICE1)) {
                                                    String STG_BATCH_NAME = ",LINE INVOICE1," + db_CONS_LINE_INVOICE1 + "," + db_STG_LINE_INVOICE1 + ",Pass";
                                                    section1_results.add(STG_BATCH_NAME);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE INVOICE1" + "," + db_CONS_LINE_INVOICE1 + "," + db_STG_LINE_INVOICE1 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String STG_BATCH_NAME = ",LINE INVOICE1," + db_CONS_LINE_INVOICE1 + "," + db_STG_LINE_INVOICE1 + ",Fail";
                                                    section1_results.add(STG_BATCH_NAME);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE INVOICE1" + "," + db_CONS_LINE_INVOICE1 + "," + db_STG_LINE_INVOICE1 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            } else {
                                                String STG_BATCH_NAME = ",LINE INVOICE1," + db_CONS_LINE_INVOICE1 + "," + db_STG_LINE_INVOICE1 + ",Pass";
                                                section1_results.add(STG_BATCH_NAME);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE INVOICE1" + "," + db_CONS_LINE_INVOICE1 + "," + db_STG_LINE_INVOICE1 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            }

                                            //--------------------  Validation RECEIPT_METHOD ---------------
                                            if (db_CONS_LINE_RECEIPT_METHOD.equals(db_STG_LINE_RECEIPT_METHOD)) {
                                                String STG_ITEM_NUMBER = ",LINE RECEIPT_METHOD," + db_CONS_LINE_RECEIPT_METHOD + "," + db_STG_LINE_RECEIPT_METHOD + ",Pass";
                                                section1_results.add(STG_ITEM_NUMBER);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE RECEIPT_METHOD" + "," + db_CONS_LINE_RECEIPT_METHOD + "," + db_STG_LINE_RECEIPT_METHOD + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String STG_ITEM_NUMBER = ",LINE RECEIPT_METHOD," + db_CONS_LINE_RECEIPT_METHOD + "," + db_STG_LINE_RECEIPT_METHOD + ",Fail";
                                                section1_results.add(STG_ITEM_NUMBER);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE RECEIPT_METHOD" + "," + db_CONS_LINE_RECEIPT_METHOD + "," + db_STG_LINE_RECEIPT_METHOD + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }

                                            //--------------------  Validation BILL_TO_LOCATION ---------------
                                            if (db_CONS_LINE_BILL_TO_LOCATION.equals(db_STG_LINE_BILL_TO_LOCATION)) {
                                                String STG_CURRENCY_CODE = ",LINE BILL_TO_LOCATION," + db_CONS_LINE_BILL_TO_LOCATION + "," + db_STG_LINE_BILL_TO_LOCATION + ",Pass";
                                                section1_results.add(STG_CURRENCY_CODE);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE BILL_TO_LOCATION" + "," + db_CONS_LINE_BILL_TO_LOCATION + "," + db_STG_LINE_BILL_TO_LOCATION + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String STG_CURRENCY_CODE = ",LINE BILL_TO_LOCATION," + db_CONS_LINE_BILL_TO_LOCATION + "," + db_STG_LINE_BILL_TO_LOCATION + ",Fail";
                                                section1_results.add(STG_CURRENCY_CODE);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE BILL_TO_LOCATION" + "," + db_CONS_LINE_BILL_TO_LOCATION + "," + db_STG_LINE_BILL_TO_LOCATION + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }

                                            //------------- Validate RECEIPT_DATE ----------------
                                            if ((db_STG_LINE_RECEIPT_DATE != null) && (db_CONS_LINE_RECEIPT_DATE != null)) {
                                                if (db_STG_LINE_RECEIPT_DATE.equals(db_CONS_LINE_RECEIPT_DATE)) {
                                                    String STG_REMITTANCE_AMOUNT = ",LINE RECEIPT_DATE," + db_CONS_LINE_RECEIPT_DATE + "," + db_STG_LINE_RECEIPT_DATE + ",Pass";
                                                    section1_results.add(STG_REMITTANCE_AMOUNT);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE RECEIPT_DATE" + "," + db_CONS_LINE_RECEIPT_DATE + "," + db_STG_LINE_RECEIPT_DATE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String STG_REMITTANCE_AMOUNT = ",LINE RECEIPT_DATE," + db_CONS_LINE_RECEIPT_DATE + "," + db_STG_LINE_RECEIPT_DATE + ",Fail";
                                                    section1_results.add(STG_REMITTANCE_AMOUNT);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE RECEIPT_DATE" + "," + db_CONS_LINE_RECEIPT_DATE + "," + db_STG_LINE_RECEIPT_DATE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            } else {
                                                String STG_REMITTANCE_AMOUNT = ",LINE RECEIPT_DATE," + db_CONS_LINE_RECEIPT_DATE + "," + db_STG_LINE_RECEIPT_DATE + ",Pass";
                                                section1_results.add(STG_REMITTANCE_AMOUNT);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE RECEIPT_DATE" + "," + db_CONS_LINE_RECEIPT_DATE + "," + db_STG_LINE_RECEIPT_DATE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            }

                                            //------------- Validate CUSTOMER_BANK_NAME ----------------
                                            if ((db_STG_LINE_CUSTOMER_BANK_NAME != null) && (db_CONS_LINE_CUSTOMER_BANK_NAME != null)) {
                                                if (db_STG_LINE_CUSTOMER_BANK_NAME.equals(db_CONS_LINE_CUSTOMER_BANK_NAME)) {
                                                    String STG_REMITTANCE_AMOUNT = ",LINE CUSTOMER_BANK_NAME," + db_CONS_LINE_CUSTOMER_BANK_NAME + "," + db_STG_LINE_CUSTOMER_BANK_NAME + ",Pass";
                                                    section1_results.add(STG_REMITTANCE_AMOUNT);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE CUSTOMER_BANK_NAME" + "," + db_CONS_LINE_CUSTOMER_BANK_NAME + "," + db_STG_LINE_CUSTOMER_BANK_NAME + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String STG_REMITTANCE_AMOUNT = ",LINE CUSTOMER_BANK_NAME," + db_CONS_LINE_CUSTOMER_BANK_NAME + "," + db_STG_LINE_CUSTOMER_BANK_NAME + ",Fail";
                                                    section1_results.add(STG_REMITTANCE_AMOUNT);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE CUSTOMER_BANK_NAME" + "," + db_CONS_LINE_CUSTOMER_BANK_NAME + "," + db_STG_LINE_CUSTOMER_BANK_NAME + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            } else {
                                                String STG_REMITTANCE_AMOUNT = ",LINE CUSTOMER_BANK_NAME," + db_CONS_LINE_CUSTOMER_BANK_NAME + "," + db_STG_LINE_CUSTOMER_BANK_NAME + ",Pass";
                                                section1_results.add(STG_REMITTANCE_AMOUNT);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE CUSTOMER_BANK_NAME" + "," + db_CONS_LINE_CUSTOMER_BANK_NAME + "," + db_STG_LINE_CUSTOMER_BANK_NAME + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            }

                                            //--------------------  Validation CUSTOMER_BANK_BRANCH_NAME ---------------
                                            if (db_CONS_LINE_CUSTOMER_BANK_BRANCH_NAME.equals(db_STG_LINE_CUSTOMER_BANK_BRANCH_NAME)) {
                                                String STG_LINE_SOURCE_STATUS = ",LINE CUSTOMER_BANK_BRANCH_NAME," + db_CONS_LINE_CUSTOMER_BANK_BRANCH_NAME + "," + db_STG_LINE_CUSTOMER_BANK_BRANCH_NAME + ",Pass";
                                                section1_results.add(STG_LINE_SOURCE_STATUS);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE CUSTOMER_BANK_BRANCH_NAME" + "," + db_CONS_LINE_CUSTOMER_BANK_BRANCH_NAME + "," + db_STG_LINE_CUSTOMER_BANK_BRANCH_NAME + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String STG_LINE_SOURCE_STATUS = ",LINE CUSTOMER_BANK_BRANCH_NAME," + db_CONS_LINE_CUSTOMER_BANK_BRANCH_NAME + "," + db_STG_LINE_CUSTOMER_BANK_BRANCH_NAME + ",Fail";
                                                section1_results.add(STG_LINE_SOURCE_STATUS);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE CUSTOMER_BANK_BRANCH_NAME" + "," + db_CONS_LINE_CUSTOMER_BANK_BRANCH_NAME + "," + db_STG_LINE_CUSTOMER_BANK_BRANCH_NAME + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }

                                            //--------------------  Validation PROCESS_TYPE ---------------
                                            if (db_CONS_LINE_PROCESS_TYPE.equals(db_STG_LINE_PROCESS_TYPE)) {
                                                String STG_LINE_CUSTOMER_NUMBER = ",LINE PROCESS_TYPE," + db_CONS_LINE_PROCESS_TYPE + "," + db_STG_LINE_PROCESS_TYPE + ",Pass";
                                                section1_results.add(STG_LINE_CUSTOMER_NUMBER);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE PROCESS_TYPE" + "," + db_CONS_LINE_PROCESS_TYPE + "," + db_STG_LINE_PROCESS_TYPE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String STG_LINE_CUSTOMER_NUMBER = ",LINE PROCESS_TYPE," + db_CONS_LINE_PROCESS_TYPE + "," + db_STG_LINE_PROCESS_TYPE + ",Fail";
                                                section1_results.add(STG_LINE_CUSTOMER_NUMBER);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE PROCESS_TYPE" + "," + db_CONS_LINE_PROCESS_TYPE + "," + db_STG_LINE_PROCESS_TYPE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }

                                            //------------- Validate PRINT_STS ----------------
                                            if ((db_STG_LINE_PRINT_STS != null) && (db_CONS_LINE_PRINT_STS != null)) {
                                                if (db_STG_LINE_PRINT_STS.equals(db_CONS_LINE_PRINT_STS)) {
                                                    String STG_BATCH_NAME = ",LINE PRINT_STS," + db_CONS_LINE_PRINT_STS + "," + db_STG_LINE_PRINT_STS + ",Pass";
                                                    section1_results.add(STG_BATCH_NAME);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE PRINT_STS" + "," + db_CONS_LINE_PRINT_STS + "," + db_STG_LINE_PRINT_STS + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String STG_BATCH_NAME = ",LINE PRINT_STS," + db_CONS_LINE_PRINT_STS + "," + db_STG_LINE_PRINT_STS + ",Fail";
                                                    section1_results.add(STG_BATCH_NAME);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE PRINT_STS" + "," + db_CONS_LINE_PRINT_STS + "," + db_STG_LINE_PRINT_STS + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            } else {
                                                String STG_BATCH_NAME = ",LINE PRINT_STS," + db_CONS_LINE_PRINT_STS + "," + db_STG_LINE_PRINT_STS + ",Pass";
                                                section1_results.add(STG_BATCH_NAME);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE PRINT_STS" + "," + db_CONS_LINE_PRINT_STS + "," + db_STG_LINE_PRINT_STS + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            }

                                            //--------------------  Validation ATTRIBUTE1 ---------------
                                            if ((db_CONS_LINE_ATTRIBUTE1 != null) && (db_STG_LINE_ATTRIBUTE1 != null)) {
                                                if (db_CONS_LINE_ATTRIBUTE1.equals(db_STG_LINE_ATTRIBUTE1)) {
                                                    String cons_claim_handler_ref = ",LINE ATTRIBUTE1," + db_CONS_LINE_ATTRIBUTE1 + "," + db_STG_LINE_ATTRIBUTE1 + ",Pass";
                                                    section1_results.add(cons_claim_handler_ref);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE ATTRIBUTE1" + "," + db_CONS_LINE_ATTRIBUTE1 + "," + db_STG_LINE_ATTRIBUTE1 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String cons_claim_handler_ref = ",LINE ATTRIBUTE1," + db_CONS_LINE_ATTRIBUTE1 + "," + db_STG_LINE_ATTRIBUTE1 + ",Fail";
                                                    section1_results.add(cons_claim_handler_ref);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE ATTRIBUTE1" + "," + db_CONS_LINE_ATTRIBUTE1 + "," + db_STG_LINE_ATTRIBUTE1 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            } else {
                                                String cons_claim_handler_ref = ",LINE ATTRIBUTE1," + db_CONS_LINE_ATTRIBUTE1 + "," + db_STG_LINE_ATTRIBUTE1 + ",Pass";
                                                section1_results.add(cons_claim_handler_ref);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE ATTRIBUTE1" + "," + db_CONS_LINE_ATTRIBUTE1 + "," + db_STG_LINE_ATTRIBUTE1 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            }

                                            //--------------------  Validation ATTRIBUTE2 ---------------
                                            if ((db_CONS_LINE_ATTRIBUTE2 != null) && (db_STG_LINE_ATTRIBUTE2 != null)) {
                                                if (db_CONS_LINE_ATTRIBUTE2.equals(db_STG_LINE_ATTRIBUTE2)) {
                                                    String cons_approver = ",LINE ATTRIBUTE2," + db_CONS_LINE_ATTRIBUTE2 + "," + db_STG_LINE_ATTRIBUTE2 + ",Pass";
                                                    section1_results.add(cons_approver);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE ATTRIBUTE2" + "," + db_CONS_LINE_ATTRIBUTE2 + "," + db_STG_LINE_ATTRIBUTE2 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String cons_approver = ",LINE ATTRIBUTE2," + db_CONS_LINE_ATTRIBUTE2 + "," + db_STG_LINE_ATTRIBUTE2 + ",Fail";
                                                    section1_results.add(cons_approver);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE ATTRIBUTE2" + "," + db_CONS_LINE_ATTRIBUTE2 + "," + db_STG_LINE_ATTRIBUTE2 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            } else {
                                                String cons_approver = ",LINE ATTRIBUTE2," + db_CONS_LINE_ATTRIBUTE2 + "," + db_STG_LINE_ATTRIBUTE2 + ",Pass";
                                                section1_results.add(cons_approver);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE ATTRIBUTE2" + "," + db_CONS_LINE_ATTRIBUTE2 + "," + db_STG_LINE_ATTRIBUTE2 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            }

                                            //--------------------  Validation ATTRIBUTE3 ---------------
                                            if ((db_CONS_LINE_ATTRIBUTE3 != null) && (db_STG_LINE_ATTRIBUTE3 != null)) {
                                                if (db_CONS_LINE_ATTRIBUTE3.equals(db_STG_LINE_ATTRIBUTE3)) {
                                                    String cons_account_number = ",LINE ATTRIBUTE3," + db_CONS_LINE_ATTRIBUTE3 + "," + db_STG_LINE_ATTRIBUTE3 + ",Pass";
                                                    section1_results.add(cons_account_number);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE ATTRIBUTE3" + "," + db_CONS_LINE_ATTRIBUTE3 + "," + db_STG_LINE_ATTRIBUTE3 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String cons_account_number = ",LINE ATTRIBUTE3," + db_CONS_LINE_ATTRIBUTE3 + "," + db_STG_LINE_ATTRIBUTE3 + ",Fail";
                                                    section1_results.add(cons_account_number);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE ATTRIBUTE3" + "," + db_CONS_LINE_ATTRIBUTE3 + "," + db_STG_LINE_ATTRIBUTE3 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            } else {
                                                String cons_account_number = ",LINE ATTRIBUTE3," + db_CONS_LINE_ATTRIBUTE3 + "," + db_STG_LINE_ATTRIBUTE3 + ",Pass";
                                                section1_results.add(cons_account_number);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE ATTRIBUTE3" + "," + db_CONS_LINE_ATTRIBUTE3 + "," + db_STG_LINE_ATTRIBUTE3 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            }


                                            //----------------------- LINE Reference table  -----------------------------
                                            String db_ref_line_CUSTOMER_NUMBER_meaning = "null";
                                            String db_ref_line_RECEIPT_METHOD_meaning = "null";
                                            String db_ref_line_BILL_TO_LOCATION_meaning = "null";

                                            String PulseARReceipts_fsh_refCust_accNumber = connect_db.executeQuery_DB("Reference", "ARReceipts_REF_CUST_ACCOUNT_NUMBER", "PULSE");
                                            String PulseARReceipts_fsh_refARLockbox_receiptName = connect_db.executeQuery_DB("Reference", "ARReceipts_REF_ARLOCKBOX_RECEIPT_NAME", "PULSE");
                                            String PulseARReceipts_fsh_refCust_location = connect_db.executeQuery_DB("Reference", "ARReceipts_REF_CUST_LOCATION", "PULSE");

                                            //------------------------------LINE_CUSTOMER_NUMBER-------------------------------
                                            String db_STG_LINE_CUSTOMER_NUMBERModified = db_STG_LINE_CUSTOMER_NUMBER.trim();
                                            String db_STG_LINE_BILL_TO_LOCATIONModified = db_STG_LINE_BILL_TO_LOCATION.trim();
                                            SQLResultset = SQLstmt.executeQuery(PulseARReceipts_fsh_refCust_accNumber + " WHERE ACCOUNT_NUMBER='" + db_STG_LINE_CUSTOMER_NUMBERModified + "' and LOCATION='" + db_STG_LINE_BILL_TO_LOCATIONModified + "'");
                                            //SQLResultset = SQLstmt.executeQuery("select ACCOUNT_NUMBER as accountNumber from DLG_FSH_REF_CUST where ACCOUNT_NUMBER='" + db_STG_LINE_CUSTOMER_NUMBERModified + "' and LOCATION='" + db_STG_LINE_BILL_TO_LOCATIONModified + "'");
                                            while (SQLResultset.next()) {
                                                db_ref_line_CUSTOMER_NUMBER_meaning = SQLResultset.getString("accountNumber");
                                            }
                                            if (db_ref_line_CUSTOMER_NUMBER_meaning.equals("null")) {
                                                String ref_DESTINATION_ACCOUNT_meaning = ",LINE_CUSTOMER_NUMBER Reference_Table," + "Transformation value not found" + "," + db_STG_LINE_CUSTOMER_NUMBERModified + ",Fail";
                                                section1_results.add(ref_DESTINATION_ACCOUNT_meaning);
                                                String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_CUSTOMER_NUMBER Reference_Table" + "," + "Transformation value not found" + "," + db_STG_LINE_CUSTOMER_NUMBERModified + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_line_pc_header_id);
                                                CONS_flag++;
                                            } else if (db_ref_line_CUSTOMER_NUMBER_meaning != null) {
                                                if (db_ref_line_CUSTOMER_NUMBER_meaning.equals(db_STG_LINE_CUSTOMER_NUMBERModified)) {
                                                    String ref_DESTINATION_ACCOUNT_meaning = ",LINE_CUSTOMER_NUMBER Reference_Table," + db_ref_line_CUSTOMER_NUMBER_meaning + "," + db_STG_LINE_CUSTOMER_NUMBERModified + ",Pass";
                                                    section1_results.add(ref_DESTINATION_ACCOUNT_meaning);
                                                    String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_CUSTOMER_NUMBER Reference_Table" + "," + db_ref_line_CUSTOMER_NUMBER_meaning + "," + db_STG_LINE_CUSTOMER_NUMBERModified + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_line_pc_header_id);
                                                } else {
                                                    String ref_DESTINATION_ACCOUNT_meaning = ",LINE_CUSTOMER_NUMBER Reference_Table," + db_ref_line_CUSTOMER_NUMBER_meaning + "," + db_STG_LINE_CUSTOMER_NUMBERModified + ",Fail";
                                                    section1_results.add(ref_DESTINATION_ACCOUNT_meaning);
                                                    String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_CUSTOMER_NUMBER Reference_Table" + "," + db_ref_line_CUSTOMER_NUMBER_meaning + "," + db_STG_LINE_CUSTOMER_NUMBERModified + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_line_pc_header_id);
                                                    CONS_flag++;
                                                }
                                            }

                                            //------------------------------LINE_RECEIPT_METHOD-------------------------------


                                            String db_STG_LINE_RECEIPT_METHODModified = db_STG_LINE_RECEIPT_METHOD.trim();
                                            SQLResultset = SQLstmt.executeQuery(PulseARReceipts_fsh_refARLockbox_receiptName + " WHERE RECEIPT_METHOD_NAME='" + db_STG_LINE_RECEIPT_METHODModified + "'");
                                            //SQLResultset = SQLstmt.executeQuery("select RECEIPT_METHOD_NAME as receiptMethod from DLG_FSH_REF_AR_LOCKBOX where RECEIPT_METHOD_NAME='" + db_STG_LINE_RECEIPT_METHODModified + "'");
                                            while (SQLResultset.next()) {
                                                db_ref_line_RECEIPT_METHOD_meaning = SQLResultset.getString("receiptMethod");
                                                System.out.println(db_ref_line_RECEIPT_METHOD_meaning);
                                            }
                                            if (db_ref_line_RECEIPT_METHOD_meaning.equals("null")) {
                                                String ref_DESTINATION_ACCOUNT_meaning = ",LINE_RECEIPT_METHOD Reference_Table," + "Transformation value not found" + "," + db_STG_LINE_RECEIPT_METHODModified + ",Fail";
                                                section1_results.add(ref_DESTINATION_ACCOUNT_meaning);
                                                String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_RECEIPT_METHOD Reference_Table" + "," + "Transformation value not found" + "," + db_STG_LINE_RECEIPT_METHODModified + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_line_pc_header_id);
                                                CONS_flag++;
                                            } else if (db_ref_line_RECEIPT_METHOD_meaning != null) {
                                                if (db_ref_line_RECEIPT_METHOD_meaning.equals(db_STG_LINE_RECEIPT_METHODModified)) {
                                                    String ref_DESTINATION_ACCOUNT_meaning = ",LINE_RECEIPT_METHOD Reference_Table," + db_ref_line_RECEIPT_METHOD_meaning + "," + db_STG_LINE_RECEIPT_METHODModified + ",Pass";
                                                    section1_results.add(ref_DESTINATION_ACCOUNT_meaning);
                                                    String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_RECEIPT_METHOD Reference_Table" + "," + db_ref_line_RECEIPT_METHOD_meaning + "," + db_STG_LINE_RECEIPT_METHODModified + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_line_pc_header_id);
                                                } else {
                                                    String ref_DESTINATION_ACCOUNT_meaning = ",LINE_RECEIPT_METHOD Reference_Table," + db_ref_line_RECEIPT_METHOD_meaning + "," + db_STG_LINE_RECEIPT_METHODModified + ",Fail";
                                                    section1_results.add(ref_DESTINATION_ACCOUNT_meaning);
                                                    String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_RECEIPT_METHOD Reference_Table" + "," + db_ref_line_RECEIPT_METHOD_meaning + "," + db_STG_LINE_RECEIPT_METHODModified + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_line_pc_header_id);
                                                    CONS_flag++;
                                                }
                                            }


                                            //------------------------------LINE_BILL_TO_LOCATION-------------------------------
                                            String db_STG_LINE_CUSTOMER_NUMBERTransform = db_STG_LINE_CUSTOMER_NUMBER.trim();
                                            String db_STG_LINE_BILL_TO_LOCATIONTransform = db_STG_LINE_BILL_TO_LOCATION.trim();

                                            SQLResultset = SQLstmt.executeQuery(PulseARReceipts_fsh_refCust_location + " WHERE ACCOUNT_NUMBER='" + db_STG_LINE_CUSTOMER_NUMBERTransform + "' and LOCATION='" + db_STG_LINE_BILL_TO_LOCATIONTransform + "'");
                                            //SQLResultset = SQLstmt.executeQuery("select LOCATION as location from DLG_FSH_REF_CUST where ACCOUNT_NUMBER='" + db_STG_LINE_CUSTOMER_NUMBERTransform + "' and LOCATION='" + db_STG_LINE_BILL_TO_LOCATIONTransform + "'");
                                            while (SQLResultset.next()) {
                                                db_ref_line_BILL_TO_LOCATION_meaning = SQLResultset.getString("location");
                                            }
                                            if (db_ref_line_BILL_TO_LOCATION_meaning.equals("null")) {
                                                String ref_DESTINATION_ACCOUNT_meaning = ",LINE_BILL_TO_LOCATION Reference_Table," + "Transformation value not found" + "," + db_STG_LINE_BILL_TO_LOCATIONTransform + ",Fail";
                                                section1_results.add(ref_DESTINATION_ACCOUNT_meaning);
                                                String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_BILL_TO_LOCATION Reference_Table" + "," + "Transformation value not found" + "," + db_STG_LINE_BILL_TO_LOCATIONTransform + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_line_pc_header_id);
                                                CONS_flag++;
                                            } else if (db_ref_line_BILL_TO_LOCATION_meaning != null) {
                                                if (db_ref_line_BILL_TO_LOCATION_meaning.equals(db_STG_LINE_BILL_TO_LOCATIONTransform)) {
                                                    String ref_DESTINATION_ACCOUNT_meaning = ",LINE_BILL_TO_LOCATION Reference_Table," + db_ref_line_BILL_TO_LOCATION_meaning + "," + db_STG_LINE_BILL_TO_LOCATIONTransform + ",Pass";
                                                    section1_results.add(ref_DESTINATION_ACCOUNT_meaning);
                                                    String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_BILL_TO_LOCATION Reference_Table" + "," + db_ref_line_BILL_TO_LOCATION_meaning + "," + db_STG_LINE_BILL_TO_LOCATIONTransform + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_line_pc_header_id);
                                                } else {
                                                    String ref_DESTINATION_ACCOUNT_meaning = ",LINE_BILL_TO_LOCATION Reference_Table," + db_ref_line_BILL_TO_LOCATION_meaning + "," + db_STG_LINE_BILL_TO_LOCATIONTransform + ",Fail";
                                                    section1_results.add(ref_DESTINATION_ACCOUNT_meaning);
                                                    String tbl_line_pc_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_BILL_TO_LOCATION Reference_Table" + "," + db_ref_line_BILL_TO_LOCATION_meaning + "," + db_STG_LINE_BILL_TO_LOCATIONTransform + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_line_pc_header_id);
                                                    CONS_flag++;
                                                }
                                            }


                                        }


                                    }

                                }


                            }

                        }
                    }
                }

                //----------------- Validate the Over all Status -------------------
                System.out.println("Looping ++  CONS_flag " + CONS_flag);
                String Overall_status = null;
                String Overall_stg_status = null;
                if (CONS_flag > 0) {
                    CONS_STATUS.add("Fail");
                    Overall_status = "Fail";
                } else {
                    CONS_STATUS.add("Pass");
                    Overall_status = "Pass";
                }


                if (CONS_flag > 0) {
                    OverAllStatus.add("Fail");
                } else {
                    OverAllStatus.add("Pass");
                }

                String tbl_summary_filelist = Source + "," + pattern + "," + file_name + "," + "CONS TO STG " + "," + load_date + "," + OverAllStatus + "," + btc_BATCH_PKEY;
                //String tbl_summary_filelist = Source + "," + pattern + "," + file_name + "," + load_dateFormat + "," + "CONST TO STG " + "," + OverAllStatus;
                summary_results_tbl.add(tbl_summary_filelist);

                list.addAll(section1_results);
                list.addAll(section2_results);

                // ---------------- HTML Report generation ------------------------
                report_generation.report_Test1(section1_results, "Header", xml_file_name, "CONSOLIDATION LAYER - STAGING LAYER", "PULSE_AR_Receipts", "PULSE_AR_Receipts CONSOLIDATION LAYER - STAGING LAYER", "");
                report_generation.report_Test1(section1_results, "Section2", xml_file_name, "CONSOLIDATION LAYER - STAGING LAYER", "PULSE_AR_Receipts", "PULSE_AR_Receipts CONSOLIDATION LAYER - STAGING LAYER", "");
                report_generation.report_Test1(section2_results, "Mandatory", xml_file_name, "Mandatory Check", "PULSE_AR_Receipts", "PULSE_AR_Receipts CONSOLIDATION LAYER - STAGING LAYER", "");

                table_detail_report.detail_report_tbl(section2_results_tbl);
            }
            state_model.section_method(file_list, CONS_STATUS, "N/A", OverAllStatus, "PULSE_ARReceipts_Summary");
            table_summary_report.summary_report_tbl(summary_results_tbl);
        }


    }

}