package Dashboard_Report;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class HTML_Report_Generation_State_Model_Jenkins {

    public int sec1_pass_count = 0;
    public int sec1_fail_count = 0;
    public int sec2_pass_count = 0;
    public int sec2_fail_count = 0;
    public int sec3_pass_count = 0;
    public int sec3_fail_count = 0;

    public void clean_report_summary(String report_name) throws IOException{

        String Html_teport_name = "C:\\Test\\EVO_Automation\\Results\\"+report_name +"."+"html";
        System.out.println("Report name --" +report_name);
        //File file =  new File("APINVOICE_Report_Summary.html");
        File file =  new File(report_name);
        file.delete();
    }

    public void report_Summary(List list, String section, String file_name, String section_name, String report_name, String header_name, String overAllStatus) throws IOException {

        String Html_teport_name = "C:\\Test\\EVO_Automation\\Results\\"+report_name +"."+"html";
        //String Html_teport_name = report_name +"."+"html";
        File file = new File(Html_teport_name);
        //File file = new File("APINVOICE_Report_Summary.html");
        if (file.createNewFile()) {
            System.out.println("File not available and created now");
        } else {
            System.out.println("File already created");
        }

        //-------------- Time stamp for printing in report  ----------------
        DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("yyyy_MM_dd HH:mm:ss");
        LocalDateTime now1 = LocalDateTime.now();
        String CurrentSystemDate = dtf1.format(now1);

        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(file, true));

        if (section.equals("Section1")) {
            bufferedWriter.append("<!DOCTYPE html>" +
                    "<html>" +
                    "<head> <meta charset='UTF-8'>" +
                    "<body> <table id='header'>" +
                    " <thead> \n" +
                    "\t\t\t\t <tr class='heading'> \n" +
                    "\t\t\t\t\t <th colspan='4' style='font-family:Copperplate Gothic Bold; font-size:1.2em;'> \n" +
                    "\t\t\t\t\t\t </th><th align = \"center\"> " + header_name + " \n <br><br>" +
                    "\t\t\t\t\t </th> \n" +
                    "\t\t\t\t </tr> " +
                    "\t\t\t\t\t <tr class='subheading' align =\"center\"> \n" +
                    "\t\t\t\t\t <th>&nbsp;Date&nbsp;&&nbsp;Time</th> \n" +
                    "\t\t\t\t\t <th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;" + CurrentSystemDate + "</th> \n" +
                    "\t\t\t\t </tr> " +
                    "\t\t\t\t <tr class='subheading'>" +
                    "\t\t\t\t <th >&nbsp;File&nbsp;Name</th>" +
//                    "\t\t\t\t\t <th>&nbsp;:" + file_name + "</th> \n" +
                    "\t\t\t\t </tr> \n" +
                    "\t\t\t\t </tr></thead></table>");

            bufferedWriter.append("<table id= '1'  border=\"1\" cellspacing=\"2\" cellpadding=\"1\" style=\"width:90%\">" +
                    "<th width=\"20%\" align =\"left\">SECTION - 1 \n </th>" +
                    "<th > " + section_name + " \n </th> </table>" +
                    "<table border=\"2\" cellspacing=\"0\" cellpadding=\"4\" style=\"width:90%\">" +
                    "<tr>" +
                    "<th width=\"15%\" border=\"2\" >S.No</th>" +
                    "<th width=\"40%\" border=\"2\" >File Name</th>" +
                    "<th width=\"15%\" border=\"2\" >CONS to STG STATUS</th>" +
                    "<th width=\"15%\" border=\"2\" >STG to TO STATUS</th>" +
                    "<th width=\"15%\" border=\"2\">Over All Test Status</th>" +
                    "</tr>");
            for (int i = 0; i < list.size(); i++) {
                String exp_result1 = (String) list.get(i);
                System.out.println("List----" + exp_result1);
                String[] exp_result = exp_result1.split(",");
                bufferedWriter.append("<tr>");
                for (int j = 0; j < exp_result.length; j++) {
                    System.out.println(exp_result[j]);
                    /*if (exp_result[j].equals("Pass")) {
                        sec1_pass_count++;
                    } else if (exp_result[j].equals("Fail")) {
                        sec1_fail_count++;
                    }*/
                    if ((j == exp_result.length - 1) && exp_result[j].equals("Fail")) {
                        bufferedWriter.append("<td align=\"center\" bgcolor = \"#FF0000\">" + exp_result[j] + "</td> ");
                        sec1_fail_count++;
                    } else if (((j == exp_result.length - 1) && exp_result[j].equals("Pass"))) {
                        bufferedWriter.append("<td align=\"center\" bgcolor = \"#00FF00\">" + exp_result[j] + "</td> ");
                        sec1_pass_count++;
                    } else if ((j == exp_result.length - 1) && ((!exp_result[j].equals("Fail")) || (!exp_result[j].equals("Pass")))) {
                        bufferedWriter.append("<td width=\"20%\" align=\"left\" bgcolor = \"#0080FF\" >" + exp_result[j] + "</td> ");
                        sec1_fail_count++;
                    } else {
                        bufferedWriter.append("<td align=\"center\" >" + exp_result[j] + "</td> ");
                    }
                }
                bufferedWriter.append("</tr>");

            }
            //bufferedWriter.append("</tr><td style=\"font-weight:bold\" align=\"center\" font color = \"bold\" >Total No of File:" + list.size() + "</td><td></td><td style=\"font-weight:bold\" align=\"center\" > Total Pass :" + sec1_pass_count + "</td><td style=\"font-weight:bold\" align=\"center\"> Total Fail: " + sec1_fail_count + "</td> <td>" + overAllStatus + "</td>");
            if(overAllStatus.equalsIgnoreCase("Fail")){
                bufferedWriter.append("</tr><td style=\"font-weight:bold\" align=\"center\" font color = \"bold\" >Total Verification:"+list.size()+"</td><td></td><td style=\"font-weight:bold\" align=\"center\" > Total Pass :"+sec1_pass_count +"</td><td style=\"font-weight:bold\" align=\"center\"> Total Fail: "+sec1_fail_count+"</td> <td style=\"font-weight:bold\" align=\"center\" bgcolor = \"#FF0001\">" + overAllStatus + "</td>");
            }else{
                bufferedWriter.append("</tr><td style=\"font-weight:bold\" align=\"center\" font color = \"bold\" >Total Verification:"+list.size()+"</td><td></td><td style=\"font-weight:bold\" align=\"center\" > Total Pass :"+sec1_pass_count +"</td><td style=\"font-weight:bold\" align=\"center\"> Total Fail: "+sec1_fail_count+"</td> <td style=\"font-weight:bold\" align=\"center\" bgcolor = \"#00FF00\">" + overAllStatus + "</td>");
            }
            bufferedWriter.append("</table> </body> </html>");
            bufferedWriter.append("<br><br><br>");
            sec1_pass_count = 0;
            sec1_fail_count = 0;
        }
        bufferedWriter.append("</table> </body> </html>");
        bufferedWriter.close();
    }

}
