package Dashboard_Report;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;


public class HTML_Report_Generation_DB_EVO {

    public int sec1_pass_count = 0;
    public int sec1_fail_count = 0;
    public int sec2_pass_count = 0;
    public int sec2_fail_count = 0;
    public int sec3_pass_count = 0;
    public int sec3_fail_count = 0;

    public void clean_report(String report_name) throws IOException{

        String Html_teport_name = report_name +"."+"html";
        Path path = Paths.get("C:\\Test\\EVO_Automation\\Results");
        System.out.println("Report name --" +report_name);
        //File file =  new File("APINVOICE_Report_Summary.html");
        System.out.println("File Path ------>" + path+"\\"+report_name);

        File file =  new File(path+"\\"+report_name);
        file.delete();
    }

    public void report_Test1(List list, String section, String file_name, String section_name, String report_name, String header_name, String overAllStatus) throws IOException {

        //-------------- Time stamp for printing in report file name ----------------
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy_MM_dd_HH_mm");
        LocalDateTime now = LocalDateTime.now();
        String CurrentDate = dtf.format(now);



        //----------------- Creating Report directory ---------------
        Path path = Paths.get("C:\\Test\\EVO_Automation\\Results");
        if (!Files.exists(path)) {
            try {
                Files.createDirectories(path);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        String Html_teport_name = report_name +"."+"html";
        File file =  new File(path+"\\" + Html_teport_name);
        //File file =  new File(path+"\\" + report_name + "_Report_" + CurrentDate+".html");
        if(file.createNewFile()){
            System.out.println("File not available and created now");
        }else{
            System.out.println("File already created");
        }

        //-------------- Time stamp for printing in report  ----------------
        DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("yyyy_MM_dd HH:mm:ss");
        LocalDateTime now1 = LocalDateTime.now();
        String CurrentSystemDate = dtf1.format(now1);

        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(file,true));

        if(section.equals("Header")) {
            bufferedWriter.append("<!DOCTYPE html>" +
                    "<html>" +
                    "<head> <meta charset='UTF-8'>" +
                    "<body> <table id='header'>" +
                    " <thead> \n" +
                    "\t\t\t\t <tr class='heading'> \n" +
                    "\t\t\t\t\t <th colspan='4' style='font-family:Copperplate Gothic Bold; font-size:1.2em;'> \n" +
                    "\t\t\t\t\t\t </th><th align = \"center\"> " + header_name + " \n <br><br>" +
                    "\t\t\t\t\t </th> \n" +
                    "\t\t\t\t </tr> " +
                    "\t\t\t\t\t <tr class='subheading' align =\"center\"> \n" +
                    "\t\t\t\t\t <th>&nbsp;Date&nbsp;&&nbsp;Time</th> \n" +
                    "\t\t\t\t\t <th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;" + CurrentSystemDate + "</th> \n" +
                    "\t\t\t\t </tr> " +
                    "\t\t\t\t <tr class='subheading'>" +
                    "\t\t\t\t <th >&nbsp;File&nbsp;Name</th>" +
                    "\t\t\t\t\t <th>&nbsp;:" + file_name + "</th> \n" +
                    "\t\t\t\t </tr> \n" +
                    "\t\t\t\t </tr></thead></table>");
        }
        if(section.equals("Section1")){


                bufferedWriter.append("<table id= '1'  border=\"1\" cellspacing=\"2\" cellpadding=\"1\" style=\"width:90%\">" +
                        "<th width=\"20%\" align =\"left\">SECTION - 1 \n </th>" +
                        "<th > "+section_name+ " \n </th> </table>" +
                        "<table border=\"2\" cellspacing=\"0\" cellpadding=\"4\" style=\"width:90%\">" +
                        "<tr>" +
                        "<th width=\"15%\" border=\"2\" >S.No</th>" +
                        "<th width=\"40%\" border=\"2\" >File Name</th>" +
                        "<th width=\"15%\" border=\"2\" >CONS to STG STATUS</th>" +
                        "<th width=\"15%\" border=\"2\" >STG to TO STATUS</th>" +
                        "<th width=\"15%\" border=\"2\">Over All Test Status</th>" +
                        "</tr>");
                for (int i = 0; i < list.size(); i++) {
                    String exp_result1 = (String) list.get(i);
                    System.out.println("List----" + exp_result1);
                    String[] exp_result = exp_result1.split(",");
                    bufferedWriter.append("<tr>");
                    for (int j = 0; j < exp_result.length; j++) {
                        System.out.println(exp_result[j]);
                        if (exp_result[j].equals("Pass")) {
                            sec1_pass_count++;
                        } else if (exp_result[j].equals("Fail")) {
                            sec1_fail_count++;
                        }

                        if ((j == exp_result.length - 1) && exp_result[j].equals("Fail")) {

                            bufferedWriter.append("<td align=\"center\" bgcolor = \"#FF0000\">" + exp_result[j] + "</td> ");
                        } else if (((j == exp_result.length - 1) && exp_result[j].equals("Pass"))) {
                            bufferedWriter.append("<td align=\"center\" bgcolor = \"#00FF00\">" + exp_result[j] + "</td> ");
                        }else if((j == exp_result.length - 1) && ((!exp_result[j].equals("Fail")) || (!exp_result[j].equals("Pass")))){
                            j = 2;
                            bufferedWriter.append("<td width=\"20%\" align=\"left\" bgcolor = \"#0080FF\" >" + exp_result[j] + "</td> ");
                        } else {
                            bufferedWriter.append("<td align=\"center\" >" + exp_result[j] + "</td> ");
                        }
                    }
                    bufferedWriter.append("</tr>");

                }
                if(overAllStatus.equalsIgnoreCase("Fail")){
                    bufferedWriter.append("</tr><td style=\"font-weight:bold\" align=\"center\" font color = \"bold\" >Total File:"+list.size()+"</td><td></td><td> </td><td></td> <td style=\"font-weight:bold\" align=\"center\" bgcolor = \"#FF0001\">" + overAllStatus + "</td>");
                }else {
                    bufferedWriter.append("</tr><td style=\"font-weight:bold\" align=\"center\" font color = \"bold\" >Total File:"+list.size()+"</td><td></td><td style=\"font-weight:bold\" align=\"center\" > Total Pass :"+sec1_pass_count +"</td><td style=\"font-weight:bold\" align=\"center\"> Total Fail: "+sec1_fail_count+"</td> <td style=\"font-weight:bold\" align=\"center\" bgcolor = \"#00FF00\">" + overAllStatus + "</td>");
                }
                //bufferedWriter.append("</tr><td style=\"font-weight:bold\" align=\"center\" font color = \"bold\" >Total No of File:" + list.size() + "</td><td></td><td style=\"font-weight:bold\" align=\"center\" > Total Pass :" + sec1_pass_count + "</td><td style=\"font-weight:bold\" align=\"center\"> Total Fail: " + sec1_fail_count + "</td> <td>" + overAllStatus + "</td>" );
                bufferedWriter.append("</table> </body> </html>");
                bufferedWriter.append("<br><br><br>");
                sec1_pass_count = 0;
                sec1_fail_count = 0;
                overAllStatus = "null";
            }

                if(section.equals("Section2")){
                    bufferedWriter.append("<html><table id = '2' border=\"1\" cellspacing=\"2\" cellpadding=\"1\" style=\"width:90%\">" +
                            "<th width=\"15%\" align =\"left\">SECTION - 2 \n "+file_name+" </th>"+
                            "<th > " +section_name+" \n </th> </table>"+
                            "<table id = '2' border=\"2\" cellspacing=\"0\" cellpadding=\"4\" style=\"width:90%\">" +
                            "<tr>" +
                            "<th width=\"15%\" border=\"2\" >S.No</th>" +
                            "<th width=\"25%\" border=\"2\" >File vs DB column</th>" +
                            "<th width=\"25%\" border=\"2\" >Actual Value in DB</th>" +
                            "<th width=\"20%\" border=\"2\">Expected Test Value</th>" +
                            "<th width=\"15%\" border=\"2\">Test Status</th>" +
                            "</tr>");
                    for (int s = 0; s < list.size(); s++) {
                        String exp_result1 = (String) list.get(s);
                        System.out.println("List----" + exp_result1);
                        String[] exp_result = exp_result1.split(",");
                        bufferedWriter.append("<tr>");
                        for (int t = 0; t < exp_result.length; t++) {
                            System.out.println(exp_result[t]);
                            if(exp_result[t].equals("Pass")){
                                sec2_pass_count++;
                            }else if(exp_result[t].equals("Fail")){
                                sec2_fail_count++;
                            }
                            if((t == exp_result.length-1 ) && exp_result[t].equals("Fail")) {
                                bufferedWriter.append("<td align=\"center\" bgcolor = \"#FF0000\">" + exp_result[t] + "</td> ");
                            }else if(((t == exp_result.length-1 ) && exp_result[t].equals("Pass"))) {
                                bufferedWriter.append("<td align=\"center\" bgcolor = \"#00FF00\">" + exp_result[t] + "</td> ");
                            }else{
                                bufferedWriter.append("<td align=\"center\" >" + exp_result[t] + "</td> ");
                            }
                        }
                        bufferedWriter.append("</tr>");

                    }
                    if(overAllStatus.equalsIgnoreCase("Fail")){
                        bufferedWriter.append("</tr><td style=\"font-weight:bold\" align=\"center\" font color = \"bold\" >Total Verification:"+list.size()+"</td><td></td><td style=\"font-weight:bold\" align=\"center\" > Total Pass :"+sec2_pass_count +"</td><td style=\"font-weight:bold\" align=\"center\"> Total Fail: "+sec2_fail_count+"</td> <td style=\"font-weight:bold\" align=\"center\" bgcolor = \"#FF0001\">" + overAllStatus + "</td>");
                    }else {
                        bufferedWriter.append("</tr><td style=\"font-weight:bold\" align=\"center\" font color = \"bold\" >Total Verification:"+list.size()+"</td><td></td><td style=\"font-weight:bold\" align=\"center\" > Total Pass :"+sec2_pass_count +"</td><td style=\"font-weight:bold\" align=\"center\"> Total Fail: "+sec2_fail_count+"</td> <td style=\"font-weight:bold\" align=\"center\" bgcolor = \"#00FF00\">" + overAllStatus + "</td>");
                    }
                    //bufferedWriter.append("</tr><td style=\"font-weight:bold\" align=\"center\" font color = \"bold\" >Total Verification:"+list.size()+"</td><td></td><td style=\"font-weight:bold\" align=\"center\" > Total Pass :"+sec2_pass_count +"</td><td style=\"font-weight:bold\" align=\"center\"> Total Fail: "+sec2_fail_count+"</td> <td style=\"font-weight:bold\" align=\"center\" bgcolor = \"#FF0001\">" + overAllStatus + "</td>");
                    bufferedWriter.append("</table> </body> </html>");
                    bufferedWriter.append("<br><br><br>");
                    sec2_pass_count = 0;
                    sec2_fail_count = 0;
                    overAllStatus = "null";
                }

        if(section.equals("Section3")){
            bufferedWriter.append("<html><table id = '3' border=\"1\" cellspacing=\"2\" cellpadding=\"1\" style=\"width:90%\">" +
                    "<th width=\"20%\" align =\"left\">SECTION - 3 \n </th>"+
                    "<th align =\"center\">"+section_name+" \n </th> </table>"+
                    "<table id = '2' border=\"2\" cellspacing=\"0\" cellpadding=\"4\" style=\"width:90%\">" +
                    "<tr>" +
                    "<th width=\"15%\" border=\"2\" >S.No</th>" +
                    "<th width=\"25%\" border=\"2\" >No of Records HDR Records in File</th>" +
                    "<th width=\"25%\"border=\"2\" >Actual - Summarized Record in DB</th>" +
                    "<th width=\"20%\" border=\"2\">Expected - Summarized Records</th>" +
                    "<th width=\"15%\" border=\"2\">Test Status</th>" +
                    "</tr>");
            for (int s = 0; s < list.size(); s++) {
                String exp_result1 = (String) list.get(s);
                System.out.println("List----" + exp_result1);
                String[] exp_result = exp_result1.split(",");
                bufferedWriter.append("<tr>");
                for (int t = 0; t < exp_result.length; t++) {
                    System.out.println(exp_result[t]);
                    if(exp_result[t].equals("Pass")){
                        sec3_pass_count++;
                    }else if(exp_result[t].equals("Fail")){
                        sec3_fail_count++;
                    }
                    if((t == exp_result.length-1 ) && exp_result[t].equals("Fail")) {
                        bufferedWriter.append("<td align=\"center\" bgcolor = \"#FF0000\">" + exp_result[t] + "</td> ");
                    }else if(((t == exp_result.length-1 ) && exp_result[t].equals("Pass"))){
                        bufferedWriter.append("<td align=\"center\" bgcolor = \"#00FF00\">" + exp_result[t] + "</td> ");
                    }else{
                        bufferedWriter.append("<td align=\"center\" >" + exp_result[t] + "</td> ");
                    }
                }
                bufferedWriter.append("</tr>");

            }
            if(overAllStatus.equalsIgnoreCase("Fail")){
                bufferedWriter.append("</tr><td style=\"font-weight:bold\" align=\"center\" font color = \"bold\" >Total Verification:"+list.size()+"</td><td></td><td style=\"font-weight:bold\" align=\"center\" > Total Pass :"+sec3_pass_count +"</td><td style=\"font-weight:bold\" align=\"center\"> Total Fail: "+sec3_fail_count+"</td> <td style=\"font-weight:bold\" align=\"center\" bgcolor = \"#FF0001\">" + overAllStatus + "</td>");
            }else {
                bufferedWriter.append("</tr><td style=\"font-weight:bold\" align=\"center\" font color = \"bold\" >Total Verification:"+list.size()+"</td><td></td><td style=\"font-weight:bold\" align=\"center\" > Total Pass :"+sec3_pass_count +"</td><td style=\"font-weight:bold\" align=\"center\"> Total Fail: "+sec3_fail_count+"</td> <td style=\"font-weight:bold\" align=\"center\" bgcolor = \"#00FF00\">" + overAllStatus + "</td>");
            }
            //bufferedWriter.append("</tr><td style=\"font-weight:bold\" align=\"center\" font color = \"bold\" >Total Verification:"+list.size()+"</td><td></td><td style=\"font-weight:bold\" align=\"center\" > Total Pass :"+sec3_pass_count +"</td><td style=\"font-weight:bold\" align=\"center\"> Total Fail: "+sec3_fail_count+"</td>");
            bufferedWriter.append("</table> </body> </html>");
            bufferedWriter.append("<br><br><br>");
            sec3_pass_count = 0;
            sec3_fail_count = 0;

        }

        if(section.equals("Section4")){
            bufferedWriter.append("<html><table id = '3' border=\"1\" cellspacing=\"2\" cellpadding=\"1\" style=\"width:90%\">" +
                    "<th width=\"20%\" align =\"left\">SECTION - 4 \n </th>"+
                    "<th align =\"center\">"+section_name+ " \n </th> </table>"+
                    "<table id = '2' border=\"2\" cellspacing=\"0\" cellpadding=\"4\" style=\"width:90%\">" +
                    "<tr>" +
                    "<th width=\"15%\" border=\"2\" >S.No</th>" +
                    "<th width=\"25%\" border=\"2\" >File vs DB column</th>" +
                    "<th width=\"25%\"border=\"2\" >Actual Value in DB</th>" +
                    "<th width=\"20%\" border=\"2\">Expected Test Value</th>" +
                    "<th width=\"15%\" border=\"2\">Test Status</th>" +
                    "</tr>");
            for (int s = 0; s < list.size(); s++) {
                String exp_result1 = (String) list.get(s);
                System.out.println("List----" + exp_result1);
                String[] exp_result = exp_result1.split(",");
                bufferedWriter.append("<tr>");
                for (int t = 0; t < exp_result.length; t++) {
                    System.out.println(exp_result[t]);
                    if(exp_result[t].equals("Pass")){
                        sec3_pass_count++;
                    }else if(exp_result[t].equals("Fail")){
                        sec3_fail_count++;
                    }
                    if((t == exp_result.length-1 ) && exp_result[t].equals("Fail")) {
                        bufferedWriter.append("<td align=\"center\" bgcolor = \"#FF0000\">" + exp_result[t] + "</td> ");
                    }else if(((t == exp_result.length-1 ) && exp_result[t].equals("Pass"))){
                        bufferedWriter.append("<td align=\"center\" bgcolor = \"#00FF00\">" + exp_result[t] + "</td> ");
                    }else{
                        bufferedWriter.append("<td align=\"center\">" + exp_result[t] + "</td> ");
                    }
                }
                bufferedWriter.append("</tr>");

            }
            if(overAllStatus.equalsIgnoreCase("Fail")){
                bufferedWriter.append("</tr><td style=\"font-weight:bold\" align=\"center\" font color = \"bold\" >Total Verification:"+list.size()+"</td><td></td><td style=\"font-weight:bold\" align=\"center\" > Total Pass :"+sec3_pass_count +"</td><td style=\"font-weight:bold\" align=\"center\"> Total Fail: "+sec3_fail_count+"</td> <td style=\"font-weight:bold\" align=\"center\" bgcolor = \"#FF0001\">" + overAllStatus + "</td>");
            }else {
                bufferedWriter.append("</tr><td style=\"font-weight:bold\" align=\"center\" font color = \"bold\" >Total Verification:"+list.size()+"</td><td></td><td style=\"font-weight:bold\" align=\"center\" > Total Pass :"+sec3_pass_count +"</td><td style=\"font-weight:bold\" align=\"center\"> Total Fail: "+sec3_fail_count+"</td> <td style=\"font-weight:bold\" align=\"center\" bgcolor = \"#00FF00\">" + overAllStatus + "</td>");
            }
            //bufferedWriter.append("</tr><td style=\"font-weight:bold\" align=\"center\" font color = \"bold\" >Total Verification:"+list.size()+"</td><td></td><td style=\"font-weight:bold\" align=\"center\" > Total Pass :"+sec3_pass_count +"</td><td style=\"font-weight:bold\" align=\"center\"> Total Fail: "+sec3_fail_count+"</td> <td style=\"font-weight:bold\" align=\"center\" bgcolor = \"#FF0001\">" + overAllStatus + "</td>");
            bufferedWriter.append("</table> </body> </html>");
            bufferedWriter.append("<br><br><br>");
            sec3_pass_count = 0;
            sec3_fail_count = 0;

        }

        if(section.equals("Section5")){
            bufferedWriter.append("<html><table id = '3' border=\"1\" cellspacing=\"2\" cellpadding=\"1\" style=\"width:90%\">" +
                    "<th width=\"20%\" align =\"left\">SECTION - 5 \n </th>"+
                    "<th align =\"center\">"+section_name+ " \n </th> </table>"+
                    "<table id = '2' border=\"2\" cellspacing=\"0\" cellpadding=\"4\" style=\"width:90%\">" +
                    "<tr>" +
                    "<th width=\"15%\" border=\"2\" >S.No</th>" +
                    "<th width=\"25%\" border=\"2\" >Actual Records in AGG Table</th>" +
                    "<th width=\"25%\"border=\"2\" >Actual Records in TO Table</th>" +
                    "<th width=\"20%\" border=\"2\">Expected Records in TO Table</th>" +
                    "<th width=\"15%\" border=\"2\">Test Status</th>" +
                    "</tr>");
            for (int s = 0; s < list.size(); s++) {
                String exp_result1 = (String) list.get(s);
                System.out.println("List----" + exp_result1);
                String[] exp_result = exp_result1.split(",");
                bufferedWriter.append("<tr>");
                for (int t = 0; t < exp_result.length; t++) {
                    System.out.println(exp_result[t]);
                    if(exp_result[t].equals("Pass")){
                        sec3_pass_count++;
                    }else if(exp_result[t].equals("Fail")){
                        sec3_fail_count++;
                    }
                    if((t == exp_result.length-1 ) && exp_result[t].equals("Fail")) {
                        bufferedWriter.append("<td align=\"center\" bgcolor = \"#FF0000\">" + exp_result[t] + "</td> ");
                    }else if(((t == exp_result.length-1 ) && exp_result[t].equals("Pass"))){
                        bufferedWriter.append("<td align=\"center\" bgcolor = \"#00FF00\">" + exp_result[t] + "</td> ");
                    }else{
                        bufferedWriter.append("<td align=\"center\" >" + exp_result[t] + "</td> ");
                    }
                }
                bufferedWriter.append("</tr>");

            }
            if(overAllStatus.equalsIgnoreCase("Fail")){
                bufferedWriter.append("</tr><td style=\"font-weight:bold\" align=\"center\" font color = \"bold\" >Total Verification:"+list.size()+"</td><td></td><td style=\"font-weight:bold\" align=\"center\" > Total Pass :"+sec3_pass_count +"</td><td style=\"font-weight:bold\" align=\"center\"> Total Fail: "+sec3_fail_count+"</td> <td style=\"font-weight:bold\" align=\"center\" bgcolor = \"#FF0001\">" + overAllStatus + "</td>");
            }else {
                bufferedWriter.append("</tr><td style=\"font-weight:bold\" align=\"center\" font color = \"bold\" >Total Verification:"+list.size()+"</td><td></td><td style=\"font-weight:bold\" align=\"center\" > Total Pass :"+sec3_pass_count +"</td><td style=\"font-weight:bold\" align=\"center\"> Total Fail: "+sec3_fail_count+"</td> <td style=\"font-weight:bold\" align=\"center\" bgcolor = \"#00FF00\">" + overAllStatus + "</td>");
            }
            //bufferedWriter.append("</tr><td style=\"font-weight:bold\" align=\"center\" font color = \"bold\" >Total Verification:"+list.size()+"</td><td></td><td style=\"font-weight:bold\" align=\"center\" > Total Pass :"+sec3_pass_count +"</td><td style=\"font-weight:bold\" align=\"center\"> Total Fail: "+sec3_fail_count+"</td>");
            bufferedWriter.append("</table> </body> </html>");
            bufferedWriter.append("<br><br><br>");
            sec3_pass_count = 0;
            sec3_fail_count = 0;

        }

        if(section.equals("Section6")){
            bufferedWriter.append("<html><table id = '3' border=\"1\" cellspacing=\"2\" cellpadding=\"1\" style=\"width:90%\">" +
                    "<th width=\"20%\" align =\"left\">SECTION - 6 \n </th>"+
                    "<th align =\"center\">" + section_name + " \n </th> </table>"+
                    "<table id = '2' border=\"2\" cellspacing=\"0\" cellpadding=\"4\" style=\"width:90%\">" +
                    "<tr>" +
                    "<th width=\"5%\" border=\"2\" >S.No</th>" +
                    "<th width=\"15%\" border=\"2\" >Batch Name</th>" +
                    "<th width=\"15%\"border=\"2\" >Journal Name</th>" +
                    "<th width=\"5%\"border=\"2\" >Line Num</th>" +
                    "<th width=\"10%\"border=\"2\" >BC Entered DR</th>" +
                    "<th width=\"10%\"border=\"2\" >BC Entered CR</th>" +
                    "<th width=\"15%\" border=\"2\">Expected Posting GL Combination</th>" +
                    "<th width=\"15%\" border=\"2\">Actual Posting GL Combination</th>" +
                    "<th width=\"10%\" border=\"2\">Test Status</th>" +
                    "</tr>");
            for (int s = 0; s < list.size(); s++) {
                String exp_result1 = (String) list.get(s);
                System.out.println("List----" + exp_result1);
                String[] exp_result = exp_result1.split(",");
                bufferedWriter.append("<tr>");
                for (int t = 0; t < exp_result.length; t++) {
                    System.out.println(exp_result[t]);
                    if(exp_result[t].equals("Pass")){
                        sec3_pass_count++;
                    }else if(exp_result[t].equals("Fail")){
                        sec3_fail_count++;
                    }
                    if((t == exp_result.length-1 ) && exp_result[t].equals("Fail")) {
                        bufferedWriter.append("<td align=\"center\" bgcolor = \"#FF0000\">" + exp_result[t] + "</td> ");
                    }else if(((t == exp_result.length-1 ) && exp_result[t].equals("Pass"))){
                        bufferedWriter.append("<td align=\"center\" bgcolor = \"#00FF00\">" + exp_result[t] + "</td> ");
                    }else{
                        bufferedWriter.append("<td align=\"center\" >" + exp_result[t] + "</td> ");
                    }
                }
                bufferedWriter.append("</tr>");

            }
            bufferedWriter.append("</tr><td style=\"font-weight:bold\" align=\"center\" font color = \"bold\" >Total Verification:"+list.size()+"</td><td></td><td></td><td></td><td></td><td style=\"font-weight:bold\" align=\"center\" > Total Pass :"+sec3_pass_count +"</td><td style=\"font-weight:bold\" align=\"center\"> Total Fail: "+sec3_fail_count+"</td>");
            bufferedWriter.append("</table> </body> </html>");
            bufferedWriter.append("<br><br><br>");
            sec3_pass_count = 0;
            sec3_fail_count = 0;

        }

        String failed_res = "";
        String failed_res1 = "";

        if(section.equals("Consolidation_SM")){
            bufferedWriter.append("<html><table id = '3' border=\"1\" cellspacing=\"2\" cellpadding=\"1\" style=\"width:90%\">" +
                    "<th width=\"20%\" align =\"left\">SECTION - 1 \n </th>"+
                    "<th align =\"center\">"+section_name+" \n </th> </table>"+
                    "<table id = '2' border=\"2\" cellspacing=\"0\" cellpadding=\"4\" style=\"width:90%\">" +
                    "<tr>" +
                    "<th width=\"10%\" border=\"2\" >S.No</th>" +
                    "<th width=\"25%\" border=\"2\" >File Name</th>" +
                    "<th width=\"20%\"border=\"2\" >Batch Control Status</th>" +
                    "<th width=\"15%\" border=\"2\">Consolidation Layer Status</th>" +
                    "<th width=\"20%\" border=\"2\">Failed Columns</th>" +
                    "<th width=\"10%\" border=\"2\">Status</th>" +
                    "</tr>");
            int a = 5;
            for (int s = 0; s < list.size(); s++) {
                String exp_result1 = (String) list.get(s);
                System.out.println("List----" + exp_result1);
                String[] exp_result = exp_result1.split(",");
                bufferedWriter.append("<tr>");
                for (int t = 0; t < exp_result.length; t++) {
                    if(exp_result[t].equals("Pass")){
                        sec3_pass_count++;
                    }else if(exp_result[t].equals("Fail")){
                        sec3_fail_count++;
                    }
                    if((t == exp_result.length-1 ) && exp_result[t].equals("Fail")) {
                        bufferedWriter.append("<td align=\"center\" bgcolor = \"#FF0000\">" + exp_result[t] + "</td> ");
                    }else if(((t == exp_result.length-1 ) && exp_result[t].equals("Pass"))){
                        bufferedWriter.append("<td align=\"center\" bgcolor = \"#00FF00\">" + exp_result[t] + "</td> ");
                    }else if(t > 3 || t == exp_result.length){
                        String [] faled_results = exp_result[t].split("-");
                        for(int z = 0; z < faled_results.length; z++ ) {
                             failed_res = faled_results[z] + "\n";
                             failed_res1 = failed_res1 + failed_res + "\r\n";

                            System.out.println("failed column ---" + failed_res1);
                        }
                            bufferedWriter.append("<td align=\"left\" >" + failed_res1 +"</td> ").append("\n");

                        //bufferedWriter.append("<td align=\"left\" >" + exp_result[t] + "\r\n" +"</td> ");

                    }else{
                        System.out.println("failed column1 ---" + exp_result[t]);
                        bufferedWriter.append("<td align=\"center\" >" + exp_result[t] + "\r\n" + "</td> ");
                    }

                }
                bufferedWriter.append("</tr>");

            }
            if(overAllStatus.equalsIgnoreCase("Fail")){
                bufferedWriter.append("</tr><td style=\"font-weight:bold\" align=\"center\" font color = \"bold\" >Total Verification:"+list.size()+"</td><td></td><td style=\"font-weight:bold\" align=\"center\" > Total Pass :"+sec3_pass_count +"</td><td style=\"font-weight:bold\" align=\"center\"> Total Fail: "+sec3_fail_count+"</td> <td style=\"font-weight:bold\" align=\"center\" bgcolor = \"#FF0001\">" + overAllStatus + "</td>");
            }else {
                bufferedWriter.append("</tr><td style=\"font-weight:bold\" align=\"center\" font color = \"bold\" >Total Verification:"+list.size()+"</td><td></td><td style=\"font-weight:bold\" align=\"center\" > Total Pass :"+sec3_pass_count +"</td><td style=\"font-weight:bold\" align=\"center\"> Total Fail: "+sec3_fail_count+"</td> <td style=\"font-weight:bold\" align=\"center\" bgcolor = \"#00FF00\">" + overAllStatus + "</td>");
            }
            bufferedWriter.append("</table> </body> </html>");
            bufferedWriter.append("<br><br><br>");
            sec3_pass_count = 0;
            sec3_fail_count = 0;

        }

        if(section.equals("Staging_SM")){
            bufferedWriter.append("<html><table id = '3' border=\"1\" cellspacing=\"2\" cellpadding=\"1\" style=\"width:90%\">" +
                    "<th width=\"20%\" align =\"left\">SECTION - 2 \n </th>"+
                    "<th align =\"center\">"+section_name+" \n </th> </table>"+
                    "<table id = '2' border=\"2\" cellspacing=\"0\" cellpadding=\"4\" style=\"width:90%\">" +
                    "<tr>" +
                    "<th width=\"10%\" border=\"2\" >S.No</th>" +
                    "<th width=\"25%\" border=\"2\" >File Name</th>" +
                    "<th width=\"20%\"border=\"2\" >Batch Control Status</th>" +
                    "<th width=\"15%\" border=\"2\">Staging Layer Status</th>" +
                    "<th width=\"20%\" border=\"2\">Failed Columns</th>" +
                    "<th width=\"10%\" border=\"2\">Status</th>" +
                    "</tr>");
            int a = 5;
            for (int s = 0; s < list.size(); s++) {
                String exp_result1 = (String) list.get(s);
                System.out.println("List----" + exp_result1);
                String[] exp_result = exp_result1.split(",");
                bufferedWriter.append("<tr>");
                for (int t = 0; t < exp_result.length; t++) {
                    if(exp_result[t].equals("Pass")){
                        sec3_pass_count++;
                    }else if(exp_result[t].equals("Fail")){
                        sec3_fail_count++;
                    }
                    if((t == exp_result.length-1 ) && exp_result[t].equals("Fail")) {
                        bufferedWriter.append("<td align=\"center\" bgcolor = \"#FF0000\">" + exp_result[t] + "</td> ");
                    }else if(((t == exp_result.length-1 ) && exp_result[t].equals("Pass"))){
                        bufferedWriter.append("<td align=\"center\" bgcolor = \"#00FF00\">" + exp_result[t] + "</td> ");
                    }else if(t > 3 || t == exp_result.length){
                        String [] faled_results = exp_result[t].split("-");
                        for(int z = 0; z < faled_results.length; z++ ) {
                            failed_res = faled_results[z] + "\n";
                            failed_res1 = failed_res1 + failed_res + "\r\n";

                            System.out.println("failed column ---" + failed_res1);
                        }
                        bufferedWriter.append("<td align=\"left\" >" + failed_res1 +"</td> ").append("\n");

                        //bufferedWriter.append("<td align=\"left\" >" + exp_result[t] + "\r\n" +"</td> ");

                    }else{
                        System.out.println("failed column1 ---" + exp_result[t]);
                        bufferedWriter.append("<td align=\"center\" >" + exp_result[t] + "\r\n" + "</td> ");
                    }

                }
                bufferedWriter.append("</tr>");

            }
            if(overAllStatus.equalsIgnoreCase("Fail")){
                bufferedWriter.append("</tr><td style=\"font-weight:bold\" align=\"center\" font color = \"bold\" >Total Verification:"+list.size()+"</td><td></td><td style=\"font-weight:bold\" align=\"center\" > Total Pass :"+sec3_pass_count +"</td><td style=\"font-weight:bold\" align=\"center\"> Total Fail: "+sec3_fail_count+"</td> <td style=\"font-weight:bold\" align=\"center\" bgcolor = \"#FF0001\">" + overAllStatus + "</td>");
            }else {
                bufferedWriter.append("</tr><td style=\"font-weight:bold\" align=\"center\" font color = \"bold\" >Total Verification:"+list.size()+"</td><td></td><td style=\"font-weight:bold\" align=\"center\" > Total Pass :"+sec3_pass_count +"</td><td style=\"font-weight:bold\" align=\"center\"> Total Fail: "+sec3_fail_count+"</td> <td style=\"font-weight:bold\" align=\"center\" bgcolor = \"#00FF00\">" + overAllStatus + "</td>");
            }
            bufferedWriter.append("</table> </body> </html>");
            bufferedWriter.append("<br><br><br>");
            sec3_pass_count = 0;
            sec3_fail_count = 0;

        }

        if(section.equals("Aggregate_SM")){
            bufferedWriter.append("<html><table id = '3' border=\"1\" cellspacing=\"2\" cellpadding=\"1\" style=\"width:90%\">" +
                    "<th width=\"20%\" align =\"left\">SECTION - 3 \n </th>"+
                    "<th align =\"center\">"+section_name+" \n </th> </table>"+
                    "<table id = '2' border=\"2\" cellspacing=\"0\" cellpadding=\"4\" style=\"width:90%\">" +
                    "<tr>" +
                    "<th width=\"10%\" border=\"2\" >S.No</th>" +
                    "<th width=\"25%\" border=\"2\" >File Name</th>" +
                    "<th width=\"20%\"border=\"2\" >Batch Control Status</th>" +
                    "<th width=\"15%\" border=\"2\">Staging Layer Status</th>" +
                    "<th width=\"20%\" border=\"2\">Failed Columns</th>" +
                    "<th width=\"10%\" border=\"2\">Status</th>" +
                    "</tr>");
            int a = 5;
            for (int s = 0; s < list.size(); s++) {
                String exp_result1 = (String) list.get(s);
                System.out.println("List----" + exp_result1);
                String[] exp_result = exp_result1.split(",");
                bufferedWriter.append("<tr>");
                for (int t = 0; t < exp_result.length; t++) {
                    if(exp_result[t].equals("Pass")){
                        sec3_pass_count++;
                    }else if(exp_result[t].equals("Fail")){
                        sec3_fail_count++;
                    }
                    if((t == exp_result.length-1 ) && exp_result[t].equals("Fail")) {
                        bufferedWriter.append("<td align=\"center\" bgcolor = \"#FF0000\">" + exp_result[t] + "</td> ");
                    }else if(((t == exp_result.length-1 ) && exp_result[t].equals("Pass"))){
                        bufferedWriter.append("<td align=\"center\" bgcolor = \"#00FF00\">" + exp_result[t] + "</td> ");
                    }else if(t > 3 || t == exp_result.length){
                        String [] faled_results = exp_result[t].split("-");
                        for(int z = 0; z < faled_results.length; z++ ) {
                            failed_res = faled_results[z] + "\n";
                            failed_res1 = failed_res1 + failed_res + "\r\n";

                            System.out.println("failed column ---" + failed_res1);
                        }
                        bufferedWriter.append("<td align=\"left\" >" + failed_res1 +"</td> ").append("\n");

                        //bufferedWriter.append("<td align=\"left\" >" + exp_result[t] + "\r\n" +"</td> ");

                    }else{
                        System.out.println("failed column1 ---" + exp_result[t]);
                        bufferedWriter.append("<td align=\"center\" >" + exp_result[t] + "\r\n" + "</td> ");
                    }

                }
                bufferedWriter.append("</tr>");

            }
            if(overAllStatus.equalsIgnoreCase("Fail")){
                bufferedWriter.append("</tr><td style=\"font-weight:bold\" align=\"center\" font color = \"bold\" >Total Verification:"+list.size()+"</td><td></td><td style=\"font-weight:bold\" align=\"center\" > Total Pass :"+sec3_pass_count +"</td><td style=\"font-weight:bold\" align=\"center\"> Total Fail: "+sec3_fail_count+"</td> <td style=\"font-weight:bold\" align=\"center\" bgcolor = \"#FF0001\">" + overAllStatus + "</td>");
            }else {
                bufferedWriter.append("</tr><td style=\"font-weight:bold\" align=\"center\" font color = \"bold\" >Total Verification:"+list.size()+"</td><td></td><td style=\"font-weight:bold\" align=\"center\" > Total Pass :"+sec3_pass_count +"</td><td style=\"font-weight:bold\" align=\"center\"> Total Fail: "+sec3_fail_count+"</td> <td style=\"font-weight:bold\" align=\"center\" bgcolor = \"#00FF00\">" + overAllStatus + "</td>");
            }
            bufferedWriter.append("</table> </body> </html>");
            bufferedWriter.append("<br><br><br>");
            sec3_pass_count = 0;
            sec3_fail_count = 0;

        }

        // Mandatory validation
        if(section.equals("Mandatory")){
            bufferedWriter.append("<html><table id = '3' border=\"1\" cellspacing=\"2\" cellpadding=\"1\" style=\"width:90%\">" +
                    "<th width=\"20%\" align =\"left\">MANDATORY FIELD VALIDATION \n </th>"+
                    "<th align =\"center\">" + section_name + " \n </th> </table>"+
                    "<table id = '2' border=\"2\" cellspacing=\"0\" cellpadding=\"4\" style=\"width:90%\">" +
                    "<tr>" +
                    "<th width=\"3%\" border=\"2\" >S.No</th>" +
                    "<th width=\"12%\" border=\"2\" >Header ID</th>" +
                    "<th width=\"20%\"border=\"2\" >column Name</th>" +
                    "<th width=\"20%\"border=\"2\" >Mandatory for</th>" +
                    "<th width=\"25%\"border=\"2\" >Mandatory check -Note</th>" +
                    "<th width=\"10%\"border=\"2\" >Status in DB</th>" +
                    "<th width=\"10%\" border=\"2\">Test Status</th>" +
                    "</tr>");
            for (int s = 0; s < list.size(); s++) {
                String exp_result1 = (String) list.get(s);
                System.out.println("List----" + exp_result1);
                String[] exp_result = exp_result1.split(",");
                bufferedWriter.append("<tr>");
                for (int t = 0; t < exp_result.length; t++) {
                    System.out.println(exp_result[t]);
                    if(exp_result[t].equals("Pass")){
                        sec3_pass_count++;
                    }else if(exp_result[t].equals("Fail")){
                        sec3_fail_count++;
                    }
                    if((t == exp_result.length-1 ) && exp_result[t].equals("Fail")) {
                        bufferedWriter.append("<td align=\"center\" bgcolor = \"#FF0000\">" + exp_result[t] + "</td> ");
                    }else if(((t == exp_result.length-1 ) && exp_result[t].equals("Pass"))){
                        bufferedWriter.append("<td align=\"center\" bgcolor = \"#00FF00\">" + exp_result[t] + "</td> ");
                    }else{
                        bufferedWriter.append("<td align=\"center\" >" + exp_result[t] + "</td> ");
                    }
                }
                bufferedWriter.append("</tr>");

            }
            bufferedWriter.append("</tr><td style=\"font-weight:bold\" align=\"center\" font color = \"bold\" >Total Verification:"+list.size()+"</td><td></td><td></td><td></td><td></td><td style=\"font-weight:bold\" align=\"center\" > Total Pass :"+sec3_pass_count +"</td><td style=\"font-weight:bold\" align=\"center\"> Total Fail: "+sec3_fail_count+"</td>");
            bufferedWriter.append("</table> </body> </html>");
            bufferedWriter.append("<br><br><br>");
            sec3_pass_count = 0;
            sec3_fail_count = 0;

        }


        bufferedWriter.append("</table> </body> </html>");
            bufferedWriter.close();
    }
}
