package Dashboard_Report;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONException;

public class Landscape_GL_ClaimCash {

    static Statement SQLstmt = null;
    static ResultSet SQLResultset = null;

    public static HTML_Report_Generation_DB_EVO report_generation;
    public static HTML_Report_Generation_State_Model_B4C report_generation_state;
    public static SCH_EVO_PC_State_Model_B4C state_model;

    public static Table_Detail_Report table_detail_report;
    public static Table_Summary_Report table_summary_report;
    public static connectDatabase connect_db;

    public static void main(String[] args) throws IOException, SQLException, JSONException  {
        report_generation = new HTML_Report_Generation_DB_EVO();
        report_generation_state = new HTML_Report_Generation_State_Model_B4C();
        state_model = new SCH_EVO_PC_State_Model_B4C();

        table_detail_report = new Table_Detail_Report();
        table_summary_report = new Table_Summary_Report();
        connect_db = new connectDatabase();

        //----------------------- delete the existing report --------------
        report_generation.clean_report("Landscape_GLClaimcash.html");
        report_generation_state.clean_report_summary("Landscape_GLClaimcash_Summary.html");

        /*//--------------- SIT  database details -------------------
        String URL_SIT1 = "jdbc:oracle:thin:@dbs119dev.gwd.grpinf.net:1521/FSHDTST3";
        String Username_SIT1 = "FSH_ORA_DATA";
        String password_SIT1 = "Development_Test3";*/

        /*//--------------- SIT  database details -------------------
        String URL_SIT1 = "jdbc:oracle:thin:@dcn2dcll11z:1521/FSHTSIT1.gwd.grpinf.net";
        String Username_SIT1 = "FSH_ORA_DATA";
        String password_SIT1 = "vMw5HpJaFy3uD6eW";*/

        //--------------- SIT  database details -------------------
        String URL_SIT1 = "jdbc:oracle:thin:@dbs119dev.gwd.grpinf.net:1521/FSHDTST4";
        String Username_SIT1 = "FSH_ORA_DATA";
        String password_SIT1 = "XdbvFm!dm7dVCzWE";

        //--------------- EBS  database details -------------------
        String URL_ICSI = "jdbc:oracle:thin:@dcn2ddbx340.gwd.grpinf.net:1618:ICSI";
        String Username_ICSI = "apps";
        String password_ICSI = "apps4icsi";

        List<String> file_list = new ArrayList<String>();
        List<String> list = new ArrayList<String>();
        List<String> section1_results = new ArrayList<String>();
        /*List<String> section2_results = new ArrayList<String>();
        List<String> section3_results = new ArrayList<String>();*/
        List<String> section4_results = new ArrayList<String>();

        List<String> OverAllStatus = new ArrayList<String>();
        List<String> CONS_STATUS = new ArrayList<String>();
        List<String> summary_results_tbl = new ArrayList<String>();

        String[] file_lists = null;
        int section1_map_row = 1;

//--------------------- Decelaring the supporting details for reporting --------------
        String file_name = "null";
        String Source = "LAND";
        String pattern = "GLClaimcash";
        String header = "Header";

        //---- Initialiing row count variables -----
        int cons_stg_map_row = 1;

        //---- Initialiing Mandatory row count variables -----
        int mandatoryCONS_map_row = 1;
        int mandatorySTG_map_row = 1;
        int stg_line_map_row = 1;

        // Consolidation Header table variable
        String btc_BATCH_PKEY = null;
        String db_CONS_BC_HEADER_ID = "null";
        String db_CONS_SOURCE = "null";
        String db_CONS_HDR_STATUS = "null";
        String db_CONS_ACCOUNT_NUMBER = "null";
        String db_CONS_POLICY_NUMBER = "null";
        String db_CONS_CLAIM_NUMBER = "null";
        String db_CONS_UNDERWRITER = "null";
        String db_CONS_BRAND = "null";
        String db_CONS_LINE_OF_BUSINESS = "null";
        String db_CONS_PRODUCT_TYPE = "null";
        String db_CONS_TRANSACTION_REFERENCE = "null";
        String db_CONS_TRANSACTION_DATE = "null";
        String db_CONS_TRANSACTION_SUBTYPE = "null";
        String db_CONS_TRANSACTION_REASON = "null";
        String db_CONS_BANK_ACC = "null";
        String db_CONS_PAYMENT_METHOD = "null";
        String db_CONS_SUN_NUMBER = "null";
        String db_CONS_MID_NUMBER = "null";
        String db_CONS_DDI_REFERENCE = "null";
        String db_CONS_PAY_IN_SLIP_NUMBER = "null";
        String db_CONS_CHEQUE_NUMBER = "null";
        String db_CONS_CARD_TYPE = "null";
        String db_CONS_BACS_NARRATIVE = "null";
        String db_CONS_CHANNEL = "null";
        String db_CONS_INTEREST_AMOUNT = "null";
        String db_CONS_INTEREST_CURRENCY_CODE = "null";
        String db_CONS_BASE_INTEREST_AMOUNT = "null";
        String db_CONS_TAX_DEDUCTIBLE = "null";
        String db_CONS_ORDER_NUMBER = "null";
        String db_CONS_REVERSAL_INDICATOR = "null";
        String db_CONS_CARD_NARRATIVE = "null";
        String db_CONS_PAYMENT_TRANSACTION_TYPE_ID = "null";
        String db_CONS_CURRENCY_AMOUNT = "null";
        String db_CONS_CURRENCY_CODE = "null";
        String db_CONS_EXCHANGE_RATE = "null";
        String db_CONS_EXCHANGE_RATE_TYPE = "null";
        String db_CONS_BASE_CURRENCY_AMOUNT = "null";
        String db_CONS_LOSS_DATE = "null";
        String db_CONS_PRODUCT = "null";
        String db_CONS_GL_STRING = "null";
        String db_CONS_LPI_CODE = "null";
        String db_CONS_PERIL_CODE = "null";
        String load_date = null;
        Date load_dateFormat = null;

// Staging Header table variable declaration
        String db_STG_HEADER_ID = "null";
        String db_STG_SOURCE = "null";
        String db_STG_ACCOUNT_NUMBER = "null";
        String db_STG_HDR_STATUS = "null";
        String db_STG_POLICY_NUMBER = "null";
        String db_STG_CLAIM_NUMBER = "null";
        String db_STG_UNDERWRITER = "null";
        String db_STG_BRAND = "null";
        String db_STG_LINE_OF_BUSINESS = "null";
        String db_STG_PRODUCT_TYPE = "null";
        String db_STG_TRANSACTION_REFERENCE = "null";
        String db_STG_TRANSACTION_DATE = "null";
        String db_STG_TRANSACTION_SUBTYPE = "null";
        String db_STG_TRANSACTION_REASON = "null";
        String db_STG_BANK_ACC = "null";
        String db_STG_PAYMENT_METHOD = "null";
        String db_STG_SUN_NUMBER = "null";
        String db_STG_MID_NUMBER = "null";
        String db_STG_DDI_REFERENCE = "null";
        String db_STG_PAY_IN_SLIP_NUMBER = "null";
        String db_STG_CHEQUE_NUMBER = "null";
        String db_STG_CARD_TYPE = "null";
        String db_STG_BACS_NARRATIVE = "null";
        String db_STG_CHANNEL = "null";
        String db_STG_INTEREST_AMOUNT = "null";
        String db_STG_INTEREST_CURRENCY_CODE = "null";
        String db_STG_BASE_INTEREST_AMOUNT = "null";

        String db_STG_TAX_DEDUCTIBLE = "null";
        String db_STG_ORDER_NUMBER = "null";
        String db_STG_REVERSAL_INDICATOR = "null";
        String db_STG_CARD_NARRATIVE = "null";
        String db_STG_PAYMENT_TRANSACTION_TYPE_ID = "null";
        String db_STG_CURRENCY_AMOUNT = "null";
        String db_STG_CURRENCY_CODE = "null";
        String db_STG_EXCHANGE_RATE = "null";
        String db_STG_EXCHANGE_RATE_TYPE = "null";
        String db_STG_BASE_CURRENCY_AMOUNT = "null";
        String db_STG_LOSS_DATE = "null";
        String db_STG_PRODUCT = "null";
        String db_STG_FSH_ATTRIBUTE_01 = "null";
        String db_STG_PRODUCT_KEY = "null";
        String db_STG_PERIL_CODE = "null";
        String db_STG_TOH_ID = "null";
        String db_STG_EVENT_CODE = "null";
        String db_STG_ENTITY_TYPE_CODE = "null";
        String db_STG_BC_SUMMARY_ID = "null";
        String db_STG_CREDIT_IND = "null";
        String db_STG_SUMMARY_FLAG = "null";
        String STG_HDR_STATUS = "null";

        String xmlfile_name = "null";
        String xml_file_name1 = null;

        //-------- Connect to Database --------------
        connect_db.createConnection("DEVTEST4");
        //table_detail_report.detail_report_tbl_delete(connection, Source);


        //------ get the new file from batch control table --------------
        //SQLResultset = SQLstmt.executeQuery("Select distinct file_name from DLG_FSH_CTL_BATCH where Trunc(LOAD_DATE) = TRUNC(SYSDATE-1) and system = 'LAND' and pattern = 'GLPREMIUM'");
        //SQLResultset = SQLstmt.executeQuery("Select distinct file_name from DLG_FSH_CTL_BATCH where file_name = 'LANDGLReserves_20190730123600.xml'"); LANDGLClaimCash_20191105_Peril_code2.xml
        // yet - LANDGLClaimCash_20191206113828.xml, LANDGLClaimCash_20191108_4.xml LANDGLClaimCash_20191206113828.xml LANDGLClaimCash_20191206113828.xml

        boolean newRecord = true;
        String outSQL = connect_db.executeQuery_DB("BATCH", "GLClaimcash_batchCtl", "LANDSCAPE");
        SQLstmt = connect_db.resStatement();

        SQLResultset = SQLstmt.executeQuery(outSQL);
        while (SQLResultset.next()) {
            file_list.add(SQLResultset.getString("FILE_NAME"));
            System.out.println("File name---" + SQLResultset.getString("FILE_NAME"));
            list.addAll(section1_results);
        }

        // ---------------------------------- Get the batch PKEY ----------------------
        String outSQL_bkey = connect_db.executeQuery_DB("BATCH", "GLClaimcash_batchCtl_key","LANDSCAPE");

        SQLResultset = SQLstmt.executeQuery(outSQL_bkey);
        while (SQLResultset.next()) {
            btc_BATCH_PKEY = SQLResultset.getString("BATCH_PKEY");
        }

        /*// ---------------------------------- Get the batch PKEY ----------------------
        SQLResultset = SQLstmt.executeQuery("Select BATCH_PKEY from dlg_fsh_ctl_batch where  FILE_NAME = 'GLClaimCash_27112018_Bac_PM1.xml' ");
        while (SQLResultset.next()) {
            btc_BATCH_PKEY = SQLResultset.getString("BATCH_PKEY");
        }*/

        // ---------------------------------- Check the new file ----------------------
        SQLResultset = SQLstmt.executeQuery(outSQL);
        if (!SQLResultset.next()) {
            System.out.println("No new Landscape_GLClaimcash files have been received to FSH ");
            newRecord = false;
            String nonewfile = ",FILE_NAME," + "No new Landscape_GLClaimcash files have been received to FSH" + "," + "," + ",Pass";
            section1_results.add(nonewfile);
            list.addAll(section1_results);
        }

        if (newRecord) {

            //------------------------ Section 1 Start Print all the new file in the report-------------------
            for (String num_file : file_list) {
                file_lists = num_file.split(",");
                for (String file_list1 : file_lists) {
                    xml_file_name1 = file_list1;
                    //int section1_map_row = 1;
                    String newfile = section1_map_row + ",FILE_NAME," + xml_file_name1 + "," + xml_file_name1 + ",Pass";
                    section1_map_row++;
                    section1_results.add(newfile);
                }
            }
            list.addAll(section1_results);
            //report_generation.report_Test1(section1_results, "Section1", xml_file_name1, "B4C BC CONS BATCH TABLE VALIDATION", "B4C_SCHBilling", "B4C BC VALIDATION");
            //------------------------ Section 1 End ----------------------------------------------
        }


        List<String> list_header = new ArrayList<String>(); // -- Add all the header id
        if (newRecord) {
            //------------ Split the file names form the list --------------
            for (String xml_file_name : file_list) {
                int section2_map_row = 1;
                int CONS_flag = 0;
                List<String> section2_results = new ArrayList<String>();
                List<String> section3_results = new ArrayList<String>();
                List<String> section2_results_tbl = new ArrayList<String>();

                file_name = xml_file_name;

                //--------------------------------- Section 3 Start Here ---------------------------------
                boolean sec3flag = true;
                String db_STG_ACTL_RCDS = null;
                Integer db_STG_ACTL_RCDS1 = 0;

                SQLResultset = SQLstmt.executeQuery("SELECT COUNT(HEADER_ID) as STG_ACTL_RCDS FROM DLG_FSH_STG_COMM_BCCC_HDR WHERE FILE_NAME = '" + xml_file_name + "'");
                while (SQLResultset.next()) {
                    db_STG_ACTL_RCDS = SQLResultset.getString("STG_ACTL_RCDS");
                    db_STG_ACTL_RCDS1 = SQLResultset.getInt("STG_ACTL_RCDS");
                    System.out.println("stag Actual header count ----" + db_STG_ACTL_RCDS);
                }

                if (db_STG_ACTL_RCDS1 == 0) {  //--- Zero record validation
                    sec3flag = false;
                    String pc_stg_header_line = 1 + "," + "STG_ACTL_RCDS DB Does not have any records" + "," + "STG_ACTL_RCDS DB Does not have any records" + "," + "STG_AGG_ACTUAL_HEADER DB Does not have any records" + ",Fail";
                    section3_results.add(pc_stg_header_line);
                }

                SQLResultset = SQLstmt.executeQuery("SELECT SUMMARY_FLAG FROM DLG_FSH_STG_COMM_BCCC_HDR WHERE FILE_NAME = '" + xml_file_name + "'");
                while (SQLResultset.next()) {
                    db_STG_SUMMARY_FLAG = SQLResultset.getString("SUMMARY_FLAG");
                    System.out.println("stag Summary Flag ----" + db_STG_SUMMARY_FLAG);
                }

                if (sec3flag) {
                    do {

                        SQLResultset = SQLstmt.executeQuery("SELECT COUNT(a.HEADER_ID) as STG_EXP_SUM_HDRS \n" +
                                "FROM(\n" +
                                "SELECt HEADER_ID,STATUS,\n" +
                                "row_number() over(partition by SOURCE,UNDERWRITER,BRAND,LINE_OF_BUSINESS,PRODUCT_TYPE,CHANNEL,TRANSACTION_DATE,TRANSACTION_SUB_TYPE,TRANSACTION_REASON,PAYMENT_METHOD,SUN_NUMBER,BACS_NARRATIVE,MID_NUMBER,CARD_TYPE,CARD_NARRATIVE,PAY_IN_SLIP_NUMBER,INTEREST_CURRENCY_CODE,REVERSAL_INDICATOR,PAYMENT_TRANSACTION_TYPE_ID,CURRENCY_CODE,EXCHANGE_RATE,EXCHANGE_RATE_TYPE,CREDIT_IND,BANK_ACC,ENTITY_TYPE_CODE,EVENT_CODE,LOSS_DATE,PRODUCT,PRODUCT_KEY\n" +
                                "ORDER BY SOURCE,UNDERWRITER,BRAND,LINE_OF_BUSINESS,PRODUCT_TYPE,CHANNEL,TRANSACTION_DATE,TRANSACTION_SUB_TYPE,TRANSACTION_REASON,PAYMENT_METHOD,SUN_NUMBER,BACS_NARRATIVE,MID_NUMBER,CARD_TYPE,CARD_NARRATIVE,PAY_IN_SLIP_NUMBER,INTEREST_CURRENCY_CODE,REVERSAL_INDICATOR,PAYMENT_TRANSACTION_TYPE_ID,CURRENCY_CODE,EXCHANGE_RATE,EXCHANGE_RATE_TYPE,CREDIT_IND,BANK_ACC,ENTITY_TYPE_CODE,EVENT_CODE,LOSS_DATE,PRODUCT,PRODUCT_KEY) row_1\n" +
                                "FROM FSH_ORA_DATA.DLG_FSH_STG_COMM_BCCC_HDR WHERE FILE_NAME = '" + xml_file_name + "')a \n" +
                                "where a.row_1 = 1\n" +
                                "AND a.STATUS = 'COMPLETE'");

                        while (SQLResultset.next()) {
                            String STG_EXP_SUM_HDRS = SQLResultset.getString("STG_EXP_SUM_HDRS");
                            SQLResultset = SQLstmt.executeQuery("SELECT count(TOH_ID)as STG_AGG_ACTUAL_HEADER FROM DLG_FSH_STG_COMM_BCCC_AGG_HDR WHERE FILE_NAME = '" + xml_file_name + "'");
                            while (SQLResultset.next()) {
                                String STG_AGG_ACTUAL_HEADER = SQLResultset.getString("STG_AGG_ACTUAL_HEADER");
                                System.out.println("stag Aggregate actual header count ----" + STG_AGG_ACTUAL_HEADER);
                                System.out.println("stag actual header count ----" + db_STG_ACTL_RCDS);
                                System.out.println("stag expected header count ----" + STG_EXP_SUM_HDRS);
                                if (db_STG_SUMMARY_FLAG.equals("Y")) {
                                    if (STG_EXP_SUM_HDRS.equals(STG_AGG_ACTUAL_HEADER)) {
                                        String pc_stg_header_line = 1 + "," + db_STG_ACTL_RCDS + "," + STG_EXP_SUM_HDRS + "," + STG_AGG_ACTUAL_HEADER + ",Pass";
                                        section3_results.add(pc_stg_header_line);
                                    } else {
                                        String pc_stg_header_line = 1 + "," + db_STG_ACTL_RCDS + "," + STG_EXP_SUM_HDRS + "," + STG_AGG_ACTUAL_HEADER + ",Fail";
                                        section3_results.add(pc_stg_header_line);
                                    }
                                } else if (db_STG_SUMMARY_FLAG.equals("N")) {
                                    if (db_STG_ACTL_RCDS.equals(STG_AGG_ACTUAL_HEADER)) {
                                        String pc_stg_header_line = 1 + "," + db_STG_ACTL_RCDS + "," + db_STG_ACTL_RCDS + "," + STG_AGG_ACTUAL_HEADER + ",Pass";
                                        section3_results.add(pc_stg_header_line);
                                    } else {
                                        String pc_stg_header_line = 1 + "," + db_STG_ACTL_RCDS + "," + db_STG_ACTL_RCDS + "," + STG_AGG_ACTUAL_HEADER + ",Fail";
                                        section3_results.add(pc_stg_header_line);
                                    }

                                }
                            }
                        }

                    } while (SQLResultset.next());
                }


                //-------------- Validation Cons to Stag table ----------------
                String LandscapeGLClaimcash_consSqlQuery = connect_db.executeQuery_DB("LandscapeGL", "GLClaimcash_Cons","LANDSCAPE");
                SQLResultset = SQLstmt.executeQuery(LandscapeGLClaimcash_consSqlQuery + "'"+file_name+ "'" );

                //SQLResultset = SQLstmt.executeQuery("SELECT * from DLG_FSH_CONS_LAND_CC_HDR WHERE FILE_NAME = '" + xml_file_name + "'");
                while (SQLResultset.next()) {
                    db_CONS_BC_HEADER_ID = SQLResultset.getString("BC_HEADER_ID");
                    list_header.add(db_CONS_BC_HEADER_ID);
                }

                for (int i = 0; i < list_header.size(); i++) {
                    SQLResultset = SQLstmt.executeQuery(LandscapeGLClaimcash_consSqlQuery + "'"+file_name+ "' and BC_HEADER_ID = '" + list_header.get(i) + "' " );
                    //SQLResultset = SQLstmt.executeQuery("SELECT * from DLG_FSH_CONS_LAND_CC_HDR WHERE FILE_NAME = '" + xml_file_name + "' and BC_HEADER_ID = '" + list_header.get(i) + "' ");
                    while (SQLResultset.next()) {
                        db_CONS_HDR_STATUS = SQLResultset.getString("STATUS");
                        db_CONS_SOURCE = SQLResultset.getString("SOURCE");
                        db_CONS_BC_HEADER_ID = SQLResultset.getString("BC_HEADER_ID");
                        db_CONS_ACCOUNT_NUMBER = SQLResultset.getString("ACCOUNT_NUMBER");
                        db_CONS_POLICY_NUMBER = SQLResultset.getString("POLICY_NUMBER");
                        db_CONS_CLAIM_NUMBER = SQLResultset.getString("CLAIM_NUMBER");
                        db_CONS_UNDERWRITER = SQLResultset.getString("UNDERWRITER");
                        db_CONS_BRAND = SQLResultset.getString("BRAND");
                        db_CONS_LINE_OF_BUSINESS = SQLResultset.getString("LINE_OF_BUSINESS");
                        db_CONS_PRODUCT_TYPE = SQLResultset.getString("PRODUCT_TYPE");
                        db_CONS_TRANSACTION_REFERENCE = SQLResultset.getString("TRANSACTION_REFERENCE");
                        db_CONS_TRANSACTION_DATE = SQLResultset.getString("TRANSACTION_DATE");
                        db_CONS_TRANSACTION_SUBTYPE = SQLResultset.getString("TRANSACTION_SUBTYPE");
                        db_CONS_TRANSACTION_REASON = SQLResultset.getString("TRANSACTION_REASON");
                        db_CONS_BANK_ACC = SQLResultset.getString("BANK_ACC");
                        db_CONS_PAYMENT_METHOD = SQLResultset.getString("PAYMENT_METHOD");
                        db_CONS_SUN_NUMBER = SQLResultset.getString("SUN_NUMBER");
                        db_CONS_MID_NUMBER = SQLResultset.getString("MID_NUMBER");
                        db_CONS_DDI_REFERENCE = SQLResultset.getString("DDI_REFERENCE");
                        db_CONS_PAY_IN_SLIP_NUMBER = SQLResultset.getString("PAY_IN_SLIP_NUMBER");
                        db_CONS_CHEQUE_NUMBER = SQLResultset.getString("CHEQUE_NUMBER");
                        db_CONS_CARD_TYPE = SQLResultset.getString("CARD_TYPE");
                        db_CONS_BACS_NARRATIVE = SQLResultset.getString("BACS_NARRATIVE");
                        db_CONS_CHANNEL = SQLResultset.getString("CHANNEL");
                        db_CONS_INTEREST_AMOUNT = SQLResultset.getString("INTEREST_AMOUNT");
                        db_CONS_INTEREST_CURRENCY_CODE = SQLResultset.getString("INTEREST_CURRENCY_CODE");
                        db_CONS_BASE_INTEREST_AMOUNT = SQLResultset.getString("BASE_INTEREST_AMOUNT");
                        db_CONS_TAX_DEDUCTIBLE = SQLResultset.getString("TAX_DEDUCTIBLE");
                        db_CONS_ORDER_NUMBER = SQLResultset.getString("ORDER_NUMBER");
                        db_CONS_REVERSAL_INDICATOR = SQLResultset.getString("REVERSAL_INDICATOR");
                        db_CONS_CARD_NARRATIVE = SQLResultset.getString("CARD_NARRATIVE");
                        db_CONS_PAYMENT_TRANSACTION_TYPE_ID = SQLResultset.getString("PAYMENT_TRANSACTION_TYPE_ID");
                        db_CONS_CURRENCY_AMOUNT = SQLResultset.getString("CURRENCY_AMOUNT");
                        db_CONS_CURRENCY_CODE = SQLResultset.getString("CURRENCY_CODE");
                        db_CONS_EXCHANGE_RATE = SQLResultset.getString("EXCHANGE_RATE");
                        db_CONS_EXCHANGE_RATE_TYPE = SQLResultset.getString("EXCHANGE_RATE_TYPE");
                        db_CONS_BASE_CURRENCY_AMOUNT = SQLResultset.getString("BASE_CURRENCY_AMOUNT");
                        db_CONS_LOSS_DATE = SQLResultset.getString("LOSS_DATE");
                        db_CONS_PRODUCT = SQLResultset.getString("PRODUCT");
                        db_CONS_GL_STRING = SQLResultset.getString("GL_STRING");
                        db_CONS_LPI_CODE = SQLResultset.getString("LPI_CODE");
                        db_CONS_PERIL_CODE = SQLResultset.getString("PERIL_CODE");
                        load_date = SQLResultset.getString("LOAD_DATE");
                        String db_file_name = SQLResultset.getString("FILE_NAME");

                        //Converting Load date format
                        String load_dateTRIM = load_date.substring(0, 10);
                        load_dateFormat = Date.valueOf(load_dateTRIM);
                        System.out.println(load_dateFormat);


                        //Validating mandatory fields in consolidation table
                        //Source - mandatory validation
                        if ((db_CONS_SOURCE == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_SOURCE = mandatoryCONS_map_row + "," + db_CONS_BC_HEADER_ID + ",SOURCE," + "SOURCE : " + db_CONS_SOURCE + "," + "SOURCE was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_SOURCE);
                            mandatoryCONS_map_row++;
                        } else {
                            String CONS_SOURCE = mandatoryCONS_map_row + "," + db_CONS_BC_HEADER_ID + ",SOURCE," + "SOURCE : " + db_CONS_SOURCE + "," + "SOURCE was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_SOURCE);
                            mandatoryCONS_map_row++;
                        }

                        //BC_HEADER_ID - mandatory validation
                        if ((db_CONS_BC_HEADER_ID == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_ACCOUNT_NUMBER = "," + ",BC_HEADER_ID," + "BC_HEADER_ID : " + db_CONS_BC_HEADER_ID + "," + "BC_HEADER_ID was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_ACCOUNT_NUMBER);
                        } else {
                            String CONS_ACCOUNT_NUMBER = "," + ",BC_HEADER_ID," + "BC_HEADER_ID : " + db_CONS_BC_HEADER_ID + "," + "BC_HEADER_ID was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_ACCOUNT_NUMBER);
                        }

                        //ACCOUNT_NUMBER - mandatory validation
                        if ((db_CONS_ACCOUNT_NUMBER == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_ACCOUNT_NUMBER = "," + ",ACCOUNT_NUMBER," + "ACCOUNT_NUMBER : " + db_CONS_ACCOUNT_NUMBER + "," + "ACCOUNT_NUMBER was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_ACCOUNT_NUMBER);
                        } else {
                            String CONS_ACCOUNT_NUMBER = "," + ",ACCOUNT_NUMBER," + "ACCOUNT_NUMBER : " + db_CONS_ACCOUNT_NUMBER + "," + "ACCOUNT_NUMBER was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_ACCOUNT_NUMBER);
                        }

                        //POLICY_NUMBER - mandatory validation
                        if ((db_CONS_POLICY_NUMBER == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_POLICY_NUMBER = "," + ",POLICY_NUMBER," + "POLICY_NUMBER : " + db_CONS_POLICY_NUMBER + "," + "POLICY_NUMBER was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_POLICY_NUMBER);
                        } else {
                            String CONS_POLICY_NUMBER = "," + ",POLICY_NUMBER," + "POLICY_NUMBER : " + db_CONS_POLICY_NUMBER + "," + "POLICY_NUMBER was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_POLICY_NUMBER);
                        }

                        //CLAIM_NUMBER - mandatory validation
                        if ((db_CONS_CLAIM_NUMBER == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_CLAIM_NUMBER = "," + ",CLAIM_NUMBER," + "CLAIM_NUMBER : " + db_CONS_CLAIM_NUMBER + "," + "CLAIM_NUMBER was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_CLAIM_NUMBER);
                        } else {
                            String CONS_CLAIM_NUMBER = "," + ",POLICY_NUMBER," + "CLAIM_NUMBER : " + db_CONS_CLAIM_NUMBER + "," + "CLAIM_NUMBER was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_CLAIM_NUMBER);
                        }

                        //BRAND - mandatory validation
                        if ((db_CONS_BRAND == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_BRAND = "," + ",BRAND," + "BRAND : " + db_CONS_BRAND + "," + "BRAND was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_BRAND);
                        } else {
                            String CONS_BRAND = "," + ",BRAND," + "BRAND : " + db_CONS_BRAND + "," + "BRAND was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_BRAND);
                        }

                        //LINE_OF_BUSINESS - mandatory validation
                        if ((db_CONS_LINE_OF_BUSINESS == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_LINE_OF_BUSINESS = "," + ",LINE_OF_BUSINESS," + "LINE_OF_BUSINESS : " + db_CONS_LINE_OF_BUSINESS + "," + "LINE_OF_BUSINESS was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_LINE_OF_BUSINESS);
                        } else {
                            String CONS_LINE_OF_BUSINESS = "," + ",LINE_OF_BUSINESS," + "LINE_OF_BUSINESS : " + db_CONS_LINE_OF_BUSINESS + "," + "LINE_OF_BUSINESS was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_LINE_OF_BUSINESS);
                        }

                        //PRODUCT_TYPE - mandatory validation
                        if ((db_CONS_PRODUCT_TYPE == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_PRODUCT_TYPE = "," + ",PRODUCT_TYPE," + "PRODUCT_TYPE : " + db_CONS_PRODUCT_TYPE + "," + "PRODUCT_TYPE was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_PRODUCT_TYPE);
                        } else {
                            String CONS_PRODUCT_TYPE = "," + ",PRODUCT_TYPE," + "PRODUCT_TYPE : " + db_CONS_PRODUCT_TYPE + "," + "PRODUCT_TYPE was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_PRODUCT_TYPE);
                        }

                        //TRANSACTION_REFERENCE - mandatory validation
                        if ((db_CONS_TRANSACTION_REFERENCE == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_TRANSACTION_REFERENCE = "," + ",TRANSACTION_REFERENCE," + "TRANSACTION_REFERENCE : " + db_CONS_TRANSACTION_REFERENCE + "," + "TRANSACTION_REFERENCE was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_TRANSACTION_REFERENCE);
                        } else {
                            String CONS_TRANSACTION_REFERENCE = "," + ",TRANSACTION_REFERENCE," + "TRANSACTION_REFERENCE : " + db_CONS_TRANSACTION_REFERENCE + "," + "TRANSACTION_REFERENCE was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_TRANSACTION_REFERENCE);
                        }

                        //TRANSACTION_DATE - mandatory validation
                        if ((db_CONS_TRANSACTION_DATE == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_TRANSACTION_DATE = "," + ",TRANSACTION_DATE," + "TRANSACTION_DATE : " + db_CONS_TRANSACTION_DATE + "," + "TRANSACTION_DATE was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_TRANSACTION_DATE);
                        } else {
                            String CONS_TRANSACTION_DATE = "," + ",TRANSACTION_DATE," + "TRANSACTION_DATE : " + db_CONS_TRANSACTION_DATE + "," + "TRANSACTION_DATE was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_TRANSACTION_DATE);
                        }

                        //TRANSACTION_SUBTYPE - mandatory validation
                        if ((db_CONS_TRANSACTION_SUBTYPE == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_TRANSACTION_SUBTYPE = "," + ",TRANSACTION_SUBTYPE," + "TRANSACTION_SUBTYPE : " + db_CONS_TRANSACTION_SUBTYPE + "," + "TRANSACTION_SUBTYPE was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_TRANSACTION_SUBTYPE);
                        } else {
                            String CONS_TRANSACTION_SUBTYPE = "," + ",TRANSACTION_SUBTYPE," + "TRANSACTION_SUBTYPE : " + db_CONS_TRANSACTION_SUBTYPE + "," + "TRANSACTION_SUBTYPE was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_TRANSACTION_SUBTYPE);
                        }

                        //BANK_ACC - mandatory validation
                        if ((db_CONS_BANK_ACC == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_BANK_ACC = "," + ",BANK_ACC," + "BANK_ACC : " + db_CONS_BANK_ACC + "," + "BANK_ACC was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_BANK_ACC);
                        } else {
                            String CONS_BANK_ACC = "," + ",BANK_ACC," + "BANK_ACC : " + db_CONS_BANK_ACC + "," + "BANK_ACC was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_BANK_ACC);
                        }

                        //SUN_NUMBER - mandatory validation
                        if (db_CONS_PAYMENT_TRANSACTION_TYPE_ID != null && db_CONS_PAYMENT_TRANSACTION_TYPE_ID.equals("Direct Credit")) {
                            if ((db_CONS_SUN_NUMBER == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                                String CONS_PAYMENT_METHOD = "," + ",SUN_NUMBER," + "SUN_NUMBER : " + db_CONS_SUN_NUMBER + "," + "SUN_NUMBER was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                                section2_results.add(CONS_PAYMENT_METHOD);
                            } else {
                                String CONS_PAYMENT_METHOD = "," + ",SUN_NUMBER," + "SUN_NUMBER : " + db_CONS_SUN_NUMBER + "," + "SUN_NUMBER was found," + db_CONS_HDR_STATUS + "," + "Pass";
                                section2_results.add(CONS_PAYMENT_METHOD);
                            }
                        } else {
                            String CONS_PAYMENT_METHOD = "," + ",SUN_NUMBER," + "SUN_NUMBER : " + db_CONS_SUN_NUMBER + "," + "SUN_NUMBER is not mandatory neither NULL nor NOTNULL," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_PAYMENT_METHOD);
                        }

                        //BACS_NARRATIVE - mandatory validation
                        if (db_CONS_PAYMENT_TRANSACTION_TYPE_ID != null && db_CONS_PAYMENT_TRANSACTION_TYPE_ID.equals("Direct Credit")) {
                            if ((db_CONS_BACS_NARRATIVE == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                                String CONS_PAYMENT_METHOD = "," + ",BACS_NARRATIVE," + "BACS_NARRATIVE : " + db_CONS_BACS_NARRATIVE + "," + "BACS_NARRATIVE was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                                section2_results.add(CONS_PAYMENT_METHOD);
                            } else {
                                String CONS_PAYMENT_METHOD = "," + ",BACS_NARRATIVE," + "BACS_NARRATIVE : " + db_CONS_BACS_NARRATIVE + "," + "BACS_NARRATIVE was found," + db_CONS_HDR_STATUS + "," + "Pass";
                                section2_results.add(CONS_PAYMENT_METHOD);
                            }
                        } else {
                            String CONS_PAYMENT_METHOD = "," + ",BACS_NARRATIVE," + "BACS_NARRATIVE : " + db_CONS_BACS_NARRATIVE + "," + "BACS_NARRATIVE is not mandatory neither NULL nor NOTNULL," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_PAYMENT_METHOD);
                        }

                            /*//PAYMENT_METHOD - mandatory validation
                            if ((db_CONS_PAYMENT_METHOD == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                                String CONS_PAYMENT_METHOD = ","  +  ",PAYMENT_METHOD," + "PAYMENT_METHOD : " + db_CONS_PAYMENT_METHOD + "," + "PAYMENT_METHOD was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                                section2_results.add(CONS_PAYMENT_METHOD);
                            } else {
                                String CONS_PAYMENT_METHOD = ","  +  ",PAYMENT_METHOD," + "PAYMENT_METHOD : " + db_CONS_PAYMENT_METHOD + "," + "PAYMENT_METHOD was found," + db_CONS_HDR_STATUS + "," + "Pass";
                                section2_results.add(CONS_PAYMENT_METHOD);
                            }*/


                        //CHANNEL - mandatory validation
                        if ((db_CONS_CHANNEL == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_CHANNEL = "," + ",CHANNEL," + "CHANNEL : " + db_CONS_CHANNEL + "," + "CHANNEL was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_CHANNEL);
                        } else {
                            String CONS_CHANNEL = "," + ",CHANNEL," + "CHANNEL : " + db_CONS_CHANNEL + "," + "CHANNEL was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_CHANNEL);
                        }

                        //INTEREST_AMOUNT - mandatory validation
                        if ((db_CONS_INTEREST_AMOUNT == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_INTEREST_AMOUNT = "," + ",INTEREST_AMOUNT," + "INTEREST_AMOUNT : " + db_CONS_INTEREST_AMOUNT + "," + "INTEREST_AMOUNT was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_INTEREST_AMOUNT);
                        } else {
                            String CONS_INTEREST_AMOUNT = "," + ",INTEREST_AMOUNT," + "INTEREST_AMOUNT : " + db_CONS_INTEREST_AMOUNT + "," + "INTEREST_AMOUNT was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_INTEREST_AMOUNT);
                        }

                        //INTEREST_CURRENCY_CODE - mandatory validation
                        if ((db_CONS_INTEREST_CURRENCY_CODE == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_INTEREST_CURRENCY_CODE = "," + ",INTEREST_CURRENCY_CODE," + "INTEREST_CURRENCY_CODE : " + db_CONS_INTEREST_CURRENCY_CODE + "," + "INTEREST_CURRENCY_CODE was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_INTEREST_CURRENCY_CODE);
                        } else {
                            String CONS_INTEREST_CURRENCY_CODE = "," + ",INTEREST_CURRENCY_CODE," + "INTEREST_CURRENCY_CODE : " + db_CONS_INTEREST_CURRENCY_CODE + "," + "INTEREST_CURRENCY_CODE was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_INTEREST_CURRENCY_CODE);
                        }

                        //BASE_INTEREST_AMOUNT - mandatory validation
                        if ((db_CONS_BASE_INTEREST_AMOUNT == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_BASE_INTEREST_AMOUNT = "," + ",BASE_INTEREST_AMOUNT," + "BASE_INTEREST_AMOUNT : " + db_CONS_BASE_INTEREST_AMOUNT + "," + "BASE_INTEREST_AMOUNT was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_BASE_INTEREST_AMOUNT);
                        } else {
                            String CONS_BASE_INTEREST_AMOUNT = "," + ",BASE_INTEREST_AMOUNT," + "BASE_INTEREST_AMOUNT : " + db_CONS_BASE_INTEREST_AMOUNT + "," + "BASE_INTEREST_AMOUNT was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_BASE_INTEREST_AMOUNT);
                        }

                        //TAX_DEDUCTIBLE - mandatory validation
                        if ((db_CONS_TAX_DEDUCTIBLE == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_TAX_DEDUCTIBLE = "," + ",TAX_DEDUCTIBLE," + "TAX_DEDUCTIBLE : " + db_CONS_TAX_DEDUCTIBLE + "," + "TAX_DEDUCTIBLE was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_TAX_DEDUCTIBLE);
                        } else {
                            String CONS_TAX_DEDUCTIBLE = "," + ",TAX_DEDUCTIBLE," + "TAX_DEDUCTIBLE : " + db_CONS_TAX_DEDUCTIBLE + "," + "TAX_DEDUCTIBLE was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_TAX_DEDUCTIBLE);
                        }

                        //REVERSAL_INDICATOR - mandatory validation
                        if ((db_CONS_REVERSAL_INDICATOR == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_REVERSAL_INDICATOR = "," + ",REVERSAL_INDICATOR," + "REVERSAL_INDICATOR : " + db_CONS_REVERSAL_INDICATOR + "," + "REVERSAL_INDICATOR was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_REVERSAL_INDICATOR);
                        } else {
                            String CONS_REVERSAL_INDICATOR = "," + ",REVERSAL_INDICATOR," + "REVERSAL_INDICATOR : " + db_CONS_REVERSAL_INDICATOR + "," + "REVERSAL_INDICATOR was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_REVERSAL_INDICATOR);
                        }

                            /*//PAYMENT_TRANSACTION_TYPE_ID - mandatory validation
                            if ((db_CONS_PAYMENT_TRANSACTION_TYPE_ID == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                                String CONS_PAYMENT_TRANSACTION_TYPE_ID = ","  +  ",PAYMENT_TRANSACTION_TYPE_ID," + "PAYMENT_TRANSACTION_TYPE_ID : " + db_CONS_PAYMENT_TRANSACTION_TYPE_ID + "," + "PAYMENT_TRANSACTION_TYPE_ID was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                                section2_results.add(CONS_PAYMENT_TRANSACTION_TYPE_ID);
                            } else {
                                String CONS_PAYMENT_TRANSACTION_TYPE_ID = ","  +  ",PAYMENT_TRANSACTION_TYPE_ID," + "PAYMENT_TRANSACTION_TYPE_ID : " + db_CONS_PAYMENT_TRANSACTION_TYPE_ID + "," + "PAYMENT_TRANSACTION_TYPE_ID was found," + db_CONS_HDR_STATUS + "," + "Pass";
                                section2_results.add(CONS_PAYMENT_TRANSACTION_TYPE_ID);
                            }*/

                        //CURRENCY_AMOUNT - mandatory validation
                        if ((db_CONS_CURRENCY_AMOUNT == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_CURRENCY_AMOUNT = "," + ",CURRENCY_AMOUNT," + "CURRENCY_AMOUNT : " + db_CONS_CURRENCY_AMOUNT + "," + "CURRENCY_AMOUNT was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_CURRENCY_AMOUNT);
                        } else {
                            String CONS_CURRENCY_AMOUNT = "," + ",CURRENCY_AMOUNT," + "CURRENCY_AMOUNT : " + db_CONS_CURRENCY_AMOUNT + "," + "CURRENCY_AMOUNT was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_CURRENCY_AMOUNT);
                        }

                        //CURRENCY_CODE - mandatory validation
                        if ((db_CONS_CURRENCY_CODE == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_CURRENCY_CODE = "," + ",CURRENCY_CODE," + "CURRENCY_CODE : " + db_CONS_CURRENCY_CODE + "," + "CURRENCY_CODE was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_CURRENCY_CODE);
                        } else {
                            String CONS_CURRENCY_CODE = "," + ",CURRENCY_CODE," + "CURRENCY_CODE : " + db_CONS_CURRENCY_CODE + "," + "CURRENCY_CODE was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_CURRENCY_CODE);
                        }

                        //EXCHANGE_RATE - mandatory validation
                        if ((db_CONS_EXCHANGE_RATE == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_EXCHANGE_RATE = "," + ",EXCHANGE_RATE," + "EXCHANGE_RATE : " + db_CONS_EXCHANGE_RATE + "," + "EXCHANGE_RATE was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_EXCHANGE_RATE);
                        } else {
                            String CONS_EXCHANGE_RATE = "," + ",EXCHANGE_RATE," + "EXCHANGE_RATE : " + db_CONS_EXCHANGE_RATE + "," + "EXCHANGE_RATE was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_EXCHANGE_RATE);
                        }

                        //EXCHANGE_RATE_TYPE - mandatory validation
                        if ((db_CONS_EXCHANGE_RATE_TYPE == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_EXCHANGE_RATE_TYPE = "," + ",EXCHANGE_RATE_TYPE," + "EXCHANGE_RATE_TYPE : " + db_CONS_EXCHANGE_RATE_TYPE + "," + "EXCHANGE_RATE_TYPE was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_EXCHANGE_RATE_TYPE);
                        } else {
                            String CONS_EXCHANGE_RATE_TYPE = "," + ",EXCHANGE_RATE_TYPE," + "EXCHANGE_RATE_TYPE : " + db_CONS_EXCHANGE_RATE_TYPE + "," + "EXCHANGE_RATE_TYPE was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_EXCHANGE_RATE_TYPE);
                        }
                        //BASE_CURRENCY_AMOUNT - mandatory validation
                        if ((db_CONS_BASE_CURRENCY_AMOUNT == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_BASE_CURRENCY_AMOUNT = "," + ",BASE_CURRENCY_AMOUNT," + "BASE_CURRENCY_AMOUNT : " + db_CONS_BASE_CURRENCY_AMOUNT + "," + "BASE_CURRENCY_AMOUNT was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_BASE_CURRENCY_AMOUNT);
                        } else {
                            String CONS_BASE_CURRENCY_AMOUNT = "," + ",BASE_CURRENCY_AMOUNT," + "BASE_CURRENCY_AMOUNT : " + db_CONS_BASE_CURRENCY_AMOUNT + "," + "BASE_CURRENCY_AMOUNT was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_BASE_CURRENCY_AMOUNT);
                        }


                        //LOSS_DATE - mandatory validation
                        if ((db_CONS_LOSS_DATE == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_LOSS_DATE = "," + ",LOSS_DATE," + "LOSS_DATE : " + db_CONS_LOSS_DATE + "," + "LOSS_DATE was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_LOSS_DATE);
                        } else {
                            String CONS_LOSS_DATE = "," + ",LOSS_DATE," + "LOSS_DATE : " + db_CONS_LOSS_DATE + "," + "LOSS_DATE was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_LOSS_DATE);
                        }

                        //PRODUCT - mandatory validation
                        if ((db_CONS_PRODUCT == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_PRODUCT = "," + ",PRODUCT," + "PRODUCT : " + db_CONS_PRODUCT + "," + "PRODUCT was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_PRODUCT);
                        } else {
                            String CONS_PRODUCT = "," + ",PRODUCT," + "PRODUCT : " + db_CONS_PRODUCT + "," + "PRODUCT was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_PRODUCT);
                        }
                        //GL_STRING - mandatory validation
                        if ((db_CONS_GL_STRING == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_GL_STRING = "," + ",GL_STRING," + "GL_STRING : " + db_CONS_GL_STRING + "," + "GL_STRING was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_GL_STRING);
                        } else {
                            String CONS_GL_STRING = "," + ",GL_STRING," + "GL_STRING : " + db_CONS_GL_STRING + "," + "GL_STRING was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_GL_STRING);
                        }


                        //LPI_CODE - mandatory validation
                        if ((db_CONS_LPI_CODE == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_LPI_CODE = "," + ",LPI_CODE," + "LPI_CODE : " + db_CONS_LPI_CODE + "," + "LPI_CODE was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_LPI_CODE);
                        } else {
                            String CONS_LPI_CODE = "," + ",LPI_CODE," + "LPI_CODE : " + db_CONS_LPI_CODE + "," + "LPI_CODE was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_LPI_CODE);
                        }


                        //PERIL_CODE - mandatory validation
                        if ((db_CONS_PERIL_CODE == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_PERIL_CODE = "," + ",PERIL_CODE," + "PERIL_CODE : " + db_CONS_PERIL_CODE + "," + "PERIL_CODE was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_PERIL_CODE);
                        } else {
                            String CONS_PERIL_CODE = "," + ",PERIL_CODE," + "PERIL_CODE : " + db_CONS_PERIL_CODE + "," + "PERIL_CODE was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_PERIL_CODE);
                        }

                        //------------------- Consolidation to Staging ----------------------------------
                        String LandscapeGLClaimcash_stgSqlQuery = connect_db.executeQuery_DB("LandscapeGL", "GLClaimcash_Stg","LANDSCAPE");
                        SQLResultset = SQLstmt.executeQuery(LandscapeGLClaimcash_stgSqlQuery + "'"+file_name+ "' and HEADER_ID = '" + list_header.get(i) + "' " );
                        //SQLResultset = SQLstmt.executeQuery("SELECT *  from DLG_FSH_STG_COMM_BCCC_HDR  WHERE FILE_NAME = '" + xml_file_name + "' and HEADER_ID = '" + list_header.get(i) + "' ");
                        System.out.println("Header id outer ---" + db_CONS_BC_HEADER_ID);
                        if (!SQLResultset.next()) {
                            String stg_header_id = section2_map_row + ",HEADER_ID," + "no records available in STG table" + "," + db_CONS_BC_HEADER_ID + ",Fail";
                            section2_results.add(stg_header_id);
                        } else {
                            SQLResultset = SQLstmt.executeQuery(LandscapeGLClaimcash_stgSqlQuery + "'"+file_name+ "' and HEADER_ID = '" + list_header.get(i) + "' " );
                            //SQLResultset = SQLstmt.executeQuery("SELECT *  from DLG_FSH_STG_COMM_BCCC_HDR  WHERE FILE_NAME = '" + xml_file_name + "' and HEADER_ID = '" + list_header.get(i) + "' ");
                            while (SQLResultset.next()) {

                                db_STG_HDR_STATUS = SQLResultset.getString("STATUS");
                                db_STG_HEADER_ID = SQLResultset.getString("HEADER_ID");
                                db_STG_SOURCE = SQLResultset.getString("SOURCE");
                                db_STG_ACCOUNT_NUMBER = SQLResultset.getString("ACCOUNT_NUMBER");
                                db_STG_POLICY_NUMBER = SQLResultset.getString("POLICY_NUMBER");
                                db_STG_CLAIM_NUMBER = SQLResultset.getString("CLAIM_NUMBER");
                                db_STG_UNDERWRITER = SQLResultset.getString("UNDERWRITER");
                                db_STG_BRAND = SQLResultset.getString("BRAND");
                                db_STG_LINE_OF_BUSINESS = SQLResultset.getString("LINE_OF_BUSINESS");
                                db_STG_PRODUCT_TYPE = SQLResultset.getString("PRODUCT_TYPE");
                                db_STG_TRANSACTION_REFERENCE = SQLResultset.getString("TRANSACTION_REFERENCE");
                                db_STG_TRANSACTION_DATE = SQLResultset.getString("TRANSACTION_DATE");
                                db_STG_TRANSACTION_SUBTYPE = SQLResultset.getString("TRANSACTION_SUB_TYPE");
                                db_STG_TRANSACTION_REASON = SQLResultset.getString("TRANSACTION_REASON");
                                db_STG_BANK_ACC = SQLResultset.getString("BANK_ACC");
                                db_STG_PAYMENT_METHOD = SQLResultset.getString("PAYMENT_METHOD");
                                db_STG_SUN_NUMBER = SQLResultset.getString("SUN_NUMBER");
                                db_STG_MID_NUMBER = SQLResultset.getString("MID_NUMBER");
                                db_STG_DDI_REFERENCE = SQLResultset.getString("DDI_REFERENCE");
                                db_STG_PAY_IN_SLIP_NUMBER = SQLResultset.getString("PAY_IN_SLIP_NUMBER");
                                db_STG_CHEQUE_NUMBER = SQLResultset.getString("CHEQUE_NUMBER");
                                db_STG_CARD_TYPE = SQLResultset.getString("CARD_TYPE");
                                db_STG_BACS_NARRATIVE = SQLResultset.getString("BACS_NARRATIVE");
                                db_STG_CHANNEL = SQLResultset.getString("CHANNEL");
                                db_STG_INTEREST_AMOUNT = SQLResultset.getString("INTEREST_AMOUNT");
                                db_STG_INTEREST_CURRENCY_CODE = SQLResultset.getString("INTEREST_CURRENCY_CODE");
                                db_STG_BASE_INTEREST_AMOUNT = SQLResultset.getString("BASE_INTEREST_AMOUNT");
                                db_STG_TAX_DEDUCTIBLE = SQLResultset.getString("TAX_DEDUCTIBLE");
                                db_STG_ORDER_NUMBER = SQLResultset.getString("ORDER_NUMBER");
                                db_STG_REVERSAL_INDICATOR = SQLResultset.getString("REVERSAL_INDICATOR");
                                db_STG_CARD_NARRATIVE = SQLResultset.getString("CARD_NARRATIVE");
                                db_STG_PAYMENT_TRANSACTION_TYPE_ID = SQLResultset.getString("PAYMENT_TRANSACTION_TYPE_ID");
                                db_STG_CURRENCY_AMOUNT = SQLResultset.getString("CURRENCY_AMOUNT");
                                db_STG_CURRENCY_CODE = SQLResultset.getString("CURRENCY_CODE");
                                db_STG_EXCHANGE_RATE = SQLResultset.getString("EXCHANGE_RATE");
                                db_STG_EXCHANGE_RATE_TYPE = SQLResultset.getString("EXCHANGE_RATE_TYPE");
                                db_STG_BASE_CURRENCY_AMOUNT = SQLResultset.getString("BASE_CURRENCY_AMOUNT");
                                db_STG_LOSS_DATE = SQLResultset.getString("LOSS_DATE");
                                db_STG_PRODUCT = SQLResultset.getString("PRODUCT");
                                db_STG_FSH_ATTRIBUTE_01 = SQLResultset.getString("FSH_ATTRIBUTE_01");
                                db_STG_PRODUCT_KEY = SQLResultset.getString("PRODUCT_KEY");
                                db_STG_PERIL_CODE = SQLResultset.getString("PERIL_CODE");
                                db_STG_TOH_ID = SQLResultset.getString("TOH_ID");
                                db_STG_EVENT_CODE = SQLResultset.getString("EVENT_CODE");
                                db_STG_ENTITY_TYPE_CODE = SQLResultset.getString("ENTITY_TYPE_CODE");
                                db_STG_BC_SUMMARY_ID = SQLResultset.getString("BC_SUMMARY_ID");
                                db_STG_CREDIT_IND = SQLResultset.getString("CREDIT_IND");
                                db_STG_SUMMARY_FLAG = SQLResultset.getString("SUMMARY_FLAG");
                                STG_HDR_STATUS = SQLResultset.getString("STATUS");

                                //Staging mandatory validations
                                //HEADER_ID - mandatory validation
                                if ((db_STG_HEADER_ID == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = stg_line_map_row + "," + db_STG_HEADER_ID + ",HEADER_ID," + "HEADER_ID : " + db_STG_HEADER_ID + "," + "HEADER_ID was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                    stg_line_map_row++;
                                } else {
                                    String stg_header_id = stg_line_map_row + "," + db_STG_HEADER_ID + ",HEADER_ID," + "HEADER_ID : " + db_STG_HEADER_ID + "," + "HEADER_ID was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                    stg_line_map_row++;
                                }

                                //SOURCE - mandatory validation
                                if ((db_STG_SOURCE == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",SOURCE," + "SOURCE : " + db_STG_SOURCE + "," + "SOURCE was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",SOURCE," + "SOURCE : " + db_STG_SOURCE + "," + "SOURCE was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //ACCOUNT_NUMBER - mandatory validation
                                if ((db_STG_ACCOUNT_NUMBER == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",ACCOUNT_NUMBER," + "ACCOUNT_NUMBER : " + db_STG_ACCOUNT_NUMBER + "," + "ACCOUNT_NUMBER was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",ACCOUNT_NUMBER," + "ACCOUNT_NUMBER : " + db_STG_ACCOUNT_NUMBER + "," + "ACCOUNT_NUMBER was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //UNDERWRITER - mandatory validation
                                if ((db_STG_UNDERWRITER == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",UNDERWRITER," + "UNDERWRITER : " + db_STG_UNDERWRITER + "," + "UNDERWRITER was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",UNDERWRITER," + "UNDERWRITER : " + db_STG_UNDERWRITER + "," + "UNDERWRITER was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //TRANSACTION_REFERENCE - mandatory validation
                                if ((db_STG_TRANSACTION_REFERENCE == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",TRANSACTION_REFERENCE," + "TRANSACTION_REFERENCE : " + db_STG_TRANSACTION_REFERENCE + "," + "TRANSACTION_REFERENCE was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",TRANSACTION_REFERENCE," + "TRANSACTION_REFERENCE : " + db_STG_TRANSACTION_REFERENCE + "," + "TRANSACTION_REFERENCE was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //TRANSACTION_DATE - mandatory validation
                                if ((db_STG_TRANSACTION_DATE == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",TRANSACTION_DATE," + "TRANSACTION_DATE : " + db_STG_TRANSACTION_DATE + "," + "TRANSACTION_DATE was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",TRANSACTION_DATE," + "TRANSACTION_DATE : " + db_STG_TRANSACTION_DATE + "," + "TRANSACTION_DATE was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //TRANSACTION_SUBTYPE - mandatory validation
                                if ((db_STG_TRANSACTION_SUBTYPE == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",TRANSACTION_SUBTYPE," + "TRANSACTION_SUBTYPE : " + db_STG_TRANSACTION_SUBTYPE + "," + "TRANSACTION_SUBTYPE was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",TRANSACTION_SUBTYPE," + "TRANSACTION_SUBTYPE : " + db_STG_TRANSACTION_SUBTYPE + "," + "TRANSACTION_SUBTYPE was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //CURRENCY_AMOUNT - mandatory validation
                                if ((db_STG_CURRENCY_AMOUNT == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",CURRENCY_AMOUNT," + "CURRENCY_AMOUNT : " + db_STG_CURRENCY_AMOUNT + "," + "CURRENCY_AMOUNT was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",CURRENCY_AMOUNT," + "CURRENCY_AMOUNT : " + db_STG_CURRENCY_AMOUNT + "," + "CURRENCY_AMOUNT was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //CURRENCY_CODE - mandatory validation
                                if ((db_STG_CURRENCY_CODE == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",CURRENCY_CODE," + "CURRENCY_CODE : " + db_STG_CURRENCY_CODE + "," + "CURRENCY_CODE was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",CURRENCY_CODE," + "CURRENCY_CODE : " + db_STG_CURRENCY_CODE + "," + "CURRENCY_CODE was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //EXCHANGE_RATE - mandatory validation
                                if (db_STG_CURRENCY_CODE.equals("GBP")) {
                                    String stg_header_id = "," + ",EXCHANGE_RATE," + "EXCHANGE_RATE : " + db_STG_EXCHANGE_RATE + "," + "EXCHANGE_RATE is not mandatory hence accepts NULL," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                } else if ((db_STG_EXCHANGE_RATE == null) && (STG_HDR_STATUS != "REVIEW")) {
                                    String stg_header_id = "," + ",EXCHANGE_RATE," + "EXCHANGE_RATE : " + db_STG_EXCHANGE_RATE + "," + "EXCHANGE_RATE was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",EXCHANGE_RATE," + "EXCHANGE_RATE : " + db_STG_EXCHANGE_RATE + "," + "EXCHANGE_RATE was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //EXCHANGE_RATE_TYPE - mandatory validation
                                if (db_STG_CURRENCY_CODE.equals("GBP")) {
                                    String stg_header_id = "," + ",EXCHANGE_RATE_TYPE," + "EXCHANGE_RATE_TYPE : " + db_STG_EXCHANGE_RATE_TYPE + "," + "EXCHANGE_RATE_TYPE is not mandatory hence accepts NULL," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                } else if ((db_STG_EXCHANGE_RATE_TYPE == null) && (STG_HDR_STATUS != "REVIEW")) {
                                    String stg_header_id = "," + ",EXCHANGE_RATE_TYPE," + "EXCHANGE_RATE_TYPE : " + db_STG_EXCHANGE_RATE_TYPE + "," + "EXCHANGE_RATE_TYPE was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",EXCHANGE_RATE_TYPE," + "EXCHANGE_RATE_TYPE : " + db_STG_EXCHANGE_RATE_TYPE + "," + "EXCHANGE_RATE_TYPE was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //BASE_CURRENCY_AMOUNT - mandatory validation
                                if ((db_STG_BASE_CURRENCY_AMOUNT == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",BASE_CURRENCY_AMOUNT," + "BASE_CURRENCY_AMOUNT : " + db_STG_BASE_CURRENCY_AMOUNT + "," + "BASE_CURRENCY_AMOUNT was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",BASE_CURRENCY_AMOUNT," + "BASE_CURRENCY_AMOUNT : " + db_STG_BASE_CURRENCY_AMOUNT + "," + "BASE_CURRENCY_AMOUNT was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //EVENT_CODE - mandatory validation
                                if ((db_STG_EVENT_CODE == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",EVENT_CODE," + "EVENT_CODE : " + db_STG_EVENT_CODE + "," + "EVENT_CODE was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",EVENT_CODE," + "EVENT_CODE : " + db_STG_EVENT_CODE + "," + "EVENT_CODE was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //ENTITY_TYPE_CODE - mandatory validation
                                if ((db_STG_ENTITY_TYPE_CODE == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",ENTITY_TYPE_CODE," + "ENTITY_TYPE_CODE : " + db_STG_ENTITY_TYPE_CODE + "," + "ENTITY_TYPE_CODE was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",ENTITY_TYPE_CODE," + "ENTITY_TYPE_CODE : " + db_STG_ENTITY_TYPE_CODE + "," + "ENTITY_TYPE_CODE was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }


                                //SUMMARY_FLAG - mandatory validation
                                if ((db_STG_SUMMARY_FLAG == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",SUMMARY_FLAG," + "SUMMARY_FLAG : " + db_STG_SUMMARY_FLAG + "," + "SUMMARY_FLAG was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",SUMMARY_FLAG," + "SUMMARY_FLAG : " + db_STG_SUMMARY_FLAG + "," + "SUMMARY_FLAG was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //CREDIT_IND - mandatory validation
                                if ((db_STG_CREDIT_IND == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",CREDIT_IND," + "CREDIT_IND : " + db_STG_CREDIT_IND + "," + "CREDIT_IND was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",CREDIT_IND," + "CREDIT_IND : " + db_STG_CREDIT_IND + "," + "CREDIT_IND was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }


                                //Comparing Consolidation table and Staging table
                                if (db_CONS_BC_HEADER_ID != null && db_STG_HEADER_ID != null) {
                                    if (db_CONS_BC_HEADER_ID.equals(db_STG_HEADER_ID)) {
                                        String STG_HEADER_ID = cons_stg_map_row + ",HEADER_ID," + db_STG_HEADER_ID + "," + db_CONS_BC_HEADER_ID + ",Pass";
                                        section1_results.add(STG_HEADER_ID);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",HEADER_ID" + "," + db_STG_HEADER_ID + "," + db_CONS_BC_HEADER_ID + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        cons_stg_map_row++;
                                    } else {
                                        String STG_HEADER_ID = cons_stg_map_row + ",HEADER_ID," + db_STG_HEADER_ID + "," + db_CONS_BC_HEADER_ID + ",Fail";
                                        section1_results.add(STG_HEADER_ID);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",HEADER_ID" + "," + db_STG_HEADER_ID + "," + db_CONS_BC_HEADER_ID + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        cons_stg_map_row++;
                                        CONS_flag++;
                                    }
                                }

                                //--------------------  Validation SOURCE ---------------
                                if (db_CONS_SOURCE.equals(db_STG_SOURCE)) {
                                    String STG_SOURCE = ",SOURCE," + db_STG_SOURCE + "," + db_CONS_SOURCE + ",Pass";
                                    section1_results.add(STG_SOURCE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SOURCE" + "," + db_STG_SOURCE + "," + db_CONS_SOURCE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_SOURCE = ",SOURCE," + db_STG_SOURCE + "," + db_CONS_SOURCE + ",Fail";
                                    section1_results.add(STG_SOURCE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SOURCE" + "," + db_STG_SOURCE + "," + db_CONS_SOURCE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation ACCOUNT_NUMBER ---------------
                                if (db_CONS_ACCOUNT_NUMBER.equals(db_STG_ACCOUNT_NUMBER)) {
                                    String STG_ACCOUNT_NUMBER = ",ACCOUNT_NUMBER," + db_STG_ACCOUNT_NUMBER + "," + db_CONS_ACCOUNT_NUMBER + ",Pass";
                                    section1_results.add(STG_ACCOUNT_NUMBER);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ACCOUNT_NUMBER" + "," + db_STG_ACCOUNT_NUMBER + "," + db_CONS_ACCOUNT_NUMBER + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_ACCOUNT_NUMBER = ",ACCOUNT_NUMBER," + db_STG_ACCOUNT_NUMBER + "," + db_CONS_ACCOUNT_NUMBER + ",Fail";
                                    section1_results.add(STG_ACCOUNT_NUMBER);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ACCOUNT_NUMBER" + "," + db_STG_ACCOUNT_NUMBER + "," + db_CONS_ACCOUNT_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation POLICY_NUMBER ---------------
                                if (db_CONS_POLICY_NUMBER.equals(db_STG_POLICY_NUMBER)) {
                                    String stg_policy_number = ",POLICY_NUMBER," + db_STG_POLICY_NUMBER + "," + db_CONS_POLICY_NUMBER + ",Pass";
                                    section1_results.add(stg_policy_number);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",POLICY_NUMBER" + "," + db_STG_POLICY_NUMBER + "," + db_CONS_POLICY_NUMBER + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String stg_policy_number = ",POLICY_NUMBER," + db_STG_POLICY_NUMBER + "," + db_CONS_POLICY_NUMBER + ",Fail";
                                    section1_results.add(stg_policy_number);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",POLICY_NUMBER" + "," + db_STG_POLICY_NUMBER + "," + db_CONS_POLICY_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation CLAIM_NUMBER ---------------
                                if (db_CONS_CLAIM_NUMBER.equals(db_STG_CLAIM_NUMBER)) {
                                    String stg_claim_number = ",CLAIM_NUMBER," + db_STG_CLAIM_NUMBER + "," + db_CONS_CLAIM_NUMBER + ",Pass";
                                    section1_results.add(stg_claim_number);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CLAIM_NUMBER" + "," + db_STG_CLAIM_NUMBER + "," + db_CONS_CLAIM_NUMBER + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String stg_claim_number = ",CLAIM_NUMBER," + db_STG_CLAIM_NUMBER + "," + db_CONS_CLAIM_NUMBER + ",Fail";
                                    section1_results.add(stg_claim_number);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CLAIM_NUMBER" + "," + db_STG_CLAIM_NUMBER + "," + db_CONS_CLAIM_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation LINE_OF_BUSINESS ---------------
                                if (db_CONS_LINE_OF_BUSINESS.equals(db_STG_LINE_OF_BUSINESS)) {
                                    String STG_LINE_OF_BUSINESS = ",LINE_OF_BUSINESS," + db_STG_LINE_OF_BUSINESS + "," + db_CONS_LINE_OF_BUSINESS + ",Pass";
                                    section1_results.add(STG_LINE_OF_BUSINESS);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",LINE_OF_BUSINESS" + "," + db_STG_LINE_OF_BUSINESS + "," + db_CONS_LINE_OF_BUSINESS + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_LINE_OF_BUSINESS = ",LINE_OF_BUSINESS," + db_STG_LINE_OF_BUSINESS + "," + db_CONS_LINE_OF_BUSINESS + ",Fail";
                                    section1_results.add(STG_LINE_OF_BUSINESS);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",LINE_OF_BUSINESS" + "," + db_STG_LINE_OF_BUSINESS + "," + db_CONS_LINE_OF_BUSINESS + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation TRANSACTION_REFERENCE ---------------
                                if (db_CONS_TRANSACTION_REFERENCE.equalsIgnoreCase(db_STG_TRANSACTION_REFERENCE)) {
                                    String STG_TRANSACTION_REFERENCE = ",TRANSACTION_REFERENCE," + db_STG_TRANSACTION_REFERENCE + "," + db_CONS_TRANSACTION_REFERENCE + ",Pass";
                                    section1_results.add(STG_TRANSACTION_REFERENCE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_REFERENCE" + "," + db_STG_TRANSACTION_REFERENCE + "," + db_CONS_TRANSACTION_REFERENCE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_TRANSACTION_REFERENCE = ",TRANSACTION_REFERENCE," + db_STG_TRANSACTION_REFERENCE + "," + db_CONS_TRANSACTION_REFERENCE + ",Fail";
                                    section1_results.add(STG_TRANSACTION_REFERENCE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_REFERENCE" + "," + db_STG_TRANSACTION_REFERENCE + "," + db_CONS_TRANSACTION_REFERENCE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation TRANSACTION_DATE ---------------
                                String db_STG_TRANSACTION_DATEModified = db_STG_TRANSACTION_DATE.substring(0, 10);
                                String db_CONS_TRANSACTION_DATEModified = db_CONS_TRANSACTION_DATE.substring(0, 10);
                                if (db_CONS_TRANSACTION_DATEModified.equals(db_STG_TRANSACTION_DATEModified)) {
                                    String cons_TRANSACTION_DATE = ",TRANSACTION_DATE," + db_STG_TRANSACTION_DATEModified + "," + db_CONS_TRANSACTION_DATEModified + ",Pass";
                                    section1_results.add(cons_TRANSACTION_DATE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATEModified + "," + db_CONS_TRANSACTION_DATEModified + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_TRANSACTION_DATE = ",TRANSACTION_DATE," + db_STG_TRANSACTION_DATEModified + "," + db_CONS_TRANSACTION_DATEModified + ",Fail";
                                    section1_results.add(cons_TRANSACTION_DATE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATEModified + "," + db_CONS_TRANSACTION_DATEModified + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation TRANSACTION_SUBTYPE ---------------
                                if (db_CONS_TRANSACTION_SUBTYPE.equals(db_STG_TRANSACTION_SUBTYPE)) {
                                    String STG_TRANSACTION_SUBTYPE = ",TRANSACTION_SUBTYPE," + db_STG_TRANSACTION_SUBTYPE + "," + db_CONS_TRANSACTION_SUBTYPE + ",Pass";
                                    section1_results.add(STG_TRANSACTION_SUBTYPE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_SUBTYPE" + "," + db_STG_TRANSACTION_SUBTYPE + "," + db_CONS_TRANSACTION_SUBTYPE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_TRANSACTION_SUBTYPE = ",TRANSACTION_SUBTYPE," + db_STG_TRANSACTION_SUBTYPE + "," + db_CONS_TRANSACTION_SUBTYPE + ",Fail";
                                    section1_results.add(STG_TRANSACTION_SUBTYPE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_SUBTYPE" + "," + db_STG_TRANSACTION_SUBTYPE + "," + db_CONS_TRANSACTION_SUBTYPE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation BANK_ACC ---------------
                                if (db_STG_BANK_ACC != null && db_CONS_BANK_ACC != null) {
                                    String db_STG_BANK_ACCModified = db_STG_BANK_ACC.replaceAll("\\.0*$", "");
                                    if (db_CONS_BANK_ACC.equals(db_STG_BANK_ACCModified)) {
                                        String STG_BANK_ACC = ",BANK_ACC," + db_STG_BANK_ACCModified + "," + db_CONS_BANK_ACC + ",Pass";
                                        section1_results.add(STG_BANK_ACC);
                                    } else {
                                        String STG_BANK_ACC = ",BANK_ACC," + db_STG_BANK_ACCModified + "," + db_CONS_BANK_ACC + ",Fail";
                                        section1_results.add(STG_BANK_ACC);
                                    }
                                } else if (db_STG_BANK_ACC == null && db_CONS_BANK_ACC == null) {
                                    String STG_BANK_ACC = ",BANK_ACC," + db_STG_BANK_ACC + "," + db_CONS_BANK_ACC + ",Pass";
                                    section1_results.add(STG_BANK_ACC);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BANK_ACC" + "," + db_STG_BANK_ACC + "," + db_CONS_BANK_ACC + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_BANK_ACC = ",BANK_ACC," + db_STG_BANK_ACC + "," + db_CONS_BANK_ACC + ",Fail";
                                    section1_results.add(STG_BANK_ACC);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BANK_ACC" + "," + db_STG_BANK_ACC + "," + db_CONS_BANK_ACC + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation PAYMENT_METHOD ---------------
                                if (db_STG_PAYMENT_METHOD != null && db_CONS_PAYMENT_METHOD != null) {
                                    if (db_CONS_PAYMENT_METHOD.equals(db_STG_PAYMENT_METHOD)) {
                                        String STG_BANK_ACC = ",PAYMENT_METHOD," + db_STG_PAYMENT_METHOD + "," + db_CONS_PAYMENT_METHOD + ",Pass";
                                        section1_results.add(STG_BANK_ACC);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAYMENT_METHOD" + "," + db_STG_PAYMENT_METHOD + "," + db_CONS_PAYMENT_METHOD + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String STG_BANK_ACC = ",PAYMENT_METHOD," + db_STG_PAYMENT_METHOD + "," + db_CONS_PAYMENT_METHOD + ",Fail";
                                        section1_results.add(STG_BANK_ACC);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAYMENT_METHOD" + "," + db_STG_PAYMENT_METHOD + "," + db_CONS_PAYMENT_METHOD + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                } else if (db_STG_PAYMENT_METHOD == null && db_CONS_PAYMENT_METHOD == null) {
                                    String STG_BANK_ACC = ",PAYMENT_METHOD," + db_STG_PAYMENT_METHOD + "," + db_CONS_PAYMENT_METHOD + ",Pass";
                                    section1_results.add(STG_BANK_ACC);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAYMENT_METHOD" + "," + db_STG_PAYMENT_METHOD + "," + db_CONS_PAYMENT_METHOD + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_BANK_ACC = ",PAYMENT_METHOD," + db_STG_PAYMENT_METHOD + "," + db_CONS_PAYMENT_METHOD + ",Fail";
                                    section1_results.add(STG_BANK_ACC);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAYMENT_METHOD" + "," + db_STG_PAYMENT_METHOD + "," + db_CONS_PAYMENT_METHOD + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation CHANNEL ---------------
                                if (db_CONS_CHANNEL.equals(db_STG_CHANNEL)) {
                                    String STG_CHANNEL = ",CHANNEL," + db_STG_CHANNEL + "," + db_CONS_CHANNEL + ",Pass";
                                    section1_results.add(STG_CHANNEL);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CHANNEL" + "," + db_STG_CHANNEL + "," + db_CONS_CHANNEL + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_CHANNEL = ",CHANNEL," + db_STG_CHANNEL + "," + db_CONS_CHANNEL + ",Fail";
                                    section1_results.add(STG_CHANNEL);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CHANNEL" + "," + db_STG_CHANNEL + "," + db_CONS_CHANNEL + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //TODO - confirmation required
                                //--------------------  Validation INTEREST_AMOUNT ---------------
                                if (db_CONS_INTEREST_AMOUNT.equals(db_STG_INTEREST_AMOUNT)) {
                                    String STG_INTEREST_AMOUNT = ",INTEREST_AMOUNT," + db_STG_INTEREST_AMOUNT + "," + db_CONS_INTEREST_AMOUNT + ",Pass";
                                    section1_results.add(STG_INTEREST_AMOUNT);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",INTEREST_AMOUNT" + "," + db_STG_INTEREST_AMOUNT + "," + db_CONS_INTEREST_AMOUNT + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_INTEREST_AMOUNT = ",INTEREST_AMOUNT," + db_STG_INTEREST_AMOUNT + "," + db_CONS_INTEREST_AMOUNT + ",Fail";
                                    section1_results.add(STG_INTEREST_AMOUNT);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",INTEREST_AMOUNT" + "," + db_STG_INTEREST_AMOUNT + "," + db_CONS_INTEREST_AMOUNT + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                /*//--------------------  Validation INTEREST_CURRENCY_CODE ---------------
                                if (db_CONS_INTEREST_CURRENCY_CODE.equals(db_STG_INTEREST_CURRENCY_CODE)) {
                                    String STG_INTEREST_CURRENCY_CODE = ",INTEREST_CURRENCY_CODE," + db_STG_INTEREST_CURRENCY_CODE + "," + db_CONS_INTEREST_CURRENCY_CODE + ",Pass";
                                    section1_results.add(STG_INTEREST_CURRENCY_CODE);
                                } else {
                                    String STG_INTEREST_CURRENCY_CODE = ",INTEREST_CURRENCY_CODE," + db_STG_INTEREST_CURRENCY_CODE + "," + db_CONS_INTEREST_CURRENCY_CODE + ",Fail";
                                    section1_results.add(STG_INTEREST_CURRENCY_CODE);
                                }*/

                                //TODO - confirmation required
                                //--------------------  Validation BASE_INTEREST_AMOUNT ---------------
                                if (db_CONS_BASE_INTEREST_AMOUNT.equals(db_STG_BASE_INTEREST_AMOUNT)) {
                                    String STG_BASE_INTEREST_AMOUNT = ",BASE_INTEREST_AMOUNT," + db_STG_BASE_INTEREST_AMOUNT + "," + db_CONS_BASE_INTEREST_AMOUNT + ",Pass";
                                    section1_results.add(STG_BASE_INTEREST_AMOUNT);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BASE_INTEREST_AMOUNT" + "," + db_STG_BASE_INTEREST_AMOUNT + "," + db_CONS_BASE_INTEREST_AMOUNT + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_BASE_INTEREST_AMOUNT = ",BASE_INTEREST_AMOUNT," + db_STG_BASE_INTEREST_AMOUNT + "," + db_CONS_BASE_INTEREST_AMOUNT + ",Fail";
                                    section1_results.add(STG_BASE_INTEREST_AMOUNT);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BASE_INTEREST_AMOUNT" + "," + db_STG_BASE_INTEREST_AMOUNT + "," + db_CONS_BASE_INTEREST_AMOUNT + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }


                                //--------------------  Validation TAX_DEDUCTIBLE ---------------
                                if (db_CONS_TAX_DEDUCTIBLE.equals(db_STG_TAX_DEDUCTIBLE)) {
                                    String STG_TAX_DEDUCTIBLE = ",TAX_DEDUCTIBLE," + db_STG_TAX_DEDUCTIBLE + "," + db_CONS_TAX_DEDUCTIBLE + ",Pass";
                                    section1_results.add(STG_TAX_DEDUCTIBLE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TAX_DEDUCTIBLE" + "," + db_STG_TAX_DEDUCTIBLE + "," + db_CONS_TAX_DEDUCTIBLE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_TAX_DEDUCTIBLE = ",TAX_DEDUCTIBLE," + db_STG_TAX_DEDUCTIBLE + "," + db_CONS_TAX_DEDUCTIBLE + ",Fail";
                                    section1_results.add(STG_TAX_DEDUCTIBLE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TAX_DEDUCTIBLE" + "," + db_STG_TAX_DEDUCTIBLE + "," + db_CONS_TAX_DEDUCTIBLE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation REVERSAL_INDICATOR ---------------
                                if (db_CONS_REVERSAL_INDICATOR.equals(db_STG_REVERSAL_INDICATOR)) {
                                    String STG_REVERSAL_INDICATOR = ",REVERSAL_INDICATOR," + db_STG_REVERSAL_INDICATOR + "," + db_CONS_REVERSAL_INDICATOR + ",Pass";
                                    section1_results.add(STG_REVERSAL_INDICATOR);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",REVERSAL_INDICATOR" + "," + db_STG_REVERSAL_INDICATOR + "," + db_CONS_REVERSAL_INDICATOR + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_REVERSAL_INDICATOR = ",REVERSAL_INDICATOR," + db_STG_REVERSAL_INDICATOR + "," + db_CONS_REVERSAL_INDICATOR + ",Fail";
                                    section1_results.add(STG_REVERSAL_INDICATOR);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",REVERSAL_INDICATOR" + "," + db_STG_REVERSAL_INDICATOR + "," + db_CONS_REVERSAL_INDICATOR + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation PAYMENT_TRANSACTION_TYPE_ID ---------------
                                if (db_CONS_PAYMENT_TRANSACTION_TYPE_ID != null && db_STG_PAYMENT_TRANSACTION_TYPE_ID != null) {
                                    if (db_CONS_PAYMENT_TRANSACTION_TYPE_ID.equalsIgnoreCase(db_STG_PAYMENT_TRANSACTION_TYPE_ID)) {
                                        String STG_BANK_ACC = ",PAYMENT_TRANSACTION_TYPE_ID," + db_STG_PAYMENT_TRANSACTION_TYPE_ID + "," + db_CONS_PAYMENT_TRANSACTION_TYPE_ID + ",Pass";
                                        section1_results.add(STG_BANK_ACC);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAYMENT_TRANSACTION_TYPE_ID" + "," + db_STG_PAYMENT_TRANSACTION_TYPE_ID + "," + db_CONS_PAYMENT_TRANSACTION_TYPE_ID + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String STG_BANK_ACC = ",PAYMENT_TRANSACTION_TYPE_ID," + db_STG_PAYMENT_TRANSACTION_TYPE_ID + "," + db_CONS_PAYMENT_TRANSACTION_TYPE_ID + ",Fail";
                                        section1_results.add(STG_BANK_ACC);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAYMENT_TRANSACTION_TYPE_ID" + "," + db_STG_PAYMENT_TRANSACTION_TYPE_ID + "," + db_CONS_PAYMENT_TRANSACTION_TYPE_ID + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                } else if (db_STG_PAYMENT_TRANSACTION_TYPE_ID == null && db_CONS_PAYMENT_TRANSACTION_TYPE_ID == null) {
                                    String STG_BANK_ACC = ",PAYMENT_TRANSACTION_TYPE_ID," + db_STG_PAYMENT_TRANSACTION_TYPE_ID + "," + db_CONS_PAYMENT_TRANSACTION_TYPE_ID + ",Pass";
                                    section1_results.add(STG_BANK_ACC);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAYMENT_TRANSACTION_TYPE_ID" + "," + db_STG_PAYMENT_TRANSACTION_TYPE_ID + "," + db_CONS_PAYMENT_TRANSACTION_TYPE_ID + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_BANK_ACC = ",PAYMENT_TRANSACTION_TYPE_ID," + db_STG_PAYMENT_TRANSACTION_TYPE_ID + "," + db_CONS_PAYMENT_TRANSACTION_TYPE_ID + ",Fail";
                                    section1_results.add(STG_BANK_ACC);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAYMENT_TRANSACTION_TYPE_ID" + "," + db_STG_PAYMENT_TRANSACTION_TYPE_ID + "," + db_CONS_PAYMENT_TRANSACTION_TYPE_ID + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation CURRENCY_CODE ---------------
                                if (db_CONS_CURRENCY_CODE.equals(db_STG_CURRENCY_CODE)) {
                                    String STG_CURRENCY_CODE = ",CURRENCY_CODE," + db_STG_CURRENCY_CODE + "," + db_CONS_CURRENCY_CODE + ",Pass";
                                    section1_results.add(STG_CURRENCY_CODE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CURRENCY_CODE" + "," + db_STG_CURRENCY_CODE + "," + db_CONS_CURRENCY_CODE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_CURRENCY_CODE = ",CURRENCY_CODE," + db_STG_CURRENCY_CODE + "," + db_CONS_CURRENCY_CODE + ",Fail";
                                    section1_results.add(STG_CURRENCY_CODE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CURRENCY_CODE" + "," + db_STG_CURRENCY_CODE + "," + db_CONS_CURRENCY_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }


                                //--------------------  Validation EXCHANGE_RATE     ---------------
                                if (db_CONS_EXCHANGE_RATE.equals(db_STG_EXCHANGE_RATE)) {
                                    String STG_EXCHANGE_RATE = ",EXCHANGE_RATE," + db_STG_EXCHANGE_RATE + "," + db_CONS_EXCHANGE_RATE + ",Pass";
                                    section1_results.add(STG_EXCHANGE_RATE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",EXCHANGE_RATE" + "," + db_STG_EXCHANGE_RATE + "," + db_CONS_EXCHANGE_RATE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_EXCHANGE_RATE = ",EXCHANGE_RATE," + db_STG_EXCHANGE_RATE + "," + db_CONS_EXCHANGE_RATE + ",Fail";
                                    section1_results.add(STG_EXCHANGE_RATE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",EXCHANGE_RATE" + "," + db_STG_EXCHANGE_RATE + "," + db_CONS_EXCHANGE_RATE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation EXCHANGE_RATE_TYPE ---------------
                                if (db_CONS_EXCHANGE_RATE_TYPE.equals(db_STG_EXCHANGE_RATE_TYPE)) {
                                    String STG_EXCHANGE_RATE_TYPE = ",EXCHANGE_RATE_TYPE," + db_STG_EXCHANGE_RATE_TYPE + "," + db_CONS_EXCHANGE_RATE_TYPE + ",Pass";
                                    section1_results.add(STG_EXCHANGE_RATE_TYPE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",EXCHANGE_RATE_TYPE" + "," + db_STG_EXCHANGE_RATE_TYPE + "," + db_CONS_EXCHANGE_RATE_TYPE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_EXCHANGE_RATE_TYPE = ",EXCHANGE_RATE_TYPE," + db_STG_EXCHANGE_RATE_TYPE + "," + db_CONS_EXCHANGE_RATE_TYPE + ",Fail";
                                    section1_results.add(STG_EXCHANGE_RATE_TYPE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",EXCHANGE_RATE_TYPE" + "," + db_STG_EXCHANGE_RATE_TYPE + "," + db_CONS_EXCHANGE_RATE_TYPE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation LOSS_DATE ---------------
                                if (db_STG_LOSS_DATE != null && db_CONS_LOSS_DATE != null) {
                                    String db_STG_LOSS_DATEModified = db_STG_LOSS_DATE.substring(0, 10);
                                    String db_CONS_LOSS_DATEModified = db_CONS_LOSS_DATE.substring(0, 10);
                                    if (db_CONS_LOSS_DATEModified.equals(db_STG_LOSS_DATEModified)) {
                                        String cons_LOSS_DATE = ",LOSS_DATE," + db_STG_LOSS_DATEModified + "," + db_CONS_LOSS_DATEModified + ",Pass";
                                        section1_results.add(cons_LOSS_DATE);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",LOSS_DATE" + "," + db_STG_LOSS_DATEModified + "," + db_CONS_LOSS_DATEModified + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String cons_LOSS_DATE = ",LOSS_DATE," + db_STG_LOSS_DATEModified + "," + db_CONS_LOSS_DATEModified + ",Fail";
                                        section1_results.add(cons_LOSS_DATE);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",LOSS_DATE" + "," + db_STG_LOSS_DATEModified + "," + db_CONS_LOSS_DATEModified + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                } else if (db_STG_LOSS_DATE == null && db_CONS_LOSS_DATE == null) {
                                    String STG_BANK_ACC = ",LOSS_DATE," + db_STG_LOSS_DATE + "," + db_CONS_LOSS_DATE + ",Pass";
                                    section1_results.add(STG_BANK_ACC);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",LOSS_DATE" + "," + db_STG_LOSS_DATE + "," + db_CONS_LOSS_DATE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_BANK_ACC = ",LOSS_DATE," + db_STG_LOSS_DATE + "," + db_CONS_LOSS_DATE + ",Fail";
                                    section1_results.add(STG_BANK_ACC);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",LOSS_DATE" + "," + db_STG_LOSS_DATE + "," + db_CONS_LOSS_DATE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation PRODUCT     ---------------
                                if (db_CONS_PRODUCT.equals(db_STG_PRODUCT)) {
                                    String STG_PRODUCT = ",PRODUCT," + db_STG_PRODUCT + "," + db_CONS_PRODUCT + ",Pass";
                                    section1_results.add(STG_PRODUCT);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT" + "," + db_STG_PRODUCT + "," + db_CONS_PRODUCT + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_PRODUCT = ",PRODUCT," + db_STG_PRODUCT + "," + db_CONS_PRODUCT + ",Fail";
                                    section1_results.add(STG_PRODUCT);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT" + "," + db_STG_PRODUCT + "," + db_CONS_PRODUCT + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation FSH_ATTRIBUTE_01     ---------------
                                if (db_CONS_GL_STRING.equals(db_STG_FSH_ATTRIBUTE_01)) {
                                    String STG_FSH_ATTRIBUTE_01 = ",FSH_ATTRIBUTE_01," + db_STG_FSH_ATTRIBUTE_01 + "," + db_CONS_GL_STRING + ",Pass";
                                    section1_results.add(STG_FSH_ATTRIBUTE_01);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",FSH_ATTRIBUTE_01" + "," + db_STG_FSH_ATTRIBUTE_01 + "," + db_CONS_GL_STRING + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_FSH_ATTRIBUTE_01 = ",FSH_ATTRIBUTE_01," + db_STG_FSH_ATTRIBUTE_01 + "," + db_CONS_GL_STRING + ",Fail";
                                    section1_results.add(STG_FSH_ATTRIBUTE_01);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",FSH_ATTRIBUTE_01" + "," + db_STG_FSH_ATTRIBUTE_01 + "," + db_CONS_GL_STRING + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation PRODUCT_KEY     ---------------
                                if (db_CONS_LPI_CODE.equals(db_STG_PRODUCT_KEY)) {
                                    String STG_PRODUCT_KEY = ",PRODUCT_KEY," + db_STG_PRODUCT_KEY + "," + db_CONS_LPI_CODE + ",Pass";
                                    section1_results.add(STG_PRODUCT_KEY);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT_KEY" + "," + db_STG_PRODUCT_KEY + "," + db_CONS_LPI_CODE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String STG_PRODUCT_KEY = ",PRODUCT_KEY," + db_STG_PRODUCT_KEY + "," + db_CONS_LPI_CODE + ",Fail";
                                    section1_results.add(STG_PRODUCT_KEY);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT_KEY" + "," + db_STG_PRODUCT_KEY + "," + db_CONS_LPI_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }


                                //----------------------- STANDARDISATION start here -----------------------------
                                String db_lookup_underwriter_meaning = "null";
                                String db_lookup_product_type_meaning = "null";
                                String db_lookup_line_of_business_meaning = "null";
                                String db_lookup_brand_meaning = "null";
                                String db_lookup_channel_meaning = "null";
                                String db_lookup_transaction_reason_meaning = "null";
                                String db_lookup_SUN_NUMBER_meaning = "null";
                                String db_lookup_event_code_meaning = "null";
                                String db_lookup_entity_type_code_meaning = "null";
                                String db_lookup_summary_flag_meaning = "null";
                                String db_lookup_MID_NUMBER_meaning = "null";
                                String db_lookup_DDI_REFERENCE_meaning = "null";
                                String db_lookup_PAY_IN_SLIP_NUMBER_meaning = "null";
                                String db_lookup_CARD_TYPE_meaning = "null";
                                String db_lookup_BACS_NARRATIVE_meaning = "null";
                                String db_lookup_ORDER_NUMBER_meaning = "null";
                                String db_lookup_credit_ind_meaning = "null";
                                String db_lookup_PERIL_CODE_meaning = "null";
                                String db_lookup_EVENT_CODE_meaning = "null";
                                String db_lookup_ENTITY_TYPE_CODE_meaning = "null";
                                String db_lookup_SUMMARY_FLAG_meaning = "null";


                                //------------------------ UnderWriter Validation -----------------
                                String LandscapeGLClaimcash_fsh_lookup = connect_db.executeQuery_DB("Lookup", "FSH_LOOKUP","LANDSCAPE");
                                String fsh_source = connect_db.executeQuery_DB("Lookup", "FSH_LOOKUP_SOURCE_LandscapeGLClaimcash","LANDSCAPE");
                                if (db_CONS_UNDERWRITER == (null)) {

                                    SQLResultset = SQLstmt.executeQuery(LandscapeGLClaimcash_fsh_lookup + " LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'UNDERWRITER'" + fsh_source);

                                    //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'UNDERWRITER' and System = 'LAND'  and PATTERN = 'GLClaimCash'");
                                    while (SQLResultset.next()) {
                                        db_lookup_underwriter_meaning = SQLResultset.getString("MEANING");
                                    }

                                    if (db_lookup_underwriter_meaning.equals("null")) {
                                        String lookup_underWriter_meaning = ",UNDERWRITER LOOKUP," + "LookUp value not found" + "," + db_STG_UNDERWRITER + ",Fail";
                                        section1_results.add(lookup_underWriter_meaning);
                                        String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",UNDERWRITER lookup" + "," + "LookUp value not found" + "," + db_STG_UNDERWRITER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_underWriter_meaning);
                                        CONS_flag++;
                                    } else if (db_lookup_underwriter_meaning != null) {
                                        if (db_lookup_underwriter_meaning.equals(db_STG_UNDERWRITER)) {
                                            String lookup_underWriter_meaning = ",UNDERWRITER LOOKUP," + db_lookup_underwriter_meaning + "," + db_STG_UNDERWRITER + ",Pass";
                                            section1_results.add(lookup_underWriter_meaning);
                                            String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",UNDERWRITER lookup" + "," + db_lookup_underwriter_meaning + "," + db_STG_UNDERWRITER + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_underWriter_meaning);
                                        } else {
                                            String lookup_underWriter_meaning = ",UNDERWRITER LOOKUP," + db_lookup_underwriter_meaning + "," + db_STG_UNDERWRITER + ",Fail";
                                            section1_results.add(lookup_underWriter_meaning);
                                            String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",UNDERWRITER lookup" + "," + db_lookup_underwriter_meaning + "," + db_STG_UNDERWRITER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_underWriter_meaning);
                                            CONS_flag++;
                                        }
                                    }
                                } else {
                                    if (db_CONS_UNDERWRITER.equals(db_STG_UNDERWRITER)) {
                                        String STG_UNDERWRITER = ",UNDERWRITER," + db_STG_UNDERWRITER + "," + db_CONS_UNDERWRITER + ",Pass";
                                        section1_results.add(STG_UNDERWRITER);
                                        String tbl_header_id = section2_map_row + section2_map_row + "," + header + "," + Source + "," + pattern + ",UNDERWRITER" + "," + db_STG_UNDERWRITER + "," + db_CONS_UNDERWRITER + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String STG_UNDERWRITER = ",UNDERWRITER," + db_STG_UNDERWRITER + "," + db_CONS_UNDERWRITER + ",Fail";
                                        section1_results.add(STG_UNDERWRITER);
                                        String tbl_header_id = section2_map_row + section2_map_row + "," + header + "," + Source + "," + pattern + ",UNDERWRITER" + "," + db_STG_UNDERWRITER + "," + db_CONS_UNDERWRITER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //------------------------ BRAND Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(LandscapeGLClaimcash_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_CONS_BRAND + "' and LOOKUP_TYPE = 'BRAND'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_BRAND + "' and LOOKUP_TYPE = 'BRAND' and System = 'LAND'  and PATTERN = 'GLClaimCash'");
                                while (SQLResultset.next()) {
                                    db_lookup_brand_meaning = SQLResultset.getString("MEANING");
                                }

                                if (db_lookup_brand_meaning.equals("null")) {
                                    String lookup_brand_meaning = ",BRAND lookup," + "LookUp value not found" + "," + db_STG_BRAND + ",Fail";
                                    section1_results.add(lookup_brand_meaning);
                                    String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",BRAND lookup" + "," + "LookUp value not found" + "," + db_STG_BRAND + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_underWriter_meaning);
                                    CONS_flag++;
                                } else if (db_lookup_brand_meaning != null) {
                                    if (db_lookup_brand_meaning.equals(db_STG_BRAND)) {
                                        String lookup_brand_meaning = ",BRAND lookup," + db_lookup_brand_meaning + "," + db_STG_BRAND + ",Pass";
                                        section1_results.add(lookup_brand_meaning);
                                        String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",BRAND lookup" + "," + db_lookup_brand_meaning + "," + db_STG_BRAND + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_underWriter_meaning);
                                    } else {
                                        String lookup_brand_meaning = ",BRAND lookup," + db_lookup_brand_meaning + "," + db_STG_BRAND + ",Fail";
                                        section1_results.add(lookup_brand_meaning);
                                        String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",BRAND lookup" + "," + db_lookup_brand_meaning + "," + db_STG_BRAND + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_underWriter_meaning);
                                        CONS_flag++;
                                    }
                                }


                                //------------------------ PRODUCT_TYPE Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(LandscapeGLClaimcash_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_CONS_PRODUCT_TYPE + "' and LOOKUP_TYPE = 'PRODUCT_TYPE'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_PRODUCT_TYPE + "' and LOOKUP_TYPE = 'PRODUCT_TYPE' and System = 'LAND'  and PATTERN = 'GLClaimCash'");
                                while (SQLResultset.next()) {
                                    db_lookup_product_type_meaning = SQLResultset.getString("MEANING");
                                }

                                if (db_lookup_product_type_meaning.equals("null")) {
                                    String lookup_product_type_meaning = ",PRODUCT_TYPE LOOKUP," + "LookUp value not found" + "," + db_STG_PRODUCT_TYPE + ",Fail";
                                    section1_results.add(lookup_product_type_meaning);
                                    String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT_TYPE lookup" + "," + "LookUp value not found" + "," + db_STG_PRODUCT_TYPE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_underWriter_meaning);
                                    CONS_flag++;
                                } else if (db_lookup_product_type_meaning != null) {
                                    if (db_lookup_product_type_meaning.equals(db_STG_PRODUCT_TYPE)) {
                                        String lookup_product_type_meaning = ",PRODUCT_TYPE LOOKUP," + db_lookup_product_type_meaning + "," + db_STG_PRODUCT_TYPE + ",Pass";
                                        section1_results.add(lookup_product_type_meaning);
                                        String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT_TYPE lookup" + "," + db_lookup_product_type_meaning + "," + db_STG_PRODUCT_TYPE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_underWriter_meaning);
                                    } else {
                                        String lookup_product_type_meaning = ",PRODUCT_TYPE LOOKUP," + db_lookup_product_type_meaning + "," + db_STG_PRODUCT_TYPE + ",Fail";
                                        section1_results.add(lookup_product_type_meaning);
                                        String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT_TYPE lookup" + "," + db_lookup_product_type_meaning + "," + db_STG_PRODUCT_TYPE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_underWriter_meaning);
                                        CONS_flag++;
                                    }
                                }

                                //------------------------ TRANSACTION_REASON Validation -----------------

                                if (db_CONS_TRANSACTION_REASON == (null)) {
                                    SQLResultset = SQLstmt.executeQuery(LandscapeGLClaimcash_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'TRANSACTION_REASON'" + fsh_source);
                                    //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'TRANSACTION_REASON' and System = 'LAND'  and PATTERN = 'GLClaimCash'");
                                    while (SQLResultset.next()) {
                                        db_lookup_transaction_reason_meaning = SQLResultset.getString("MEANING");
                                    }

                                    if (db_lookup_transaction_reason_meaning.equals("null")) {
                                        String lookup_transaction_reason_meaning = ",TRANSACTION_REASON LOOKUP," + "LookUp value not found" + "," + db_STG_TRANSACTION_REASON + ",Fail";
                                        section1_results.add(lookup_transaction_reason_meaning);
                                        String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_REASON lookup" + "," + "LookUp value not found" + "," + db_STG_TRANSACTION_REASON + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_underWriter_meaning);
                                        CONS_flag++;
                                    } else if (db_lookup_transaction_reason_meaning != null) {
                                        if (db_lookup_transaction_reason_meaning.equals(db_STG_TRANSACTION_REASON)) {
                                            String lookup_transaction_reason_meaning = ",TRANSACTION_REASON LOOKUP," + db_lookup_transaction_reason_meaning + "," + db_STG_TRANSACTION_REASON + ",Pass";
                                            section1_results.add(lookup_transaction_reason_meaning);
                                            String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_REASON lookup" + "," + db_lookup_transaction_reason_meaning + "," + db_STG_TRANSACTION_REASON + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_underWriter_meaning);
                                        } else {
                                            String lookup_transaction_reason_meaning = ",TRANSACTION_REASON LOOKUP," + db_lookup_transaction_reason_meaning + "," + db_STG_TRANSACTION_REASON + ",Fail";
                                            section1_results.add(lookup_transaction_reason_meaning);
                                            String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_REASON lookup" + "," + db_lookup_transaction_reason_meaning + "," + db_STG_TRANSACTION_REASON + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_underWriter_meaning);
                                            CONS_flag++;
                                        }
                                    }
                                } else {
                                    if (db_CONS_TRANSACTION_REASON.equalsIgnoreCase(db_STG_TRANSACTION_REASON)) {
                                        String STG_TRANSACTION_REASON = ",TRANSACTION_REASON," + db_STG_TRANSACTION_REASON + "," + db_CONS_TRANSACTION_REASON + ",Pass";
                                        section1_results.add(STG_TRANSACTION_REASON);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_REASON" + "," + db_STG_TRANSACTION_REASON + "," + db_CONS_TRANSACTION_REASON + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String STG_TRANSACTION_REASON = ",TRANSACTION_REASON," + db_STG_TRANSACTION_REASON + "," + db_CONS_TRANSACTION_REASON + ",Fail";
                                        section1_results.add(STG_TRANSACTION_REASON);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_REASON" + "," + db_STG_TRANSACTION_REASON + "," + db_CONS_TRANSACTION_REASON + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }


                                //------------------------ SUN_NUMBER Validation -----------------
                                if (db_CONS_SUN_NUMBER == (null)) {
                                    SQLResultset = SQLstmt.executeQuery(LandscapeGLClaimcash_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'SUN_NUMBER'" + fsh_source);
                                    //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'SUN_NUMBER' and System = 'LAND'  and PATTERN = 'GLClaimCash'");
                                    while (SQLResultset.next()) {
                                        db_lookup_SUN_NUMBER_meaning = SQLResultset.getString("MEANING");
                                    }

                                    if (db_lookup_SUN_NUMBER_meaning.equals("null")) {
                                        String lookup_SUN_NUMBER_meaning = ",SUN_NUMBER LOOKUP," + "LookUp value not found" + "," + db_STG_SUN_NUMBER + ",Fail";
                                        section1_results.add(lookup_SUN_NUMBER_meaning);
                                        String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",SUN_NUMBER lookup" + "," + "LookUp value not found" + "," + db_STG_SUN_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_underWriter_meaning);
                                        CONS_flag++;
                                    } else if (db_lookup_SUN_NUMBER_meaning != null) {
                                        if (db_lookup_SUN_NUMBER_meaning.equals(db_STG_SUN_NUMBER)) {
                                            String lookup_SUN_NUMBER_meaning = ",SUN_NUMBER LOOKUP," + db_lookup_SUN_NUMBER_meaning + "," + db_STG_SUN_NUMBER + ",Pass";
                                            section1_results.add(lookup_SUN_NUMBER_meaning);
                                            String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",SUN_NUMBER lookup" + "," + db_lookup_SUN_NUMBER_meaning + "," + db_STG_SUN_NUMBER + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_underWriter_meaning);
                                        } else {
                                            String lookup_SUN_NUMBER_meaning = ",SUN_NUMBER LOOKUP," + db_lookup_SUN_NUMBER_meaning + "," + db_STG_SUN_NUMBER + ",Fail";
                                            section1_results.add(lookup_SUN_NUMBER_meaning);
                                            String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",SUN_NUMBER lookup" + "," + db_lookup_SUN_NUMBER_meaning + "," + db_STG_SUN_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_underWriter_meaning);
                                            CONS_flag++;
                                        }
                                    }
                                } else {
                                    String db_CONS_SUN_NUMBERModified = db_CONS_SUN_NUMBER.replaceAll("\\.0*$", "");
                                    if (db_CONS_SUN_NUMBERModified.equals(db_STG_SUN_NUMBER)) {
                                        String STG_SUN_NUMBER = ",SUN_NUMBER," + db_STG_SUN_NUMBER + "," + db_CONS_SUN_NUMBERModified + ",Pass";
                                        section1_results.add(STG_SUN_NUMBER);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SUN_NUMBER" + "," + db_STG_SUN_NUMBER + "," + db_CONS_SUN_NUMBERModified + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String STG_SUN_NUMBER = ",SUN_NUMBER," + db_STG_SUN_NUMBER + "," + db_CONS_SUN_NUMBERModified + ",Fail";
                                        section1_results.add(STG_SUN_NUMBER);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SUN_NUMBER" + "," + db_STG_SUN_NUMBER + "," + db_CONS_SUN_NUMBERModified + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //------------------------ MID_NUMBER Validation -----------------
                                if (db_CONS_MID_NUMBER == (null)) {
                                    SQLResultset = SQLstmt.executeQuery(LandscapeGLClaimcash_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'MID_NUMBER'" + fsh_source);
                                    //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'MID_NUMBER' and System = 'LAND'  and PATTERN = 'GLClaimCash'");
                                    while (SQLResultset.next()) {
                                        db_lookup_MID_NUMBER_meaning = SQLResultset.getString("MEANING");
                                    }

                                    if (db_lookup_MID_NUMBER_meaning.equals("null")) {
                                        String lookup_MID_NUMBER_meaning = ",MID_NUMBER LOOKUP," + "LookUp value not found" + "," + db_STG_MID_NUMBER + ",Fail";
                                        section1_results.add(lookup_MID_NUMBER_meaning);
                                        String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",MID_NUMBER lookup" + "," + "LookUp value not found" + "," + db_STG_MID_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_underWriter_meaning);
                                        CONS_flag++;
                                    } else if (db_lookup_MID_NUMBER_meaning != null) {
                                        if (db_lookup_MID_NUMBER_meaning.equals(db_STG_MID_NUMBER)) {
                                            String lookup_MID_NUMBER_meaning = ",MID_NUMBER LOOKUP," + db_lookup_MID_NUMBER_meaning + "," + db_STG_MID_NUMBER + ",Pass";
                                            section1_results.add(lookup_MID_NUMBER_meaning);
                                            String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",MID_NUMBER lookup" + "," + db_lookup_MID_NUMBER_meaning + "," + db_STG_MID_NUMBER + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_underWriter_meaning);
                                        } else {
                                            String lookup_MID_NUMBER_meaning = ",MID_NUMBER LOOKUP," + db_lookup_MID_NUMBER_meaning + "," + db_STG_MID_NUMBER + ",Fail";
                                            section1_results.add(lookup_MID_NUMBER_meaning);
                                            String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",MID_NUMBER lookup" + "," + db_lookup_MID_NUMBER_meaning + "," + db_STG_MID_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_underWriter_meaning);
                                            CONS_flag++;
                                        }
                                    }
                                } else if (db_STG_MID_NUMBER != null) {
                                    String lookup_MID_NUMBER_meaning = ",MID_NUMBER lookup," + db_lookup_MID_NUMBER_meaning + "," + db_STG_MID_NUMBER + ",Fail";
                                    section1_results.add(lookup_MID_NUMBER_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",MID_NUMBER" + "," + db_lookup_MID_NUMBER_meaning + "," + db_STG_MID_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }


                                //------------------------ DDI_REFERENCE Validation -----------------
                                if (db_CONS_DDI_REFERENCE == (null)) {
                                    SQLResultset = SQLstmt.executeQuery(LandscapeGLClaimcash_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'DDI_REFERENCE'" + fsh_source);
                                    //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'DDI_REFERENCE' and System = 'LAND'  and PATTERN = 'GLClaimCash'");
                                    while (SQLResultset.next()) {
                                        db_lookup_DDI_REFERENCE_meaning = SQLResultset.getString("MEANING");
                                    }

                                    if (db_lookup_DDI_REFERENCE_meaning.equals("null")) {
                                        String lookup_DDI_REFERENCE_meaning = ",DDI_REFERENCE LOOKUP," + "LookUp value not found" + "," + db_STG_DDI_REFERENCE + ",Fail";
                                        section1_results.add(lookup_DDI_REFERENCE_meaning);
                                        String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",DDI_REFERENCE lookup" + "," + "LookUp value not found" + "," + db_STG_DDI_REFERENCE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_underWriter_meaning);
                                        CONS_flag++;
                                    } else if (db_lookup_DDI_REFERENCE_meaning != null) {
                                        if (db_lookup_DDI_REFERENCE_meaning.equals(db_STG_DDI_REFERENCE)) {
                                            String lookup_DDI_REFERENCE_meaning = ",DDI_REFERENCE LOOKUP," + db_lookup_DDI_REFERENCE_meaning + "," + db_STG_DDI_REFERENCE + ",Pass";
                                            section1_results.add(lookup_DDI_REFERENCE_meaning);
                                            String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",DDI_REFERENCE lookup" + "," + db_lookup_DDI_REFERENCE_meaning + "," + db_STG_DDI_REFERENCE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_underWriter_meaning);
                                        } else {
                                            String lookup_DDI_REFERENCE_meaning = ",DDI_REFERENCE LOOKUP," + db_lookup_DDI_REFERENCE_meaning + "," + db_STG_DDI_REFERENCE + ",Fail";
                                            section1_results.add(lookup_DDI_REFERENCE_meaning);
                                            String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",DDI_REFERENCE lookup" + "," + db_lookup_DDI_REFERENCE_meaning + "," + db_STG_DDI_REFERENCE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_underWriter_meaning);
                                        }
                                    }
                                } else {
                                    if (db_CONS_DDI_REFERENCE.equals(db_STG_DDI_REFERENCE)) {
                                        String STG_DDI_REFERENCE = ",DDI_REFERENCE," + db_STG_DDI_REFERENCE + "," + db_CONS_DDI_REFERENCE + ",Pass";
                                        section1_results.add(STG_DDI_REFERENCE);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",DDI_REFERENCE" + "," + db_STG_DDI_REFERENCE + "," + db_CONS_DDI_REFERENCE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String STG_DDI_REFERENCE = ",DDI_REFERENCE," + db_STG_DDI_REFERENCE + "," + db_CONS_DDI_REFERENCE + ",Fail";
                                        section1_results.add(STG_DDI_REFERENCE);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",DDI_REFERENCE" + "," + db_STG_DDI_REFERENCE + "," + db_CONS_DDI_REFERENCE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //------------------------ PAY_IN_SLIP_NUMBER Validation -----------------
                                if (db_CONS_PAY_IN_SLIP_NUMBER == (null)) {
                                    SQLResultset = SQLstmt.executeQuery(LandscapeGLClaimcash_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'PAY_IN_SLIP_NUMBER'" + fsh_source);
                                    //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'PAY_IN_SLIP_NUMBER' and System = 'LAND'  and PATTERN = 'GLClaimCash'");
                                    while (SQLResultset.next()) {
                                        db_lookup_PAY_IN_SLIP_NUMBER_meaning = SQLResultset.getString("MEANING");
                                    }

                                    if (db_lookup_PAY_IN_SLIP_NUMBER_meaning.equals("null")) {
                                        String lookup_PAY_IN_SLIP_NUMBER_meaning = ",PAY_IN_SLIP_NUMBER LOOKUP," + "LookUp value not found" + "," + db_STG_PAY_IN_SLIP_NUMBER + ",Fail";
                                        section1_results.add(lookup_PAY_IN_SLIP_NUMBER_meaning);
                                        String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAY_IN_SLIP_NUMBER lookup" + "," + "LookUp value not found" + "," + db_STG_PAY_IN_SLIP_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_underWriter_meaning);
                                        CONS_flag++;
                                    } else if (db_lookup_PAY_IN_SLIP_NUMBER_meaning != null) {
                                        if (db_lookup_PAY_IN_SLIP_NUMBER_meaning.equals(db_STG_PAY_IN_SLIP_NUMBER)) {
                                            String lookup_PAY_IN_SLIP_NUMBER_meaning = ",PAY_IN_SLIP_NUMBER LOOKUP," + db_lookup_PAY_IN_SLIP_NUMBER_meaning + "," + db_STG_PAY_IN_SLIP_NUMBER + ",Pass";
                                            section1_results.add(lookup_PAY_IN_SLIP_NUMBER_meaning);
                                            String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAY_IN_SLIP_NUMBER lookup" + "," + db_lookup_PAY_IN_SLIP_NUMBER_meaning + "," + db_STG_PAY_IN_SLIP_NUMBER + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_underWriter_meaning);
                                        } else {
                                            String lookup_PAY_IN_SLIP_NUMBER_meaning = ",PAY_IN_SLIP_NUMBER LOOKUP," + db_lookup_PAY_IN_SLIP_NUMBER_meaning + "," + db_STG_PAY_IN_SLIP_NUMBER + ",Fail";
                                            section1_results.add(lookup_PAY_IN_SLIP_NUMBER_meaning);
                                            String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAY_IN_SLIP_NUMBER lookup" + "," + db_lookup_PAY_IN_SLIP_NUMBER_meaning + "," + db_STG_PAY_IN_SLIP_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_underWriter_meaning);
                                            CONS_flag++;
                                        }
                                    }
                                } else {
                                    if (db_CONS_PAY_IN_SLIP_NUMBER.equals(db_STG_PAY_IN_SLIP_NUMBER)) {
                                        String STG_PAY_IN_SLIP_NUMBER = ",PAY_IN_SLIP_NUMBER," + db_STG_PAY_IN_SLIP_NUMBER + "," + db_CONS_PAY_IN_SLIP_NUMBER + ",Pass";
                                        section1_results.add(STG_PAY_IN_SLIP_NUMBER);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAY_IN_SLIP_NUMBER" + "," + db_STG_PAY_IN_SLIP_NUMBER + "," + db_CONS_PAY_IN_SLIP_NUMBER + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String STG_PAY_IN_SLIP_NUMBER = ",PAY_IN_SLIP_NUMBER," + db_STG_PAY_IN_SLIP_NUMBER + "," + db_CONS_PAY_IN_SLIP_NUMBER + ",Fail";
                                        section1_results.add(STG_PAY_IN_SLIP_NUMBER);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAY_IN_SLIP_NUMBER" + "," + db_STG_PAY_IN_SLIP_NUMBER + "," + db_CONS_PAY_IN_SLIP_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //------------------------ CARD_TYPE Validation -----------------
                                if (db_CONS_CARD_TYPE == (null)) {
                                    SQLResultset = SQLstmt.executeQuery(LandscapeGLClaimcash_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'CARD_TYPE'" + fsh_source);
                                    //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'CARD_TYPE' and System = 'LAND'  and PATTERN = 'GLClaimCash'");
                                    while (SQLResultset.next()) {
                                        db_lookup_CARD_TYPE_meaning = SQLResultset.getString("MEANING");
                                    }

                                    if (db_lookup_CARD_TYPE_meaning.equals("null")) {
                                        String lookup_CARD_TYPE_meaning = ",CARD_TYPE LOOKUP," + "LookUp value not found" + "," + db_STG_CARD_TYPE + ",Fail";
                                        section1_results.add(lookup_CARD_TYPE_meaning);
                                        String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",CARD_TYPE lookup" + "," + "LookUp value not found" + "," + db_STG_CARD_TYPE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_underWriter_meaning);
                                        CONS_flag++;
                                    } else if (db_lookup_CARD_TYPE_meaning != null) {
                                        if (db_lookup_CARD_TYPE_meaning.equals(db_STG_CARD_TYPE)) {
                                            String lookup_CARD_TYPE_meaning = ",CARD_TYPE LOOKUP," + db_lookup_CARD_TYPE_meaning + "," + db_STG_CARD_TYPE + ",Pass";
                                            section1_results.add(lookup_CARD_TYPE_meaning);
                                            String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",CARD_TYPE lookup" + "," + db_lookup_CARD_TYPE_meaning + "," + db_STG_CARD_TYPE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_underWriter_meaning);
                                        } else {
                                            String lookup_CARD_TYPE_meaning = ",CARD_TYPE LOOKUP," + db_lookup_CARD_TYPE_meaning + "," + db_STG_CARD_TYPE + ",Fail";
                                            section1_results.add(lookup_CARD_TYPE_meaning);
                                            String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",CARD_TYPE lookup" + "," + db_lookup_CARD_TYPE_meaning + "," + db_STG_CARD_TYPE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_underWriter_meaning);
                                            CONS_flag++;
                                        }
                                    }
                                } else {
                                    if (db_CONS_CARD_TYPE.equals(db_STG_CARD_TYPE)) {
                                        String STG_CARD_TYPE = ",CARD_TYPE," + db_STG_CARD_TYPE + "," + db_CONS_CARD_TYPE + ",Pass";
                                        section1_results.add(STG_CARD_TYPE);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CARD_TYPE" + "," + db_STG_CARD_TYPE + "," + db_CONS_CARD_TYPE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String STG_CARD_TYPE = ",CARD_TYPE," + db_STG_CARD_TYPE + "," + db_CONS_CARD_TYPE + ",Fail";
                                        section1_results.add(STG_CARD_TYPE);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CARD_TYPE" + "," + db_STG_CARD_TYPE + "," + db_CONS_CARD_TYPE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //------------------------ BACS_NARRATIVE Validation -----------------
                                if (db_CONS_BACS_NARRATIVE == (null)) {
                                    SQLResultset = SQLstmt.executeQuery(LandscapeGLClaimcash_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'BACS_NARRATIVE'" + fsh_source);
                                    //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'BACS_NARRATIVE' and System = 'LAND'  and PATTERN = 'GLClaimCash'");
                                    while (SQLResultset.next()) {
                                        db_lookup_BACS_NARRATIVE_meaning = SQLResultset.getString("MEANING");
                                    }

                                    if (db_lookup_BACS_NARRATIVE_meaning.equals("null")) {
                                        String lookup_BACS_NARRATIVE_meaning = ",BACS_NARRATIVE LOOKUP," + "LookUp value not found" + "," + db_STG_BACS_NARRATIVE + ",Fail";
                                        section1_results.add(lookup_BACS_NARRATIVE_meaning);
                                        String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",BACS_NARRATIVE lookup" + "," + "LookUp value not found" + "," + db_STG_BACS_NARRATIVE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_underWriter_meaning);
                                        CONS_flag++;
                                    } else if (db_lookup_BACS_NARRATIVE_meaning != null) {
                                        if (db_lookup_BACS_NARRATIVE_meaning.equals(db_STG_BACS_NARRATIVE)) {
                                            String lookup_BACS_NARRATIVE_meaning = ",BACS_NARRATIVE LOOKUP," + db_lookup_BACS_NARRATIVE_meaning + "," + db_STG_BACS_NARRATIVE + ",Pass";
                                            section1_results.add(lookup_BACS_NARRATIVE_meaning);
                                            String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",BACS_NARRATIVE lookup" + "," + db_lookup_BACS_NARRATIVE_meaning + "," + db_STG_BACS_NARRATIVE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_underWriter_meaning);
                                        } else {
                                            String lookup_BACS_NARRATIVE_meaning = ",BACS_NARRATIVE LOOKUP," + db_lookup_BACS_NARRATIVE_meaning + "," + db_STG_BACS_NARRATIVE + ",Fail";
                                            section1_results.add(lookup_BACS_NARRATIVE_meaning);
                                            String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",BACS_NARRATIVE lookup" + "," + db_lookup_BACS_NARRATIVE_meaning + "," + db_STG_BACS_NARRATIVE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_underWriter_meaning);
                                            CONS_flag++;
                                        }
                                    }
                                } else {
                                    if (db_CONS_BACS_NARRATIVE.equals(db_STG_BACS_NARRATIVE)) {
                                        String STG_BACS_NARRATIVE = ",BACS_NARRATIVE," + db_STG_BACS_NARRATIVE + "," + db_CONS_BACS_NARRATIVE + ",Pass";
                                        section1_results.add(STG_BACS_NARRATIVE);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BACS_NARRATIVE" + "," + db_STG_BACS_NARRATIVE + "," + db_CONS_BACS_NARRATIVE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String STG_BACS_NARRATIVE = ",BACS_NARRATIVE," + db_STG_BACS_NARRATIVE + "," + db_CONS_BACS_NARRATIVE + ",Fail";
                                        section1_results.add(STG_BACS_NARRATIVE);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BACS_NARRATIVE" + "," + db_STG_BACS_NARRATIVE + "," + db_CONS_BACS_NARRATIVE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //------------------------ ORDER_NUMBER Validation -----------------
                                if (db_CONS_ORDER_NUMBER == (null)) {
                                    SQLResultset = SQLstmt.executeQuery(LandscapeGLClaimcash_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'ORDER_NUMBER'" + fsh_source);
                                    //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'ORDER_NUMBER' and System = 'LAND'  and PATTERN = 'GLClaimCash'");
                                    while (SQLResultset.next()) {
                                        db_lookup_ORDER_NUMBER_meaning = SQLResultset.getString("MEANING");
                                    }

                                    if (db_lookup_ORDER_NUMBER_meaning.equals("null")) {
                                        String lookup_ORDER_NUMBER_meaning = ",ORDER_NUMBER LOOKUP," + "LookUp value not found" + "," + db_STG_ORDER_NUMBER + ",Fail";
                                        section1_results.add(lookup_ORDER_NUMBER_meaning);
                                        String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",ORDER_NUMBER lookup" + "," + "LookUp value not found" + "," + db_STG_ORDER_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_underWriter_meaning);
                                        CONS_flag++;
                                    } else if (db_lookup_ORDER_NUMBER_meaning != null) {
                                        if (db_lookup_ORDER_NUMBER_meaning.equals(db_STG_ORDER_NUMBER)) {
                                            String lookup_ORDER_NUMBER_meaning = ",ORDER_NUMBER LOOKUP," + db_lookup_ORDER_NUMBER_meaning + "," + db_STG_ORDER_NUMBER + ",Pass";
                                            section1_results.add(lookup_ORDER_NUMBER_meaning);
                                            String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",ORDER_NUMBER lookup" + "," + db_lookup_ORDER_NUMBER_meaning + "," + db_STG_ORDER_NUMBER + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_underWriter_meaning);
                                        } else {
                                            String lookup_ORDER_NUMBER_meaning = ",ORDER_NUMBER LOOKUP," + db_lookup_ORDER_NUMBER_meaning + "," + db_STG_ORDER_NUMBER + ",Fail";
                                            section1_results.add(lookup_ORDER_NUMBER_meaning);
                                            String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",ORDER_NUMBER lookup" + "," + db_lookup_ORDER_NUMBER_meaning + "," + db_STG_ORDER_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                            section2_results_tbl.add(tbl_underWriter_meaning);
                                            CONS_flag++;
                                        }
                                    }
                                } else {
                                    if (db_CONS_ORDER_NUMBER.equals(db_STG_ORDER_NUMBER)) {
                                        String STG_ORDER_NUMBER = ",ORDER_NUMBER," + db_STG_ORDER_NUMBER + "," + db_CONS_ORDER_NUMBER + ",Pass";
                                        section1_results.add(STG_ORDER_NUMBER);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ORDER_NUMBER" + "," + db_STG_ORDER_NUMBER + "," + db_CONS_ORDER_NUMBER + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String STG_ORDER_NUMBER = ",ORDER_NUMBER," + db_STG_ORDER_NUMBER + "," + db_CONS_ORDER_NUMBER + ",Fail";
                                        section1_results.add(STG_ORDER_NUMBER);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ORDER_NUMBER" + "," + db_STG_ORDER_NUMBER + "," + db_CONS_ORDER_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //------------------------ PERIL_CODE Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(LandscapeGLClaimcash_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_CONS_PERIL_CODE + "' and LOOKUP_TYPE = 'PERIL_CODE'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_PERIL_CODE + "' and LOOKUP_TYPE = 'PERIL_CODE' and System = 'LAND'  and PATTERN = 'GLClaimCash'");
                                while (SQLResultset.next()) {
                                    db_lookup_PERIL_CODE_meaning = SQLResultset.getString("MEANING");
                                }

                                if (db_lookup_PERIL_CODE_meaning.contains(",")) {
                                    db_lookup_PERIL_CODE_meaning = db_lookup_PERIL_CODE_meaning.replace(",", "");
                                    System.out.println(db_lookup_PERIL_CODE_meaning);
                                }
                                if (db_STG_PERIL_CODE != null) {
                                    if (db_STG_PERIL_CODE.contains(",")) {
                                        db_STG_PERIL_CODE = db_STG_PERIL_CODE.replace(", $", "");
                                    }
                                }
                                if (db_lookup_PERIL_CODE_meaning.equals("null")) {
                                    String lookup_PERIL_CODE_meaning = ",PERIL_CODE LOOKUP," + "LookUp value not found" + "," + db_STG_PERIL_CODE + ",Fail";
                                    section1_results.add(lookup_PERIL_CODE_meaning);
                                    String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",PERIL_CODE lookup" + "," + "LookUp value not found" + "," + db_STG_PERIL_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_underWriter_meaning);
                                    CONS_flag++;
                                } else if (db_lookup_PERIL_CODE_meaning != null) {
                                    if (db_lookup_PERIL_CODE_meaning.equals(db_STG_PERIL_CODE)) {
                                        String lookup_PERIL_CODE_meaning = ",PERIL_CODE LOOKUP," + db_lookup_PERIL_CODE_meaning + "," + db_STG_PERIL_CODE + ",Pass";
                                        section1_results.add(lookup_PERIL_CODE_meaning);
                                        String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",PERIL_CODE lookup" + "," + db_lookup_PERIL_CODE_meaning + "," + db_STG_PERIL_CODE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_underWriter_meaning);
                                    } else {
                                        String lookup_PERIL_CODE_meaning = ",PERIL_CODE LOOKUP," + db_lookup_PERIL_CODE_meaning + "," + db_STG_PERIL_CODE + ",Fail";
                                        section1_results.add(lookup_PERIL_CODE_meaning);
                                        String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",PERIL_CODE lookup" + "," + db_lookup_PERIL_CODE_meaning + "," + db_STG_PERIL_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_underWriter_meaning);
                                        CONS_flag++;
                                    }
                                }


                                //------------------------ EVENT_CODE Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(LandscapeGLClaimcash_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'EVENT_CODE'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'EVENT_CODE' and System = 'LAND'  and PATTERN = 'GLClaimCash'");
                                while (SQLResultset.next()) {
                                    db_lookup_EVENT_CODE_meaning = SQLResultset.getString("MEANING");
                                }

                                if (db_lookup_EVENT_CODE_meaning.equals("null")) {
                                    String lookup_EVENT_CODE_meaning = ",EVENT_CODE LOOKUP," + "LookUp value not found" + "," + db_STG_EVENT_CODE + ",Fail";
                                    section1_results.add(lookup_EVENT_CODE_meaning);
                                    String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",EVENT_CODE lookup" + "," + "LookUp value not found" + "," + db_STG_EVENT_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_underWriter_meaning);
                                    CONS_flag++;
                                } else if (db_lookup_EVENT_CODE_meaning != null) {
                                    if (db_lookup_EVENT_CODE_meaning.equals(db_STG_EVENT_CODE)) {
                                        String lookup_EVENT_CODE_meaning = ",EVENT_CODE LOOKUP," + db_lookup_EVENT_CODE_meaning + "," + db_STG_EVENT_CODE + ",Pass";
                                        section1_results.add(lookup_EVENT_CODE_meaning);
                                        String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",EVENT_CODE lookup" + "," + db_lookup_EVENT_CODE_meaning + "," + db_STG_EVENT_CODE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_underWriter_meaning);
                                    } else {
                                        String lookup_EVENT_CODE_meaning = ",EVENT_CODE LOOKUP," + db_lookup_EVENT_CODE_meaning + "," + db_STG_EVENT_CODE + ",Fail";
                                        section1_results.add(lookup_EVENT_CODE_meaning);
                                        String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",EVENT_CODE lookup" + "," + db_lookup_EVENT_CODE_meaning + "," + db_STG_EVENT_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_underWriter_meaning);
                                        CONS_flag++;
                                    }
                                }

                                //------------------------ ENTITY_TYPE_CODE Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(LandscapeGLClaimcash_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'ENTITY_TYPE_CODE'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'ENTITY_TYPE_CODE' and System = 'LAND'  and PATTERN = 'GLClaimCash'");
                                while (SQLResultset.next()) {
                                    db_lookup_ENTITY_TYPE_CODE_meaning = SQLResultset.getString("MEANING");
                                }

                                if (db_lookup_ENTITY_TYPE_CODE_meaning.equals("null")) {
                                    String lookup_ENTITY_TYPE_CODE_meaning = ",ENTITY_TYPE_CODE LOOKUP," + "LookUp value not found" + "," + db_STG_ENTITY_TYPE_CODE + ",Fail";
                                    section1_results.add(lookup_ENTITY_TYPE_CODE_meaning);
                                    String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",ENTITY_TYPE_CODE lookup" + "," + "LookUp value not found" + "," + db_STG_ENTITY_TYPE_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_underWriter_meaning);
                                    CONS_flag++;
                                } else if (db_lookup_ENTITY_TYPE_CODE_meaning != null) {
                                    if (db_lookup_ENTITY_TYPE_CODE_meaning.equals(db_STG_ENTITY_TYPE_CODE)) {
                                        String lookup_ENTITY_TYPE_CODE_meaning = ",ENTITY_TYPE_CODE LOOKUP," + db_lookup_ENTITY_TYPE_CODE_meaning + "," + db_STG_ENTITY_TYPE_CODE + ",Pass";
                                        section1_results.add(lookup_ENTITY_TYPE_CODE_meaning);
                                        String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",ENTITY_TYPE_CODE lookup" + "," + db_lookup_ENTITY_TYPE_CODE_meaning + "," + db_STG_ENTITY_TYPE_CODE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_underWriter_meaning);
                                    } else {
                                        String lookup_ENTITY_TYPE_CODE_meaning = ",ENTITY_TYPE_CODE LOOKUP," + db_lookup_ENTITY_TYPE_CODE_meaning + "," + db_STG_ENTITY_TYPE_CODE + ",Fail";
                                        section1_results.add(lookup_ENTITY_TYPE_CODE_meaning);
                                        String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",ENTITY_TYPE_CODE lookup" + "," + db_lookup_ENTITY_TYPE_CODE_meaning + "," + db_STG_ENTITY_TYPE_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_underWriter_meaning);
                                        CONS_flag++;
                                    }
                                }


                                //------------------------ SUMMARY_FLAG Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(LandscapeGLClaimcash_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_CONS_SOURCE + "' and LOOKUP_TYPE = 'SUMMARISE_DATA_FLAG'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_SOURCE + "' and LOOKUP_TYPE = 'SUMMARISE_DATA_FLAG' and System = 'LAND'  and PATTERN = 'GLClaimCash'");
                                while (SQLResultset.next()) {
                                    db_lookup_SUMMARY_FLAG_meaning = SQLResultset.getString("MEANING");
                                }

                                if (db_lookup_SUMMARY_FLAG_meaning.equals("null")) {
                                    String lookup_SUMMARY_FLAG_meaning = ",SUMMARY_FLAG LOOKUP," + "LookUp value not found" + "," + db_STG_SUMMARY_FLAG + ",Fail";
                                    section1_results.add(lookup_SUMMARY_FLAG_meaning);
                                    String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",SUMMARY_FLAG lookup" + "," + "LookUp value not found" + "," + db_STG_SUMMARY_FLAG + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_underWriter_meaning);
                                    CONS_flag++;
                                } else if (db_lookup_SUMMARY_FLAG_meaning != null) {
                                    if (db_lookup_SUMMARY_FLAG_meaning.equals(db_STG_SUMMARY_FLAG)) {
                                        String lookup_SUMMARY_FLAG_meaning = ",SUMMARY_FLAG LOOKUP," + db_lookup_SUMMARY_FLAG_meaning + "," + db_STG_SUMMARY_FLAG + ",Pass";
                                        section1_results.add(lookup_SUMMARY_FLAG_meaning);
                                        String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",SUMMARY_FLAG lookup" + "," + db_lookup_SUMMARY_FLAG_meaning + "," + db_STG_SUMMARY_FLAG + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_underWriter_meaning);
                                    } else {
                                        String lookup_SUMMARY_FLAG_meaning = ",SUMMARY_FLAG LOOKUP," + db_lookup_SUMMARY_FLAG_meaning + "," + db_STG_SUMMARY_FLAG + ",Fail";
                                        section1_results.add(lookup_SUMMARY_FLAG_meaning);
                                        String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",SUMMARY_FLAG lookup" + "," + db_lookup_SUMMARY_FLAG_meaning + "," + db_STG_SUMMARY_FLAG + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_underWriter_meaning);
                                        CONS_flag++;
                                    }
                                }

                                //------------------------ CREDIT_IND Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(LandscapeGLClaimcash_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'CREDIT_IND'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'CREDIT_IND' and System = 'LAND'  and PATTERN = 'GLClaimCash'");
                                while (SQLResultset.next()) {
                                    db_lookup_credit_ind_meaning = SQLResultset.getString("MEANING");
                                }

                                if (db_lookup_credit_ind_meaning.equals("null")) {
                                    String lookup_credit_ind_meaning = ",CREDIT_INDICATOR LOOKUP," + "LookUp value not found" + "," + db_STG_CREDIT_IND + ",Fail";
                                    section1_results.add(lookup_credit_ind_meaning);
                                    String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",CREDIT_INDICATOR lookup" + "," + "LookUp value not found" + "," + db_STG_CREDIT_IND + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_underWriter_meaning);
                                    CONS_flag++;
                                } else if (db_lookup_credit_ind_meaning != null) {
                                    if (db_lookup_credit_ind_meaning.equals(db_STG_CREDIT_IND)) {
                                        String lookup_credit_ind_meaning = ",CREDIT_INDICATOR LOOKUP," + db_lookup_credit_ind_meaning + "," + db_STG_CREDIT_IND + ",Pass";
                                        section1_results.add(lookup_credit_ind_meaning);
                                        String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",CREDIT_INDICATOR lookup" + "," + "LookUp value not found" + "," + db_STG_CREDIT_IND + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_underWriter_meaning);
                                    } else {
                                        String lookup_credit_ind_meaning = ",CREDIT_INDICATOR LOOKUP," + db_lookup_credit_ind_meaning + "," + db_STG_CREDIT_IND + ",Fail";
                                        section1_results.add(lookup_credit_ind_meaning);
                                        String tbl_underWriter_meaning = section2_map_row + "," + header + "," + Source + "," + pattern + ",CREDIT_INDICATOR lookup" + "," + "LookUp value not found" + "," + db_STG_CREDIT_IND + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_underWriter_meaning);
                                        CONS_flag++;
                                    }
                                }


                            }
                        }
                    }
                }

                //----------------- Validate the Over all Status -------------------
                System.out.println("Looping ++  CONS_flag " + CONS_flag);
                String Overall_status = null;
                String Overall_stg_status = null;
                if (CONS_flag > 0) {
                    CONS_STATUS.add("Fail");
                    Overall_status = "Fail";
                } else {
                    CONS_STATUS.add("Pass");
                    Overall_status = "Pass";
                }


                if (CONS_flag > 0) {
                    OverAllStatus.add("Fail");
                } else {
                    OverAllStatus.add("Pass");
                }

                String tbl_summary_filelist = Source +","+ pattern + ","+file_name +","+ "CONS TO STG " + "," + load_date + ","+ OverAllStatus + "," + btc_BATCH_PKEY;
                //String tbl_summary_filelist = Source + "," + pattern + "," + file_name + "," + load_dateFormat + "," + "CONST TO STG " + "," + OverAllStatus;
                summary_results_tbl.add(tbl_summary_filelist);


                list.addAll(section1_results);
                list.addAll(section2_results);
                list.addAll(section3_results);
                list.addAll(section4_results);

                // ---------------- HTML Report generation ------------------------
                report_generation.report_Test1(section1_results, "Header", xml_file_name, "CONSOLIDATION LAYER - STAGING LAYER", "Landscape_GL_ClaimCash", "Landscape_GL_ClaimCash : CONSOLIDATION LAYER - STAGING AGGREGATE LAYER", "");
                report_generation.report_Test1(section1_results, "Section2", xml_file_name, "CONSOLIDATION LAYER - STAGING LAYER", "Landscape_GL_ClaimCash", "Landscape_GL_ClaimCash : CONSOLIDATION LAYER - STAGING AGGREGATE LAYER", "");
                report_generation.report_Test1(section2_results, "Mandatory", xml_file_name, "Mandatory Check", "Landscape_GL_ClaimCash", "Landscape_GL_ClaimCash : CONSOLIDATION LAYER - STAGING AGGREGATE LAYER", "");
                report_generation.report_Test1(section4_results, "Mandatory", xml_file_name, "Mandatory_Check_STG", "Landscape_GL_ClaimCash", "Landscape_GL_ClaimCash : CONSOLIDATION LAYER - STAGING AGGREGATE LAYER", "");
                report_generation.report_Test1(section3_results, "Section3", xml_file_name, "STAGING TO AGGREGATE LAYER", "Landscape_GL_ClaimCash", "Landscape_GL_ClaimCash : CONSOLIDATION LAYER - STAGING AGGREGATE LAYER", "");

                table_detail_report.detail_report_tbl(section2_results_tbl);

            }

            state_model.section_method(file_list, CONS_STATUS, "N/A", OverAllStatus, "Landscape_GLClaimcash_Summary");
            table_summary_report.summary_report_tbl(summary_results_tbl );
        }
    }
}







