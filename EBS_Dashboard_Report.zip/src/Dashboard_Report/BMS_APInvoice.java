package Dashboard_Report;

import java.io.IOException;
import java.sql.*;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONException;

public class BMS_APInvoice {

    static Statement SQLstmt = null;
    static ResultSet SQLResultset = null;

    public static HTML_Report_Generation_DB_EVO report_generation;
    public static HTML_Report_Generation_State_Model_B4C report_generation_state;
    public static SCH_EVO_PC_State_Model_B4C state_model;

    public static Table_Detail_Report table_detail_report;
    public static Table_Summary_Report table_summary_report;
    public static connectDatabase connect_db;

    public static void main(String[] args) throws IOException, SQLException, ParseException, JSONException {
        report_generation = new HTML_Report_Generation_DB_EVO();
        report_generation_state = new HTML_Report_Generation_State_Model_B4C();
        state_model = new SCH_EVO_PC_State_Model_B4C();

        table_detail_report = new Table_Detail_Report();
        table_summary_report = new Table_Summary_Report();
        connect_db = new connectDatabase();

        //----------------------- delete the existing report --------------
        report_generation.clean_report("BMS_APInvoice.html");
        report_generation_state.clean_report_summary("BMS_APInvoice_Summary.html");

        /*//--------------- SIT  database details -------------------
        String URL_SIT1 = "jdbc:oracle:thin:@dbs119dev.gwd.grpinf.net:1521/FSHDTST3";
        String Username_SIT1 = "FSH_ORA_DATA";
        String password_SIT1 = "Development_Test3";*/

        //--------------- SIT  database details -------------------
        String URL_SIT1 = "jdbc:oracle:thin:@dbs119dev.gwd.grpinf.net:1521/FSHDTST4";
        String Username_SIT1 = "FSH_ORA_DATA";
        String password_SIT1 = "XdbvFm!dm7dVCzWE";

        //--------------- EBS  database details -------------------
        String URL_ICSI = "jdbc:oracle:thin:@dcn2ddbx340.gwd.grpinf.net:1618:ICSI";
        String Username_ICSI = "apps";
        String password_ICSI = "apps4icsi";

        List<String> file_list = new ArrayList<String>();
        List<String> list = new ArrayList<String>();
        List<String> section1_results = new ArrayList<String>();
        /*List<String> section2_results = new ArrayList<String>();
        List<String> section3_results = new ArrayList<String>();*/
        List<String> section4_results = new ArrayList<String>();

        List<String> OverAllStatus = new ArrayList<String>();
        List<String> CONS_STATUS = new ArrayList<String>();
        List<String> summary_results_tbl = new ArrayList<String>();

        String[] file_lists = null;
        int section1_map_row = 1;

        //--------------------- Declaring the supporting details for reporting --------------
        String file_name = "null";
        String Source = "ECLI";
        String pattern = "APInvoice";
        String header = "Header";
        String line = "Line";

        int cons_stg_map_row = 1;
        int stg_line_map_row = 1;
        int stg_hdr_map_row = 1;
        int cons_mandatory_map_row = 1;
        int stg_mandatory_map_row = 1;

        //--------------- Consolidation variables decleration ---------
        String db_CONS_SOURCE = "null";
        String db_CONS_CURRENCY_CODE = "null";
        String db_cons_header_pkey = "null";
        String db_cons_header_id = "null";
        String db_CONS_TRANSACTION_DATE = "null";
        String db_CONS_SUPPLIER_NAME = "null";
        String db_CONS_POLICY_NUMBER = "null";
        String db_CONS_CLAIM_NUMBER = "null";
        String db_CONS_BRAND = "null";
        String db_CONS_PRODUCT_TYPE = "null";
        String db_CONS_CHANNEL = "null";
        String db_CONS_BASE_CURRENCY_NET_AMOUNT = "null";
        String db_CONS_THIRD_CLAIM_REF = "null";
        String db_CONS_PAYEE_TYPE = "null";
        String db_CONS_PAYMENT_METHOD = "null";
        String db_CONS_PAYMENT_TERMS = "null";
        String db_CONS_CLAIM_HANDLER_REF = "null";
        String db_CONS_APPROVER = "null";
        String db_CONS_BANK_ACCOUNT_NUMBER = "null";
        String db_CONS_BANK_SORT_CODE = "null";
        String db_CONS_INVOICE_NUM = "null";
        String db_CONS_INVOICE_DATE = "null";
        String db_CONS_INVOICE_RECEIVED_DATE = "null";
        String db_CONS_VENDOR_SITE_ID = "null";
        String db_CONS_EXCHANGE_RATE = "null";
        String db_CONS_EXCHANGE_RATE_TYPE = "null";
        String db_CONS_EXCHANGE_EFFECTIVE_DATE = "null";
        String db_CONS_PAYEE_DESCRIPTION = "null";
        String db_CONS_PAYEE_ADDRESS_LINE1 = "null";
        String db_CONS_PAYEE_ADDRESS_LINE2 = "null";
        String db_CONS_PAYEE_ADDRESS_LINE3 = "null";
        String db_CONS_PAYEE_CITY = "null";
        String db_CONS_PAYEE_COUNTY = "null";
        String db_CONS_PAYEE_COUNTRY = "null";
        String db_CONS_PAYEE_POSTCODE = "null";
        String db_CONS_SYSTEM = "null";
        String db_CONS_FILE_NAME = "null";
        String db_CONS_TRANSACTION_TYPE = "null";
        String db_CONS_TXN_REFERENCE1 = "null";
        String db_CONS_UNDERWRITER = "null";
        String db_CONS_LINE_OF_BUSINESS = "null";
        String db_CONS_INVOICE_CURRENCY_CODE = "null";
        String db_CONS_INVOICE_GROSS_AMOUNT = "null";
        String db_CONS_INVOICE_NET_AMOUNT = "null";
        String db_CONS_INVOICE_VAT_AMOUNT = "null";
        String CONS_HDR_STATUS = "null";

        String load_date = "null";
        Date load_dateFormat = null;
        String btc_BATCH_PKEY = null;

        String db_CONS_line_id = "null";
        String db_CONS_LINE_NUMBER = "null";
        String db_CONS_LINE_INVOICE_NUM = "null";
        String db_CONS_LINE_VENDOR_SITE_ID = "null";
        String db_CONS_LINE_CATEGORY = "null";
        String db_CONS_LINE_ITEM_AMOUNT = "null";
        String db_CONS_BASE_LINE_ITEM_AMOUNT = "null";
        String db_CONS_LINE_TRANSACTION_DATE = "null";
        String db_CONS_LINE_TAX_CODE = "null";
        String db_CONS_LINE_HEADER_ID = "null";
        String db_CONS_CATEGORY = "null";
        String db_CONS_LINE_DESCRIPTION = "null";
        String db_CONS_LINE_SOURCE = "null";
        String db_CONS_LINE_PARTITION_ID = "null";
        String db_CONS_LINE_FILE_NAME = "null";
        String CONS_LINE_STATUS = "null";


        String db_STG_SUMMARY_FLAG = "null";
        String STG_HDR_STATUS = "null";
        String db_STG_HEADER_ID = "null";
        String db_STG_SOURCE = "null";
        String db_STG_PAYMENT_METHOD_CODE = "null";
        String db_STG_TRANSACTION_DATE = "null";
        String db_STG_ATTRIBUTE9 = "null";
        String db_STG_POLICY_NUMBER = "null";
        String db_STG_GLOBAL_ATTRIBUTE1 = "null";
        String db_STG_CLAIM_NUMBER = "null";
        String db_STG_GLOBAL_ATTRIBUTE2 = "null";
        String db_STG_BRAND = "null";
        String db_STG_PRODUCT_TYPE = "null";
        String db_STG_CHANNEL = "null";
        String db_STG_GLOBAL_ATTRIBUTE3 = "null";
        String db_STG_INVOICE_AMOUNT = "null";
        String db_STG_THIRD_CLAIM_REF = "null";
        String db_STG_PAYEE_TYPE = "null";
        String db_STG_PAYMENT_METHOD = "null";
        String db_STG_PAYMENT_TERMS = "null";
        String db_STG_CLAIM_HANDLER_REF = "null";
        String db_STG_APPROVER = "null";
        String db_STG_ACCOUNT_NUMBER = "null";
        String db_STG_SORT_CODE = "null";
        String db_STG_PAYMENT_COUNTRY = "null";
        String db_STG_INVOICE_NUM = "null";
        String db_STG_DESCRIPTION = "null";
        String db_STG_INVOICE_DATE = "null";
        String db_STG_INVOICE_RECEIVED_DATE = "null";
        String db_STG_VENDOR_ID = "null";
        String db_STG_VENDOR_NAME = "null";
        String db_STG_VENDOR_SITE_ID = "null";
        String db_STG_VENDOR_SITE_CD = "null";
        String db_STG_VENDOR_SITE_CODE = "null";
        String db_STG_EXCHANGE_EFFECTIVE_DATE = "null";
        String db_STG_ATTRIBUTE_CATEGORY = "null";
        String db_STG_ATTRIBUTE1 = "null";
        String db_STG_ATTRIBUTE2 = "null";
        String db_STG_ATTRIBUTE3 = "null";
        String db_STG_ATTRIBUTE4 = "null";
        String db_STG_ATTRIBUTE5 = "null";
        String db_STG_ATTRIBUTE6 = "null";
        String db_STG_ATTRIBUTE7 = "null";
        String db_STG_ATTRIBUTE8 = "null";
        String db_STG_FILE_NAME = "null";
        String db_STG_FSH_ATTRIBUTE1 = "null";
        String db_STG_FSH_ATTRIBUTE2 = "null";
        String db_STG_UNDERWRITER = "null";
        String db_STG_LINE_OF_BUSINESS = "null";
        String db_STG_PRODUCT = "null";
        String db_STG_INVOICE_CURRENCY_CODE = "null";
        String db_STG_INVOICE_ID = "null";
        String db_STG_EXCHANGE_RATE = "null";
        String db_STG_EXCHANGE_RATE_TYPE = "null";
        String db_STG_PAY_GROUP_LOOKUP_CODE = "null";
        String db_STG_ORG_ID = "null";
        String db_STG_FSH_ATTRIBUTE_04 = "null";
        String db_STG_FSH_ATTRIBUTE_05 = "null";
        String db_STG_CALC_TAX_DURING_IMPORT_FLAG = "null";
        String db_STG_BUSINESS_UNIT = "null";
        String db_STG_ATTRIBUTE13 = "null";
        String db_STG_ATTRIBUTE15 = "null";

        String db_STG_LINE_SUMMARY_FLAG = "null";
        String db_STG_line_id = "null";
        String db_stg_LINE_INVOICE_ID = "null";
        String db_STG_LINE_NUMBER = "null";
        String db_STG_LINE_TYPE_LOOKUP_CODE = "null";
        String db_STG_LINE_SUBJECT_REV_CHARGE = "null";
        String db_STG_LINE_PRORATE_ACROSS_FLAG = "null";
        String db_STG_LINE_AMOUNT_INCLUDES_TAX_FLAG = "null";
        String db_STG_LINE_TAX_RATE_CODE = "null";
        String db_STG_LINE_DESCRIPTION = "null";
        String db_STG_LINE_ITEM_AMOUNT = "null";
        String db_STG_LINE_CATEGORY = "null";
        String db_STG_LINE_CURRENCY_CODE = "null";
        String db_STG_LINE_INVOICE_ID = "null";
        String db_STG_LINE_DIST_CODE_CONCATENATED = "null";
        String STG_LINE_STATUS = "null";
        String db_STG_BASE_LINE_ITEM_AMOUNT = "null";
        String db_STG_LINE_TRANSACTION_DATE = "null";
        String db_STG_LINE_TAX_CODE = "null";
        String db_STG_LINE_HEADER_ID = "null";
        //String db_STG_CATEGORY = "null";
        String db_STG_PARTITION_ID = "null";
        String db_STG_LINE_PARTITION_ID = "null";
        String db_STG_LINE_SOURCE = "null";
        String db_STG_LINE_FILE_NAME = "null";
        String db_STG_LINE_BUSINESS_UNIT = "null";

        String xmlfile_name = "null";
        String xml_file_name1 = null;


        //---------------- Line item -------
        String db_stg_line_id = "null";
        String db_stg_INVOICE_ID = "null";


        //-------- Connect to Database --------------
        connect_db.createConnection("DEVTEST4");
        //table_detail_report.detail_report_tbl_delete(connection, Source);


        //------ get the new file from batch control table --------------
        boolean newRecord = true;
        //SQLResultset = SQLstmt.executeQuery("Select distinct file_name from DLG_FSH_CTL_BATCH where Trunc(LOAD_DATE) = TRUNC(SYSDATE-1) and system = 'LAND' and pattern = 'GLPREMIUM'"); LANDGLPremium_20191115130012.xml LANDGLPremium_20191106125232.xml
        String outSQL = connect_db.executeQuery_DB("BATCH", "APInvoice_batchCtl", "BMS");
        SQLstmt = connect_db.resStatement();

        SQLResultset = SQLstmt.executeQuery(outSQL);
        while (SQLResultset.next()) {
            file_list.add(SQLResultset.getString("FILE_NAME"));
            System.out.println("File name---" + SQLResultset.getString("FILE_NAME"));
            list.addAll(section1_results);
        }


        // ---------------------------------- Get the batch PKEY ----------------------
        String outSQL_bkey = connect_db.executeQuery_DB("BATCH", "APInvoice_batchCtl_key", "BMS");

        SQLResultset = SQLstmt.executeQuery(outSQL_bkey);
        while (SQLResultset.next()) {
            btc_BATCH_PKEY = SQLResultset.getString("BATCH_PKEY");
        }

        // ---------------------------------- Check the new file ----------------------
        SQLResultset = SQLstmt.executeQuery(outSQL);
        if (!SQLResultset.next()) {
            System.out.println("No new BMS_APInvoice files have been received to FSH ");
            newRecord = false;
            String nonewfile = ",FILE_NAME," + "No new BMS_APInvoice files have been received to FSH" + "," + "," + ",Pass";
            section1_results.add(nonewfile);
            list.addAll(section1_results);
        }

        if (newRecord) {

            //------------------------ Section 1 Start Print all the new file in the report-------------------
            for (String num_file : file_list) {
                file_lists = num_file.split(",");
                for (String file_list1 : file_lists) {
                    xml_file_name1 = file_list1;
                    //int section1_map_row = 1;
                    String newfile = section1_map_row + ",FILE_NAME," + xml_file_name1 + "," + xml_file_name1 + ",Pass";
                    section1_map_row++;
                    section1_results.add(newfile);
                }
            }
            list.addAll(section1_results);
            //report_generation.report_Test1(section1_results, "Section1", xml_file_name1, "B4C BC CONS BATCH TABLE VALIDATION", "B4C_SCHBilling", "B4C BC VALIDATION");
            //------------------------ Section 1 End ----------------------------------------------
        }

        List<String> list_header = new ArrayList<String>(); // -- Add all the header id
        if (newRecord) {
            //------------ Split the file names form the list --------------
            for (String xml_file_name : file_list) {
                int section2_map_row = 1;
                int CONS_flag = 0;
                List<String> section2_results = new ArrayList<String>();
                List<String> section3_results = new ArrayList<String>();
                List<String> section2_results_tbl = new ArrayList<String>();

                file_name = xml_file_name;


        /*//------ get the new file from batch control table --------------
        boolean newRecord = true;
        //SQLResultset = SQLstmt.executeQuery("Select distinct file_name from DLG_FSH_CTL_BATCH where Trunc(LOAD_DATE) = TRUNC(SYSDATE-1) and system = 'ECLI' and pattern = 'BMS_AP_State_model_005_1.csv'");
        SQLResultset = SQLstmt.executeQuery("Select distinct file_name from DLG_FSH_CTL_BATCH where file_name = 'BMS_AP_RevSts_ctl_001.csv'");
        while (SQLResultset.next()) {
            file_list.add(SQLResultset.getString("FILE_NAME"));
            System.out.println("File name---" + SQLResultset.getString("FILE_NAME"));
            list.addAll(section1_results);
        }

        //------------------ validate no new files -----------------------
        String xmlfile_name = "null";
        //SQLResultset = SQLstmt.executeQuery("Select distinct file_name from DLG_FSH_CTL_BATCH where Trunc(LOAD_DATE) = TRUNC(SYSDATE-1) and system = 'ECLI' and pattern = 'APInvoice' ");
        SQLResultset = SQLstmt.executeQuery("Select distinct file_name from DLG_FSH_CTL_BATCH where file_name = 'BMS_AP_RevSts_ctl_001.csv'");
        if (!SQLResultset.next()) {
            System.out.println("No new BMS AP INVOICE files have been received to FSH ");
            newRecord = false;
            String nonewfile = ",FILE_NAME," + "No new BMS AP INVOICE files have been received to FSH" + "," + "," + ",Pass";
        }

        List<String> list_header = new ArrayList<String>(); // -- Add all the header id
        if (newRecord) {
            //------------ Split the file names form the list --------------
            for (String xml_file_name : file_list) {

                //-------------- Validation Cons to Stag table ----------------
                SQLResultset = SQLstmt.executeQuery("SELECT * from DLG_FSH_CONS_BMSX_API_HDR WHERE FILE_NAME = '" + xml_file_name + "'");
                while (SQLResultset.next()) {
                    db_cons_header_id = SQLResultset.getString("HEADER_ID");
                    list_header.add(db_cons_header_id);
                }*/

                //--------------------------------- Section 3 Start Here ---------------------------------
                boolean sec3flag = true;
                String db_STG_ACTL_RCDS = null;
                Integer db_STG_ACTL_RCDS1 = 0;

                SQLResultset = SQLstmt.executeQuery("SELECT COUNT(HEADER_ID) as STG_ACTL_RCDS FROM DLG_FSH_STG_COMM_API_HDR WHERE FILE_NAME = '" + xml_file_name + "'");
                while (SQLResultset.next()) {
                    db_STG_ACTL_RCDS = SQLResultset.getString("STG_ACTL_RCDS");
                    db_STG_ACTL_RCDS1 = SQLResultset.getInt("STG_ACTL_RCDS");
                    System.out.println("stag Actual header count ----" + db_STG_ACTL_RCDS);
                }

                if (db_STG_ACTL_RCDS1 == 0) {  //--- Zero record validation
                    sec3flag = false;
                    String pc_stg_header_line = 1 + "," + "STG_ACTL_RCDS DB Does not have any records" + "," + "STG_ACTL_RCDS DB Does not have any records" + "," + "STG_AGG_ACTUAL_HEADER DB Does not have any records" + ",Fail";
                    section3_results.add(pc_stg_header_line);
                }

                /*SQLResultset = SQLstmt.executeQuery("SELECT SUMMARY_FLAG FROM DLG_FSH_STG_COMM_API_HDR WHERE FILE_NAME = '" + xml_file_name + "'");
                while (SQLResultset.next()) {
                    db_STG_SUMMARY_FLAG = SQLResultset.getString("SUMMARY_FLAG");
                    System.out.println("stag Summary Flag ----" + db_STG_SUMMARY_FLAG);
                }*/

                if (sec3flag){
                    do{

                        /*SQLResultset = SQLstmt.executeQuery("SELECT COUNT(a.HEADER_ID) as STG_EXP_SUM_HDRS \n" +
                                "FROM(\n" +
                                "SELECt HEADER_ID,STATUS,\n" +
                                "row_number() over(partition by SOURCE,UNDERWRITER,BRAND,LINE_OF_BUSINESS,PRODUCT_TYPE,CHANNEL,TRANSACTION_DATE,BILLING_INSTRUCTION_TYPE,ON_RISK_DATE,OFF_RISK_DATE,TAX_REGION,PRODUCT_KEY,EVENT_CODE,ENTITY_TYPE_CODE,SUMMARY_FLAG,ACCOUNTING_METHOD\n" +
                                "ORDER BY SOURCE,UNDERWRITER,BRAND,LINE_OF_BUSINESS,PRODUCT_TYPE,CHANNEL,TRANSACTION_DATE,BILLING_INSTRUCTION_TYPE,ON_RISK_DATE,OFF_RISK_DATE,TAX_REGION,PRODUCT_KEY,EVENT_CODE,ENTITY_TYPE_CODE,SUMMARY_FLAG,ACCOUNTING_METHOD) row_1\n" +
                                "FROM FSH_ORA_DATA.DLG_FSH_STG_COMM_API_HDR WHERE FILE_NAME = '" + xml_file_name + "')a \n" +
                                "where a.row_1 = 1\n" +
                                "AND a.STATUS = 'COMPLETE'");

                        while (SQLResultset.next()) {
                            String STG_EXP_SUM_HDRS = SQLResultset.getString("STG_EXP_SUM_HDRS");*/
                            SQLResultset = SQLstmt.executeQuery("SELECT count(INVOICE_ID) as STG_AGG_ACTUAL_HEADER FROM DLG_FSH_STG_COMM_API_AGG_HDR WHERE FILE_NAME = '" + xml_file_name + "'");
                            while (SQLResultset.next()) {
                                String STG_AGG_ACTUAL_HEADER = SQLResultset.getString("STG_AGG_ACTUAL_HEADER");
                                System.out.println("stag Aggregate actual header count ----" + STG_AGG_ACTUAL_HEADER);
                                System.out.println("stag actual header count ----" + db_STG_ACTL_RCDS);
                                //System.out.println("stag expected header count ----" + STG_EXP_SUM_HDRS);
                                /*if (db_STG_SUMMARY_FLAG.equals("Y")) {
                                    if (STG_EXP_SUM_HDRS.equals(STG_AGG_ACTUAL_HEADER)) {
                                        String pc_stg_header_line = 1 + "," + db_STG_ACTL_RCDS + "," + STG_EXP_SUM_HDRS + "," + STG_AGG_ACTUAL_HEADER + ",Pass";
                                        section3_results.add(pc_stg_header_line);
                                    } else {
                                        String pc_stg_header_line = 1 + "," + db_STG_ACTL_RCDS + "," + STG_EXP_SUM_HDRS + "," + STG_AGG_ACTUAL_HEADER + ",Fail";
                                        section3_results.add(pc_stg_header_line);
                                    }
                                } */
                                // else if(db_STG_SUMMARY_FLAG.equals("N")){
                                    if (db_STG_ACTL_RCDS.equals(STG_AGG_ACTUAL_HEADER)) {
                                        String pc_stg_header_line = 1 + "," + db_STG_ACTL_RCDS + "," + db_STG_ACTL_RCDS + "," + STG_AGG_ACTUAL_HEADER + ",Pass";
                                        section3_results.add(pc_stg_header_line);
                                    } else {
                                        String pc_stg_header_line = 1 + "," + db_STG_ACTL_RCDS + "," + db_STG_ACTL_RCDS + "," + STG_AGG_ACTUAL_HEADER + ",Fail";
                                        section3_results.add(pc_stg_header_line);
                                    }

                                }
                    }while (SQLResultset.next());
                }



                //---------------- LINE Validation --------------------
                boolean sec3_lineflag = true;
                String db_STG_ACTL_RCDS_LINE = null;
                Integer db_STG_ACTL_RCDS1_LINE = 0;

                SQLResultset = SQLstmt.executeQuery("SELECT COUNT(LINE_ID) as STG_ACTL_RCDS FROM DLG_FSH_STG_COMM_API_LIN WHERE FILE_NAME = '" + xml_file_name + "'");
                while (SQLResultset.next()) {
                    db_STG_ACTL_RCDS_LINE = SQLResultset.getString("STG_ACTL_RCDS");
                    db_STG_ACTL_RCDS1_LINE = SQLResultset.getInt("STG_ACTL_RCDS");
                }

                if (db_STG_ACTL_RCDS1_LINE == 0) {  //--- Zero record validation
                    sec3_lineflag = false;
                    String pc_stg_header_line = 1 + "," + "STG_ACTL_RCDS DB Does not have any records" + "," + "STG_ACTL_RCDS DB Does not have any records" + "," + "STG_AGG_ACTUAL_HEADER DB Does not have any records" + ",Fail";
                    section3_results.add(pc_stg_header_line);
                }

                /*SQLResultset = SQLstmt.executeQuery("SELECT SUMMARY_FLAG FROM DLG_FSH_STG_COMM_API_LIN WHERE FILE_NAME = '" + xml_file_name + "'");
                while (SQLResultset.next()) {
                    db_STG_LINE_SUMMARY_FLAG = SQLResultset.getString("SUMMARY_FLAG");
                    System.out.println("stag Summary Flag ----" + db_STG_LINE_SUMMARY_FLAG);
                }*/

                if (sec3_lineflag){
                    do{

                        SQLResultset = SQLstmt.executeQuery("SELECT COUNT(a.LINE_ID) as STG_EXP_SUM_HDRS \n" +
                                "FROM(\n" +
                                "SELECt LINE_ID,STATUS,\n" +
                                "row_number() over(partition by CATEGORY,TAX_CODE,DIST_CODE_CONCATENATED,CURRENCY_CODE\n" +
                                "ORDER BY CATEGORY,TAX_CODE,DIST_CODE_CONCATENATED,CURRENCY_CODE) row_1\n" +
                                "FROM FSH_ORA_DATA.DLG_FSH_STG_COMM_API_LIN WHERE FILE_NAME  = '" + xml_file_name + "')a \n" +
                                "where a.row_1 = 1\n" +
                                "AND a.STATUS = 'COMPLETE'");

                        while (SQLResultset.next()) {
                            String STG_EXP_SUM_HDRS_LINE = SQLResultset.getString("STG_EXP_SUM_HDRS");
                            SQLResultset = SQLstmt.executeQuery("SELECT count(INVOICE_ID)as STG_AGG_ACTUAL_HEADER FROM DLG_FSH_STG_COMM_API_AGG_LIN WHERE FILE_NAME = '" + xml_file_name + "'");
                            while (SQLResultset.next()) {
                                String STG_AGG_ACTUAL_HEADER_LINE = SQLResultset.getString("STG_AGG_ACTUAL_HEADER");

                                //if (db_STG_LINE_SUMMARY_FLAG.equals("Y")) {
                                    if (STG_EXP_SUM_HDRS_LINE.equals(STG_AGG_ACTUAL_HEADER_LINE)) {
                                        String pc_stg_header_line = 1 + "," + db_STG_ACTL_RCDS_LINE + "," + STG_EXP_SUM_HDRS_LINE + "," + STG_AGG_ACTUAL_HEADER_LINE + ",Pass";
                                        section3_results.add(pc_stg_header_line);
                                    } else {
                                        String pc_stg_header_line = 1 + "," + db_STG_ACTL_RCDS_LINE + "," + STG_EXP_SUM_HDRS_LINE + "," + STG_AGG_ACTUAL_HEADER_LINE + ",Fail";
                                        section3_results.add(pc_stg_header_line);
                                    }
                                /*} else if(db_STG_LINE_SUMMARY_FLAG.equals("N")){
                                    if (db_STG_ACTL_RCDS_LINE.equals(STG_AGG_ACTUAL_HEADER_LINE)) {
                                        String pc_stg_header_line = 1 + "," + db_STG_ACTL_RCDS_LINE + "," + db_STG_ACTL_RCDS_LINE + "," + STG_AGG_ACTUAL_HEADER_LINE + ",Pass";
                                        section3_results.add(pc_stg_header_line);
                                    } else {
                                        String pc_stg_header_line = 1 + "," + db_STG_ACTL_RCDS_LINE + "," + db_STG_ACTL_RCDS_LINE + "," + STG_AGG_ACTUAL_HEADER_LINE + ",Fail";
                                        section3_results.add(pc_stg_header_line);
                                    }

                                }*/
                            }
                        }

                    }while (SQLResultset.next());
                }


             //-------------- Validation Cons to Stag table ----------------
                String BMSAPInvoice_consSqlQuery = connect_db.executeQuery_DB("BMS_AP", "APInvoice_Cons", "BMS");
                SQLResultset = SQLstmt.executeQuery(BMSAPInvoice_consSqlQuery + "'" + file_name + "'");
                //SQLResultset = SQLstmt.executeQuery("SELECT * from DLG_FSH_CONS_BMSX_API_HDR WHERE FILE_NAME = '" + xml_file_name + "'");
                while (SQLResultset.next()) {
                    db_cons_header_id = SQLResultset.getString("HEADER_ID");
                    list_header.add(db_cons_header_id);
                }

                for (int i = 0; i < list_header.size(); i++) {
                    SQLResultset = SQLstmt.executeQuery(BMSAPInvoice_consSqlQuery + "'" + file_name + "' and HEADER_ID = '" + list_header.get(i) + "' ");
                    //SQLResultset = SQLstmt.executeQuery("SELECT * from DLG_FSH_CONS_BMSX_API_HDR WHERE FILE_NAME = '" + xml_file_name + "' and HEADER_ID ='" + list_header.get(i) + "'");
                    while (SQLResultset.next()) {
                        db_cons_header_id = SQLResultset.getString("HEADER_ID");
                        db_cons_header_pkey = SQLResultset.getString("HEADER_PKEY");
                        db_CONS_SOURCE = SQLResultset.getString("SOURCE");
                        db_CONS_TRANSACTION_DATE = SQLResultset.getString("TRANSACTION_DATE");
                        db_CONS_SUPPLIER_NAME = SQLResultset.getString("SUPPLIER_NAME");
                        db_CONS_CLAIM_NUMBER = SQLResultset.getString("CLAIM_NUMBER");
                        db_CONS_CHANNEL = SQLResultset.getString("CHANNEL");
                        db_CONS_THIRD_CLAIM_REF = SQLResultset.getString("THIRD_CLAIM_REF");
                        db_CONS_INVOICE_NUM = SQLResultset.getString("INVOICE_NUM");
                        db_CONS_INVOICE_DATE = SQLResultset.getString("INVOICE_DATE");
                        db_CONS_INVOICE_RECEIVED_DATE = SQLResultset.getString("INVOICE_RECEIVED_DATE");
                        db_CONS_VENDOR_SITE_ID = SQLResultset.getString("VENDOR_SITE_ID");
                        db_CONS_SYSTEM = SQLResultset.getString("SYSTEM");
                        db_CONS_FILE_NAME = SQLResultset.getString("FILE_NAME");
                        db_CONS_TRANSACTION_TYPE = SQLResultset.getString("TRANSACTION_TYPE");
                        db_CONS_TXN_REFERENCE1 = SQLResultset.getString("TXN_REFERENCE1");
                        db_CONS_INVOICE_CURRENCY_CODE = SQLResultset.getString("INVOICE_CURRENCY_CD");
                        db_CONS_INVOICE_GROSS_AMOUNT = SQLResultset.getString("INVOICE_GROSS_AMOUNT");
                        db_CONS_INVOICE_NET_AMOUNT = SQLResultset.getString("INVOICE_NET_AMOUNT");
                        db_CONS_INVOICE_VAT_AMOUNT = SQLResultset.getString("INVOICE_VAT_AMOUNT");
                        CONS_HDR_STATUS = SQLResultset.getString("STATUS");
                        load_date = SQLResultset.getString("LOAD_DATE");
                        String db_file_name = SQLResultset.getString("FILE_NAME");

                        //Converting Load date format
                        String load_dateTRIM = load_date.substring(0, 10);
                        load_dateFormat = Date.valueOf(load_dateTRIM);
                        System.out.println(load_dateFormat);

                        //Validating mandatory fields in consolidation table
                        //TRANSACTION_DATE - mandatory validation
                        if ((db_CONS_TRANSACTION_DATE == null) && (CONS_HDR_STATUS != "REVIEW")) {

                            String stg_TRANSACTION_DATE = cons_mandatory_map_row + "," + db_cons_header_id + ",TRANSACTION_DATE," + "TRANSACTION_DATE : " + db_CONS_TRANSACTION_DATE + "," + "TRANSACTION_DATE was not found," + CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(stg_TRANSACTION_DATE);
                            cons_mandatory_map_row++;
                        } else {
                            String stg_TRANSACTION_DATE = cons_mandatory_map_row + "," + db_cons_header_id + ",TRANSACTION_DATE," + "TRANSACTION_DATE : " + db_CONS_TRANSACTION_DATE + "," + "TRANSACTION_DATE was found," + CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(stg_TRANSACTION_DATE);
                            cons_mandatory_map_row++;
                        }

                        //HEADER_ID - mandatory validation
                        if ((db_cons_header_id == null) && (CONS_HDR_STATUS != "REVIEW")) {

                            String stg_CLAIM_NUMBER = "," + ",HEADER_ID," + "HEADER_ID : " + db_cons_header_id + "," + "HEADER_ID was not found," + CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(stg_CLAIM_NUMBER);
                        } else {
                            String stg_CLAIM_NUMBER = "," + ",HEADER_ID," + "HEADER_ID : " + db_cons_header_id + "," + "HEADER_ID was found," + CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(stg_CLAIM_NUMBER);
                        }

                        //CLAIM_NUMBER - mandatory validation
                        if ((db_CONS_CLAIM_NUMBER == null) && (CONS_HDR_STATUS != "REVIEW")) {

                            String stg_CLAIM_NUMBER = "," + ",CLAIM_NUMBER," + "CLAIM_NUMBER : " + db_CONS_CLAIM_NUMBER + "," + "CLAIM_NUMBER was not found," + CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(stg_CLAIM_NUMBER);
                        } else {
                            String stg_CLAIM_NUMBER = "," + ",CLAIM_NUMBER," + "CLAIM_NUMBER : " + db_CONS_CLAIM_NUMBER + "," + "CLAIM_NUMBER was found," + CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(stg_CLAIM_NUMBER);
                        }

                        //CHANNEL - mandatory validation
                        if ((db_CONS_CHANNEL == null) && (CONS_HDR_STATUS != "REVIEW")) {

                            String stg_CHANNEL = "," + ",CHANNEL," + "CHANNEL : " + db_CONS_CHANNEL + "," + "CHANNEL was not found," + CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(stg_CHANNEL);
                        } else {
                            String stg_CHANNEL = "," + ",CHANNEL," + "CHANNEL : " + db_CONS_CHANNEL + "," + "CHANNEL was found," + CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(stg_CHANNEL);
                        }

                        //INVOICE_NET_AMOUNT - mandatory validation
                        if ((db_CONS_INVOICE_NET_AMOUNT == null) && (CONS_HDR_STATUS != "REVIEW")) {

                            String stg_INVOICE_NET_AMOUNT = "," + ",INVOICE_NET_AMOUNT," + "INVOICE_NET_AMOUNT : " + db_CONS_INVOICE_NET_AMOUNT + "," + "INVOICE_NET_AMOUNT was not found," + CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(stg_INVOICE_NET_AMOUNT);
                        } else {
                            String stg_INVOICE_NET_AMOUNT = "," + ",INVOICE_NET_AMOUNT," + "INVOICE_NET_AMOUNT : " + db_CONS_INVOICE_NET_AMOUNT + "," + "INVOICE_NET_AMOUNT was found," + CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(stg_INVOICE_NET_AMOUNT);
                        }

                        //INVOICE_VAT_AMOUNT - mandatory validation
                        if ((db_CONS_INVOICE_VAT_AMOUNT == null) && (CONS_HDR_STATUS != "REVIEW")) {

                            String stg_INVOICE_VAT_AMOUNT = "," + ",INVOICE_VAT_AMOUNT," + "INVOICE_VAT_AMOUNT : " + db_CONS_INVOICE_VAT_AMOUNT + "," + "INVOICE_VAT_AMOUNT was not found," + CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(stg_INVOICE_VAT_AMOUNT);
                        } else {
                            String stg_INVOICE_VAT_AMOUNT = "," + ",INVOICE_VAT_AMOUNT," + "INVOICE_VAT_AMOUNT : " + db_CONS_INVOICE_VAT_AMOUNT + "," + "INVOICE_VAT_AMOUNT was found," + CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(stg_INVOICE_VAT_AMOUNT);
                        }

                        //INVOICE_GROSS_AMOUNT - mandatory validation
                        if ((db_CONS_INVOICE_GROSS_AMOUNT == null) && (CONS_HDR_STATUS != "REVIEW")) {

                            String stg_INVOICE_GROSS_AMOUNT = "," + ",INVOICE_GROSS_AMOUNT," + "INVOICE_GROSS_AMOUNT : " + db_CONS_INVOICE_GROSS_AMOUNT + "," + "INVOICE_GROSS_AMOUNT was not found," + CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(stg_INVOICE_GROSS_AMOUNT);
                        } else {
                            String stg_INVOICE_GROSS_AMOUNT = "," + ",INVOICE_GROSS_AMOUNT," + "INVOICE_GROSS_AMOUNT : " + db_CONS_INVOICE_GROSS_AMOUNT + "," + "INVOICE_GROSS_AMOUNT was found," + CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(stg_INVOICE_GROSS_AMOUNT);
                        }

                        //INVOICE_NUM - mandatory validation
                        if ((db_CONS_INVOICE_NUM == null) && (CONS_HDR_STATUS != "REVIEW")) {

                            String stg_INVOICE_NUM = "," + ",INVOICE_NUM," + "INVOICE_NUM : " + db_CONS_INVOICE_NUM + "," + "INVOICE_NUM was not found," + CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(stg_INVOICE_NUM);
                        } else {
                            String stg_INVOICE_NUM = "," + ",INVOICE_NUM," + "INVOICE_NUM : " + db_CONS_INVOICE_NUM + "," + "INVOICE_NUM was found," + CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(stg_INVOICE_NUM);
                        }

                        //INVOICE_DATE - mandatory validation
                        if ((db_CONS_INVOICE_DATE == null) && (CONS_HDR_STATUS != "REVIEW")) {

                            String stg_INVOICE_DATE = "," + ",INVOICE_DATE," + "INVOICE_DATE : " + db_CONS_INVOICE_DATE + "," + "INVOICE_DATE was not found," + CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(stg_INVOICE_DATE);
                        } else {
                            String stg_INVOICE_DATE = "," + ",INVOICE_DATE," + "INVOICE_DATE : " + db_CONS_INVOICE_DATE + "," + "INVOICE_DATE was found," + CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(stg_INVOICE_DATE);
                        }

                        //INVOICE_RECEIVED_DATE - mandatory validation
                        if ((db_CONS_INVOICE_RECEIVED_DATE == null) && (CONS_HDR_STATUS != "REVIEW")) {

                            String stg_INVOICE_RECEIVED_DATE = "," + ",INVOICE_RECEIVED_DATE," + "INVOICE_RECEIVED_DATE : " + db_CONS_INVOICE_RECEIVED_DATE + "," + "INVOICE_RECEIVED_DATE was not found," + CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(stg_INVOICE_RECEIVED_DATE);
                        } else {
                            String stg_INVOICE_RECEIVED_DATE = "," + ",INVOICE_RECEIVED_DATE," + "INVOICE_RECEIVED_DATE : " + db_CONS_INVOICE_RECEIVED_DATE + "," + "INVOICE_RECEIVED_DATE was found," + CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(stg_INVOICE_RECEIVED_DATE);
                        }

                        //SUPPLIER_NAME - mandatory validation
                        if ((db_CONS_SUPPLIER_NAME == null) && (CONS_HDR_STATUS != "REVIEW")) {

                            String stg_SUPPLIER_NAME = "," + ",SUPPLIER_NAME," + "SUPPLIER_NAME : " + db_CONS_SUPPLIER_NAME + "," + "SUPPLIER_NAME was not found," + CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(stg_SUPPLIER_NAME);
                        } else {
                            String stg_SUPPLIER_NAME = "," + ",SUPPLIER_NAME," + "SUPPLIER_NAME : " + db_CONS_SUPPLIER_NAME + "," + "SUPPLIER_NAME was found," + CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(stg_SUPPLIER_NAME);
                        }

                        //VENDOR_SITE_ID - mandatory validation
                        if ((db_CONS_VENDOR_SITE_ID == null) && (CONS_HDR_STATUS != "REVIEW")) {

                            String stg_VENDOR_SITE_ID = "," + ",VENDOR_SITE_ID," + "VENDOR_SITE_ID : " + db_CONS_VENDOR_SITE_ID + "," + "VENDOR_SITE_ID was not found," + CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(stg_VENDOR_SITE_ID);
                        } else {
                            String stg_VENDOR_SITE_ID = "," + ",VENDOR_SITE_ID," + "VENDOR_SITE_ID : " + db_CONS_VENDOR_SITE_ID + "," + "VENDOR_SITE_ID was found," + CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(stg_VENDOR_SITE_ID);
                        }

                        // TRANSACTION_TYPE - mandatory validation
                        if ((db_CONS_TRANSACTION_TYPE == null) && (CONS_HDR_STATUS != "REVIEW")) {

                            String TRANSACTION_TYPE = "," + ", TRANSACTION_TYPE," + " TRANSACTION_TYPE : " + db_CONS_TRANSACTION_TYPE + "," + " TRANSACTION_TYPE was not found," + CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(TRANSACTION_TYPE);
                        } else {
                            String TRANSACTION_TYPE = "," + ", TRANSACTION_TYPE," + " TRANSACTION_TYPE : " + db_CONS_TRANSACTION_TYPE + "," + " TRANSACTION_TYPE was found," + CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(TRANSACTION_TYPE);
                        }

                        // TXN_REFERENCE1 - mandatory validation
                        if ((db_CONS_TXN_REFERENCE1 == null) && (CONS_HDR_STATUS != "REVIEW")) {

                            String stg_TXN_REFERENCE1 = "," + ", TXN_REFERENCE1," + " TXN_REFERENCE1 : " + db_CONS_TXN_REFERENCE1 + "," + " TXN_REFERENCE1 was not found," + CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(stg_TXN_REFERENCE1);
                        } else {
                            String stg_TXN_REFERENCE1 = "," + ", TXN_REFERENCE1," + " TXN_REFERENCE1 : " + db_CONS_TXN_REFERENCE1 + "," + " TXN_REFERENCE1 was found," + CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(stg_TXN_REFERENCE1);
                        }


                        //------------------- Consolidation to Staging ----------------------------------
                        String BMSAPInvoice_stgSqlQuery = connect_db.executeQuery_DB("BMS_AP", "APInvoice_Stg", "BMS");
                        SQLResultset = SQLstmt.executeQuery(BMSAPInvoice_stgSqlQuery + "'" + file_name + "' and HEADER_ID = '" + list_header.get(i) + "' ");
                        //SQLResultset = SQLstmt.executeQuery("SELECT * from DLG_FSH_STG_COMM_API_HDR WHERE FILE_NAME = '" + xml_file_name + "' and HEADER_ID ='" + list_header.get(i) + "'");
                        System.out.println("Header id outer ---" + db_cons_header_id);
                        if (!SQLResultset.next()) {
                            String stg_header_id = section2_map_row + ",HEADER_ID," + "no records available in STG table" + "," + db_cons_header_id + ",Fail";
                            section2_results.add(stg_header_id);
                        } else {
                            SQLResultset = SQLstmt.executeQuery(BMSAPInvoice_stgSqlQuery + "'" + file_name + "' and HEADER_ID = '" + list_header.get(i) + "' ");
                            while (SQLResultset.next()) {
                                db_STG_HEADER_ID = SQLResultset.getString("HEADER_ID");
                                db_STG_SOURCE = SQLResultset.getString("SOURCE");
                                db_STG_PAYMENT_METHOD_CODE = SQLResultset.getString("PAYMENT_METHOD_CODE");
                                String db_STG_THIRD_PARTY_REF = SQLResultset.getString("THIRD_PARTY_REF");
                                db_STG_TRANSACTION_DATE = SQLResultset.getString("TRANSACTION_DATE");
                                db_STG_GLOBAL_ATTRIBUTE2 = SQLResultset.getString("GLOBAL_ATTRIBUTE2");
                                db_STG_CHANNEL = SQLResultset.getString("CHANNEL");
                                db_STG_GLOBAL_ATTRIBUTE3 = SQLResultset.getString("GLOBAL_ATTRIBUTE3");
                                db_STG_GLOBAL_ATTRIBUTE2 = SQLResultset.getString("GLOBAL_ATTRIBUTE2");
                                db_STG_INVOICE_AMOUNT = SQLResultset.getString("INVOICE_AMOUNT");
                                db_STG_INVOICE_NUM = SQLResultset.getString("INVOICE_NUM");
                                db_STG_DESCRIPTION = SQLResultset.getString("DESCRIPTION");
                                db_STG_INVOICE_DATE = SQLResultset.getString("INVOICE_DATE");
                                db_STG_INVOICE_RECEIVED_DATE = SQLResultset.getString("INVOICE_RECEIVED_DATE");
                                db_STG_VENDOR_ID = SQLResultset.getString("VENDOR_ID");
                                db_STG_VENDOR_NAME = SQLResultset.getString("VENDOR_NAME");
                                db_STG_VENDOR_SITE_ID = SQLResultset.getString("VENDOR_SITE_ID");
                                db_STG_VENDOR_SITE_CD = SQLResultset.getString("VENDOR_SITE_CD");
                                db_STG_VENDOR_SITE_CODE = SQLResultset.getString("VENDOR_SITE_CODE");
                                db_STG_EXCHANGE_EFFECTIVE_DATE = SQLResultset.getString("EXCHANGE_EFFECTIVE_DATE");
                                db_STG_ATTRIBUTE_CATEGORY = SQLResultset.getString("ATTRIBUTE_CATEGORY");
                                db_STG_ATTRIBUTE1 = SQLResultset.getString("ATTRIBUTE1");
                                db_STG_ATTRIBUTE2 = SQLResultset.getString("ATTRIBUTE2");
                                db_STG_ATTRIBUTE3 = SQLResultset.getString("ATTRIBUTE3");
                                db_STG_ATTRIBUTE4 = SQLResultset.getString("ATTRIBUTE4");
                                db_STG_ATTRIBUTE5 = SQLResultset.getString("ATTRIBUTE5");
                                db_STG_ATTRIBUTE6 = SQLResultset.getString("ATTRIBUTE6");
                                db_STG_ATTRIBUTE7 = SQLResultset.getString("ATTRIBUTE7");
                                db_STG_ATTRIBUTE8 = SQLResultset.getString("ATTRIBUTE8");
                                db_STG_FILE_NAME = SQLResultset.getString("FILE_NAME");
                                db_STG_INVOICE_ID = SQLResultset.getString("INVOICE_ID");
                                db_STG_PAY_GROUP_LOOKUP_CODE = SQLResultset.getString("PAY_GROUP_LOOKUP_CODE");
                                db_STG_ORG_ID = SQLResultset.getString("ORG_ID");
                                db_STG_INVOICE_CURRENCY_CODE = SQLResultset.getString("INVOICE_CURRENCY_CODE");
                                db_STG_INVOICE_AMOUNT = SQLResultset.getString("INVOICE_AMOUNT");
                                db_STG_FSH_ATTRIBUTE_04 = SQLResultset.getString("FSH_ATTRIBUTE_04");
                                db_STG_FSH_ATTRIBUTE_05 = SQLResultset.getString("FSH_ATTRIBUTE_05");
                                db_STG_LINE_OF_BUSINESS = SQLResultset.getString("LINE_OF_BUSINESS");
                                db_STG_PAYEE_TYPE = SQLResultset.getString("PAYEE_TYPE");
                                //db_STG_PRODUCT = SQLResultset.getString("PRODUCT");
                                //db_STG_UNDERWRITER = SQLResultset.getString("UNDERWRITER");
                                db_STG_CALC_TAX_DURING_IMPORT_FLAG = SQLResultset.getString("CALC_TAX_DURING_IMPORT_FLAG");
                                db_STG_BUSINESS_UNIT = SQLResultset.getString("BUSINESS_UNIT");
                                db_STG_BRAND = SQLResultset.getString("BRAND");
                                db_STG_ATTRIBUTE13 = SQLResultset.getString("ATTRIBUTE13");
                                db_STG_ATTRIBUTE15 = SQLResultset.getString("ATTRIBUTE15");
                                db_STG_GLOBAL_ATTRIBUTE1 = SQLResultset.getString("GLOBAL_ATTRIBUTE1");
                                db_STG_ATTRIBUTE9 = SQLResultset.getString("ATTRIBUTE9");
                                STG_HDR_STATUS = SQLResultset.getString("STATUS");

                                //Staging mandatory validations
                                //HEADER_ID - mandatory validation
                                if ((db_STG_HEADER_ID == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = stg_hdr_map_row + "," + db_STG_HEADER_ID + ",HEADER_ID," + "HEADER_ID : " + db_STG_HEADER_ID + "," + "HEADER_ID was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                    stg_hdr_map_row++;
                                } else {
                                    String stg_header_id = stg_hdr_map_row + "," + db_STG_HEADER_ID + ",HEADER_ID," + "HEADER_ID : " + db_STG_HEADER_ID + "," + "HEADER_ID was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                    stg_hdr_map_row++;
                                }

                                //INVOICE_ID - mandatory validation
                                if ((db_STG_INVOICE_ID == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",INVOICE_ID," + "INVOICE_ID : " + db_STG_INVOICE_ID + "," + "INVOICE_ID was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",INVOICE_ID," + "INVOICE_ID : " + db_STG_INVOICE_ID + "," + "INVOICE_ID was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //INVOICE_NUM - mandatory validation
                                if ((db_STG_INVOICE_NUM == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",INVOICE_NUM," + "INVOICE_NUM : " + db_STG_INVOICE_NUM + "," + "INVOICE_NUM was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",INVOICE_NUM," + "INVOICE_NUM : " + db_STG_INVOICE_NUM + "," + "INVOICE_NUM was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //INVOICE_DATE - mandatory validation
                                if ((db_STG_INVOICE_DATE == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",INVOICE_DATE," + "INVOICE_DATE : " + db_STG_INVOICE_DATE + "," + "INVOICE_DATE was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",INVOICE_DATE," + "INVOICE_DATE : " + db_STG_INVOICE_DATE + "," + "INVOICE_DATE was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //INVOICE_AMOUNT - mandatory validation
                                if ((db_STG_INVOICE_AMOUNT == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",INVOICE_AMOUNT," + "INVOICE_AMOUNT : " + db_STG_INVOICE_AMOUNT + "," + "INVOICE_AMOUNT was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",INVOICE_AMOUNT," + "INVOICE_AMOUNT : " + db_STG_INVOICE_AMOUNT + "," + "INVOICE_AMOUNT was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //INVOICE_CURRENCY_CODE - mandatory validation
                                if ((db_STG_INVOICE_CURRENCY_CODE == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",INVOICE_CURRENCY_CODE," + "INVOICE_CURRENCY_CODE : " + db_STG_INVOICE_CURRENCY_CODE + "," + "INVOICE_CURRENCY_CODE was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",INVOICE_CURRENCY_CODE," + "INVOICE_CURRENCY_CODE : " + db_STG_INVOICE_CURRENCY_CODE + "," + "INVOICE_CURRENCY_CODE was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //EXCHANGE_RATE - mandatory validation
                                if (db_STG_INVOICE_CURRENCY_CODE.equals("GBP")) {
                                    String stg_header_id = "," + ",EXCHANGE_RATE," + "EXCHANGE_RATE : " + db_STG_EXCHANGE_RATE + "," + "EXCHANGE_RATE is not mandatory- neither NULL nor NOTNULL," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                } else if ((db_STG_EXCHANGE_RATE == null) && (STG_HDR_STATUS != "REVIEW")) {
                                    String stg_header_id = "," + ",EXCHANGE_RATE," + "EXCHANGE_RATE : " + db_STG_EXCHANGE_RATE + "," + "EXCHANGE_RATE was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",EXCHANGE_RATE," + "EXCHANGE_RATE : " + db_STG_EXCHANGE_RATE + "," + "EXCHANGE_RATE was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //EXCHANGE_RATE_TYPE - mandatory validation
                                if (db_STG_INVOICE_CURRENCY_CODE.equals("GBP")) {
                                    String stg_header_id = "," + ",EXCHANGE_RATE_TYPE," + "EXCHANGE_RATE_TYPE : " + db_STG_EXCHANGE_RATE_TYPE + "," + "EXCHANGE_RATE_TYPE is not mandatory- neither NULL nor NOTNULL," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                } else if ((db_STG_EXCHANGE_RATE_TYPE == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",EXCHANGE_RATE_TYPE," + "EXCHANGE_RATE_TYPE : " + db_STG_EXCHANGE_RATE_TYPE + "," + "EXCHANGE_RATE_TYPE was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",EXCHANGE_RATE_TYPE," + "EXCHANGE_RATE_TYPE : " + db_STG_EXCHANGE_RATE_TYPE + "," + "EXCHANGE_RATE_TYPE was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //EXCHANGE_EFFECTIVE_DATE - mandatory validation
                                if (db_STG_INVOICE_CURRENCY_CODE.equals("GBP")) {
                                    String stg_header_id = "," + ",EXCHANGE_EFFECTIVE_DATE," + "EXCHANGE_EFFECTIVE_DATE : " + db_STG_EXCHANGE_EFFECTIVE_DATE + "," + "EXCHANGE_EFFECTIVE_DATE is not mandatory- neither NULL nor NOTNULL," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                } else if ((db_STG_EXCHANGE_EFFECTIVE_DATE == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",EXCHANGE_EFFECTIVE_DATE," + "EXCHANGE_EFFECTIVE_DATE : " + db_STG_EXCHANGE_EFFECTIVE_DATE + "," + "EXCHANGE_EFFECTIVE_DATE was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",EXCHANGE_EFFECTIVE_DATE," + "EXCHANGE_EFFECTIVE_DATE : " + db_STG_EXCHANGE_EFFECTIVE_DATE + "," + "EXCHANGE_EFFECTIVE_DATE was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }


                                //DESCRIPTION - mandatory validation
                                if (db_STG_PAYEE_TYPE.equals("PS") || db_STG_PAYEE_TYPE.equals("PI")) {
                                    if ((db_STG_DESCRIPTION == null) && (STG_HDR_STATUS != "REVIEW")) {

                                        String stg_header_id = "," + ",DESCRIPTION," + "DESCRIPTION : " + db_STG_DESCRIPTION + "," + "DESCRIPTION was not found," + STG_HDR_STATUS + "," + "Fail";
                                        section4_results.add(stg_header_id);
                                    } else {
                                        String stg_header_id = "," + ",DESCRIPTION," + "DESCRIPTION : " + db_STG_DESCRIPTION + "," + "DESCRIPTION was found," + STG_HDR_STATUS + "," + "Pass";
                                        section4_results.add(stg_header_id);
                                    }
                                } else {
                                    String stg_header_id = "," + ",DESCRIPTION," + "DESCRIPTION : " + db_STG_DESCRIPTION + "," + "DESCRIPTION is not mandatory- neither NULL nor NOTNULL," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }


                                //GLOBAL_ATTRIBUTE2 - mandatory validation
                                if ((db_STG_GLOBAL_ATTRIBUTE2 == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",GLOBAL_ATTRIBUTE2," + "GLOBAL_ATTRIBUTE2 : " + db_STG_GLOBAL_ATTRIBUTE2 + "," + "GLOBAL_ATTRIBUTE2 was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",GLOBAL_ATTRIBUTE2," + "GLOBAL_ATTRIBUTE2 : " + db_STG_GLOBAL_ATTRIBUTE2 + "," + "GLOBAL_ATTRIBUTE2 was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //GLOBAL_ATTRIBUTE3 - mandatory validation
                                if ((db_STG_GLOBAL_ATTRIBUTE3 == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",GLOBAL_ATTRIBUTE3," + "GLOBAL_ATTRIBUTE3 : " + db_STG_GLOBAL_ATTRIBUTE3 + "," + "GLOBAL_ATTRIBUTE3 was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",GLOBAL_ATTRIBUTE3," + "GLOBAL_ATTRIBUTE3 : " + db_STG_GLOBAL_ATTRIBUTE3 + "," + "GLOBAL_ATTRIBUTE3 was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //INVOICE_RECEIVED_DATE - mandatory validation
                                if ((db_STG_INVOICE_RECEIVED_DATE == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",INVOICE_RECEIVED_DATE," + "INVOICE_RECEIVED_DATE : " + db_STG_INVOICE_RECEIVED_DATE + "," + "INVOICE_RECEIVED_DATE was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",INVOICE_RECEIVED_DATE," + "INVOICE_RECEIVED_DATE : " + db_STG_INVOICE_RECEIVED_DATE + "," + "INVOICE_RECEIVED_DATE was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //CALC_TAX_DURING_IMPORT_FLAG - mandatory validation
                                if ((db_STG_CALC_TAX_DURING_IMPORT_FLAG == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",CALC_TAX_DURING_IMPORT_FLAG," + "CALC_TAX_DURING_IMPORT_FLAG : " + db_STG_CALC_TAX_DURING_IMPORT_FLAG + "," + "CALC_TAX_DURING_IMPORT_FLAG was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",CALC_TAX_DURING_IMPORT_FLAG," + "CALC_TAX_DURING_IMPORT_FLAG : " + db_STG_CALC_TAX_DURING_IMPORT_FLAG + "," + "CALC_TAX_DURING_IMPORT_FLAG was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //BUSINESS_UNIT - mandatory validation
                                if ((db_STG_BUSINESS_UNIT == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",BUSINESS_UNIT," + "BUSINESS_UNIT : " + db_STG_BUSINESS_UNIT + "," + "BUSINESS_UNIT was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",BUSINESS_UNIT," + "BUSINESS_UNIT : " + db_STG_BUSINESS_UNIT + "," + "BUSINESS_UNIT was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //TRANSACTION_DATE - mandatory validation
                                if ((db_STG_TRANSACTION_DATE == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",TRANSACTION_DATE," + "TRANSACTION_DATE : " + db_STG_TRANSACTION_DATE + "," + "TRANSACTION_DATE was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",TRANSACTION_DATE," + "TRANSACTION_DATE : " + db_STG_TRANSACTION_DATE + "," + "TRANSACTION_DATE was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //PAY_GROUP_LOOKUP_CODE - mandatory validation
                                if ((db_STG_PAY_GROUP_LOOKUP_CODE == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",PAY_GROUP_LOOKUP_CODE," + "PAY_GROUP_LOOKUP_CODE : " + db_STG_PAY_GROUP_LOOKUP_CODE + "," + "PAY_GROUP_LOOKUP_CODE was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",PAY_GROUP_LOOKUP_CODE," + "PAY_GROUP_LOOKUP_CODE : " + db_STG_PAY_GROUP_LOOKUP_CODE + "," + "PAY_GROUP_LOOKUP_CODE was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //ATTRIBUTE13 - mandatory validation
                                if ((db_STG_ATTRIBUTE13 == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",ATTRIBUTE13," + "ATTRIBUTE13 : " + db_STG_ATTRIBUTE13 + "," + "ATTRIBUTE13 was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",ATTRIBUTE13," + "ATTRIBUTE13 : " + db_STG_ATTRIBUTE13 + "," + "ATTRIBUTE13 was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //ATTRIBUTE15 - mandatory validation
                                if ((db_STG_ATTRIBUTE15 == null) && (STG_HDR_STATUS != "REVIEW")) {

                                    String stg_header_id = "," + ",ATTRIBUTE15," + "ATTRIBUTE15 : " + db_STG_ATTRIBUTE15 + "," + "ATTRIBUTE15 was not found," + STG_HDR_STATUS + "," + "Fail";
                                    section4_results.add(stg_header_id);
                                } else {
                                    String stg_header_id = "," + ",ATTRIBUTE15," + "ATTRIBUTE15 : " + db_STG_ATTRIBUTE15 + "," + "ATTRIBUTE15 was found," + STG_HDR_STATUS + "," + "Pass";
                                    section4_results.add(stg_header_id);
                                }

                                //Validation - CONS TO STG LAYER
                                if (db_cons_header_id.equals(db_STG_HEADER_ID)) {
                                    String cons_header_id = cons_stg_map_row + ",HEADER_ID," + db_STG_HEADER_ID + "," + db_cons_header_id + ",Pass";
                                    section1_results.add(cons_header_id);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",HEADER_ID" + "," + db_STG_HEADER_ID + "," + db_cons_header_id + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    cons_stg_map_row++;
                                } else {
                                    String cons_header_id = cons_stg_map_row + ",HEADER_ID," + db_STG_HEADER_ID + "," + db_cons_header_id + ",Fail";
                                    section1_results.add(cons_header_id);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",HEADER_ID" + "," + db_STG_HEADER_ID + "," + db_cons_header_id + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    cons_stg_map_row++;
                                    CONS_flag++;
                                }

                                //--------------------  Validation TRANSACTION_DATE ---------------
                                if (db_CONS_TRANSACTION_DATE.equals(db_STG_TRANSACTION_DATE)) {
                                    String cons_trans_date = ",TRANSACTION_DATE," + db_STG_TRANSACTION_DATE + "," + db_CONS_TRANSACTION_DATE + ",Pass";
                                    section1_results.add(cons_trans_date);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATE + "," + db_CONS_TRANSACTION_DATE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_trans_date = ",TRANSACTION_DATE," + db_STG_TRANSACTION_DATE + "," + db_CONS_TRANSACTION_DATE + ",Fail";
                                    section1_results.add(cons_trans_date);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATE + "," + db_CONS_TRANSACTION_DATE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation VENDOR_NAME ---------------
                                if (db_CONS_SUPPLIER_NAME.equals(db_STG_VENDOR_NAME)) {
                                    String cons_VENDOR_NAME = ",VENDOR_NAME," + db_STG_VENDOR_NAME + "," + db_CONS_SUPPLIER_NAME + ",Pass";
                                    section1_results.add(cons_VENDOR_NAME);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATE + "," + db_CONS_TRANSACTION_DATE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_VENDOR_NAME = ",VENDOR_NAME," + db_STG_VENDOR_NAME + "," + db_CONS_SUPPLIER_NAME + ",Fail";
                                    section1_results.add(cons_VENDOR_NAME);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATE + "," + db_CONS_TRANSACTION_DATE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }


                                //--------------------  Validation INVOICE_AMOUNT ---------------
                                if (db_CONS_INVOICE_GROSS_AMOUNT.equals(db_STG_INVOICE_AMOUNT)) {
                                    String cons_invoice_amount = ",INVOICE_AMOUNT," + db_STG_INVOICE_AMOUNT + "," + db_CONS_INVOICE_GROSS_AMOUNT + ",Pass";
                                    section1_results.add(cons_invoice_amount);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATE + "," + db_CONS_TRANSACTION_DATE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_invoice_amount = ",INVOICE_AMOUNT," + db_STG_INVOICE_AMOUNT + "," + db_CONS_INVOICE_GROSS_AMOUNT + ",Fail";
                                    section1_results.add(cons_invoice_amount);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATE + "," + db_CONS_TRANSACTION_DATE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation INVOICE_CURRENCY_CODE ---------------
                                if (db_CONS_INVOICE_CURRENCY_CODE.equals(db_STG_INVOICE_CURRENCY_CODE)) {
                                    String cons_INVOICE_CURRENCY_CODE = ",INVOICE_CURRENCY_CODE," + db_STG_INVOICE_CURRENCY_CODE + "," + db_CONS_INVOICE_CURRENCY_CODE + ",Pass";
                                    section1_results.add(cons_INVOICE_CURRENCY_CODE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATE + "," + db_CONS_TRANSACTION_DATE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_INVOICE_CURRENCY_CODE = ",INVOICE_CURRENCY_CODE," + db_STG_INVOICE_CURRENCY_CODE + "," + db_CONS_INVOICE_CURRENCY_CODE + ",Fail";
                                    section1_results.add(cons_INVOICE_CURRENCY_CODE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATE + "," + db_CONS_TRANSACTION_DATE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation TRANSACTION_TYPE ---------------
                                if (db_CONS_TRANSACTION_TYPE.equals(db_STG_FSH_ATTRIBUTE_04)) {
                                    String cons_TRANSACTION_TYPE = ",TRANSACTION_TYPE," + db_STG_FSH_ATTRIBUTE_04 + "," + db_CONS_TRANSACTION_TYPE + ",Pass";
                                    section1_results.add(cons_TRANSACTION_TYPE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATE + "," + db_CONS_TRANSACTION_DATE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_TRANSACTION_TYPE = ",TRANSACTION_TYPE," + db_STG_FSH_ATTRIBUTE_04 + "," + db_CONS_TRANSACTION_TYPE + ",Fail";
                                    section1_results.add(cons_TRANSACTION_TYPE);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATE + "," + db_CONS_TRANSACTION_DATE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation TXN_REFERENCE1 ---------------
                                if (db_CONS_TXN_REFERENCE1.equals(db_STG_FSH_ATTRIBUTE_05)) {
                                    String cons_TXN_REFERENCE1 = ",TXN_REFERENCE1," + db_STG_FSH_ATTRIBUTE_05 + "," + db_CONS_TXN_REFERENCE1 + ",Pass";
                                    section1_results.add(cons_TXN_REFERENCE1);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATE + "," + db_CONS_TRANSACTION_DATE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_TXN_REFERENCE1 = ",TXN_REFERENCE1," + db_STG_FSH_ATTRIBUTE_05 + "," + db_CONS_TXN_REFERENCE1 + ",Fail";
                                    section1_results.add(cons_TXN_REFERENCE1);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATE + "," + db_CONS_TRANSACTION_DATE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation TRANSACTION_DATE ---------------
                                if (db_CONS_TRANSACTION_DATE.equals(db_STG_TRANSACTION_DATE)) {
                                    String cons_trans_date = ",TRANSACTION_DATE," + db_STG_TRANSACTION_DATE + "," + db_CONS_TRANSACTION_DATE + ",Pass";
                                    section1_results.add(cons_trans_date);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATE + "," + db_CONS_TRANSACTION_DATE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_trans_date = ",TRANSACTION_DATE," + db_STG_TRANSACTION_DATE + "," + db_CONS_TRANSACTION_DATE + ",Fail";
                                    section1_results.add(cons_trans_date);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATE + "," + db_CONS_TRANSACTION_DATE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation CHANNEL ---------------
                                if (db_CONS_CHANNEL.equals(db_STG_CHANNEL)) {
                                    String cons_channel = ",CHANNEL," + db_STG_CHANNEL + "," + db_CONS_CHANNEL + ",Pass";
                                    section1_results.add(cons_channel);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATE + "," + db_CONS_TRANSACTION_DATE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_channel = ",CHANNEL," + db_STG_CHANNEL + "," + db_CONS_CHANNEL + ",Fail";
                                    section1_results.add(cons_channel);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATE + "," + db_CONS_TRANSACTION_DATE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation THIRD_CLAIM_REF ---------------
                                if (db_CONS_THIRD_CLAIM_REF.equals(db_STG_THIRD_PARTY_REF)) {
                                    String cons_third_claim_ref = ",THIRD_CLAIM_REF," + db_STG_THIRD_PARTY_REF + "," + db_CONS_THIRD_CLAIM_REF + ",Pass";
                                    section1_results.add(cons_third_claim_ref);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATE + "," + db_CONS_TRANSACTION_DATE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_third_claim_ref = ",THIRD_CLAIM_REF," + db_STG_THIRD_PARTY_REF + "," + db_CONS_THIRD_CLAIM_REF + ",Fail";
                                    section1_results.add(cons_third_claim_ref);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATE + "," + db_CONS_TRANSACTION_DATE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                // CLAIM_HANDLER_REF is not available in CONS layer
                                //--------------------  Validation CLAIM_HANDLER_REF ---------------
                                if (db_CONS_CLAIM_HANDLER_REF.equals(db_STG_CLAIM_HANDLER_REF)) {
                                    String cons_claim_handler_ref = ",CLAIM_HANDLER_REF," + db_STG_CLAIM_HANDLER_REF + "," + db_CONS_CLAIM_HANDLER_REF + ",Pass";
                                    section1_results.add(cons_claim_handler_ref);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATE + "," + db_CONS_TRANSACTION_DATE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_claim_handler_ref = ",CLAIM_HANDLER_REF," + db_STG_CLAIM_HANDLER_REF + "," + db_CONS_CLAIM_HANDLER_REF + ",Fail";
                                    section1_results.add(cons_claim_handler_ref);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATE + "," + db_CONS_TRANSACTION_DATE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                // APPROVER is not available in CONS layer
                                //--------------------  Validation APPROVER ---------------
                                if (db_CONS_APPROVER.equals(db_STG_APPROVER)) {
                                    String cons_approver = ",APPROVER," + db_STG_APPROVER + "," + db_CONS_APPROVER + ",Pass";
                                    section1_results.add(cons_approver);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATE + "," + db_CONS_TRANSACTION_DATE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_approver = ",APPROVER," + db_STG_APPROVER + "," + db_CONS_APPROVER + ",Fail";
                                    section1_results.add(cons_approver);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATE + "," + db_CONS_TRANSACTION_DATE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                // APPROVER is not available in CONS layer
                                //--------------------  Validation ACCOUNT_NUMBER ---------------
                                if (db_CONS_BANK_ACCOUNT_NUMBER.equals(db_STG_ACCOUNT_NUMBER)) {
                                    String cons_account_number = ",ACCOUNT_NUMBER," + db_STG_ACCOUNT_NUMBER + "," + db_CONS_BANK_ACCOUNT_NUMBER + ",Pass";
                                    section1_results.add(cons_account_number);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATE + "," + db_CONS_TRANSACTION_DATE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_account_number = ",ACCOUNT_NUMBER," + db_STG_ACCOUNT_NUMBER + "," + db_CONS_BANK_ACCOUNT_NUMBER + ",Fail";
                                    section1_results.add(cons_account_number);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATE + "," + db_CONS_TRANSACTION_DATE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                // SORT_CODE is not available in CONS layer
                                // --------------------  Validation SORT_CODE ---------------
                                if (db_CONS_BANK_SORT_CODE.equals(db_STG_SORT_CODE)) {
                                    String cons_sort_code = ",SORT_CODE," + db_STG_SORT_CODE + "," + db_CONS_BANK_SORT_CODE + ",Pass";
                                    section1_results.add(cons_sort_code);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATE + "," + db_CONS_TRANSACTION_DATE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_sort_code = ",SORT_CODE," + db_STG_SORT_CODE + "," + db_CONS_BANK_SORT_CODE + ",Fail";
                                    section1_results.add(cons_sort_code);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATE + "," + db_CONS_TRANSACTION_DATE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation INVOICE_NUM ---------------
                                if (db_CONS_INVOICE_NUM.equals(db_STG_INVOICE_NUM)) {
                                    String cons_invoice_number = ",INVOICE_NUM," + db_STG_INVOICE_NUM + "," + db_CONS_INVOICE_NUM + ",Pass";
                                    section1_results.add(cons_invoice_number);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATE + "," + db_CONS_TRANSACTION_DATE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_invoice_number = ",INVOICE_NUM," + db_STG_INVOICE_NUM + "," + db_CONS_INVOICE_NUM + ",Fail";
                                    section1_results.add(cons_invoice_number);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATE + "," + db_CONS_TRANSACTION_DATE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation DESCRIPTION ---------------
                                if (db_CONS_INVOICE_NUM.equals(db_STG_DESCRIPTION)) {
                                    String cons_description = ",DESCRIPTION," + db_STG_DESCRIPTION + "," + db_CONS_INVOICE_NUM + ",Pass";
                                    section1_results.add(cons_description);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATE + "," + db_CONS_TRANSACTION_DATE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_description = ",DESCRIPTION," + db_STG_DESCRIPTION + "," + db_CONS_INVOICE_NUM + ",Fail";
                                    section1_results.add(cons_description);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATE + "," + db_CONS_TRANSACTION_DATE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }


                                //--------------------  Validation INVOICE_DATE ---------------
                                if (db_CONS_INVOICE_DATE.equals(db_STG_INVOICE_DATE)) {
                                    String cons_invoice_date = ",INVOICE_DATE," + db_STG_INVOICE_DATE + "," + db_CONS_INVOICE_DATE + ",Pass";
                                    section1_results.add(cons_invoice_date);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATE + "," + db_CONS_TRANSACTION_DATE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_invoice_date = ",INVOICE_DATE," + db_STG_INVOICE_DATE + "," + db_CONS_INVOICE_DATE + ",Fail";
                                    section1_results.add(cons_invoice_date);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATE + "," + db_CONS_TRANSACTION_DATE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation INVOICE_RECEIVED_DATE ---------------
                                String db_STG_INVOICE_RECEIVED_DATEModified = db_STG_INVOICE_RECEIVED_DATE.substring(0, 10);
                                String db_CONS_INVOICE_RECEIVED_DATEModified = db_CONS_INVOICE_RECEIVED_DATE.substring(0, 10);
                                if (db_CONS_INVOICE_RECEIVED_DATEModified.equals(db_STG_INVOICE_RECEIVED_DATEModified)) {
                                    String cons_invoice_recived_date = ",INVOICE_RECEIVED_DATE," + db_STG_INVOICE_RECEIVED_DATEModified + "," + db_CONS_INVOICE_RECEIVED_DATEModified + ",Pass";
                                    section1_results.add(cons_invoice_recived_date);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATE + "," + db_CONS_TRANSACTION_DATE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_invoice_recived_date = ",INVOICE_RECEIVED_DATE," + db_STG_INVOICE_RECEIVED_DATEModified + "," + db_CONS_INVOICE_RECEIVED_DATEModified + ",Fail";
                                    section1_results.add(cons_invoice_recived_date);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATE + "," + db_CONS_TRANSACTION_DATE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation VENDOR_SITE_ID ---------------
                                if (db_CONS_VENDOR_SITE_ID.equals(db_STG_VENDOR_SITE_ID)) {
                                    String cons_invoice_site_id = ",VENDOR_SITE_ID," + db_STG_VENDOR_SITE_ID + "," + db_CONS_VENDOR_SITE_ID + ",Pass";
                                    section1_results.add(cons_invoice_site_id);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATE + "," + db_CONS_TRANSACTION_DATE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_invoice_site_id = ",VENDOR_SITE_ID," + db_STG_VENDOR_SITE_ID + "," + db_CONS_VENDOR_SITE_ID + ",Fail";
                                    section1_results.add(cons_invoice_site_id);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATE + "," + db_CONS_TRANSACTION_DATE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //--------------------  Validation FILE_NAME --------------
                                if (db_CONS_FILE_NAME.equals(db_STG_FILE_NAME)) {
                                    String cons_file_name = ",FILE_NAME," + db_STG_FILE_NAME + "," + db_CONS_FILE_NAME + ",Pass";
                                    section1_results.add(cons_file_name);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATE + "," + db_CONS_TRANSACTION_DATE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_file_name = ",FILE_NAME," + db_STG_FILE_NAME + "," + db_CONS_FILE_NAME + ",Fail";
                                    section1_results.add(cons_file_name);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATE + "," + db_CONS_TRANSACTION_DATE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }

                                //------------------------Reference Data validation---------------------
                                String PulseARReceipts_fsh_apSuppl_paymentMethodCode = connect_db.executeQuery_DB("Reference", "APInvoice_REF_APSUPPL_paymentMethodCode", "BMS");
                                String PulseARReceipts_fsh_apSuppl_status = connect_db.executeQuery_DB("Reference", "APInvoice_REF_SUPPL_STATUS", "BMS");
                                String PulseARReceipts_fsh_apSuppl_vendorSiteCode = connect_db.executeQuery_DB("Reference", "APInvoice_REF_APSUPPL_vendorSiteCode", "BMS");
                                String PulseARReceipts_fsh_apSuppl_globalAttribute1 = connect_db.executeQuery_DB("Reference", "APInvoice_REF_APSUPPL_globalAttribute1", "BMS");
                                String PulseARReceipts_fsh_apSuppl_attribute9 = connect_db.executeQuery_DB("Reference", "APInvoice_REF_APSUPPL_attribute9", "BMS");

                                //---------------- Validate PAYMENT_METHOD_CODE -----------------------

                                String db_transform_PAYMENT_METHOD_CODE_meaning = "null";
                                SQLResultset = SQLstmt.executeQuery(PulseARReceipts_fsh_apSuppl_paymentMethodCode + " WHERE VENDOR_SITE_ID = '" + db_STG_VENDOR_SITE_ID + "' and SUPPLIER_NAME = '" + db_STG_VENDOR_NAME + "' " + PulseARReceipts_fsh_apSuppl_status);
                                //SQLResultset = SQLstmt.executeQuery("Select PAYMENT_METHOD_CODE as paymentMethodCode from DLG_FSH_REF_AP_SUPPLIER where VENDOR_SITE_ID = '" + db_STG_VENDOR_SITE_ID + "' and SUPPLIER_NAME = '" + db_STG_VENDOR_NAME + "' and SUPPLIER_STATUS ='Active' and SUPPLIER_SITE_STATUS='Active'");
                                while (SQLResultset.next()) {
                                    db_transform_PAYMENT_METHOD_CODE_meaning = SQLResultset.getString("paymentMethodCode");
                                    System.out.println("stag count ----" + db_transform_PAYMENT_METHOD_CODE_meaning);
                                }

                                if (db_transform_PAYMENT_METHOD_CODE_meaning.equals("null")) {
                                    String transform_PAYMENT_METHOD_CODE_meaning = ",PAYMENT_METHOD_CODE Ref_Transformation," + "Transformation value not found" + "," + db_STG_PAYMENT_METHOD_CODE + ",Fail";
                                    section1_results.add(transform_PAYMENT_METHOD_CODE_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAYMENT_METHOD_CODE Ref_Transformation" + "," + "Transformation value not found" + "," + db_STG_PAYMENT_METHOD_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_transform_PAYMENT_METHOD_CODE_meaning != null) {
                                    if (db_transform_PAYMENT_METHOD_CODE_meaning.equals(db_STG_PAYMENT_METHOD_CODE)) {
                                        String transform_PAYMENT_METHOD_CODE_meaning = ",PAYMENT_METHOD_CODE Ref_Transformation," + db_transform_PAYMENT_METHOD_CODE_meaning + "," + db_STG_PAYMENT_METHOD_CODE + ",Pass";
                                        section1_results.add(transform_PAYMENT_METHOD_CODE_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAYMENT_METHOD_CODE Ref_Transformation" + "," + db_transform_PAYMENT_METHOD_CODE_meaning + "," + db_STG_PAYMENT_METHOD_CODE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);

                                    } else {
                                        String transform_PAYMENT_METHOD_CODE_meaning = ",PAYMENT_METHOD_CODE Ref_Transformation," + db_transform_PAYMENT_METHOD_CODE_meaning + "," + db_STG_PAYMENT_METHOD_CODE + ",Fail";
                                        section1_results.add(transform_PAYMENT_METHOD_CODE_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAYMENT_METHOD_CODE Ref_Transformation" + "," + db_transform_PAYMENT_METHOD_CODE_meaning + "," + db_STG_PAYMENT_METHOD_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //---------------- Validate VENDOR_SITE_CODE -----------------------

                                String db_transform_VENDOR_SITE_CODE_meaning = "null";
                                SQLResultset = SQLstmt.executeQuery(PulseARReceipts_fsh_apSuppl_vendorSiteCode + " WHERE VENDOR_SITE_ID = '" + db_STG_VENDOR_SITE_ID + "' and SUPPLIER_NAME = '" + db_STG_VENDOR_NAME + "' " + PulseARReceipts_fsh_apSuppl_status);
                                //SQLResultset = SQLstmt.executeQuery("Select SUPPLIER_SITE as vendorSiteCode from DLG_FSH_REF_AP_SUPPLIER where VENDOR_SITE_ID = '" + db_STG_VENDOR_SITE_ID + "' and SUPPLIER_NAME = '" + db_STG_VENDOR_NAME + "' and SUPPLIER_STATUS ='Active' and SUPPLIER_SITE_STATUS='Active'");
                                while (SQLResultset.next()) {
                                    db_transform_VENDOR_SITE_CODE_meaning = SQLResultset.getString("vendorSiteCode");
                                }
                                if (db_transform_VENDOR_SITE_CODE_meaning.equals("null")) {
                                    String transform_VENDOR_SITE_CODE_meaning = ",VENDOR_SITE_CODE Ref_Transformation," + "Transformation value not found" + "," + db_STG_VENDOR_SITE_CODE + ",Fail";
                                    section1_results.add(transform_VENDOR_SITE_CODE_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",VENDOR_SITE_CODE Ref_Transformation" + "," + "Transformation value not found" + "," + db_STG_VENDOR_SITE_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_transform_VENDOR_SITE_CODE_meaning != null) {
                                    if (db_transform_VENDOR_SITE_CODE_meaning.equals(db_STG_VENDOR_SITE_CODE)) {
                                        String transform_VENDOR_SITE_CODE_meaning = ",VENDOR_SITE_CODE Ref_Transformation," + db_transform_VENDOR_SITE_CODE_meaning + "," + db_STG_VENDOR_SITE_CODE + ",Pass";
                                        section1_results.add(transform_VENDOR_SITE_CODE_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",VENDOR_SITE_CODE Ref_Transformation" + "," + db_transform_VENDOR_SITE_CODE_meaning + "," + db_STG_VENDOR_SITE_CODE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String transform_VENDOR_SITE_CODE_meaning = ",VENDOR_SITE_CODE Ref_Transformation," + db_transform_VENDOR_SITE_CODE_meaning + "," + db_STG_VENDOR_SITE_CODE + ",Fail";
                                        section1_results.add(transform_VENDOR_SITE_CODE_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",VENDOR_SITE_CODE Ref_Transformation" + "," + db_transform_VENDOR_SITE_CODE_meaning + "," + db_STG_VENDOR_SITE_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //---------------- Validate GLOBAL_ATTRIBUTE1 -----------------------

                                String db_transform_GLOBAL_ATTRIBUTE1_meaning = "null";
                                String db_STG_GLOBAL_ATTRIBUTE1Modified = db_STG_GLOBAL_ATTRIBUTE1.replaceAll("\\.0*$", "");
                                SQLResultset = SQLstmt.executeQuery(PulseARReceipts_fsh_apSuppl_globalAttribute1 + " WHERE VENDOR_SITE_ID = '" + db_STG_VENDOR_SITE_ID + "' and SUPPLIER_NAME = '" + db_STG_VENDOR_NAME + "' " + PulseARReceipts_fsh_apSuppl_status);
                                //SQLResultset = SQLstmt.executeQuery("Select VENDOR_ID as globalAttribute1 from DLG_FSH_REF_AP_SUPPLIER where VENDOR_SITE_ID = '" + db_STG_VENDOR_SITE_ID + "' and SUPPLIER_NAME = '" + db_STG_VENDOR_NAME + "' and SUPPLIER_STATUS ='Active' and SUPPLIER_SITE_STATUS='Active'");
                                while (SQLResultset.next()) {
                                    db_transform_GLOBAL_ATTRIBUTE1_meaning = SQLResultset.getString("globalAttribute1");
                                }
                                if (db_transform_GLOBAL_ATTRIBUTE1_meaning.equals("null")) {
                                    String transform_GLOBAL_ATTRIBUTE1_meaning = ",GLOBAL_ATTRIBUTE1 Ref_Transformation," + "Transformation value not found" + "," + db_STG_GLOBAL_ATTRIBUTE1Modified + ",Fail";
                                    section1_results.add(transform_GLOBAL_ATTRIBUTE1_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",GLOBAL_ATTRIBUTE1 Ref_Transformation" + "," + "Transformation value not found" + "," + db_STG_GLOBAL_ATTRIBUTE1Modified + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_transform_GLOBAL_ATTRIBUTE1_meaning != null) {
                                    if (db_transform_GLOBAL_ATTRIBUTE1_meaning.equals(db_STG_GLOBAL_ATTRIBUTE1Modified)) {
                                        String transform_GLOBAL_ATTRIBUTE1_meaning = ",GLOBAL_ATTRIBUTE1 Ref_Transformation," + db_transform_GLOBAL_ATTRIBUTE1_meaning + "," + db_STG_GLOBAL_ATTRIBUTE1Modified + ",Pass";
                                        section1_results.add(transform_GLOBAL_ATTRIBUTE1_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",GLOBAL_ATTRIBUTE1 Ref_Transformation" + "," + db_transform_GLOBAL_ATTRIBUTE1_meaning + "," + db_STG_GLOBAL_ATTRIBUTE1Modified + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String transform_GLOBAL_ATTRIBUTE1_meaning = ",GLOBAL_ATTRIBUTE1 Ref_Transformation," + db_transform_GLOBAL_ATTRIBUTE1_meaning + "," + db_STG_GLOBAL_ATTRIBUTE1Modified + ",Fail";
                                        section1_results.add(transform_GLOBAL_ATTRIBUTE1_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",GLOBAL_ATTRIBUTE1 Ref_Transformation" + "," + db_transform_GLOBAL_ATTRIBUTE1_meaning + "," + db_STG_GLOBAL_ATTRIBUTE1Modified + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }


                                //---------------- Validate ATTRIBUTE9 -----------------------

                                String db_transform_ATTRIBUTE9_meaning = "null";
                                SQLResultset = SQLstmt.executeQuery(PulseARReceipts_fsh_apSuppl_attribute9 + " WHERE VENDOR_SITE_ID = '" + db_STG_VENDOR_SITE_ID + "' and SUPPLIER_NAME = '" + db_STG_VENDOR_NAME + "' " + PulseARReceipts_fsh_apSuppl_status);
                                //SQLResultset = SQLstmt.executeQuery("Select SUPPLIER_NUMBER as attribute9 from DLG_FSH_REF_AP_SUPPLIER where VENDOR_SITE_ID = '" + db_STG_VENDOR_SITE_ID + "' and SUPPLIER_NAME = '" + db_STG_VENDOR_NAME + "' and SUPPLIER_STATUS ='Active' and SUPPLIER_SITE_STATUS='Active'");
                                while (SQLResultset.next()) {
                                    db_transform_ATTRIBUTE9_meaning = SQLResultset.getString("attribute9");
                                }
                                if (db_transform_ATTRIBUTE9_meaning.equals("null")) {
                                    String transform_ATTRIBUTE9_meaning = ",ATTRIBUTE9 Ref_Transformation," + "Transformation value not found" + "," + db_STG_ATTRIBUTE9 + ",Fail";
                                    section1_results.add(transform_ATTRIBUTE9_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ATTRIBUTE9 Ref_Transformation" + "," + "Transformation value not found" + "," + db_STG_ATTRIBUTE9 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_transform_ATTRIBUTE9_meaning != null) {
                                    if (db_transform_ATTRIBUTE9_meaning.equals(db_STG_ATTRIBUTE9)) {
                                        String transform_ATTRIBUTE9_meaning = ",ATTRIBUTE9 Ref_Transformation," + db_transform_ATTRIBUTE9_meaning + "," + db_STG_ATTRIBUTE9 + ",Pass";
                                        section1_results.add(transform_ATTRIBUTE9_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ATTRIBUTE9 Ref_Transformation" + "," + db_transform_ATTRIBUTE9_meaning + "," + db_STG_ATTRIBUTE9 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String transform_ATTRIBUTE9_meaning = ",ATTRIBUTE9 Ref_Transformation," + db_transform_ATTRIBUTE9_meaning + "," + db_STG_ATTRIBUTE9 + ",Fail";
                                        section1_results.add(transform_ATTRIBUTE9_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ATTRIBUTE9 Ref_Transformation" + "," + db_transform_ATTRIBUTE9_meaning + "," + db_STG_ATTRIBUTE9 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //----------------------- STANDARDISATION start here -----------------------------
                                String db_lookup_source_meaning = "null";
                                String db_lookup_GLOBAL_ATTRIBUTE2_meaning = "null";
                                String db_lookup_GLOBAL_ATTRIBUTE3_meaning = "null";
                                String db_lookup_line_of_business_meaning = "null";
                                String db_lookup_line_product_meaning = "null";
                                String db_lookup_line_currency_code_meaning = "null";
                                String db_lookup_exchange_rate_meaning = "null";
                                String db_lookup_exchange_rate_type_meaning = "null";
                                String db_lookup_group_lookup_code_meaning = "null";
                                String db_lookup_org_id_meaning = "null";
                                String db_lookup_line_payee_type_meaning = "null";
                                String db_lookup_calc_tax_import_flag_meaning = "null";
                                String db_lookup_underwriter_meaning = "null";
                                String db_lookup_product_meaning = "null";
                                String db_lookup_business_unit_meaning = "null";
                                String db_lookup_brand_meaning = "null";
                                String db_lookup_pay_group_lookup_code_meaning = "null";
                                String db_lookup_attribute13_meaning = "null";

                                String BMSAPInvoice_fsh_lookup = connect_db.executeQuery_DB("Lookup", "FSH_LOOKUP", "BMS");
                                String BMSAPInvoice_fsh_sys_lookup = connect_db.executeQuery_DB("Lookup", "FSH_SYS_LOOKUP", "BMS");
                                String fsh_source = connect_db.executeQuery_DB("Lookup", "FSH_LOOKUP_SOURCE_BMS_APInvoice", "BMS");

                                //---------------- Validate SOURCE -----------------------
                                SQLResultset = SQLstmt.executeQuery(BMSAPInvoice_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'APSOURCE'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'APSOURCE' and system = 'ECLI' and pattern = 'APInvoice'");
                                while (SQLResultset.next()) {
                                    db_lookup_source_meaning = SQLResultset.getString("MEANING");
                                }
                                if (db_lookup_source_meaning.equals("null")) {
                                    String lookup_source_meaning = ",SOURCE lookup," + "LookUp value not found" + "," + db_STG_SOURCE + ",Fail";
                                    section1_results.add(lookup_source_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SOURCE lookup" + "," + "LookUp value not found" + "," + db_STG_SOURCE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_lookup_source_meaning != null) {
                                    if (db_lookup_source_meaning.equals(db_STG_SOURCE)) {
                                        String lookup_source_meaning = ",SOURCE lookup," + db_lookup_source_meaning + "," + db_STG_SOURCE + ",Pass";
                                        section1_results.add(lookup_source_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SOURCE lookup" + "," + db_lookup_source_meaning + "," + db_STG_SOURCE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String lookup_source_meaning = ",SOURCE lookup," + db_lookup_source_meaning + "," + db_STG_SOURCE + ",Fail";
                                        section1_results.add(lookup_source_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SOURCE lookup" + "," + db_lookup_source_meaning + "," + db_STG_SOURCE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //------------------------ LINE_OF_BUSINESS Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(BMSAPInvoice_fsh_sys_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'LINE_OF_BUSINESS'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'LINE_OF_BUSINESS' and system = 'ECLI' and pattern = 'APInvoice'");
                                while (SQLResultset.next()) {
                                    db_lookup_line_of_business_meaning = SQLResultset.getString("MEANING");
                                }

                                if (db_lookup_line_of_business_meaning.equals("null")) {
                                    String lookup_line_of_business_meaning = ",LINE_OF_BUSINESS lookup," + "LookUp value not found" + "," + db_STG_LINE_OF_BUSINESS + ",Fail";
                                    section1_results.add(lookup_line_of_business_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",LINE_OF_BUSINESS lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_OF_BUSINESS + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_lookup_line_of_business_meaning != null) {
                                    if (db_lookup_line_of_business_meaning.equals(db_STG_LINE_OF_BUSINESS)) {
                                        String lookup_line_of_business_meaning = ",LINE_OF_BUSINESS lookup," + db_lookup_line_of_business_meaning + "," + db_STG_LINE_OF_BUSINESS + ",Pass";
                                        section1_results.add(lookup_line_of_business_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",LINE_OF_BUSINESS lookup" + "," + db_lookup_line_of_business_meaning + "," + db_STG_LINE_OF_BUSINESS + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String lookup_line_of_business_meaning = ",LINE_OF_BUSINESS lookup," + db_lookup_line_of_business_meaning + "," + db_STG_LINE_OF_BUSINESS + ",Fail";
                                        section1_results.add(lookup_line_of_business_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",LINE_OF_BUSINESS lookup" + "," + db_lookup_line_of_business_meaning + "," + db_STG_LINE_OF_BUSINESS + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //------------------------ BRAND Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(BMSAPInvoice_fsh_sys_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'BRAND'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'BRAND' and system = 'ECLI' and pattern = 'APInvoice'");
                                while (SQLResultset.next()) {
                                    db_lookup_brand_meaning = SQLResultset.getString("MEANING");
                                }

                                if (db_lookup_brand_meaning.equals("null")) {
                                    String lookup_brand_meaning = ",BRAND lookup," + "LookUp value not found" + "," + db_STG_BRAND + ",Fail";
                                    section1_results.add(lookup_brand_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BRAND lookup" + "," + "LookUp value not found" + "," + db_STG_BRAND + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_lookup_brand_meaning != null) {
                                    if (db_lookup_brand_meaning.equals(db_STG_BRAND)) {
                                        String lookup_brand_meaning = ",BRAND lookup," + db_lookup_brand_meaning + "," + db_STG_BRAND + ",Pass";
                                        section1_results.add(lookup_brand_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BRAND lookup" + "," + db_lookup_brand_meaning + "," + db_STG_BRAND + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String lookup_brand_meaning = ",BRAND lookup," + db_lookup_brand_meaning + "," + db_STG_BRAND + ",Fail";
                                        section1_results.add(lookup_brand_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BRAND lookup" + "," + db_lookup_brand_meaning + "," + db_STG_BRAND + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //------------------------ PAYEE_TYPE Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(BMSAPInvoice_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'PAYEE_TYPE'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT * FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'PAYEE_TYPE' and system = 'ECLI' and pattern = 'APInvoice'");
                                while (SQLResultset.next()) {
                                    db_lookup_line_payee_type_meaning = SQLResultset.getString("MEANING");
                                }

                                if (db_lookup_line_payee_type_meaning.equals("null")) {
                                    String lookup_line_payee_type_meaning = ",PAYEE_TYPE lookup," + "LookUp value not found" + "," + db_STG_PAYEE_TYPE + ",Fail";
                                    section1_results.add(lookup_line_payee_type_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAYEE_TYPE lookup" + "," + "LookUp value not found" + "," + db_STG_PAYEE_TYPE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_lookup_line_payee_type_meaning != null) {
                                    if (db_lookup_line_payee_type_meaning.equals(db_STG_PAYEE_TYPE)) {
                                        String lookup_line_payee_type_meaning = ",PAYEE_TYPE lookup," + db_lookup_line_payee_type_meaning + "," + db_STG_PAYEE_TYPE + ",Pass";
                                        section1_results.add(lookup_line_payee_type_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAYEE_TYPE lookup" + "," + db_lookup_line_payee_type_meaning + "," + db_STG_PAYEE_TYPE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String lookup_line_payee_type_meaning = ",PAYEE_TYPE lookup," + db_lookup_line_payee_type_meaning + "," + db_STG_PAYEE_TYPE + ",Fail";
                                        section1_results.add(lookup_line_payee_type_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAYEE_TYPE lookup" + "," + db_lookup_line_payee_type_meaning + "," + db_STG_PAYEE_TYPE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //------------------------ PAY_GROUP_LOOKUP_CODE Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(BMSAPInvoice_fsh_sys_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'PAY_GROUP_LOOKUP_CODE'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'PAY_GROUP_LOOKUP_CODE' and system = 'ECLI' and pattern = 'APInvoice'");
                                while (SQLResultset.next()) {
                                    db_lookup_pay_group_lookup_code_meaning = SQLResultset.getString("MEANING");
                                }

                                if (db_lookup_pay_group_lookup_code_meaning.equals("null")) {
                                    String lookup_pay_group_lookup_code_meaning = ",PAY_GROUP_LOOKUP_CODE lookup," + "LookUp value not found" + "," + db_STG_PAY_GROUP_LOOKUP_CODE + ",Fail";
                                    section1_results.add(lookup_pay_group_lookup_code_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAY_GROUP_LOOKUP_CODE lookup" + "," + "LookUp value not found" + "," + db_STG_PAY_GROUP_LOOKUP_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_lookup_pay_group_lookup_code_meaning != null) {
                                    if (db_lookup_pay_group_lookup_code_meaning.equals(db_STG_PAY_GROUP_LOOKUP_CODE)) {
                                        String lookup_pay_group_lookup_code_meaning = ",PAY_GROUP_LOOKUP_CODE lookup," + db_lookup_pay_group_lookup_code_meaning + "," + db_STG_PAY_GROUP_LOOKUP_CODE + ",Pass";
                                        section1_results.add(lookup_pay_group_lookup_code_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAY_GROUP_LOOKUP_CODE lookup" + "," + db_lookup_pay_group_lookup_code_meaning + "," + db_STG_PAY_GROUP_LOOKUP_CODE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String lookup_pay_group_lookup_code_meaning = ",PAY_GROUP_LOOKUP_CODE lookup," + db_lookup_pay_group_lookup_code_meaning + "," + db_STG_PAY_GROUP_LOOKUP_CODE + ",Fail";
                                        section1_results.add(lookup_pay_group_lookup_code_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PAY_GROUP_LOOKUP_CODE lookup" + "," + db_lookup_pay_group_lookup_code_meaning + "," + db_STG_PAY_GROUP_LOOKUP_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //------------------------ ATTRIBUTE13 Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(BMSAPInvoice_fsh_sys_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'BRAND'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'BRAND' and system = 'ECLI' and pattern = 'APInvoice'");
                                while (SQLResultset.next()) {
                                    db_lookup_attribute13_meaning = SQLResultset.getString("MEANING");
                                }

                                if (db_lookup_attribute13_meaning.equals("null")) {
                                    String lookup_attribute13_meaning = ",ATTRIBUTE13 lookup," + "LookUp value not found" + "," + db_STG_ATTRIBUTE13 + ",Fail";
                                    section1_results.add(lookup_attribute13_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ATTRIBUTE13 lookup" + "," + "LookUp value not found" + "," + db_STG_ATTRIBUTE13 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_lookup_attribute13_meaning != null) {
                                    if (db_lookup_attribute13_meaning.equals(db_STG_ATTRIBUTE13)) {
                                        String lookup_attribute13_meaning = ",ATTRIBUTE13 lookup," + db_lookup_attribute13_meaning + "," + db_STG_ATTRIBUTE13 + ",Pass";
                                        section1_results.add(lookup_attribute13_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ATTRIBUTE13 lookup" + "," + db_lookup_attribute13_meaning + "," + db_STG_ATTRIBUTE13 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String lookup_attribute13_meaning = ",ATTRIBUTE13 lookup," + db_lookup_attribute13_meaning + "," + db_STG_ATTRIBUTE13 + ",Fail";
                                        section1_results.add(lookup_attribute13_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ATTRIBUTE13 lookup" + "," + db_lookup_attribute13_meaning + "," + db_STG_ATTRIBUTE13 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //------------------------ ORG_ID Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(BMSAPInvoice_fsh_sys_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'ORG_ID'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT * FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'ORG_ID' and system = 'ECLI' and pattern = 'APInvoice'");
                                while (SQLResultset.next()) {
                                    db_lookup_org_id_meaning = SQLResultset.getString("MEANING");
                                }

                                if (db_lookup_org_id_meaning.equals("null")) {
                                    String lookup_org_id_meaning = ",ORG_ID lookup," + "LookUp value not found" + "," + db_STG_ORG_ID + ",Fail";
                                    section1_results.add(lookup_org_id_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ORG_ID lookup" + "," + "LookUp value not found" + "," + db_STG_ORG_ID + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_lookup_org_id_meaning != null) {
                                    if (db_lookup_org_id_meaning.equals(db_STG_ORG_ID)) {
                                        String lookup_org_id_meaning = ",ORG_ID lookup," + db_lookup_org_id_meaning + "," + db_STG_ORG_ID + ",Pass";
                                        section1_results.add(lookup_org_id_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ORG_ID lookup" + "," + db_lookup_org_id_meaning + "," + db_STG_ORG_ID + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String lookup_org_id_meaning = ",ORG_ID lookup," + db_lookup_org_id_meaning + "," + db_STG_ORG_ID + ",Fail";
                                        section1_results.add(lookup_org_id_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ORG_ID lookup" + "," + db_lookup_org_id_meaning + "," + db_STG_ORG_ID + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //------------------------ CALC_TAX_DURING_IMPORT_FLAG Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(BMSAPInvoice_fsh_sys_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'CALC_TAX_DURING_IMPORT_FLAG'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'CALC_TAX_DURING_IMPORT_FLAG' and system = 'ECLI' and pattern = 'APInvoice'");
                                while (SQLResultset.next()) {
                                    db_lookup_calc_tax_import_flag_meaning = SQLResultset.getString("MEANING");
                                }

                                if (db_lookup_calc_tax_import_flag_meaning.equals("null")) {
                                    String lookup_calc_tax_import_flag_meaning = ",CALC_TAX_DURING_IMPORT_FLAG lookup," + "LookUp value not found" + "," + db_STG_CALC_TAX_DURING_IMPORT_FLAG + ",Fail";
                                    section1_results.add(lookup_calc_tax_import_flag_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CALC_TAX_DURING_IMPORT_FLAG lookup" + "," + "LookUp value not found" + "," + db_STG_CALC_TAX_DURING_IMPORT_FLAG + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_lookup_calc_tax_import_flag_meaning != null) {
                                    if (db_lookup_calc_tax_import_flag_meaning.equals(db_STG_CALC_TAX_DURING_IMPORT_FLAG)) {
                                        String lookup_calc_tax_import_flag_meaning = ",CALC_TAX_DURING_IMPORT_FLAG lookup," + db_lookup_calc_tax_import_flag_meaning + "," + db_STG_CALC_TAX_DURING_IMPORT_FLAG + ",Pass";
                                        section1_results.add(lookup_calc_tax_import_flag_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CALC_TAX_DURING_IMPORT_FLAG lookup" + "," + db_lookup_calc_tax_import_flag_meaning + "," + db_STG_CALC_TAX_DURING_IMPORT_FLAG + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String lookup_calc_tax_import_flag_meaning = ",CALC_TAX_DURING_IMPORT_FLAG lookup," + db_lookup_calc_tax_import_flag_meaning + "," + db_STG_CALC_TAX_DURING_IMPORT_FLAG + ",Fail";
                                        section1_results.add(lookup_calc_tax_import_flag_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CALC_TAX_DURING_IMPORT_FLAG lookup" + "," + db_lookup_calc_tax_import_flag_meaning + "," + db_STG_CALC_TAX_DURING_IMPORT_FLAG + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }


                                //------------------------ BUSINESS_UNIT Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(BMSAPInvoice_fsh_sys_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'BUSINESS_UNIT'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'BUSINESS_UNIT' and system = 'ECLI' and pattern = 'APInvoice'");
                                while (SQLResultset.next()) {
                                    db_lookup_business_unit_meaning = SQLResultset.getString("MEANING");
                                }

                                if (db_lookup_business_unit_meaning.equals("null")) {
                                    String lookup_business_unit_meaning = ",BUSINESS_UNIT lookup," + "LookUp value not found" + "," + db_STG_BUSINESS_UNIT + ",Fail";
                                    section1_results.add(lookup_business_unit_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BUSINESS_UNIT lookup" + "," + "LookUp value not found" + "," + db_STG_BUSINESS_UNIT + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_lookup_business_unit_meaning != null) {
                                    if (db_lookup_business_unit_meaning.equals(db_STG_BUSINESS_UNIT)) {
                                        String lookup_business_unit_meaning = ",BUSINESS_UNIT lookup," + db_lookup_business_unit_meaning + "," + db_STG_BUSINESS_UNIT + ",Pass";
                                        section1_results.add(lookup_business_unit_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BUSINESS_UNIT lookup" + "," + db_lookup_business_unit_meaning + "," + db_STG_BUSINESS_UNIT + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String lookup_business_unit_meaning = ",BUSINESS_UNIT lookup," + db_lookup_business_unit_meaning + "," + db_STG_BUSINESS_UNIT + ",Fail";
                                        section1_results.add(lookup_business_unit_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BUSINESS_UNIT lookup" + "," + db_lookup_business_unit_meaning + "," + db_STG_BUSINESS_UNIT + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }


                                //------------------------ GLOBAL_ATTRIBUTE2 Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(BMSAPInvoice_fsh_sys_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'UNDERWRITER'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'UNDERWRITER' and system = 'ECLI' and pattern = 'APInvoice'");
                                while (SQLResultset.next()) {
                                    db_lookup_GLOBAL_ATTRIBUTE2_meaning = SQLResultset.getString("MEANING");
                                }

                                if (db_lookup_GLOBAL_ATTRIBUTE2_meaning.equals("null")) {
                                    String lookup_GLOBAL_ATTRIBUTE2_meaning = ",GLOBAL_ATTRIBUTE2 lookup," + "LookUp value not found" + "," + db_STG_GLOBAL_ATTRIBUTE2 + ",Fail";
                                    section1_results.add(lookup_GLOBAL_ATTRIBUTE2_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",GLOBAL_ATTRIBUTE2 lookup" + "," + "LookUp value not found" + "," + db_STG_GLOBAL_ATTRIBUTE2 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_lookup_GLOBAL_ATTRIBUTE2_meaning != null) {
                                    if (db_lookup_GLOBAL_ATTRIBUTE2_meaning.equals(db_STG_GLOBAL_ATTRIBUTE2)) {
                                        String lookup_GLOBAL_ATTRIBUTE2_meaning = ",GLOBAL_ATTRIBUTE2 lookup," + db_lookup_GLOBAL_ATTRIBUTE2_meaning + "," + db_STG_GLOBAL_ATTRIBUTE2 + ",Pass";
                                        section1_results.add(lookup_GLOBAL_ATTRIBUTE2_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",GLOBAL_ATTRIBUTE2 lookup" + "," + db_lookup_GLOBAL_ATTRIBUTE2_meaning + "," + db_STG_GLOBAL_ATTRIBUTE2 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String lookup_GLOBAL_ATTRIBUTE2_meaning = ",GLOBAL_ATTRIBUTE2 lookup," + db_lookup_GLOBAL_ATTRIBUTE2_meaning + "," + db_STG_GLOBAL_ATTRIBUTE2 + ",Fail";
                                        section1_results.add(lookup_GLOBAL_ATTRIBUTE2_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",GLOBAL_ATTRIBUTE2 lookup" + "," + db_lookup_GLOBAL_ATTRIBUTE2_meaning + "," + db_STG_GLOBAL_ATTRIBUTE2 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }

                                //------------------------ GLOBAL_ATTRIBUTE3 Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(BMSAPInvoice_fsh_sys_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'PRODUCT'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'PRODUCT' and system = 'ECLI' and pattern = 'APInvoice'");
                                while (SQLResultset.next()) {
                                    db_lookup_GLOBAL_ATTRIBUTE3_meaning = SQLResultset.getString("MEANING");
                                }

                                if (db_lookup_GLOBAL_ATTRIBUTE3_meaning.equals("null")) {
                                    String lookup_GLOBAL_ATTRIBUTE3_meaning = ",GLOBAL_ATTRIBUTE3 lookup," + "LookUp value not found" + "," + db_STG_GLOBAL_ATTRIBUTE3 + ",Fail";
                                    section1_results.add(lookup_GLOBAL_ATTRIBUTE3_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",GLOBAL_ATTRIBUTE3 lookup" + "," + "LookUp value not found" + "," + db_STG_GLOBAL_ATTRIBUTE3 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else if (db_lookup_GLOBAL_ATTRIBUTE3_meaning != null) {
                                    if (db_lookup_GLOBAL_ATTRIBUTE3_meaning.equals(db_STG_GLOBAL_ATTRIBUTE3)) {
                                        String lookup_GLOBAL_ATTRIBUTE3_meaning = ",GLOBAL_ATTRIBUTE3 lookup," + db_lookup_GLOBAL_ATTRIBUTE3_meaning + "," + db_STG_GLOBAL_ATTRIBUTE3 + ",Pass";
                                        section1_results.add(lookup_GLOBAL_ATTRIBUTE3_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",GLOBAL_ATTRIBUTE3 lookup" + "," + db_lookup_GLOBAL_ATTRIBUTE3_meaning + "," + db_STG_GLOBAL_ATTRIBUTE3 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                    } else {
                                        String lookup_GLOBAL_ATTRIBUTE3_meaning = ",GLOBAL_ATTRIBUTE3 lookup," + db_lookup_GLOBAL_ATTRIBUTE3_meaning + "," + db_STG_GLOBAL_ATTRIBUTE3 + ",Fail";
                                        section1_results.add(lookup_GLOBAL_ATTRIBUTE3_meaning);
                                        String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",GLOBAL_ATTRIBUTE3 lookup" + "," + db_lookup_GLOBAL_ATTRIBUTE3_meaning + "," + db_STG_GLOBAL_ATTRIBUTE3 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                        section2_results_tbl.add(tbl_header_id);
                                        CONS_flag++;
                                    }
                                }


                                //------------------------  Line Item variable Declaration -----------------------------
                                String db_STG_LINE_ORG_ID = "null";
                                String db_STG_LINE_SEGMENT1 = "null";
                                String db_STG_LINE_SEGMENT2 = "null";
                                String db_STG_LINE_SEGMENT3 = "null";
                                String db_STG_LINE_SEGMENT4 = "null";
                                String db_STG_LINE_SEGMENT5 = "null";
                                String db_STG_LINE_SEGMENT6 = "null";
                                String db_STG_LINE_SEGMENT7 = "null";
                                String db_STG_LINE_SEGMENT8 = "null";
                                String db_STG_LINE_SEGMENT9 = "null";
                                String db_STG_LINE_SEGMENT10 = "null";

                                //------------------------  Line Item validation -----------------------------
                                int line_count = 0;
                                ArrayList<String> list_line_id = new ArrayList<String>();
                                String BMAPInvoice_stglineSqlQuery = connect_db.executeQuery_DB("BMS_AP", "APInvoice_Stg_line", "BMS");
                                SQLResultset = SQLstmt.executeQuery(BMAPInvoice_stglineSqlQuery + "WHERE HEADER_ID = '" + db_STG_HEADER_ID + "' ");
                                //SQLResultset = SQLstmt.executeQuery("SELECT * FROM  DLG_FSH_STG_COMM_API_LIN WHERE  HEADER_ID = '" + db_STG_HEADER_ID + "'");
                                while (SQLResultset.next()) {
                                    list_line_id.add(SQLResultset.getString("LINE_NUMBER"));
                                }

                                for (int i_count = 0; i_count <= list_line_id.size() - 1; i_count++) {
                                    int stg_sub_indent = i_count;
                                    int sub_tag_line = 0;
                                    System.out.println("Line id ---> " + list_line_id.get(i_count));
                                    SQLResultset = SQLstmt.executeQuery(BMAPInvoice_stglineSqlQuery + "WHERE HEADER_ID = '" + db_STG_HEADER_ID + "' and LINE_NUMBER = '" + list_line_id.get(i_count) + "' ");
                                    //SQLResultset = SQLstmt.executeQuery("SELECT * FROM  DLG_FSH_STG_COMM_API_LIN WHERE  HEADER_ID = '" + db_STG_HEADER_ID + "' and LINE_NUMBER = '" + list_line_id.get(i_count) + "'");
                                    while (SQLResultset.next()) {
                                        db_STG_line_id = SQLResultset.getString("LINE_ID");
                                        db_stg_LINE_INVOICE_ID = SQLResultset.getString("INVOICE_ID");
                                        db_STG_LINE_NUMBER = SQLResultset.getString("LINE_NUMBER");
                                        db_STG_LINE_TYPE_LOOKUP_CODE = SQLResultset.getString("LINE_TYPE_LOOKUP_CODE");
                                        db_STG_LINE_SUBJECT_REV_CHARGE = SQLResultset.getString("SUBJECT_REV_CHARGE");
                                        db_STG_LINE_PRORATE_ACROSS_FLAG = SQLResultset.getString("PRORATE_ACROSS_FLAG");
                                        db_STG_LINE_AMOUNT_INCLUDES_TAX_FLAG = SQLResultset.getString("AMOUNT_INCLUDES_TAX_FLAG");
                                        db_STG_LINE_TAX_RATE_CODE = SQLResultset.getString("TAX_RATE_CODE");
                                        db_STG_LINE_DESCRIPTION = SQLResultset.getString("DESCRIPTION");
                                        db_STG_LINE_ITEM_AMOUNT = SQLResultset.getString("LINE_ITEM_AMOUNT");
                                        db_STG_BASE_LINE_ITEM_AMOUNT = SQLResultset.getString("BASE_LINE_ITEM_AMOUNT");
                                        db_STG_LINE_TAX_CODE = SQLResultset.getString("TAX_CODE");
                                        db_STG_LINE_HEADER_ID = SQLResultset.getString("HEADER_ID");
                                        //db_STG_CATEGORY = SQLResultset.getString("CATEGORY");
                                        db_STG_LINE_PARTITION_ID = SQLResultset.getString("PARTITION_ID");
                                        db_STG_LINE_SOURCE = SQLResultset.getString("SOURCE");
                                        db_STG_LINE_FILE_NAME = SQLResultset.getString("FILE_NAME");
                                        db_STG_LINE_ORG_ID = SQLResultset.getString("ORG_ID");
                                        db_STG_LINE_BUSINESS_UNIT = SQLResultset.getString("BUSINESS_UNIT");
                                        db_STG_LINE_SEGMENT1 = SQLResultset.getString("SEGMENT1");
                                        db_STG_LINE_SEGMENT2 = SQLResultset.getString("SEGMENT2");
                                        db_STG_LINE_SEGMENT3 = SQLResultset.getString("SEGMENT3");
                                        db_STG_LINE_SEGMENT4 = SQLResultset.getString("SEGMENT4");
                                        db_STG_LINE_SEGMENT5 = SQLResultset.getString("SEGMENT5");
                                        db_STG_LINE_SEGMENT6 = SQLResultset.getString("SEGMENT6");
                                        db_STG_LINE_SEGMENT7 = SQLResultset.getString("SEGMENT7");
                                        db_STG_LINE_SEGMENT8 = SQLResultset.getString("SEGMENT8");
                                        db_STG_LINE_SEGMENT9 = SQLResultset.getString("SEGMENT9");
                                        db_STG_LINE_SEGMENT10 = SQLResultset.getString("SEGMENT10");
                                        db_STG_LINE_CATEGORY = SQLResultset.getString("CATEGORY");
                                        db_STG_LINE_CURRENCY_CODE = SQLResultset.getString("CURRENCY_CODE");
                                        db_STG_LINE_INVOICE_ID = SQLResultset.getString("INVOICE_ID");
                                        db_STG_LINE_DIST_CODE_CONCATENATED = SQLResultset.getString("DIST_CODE_CONCATENATED");
                                        STG_LINE_STATUS = SQLResultset.getString("STATUS");

                                        //Staging LINE mandatory validations
                                        //INVOICE_ID - mandatory validation
                                        if ((db_STG_LINE_INVOICE_ID == null) && (STG_LINE_STATUS != "REVIEW")) {

                                            String stg_line_id = stg_line_map_row + "," + db_STG_line_id + ",LINE_INVOICE_ID," + "LINE_INVOICE_ID : " + db_STG_INVOICE_ID + "," + "LINE_INVOICE_ID was not found," + STG_LINE_STATUS + "," + "Fail";
                                            section4_results.add(stg_line_id);
                                            stg_line_map_row++;
                                        } else {
                                            String stg_line_id = stg_line_map_row + "," + db_STG_line_id + ",LINE_INVOICE_ID," + "LINE_INVOICE_ID : " + db_STG_INVOICE_ID + "," + "LINE_INVOICE_ID was found," + STG_LINE_STATUS + "," + "Pass";
                                            section4_results.add(stg_line_id);
                                            stg_line_map_row++;
                                        }

                                        //LINE_TYPE_LOOKUP_CODE - mandatory validation
                                        if ((db_STG_LINE_TYPE_LOOKUP_CODE == null) && (STG_HDR_STATUS != "REVIEW")) {

                                            String stg_line_id = "," + ",LINE_TYPE_LOOKUP_CODE," + "LINE_TYPE_LOOKUP_CODE : " + db_STG_INVOICE_ID + "," + "LINE_TYPE_LOOKUP_CODE was not found," + STG_LINE_STATUS + "," + "Fail";
                                            section4_results.add(stg_line_id);
                                        } else {
                                            String stg_header_id = "," + ",LINE_TYPE_LOOKUP_CODE," + "LINE_TYPE_LOOKUP_CODE : " + db_STG_INVOICE_ID + "," + "LINE_TYPE_LOOKUP_CODE was found," + STG_LINE_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                        }

                                        //LINE_PRORATE_ACROSS_FLAG - mandatory validation
                                        if (db_STG_LINE_TYPE_LOOKUP_CODE.equals("TAX")) {
                                            if ((db_STG_LINE_PRORATE_ACROSS_FLAG == null) && (STG_HDR_STATUS != "REVIEW")) {

                                                String stg_line_id = "," + ",LINE_PRORATE_ACROSS_FLAG," + "LINE_PRORATE_ACROSS_FLAG : " + db_STG_LINE_PRORATE_ACROSS_FLAG + "," + "LINE_PRORATE_ACROSS_FLAG was not found," + STG_LINE_STATUS + "," + "Fail";
                                                section4_results.add(stg_line_id);
                                            } else {
                                                String stg_line_id = "," + ",LINE_PRORATE_ACROSS_FLAG," + "LINE_PRORATE_ACROSS_FLAG : " + db_STG_LINE_PRORATE_ACROSS_FLAG + "," + "LINE_PRORATE_ACROSS_FLAG was found," + STG_LINE_STATUS + "," + "Pass";
                                                section4_results.add(stg_line_id);
                                            }
                                        } else {
                                            String stg_line_id = "," + ",LINE_PRORATE_ACROSS_FLAG," + "LINE_PRORATE_ACROSS_FLAG : " + db_STG_LINE_PRORATE_ACROSS_FLAG + "," + "LINE_PRORATE_ACROSS_FLAG is not mandatory- neither NULL nor NOTNULL," + STG_LINE_STATUS + "," + "Pass";
                                            section4_results.add(stg_line_id);
                                        }

                                        //LINE_ITEM_AMOUNT - mandatory validation
                                        if ((db_STG_LINE_ITEM_AMOUNT == null) && (STG_HDR_STATUS != "REVIEW")) {

                                            String stg_line_id = "," + ",LINE_ITEM_AMOUNT," + "LINE_ITEM_AMOUNT : " + db_STG_LINE_ITEM_AMOUNT + "," + "LINE_ITEM_AMOUNT was not found," + STG_LINE_STATUS + "," + "Fail";
                                            section4_results.add(stg_line_id);
                                        } else {
                                            String stg_header_id = "," + ",LINE_ITEM_AMOUNT," + "LINE_ITEM_AMOUNT : " + db_STG_LINE_ITEM_AMOUNT + "," + "LINE_ITEM_AMOUNT was found," + STG_LINE_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                        }

                                        //LINE_TAX_CODE - mandatory validation
                                        if ((db_STG_LINE_TAX_CODE == null) && (STG_HDR_STATUS != "REVIEW")) {

                                            String stg_line_id = "," + ",LINE_TAX_CODE," + "LINE_TAX_CODE : " + db_STG_LINE_TAX_CODE + "," + "LINE_TAX_CODE was not found," + STG_LINE_STATUS + "," + "Fail";
                                            section4_results.add(stg_line_id);
                                        } else {
                                            String stg_header_id = "," + ",LINE_TAX_CODE," + "LINE_TAX_CODE : " + db_STG_LINE_TAX_CODE + "," + "LINE_TAX_CODE was found," + STG_LINE_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                        }

                                        //LINE_DIST_CODE_CONCATENATED - mandatory validation
                                        if ((db_STG_LINE_DIST_CODE_CONCATENATED == null) && (STG_HDR_STATUS != "REVIEW")) {

                                            String stg_line_id = "," + ",LINE_DIST_CODE_CONCATENATED," + "LINE_DIST_CODE_CONCATENATED : " + db_STG_LINE_DIST_CODE_CONCATENATED + "," + "LINE_DIST_CODE_CONCATENATED was not found," + STG_LINE_STATUS + "," + "Fail";
                                            section4_results.add(stg_line_id);
                                        } else {
                                            String stg_header_id = "," + ",LINE_DIST_CODE_CONCATENATED," + "LINE_DIST_CODE_CONCATENATED : " + db_STG_LINE_DIST_CODE_CONCATENATED + "," + "LINE_DIST_CODE_CONCATENATED was found," + STG_LINE_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                        }

                                        //LINE_HEADER_ID - mandatory validation
                                        if ((db_STG_LINE_HEADER_ID == null) && (STG_HDR_STATUS != "REVIEW")) {

                                            String stg_line_id = "," + ",LINE_HEADER_ID," + "LINE_HEADER_ID : " + db_STG_LINE_HEADER_ID + "," + "LINE_HEADER_ID was not found," + STG_LINE_STATUS + "," + "Fail";
                                            section4_results.add(stg_line_id);
                                        } else {
                                            String stg_header_id = "," + ",LINE_HEADER_ID," + "LINE_HEADER_ID : " + db_STG_LINE_HEADER_ID + "," + "LINE_HEADER_ID was found," + STG_LINE_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                        }

                                        //LINE_CURRENCY_CODE - mandatory validation
                                        if ((db_STG_LINE_CURRENCY_CODE == null) && (STG_HDR_STATUS != "REVIEW")) {

                                            String stg_line_id = "," + ",LINE_CURRENCY_CODE," + "LINE_CURRENCY_CODE : " + db_STG_LINE_CURRENCY_CODE + "," + "LINE_CURRENCY_CODE was not found," + STG_LINE_STATUS + "," + "Fail";
                                            section4_results.add(stg_line_id);
                                        } else {
                                            String stg_header_id = "," + ",LINE_CURRENCY_CODE," + "LINE_CURRENCY_CODE : " + db_STG_LINE_CURRENCY_CODE + "," + "LINE_CURRENCY_CODE was found," + STG_LINE_STATUS + "," + "Pass";
                                            section4_results.add(stg_header_id);
                                        }

                                        String BMSAPInvoice_conslineSqlQuery = connect_db.executeQuery_DB("BMS_AP", "APInvoice_Cons_line", "BMS");
                                        SQLResultset = SQLstmt.executeQuery(BMSAPInvoice_conslineSqlQuery + "WHERE HEADER_ID = '" + db_STG_LINE_HEADER_ID + "' and LINE_NUMBER = '" + db_STG_LINE_NUMBER + "' ");
                                        //SQLResultset = SQLstmt.executeQuery("SELECT * FROM DLG_FSH_CONS_BMSX_API_LIN WHERE HEADER_ID = '" + db_STG_LINE_HEADER_ID + "' and LINE_NUMBER = '" + db_STG_LINE_NUMBER + "'  ");
                                        while (SQLResultset.next()) {
                                            db_CONS_line_id = SQLResultset.getString("LINE_ID");
                                            db_CONS_LINE_NUMBER = SQLResultset.getString("LINE_NUMBER");
                                            db_CONS_LINE_CATEGORY = SQLResultset.getString("CATEGORY");
                                            db_CONS_LINE_ITEM_AMOUNT = SQLResultset.getString("LINE_ITEM_AMOUNT");
                                            //db_CONS_BASE_LINE_ITEM_AMOUNT = SQLResultset.getString("BASE_LINE_ITEM_AMOUNT");
                                            //db_CONS_LINE_TRANSACTION_DATE = SQLResultset.getString("TRANSACTION_DATE");
                                            db_CONS_LINE_TAX_CODE = SQLResultset.getString("TAX_CODE");
                                            db_CONS_LINE_HEADER_ID = SQLResultset.getString("HEADER_ID");
                                            //db_CONS_CATEGORY = SQLResultset.getString("CATEGORY");
                                            db_CONS_LINE_DESCRIPTION = SQLResultset.getString("INVOICE_NUM");
                                            db_CONS_LINE_INVOICE_NUM = SQLResultset.getString("INVOICE_NUM");
                                            db_CONS_LINE_VENDOR_SITE_ID = SQLResultset.getString("VENDOR_SITE_ID");
                                            db_CONS_LINE_SOURCE = SQLResultset.getString("SOURCE");
                                            //db_CONS_LINE_PARTITION_ID = SQLResultset.getString("PARTITION_ID");
                                            db_CONS_LINE_FILE_NAME = SQLResultset.getString("FILE_NAME");
                                            CONS_LINE_STATUS = SQLResultset.getString("STATUS");

                                            //Validating mandatory fields in LINE consolidation table
                                            //INVOICE_NUM - mandatory validation
                                            if ((db_CONS_LINE_INVOICE_NUM == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String stg_INVOICE_NUM = stg_mandatory_map_row + "," + db_CONS_line_id + ",LINE INVOICE_NUM," + "LINE INVOICE_NUM : " + db_CONS_LINE_INVOICE_NUM + "," + "LINE INVOICE_NUM was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(stg_INVOICE_NUM);
                                                stg_mandatory_map_row++;
                                            } else {
                                                String stg_INVOICE_NUM = stg_mandatory_map_row + "," + db_CONS_line_id + ",LINE INVOICE_NUM," + "LINE INVOICE_NUM : " + db_CONS_LINE_INVOICE_NUM + "," + "LINE INVOICE_NUM was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(stg_INVOICE_NUM);
                                                stg_mandatory_map_row++;
                                            }


                                            //LINE_NUMBER - mandatory validation
                                            if ((db_CONS_LINE_NUMBER == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String stg_LINE_NUMBER = "," + ",LINE LINE_NUMBER," + "LINE LINE_NUMBER : " + db_CONS_LINE_NUMBER + "," + "LINE LINE_NUMBER was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(stg_LINE_NUMBER);
                                            } else {
                                                String stg_LINE_NUMBER = "," + ",LINE LINE_NUMBER," + "LINE LINE_NUMBER : " + db_CONS_LINE_NUMBER + "," + "LINE LINE_NUMBER was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(stg_LINE_NUMBER);
                                            }


                                            //VENDOR_SITE_ID - mandatory validation
                                            if ((db_CONS_LINE_VENDOR_SITE_ID == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String stg_VENDOR_SITE_ID = "," + ",LINE VENDOR_SITE_ID," + "LINE VENDOR_SITE_ID : " + db_CONS_LINE_VENDOR_SITE_ID + "," + "LINE VENDOR_SITE_ID was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(stg_VENDOR_SITE_ID);
                                            } else {
                                                String stg_VENDOR_SITE_ID = "," + ",LINE VENDOR_SITE_ID," + "LINE VENDOR_SITE_ID : " + db_CONS_LINE_VENDOR_SITE_ID + "," + "LINE VENDOR_SITE_ID was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(stg_VENDOR_SITE_ID);
                                            }


                                            //CATEGORY - mandatory validation
                                            if ((db_CONS_LINE_CATEGORY == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String stg_CATEGORY = "," + ",LINE CATEGORY," + "LINE CATEGORY : " + db_CONS_LINE_CATEGORY + "," + "LINE CATEGORY was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(stg_CATEGORY);
                                            } else {
                                                String stg_CATEGORY = "," + ",LINE CATEGORY," + "LINE CATEGORY : " + db_CONS_LINE_CATEGORY + "," + "LINE CATEGORY was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(stg_CATEGORY);
                                            }


                                            //LINE_ITEM_AMOUNT - mandatory validation
                                            if ((db_CONS_LINE_ITEM_AMOUNT == null) && (CONS_LINE_STATUS != "REVIEW")) {

                                                String stg_LINE_ITEM_AMOUNT = "," + ",LINE LINE_ITEM_AMOUNT," + "LINE LINE_ITEM_AMOUNT : " + db_CONS_LINE_ITEM_AMOUNT + "," + "LINE LINE_ITEM_AMOUNT was not found," + CONS_LINE_STATUS + "," + "Fail";
                                                section2_results.add(stg_LINE_ITEM_AMOUNT);
                                            } else {
                                                String stg_LINE_ITEM_AMOUNT = "," + ",LINE LINE_ITEM_AMOUNT," + "LINE LINE_ITEM_AMOUNT : " + db_CONS_LINE_ITEM_AMOUNT + "," + "LINE LINE_ITEM_AMOUNT was found," + CONS_LINE_STATUS + "," + "Pass";
                                                section2_results.add(stg_LINE_ITEM_AMOUNT);
                                            }


                                            String tbl_line = stg_line_map_row + "." + stg_sub_indent;
                                            //------------- Validate Line HEADER_ID ----------------
                                            if (db_STG_LINE_HEADER_ID.equals(db_CONS_LINE_HEADER_ID)) {
                                                String stg_line_pc_header_id = stg_line_map_row + "." + stg_sub_indent + ",LINE HEADER_ID," + db_STG_LINE_HEADER_ID + "," + db_CONS_LINE_HEADER_ID + ",Pass";
                                                section1_results.add(stg_line_pc_header_id);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE HEADER_ID" + "," + db_STG_LINE_HEADER_ID + "," + db_CONS_LINE_HEADER_ID + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                stg_sub_indent++;
                                            } else {
                                                String stg_line_pc_header_id = stg_line_map_row + "." + stg_sub_indent + ",LINE HEADER_ID," + db_STG_LINE_HEADER_ID + "," + db_CONS_LINE_HEADER_ID + ",Fail";
                                                section1_results.add(stg_line_pc_header_id);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE HEADER_ID" + "," + db_STG_LINE_HEADER_ID + "," + db_CONS_LINE_HEADER_ID + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                stg_sub_indent++;
                                                CONS_flag++;
                                            }

                                            //------------- Validate LINE_NUMBER ----------------
                                            if (db_STG_LINE_NUMBER.equals(db_CONS_LINE_NUMBER)) {
                                                String stg_line_number = ",LINE_NUMBER," + db_STG_LINE_NUMBER + "," + db_CONS_LINE_NUMBER + ",Pass";
                                                section1_results.add(stg_line_number);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_NUMBER" + "," + db_STG_LINE_NUMBER + "," + db_CONS_LINE_NUMBER + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String stg_line_number = ",LINE_NUMBER," + db_STG_LINE_NUMBER + "," + db_CONS_LINE_NUMBER + ",Fail";
                                                section1_results.add(stg_line_number);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_NUMBER" + "," + db_STG_LINE_NUMBER + "," + db_CONS_LINE_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }

                                            //------------- Validate LINE_ID ----------------
                                            String[] db_CONS_line_idModified = db_CONS_line_id.split("~");
                                            if (db_STG_line_id.equals(db_CONS_line_idModified[0])) {
                                                String stg_line_id = ",LINE_ID," + db_STG_line_id + "," + db_CONS_line_idModified[0] + ",Pass";
                                                section1_results.add(stg_line_id);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_ID" + "," + db_STG_line_id + "," + db_CONS_line_idModified[0] + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String stg_line_id = ",LINE_ID," + db_STG_line_id + "," + db_CONS_line_idModified[0] + ",Fail";
                                                section1_results.add(stg_line_id);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_ID" + "," + db_STG_line_id + "," + db_CONS_line_idModified[0] + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }

                                            //------------- Validate CATEGORY ----------------
                                            if (db_STG_LINE_CATEGORY.equals(db_CONS_LINE_CATEGORY)) {
                                                String stg_category = ",LINE CATEGORY," + db_STG_LINE_CATEGORY + "," + db_CONS_LINE_CATEGORY + ",Pass";
                                                section1_results.add(stg_category);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE CATEGORY" + "," + db_STG_LINE_CATEGORY + "," + db_CONS_LINE_CATEGORY + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String stg_category = ",LINE CATEGORY," + db_STG_LINE_CATEGORY + "," + db_CONS_LINE_CATEGORY + ",Fail";
                                                section1_results.add(stg_category);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE CATEGORY" + "," + db_STG_LINE_CATEGORY + "," + db_CONS_LINE_CATEGORY + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }

                                            //------------- Validate Line DESCRIPTION ----------------
                                            if (db_STG_LINE_DESCRIPTION.equals(db_CONS_LINE_DESCRIPTION)) {
                                                String stg_line_description = ",LINE DESCRIPTION," + db_STG_LINE_DESCRIPTION + "," + db_CONS_LINE_DESCRIPTION + ",Pass";
                                                section1_results.add(stg_line_description);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE DESCRIPTION" + "," + db_STG_LINE_DESCRIPTION + "," + db_CONS_LINE_DESCRIPTION + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String stg_line_description = ",LINE DESCRIPTION," + db_STG_LINE_DESCRIPTION + "," + db_CONS_LINE_DESCRIPTION + ",Fail";
                                                section1_results.add(stg_line_description);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE DESCRIPTION" + "," + db_STG_LINE_DESCRIPTION + "," + db_CONS_LINE_DESCRIPTION + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }

                                            //------------- Validate Line CURRENCY_CODE ----------------
                                            if (db_STG_LINE_CURRENCY_CODE.equals(db_CONS_INVOICE_CURRENCY_CODE)) {
                                                String stg_line_currency_code = ",LINE CURRENCY_CODE," + db_STG_LINE_CURRENCY_CODE + "," + db_CONS_INVOICE_CURRENCY_CODE + ",Pass";
                                                section1_results.add(stg_line_currency_code);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE CURRENCY_CODE" + "," + db_STG_LINE_CURRENCY_CODE + "," + db_CONS_INVOICE_CURRENCY_CODE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String stg_line_currency_code = ",LINE CURRENCY_CODE," + db_STG_LINE_CURRENCY_CODE + "," + db_CONS_INVOICE_CURRENCY_CODE + ",Fail";
                                                section1_results.add(stg_line_currency_code);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE CURRENCY_CODE" + "," + db_STG_LINE_CURRENCY_CODE + "," + db_CONS_INVOICE_CURRENCY_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }

                                            //------------- Validate DESCRIPTION ----------------
                                            if (db_STG_LINE_DESCRIPTION.equals(db_CONS_INVOICE_NUM)) {
                                                String stg_line_description = ",LINE DESCRIPTION," + db_STG_LINE_DESCRIPTION + "," + db_CONS_INVOICE_NUM + ",Pass";
                                                section1_results.add(stg_line_description);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE DESCRIPTION" + "," + db_STG_LINE_DESCRIPTION + "," + db_CONS_INVOICE_NUM + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String stg_line_description = ",LINE DESCRIPTION," + db_STG_LINE_DESCRIPTION + "," + db_CONS_INVOICE_NUM + ",Fail";
                                                section1_results.add(stg_line_description);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE DESCRIPTION" + "," + db_STG_LINE_DESCRIPTION + "," + db_CONS_INVOICE_NUM + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }

                                            //------------- Validate LINE_ITEM_AMOUNT ----------------
                                            if (db_STG_LINE_ITEM_AMOUNT.equals(db_CONS_LINE_ITEM_AMOUNT)) {
                                                String stg_line_amount = ",LINE_ITEM_AMOUNT," + db_STG_LINE_ITEM_AMOUNT + "," + db_CONS_LINE_ITEM_AMOUNT + ",Pass";
                                                section1_results.add(stg_line_amount);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_ITEM_AMOUNT" + "," + db_STG_LINE_ITEM_AMOUNT + "," + db_CONS_LINE_ITEM_AMOUNT + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String stg_line_amount = ",LINE_ITEM_AMOUNT," + db_STG_LINE_ITEM_AMOUNT + "," + db_CONS_LINE_ITEM_AMOUNT + ",Fail";
                                                section1_results.add(stg_line_amount);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_ITEM_AMOUNT" + "," + db_STG_LINE_ITEM_AMOUNT + "," + db_CONS_LINE_ITEM_AMOUNT + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }

                                            //------------- Validate LINE_TAX_CODE ----------------
                                            if (db_STG_LINE_TAX_CODE.equals(db_CONS_LINE_TAX_CODE)) {
                                                String stg_line_tax_code = ",LINE_TAX_CODE," + db_STG_LINE_TAX_CODE + "," + db_CONS_LINE_TAX_CODE + ",Pass";
                                                section1_results.add(stg_line_tax_code);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_TAX_CODE" + "," + db_STG_LINE_TAX_CODE + "," + db_CONS_LINE_TAX_CODE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String stg_line_tax_code = ",LINE_TAX_CODE," + db_STG_LINE_TAX_CODE + "," + db_CONS_LINE_TAX_CODE + ",Fail";
                                                section1_results.add(stg_line_tax_code);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_TAX_CODE" + "," + db_STG_LINE_TAX_CODE + "," + db_CONS_LINE_TAX_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }

                                            //------------- Validate LINE_SOURCE ----------------
                                            if (db_STG_LINE_SOURCE.equals(db_CONS_LINE_SOURCE)) {
                                                String stg_line_source = ",LINE_SOURCE," + db_STG_LINE_SOURCE + "," + db_CONS_LINE_SOURCE + ",Pass";
                                                section1_results.add(stg_line_source);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_SOURCE" + "," + db_STG_LINE_SOURCE + "," + db_CONS_LINE_SOURCE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String stg_line_source = ",LINE_SOURCE," + db_STG_LINE_SOURCE + "," + db_CONS_LINE_SOURCE + ",Fail";
                                                section1_results.add(stg_line_source);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_SOURCE" + "," + db_STG_LINE_SOURCE + "," + db_CONS_LINE_SOURCE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }

                                            //------------- Validate LINE_FILE_NAME ----------------
                                            if (db_STG_LINE_FILE_NAME.equals(db_CONS_LINE_FILE_NAME)) {
                                                String stg_line_file_name = ",LINE_FILE_NAME," + db_STG_LINE_FILE_NAME + "," + db_CONS_LINE_FILE_NAME + ",Pass";
                                                section1_results.add(stg_line_file_name);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_FILE_NAME" + "," + db_STG_LINE_FILE_NAME + "," + db_CONS_LINE_FILE_NAME + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            } else {
                                                String stg_line_file_name = ",LINE_FILE_NAME," + db_STG_LINE_FILE_NAME + "," + db_CONS_LINE_FILE_NAME + ",Fail";
                                                section1_results.add(stg_line_file_name);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_FILE_NAME" + "," + db_STG_LINE_FILE_NAME + "," + db_CONS_LINE_FILE_NAME + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }

                                            //----------------------- LINE STANDARDISATION start here -----------------------------
                                            String db_lookup_line_org_id_meaning = "null";
                                            String db_lookup_line_business_unit_meaning = "null";
                                            String db_lookup_line_segment1_meaning = "null";
                                            String db_lookup_line_segment2_meaning = "null";
                                            String db_lookup_line_segment3_meaning = "null";
                                            String db_lookup_line_segment4_meaning = "null";
                                            String db_lookup_line_segment5_meaning = "null";
                                            String db_lookup_line_segment6_meaning = "null";
                                            String db_lookup_line_segment7_meaning = "null";
                                            String db_lookup_line_segment8_meaning = "null";
                                            String db_lookup_line_segment9_meaning = "null";
                                            String db_lookup_line_segment10_meaning = "null";
                                            String db_lookup_line_category_meaning = "null";
                                            String db_lookup_line_tax_code_meaning = "null";
                                            String db_lookup_line_tax_rate_code_meaning = "null";
                                            String db_lookup_LINE_TYPE_LOOKUP_CODE1_meaning = "null";
                                            String db_lookup_LINE_TYPE_LOOKUP_CODE2_meaning = "null";
                                            String db_lookup_line_cost_centre_meaning = "null";
                                            String db_lookup_line_account_code_meaning = "null";

                                            //---------------- Validate LINE ORG_ID -----------------------
                                            SQLResultset = SQLstmt.executeQuery(BMSAPInvoice_fsh_sys_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'ORG_ID'" + fsh_source);
                                            //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'ORG_ID' and system = 'ECLI' and pattern = 'APInvoice'");
                                            while (SQLResultset.next()) {
                                                db_lookup_line_org_id_meaning = SQLResultset.getString("MEANING");
                                            }
                                            if (db_lookup_line_org_id_meaning.equals("null")) {
                                                String lookup_org_id_meaning = ",LINE ORG_ID lookup," + "LookUp value not found" + "," + db_STG_LINE_ORG_ID + ",Fail";
                                                section1_results.add(lookup_org_id_meaning);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE ORG_ID lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_ORG_ID + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            } else if (db_lookup_line_org_id_meaning != null) {
                                                if (db_lookup_line_org_id_meaning.equals(db_STG_LINE_ORG_ID)) {
                                                    String lookup_org_id_meaning = ",LINE ORG_ID lookup," + db_lookup_line_org_id_meaning + "," + db_STG_LINE_ORG_ID + ",Pass";
                                                    section1_results.add(lookup_org_id_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE ORG_ID lookup" + "," + db_lookup_line_org_id_meaning + "," + db_STG_LINE_ORG_ID + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String lookup_org_id_meaning = ",LINE ORG_ID lookup," + db_lookup_line_org_id_meaning + "," + db_STG_LINE_ORG_ID + ",Fail";
                                                    section1_results.add(lookup_org_id_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE ORG_ID lookup" + "," + db_lookup_line_org_id_meaning + "," + db_STG_LINE_ORG_ID + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            }

                                            //---------------- Validate LINE BUSINESS_UNIT -----------------------
                                            SQLResultset = SQLstmt.executeQuery(BMSAPInvoice_fsh_sys_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'BUSINESS_UNIT'" + fsh_source);
                                            //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'BUSINESS_UNIT' and system = 'ECLI' and pattern = 'APInvoice'");
                                            while (SQLResultset.next()) {
                                                db_lookup_line_business_unit_meaning = SQLResultset.getString("MEANING");
                                            }
                                            if (db_lookup_line_business_unit_meaning.equals("null")) {
                                                String lookup_org_id_meaning = ",LINE BUSINESS_UNIT lookup," + "LookUp value not found" + "," + db_STG_LINE_BUSINESS_UNIT + ",Fail";
                                                section1_results.add(lookup_org_id_meaning);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE BUSINESS_UNIT lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_BUSINESS_UNIT + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            } else if (db_lookup_line_business_unit_meaning != null) {
                                                if (db_lookup_line_business_unit_meaning.equals(db_STG_LINE_BUSINESS_UNIT)) {
                                                    String lookup_org_id_meaning = ",LINE BUSINESS_UNIT lookup," + db_lookup_line_business_unit_meaning + "," + db_STG_LINE_BUSINESS_UNIT + ",Pass";
                                                    section1_results.add(lookup_org_id_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE BUSINESS_UNIT lookup" + "," + db_lookup_line_business_unit_meaning + "," + db_STG_LINE_BUSINESS_UNIT + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String lookup_org_id_meaning = ",LINE BUSINESS_UNIT lookup," + db_lookup_line_business_unit_meaning + "," + db_STG_LINE_BUSINESS_UNIT + ",Fail";
                                                    section1_results.add(lookup_org_id_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE BUSINESS_UNIT lookup" + "," + db_lookup_line_business_unit_meaning + "," + db_STG_LINE_BUSINESS_UNIT + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            }

                                            //---------------- Validate LINE SEGMENT1 -----------------------
                                            SQLResultset = SQLstmt.executeQuery(BMSAPInvoice_fsh_sys_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'SEGMENT1'" + fsh_source);
                                            //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'SEGMENT1' and system = 'ECLI' and pattern = 'APInvoice'");
                                            while (SQLResultset.next()) {
                                                db_lookup_line_segment1_meaning = SQLResultset.getString("MEANING");
                                            }
                                            if (db_lookup_line_segment1_meaning.equals("null")) {
                                                String lookup_segment1_meaning = ",LINE SEGMENT1 lookup," + "LookUp value not found" + "," + db_STG_LINE_SEGMENT1 + ",Fail";
                                                section1_results.add(lookup_segment1_meaning);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT1 lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_SEGMENT1 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            } else if (db_lookup_line_segment1_meaning != null) {
                                                if (db_lookup_line_segment1_meaning.equals(db_STG_LINE_SEGMENT1)) {
                                                    String lookup_segment1_meaning = ",LINE SEGMENT1 lookup," + db_lookup_line_segment1_meaning + "," + db_STG_LINE_SEGMENT1 + ",Pass";
                                                    section1_results.add(lookup_segment1_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT1 lookup" + "," + db_lookup_line_segment1_meaning + "," + db_STG_LINE_SEGMENT1 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String lookup_segment1_meaning = ",LINE SEGMENT1 lookup," + db_lookup_line_segment1_meaning + "," + db_STG_LINE_SEGMENT1 + ",Fail";
                                                    section1_results.add(lookup_segment1_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT1 lookup" + "," + db_lookup_line_segment1_meaning + "," + db_STG_LINE_SEGMENT1 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            }

                                            //---------------- Validate LINE SEGMENT2 -----------------------
                                            SQLResultset = SQLstmt.executeQuery(BMSAPInvoice_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_CONS_CHANNEL + "' and LOOKUP_TYPE = 'SEGMENT2'" + fsh_source);
                                            //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_CHANNEL + "' and LOOKUP_TYPE = 'SEGMENT2' and system = 'ECLI' and pattern = 'APInvoice'");
                                            while (SQLResultset.next()) {
                                                db_lookup_line_segment2_meaning = SQLResultset.getString("MEANING");
                                            }
                                            if (db_lookup_line_segment2_meaning.equals("null")) {
                                                String lookup_segment2_meaning = ",LINE SEGMENT2 lookup," + "LookUp value not found" + "," + db_STG_LINE_SEGMENT2 + ",Fail";
                                                section1_results.add(lookup_segment2_meaning);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT2 lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_SEGMENT2 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            } else if (db_lookup_line_segment2_meaning != null) {
                                                if (db_lookup_line_segment2_meaning.equals(db_STG_LINE_SEGMENT2)) {
                                                    String lookup_segment2_meaning = ",LINE SEGMENT2 lookup," + db_lookup_line_segment2_meaning + "," + db_STG_LINE_SEGMENT2 + ",Pass";
                                                    section1_results.add(lookup_segment2_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT2 lookup" + "," + db_lookup_line_segment2_meaning + "," + db_STG_LINE_SEGMENT2 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String lookup_segment2_meaning = ",LINE SEGMENT2 lookup," + db_lookup_line_segment2_meaning + "," + db_STG_LINE_SEGMENT2 + ",Fail";
                                                    section1_results.add(lookup_segment2_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT2 lookup" + "," + db_lookup_line_segment2_meaning + "," + db_STG_LINE_SEGMENT2 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            }

                                            //---------------- Validate LINE SEGMENT3 -----------------------
                                            SQLResultset = SQLstmt.executeQuery(BMSAPInvoice_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_CONS_LINE_CATEGORY + "' and LOOKUP_TYPE = 'SEGMENT3' " + fsh_source);
                                            //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_LINE_CATEGORY + "' and LOOKUP_TYPE = 'SEGMENT3' and system = 'ECLI' and pattern = 'APInvoice'");
                                            while (SQLResultset.next()) {
                                                db_lookup_line_segment3_meaning = SQLResultset.getString("MEANING");
                                            }
                                            if (db_lookup_line_segment3_meaning.equals("null")) {
                                                String lookup_segment3_meaning = ",LINE SEGMENT3 lookup," + "LookUp value not found" + "," + db_STG_LINE_SEGMENT3 + ",Fail";
                                                section1_results.add(lookup_segment3_meaning);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT3 lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_SEGMENT3 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            } else if (db_lookup_line_segment3_meaning != null) {
                                                if (db_lookup_line_segment3_meaning.equals(db_STG_LINE_SEGMENT3)) {
                                                    String lookup_segment3_meaning = ",LINE SEGMENT3 lookup," + db_lookup_line_segment3_meaning + "," + db_STG_LINE_SEGMENT3 + ",Pass";
                                                    section1_results.add(lookup_segment3_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT3 lookup" + "," + db_lookup_line_segment3_meaning + "," + db_STG_LINE_SEGMENT3 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String lookup_segment3_meaning = ",LINE SEGMENT3 lookup," + db_lookup_line_segment3_meaning + "," + db_STG_LINE_SEGMENT3 + ",Fail";
                                                    section1_results.add(lookup_segment3_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT3 lookup" + "," + db_lookup_line_segment3_meaning + "," + db_STG_LINE_SEGMENT3 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            }

                                            //---------------- Validate LINE SEGMENT4 -----------------------
                                            SQLResultset = SQLstmt.executeQuery(BMSAPInvoice_fsh_sys_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'SEGMENT4' " + fsh_source);
                                            //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'SEGMENT4' and system = 'ECLI' and pattern = 'APInvoice'");
                                            while (SQLResultset.next()) {
                                                db_lookup_line_segment4_meaning = SQLResultset.getString("MEANING");
                                            }
                                            if (db_lookup_line_segment4_meaning.equals("null")) {
                                                String lookup_segment4_meaning = ",LINE SEGMENT4 lookup," + "LookUp value not found" + "," + db_STG_LINE_SEGMENT4 + ",Fail";
                                                section1_results.add(lookup_segment4_meaning);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT4 lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_SEGMENT4 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            } else if (db_lookup_line_segment4_meaning != null) {
                                                if (db_lookup_line_segment4_meaning.equals(db_STG_LINE_SEGMENT4)) {
                                                    String lookup_segment4_meaning = ",LINE SEGMENT4 lookup," + db_lookup_line_segment4_meaning + "," + db_STG_LINE_SEGMENT4 + ",Pass";
                                                    section1_results.add(lookup_segment4_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT4 lookup" + "," + db_lookup_line_segment4_meaning + "," + db_STG_LINE_SEGMENT4 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String lookup_segment4_meaning = ",LINE SEGMENT4 lookup," + db_lookup_line_segment4_meaning + "," + db_STG_LINE_SEGMENT4 + ",Fail";
                                                    section1_results.add(lookup_segment4_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT4 lookup" + "," + db_lookup_line_segment4_meaning + "," + db_STG_LINE_SEGMENT4 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            }

                                            //---------------- Validate LINE SEGMENT5 -----------------------
                                            SQLResultset = SQLstmt.executeQuery(BMSAPInvoice_fsh_sys_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'SEGMENT5' " + fsh_source);
                                            //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'SEGMENT5' and system = 'ECLI' and pattern = 'APInvoice'");
                                            while (SQLResultset.next()) {
                                                db_lookup_line_segment5_meaning = SQLResultset.getString("MEANING");
                                            }
                                            if (db_lookup_line_segment5_meaning.equals("null")) {
                                                String lookup_segment5_meaning = ",LINE SEGMENT5 lookup," + "LookUp value not found" + "," + db_STG_LINE_SEGMENT5 + ",Fail";
                                                section1_results.add(lookup_segment5_meaning);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT5 lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_SEGMENT5 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            } else if (db_lookup_line_segment5_meaning != null) {
                                                if (db_lookup_line_segment5_meaning.equals(db_STG_LINE_SEGMENT5)) {
                                                    String lookup_segment5_meaning = ",LINE SEGMENT5 lookup," + db_lookup_line_segment5_meaning + "," + db_STG_LINE_SEGMENT5 + ",Pass";
                                                    section1_results.add(lookup_segment5_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT5 lookup" + "," + db_lookup_line_org_id_meaning + "," + db_STG_LINE_SEGMENT5 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String lookup_segment5_meaning = ",LINE SEGMENT5 lookup," + db_lookup_line_segment5_meaning + "," + db_STG_LINE_SEGMENT5 + ",Fail";
                                                    section1_results.add(lookup_segment5_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT5 lookup" + "," + db_lookup_line_org_id_meaning + "," + db_STG_LINE_SEGMENT5 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            }

                                            //---------------- Validate LINE SEGMENT6 -----------------------
                                            SQLResultset = SQLstmt.executeQuery(BMSAPInvoice_fsh_sys_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'SEGMENT6' " + fsh_source);
                                            //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'SEGMENT6' and system = 'ECLI' and pattern = 'APInvoice'");
                                            while (SQLResultset.next()) {
                                                db_lookup_line_segment6_meaning = SQLResultset.getString("MEANING");
                                            }
                                            if (db_lookup_line_segment6_meaning.equals("null")) {
                                                String lookup_segment6_meaning = ",LINE SEGMENT6 lookup," + "LookUp value not found" + "," + db_STG_LINE_SEGMENT6 + ",Fail";
                                                section1_results.add(lookup_segment6_meaning);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT6 lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_SEGMENT6 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            } else if (db_lookup_line_segment6_meaning != null) {
                                                if (db_lookup_line_segment6_meaning.equals(db_STG_LINE_SEGMENT6)) {
                                                    String lookup_segment6_meaning = ",LINE SEGMENT6 lookup," + db_lookup_line_segment6_meaning + "," + db_STG_LINE_SEGMENT6 + ",Pass";
                                                    section1_results.add(lookup_segment6_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT6 lookup" + "," + db_lookup_line_segment6_meaning + "," + db_STG_LINE_SEGMENT6 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String lookup_segment6_meaning = ",LINE SEGMENT6 lookup," + db_lookup_line_segment6_meaning + "," + db_STG_LINE_SEGMENT6 + ",Fail";
                                                    section1_results.add(lookup_segment6_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT6 lookup" + "," + db_lookup_line_segment6_meaning + "," + db_STG_LINE_SEGMENT6 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            }

                                            //---------------- Validate LINE SEGMENT7 -----------------------
                                            SQLResultset = SQLstmt.executeQuery(BMSAPInvoice_fsh_sys_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'SEGMENT7' " + fsh_source);
                                            //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'SEGMENT7' and system = 'ECLI' and pattern = 'APInvoice'");
                                            while (SQLResultset.next()) {
                                                db_lookup_line_segment7_meaning = SQLResultset.getString("MEANING");
                                            }
                                            if (db_lookup_line_segment7_meaning.equals("null")) {
                                                String lookup_segment7_meaning = ",LINE SEGMENT7 lookup," + "LookUp value not found" + "," + db_STG_LINE_SEGMENT7 + ",Fail";
                                                section1_results.add(lookup_segment7_meaning);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT7 lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_SEGMENT7 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            } else if (db_lookup_line_segment7_meaning != null) {
                                                if (db_lookup_line_segment7_meaning.equals(db_STG_LINE_SEGMENT7)) {
                                                    String lookup_segment7_meaning = ",LINE SEGMENT7 lookup," + db_lookup_line_segment7_meaning + "," + db_STG_LINE_SEGMENT7 + ",Pass";
                                                    section1_results.add(lookup_segment7_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT7 lookup" + "," + db_lookup_line_segment7_meaning + "," + db_STG_LINE_SEGMENT7 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String lookup_segment7_meaning = ",LINE SEGMENT7 lookup," + db_lookup_line_segment7_meaning + "," + db_STG_LINE_SEGMENT7 + ",Fail";
                                                    section1_results.add(lookup_segment7_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT7 lookup" + "," + db_lookup_line_segment7_meaning + "," + db_STG_LINE_SEGMENT7 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            }

                                            //---------------- Validate LINE SEGMENT8 -----------------------
                                            SQLResultset = SQLstmt.executeQuery(BMSAPInvoice_fsh_sys_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'SEGMENT8' " + fsh_source);
                                            //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'SEGMENT8' and system = 'ECLI' and pattern = 'APInvoice'");
                                            while (SQLResultset.next()) {
                                                db_lookup_line_segment8_meaning = SQLResultset.getString("MEANING");
                                            }
                                            if (db_lookup_line_segment8_meaning.equals("null")) {
                                                String lookup_segment8_meaning = ",LINE SEGMENT8 lookup," + "LookUp value not found" + "," + db_STG_LINE_SEGMENT8 + ",Fail";
                                                section1_results.add(lookup_segment8_meaning);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT8 lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_SEGMENT8 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            } else if (db_lookup_line_segment8_meaning != null) {
                                                if (db_lookup_line_segment8_meaning.equals(db_STG_LINE_SEGMENT8)) {
                                                    String lookup_segment8_meaning = ",LINE SEGMENT8 lookup," + db_lookup_line_segment8_meaning + "," + db_STG_LINE_SEGMENT8 + ",Pass";
                                                    section1_results.add(lookup_segment8_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT8 lookup" + "," + db_lookup_line_segment8_meaning + "," + db_STG_LINE_SEGMENT8 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String lookup_segment8_meaning = ",LINE SEGMENT8 lookup," + db_lookup_line_segment8_meaning + "," + db_STG_LINE_SEGMENT8 + ",Fail";
                                                    section1_results.add(lookup_segment8_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT8 lookup" + "," + db_lookup_line_segment8_meaning + "," + db_STG_LINE_SEGMENT8 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            }

                                            //---------------- Validate LINE SEGMENT9 -----------------------
                                            SQLResultset = SQLstmt.executeQuery(BMSAPInvoice_fsh_sys_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'SEGMENT9'" + fsh_source);
                                            //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'SEGMENT9' and system = 'ECLI' and pattern = 'APInvoice'");
                                            while (SQLResultset.next()) {
                                                db_lookup_line_segment9_meaning = SQLResultset.getString("MEANING");
                                            }
                                            if (db_lookup_line_segment9_meaning.equals("null")) {
                                                String lookup_segment9_meaning = ",LINE SEGMENT9 lookup," + "LookUp value not found" + "," + db_STG_LINE_SEGMENT9 + ",Fail";
                                                section1_results.add(lookup_segment9_meaning);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT9 lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_SEGMENT9 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            } else if (db_lookup_line_segment9_meaning != null) {
                                                if (db_lookup_line_segment9_meaning.equals(db_STG_LINE_SEGMENT9)) {
                                                    String lookup_segment9_meaning = ",LINE SEGMENT9 lookup," + db_lookup_line_segment9_meaning + "," + db_STG_LINE_SEGMENT9 + ",Pass";
                                                    section1_results.add(lookup_segment9_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT9 lookup" + "," + db_lookup_line_segment9_meaning + "," + db_STG_LINE_SEGMENT9 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String lookup_segment9_meaning = ",LINE SEGMENT9 lookup," + db_lookup_line_segment9_meaning + "," + db_STG_LINE_SEGMENT9 + ",Fail";
                                                    section1_results.add(lookup_segment9_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT9 lookup" + "," + db_lookup_line_segment9_meaning + "," + db_STG_LINE_SEGMENT9 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            }

                                            //---------------- Validate LINE SEGMENT10 -----------------------
                                            SQLResultset = SQLstmt.executeQuery(BMSAPInvoice_fsh_sys_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'SEGMENT10'" + fsh_source);
                                            //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'SEGMENT10' and system = 'ECLI' and pattern = 'APInvoice'");
                                            while (SQLResultset.next()) {
                                                db_lookup_line_segment10_meaning = SQLResultset.getString("MEANING");
                                            }
                                            if (db_lookup_line_segment10_meaning.equals("null")) {
                                                String lookup_segment10_meaning = ",LINE SEGMENT10 lookup," + "LookUp value not found" + "," + db_STG_LINE_SEGMENT10 + ",Fail";
                                                section1_results.add(lookup_segment10_meaning);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT10 lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_SEGMENT10 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            } else if (db_lookup_line_segment10_meaning != null) {
                                                if (db_lookup_line_segment10_meaning.equals(db_STG_LINE_SEGMENT10)) {
                                                    String lookup_segment10_meaning = ",LINE SEGMENT10 lookup," + db_lookup_line_segment10_meaning + "," + db_STG_LINE_SEGMENT10 + ",Pass";
                                                    section1_results.add(lookup_segment10_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT10 lookup" + "," + db_lookup_line_segment10_meaning + "," + db_STG_LINE_SEGMENT10 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String lookup_segment10_meaning = ",LINE SEGMENT10 lookup," + db_lookup_line_segment10_meaning + "," + db_STG_LINE_SEGMENT10 + ",Fail";
                                                    section1_results.add(lookup_segment10_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE SEGMENT10 lookup" + "," + db_lookup_line_segment10_meaning + "," + db_STG_LINE_SEGMENT10 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            }

                                            //---------------- Validate LINE COST_CENTRE -----------------------
                                            SQLResultset = SQLstmt.executeQuery(BMSAPInvoice_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_CONS_CHANNEL + "' and LOOKUP_TYPE = 'SEGMENT2' " + fsh_source);
                                            //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_CHANNEL + "' and LOOKUP_TYPE = 'SEGMENT2' and system = 'ECLI' and pattern = 'APInvoice'");
                                            while (SQLResultset.next()) {
                                                db_lookup_line_cost_centre_meaning = SQLResultset.getString("MEANING");
                                            }
                                            if (db_lookup_line_cost_centre_meaning.equals("null")) {
                                                String lookup_line_cost_centre_meaning = ",LINE COST_CENTRE lookup," + "LookUp value not found" + "," + db_STG_LINE_SEGMENT2 + ",Fail";
                                                section1_results.add(lookup_line_cost_centre_meaning);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE COST_CENTRE lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_SEGMENT2 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            } else if (db_lookup_line_cost_centre_meaning != null) {
                                                if (db_lookup_line_cost_centre_meaning.equals(db_STG_LINE_SEGMENT2)) {
                                                    String lookup_line_cost_centre_meaning = ",LINE COST_CENTRE lookup," + db_lookup_line_cost_centre_meaning + "," + db_STG_LINE_SEGMENT2 + ",Pass";
                                                    section1_results.add(lookup_line_cost_centre_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE COST_CENTRE lookup" + "," + db_lookup_line_cost_centre_meaning + "," + db_STG_LINE_SEGMENT2 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String lookup_line_cost_centre_meaning = ",LINE COST_CENTRE lookup," + db_lookup_line_cost_centre_meaning + "," + db_STG_LINE_SEGMENT2 + ",Fail";
                                                    section1_results.add(lookup_line_cost_centre_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE COST_CENTRE lookup" + "," + db_lookup_line_cost_centre_meaning + "," + db_STG_LINE_SEGMENT2 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            }

                                            //---------------- Validate LINE ACCOUNT_CODE -----------------------
                                            SQLResultset = SQLstmt.executeQuery(BMSAPInvoice_fsh_lookup + " WHERE  LOOKUP_CODE = '" + db_CONS_LINE_CATEGORY + "' and LOOKUP_TYPE = 'SEGMENT3' " + fsh_source);
                                            //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_LINE_CATEGORY + "' and LOOKUP_TYPE = 'SEGMENT3' and system = 'ECLI' and pattern = 'APInvoice'");
                                            while (SQLResultset.next()) {
                                                db_lookup_line_account_code_meaning = SQLResultset.getString("MEANING");
                                            }
                                            if (db_lookup_line_account_code_meaning.equals("null")) {
                                                String lookup_line_account_code_meaning = ",LINE ACCOUNT_CODE lookup," + "LookUp value not found" + "," + db_STG_LINE_SEGMENT3 + ",Fail";
                                                section1_results.add(lookup_line_account_code_meaning);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE ACCOUNT_CODE lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_SEGMENT3 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            } else if (db_lookup_line_account_code_meaning != null) {
                                                if (db_lookup_line_account_code_meaning.equals(db_STG_LINE_SEGMENT3)) {
                                                    String lookup_line_account_code_meaning = ",LINE ACCOUNT_CODE lookup," + db_lookup_line_account_code_meaning + "," + db_STG_LINE_SEGMENT3 + ",Pass";
                                                    section1_results.add(lookup_line_account_code_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE ACCOUNT_CODE lookup" + "," + db_lookup_line_account_code_meaning + "," + db_STG_LINE_SEGMENT3 + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String lookup_line_account_code_meaning = ",LINE ACCOUNT_CODE lookup," + db_lookup_line_account_code_meaning + "," + db_STG_LINE_SEGMENT3 + ",Fail";
                                                    section1_results.add(lookup_line_account_code_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE ACCOUNT_CODE lookup" + "," + db_lookup_line_account_code_meaning + "," + db_STG_LINE_SEGMENT3 + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            }

                                            //---------------- Validate LINE CATEGORY -----------------------
                                            if (db_CONS_LINE_CATEGORY.equals("VAT")) {
                                                SQLResultset = SQLstmt.executeQuery(BMSAPInvoice_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_CONS_LINE_CATEGORY + "' and LOOKUP_TYPE = 'LINE_TYPE_LOOKUP_CODE' " + fsh_source);
                                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_LINE_CATEGORY + "' and LOOKUP_TYPE = 'LINE_TYPE_LOOKUP_CODE' and system = 'ECLI' and pattern = 'APInvoice'");
                                                while (SQLResultset.next()) {
                                                    db_lookup_line_category_meaning = SQLResultset.getString("MEANING");
                                                }
                                                if (db_lookup_line_category_meaning.equals("null")) {
                                                    String lookup_line_category_meaning = ",LINE CATEGORY lookup," + "LookUp value not found" + "," + db_STG_LINE_TYPE_LOOKUP_CODE + ",Fail";
                                                    section1_results.add(lookup_line_category_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE CATEGORY lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_TYPE_LOOKUP_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                } else if (db_lookup_line_category_meaning != null) {
                                                    if (db_lookup_line_category_meaning.equals(db_STG_LINE_TYPE_LOOKUP_CODE)) {
                                                        String lookup_line_category_meaning = ",LINE CATEGORY lookup," + db_lookup_line_category_meaning + "," + db_STG_LINE_TYPE_LOOKUP_CODE + ",Pass";
                                                        section1_results.add(lookup_line_category_meaning);
                                                        String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE CATEGORY lookup" + "," + db_lookup_line_category_meaning + "," + db_STG_LINE_TYPE_LOOKUP_CODE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                        section2_results_tbl.add(tbl_header_id);
                                                    } else {
                                                        String lookup_line_category_meaning = ",LINE CATEGORY lookup," + db_lookup_line_category_meaning + "," + db_STG_LINE_TYPE_LOOKUP_CODE + ",Fail";
                                                        section1_results.add(lookup_line_category_meaning);
                                                        String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE CATEGORY lookup" + "," + db_lookup_line_category_meaning + "," + db_STG_LINE_TYPE_LOOKUP_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                        section2_results_tbl.add(tbl_header_id);
                                                        CONS_flag++;
                                                    }
                                                }
                                            } else {

                                                SQLResultset = SQLstmt.executeQuery(BMSAPInvoice_fsh_sys_lookup + " WHERE LOOKUP_CODE = 'ITEM' and LOOKUP_TYPE = 'LINE_TYPE_LOOKUP_CODE' " + fsh_source);
                                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_CODE = 'ITEM' and LOOKUP_TYPE = 'LINE_TYPE_LOOKUP_CODE' and system = 'ECLI' and pattern = 'APInvoice'");
                                                while (SQLResultset.next()) {
                                                    db_lookup_line_category_meaning = SQLResultset.getString("MEANING");
                                                    System.out.println("The meaning of Parameter Lookups::" + db_lookup_line_category_meaning);
                                                }
                                                if (db_lookup_line_category_meaning.equals("null")) {
                                                    String lookup_line_category_meaning = ",LINE CATEGORY lookup," + "LookUp value not found" + "," + db_STG_LINE_TYPE_LOOKUP_CODE + ",Fail";
                                                    section1_results.add(lookup_line_category_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE CATEGORY lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_TYPE_LOOKUP_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                } else if (db_lookup_line_category_meaning != null) {
                                                    if (db_lookup_line_category_meaning.equals(db_STG_LINE_TYPE_LOOKUP_CODE)) {
                                                        String lookup_line_category_meaning = ",LINE CATEGORY lookup," + db_lookup_line_category_meaning + "," + db_STG_LINE_TYPE_LOOKUP_CODE + ",Pass";
                                                        section1_results.add(lookup_line_category_meaning);
                                                        String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE CATEGORY lookup" + "," + db_lookup_line_category_meaning + "," + db_STG_LINE_TYPE_LOOKUP_CODE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                        section2_results_tbl.add(tbl_header_id);
                                                    } else {
                                                        String lookup_line_category_meaning = ",LINE CATEGORY lookup," + db_lookup_line_category_meaning + "," + db_STG_LINE_TYPE_LOOKUP_CODE + ",Fail";
                                                        section1_results.add(lookup_line_category_meaning);
                                                        String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE CATEGORY lookup" + "," + db_lookup_line_category_meaning + "," + db_STG_LINE_TYPE_LOOKUP_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                        section2_results_tbl.add(tbl_header_id);
                                                        CONS_flag++;
                                                    }
                                                }
                                            }

                                            //---------------- Validate LINE TAX_CODE -----------------------
                                            if (db_STG_LINE_TAX_CODE.equals("24")) {

                                                SQLResultset = SQLstmt.executeQuery(BMSAPInvoice_fsh_lookup + " WHERE LOOKUP_CODE = ' " + db_CONS_LINE_TAX_CODE + " ' and LOOKUP_TYPE = 'SUBJECT_REV_CHARGE'" + fsh_source);
                                                //SQLResultset = SQLstmt.executeQuery("SELECT * FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = ' " + db_CONS_LINE_TAX_CODE + " ' and LOOKUP_TYPE = 'SUBJECT_REV_CHARGE' and system = 'ECLI' and pattern = 'APInvoice'");
                                                while (SQLResultset.next()) {
                                                    db_lookup_line_tax_code_meaning = SQLResultset.getString("MEANING");
                                                }
                                                if (db_lookup_line_tax_code_meaning.equals("null")) {
                                                    String lookup_line_tax_code_meaning = ",LINE TAX_CODE lookup," + "LookUp value not found" + "," + db_STG_LINE_SUBJECT_REV_CHARGE + ",Fail";
                                                    section1_results.add(lookup_line_tax_code_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE TAX_CODE lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_SUBJECT_REV_CHARGE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                } else if (db_lookup_line_tax_code_meaning != null) {
                                                    if (db_lookup_line_tax_code_meaning.equals(db_STG_LINE_SUBJECT_REV_CHARGE)) {
                                                        String lookup_line_tax_code_meaning = ",LINE TAX_CODE lookup," + db_lookup_line_tax_code_meaning + "," + db_STG_LINE_SUBJECT_REV_CHARGE + ",Pass";
                                                        section1_results.add(lookup_line_tax_code_meaning);
                                                        String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE TAX_CODE lookup" + "," + db_lookup_line_tax_code_meaning + "," + db_STG_LINE_SUBJECT_REV_CHARGE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                        section2_results_tbl.add(tbl_header_id);
                                                    } else {
                                                        String lookup_line_tax_code_meaning = ",LINE TAX_CODE lookup," + db_lookup_line_tax_code_meaning + "," + db_STG_LINE_SUBJECT_REV_CHARGE + ",Fail";
                                                        section1_results.add(lookup_line_tax_code_meaning);
                                                        String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE TAX_CODE lookup" + "," + db_lookup_line_tax_code_meaning + "," + db_STG_LINE_SUBJECT_REV_CHARGE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                        section2_results_tbl.add(tbl_header_id);
                                                        CONS_flag++;
                                                    }
                                                }
                                            } else {

                                                //SQLResultset = SQLstmt.executeQuery("SELECT * FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_TYPE = 'SUBJECT_REV_CHARGE' and system = 'ECLI' and pattern = 'APInvoice'");
                                                //while (SQLResultset.next()) {
                                                db_lookup_line_tax_code_meaning = "0";
                                                System.out.println("The meaning of Lookups::" + db_lookup_line_tax_code_meaning);
                                                //}
                                                if (db_lookup_line_tax_code_meaning.equals("null")) {
                                                    String lookup_line_tax_code_meaning = ",LINE TAX_CODE lookup," + "LookUp value not found" + "," + db_STG_LINE_SUBJECT_REV_CHARGE + ",Fail";
                                                    section1_results.add(lookup_line_tax_code_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE TAX_CODE lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_SUBJECT_REV_CHARGE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                } else if (db_lookup_line_tax_code_meaning != null) {
                                                    if (db_lookup_line_tax_code_meaning.equals(db_STG_LINE_SUBJECT_REV_CHARGE)) {
                                                        String lookup_line_tax_code_meaning = ",LINE TAX_CODE lookup," + db_lookup_line_tax_code_meaning + "," + db_STG_LINE_SUBJECT_REV_CHARGE + ",Pass";
                                                        section1_results.add(lookup_line_tax_code_meaning);
                                                        String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE TAX_CODE lookup" + "," + db_lookup_line_tax_code_meaning + "," + db_STG_LINE_SUBJECT_REV_CHARGE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                        section2_results_tbl.add(tbl_header_id);
                                                    } else {
                                                        String lookup_line_tax_code_meaning = ",LINE TAX_CODE lookup," + db_lookup_line_tax_code_meaning + "," + db_STG_LINE_SUBJECT_REV_CHARGE + ",Fail";
                                                        section1_results.add(lookup_line_tax_code_meaning);
                                                        String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE TAX_CODE lookup" + "," + db_lookup_line_tax_code_meaning + "," + db_STG_LINE_SUBJECT_REV_CHARGE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                        section2_results_tbl.add(tbl_header_id);
                                                        CONS_flag++;
                                                    }
                                                }
                                            }

                                            //---------------- Validate LINE TAX_RATE_CODE -----------------------
                                            if (db_STG_LINE_TYPE_LOOKUP_CODE.equals("TAX")) {

                                                SQLResultset = SQLstmt.executeQuery(BMSAPInvoice_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_CONS_LINE_TAX_CODE + "' and LOOKUP_TYPE = 'TAX_RATE_CODE'" + fsh_source);
                                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_LINE_TAX_CODE + "' and LOOKUP_TYPE = 'TAX_RATE_CODE' and system = 'ECLI' and pattern = 'APInvoice'");
                                                while (SQLResultset.next()) {
                                                    db_lookup_line_tax_rate_code_meaning = SQLResultset.getString("MEANING");
                                                }
                                                if (db_lookup_line_tax_rate_code_meaning.equals("null")) {
                                                    String lookup_line_tax_rate_code_meaning = ",LINE TAX_RATE_CODE lookup," + "LookUp value not found" + "," + db_STG_LINE_TAX_RATE_CODE + ",Fail";
                                                    section1_results.add(lookup_line_tax_rate_code_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE TAX_RATE_CODE lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_TAX_RATE_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                } else if (db_lookup_line_tax_rate_code_meaning != null) {
                                                    if (db_lookup_line_tax_rate_code_meaning.equals(db_STG_LINE_TAX_RATE_CODE)) {
                                                        String lookup_line_tax_rate_code_meaning = ",LINE TAX_RATE_CODE lookup," + db_lookup_line_tax_rate_code_meaning + "," + db_STG_LINE_TAX_RATE_CODE + ",Pass";
                                                        section1_results.add(lookup_line_tax_rate_code_meaning);
                                                        String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE TAX_RATE_CODE lookup" + "," + db_lookup_line_tax_rate_code_meaning + "," + db_STG_LINE_TAX_RATE_CODE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                        section2_results_tbl.add(tbl_header_id);
                                                    } else {
                                                        String lookup_line_tax_rate_code_meaning = ",LINE TAX_RATE_CODE lookup," + db_lookup_line_tax_rate_code_meaning + "," + db_STG_LINE_TAX_RATE_CODE + ",Fail";
                                                        section1_results.add(lookup_line_tax_rate_code_meaning);
                                                        String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE TAX_RATE_CODE lookup" + "," + db_lookup_line_tax_rate_code_meaning + "," + db_STG_LINE_TAX_RATE_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                        section2_results_tbl.add(tbl_header_id);
                                                        CONS_flag++;
                                                    }
                                                }
                                            } else if (db_STG_LINE_SUBJECT_REV_CHARGE.equals("1")) {

                                                SQLResultset = SQLstmt.executeQuery(BMSAPInvoice_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_CONS_LINE_TAX_CODE + "' and LOOKUP_TYPE = 'TAX_RATE_CODE'" + fsh_source);
                                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_LINE_TAX_CODE + "' and LOOKUP_TYPE = 'TAX_RATE_CODE' and system = 'ECLI' and pattern = 'APInvoice'");
                                                while (SQLResultset.next()) {
                                                    db_lookup_line_tax_rate_code_meaning = SQLResultset.getString("MEANING");
                                                    System.out.println("The meaning of Lookups::" + db_lookup_line_tax_rate_code_meaning);
                                                }
                                                if (db_lookup_line_tax_rate_code_meaning.equals("null")) {
                                                    String lookup_line_tax_rate_code_meaning = ",LINE TAX_RATE_CODE lookup," + "LookUp value not found" + "," + db_STG_LINE_TAX_RATE_CODE + ",Fail";
                                                    section1_results.add(lookup_line_tax_rate_code_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE TAX_RATE_CODE lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_TAX_RATE_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                } else if (db_lookup_line_tax_rate_code_meaning != null) {
                                                    if (db_lookup_line_tax_rate_code_meaning.equals(db_STG_LINE_TAX_RATE_CODE)) {
                                                        String lookup_line_tax_rate_code_meaning = ",LINE TAX_RATE_CODE lookup," + db_lookup_line_tax_rate_code_meaning + "," + db_STG_LINE_TAX_RATE_CODE + ",Pass";
                                                        section1_results.add(lookup_line_tax_rate_code_meaning);
                                                        String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE TAX_RATE_CODE lookup" + "," + db_lookup_line_tax_rate_code_meaning + "," + db_STG_LINE_TAX_RATE_CODE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                        section2_results_tbl.add(tbl_header_id);
                                                    } else {
                                                        String lookup_line_tax_rate_code_meaning = ",LINE TAX_RATE_CODE lookup," + db_lookup_line_tax_rate_code_meaning + "," + db_STG_LINE_TAX_RATE_CODE + ",Fail";
                                                        section1_results.add(lookup_line_tax_rate_code_meaning);
                                                        String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE TAX_RATE_CODE lookup" + "," + db_lookup_line_tax_rate_code_meaning + "," + db_STG_LINE_TAX_RATE_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                        section2_results_tbl.add(tbl_header_id);
                                                        CONS_flag++;
                                                    }
                                                }
                                            } else if (db_STG_LINE_TYPE_LOOKUP_CODE.equals("ITEM")) {
                                                db_lookup_line_tax_rate_code_meaning = null;
                                                System.out.println("The meaning of Lookups::" + db_lookup_line_tax_rate_code_meaning);
                                                String lookup_line_tax_rate_code_meaning = ",LINE TAX_RATE_CODE lookup," + db_lookup_line_tax_rate_code_meaning + "," + db_STG_LINE_TAX_RATE_CODE + ",Pass";
                                                section1_results.add(lookup_line_tax_rate_code_meaning);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE TAX_RATE_CODE lookup" + "," + db_lookup_line_tax_rate_code_meaning + "," + db_STG_LINE_TAX_RATE_CODE + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);

                                            } else {
                                                String lookup_line_tax_rate_code_meaning = ",LINE TAX_RATE_CODE lookup," + db_lookup_line_tax_rate_code_meaning + "," + db_STG_LINE_TAX_RATE_CODE + ",Fail";
                                                section1_results.add(lookup_line_tax_rate_code_meaning);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE TAX_RATE_CODE lookup" + "," + db_lookup_line_tax_rate_code_meaning + "," + db_STG_LINE_TAX_RATE_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            }

                                            //---------------- Validate  LINE_TYPE_LOOKUP_CODE1 -----------------------
                                            if (db_STG_LINE_TYPE_LOOKUP_CODE.equals("TAX")) {
                                                SQLResultset = SQLstmt.executeQuery(BMSAPInvoice_fsh_sys_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'PRORATE_ACROSS_FLAG'" + fsh_source);
                                                //SQLResultset = SQLstmt.executeQuery("SELECT * FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'PRORATE_ACROSS_FLAG' and system = 'ECLI' and pattern = 'APInvoice'");
                                                while (SQLResultset.next()) {
                                                    db_lookup_LINE_TYPE_LOOKUP_CODE1_meaning = SQLResultset.getString("MEANING");
                                                }
                                                if (db_lookup_LINE_TYPE_LOOKUP_CODE1_meaning.equals("null")) {
                                                    String lookup_LINE_TYPE_LOOKUP_CODE1_meaning = ",LINE_TYPE_LOOKUP_CODE1 lookup," + "LookUp value not found" + "," + db_STG_LINE_PRORATE_ACROSS_FLAG + ",Fail";
                                                    section1_results.add(lookup_LINE_TYPE_LOOKUP_CODE1_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_TYPE_LOOKUP_CODE1 lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_PRORATE_ACROSS_FLAG + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                } else if (db_lookup_LINE_TYPE_LOOKUP_CODE1_meaning != null) {
                                                    if (db_lookup_LINE_TYPE_LOOKUP_CODE1_meaning.equals(db_STG_LINE_PRORATE_ACROSS_FLAG)) {
                                                        String lookup_LINE_TYPE_LOOKUP_CODE1_meaning = ",LINE_TYPE_LOOKUP_CODE1 lookup," + db_lookup_LINE_TYPE_LOOKUP_CODE1_meaning + "," + db_STG_LINE_PRORATE_ACROSS_FLAG + ",Pass";
                                                        section1_results.add(lookup_LINE_TYPE_LOOKUP_CODE1_meaning);
                                                        String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_TYPE_LOOKUP_CODE1 lookup" + "," + db_lookup_LINE_TYPE_LOOKUP_CODE1_meaning + "," + db_STG_LINE_PRORATE_ACROSS_FLAG + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                        section2_results_tbl.add(tbl_header_id);
                                                    } else {
                                                        String lookup_LINE_TYPE_LOOKUP_CODE1_meaning = ",LINE_TYPE_LOOKUP_CODE1 lookup," + db_lookup_LINE_TYPE_LOOKUP_CODE1_meaning + "," + db_STG_LINE_PRORATE_ACROSS_FLAG + ",Fail";
                                                        section1_results.add(lookup_LINE_TYPE_LOOKUP_CODE1_meaning);
                                                        String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_TYPE_LOOKUP_CODE1 lookup" + "," + db_lookup_LINE_TYPE_LOOKUP_CODE1_meaning + "," + db_STG_LINE_PRORATE_ACROSS_FLAG + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                        section2_results_tbl.add(tbl_header_id);
                                                        CONS_flag++;
                                                    }
                                                }
                                            } else {
                                                db_lookup_LINE_TYPE_LOOKUP_CODE1_meaning = "null";
                                                System.out.println("The meaning of Lookups::" + db_lookup_LINE_TYPE_LOOKUP_CODE1_meaning);
                                                //db_lookup_LINE_TYPE_LOOKUP_CODE1_meaning.equals(db_STG_LINE_PRORATE_ACROSS_FLAG)
                                                String lookup_LINE_TYPE_LOOKUP_CODE1_meaning = ",LINE_TYPE_LOOKUP_CODE1 lookup," + db_lookup_LINE_TYPE_LOOKUP_CODE1_meaning + "," + db_STG_LINE_PRORATE_ACROSS_FLAG + ",Pass";
                                                section1_results.add(lookup_LINE_TYPE_LOOKUP_CODE1_meaning);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_TYPE_LOOKUP_CODE1 lookup" + "," + db_lookup_LINE_TYPE_LOOKUP_CODE1_meaning + "," + db_STG_LINE_PRORATE_ACROSS_FLAG + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                            }

                                            //---------------- Validate  LINE_TYPE_LOOKUP_CODE2 -----------------------
                                            if (db_STG_LINE_TYPE_LOOKUP_CODE.equals("TAX")) {
                                                SQLResultset = SQLstmt.executeQuery(BMSAPInvoice_fsh_sys_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'AMOUNT_INCLUDES_TAX_FLAG'" + fsh_source);
                                                //SQLResultset = SQLstmt.executeQuery("SELECT * FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'AMOUNT_INCLUDES_TAX_FLAG' and system = 'ECLI' and pattern = 'APInvoice'");
                                                while (SQLResultset.next()) {
                                                    db_lookup_LINE_TYPE_LOOKUP_CODE2_meaning = SQLResultset.getString("MEANING");
                                                }
                                                if (db_lookup_LINE_TYPE_LOOKUP_CODE2_meaning.equals("null")) {
                                                    String lookup_LINE_TYPE_LOOKUP_CODE2_meaning = ",LINE_TYPE_LOOKUP_CODE2 lookup," + "LookUp value not found" + "," + db_STG_LINE_AMOUNT_INCLUDES_TAX_FLAG + ",Fail";
                                                    section1_results.add(lookup_LINE_TYPE_LOOKUP_CODE2_meaning);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_TYPE_LOOKUP_CODE2 lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_AMOUNT_INCLUDES_TAX_FLAG + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                } else if (db_lookup_LINE_TYPE_LOOKUP_CODE2_meaning != null) {
                                                    if (db_lookup_LINE_TYPE_LOOKUP_CODE2_meaning.equals(db_STG_LINE_AMOUNT_INCLUDES_TAX_FLAG)) {
                                                        String lookup_LINE_TYPE_LOOKUP_CODE2_meaning = ",LINE_TYPE_LOOKUP_CODE2 lookup," + db_lookup_LINE_TYPE_LOOKUP_CODE2_meaning + "," + db_STG_LINE_AMOUNT_INCLUDES_TAX_FLAG + ",Pass";
                                                        section1_results.add(lookup_LINE_TYPE_LOOKUP_CODE2_meaning);
                                                        String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_TYPE_LOOKUP_CODE2 lookup" + "," + db_lookup_LINE_TYPE_LOOKUP_CODE2_meaning + "," + db_STG_LINE_AMOUNT_INCLUDES_TAX_FLAG + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                        section2_results_tbl.add(tbl_header_id);
                                                    } else {
                                                        String lookup_LINE_TYPE_LOOKUP_CODE2_meaning = ",LINE_TYPE_LOOKUP_CODE2 lookup," + db_lookup_LINE_TYPE_LOOKUP_CODE2_meaning + "," + db_STG_LINE_AMOUNT_INCLUDES_TAX_FLAG + ",Fail";
                                                        section1_results.add(lookup_LINE_TYPE_LOOKUP_CODE2_meaning);
                                                        String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_TYPE_LOOKUP_CODE2 lookup" + "," + db_lookup_LINE_TYPE_LOOKUP_CODE2_meaning + "," + db_STG_LINE_AMOUNT_INCLUDES_TAX_FLAG + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                        section2_results_tbl.add(tbl_header_id);
                                                        CONS_flag++;
                                                    }
                                                }
                                            } else {
                                                db_lookup_LINE_TYPE_LOOKUP_CODE2_meaning = "null";
                                                System.out.println("The meaning of Lookups::" + db_lookup_LINE_TYPE_LOOKUP_CODE2_meaning);
                                                //db_lookup_LINE_TYPE_LOOKUP_CODE2_meaning.equals(db_STG_LINE_AMOUNT_INCLUDES_TAX_FLAG)
                                                String lookup_LINE_TYPE_LOOKUP_CODE2_meaning = ",LINE_TYPE_LOOKUP_CODE2 lookup," + db_lookup_LINE_TYPE_LOOKUP_CODE2_meaning + "," + db_STG_LINE_AMOUNT_INCLUDES_TAX_FLAG + ",Pass";
                                                section1_results.add(lookup_LINE_TYPE_LOOKUP_CODE2_meaning);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_TYPE_LOOKUP_CODE2 lookup" + "," + db_lookup_LINE_TYPE_LOOKUP_CODE2_meaning + "," + db_STG_LINE_AMOUNT_INCLUDES_TAX_FLAG + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);

                                            }

                                            //---------------- Validate  LINE_SEGMENT1_to_SGMENT10  -----------------------
                                            String LINE_SEGMENT1ToSGMENT10 = (db_STG_LINE_SEGMENT1 + "." + db_STG_LINE_SEGMENT2 + "." + db_STG_LINE_SEGMENT3 + "." + db_STG_LINE_SEGMENT4 + "." + db_STG_LINE_SEGMENT5 + "." + db_STG_LINE_SEGMENT6 + "." + db_STG_LINE_SEGMENT7 + "." + db_STG_LINE_SEGMENT8 + "." + db_STG_LINE_SEGMENT9 + "." + db_STG_LINE_SEGMENT10);

                                            if (LINE_SEGMENT1ToSGMENT10.equals("null")) {
                                                String lookup_LINE_SEGMENT1ToSGMENT10 = ",LINE_SEGMENT1_to_SGMENT10 lookup," + "LookUp value not found" + "," + db_STG_LINE_DIST_CODE_CONCATENATED + ",Fail";
                                                section1_results.add(lookup_LINE_SEGMENT1ToSGMENT10);
                                                String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_SEGMENT1_to_SGMENT10 lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_DIST_CODE_CONCATENATED + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                section2_results_tbl.add(tbl_header_id);
                                                CONS_flag++;
                                            } else if (LINE_SEGMENT1ToSGMENT10 != null) {
                                                if (LINE_SEGMENT1ToSGMENT10.equals(db_STG_LINE_DIST_CODE_CONCATENATED)) {
                                                    String lookup_LINE_SEGMENT1ToSGMENT10 = ",LINE_SEGMENT1_to_SGMENT10 lookup," + LINE_SEGMENT1ToSGMENT10 + "," + db_STG_LINE_DIST_CODE_CONCATENATED + ",Pass";
                                                    section1_results.add(lookup_LINE_SEGMENT1ToSGMENT10);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_SEGMENT1_to_SGMENT10 lookup" + "," + LINE_SEGMENT1ToSGMENT10 + "," + db_STG_LINE_DIST_CODE_CONCATENATED + ",Pass" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                } else {
                                                    String lookup_LINE_SEGMENT1ToSGMENT10 = ",LINE_SEGMENT1_to_SGMENT10 lookup," + LINE_SEGMENT1ToSGMENT10 + "," + db_STG_LINE_DIST_CODE_CONCATENATED + ",Fail";
                                                    section1_results.add(lookup_LINE_SEGMENT1ToSGMENT10);
                                                    String tbl_header_id = tbl_line + "," + line + "," + Source + "," + pattern + ",LINE_SEGMENT1_to_SGMENT10 lookup" + "," + LINE_SEGMENT1ToSGMENT10 + "," + db_STG_LINE_DIST_CODE_CONCATENATED + ",Fail" + "," + load_dateFormat + "," + db_file_name + "," + btc_BATCH_PKEY;
                                                    section2_results_tbl.add(tbl_header_id);
                                                    CONS_flag++;
                                                }
                                            }


                                        }


                                    }

                                }


                            }

                        }
                    }
                }

                //----------------- Validate the Over all Status -------------------
                System.out.println("Looping ++  CONS_flag " + CONS_flag);
                String Overall_status = null;
                String Overall_stg_status = null;
                if (CONS_flag > 0) {
                    CONS_STATUS.add("Fail");
                    Overall_status = "Fail";
                } else {
                    CONS_STATUS.add("Pass");
                    Overall_status = "Pass";
                }


                if (CONS_flag > 0) {
                    OverAllStatus.add("Fail");
                } else {
                    OverAllStatus.add("Pass");
                }

                String tbl_summary_filelist = Source + "," + pattern + "," + file_name + "," + "CONS TO STG " + "," + load_date + "," + OverAllStatus + "," + btc_BATCH_PKEY;
                //String tbl_summary_filelist = Source + "," + pattern + "," + file_name + "," + load_dateFormat + "," + "CONST TO STG " + "," + OverAllStatus;
                summary_results_tbl.add(tbl_summary_filelist);

                list.addAll(section1_results);
                list.addAll(section2_results);
                list.addAll(section3_results);
                list.addAll(section4_results);

                // ---------------- HTML Report generation ------------------------
                report_generation.report_Test1(section1_results, "Header", xml_file_name, "CONSOLIDATION LAYER - STAGING LAYER", "BMS_AP_Invoice", "BMS_AP_Invoice : CONSOLIDATION LAYER - STAGING AGGREGATE LAYER", "");
                report_generation.report_Test1(section1_results, "Section2", xml_file_name, "CONSOLIDATION LAYER - STAGING LAYER", "BMS_AP_Invoice", "BMS_AP_Invoice  : CONSOLIDATION LAYER - STAGING AGGREGATE LAYER", "");
                report_generation.report_Test1(section2_results, "Mandatory", xml_file_name, "Manadatory_Check_CONS", "BMS_AP_Invoice", "BMS_AP_Invoice  : CONSOLIDATION LAYER - STAGING AGGREGATE LAYER", "");
                report_generation.report_Test1(section4_results, "Mandatory", xml_file_name, "Manadatory_Check_STG", "BMS_AP_Invoice", "BMS_AP_Invoice  : CONSOLIDATION LAYER - STAGING AGGREGATE LAYER", "");
                report_generation.report_Test1(section3_results, "Section3", xml_file_name, "STAGING TO AGGREGATE LAYER", "BMS_AP_Invoice", "BMS_AP_Invoice  : CONSOLIDATION LAYER - STAGING AGGREGATE LAYER", "");


                table_detail_report.detail_report_tbl(section2_results_tbl);
            }
            state_model.section_method(file_list, CONS_STATUS, "N/A", OverAllStatus, "BMS_APInvoice_Summary");
            table_summary_report.summary_report_tbl(summary_results_tbl);
        }


    }

}
