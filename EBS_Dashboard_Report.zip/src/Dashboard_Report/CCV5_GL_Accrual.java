package Dashboard_Report;

import org.json.JSONException;

import java.io.IOException;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class CCV5_GL_Accrual {

    static Statement SQLstmt = null;
    static ResultSet SQLResultset = null;


    public static HTML_Report_Generation_DB_EVO report_generation;
    public static HTML_Report_Generation_State_Model_B4C report_generation_state;
    public static SCH_EVO_PC_State_Model_B4C state_model;

    public static Table_Detail_Report table_detail_report;
    public static Table_Summary_Report table_summary_report;
    public static connectDatabase connect_db;

    public static void main(String[] args) throws IOException, SQLException, JSONException {
        report_generation = new HTML_Report_Generation_DB_EVO();
        report_generation_state = new HTML_Report_Generation_State_Model_B4C();
        state_model = new SCH_EVO_PC_State_Model_B4C();

        table_detail_report = new Table_Detail_Report();
        table_summary_report = new Table_Summary_Report();
        connect_db = new connectDatabase();


        //----------------------- delete the existing report --------------
        report_generation.clean_report("CCV5_GLAccrual.html");
        report_generation_state.clean_report_summary("CCV5_GLAccrual_Summary.html");

        /*//--------------- SIT  database details -------------------
        String URL_SIT1 = "jdbc:oracle:thin:@dbs119dev.gwd.grpinf.net:1521/FSHDTST3";
        String Username_SIT1 = "FSH_ORA_DATA";
        String password_SIT1 = "Development_Test3";*/

        //--------------- SIT  database details -------------------
        String URL_SIT1 = "jdbc:oracle:thin:@dcn2dcll11z:1521/FSHTSIT1.gwd.grpinf.net";
        String Username_SIT1 = "FSH_ORA_DATA";
        String password_SIT1 = "vMw5HpJaFy3uD6eW";

        //--------------- EBS  database details -------------------
        String URL_ICSI = "jdbc:oracle:thin:@dcn2ddbx340.gwd.grpinf.net:1618:ICSI";
        String Username_ICSI = "apps";
        String password_ICSI = "apps4icsi";

        List<String> file_list = new ArrayList<String>();
        List<String> list = new ArrayList<String>();
        List<String> section1_results = new ArrayList<String>();
        /*List<String> section2_results = new ArrayList<String>();
        List<String> section3_results = new ArrayList<String>();*/
        List<String> section4_results = new ArrayList<String>();

        List<String> OverAllStatus = new ArrayList<String>();
        List<String> CONS_STATUS = new ArrayList<String>();
        List<String> summary_results_tbl = new ArrayList<String>();

        String[] file_lists = null;
        int section1_map_row = 1;

        //--------------------- Decelaring the supporting details for reporting --------------
        String file_name = "null";
        String Source = "ECLI";
        String pattern = "GLAccrual";
        String header = "Header";

        //---- Initialiing row count variables -----
        int cons_stg_map_row = 1;
        int stg_line_map_row = 1;
        int mandatoryCONS_map_row = 1;
        int mandatorySTG_map_row = 1;


        String btc_BATCH_PKEY = "null";
        String db_cons_header_id = "null";
        String db_CONS_JOB_NUMBER = "null";
        String db_CONS_SOURCE = "null";
        String db_CONS_INSURER_NAME = "null";
        String db_CONS_LOCATION = "null";
        String db_CONS_REPORT_DATE = "null";
        String db_CONS_PARTS_COST = "null";
        String db_CONS_TURNED_WIP_DATE = "null";
        String db_CONS_FILE_NAME = "null";
        String db_CONS_HDR_STATUS = "null";
        String load_date = null;
        Date load_dateFormat = null;


        String db_STG_HEADER_ID = "null";
        String db_STG_SOURCE = "null";
        String db_STG_UNDERWRITER = "null";
        String db_STG_LOCATION = "null";
        String db_STG_CHANNEL = "null";
        String db_STG_TRANSACTION_DATE = "null";
        String db_STG_TRANSACTION_AMOUNT = "null";
        String db_STG_BASE_CURRENCY_AMOUNT = "null";
        String db_STG_FSH_ATTRIBUTE_01 = "null";
        String db_STG_FILE_NAME = "null";
        String db_STG_LOSS_DATE = "null";
        String db_STG_SOURCE_EVENT_ID = "null";
        String db_STG_BRAND = "null";
        String db_STG_PRODUCT = "null";
        String db_STG_PRODUCT_TYPE = "null";
        String db_STG_CURRENCY_CODE = "null";
        String db_STG_EXCHANGE_RATE = "null";
        String db_STG_EXCHANGE_RATE_TYPE = "null";
        String db_STG_CLAIM_NUMBER = "null";
        String db_STG_EVENT_CODE = "null";
        String db_STG_ENTITY_TYPE_CODE = "null";
        String db_STG_RESERVES_FLAG = "null";
        String db_STG_PRODUCT_KEY = "null";
        String db_STG_LINE_OF_BUSINESS = "null";
        String db_STG_POLICY_NUMBER = "null";
        String db_STG_SUMMARY_FLAG = "null";
        String db_STG_HDR_STATUS = "null";

        String xmlfile_name = "null";
        String xml_file_name1 = null;


        //-------- Connect to Database --------------
        connect_db.createConnection("SIT2");
        //table_detail_report.detail_report_tbl_delete(connection, Source);


        //------ get the new file from batch control table --------------
        boolean newRecord = true;
        String outSQL = connect_db.executeQuery_DB("BATCH", "GLAccrual_batchCtl", "BMS");
        SQLstmt = connect_db.resStatement();

        SQLResultset = SQLstmt.executeQuery(outSQL);
        while (SQLResultset.next()) {
            file_list.add(SQLResultset.getString("FILE_NAME"));
            System.out.println("File name---" + SQLResultset.getString("FILE_NAME"));
            list.addAll(section1_results);
        }


        // ---------------------------------- Get the batch PKEY ----------------------
        String outSQL_bkey = connect_db.executeQuery_DB("BATCH", "GLAccrual_batchCtl_key", "BMS");

        SQLResultset = SQLstmt.executeQuery(outSQL_bkey);
        while (SQLResultset.next()) {
            btc_BATCH_PKEY = SQLResultset.getString("BATCH_PKEY");
        }

        // ---------------------------------- Check the new file ----------------------
        SQLResultset = SQLstmt.executeQuery(outSQL);
        if (!SQLResultset.next()) {
            System.out.println("No new BMS_GLAccrual files have been received to FSH ");
            newRecord = false;
            String nonewfile = ",FILE_NAME," + "No new BMS_GLAccrual files have been received to FSH" + "," + "," + ",Pass";
            section1_results.add(nonewfile);
            list.addAll(section1_results);
        }


        if (newRecord) {

            //------------------------ Section 1 Start Print all the new file in the report-------------------
            for (String num_file : file_list) {
                file_lists = num_file.split(",");
                for (String file_list1 : file_lists) {
                    xml_file_name1 = file_list1;
                    //int section1_map_row = 1;
                    String newfile = section1_map_row + ",FILE_NAME," + xml_file_name1 + "," + xml_file_name1 + ",Pass";
                    section1_map_row++;
                    section1_results.add(newfile);
                }
            }
            list.addAll(section1_results);
            //report_generation.report_Test1(section1_results, "Section1", xml_file_name1, "B4C BC CONS BATCH TABLE VALIDATION", "B4C_SCHBilling", "B4C BC VALIDATION");
            //------------------------ Section 1 End ----------------------------------------------
        }

        List<String> list_header = new ArrayList<String>(); // -- Add all the header id
        if (newRecord) {
            //------------ Split the file names form the list --------------
            for (String xml_file_name : file_list) {
                int section2_map_row = 1;
                int CONS_flag = 0;
                List<String> section2_results = new ArrayList<String>();
                List<String> section3_results = new ArrayList<String>();
                List<String> section2_results_tbl = new ArrayList<String>();

                file_name = xml_file_name;

                //--------------------------------- Staging to Staging Aggregate Validations ---------------------------------//
                //----------------------------------Count Validations---------------------------------------------------------//
                boolean sec3flag = true;
                String db_STG_ACTL_RCDS = null;
                Integer db_STG_ACTL_RCDS1 = 0;
                SQLResultset = SQLstmt.executeQuery("SELECT COUNT(CC_HEADER_ID) as STG_ACTL_RCDS FROM DLG_FSH_STG_COMM_CC_HDR WHERE FILE_NAME = '" + xml_file_name + "'");
                while (SQLResultset.next()) {
                    db_STG_ACTL_RCDS = SQLResultset.getString("STG_ACTL_RCDS");
                    db_STG_ACTL_RCDS1 = SQLResultset.getInt("STG_ACTL_RCDS");
                    System.out.println("Staging count ----" + db_STG_ACTL_RCDS);
                }
                if (db_STG_ACTL_RCDS1 == 0) {  //--- Zero record validation
                    sec3flag = false;
                    String pc_stg_header_line = 1 + "," + "STG_ACTL_RCDS DB Does not have any records" + "," + "STG_ACTL_RCDS DB Does not have any records" + "," + "STG_AGG_ACTUAL_HEADER DB Does not have any records" + ",Fail";
                    section3_results.add(pc_stg_header_line);
                }

                SQLResultset = SQLstmt.executeQuery("SELECT * FROM DLG_FSH_STG_COMM_CC_HDR WHERE FILE_NAME = '" + xml_file_name + "'");
                while (SQLResultset.next()) {
                    db_STG_SUMMARY_FLAG = SQLResultset.getString("SUMMARY_FLAG");
                }

                if (sec3flag) {
                    do {
                        SQLResultset = SQLstmt.executeQuery("SELECT COUNT(a.CC_HEADER_ID) as STG_EXP_SUM_HDRS \n" +
                                "FROM(\n" +
                                "SELECt CC_HEADER_ID,STATUS,\n" +
                                "row_number() over(partition by SOURCE,SOURCE_EVENT_ID,UNDERWRITER,BRAND,PRODUCT_TYPE,PRODUCT,CHANNEL,TRANSACTION_DATE,CURRENCY_CODE,EXCHANGE_RATE,EXCHANGE_RATE_TYPE,EVENT_CODE,ENTITY_TYPE_CODE,RESERVES_FLAG,PRODUCT_KEY,BATCH_FKEY,LINE_OF_BUSINESS,SUMMARY_FLAG,LOSS_DATE,LOCATION\n" +
                                "ORDER BY SOURCE,SOURCE_EVENT_ID,UNDERWRITER,BRAND,PRODUCT_TYPE,PRODUCT,CHANNEL,TRANSACTION_DATE,CURRENCY_CODE,EXCHANGE_RATE,EXCHANGE_RATE_TYPE,EVENT_CODE,ENTITY_TYPE_CODE,RESERVES_FLAG,PRODUCT_KEY,BATCH_FKEY,LINE_OF_BUSINESS,SUMMARY_FLAG,LOSS_DATE,LOCATION) row_1\n" +
                                "FROM FSH_ORA_DATA.DLG_FSH_STG_COMM_CC_HDR WHERE FILE_NAME = '" + xml_file_name + "')a \n" +
                                "where a.row_1 = 1\n" +
                                "AND a.STATUS = 'COMPLETE'");

                        while (SQLResultset.next()) {
                            String STG_EXP_SUM_HDRS = SQLResultset.getString("STG_EXP_SUM_HDRS");
                            SQLResultset = SQLstmt.executeQuery("SELECT count(TOH_ID)as STG_AGG_ACTUAL_HEADER FROM DLG_FSH_STG_COMM_CC_AGG_HDR WHERE FILE_NAME = '" + xml_file_name + "'");
                            while (SQLResultset.next()) {
                                String STG_AGG_ACTUAL_HEADER = SQLResultset.getString("STG_AGG_ACTUAL_HEADER");
                                System.out.println("Staging Aggregate header count ----" + STG_AGG_ACTUAL_HEADER);
                                if (db_STG_SUMMARY_FLAG.equals("Y")) {
                                    if (STG_EXP_SUM_HDRS.equals(STG_AGG_ACTUAL_HEADER)) {
                                        String pc_stg_header_line = 1 + "," + db_STG_ACTL_RCDS + "," + STG_EXP_SUM_HDRS + "," + STG_AGG_ACTUAL_HEADER + ",Pass";
                                        section3_results.add(pc_stg_header_line);
                                    } else {
                                        String pc_stg_header_line = 1 + "," + db_STG_ACTL_RCDS + "," + STG_EXP_SUM_HDRS + "," + STG_AGG_ACTUAL_HEADER + ",Fail";
                                        section3_results.add(pc_stg_header_line);
                                    }
                                } else if (db_STG_SUMMARY_FLAG.equals("N")) {
                                    if (db_STG_ACTL_RCDS.equals(STG_AGG_ACTUAL_HEADER)) {
                                        String pc_stg_header_line = 1 + "," + db_STG_ACTL_RCDS + "," + db_STG_ACTL_RCDS + "," + STG_AGG_ACTUAL_HEADER + ",Pass";
                                        section3_results.add(pc_stg_header_line);
                                    } else {
                                        String pc_stg_header_line = 1 + "," + db_STG_ACTL_RCDS + "," + db_STG_ACTL_RCDS + "," + STG_AGG_ACTUAL_HEADER + ",Fail";
                                        section3_results.add(pc_stg_header_line);
                                    }

                                }
                            }
                        }

                    } while (SQLResultset.next());
                }

                //-------------- Validation Cons to Stag table ----------------
                String BMSGLAccrual_consSqlQuery = connect_db.executeQuery_DB("CCV5_GL", "GLAccrual_Cons","CCV5");
                SQLResultset = SQLstmt.executeQuery(BMSGLAccrual_consSqlQuery + "'"+file_name+ "'" );
                //SQLResultset = SQLstmt.executeQuery("SELECT * from DLG_FSH_CONS_ECLI_GL_ACC_HDR WHERE FILE_NAME = '" + xml_file_name + "'");
                while (SQLResultset.next()) {
                    db_CONS_JOB_NUMBER = SQLResultset.getString("JOB_NUMBER");
                    list_header.add(db_CONS_JOB_NUMBER);
                }

                for (int i = 0; i < list_header.size(); i++) {
                    SQLResultset = SQLstmt.executeQuery(BMSGLAccrual_consSqlQuery + "'"+file_name+ "' and JOB_NUMBER = '" + list_header.get(i) + "' " );
                    //SQLResultset = SQLstmt.executeQuery("SELECT * from DLG_FSH_CONS_ECLI_GL_ACC_HDR WHERE FILE_NAME = '" + xml_file_name + "' and JOB_NUMBER ='" + list_header.get(i) + "'");
                    while (SQLResultset.next()) {
                        db_CONS_JOB_NUMBER = SQLResultset.getString("JOB_NUMBER");
                        db_CONS_SOURCE = SQLResultset.getString("SOURCE");
                        db_CONS_INSURER_NAME = SQLResultset.getString("INSURER_NAME");
                        db_CONS_LOCATION = SQLResultset.getString("LOCATION");
                        db_CONS_REPORT_DATE = SQLResultset.getString("REPORT_DATE");
                        db_CONS_PARTS_COST = SQLResultset.getString("PARTS_COST");
                        db_CONS_TURNED_WIP_DATE = SQLResultset.getString("TURNED_WIP_DATE");
                        db_CONS_HDR_STATUS = SQLResultset.getString("STATUS");
                        load_date = SQLResultset.getString("LOAD_DATE");
                        String db_file_name = SQLResultset.getString("FILE_NAME");

                        //Converting Load date format
                        String load_dateTRIM = load_date.substring(0, 10);
                        load_dateFormat = Date.valueOf(load_dateTRIM);
                        System.out.println(load_dateFormat);

                        //Validating mandatory fields in consolidation table
                        //JOB_NUMBER - mandatory validation
                        if ((db_CONS_JOB_NUMBER == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_JOB_NUMBER = mandatoryCONS_map_row + "," + db_CONS_JOB_NUMBER + ",JOB_NUMBER," + "JOB_NUMBER : " + db_CONS_JOB_NUMBER + "," + "JOB_NUMBER was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_JOB_NUMBER);
                            mandatoryCONS_map_row++;
                        } else {
                            String CONS_JOB_NUMBER = mandatoryCONS_map_row + "," + db_CONS_JOB_NUMBER + ",JOB_NUMBER," + "JOB_NUMBER : " + db_CONS_JOB_NUMBER + "," + "JOB_NUMBER was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_JOB_NUMBER);
                            mandatoryCONS_map_row++;
                        }

                        //SOURCE - mandatory validation
                        if ((db_CONS_SOURCE == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_SOURCE = "," + ",SOURCE," + "SOURCE : " + db_CONS_SOURCE + "," + "SOURCE was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_SOURCE);
                        } else {
                            String CONS_SOURCE = "," + ",SOURCE," + "SOURCE : " + db_CONS_SOURCE + "," + "SOURCE was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_SOURCE);
                        }

                        //INSURER_NAME - mandatory validation
                        if ((db_CONS_INSURER_NAME == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_INSURER_NAME = "," +  ",INSURER_NAME," + "INSURER_NAME : " + db_CONS_INSURER_NAME + "," + "INSURER_NAME was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_INSURER_NAME);
                        } else {
                            String CONS_INSURER_NAME = "," + ",INSURER_NAME," + "INSURER_NAME : " + db_CONS_INSURER_NAME + "," + "INSURER_NAME was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_INSURER_NAME);
                        }

                        //LOCATION - mandatory validation
                        if ((db_CONS_LOCATION == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_CLAIM_NUMBER = "," + ",LOCATION," + "LOCATION : " + db_CONS_LOCATION + "," + "LOCATION was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_CLAIM_NUMBER);
                        } else {
                            String CONS_CLAIM_NUMBER = "," + ",LOCATION," + "LOCATION : " + db_CONS_LOCATION + "," + "LOCATION was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_CLAIM_NUMBER);
                        }

                        //REPORT_DATE - mandatory validation
                        if ((db_CONS_REPORT_DATE == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_REPORT_DATE = "," + ",REPORT_DATE," + "REPORT_DATE : " + db_CONS_REPORT_DATE + "," + "REPORT_DATE was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_REPORT_DATE);
                        } else {
                            String CONS_REPORT_DATE = "," + ",REPORT_DATE," + "REPORT_DATE : " + db_CONS_REPORT_DATE + "," + "REPORT_DATE was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_REPORT_DATE);
                        }

                        //PARTS_COST - mandatory validation
                        if ((db_CONS_PARTS_COST == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_PARTS_COST = "," + ",PARTS_COST," + "PARTS_COST : " + db_CONS_PARTS_COST + "," + "PARTS_COST was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_PARTS_COST);
                        } else {
                            String CONS_PARTS_COST = "," + ",PARTS_COST," + "PARTS_COST : " + db_CONS_PARTS_COST + "," + "PARTS_COST was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_PARTS_COST);
                        }

                        //TURNED_WIP_DATE - mandatory validation
                        if ((db_CONS_TURNED_WIP_DATE == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_TURNED_WIP_DATE = "," + ",TURNED_WIP_DATE," + "TURNED_WIP_DATE : " + db_CONS_TURNED_WIP_DATE + "," + "TURNED_WIP_DATE was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_TURNED_WIP_DATE);
                        } else {
                            String CONS_TURNED_WIP_DATE = "," + ",TURNED_WIP_DATE," + "TURNED_WIP_DATE : " + db_CONS_TURNED_WIP_DATE + "," + "TURNED_WIP_DATE was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_TURNED_WIP_DATE);
                        }

                        //FILE_NAME - mandatory validation
                        if ((db_CONS_FILE_NAME == null) && (db_CONS_HDR_STATUS != "REVIEW")) {

                            String CONS_PARTS_COST = "," + ",FILE_NAME," + "FILE_NAME : " + db_CONS_FILE_NAME + "," + "FILE_NAME was not found," + db_CONS_HDR_STATUS + "," + "Fail";
                            section2_results.add(CONS_PARTS_COST);
                        } else {
                            String CONS_PARTS_COST = "," + ",FILE_NAME," + "FILE_NAME : " + db_CONS_FILE_NAME + "," + "FILE_NAME was found," + db_CONS_HDR_STATUS + "," + "Pass";
                            section2_results.add(CONS_PARTS_COST);
                        }

                        //------------------- Consolidation to Staging ----------------------------------
                        String BMSGLAccrual_stgSqlQuery = connect_db.executeQuery_DB("CCV5_GL", "GLAccrual_Stg","CCV5");

                        SQLResultset = SQLstmt.executeQuery(BMSGLAccrual_stgSqlQuery + "'"+file_name+ "' and CC_HEADER_ID = '" + list_header.get(i) + "' " );
                        if (!SQLResultset.next()) {
                            String stg_header_id = section2_map_row + ",HEADER_ID," + "no records available in STG table" + "," + db_CONS_JOB_NUMBER + ",Fail";
                            section2_results.add(stg_header_id);
                        } else {
                            SQLResultset = SQLstmt.executeQuery(BMSGLAccrual_stgSqlQuery + "'"+file_name+ "' and CC_HEADER_ID = '" + list_header.get(i) + "' " );
                            while (SQLResultset.next()) {
                        /*SQLResultset = SQLstmt.executeQuery("SELECT * from DLG_FSH_STG_COMM_CC_HDR WHERE FILE_NAME = '" + xml_file_name + "' and CC_HEADER_ID ='" + list_header.get(i) + "'");
                        while (SQLResultset.next()) {*/
                            db_STG_HEADER_ID = SQLResultset.getString("CC_HEADER_ID");
                            db_STG_SOURCE = SQLResultset.getString("SOURCE");
                            db_STG_UNDERWRITER = SQLResultset.getString("UNDERWRITER");
                            db_STG_LOCATION = SQLResultset.getString("LOCATION");
                            db_STG_CHANNEL = SQLResultset.getString("CHANNEL");
                            db_STG_TRANSACTION_DATE = SQLResultset.getString("TRANSACTION_DATE");
                            db_STG_TRANSACTION_AMOUNT = SQLResultset.getString("TRANSACTION_AMOUNT");
                            db_STG_BASE_CURRENCY_AMOUNT = SQLResultset.getString("BASE_CURRENCY_AMOUNT");
                            db_STG_FSH_ATTRIBUTE_01 = SQLResultset.getString("FSH_ATTRIBUTE_01");
                            db_STG_FILE_NAME = SQLResultset.getString("FILE_NAME");
                            db_STG_LOSS_DATE = SQLResultset.getString("LOSS_DATE");
                            db_STG_SOURCE_EVENT_ID = SQLResultset.getString("SOURCE_EVENT_ID");
                            db_STG_BRAND = SQLResultset.getString("BRAND");
                            db_STG_PRODUCT = SQLResultset.getString("PRODUCT");
                            db_STG_PRODUCT_TYPE = SQLResultset.getString("PRODUCT_TYPE");
                            db_STG_CURRENCY_CODE = SQLResultset.getString("CURRENCY_CODE");
                            db_STG_EXCHANGE_RATE = SQLResultset.getString("EXCHANGE_RATE");
                            db_STG_EXCHANGE_RATE_TYPE = SQLResultset.getString("EXCHANGE_RATE_TYPE");
                            db_STG_CLAIM_NUMBER = SQLResultset.getString("CLAIM_NUMBER");
                            db_STG_EVENT_CODE = SQLResultset.getString("EVENT_CODE");
                            db_STG_ENTITY_TYPE_CODE = SQLResultset.getString("ENTITY_TYPE_CODE");
                            db_STG_RESERVES_FLAG = SQLResultset.getString("RESERVES_FLAG");
                            db_STG_PRODUCT_KEY = SQLResultset.getString("PRODUCT_KEY");
                            db_STG_LINE_OF_BUSINESS = SQLResultset.getString("LINE_OF_BUSINESS");
                            db_STG_POLICY_NUMBER = SQLResultset.getString("POLICY_NUMBER");
                            db_STG_SUMMARY_FLAG = SQLResultset.getString("SUMMARY_FLAG");
                            db_STG_HDR_STATUS = SQLResultset.getString("STATUS");


                            //Validating mandatory fields in Staging table - Bus val mandatory check
                            //CC_HEADER_ID - mandatory validation
                            if ((db_STG_HEADER_ID == null) && (db_STG_HDR_STATUS != "REVIEW")) {

                                String STG_HEADER_ID = mandatoryCONS_map_row + "," + db_STG_HEADER_ID + ",CC_HEADER_ID," + "CC_HEADER_ID : " + db_STG_HEADER_ID + "," + "CC_HEADER_ID was not found," + db_STG_HDR_STATUS + "," + "Fail";
                                section4_results.add(STG_HEADER_ID);
                                mandatorySTG_map_row++;
                            } else {
                                String STG_HEADER_ID = mandatoryCONS_map_row + "," + db_STG_HEADER_ID + ",CC_HEADER_ID," + "CC_HEADER_ID : " + db_STG_HEADER_ID + "," + "CC_HEADER_ID was found," + db_STG_HDR_STATUS + "," + "Pass";
                                section4_results.add(STG_HEADER_ID);
                                mandatorySTG_map_row++;
                            }

                            //SOURCE - mandatory validation
                            if ((db_STG_SOURCE == null) && (db_STG_HDR_STATUS != "REVIEW")) {

                                String STG_SOURCE = "," + ",SOURCE," + "SOURCE : " + db_STG_SOURCE + "," + "SOURCE was not found," + db_STG_HDR_STATUS + "," + "Fail";
                                section4_results.add(STG_SOURCE);
                            } else {
                                String STG_SOURCE = "," + ",SOURCE," + "SOURCE : " + db_STG_SOURCE + "," + "SOURCE was found," + db_STG_HDR_STATUS + "," + "Pass";
                                section4_results.add(STG_SOURCE);
                            }

                            //SOURCE_EVENT_ID - mandatory validation
                            if ((db_STG_SOURCE_EVENT_ID == null) && (db_STG_HDR_STATUS != "REVIEW")) {

                                String STG_SOURCE_EVENT_ID = ","  +  ",SOURCE_EVENT_ID," + "SOURCE_EVENT_ID : " + db_STG_SOURCE_EVENT_ID + "," + "SOURCE_EVENT_ID was not found," + db_STG_HDR_STATUS + "," + "Fail";
                                section4_results.add(STG_SOURCE_EVENT_ID);
                            } else {
                                String STG_SOURCE_EVENT_ID = ","  +  ",SOURCE_EVENT_ID," + "SOURCE_EVENT_ID : " + db_STG_SOURCE_EVENT_ID + "," + "SOURCE_EVENT_ID was found," + db_STG_HDR_STATUS + "," + "Pass";
                                section4_results.add(STG_SOURCE_EVENT_ID);
                            }

                            //UNDERWRITER - mandatory validation
                            if ((db_STG_UNDERWRITER == null) && (db_STG_HDR_STATUS != "REVIEW")) {

                                String STG_UNDERWRITER = ","  +  ",UNDERWRITER," + "UNDERWRITER : " + db_STG_UNDERWRITER + "," + "UNDERWRITER was not found," + db_STG_HDR_STATUS + "," + "Fail";
                                section4_results.add(STG_UNDERWRITER);
                            } else {
                                String STG_UNDERWRITER = ","  +  ",UNDERWRITER," + "UNDERWRITER : " + db_STG_UNDERWRITER + "," + "UNDERWRITER was found," + db_STG_HDR_STATUS + "," + "Pass";
                                section4_results.add(STG_UNDERWRITER);
                            }

                            //BRAND - mandatory validation
                            if ((db_STG_BRAND == null) && (db_STG_HDR_STATUS != "REVIEW")) {

                                String STG_BRAND = ","  +  ",BRAND," + "BRAND : " + db_STG_BRAND + "," + "BRAND was not found," + db_STG_HDR_STATUS + "," + "Fail";
                                section4_results.add(STG_BRAND);
                            } else {
                                String STG_BRAND = ","  +  ",BRAND," + "BRAND : " + db_STG_BRAND + "," + "BRAND was found," + db_STG_HDR_STATUS + "," + "Pass";
                                section4_results.add(STG_BRAND);
                            }

                            //PRODUCT - mandatory validation
                            if ((db_STG_PRODUCT == null) && (db_STG_HDR_STATUS != "REVIEW")) {

                                String STG_PRODUCT = ","  +  ",PRODUCT," + "PRODUCT : " + db_STG_PRODUCT + "," + "PRODUCT was not found," + db_STG_HDR_STATUS + "," + "Fail";
                                section4_results.add(STG_PRODUCT);
                            } else {
                                String STG_PRODUCT = ","  +  ",PRODUCT," + "PRODUCT : " + db_STG_PRODUCT + "," + "PRODUCT was found," + db_STG_HDR_STATUS + "," + "Pass";
                                section4_results.add(STG_PRODUCT);
                            }

                            //PRODUCT_TYPE - mandatory validation
                            if ((db_STG_PRODUCT_TYPE == null) && (db_STG_HDR_STATUS != "REVIEW")) {

                                String STG_PRODUCT_TYPE = ","  +  ",PRODUCT_TYPE," + "PRODUCT_TYPE : " + db_STG_PRODUCT_TYPE + "," + "PRODUCT_TYPE was not found," + db_STG_HDR_STATUS + "," + "Fail";
                                section4_results.add(STG_PRODUCT_TYPE);
                            } else {
                                String STG_PRODUCT_TYPE = ","  +  ",PRODUCT_TYPE," + "PRODUCT_TYPE : " + db_STG_PRODUCT_TYPE + "," + "PRODUCT_TYPE was found," + db_STG_HDR_STATUS + "," + "Pass";
                                section4_results.add(STG_PRODUCT_TYPE);
                            }

                            //CHANNEL - mandatory validation
                            if ((db_STG_CHANNEL == null) && (db_STG_HDR_STATUS != "REVIEW")) {

                                String STG_CHANNEL = ","  +  ",CHANNEL," + "CHANNEL : " + db_STG_CHANNEL + "," + "CHANNEL was not found," + db_STG_HDR_STATUS + "," + "Fail";
                                section4_results.add(STG_CHANNEL);
                            } else {
                                String STG_CHANNEL = ","  +  ",CHANNEL," + "CHANNEL : " + db_STG_CHANNEL + "," + "CHANNEL was found," + db_STG_HDR_STATUS + "," + "Pass";
                                section4_results.add(STG_CHANNEL);
                            }

                            //TRANSACTION_DATE - mandatory validation
                            if ((db_STG_TRANSACTION_DATE == null) && (db_STG_HDR_STATUS != "REVIEW")) {

                                String STG_TRANSACTION_DATE = ","  +  ",TRANSACTION_DATE," + "TRANSACTION_DATE : " + db_STG_TRANSACTION_DATE + "," + "TRANSACTION_DATE was not found," + db_STG_HDR_STATUS + "," + "Fail";
                                section4_results.add(STG_TRANSACTION_DATE);
                            } else {
                                String STG_TRANSACTION_DATE = ","  +  ",TRANSACTION_DATE," + "TRANSACTION_DATE : " + db_STG_TRANSACTION_DATE + "," + "TRANSACTION_DATE was found," + db_STG_HDR_STATUS + "," + "Pass";
                                section4_results.add(STG_TRANSACTION_DATE);
                            }

                            //CURRENCY_CODE - mandatory validation
                            if ((db_STG_CURRENCY_CODE == null) && (db_STG_HDR_STATUS != "REVIEW")) {

                                String STG_CURRENCY_CODE = ","  +  ",CURRENCY_CODE," + "CURRENCY_CODE : " + db_STG_CURRENCY_CODE + "," + "CURRENCY_CODE was not found," + db_STG_HDR_STATUS + "," + "Fail";
                                section4_results.add(STG_CURRENCY_CODE);
                            } else {
                                String STG_CURRENCY_CODE = ","  +  ",CURRENCY_CODE," + "CURRENCY_CODE : " + db_STG_CURRENCY_CODE + "," + "CURRENCY_CODE was found," + db_STG_HDR_STATUS + "," + "Pass";
                                section4_results.add(STG_CURRENCY_CODE);
                            }

                            //EXCHANGE_RATE - mandatory validation
                            if ((db_STG_EXCHANGE_RATE == null) && (db_STG_HDR_STATUS != "REVIEW")) {

                                String STG_EXCHANGE_RATE = ","  +  ",EXCHANGE_RATE," + "EXCHANGE_RATE : " + db_STG_EXCHANGE_RATE + "," + "EXCHANGE_RATE was not found," + db_STG_HDR_STATUS + "," + "Fail";
                                section4_results.add(STG_EXCHANGE_RATE);
                            } else {
                                String STG_EXCHANGE_RATE = ","  +  ",EXCHANGE_RATE," + "EXCHANGE_RATE : " + db_STG_EXCHANGE_RATE + "," + "EXCHANGE_RATE was found," + db_STG_HDR_STATUS + "," + "Pass";
                                section4_results.add(STG_EXCHANGE_RATE);
                            }

                            //EXCHANGE_RATE_TYPE - mandatory validation
                            if ((db_STG_EXCHANGE_RATE_TYPE == null) && (db_STG_HDR_STATUS != "REVIEW")) {

                                String STG_EXCHANGE_RATE_TYPE = ","  +  ",EXCHANGE_RATE_TYPE," + "EXCHANGE_RATE_TYPE : " + db_STG_EXCHANGE_RATE_TYPE + "," + "EXCHANGE_RATE_TYPE was not found," + db_STG_HDR_STATUS + "," + "Fail";
                                section4_results.add(STG_EXCHANGE_RATE_TYPE);
                            } else {
                                String STG_EXCHANGE_RATE_TYPE = ","  +  ",EXCHANGE_RATE_TYPE," + "EXCHANGE_RATE_TYPE : " + db_STG_EXCHANGE_RATE_TYPE + "," + "EXCHANGE_RATE_TYPE was found," + db_STG_HDR_STATUS + "," + "Pass";
                                section4_results.add(STG_EXCHANGE_RATE_TYPE);
                            }

                            //TRANSACTION_AMOUNT - mandatory validation
                            if ((db_STG_TRANSACTION_AMOUNT == null) && (db_STG_HDR_STATUS != "REVIEW")) {

                                String STG_TRANSACTION_AMOUNT = ","  +  ",TRANSACTION_AMOUNT," + "TRANSACTION_AMOUNT : " + db_STG_TRANSACTION_AMOUNT + "," + "TRANSACTION_AMOUNT was not found," + db_STG_HDR_STATUS + "," + "Fail";
                                section4_results.add(STG_TRANSACTION_AMOUNT);
                            } else {
                                String STG_TRANSACTION_AMOUNT = ","  +  ",TRANSACTION_AMOUNT," + "TRANSACTION_AMOUNT : " + db_STG_TRANSACTION_AMOUNT + "," + "TRANSACTION_AMOUNT was found," + db_STG_HDR_STATUS + "," + "Pass";
                                section4_results.add(STG_TRANSACTION_AMOUNT);
                            }

                            //BASE_CURRENCY_AMOUNT - mandatory validation
                            if ((db_STG_BASE_CURRENCY_AMOUNT == null) && (db_STG_HDR_STATUS != "REVIEW")) {

                                String STG_BASE_CURRENCY_AMOUNT = ","  +  ",BASE_CURRENCY_AMOUNT," + "BASE_CURRENCY_AMOUNT : " + db_STG_BASE_CURRENCY_AMOUNT + "," + "BASE_CURRENCY_AMOUNT was not found," + db_STG_HDR_STATUS + "," + "Fail";
                                section4_results.add(STG_BASE_CURRENCY_AMOUNT);
                            } else {
                                String STG_BASE_CURRENCY_AMOUNT = ","  +  ",BASE_CURRENCY_AMOUNT," + "BASE_CURRENCY_AMOUNT : " + db_STG_BASE_CURRENCY_AMOUNT + "," + "BASE_CURRENCY_AMOUNT was found," + db_STG_HDR_STATUS + "," + "Pass";
                                section4_results.add(STG_BASE_CURRENCY_AMOUNT);
                            }

                            //CLAIM_NUMBER - mandatory validation
                            if ((db_STG_CLAIM_NUMBER == null) && (db_STG_HDR_STATUS != "REVIEW")) {

                                String STG_CLAIM_NUMBER = ","  +  ",CLAIM_NUMBER," + "CLAIM_NUMBER : " + db_STG_CLAIM_NUMBER + "," + "CLAIM_NUMBER was not found," + db_STG_HDR_STATUS + "," + "Fail";
                                section4_results.add(STG_CLAIM_NUMBER);
                            } else {
                                String STG_CLAIM_NUMBER = ","  +  ",CLAIM_NUMBER," + "CLAIM_NUMBER : " + db_STG_CLAIM_NUMBER + "," + "CLAIM_NUMBER was found," + db_STG_HDR_STATUS + "," + "Pass";
                                section4_results.add(STG_CLAIM_NUMBER);
                            }

                            //EVENT_CODE - mandatory validation
                            if ((db_STG_EVENT_CODE == null) && (db_STG_HDR_STATUS != "REVIEW")) {

                                String STG_EVENT_CODE = ","  +  ",EVENT_CODE," + "EVENT_CODE : " + db_STG_EVENT_CODE + "," + "EVENT_CODE was not found," + db_STG_HDR_STATUS + "," + "Fail";
                                section4_results.add(STG_EVENT_CODE);
                            } else {
                                String STG_EVENT_CODE = ","  +  ",EVENT_CODE," + "EVENT_CODE : " + db_STG_EVENT_CODE + "," + "EVENT_CODE was found," + db_STG_HDR_STATUS + "," + "Pass";
                                section4_results.add(STG_EVENT_CODE);
                            }

                            //ENTITY_TYPE_CODE - mandatory validation
                            if ((db_STG_ENTITY_TYPE_CODE == null) && (db_STG_HDR_STATUS != "REVIEW")) {

                                String STG_ENTITY_TYPE_CODE = ","  +  ",ENTITY_TYPE_CODE," + "ENTITY_TYPE_CODE : " + db_STG_ENTITY_TYPE_CODE + "," + "ENTITY_TYPE_CODE was not found," + db_STG_HDR_STATUS + "," + "Fail";
                                section4_results.add(STG_ENTITY_TYPE_CODE);
                            } else {
                                String STG_ENTITY_TYPE_CODE = ","  +  ",ENTITY_TYPE_CODE," + "ENTITY_TYPE_CODE : " + db_STG_ENTITY_TYPE_CODE + "," + "ENTITY_TYPE_CODE was found," + db_STG_HDR_STATUS + "," + "Pass";
                                section4_results.add(STG_ENTITY_TYPE_CODE);
                            }

                            //RESERVES_FLAG - mandatory validation
                            if ((db_STG_RESERVES_FLAG == null) && (db_STG_HDR_STATUS != "REVIEW")) {

                                String STG_RESERVES_FLAG = ","  +  ",RESERVES_FLAG," + "RESERVES_FLAG : " + db_STG_RESERVES_FLAG + "," + "RESERVES_FLAG was not found," + db_STG_HDR_STATUS + "," + "Fail";
                                section4_results.add(STG_RESERVES_FLAG);
                            } else {
                                String STG_RESERVES_FLAG = ","  +  ",RESERVES_FLAG," + "RESERVES_FLAG : " + db_STG_RESERVES_FLAG + "," + "RESERVES_FLAG was found," + db_STG_HDR_STATUS + "," + "Pass";
                                section4_results.add(STG_RESERVES_FLAG);
                            }

                            //PRODUCT_KEY - mandatory validation
                            if ((db_STG_PRODUCT_KEY == null) && (db_STG_HDR_STATUS != "REVIEW")) {

                                String STG_PRODUCT_KEY = ","  +  ",PRODUCT_KEY," + "PRODUCT_KEY : " + db_STG_PRODUCT_KEY + "," + "PRODUCT_KEY was not found," + db_STG_HDR_STATUS + "," + "Fail";
                                section4_results.add(STG_PRODUCT_KEY);
                            } else {
                                String STG_PRODUCT_KEY = ","  +  ",PRODUCT_KEY," + "PRODUCT_KEY : " + db_STG_PRODUCT_KEY + "," + "PRODUCT_KEY was found," + db_STG_HDR_STATUS + "," + "Pass";
                                section4_results.add(STG_PRODUCT_KEY);
                            }

                            //LOSS_DATE - mandatory validation
                            if ((db_STG_LOSS_DATE == null) && (db_STG_HDR_STATUS != "REVIEW")) {

                                String STG_LOSS_DATE = ","  +  ",LOSS_DATE," + "LOSS_DATE : " + db_STG_LOSS_DATE + "," + "LOSS_DATE was not found," + db_STG_HDR_STATUS + "," + "Fail";
                                section4_results.add(STG_LOSS_DATE);
                            } else {
                                String STG_LOSS_DATE = ","  +  ",LOSS_DATE," + "LOSS_DATE : " + db_STG_LOSS_DATE + "," + "LOSS_DATE was found," + db_STG_HDR_STATUS + "," + "Pass";
                                section4_results.add(STG_LOSS_DATE);
                            }

                            //SUMMARY_FLAG - mandatory validation
                            if ((db_STG_SUMMARY_FLAG == null) && (db_STG_HDR_STATUS != "REVIEW")) {

                                String STG_SUMMARY_FLAG = ","  +  ",SUMMARY_FLAG," + "SUMMARY_FLAG : " + db_STG_SUMMARY_FLAG + "," + "SUMMARY_FLAG was not found," + db_STG_HDR_STATUS + "," + "Fail";
                                section4_results.add(STG_SUMMARY_FLAG);
                            } else {
                                String STG_SUMMARY_FLAG = ","  +  ",SUMMARY_FLAG," + "SUMMARY_FLAG : " + db_STG_SUMMARY_FLAG + "," + "SUMMARY_FLAG was found," + db_STG_HDR_STATUS + "," + "Pass";
                                section4_results.add(STG_SUMMARY_FLAG);
                            }

                            //LINE_OF_BUSINESS - mandatory validation
                            if ((db_STG_LINE_OF_BUSINESS == null) && (db_STG_HDR_STATUS != "REVIEW")) {

                                String STG_LINE_OF_BUSINESS = ","  +  ",LINE_OF_BUSINESS," + "LINE_OF_BUSINESS : " + db_STG_LINE_OF_BUSINESS + "," + "LINE_OF_BUSINESS was not found," + db_STG_HDR_STATUS + "," + "Fail";
                                section4_results.add(STG_LINE_OF_BUSINESS);
                            } else {
                                String STG_LINE_OF_BUSINESS = ","  +  ",LINE_OF_BUSINESS," + "LINE_OF_BUSINESS : " + db_STG_LINE_OF_BUSINESS + "," + "LINE_OF_BUSINESS was found," + db_STG_HDR_STATUS + "," + "Pass";
                                section4_results.add(STG_LINE_OF_BUSINESS);
                            }

                            //POLICY_NUMBER - mandatory validation
                            if ((db_STG_POLICY_NUMBER == null) && (db_STG_HDR_STATUS != "REVIEW")) {

                                String STG_POLICY_NUMBER = ","  +  ",POLICY_NUMBER," + "POLICY_NUMBER : " + db_STG_POLICY_NUMBER + "," + "POLICY_NUMBER was not found," + db_STG_HDR_STATUS + "," + "Fail";
                                section4_results.add(STG_POLICY_NUMBER);
                            } else {
                                String STG_POLICY_NUMBER = ","  +  ",POLICY_NUMBER," + "POLICY_NUMBER : " + db_STG_POLICY_NUMBER + "," + "POLICY_NUMBER was found," + db_STG_HDR_STATUS + "," + "Pass";
                                section4_results.add(STG_POLICY_NUMBER);
                            }

                            //LOSS_DATE - mandatory validation
                            if ((db_STG_LOSS_DATE == null) && (db_STG_HDR_STATUS != "REVIEW")) {

                                String STG_LOSS_DATE = ","  +  ",LOSS_DATE," + "LOSS_DATE : " + db_STG_LOSS_DATE + "," + "LOSS_DATE was not found," + db_STG_HDR_STATUS + "," + "Fail";
                                section4_results.add(STG_LOSS_DATE);
                            } else {
                                String STG_LOSS_DATE = ","  +  ",LOSS_DATE," + "LOSS_DATE : " + db_STG_LOSS_DATE + "," + "LOSS_DATE was found," + db_STG_HDR_STATUS + "," + "Pass";
                                section4_results.add(STG_LOSS_DATE);
                            }


                            //mapping valdiations - CONS to STG table

                            if (db_CONS_JOB_NUMBER.equals(db_STG_HEADER_ID)) {
                                String cons_header_id = cons_stg_map_row + ",HEADER_ID," + db_STG_HEADER_ID + "," + db_CONS_JOB_NUMBER + ",Pass";
                                section1_results.add(cons_header_id);
                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",HEADER_ID" + "," + db_STG_HEADER_ID + "," + db_CONS_JOB_NUMBER + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                section2_results_tbl.add(tbl_header_id);
                                cons_stg_map_row++;
                            } else {
                                String cons_header_id = cons_stg_map_row + ",HEADER_ID," + db_STG_HEADER_ID + "," + db_CONS_JOB_NUMBER + ",Fail";
                                section1_results.add(cons_header_id);
                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",HEADER_ID" + "," + db_STG_HEADER_ID + "," + db_CONS_JOB_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                section2_results_tbl.add(tbl_header_id);
                                cons_stg_map_row++;
                                CONS_flag++;
                            }

                            //--------------------  Validation SOURCE ---------------
                            if (db_CONS_SOURCE.equals(db_STG_SOURCE)) {
                                String cons_source = ",SOURCE," + db_STG_SOURCE + "," + db_CONS_SOURCE + ",Pass";
                                section1_results.add(cons_source);
                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SOURCE" + "," + db_STG_SOURCE + "," + db_CONS_SOURCE + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                section2_results_tbl.add(tbl_header_id);
                            } else {
                                String cons_source = ",SOURCE," + db_STG_SOURCE + "," + db_CONS_SOURCE + ",Fail";
                                section1_results.add(cons_source);
                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SOURCE" + "," + db_STG_SOURCE + "," + db_CONS_SOURCE + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                section2_results_tbl.add(tbl_header_id);
                                CONS_flag++;
                            }

                            //--------------------  Validation UNDERWRITER ---------------
                            if(db_CONS_INSURER_NAME != null && db_STG_UNDERWRITER != null) {
                                if (db_CONS_INSURER_NAME.equalsIgnoreCase(db_STG_UNDERWRITER)) {
                                    String CONS_INSURER_NAME = ",UNDERWRITER," + db_STG_UNDERWRITER + "," + db_CONS_INSURER_NAME + ",Pass";
                                    section1_results.add(CONS_INSURER_NAME);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",UNDERWRITER" + "," + db_STG_UNDERWRITER + "," + db_CONS_INSURER_NAME + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String CONS_INSURER_NAME = ",UNDERWRITER," + db_STG_UNDERWRITER + "," + db_CONS_INSURER_NAME + ",Fail";
                                    section1_results.add(CONS_INSURER_NAME);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",UNDERWRITER" + "," + db_STG_UNDERWRITER + "," + db_CONS_INSURER_NAME + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }
                            } else {
                                String CONS_INSURER_NAME = ",UNDERWRITER," + db_STG_UNDERWRITER + "," + db_CONS_INSURER_NAME + ",Fail";
                                section1_results.add(CONS_INSURER_NAME);
                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",UNDERWRITER" + "," + db_STG_UNDERWRITER + "," + db_CONS_INSURER_NAME + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                section2_results_tbl.add(tbl_header_id);
                                CONS_flag++;
                            }


                            //--------------------  Validation TRANSACTION_DATE ---------------
                            String db_STG_TRANSACTION_DATEModified = db_STG_TRANSACTION_DATE.substring(0,10);
                            String db_CONS_REPORT_DATEModified = db_CONS_REPORT_DATE.substring(0,10);
                            if (db_CONS_REPORT_DATE.equals(db_STG_TRANSACTION_DATE)) {
                                String cons_trans_date = ",TRANSACTION_DATE," + db_STG_TRANSACTION_DATEModified + "," + db_CONS_REPORT_DATEModified + ",Pass";
                                section1_results.add(cons_trans_date);
                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATEModified + "," + db_CONS_REPORT_DATEModified + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                section2_results_tbl.add(tbl_header_id);
                            } else {
                                String cons_trans_date = ",TRANSACTION_DATE," + db_STG_TRANSACTION_DATEModified + "," + db_CONS_REPORT_DATEModified + ",Fail";
                                section1_results.add(cons_trans_date);
                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_DATE" + "," + db_STG_TRANSACTION_DATEModified + "," + db_CONS_REPORT_DATEModified + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                section2_results_tbl.add(tbl_header_id);
                                CONS_flag++;
                            }

                            //--------------------  Validation TRANSACTION_AMOUNT ---------------
                            if (db_CONS_PARTS_COST.equals(db_STG_TRANSACTION_AMOUNT)) {
                                String cons_transaction_amount = ",TRANSACTION_AMOUNT," + db_STG_TRANSACTION_AMOUNT + "," + db_CONS_PARTS_COST + ",Pass";
                                section1_results.add(cons_transaction_amount);
                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_AMOUNT" + "," + db_STG_TRANSACTION_AMOUNT + "," + db_CONS_PARTS_COST + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                section2_results_tbl.add(tbl_header_id);
                            } else {
                                String cons_transaction_amount = ",TRANSACTION_AMOUNT," + db_STG_TRANSACTION_AMOUNT + "," + db_CONS_PARTS_COST + ",Fail";
                                section1_results.add(cons_transaction_amount);
                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",TRANSACTION_AMOUNT" + "," + db_STG_TRANSACTION_AMOUNT + "," + db_CONS_PARTS_COST + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                section2_results_tbl.add(tbl_header_id);
                                CONS_flag++;
                            }

                            //--------------------  Validation LOSS_DATE and itis similar to Transaction Date ---------------
                            String db_STG_LOSS_DATEModified = db_STG_LOSS_DATE.substring(0,10);
                            //String db_CONS_REPORT_DATEModified = db_CONS_REPORT_DATE.substring(0,10);
                            if (db_CONS_REPORT_DATE.equals(db_STG_LOSS_DATE)) {
                                String cons_loss_date = ",LOSS_DATE," + db_STG_LOSS_DATEModified + "," + db_CONS_REPORT_DATEModified + ",Pass";
                                section1_results.add(cons_loss_date);
                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",LOSS_DATE" + "," + db_STG_LOSS_DATEModified + "," + db_CONS_REPORT_DATEModified + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                section2_results_tbl.add(tbl_header_id);
                            } else {
                                String cons_loss_date = ",LOSS_DATE," + db_STG_LOSS_DATEModified + "," + db_CONS_REPORT_DATEModified + ",Fail";
                                section1_results.add(cons_loss_date);
                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",LOSS_DATE" + "," + db_STG_LOSS_DATEModified + "," + db_CONS_REPORT_DATEModified + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                section2_results_tbl.add(tbl_header_id);
                                CONS_flag++;
                            }

                            //--------------------  Validation BASE_CURRENCY_AMOUNT ---------------
                            if (db_CONS_PARTS_COST.equals(db_STG_BASE_CURRENCY_AMOUNT)) {
                                String cons_BASE_CURRENCY_AMOUNT = ",INVOICE_CURRENCY_CODE," + db_STG_BASE_CURRENCY_AMOUNT + "," + db_CONS_PARTS_COST + ",Pass";
                                section1_results.add(cons_BASE_CURRENCY_AMOUNT);
                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",INVOICE_CURRENCY_CODE" + "," + db_STG_BASE_CURRENCY_AMOUNT + "," + db_CONS_PARTS_COST + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                section2_results_tbl.add(tbl_header_id);
                            } else {
                                String cons_BASE_CURRENCY_AMOUNT = ",INVOICE_CURRENCY_CODE," + db_STG_BASE_CURRENCY_AMOUNT + "," + db_CONS_PARTS_COST + ",Fail";
                                section1_results.add(cons_BASE_CURRENCY_AMOUNT);
                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",INVOICE_CURRENCY_CODE" + "," + db_STG_BASE_CURRENCY_AMOUNT + "," + db_CONS_PARTS_COST + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                section2_results_tbl.add(tbl_header_id);
                                CONS_flag++;
                            }

                            //--------------------  Validation FSH_ATTRIBUTE_01 ---------------
                            if(db_CONS_TURNED_WIP_DATE != null && db_STG_FSH_ATTRIBUTE_01 != null) {
                                if (db_CONS_TURNED_WIP_DATE.equals(db_STG_FSH_ATTRIBUTE_01)) {
                                    String cons_FSH_ATTRIBUTE_01 = ",INVOICE_CURRENCY_CODE," + db_STG_FSH_ATTRIBUTE_01 + "," + db_CONS_TURNED_WIP_DATE + ",Pass";
                                    section1_results.add(cons_FSH_ATTRIBUTE_01);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",INVOICE_CURRENCY_CODE" + "," + db_STG_FSH_ATTRIBUTE_01 + "," + db_CONS_TURNED_WIP_DATE + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String cons_FSH_ATTRIBUTE_01 = ",INVOICE_CURRENCY_CODE," + db_STG_FSH_ATTRIBUTE_01 + "," + db_CONS_TURNED_WIP_DATE + ",Fail";
                                    section1_results.add(cons_FSH_ATTRIBUTE_01);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",INVOICE_CURRENCY_CODE" + "," + db_STG_FSH_ATTRIBUTE_01 + "," + db_CONS_TURNED_WIP_DATE + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }
                            } else {
                                String cons_FSH_ATTRIBUTE_01 = ",INVOICE_CURRENCY_CODE," + db_STG_FSH_ATTRIBUTE_01 + "," + db_CONS_TURNED_WIP_DATE + ",Fail";
                                section1_results.add(cons_FSH_ATTRIBUTE_01);
                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",INVOICE_CURRENCY_CODE" + "," + db_STG_FSH_ATTRIBUTE_01 + "," + db_CONS_TURNED_WIP_DATE + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                section2_results_tbl.add(tbl_header_id);
                                CONS_flag++;
                            }

                            //----------------------- STANDARDISATION start here -----------------------------
                            String db_lookup_channel_meaning = "null";
                            String db_lookup_line_of_business_meaning = "null";
                            String db_lookup_event_code_meaning = "null";
                            String db_lookup_entity_type_code_meaning = "null";
                            String db_lookup_exchange_rate_meaning = "null";
                            String db_lookup_exchange_rate_type_meaning = "null";
                            String db_lookup_currency_code_meaning = "null";
                            String db_lookup_source_event_id_meaning = "null";
                            String db_lookup_product_type_meaning = "null";
                            String db_lookup_claim_number_meaning = "null";
                            String db_lookup_LOCATION_meaning = "null";
                            String db_lookup_product_meaning = "null";
                            String db_lookup_reserves_flag_meaning = "null";
                            String db_lookup_brand_meaning = "null";
                            String db_lookup_product_key_meaning = "null";
                            String db_lookup_summary_flag_meaning = "null";
                            String db_lookup_policy_number_meaning = "null";
                            String db_lookup_V_UNDERWRITER_NOPOST_meaning = "null";
                            String db_lookup_DEAD = "DEAD RECORD";
                            String db_lookup_VALID = "VALID RECORD";


                            //---------------- Validate LOCATION -----------------------
                                String BMSGLAccrual_fsh_lookup = connect_db.executeQuery_DB("Lookup", "FSH_LOOKUP","CCV5");
                                String BMSGLAccrual_fsh_sys_lookup = connect_db.executeQuery_DB("Lookup", "FSH_SYS_LOOKUP","CCV5");
                                String fsh_source = connect_db.executeQuery_DB("Lookup", "FSH_LOOKUP_SOURCE_CCV5GLAccrual","CCV5");

                                SQLResultset = SQLstmt.executeQuery(BMSGLAccrual_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_CONS_LOCATION + "' and LOOKUP_TYPE = 'LOCATION'" + fsh_source);
                                //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_LOCATION + "' and LOOKUP_TYPE = 'LOCATION' and system = 'ECLI' and pattern = 'GLAccrual'");
                            while (SQLResultset.next()) {
                                db_lookup_LOCATION_meaning = SQLResultset.getString("MEANING");
                            }
                            if (db_lookup_LOCATION_meaning.equals("null")) {
                                String lookup_LOCATION_meaning = ",LOCATION lookup," + "LookUp value not found" + "," + db_STG_LOCATION + ",Fail";
                                section1_results.add(lookup_LOCATION_meaning);
                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",LOCATION lookup" + "," + "LookUp value not found" + "," + db_STG_LOCATION + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                section2_results_tbl.add(tbl_header_id);
                                CONS_flag++;
                            } else if (db_lookup_LOCATION_meaning != null) {
                                if (db_lookup_LOCATION_meaning.equals(db_STG_LOCATION)) {
                                    String lookup_LOCATION_meaning = ",LOCATION lookup," + db_lookup_LOCATION_meaning + "," + db_STG_LOCATION + ",Pass";
                                    section1_results.add(lookup_LOCATION_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",LOCATION lookup" + "," + db_lookup_LOCATION_meaning + "," + db_STG_LOCATION + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String lookup_LOCATION_meaning = ",LOCATION lookup," + db_lookup_LOCATION_meaning + "," + db_STG_LOCATION + ",Fail";
                                    section1_results.add(lookup_LOCATION_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",LOCATION lookup" + "," + db_lookup_LOCATION_meaning + "," + db_STG_LOCATION + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }
                            }

                            //------------------------ V_UNDERWRITER_NOPOST - DEAD Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(BMSGLAccrual_fsh_lookup + " WHERE LOOKUP_CODE = '" + db_STG_UNDERWRITER + "' and LOOKUP_TYPE = 'UNDERWRITER_EXCL'" + fsh_source);
                            //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_STG_UNDERWRITER + "' and LOOKUP_TYPE = 'UNDERWRITER_EXCL' and system = 'ECLI' and pattern = 'GLAccrual'");
                            while (SQLResultset.next()) {
                                db_lookup_V_UNDERWRITER_NOPOST_meaning = SQLResultset.getString("MEANING");
                            }

                            if (db_STG_UNDERWRITER == null || db_lookup_V_UNDERWRITER_NOPOST_meaning != ("null")) {
                                String lookup_channel_meaning = ",V_UNDERWRITER_NOPOST lookup for DEAD Records validations," + db_lookup_DEAD + "," + db_lookup_DEAD + ",Fail";
                                section1_results.add(lookup_channel_meaning);
                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",V_UNDERWRITER_NOPOST lookup for DEAD Records validations" + "," + db_lookup_DEAD + "," + db_lookup_DEAD + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                section2_results_tbl.add(tbl_header_id);
                                CONS_flag++;
                            } else{
                                String lookup_channel_meaning = ",V_UNDERWRITER_NOPOST lookup for VALID Records validations," + db_lookup_VALID + "," + db_lookup_VALID + ",Pass";
                                section1_results.add(lookup_channel_meaning);
                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",,V_UNDERWRITER_NOPOST lookup for VALID Records validations" + "," + db_lookup_VALID + "," + db_lookup_VALID + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                section2_results_tbl.add(tbl_header_id);

                            }


                            //------------------------ CHANNEL Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(BMSGLAccrual_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'CHANNEL'" + fsh_source);
                            //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'CHANNEL' and system = 'ECLI' and pattern = 'GLAccrual'");
                            while (SQLResultset.next()) {
                                db_lookup_channel_meaning = SQLResultset.getString("MEANING");
                            }

                            if (db_lookup_channel_meaning.equals("null")) {
                                String lookup_channel_meaning = ",CHANNEL lookup," + "LookUp value not found" + "," + db_STG_CHANNEL + ",Fail";
                                section1_results.add(lookup_channel_meaning);
                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CHANNEL lookup" + "," + "LookUp value not found" + "," + db_STG_CHANNEL + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                section2_results_tbl.add(tbl_header_id);
                                CONS_flag++;
                            } else if (db_lookup_channel_meaning != null) {
                                if (db_lookup_channel_meaning.equals(db_STG_CHANNEL)) {
                                    String lookup_channel_meaning = ",CHANNEL lookup," + db_lookup_channel_meaning + "," + db_STG_CHANNEL + ",Pass";
                                    section1_results.add(lookup_channel_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CHANNEL lookup" + "," + db_lookup_channel_meaning + "," + db_STG_CHANNEL + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else {
                                    String lookup_channel_meaning = ",CHANNEL lookup," + db_lookup_channel_meaning + "," + db_STG_CHANNEL + ",Fail";
                                    section1_results.add(lookup_channel_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CHANNEL lookup" + "," + db_lookup_channel_meaning + "," + db_STG_CHANNEL + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }
                            }

                            //------------------------ EVENT_CODE Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(BMSGLAccrual_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'GLEVENTS'" + fsh_source);
                            //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'GLEVENTS' and system = 'ECLI' and pattern = 'GLAccrual'");
                            while (SQLResultset.next()) {
                                db_lookup_event_code_meaning = SQLResultset.getString("MEANING");
                            }

                            if (db_lookup_event_code_meaning.equals("null")) {
                                String lookup_event_code_meaning = ",EVENT_CODE lookup," + "LookUp value not found" + "," + db_STG_EVENT_CODE + ",Fail";
                                section1_results.add(lookup_event_code_meaning);
                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",EVENT_CODE lookup" + "," + "LookUp value not found" + "," + db_STG_EVENT_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                section2_results_tbl.add(tbl_header_id);
                                CONS_flag++;
                            } else if (db_lookup_event_code_meaning != null) {
                                if (db_lookup_event_code_meaning.equals(db_STG_EVENT_CODE)) {
                                    String lookup_event_code_meaning = ",EVENT_CODE lookup," + db_lookup_event_code_meaning + "," + db_STG_EVENT_CODE + ",Pass";
                                    section1_results.add(lookup_event_code_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",EVENT_CODE lookup" + "," + db_lookup_event_code_meaning + "," + db_STG_EVENT_CODE + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String lookup_event_code_meaning = ",EVENT_CODE lookup," + db_lookup_event_code_meaning + "," + db_STG_EVENT_CODE + ",Fail";
                                    section1_results.add(lookup_event_code_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",EVENT_CODE lookup" + "," + db_lookup_event_code_meaning + "," + db_STG_EVENT_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }
                            }

                            //------------------------ ENTITY_TYPE_CODE Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(BMSGLAccrual_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'ENTITY_TYPE_CODE'" + fsh_source);
                            //SQLResultset = SQLstmt.executeQuery("SELECT * FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'ENTITY_TYPE_CODE' and system = 'ECLI' and pattern = 'GLAccrual'");
                            while (SQLResultset.next()) {
                                db_lookup_entity_type_code_meaning = SQLResultset.getString("MEANING");
                            }

                            if (db_lookup_entity_type_code_meaning.equals("null")) {
                                String lookup_entity_type_code_meaning = ",ENTITY_TYPE_CODE lookup," + "LookUp value not found" + "," + db_STG_ENTITY_TYPE_CODE + ",Fail";
                                section1_results.add(lookup_entity_type_code_meaning);
                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ENTITY_TYPE_CODE lookup" + "," + "LookUp value not found" + "," + db_STG_ENTITY_TYPE_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                section2_results_tbl.add(tbl_header_id);
                                CONS_flag++;
                            } else if (db_lookup_entity_type_code_meaning != null) {
                                if (db_lookup_entity_type_code_meaning.equals(db_STG_ENTITY_TYPE_CODE)) {
                                    String lookup_entity_type_code_meaning = ",ENTITY_TYPE_CODE lookup," + db_lookup_entity_type_code_meaning + "," + db_STG_ENTITY_TYPE_CODE + ",Pass";
                                    section1_results.add(lookup_entity_type_code_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ENTITY_TYPE_CODE lookup" + "," + db_lookup_entity_type_code_meaning + "," + db_STG_ENTITY_TYPE_CODE + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                } else {
                                    String lookup_entity_type_code_meaning = ",ENTITY_TYPE_CODE lookup," + db_lookup_entity_type_code_meaning + "," + db_STG_ENTITY_TYPE_CODE + ",Fail";
                                    section1_results.add(lookup_entity_type_code_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",ENTITY_TYPE_CODE lookup" + "," + db_lookup_entity_type_code_meaning + "," + db_STG_ENTITY_TYPE_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }
                            }

                            //------------------------ CURRENCY_CODE Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(BMSGLAccrual_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'CURRENCY_CODE'" + fsh_source);
                            //SQLResultset = SQLstmt.executeQuery("SELECT * FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'CURRENCY_CODE' and system = 'ECLI' and pattern = 'GLAccrual'");
                            while (SQLResultset.next()) {
                                db_lookup_currency_code_meaning = SQLResultset.getString("MEANING");
                            }

                            if (db_lookup_currency_code_meaning.equals("null")) {
                                String lookup_currency_code_meaning = ",CURRENCY_CODE lookup," + "LookUp value not found" + "," + db_STG_CURRENCY_CODE + ",Fail";
                                section1_results.add(lookup_currency_code_meaning);
                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CURRENCY_CODE lookup" + "," + "LookUp value not found" + "," + db_STG_CURRENCY_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                section2_results_tbl.add(tbl_header_id);
                                CONS_flag++;
                            } else if (db_lookup_currency_code_meaning != null) {
                                if (db_lookup_currency_code_meaning.equals(db_STG_CURRENCY_CODE)) {
                                    String lookup_currency_code_meaning = ",CURRENCY_CODE lookup," + db_lookup_currency_code_meaning + "," + db_STG_CURRENCY_CODE + ",Pass";
                                    section1_results.add(lookup_currency_code_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CURRENCY_CODE lookup" + "," + db_lookup_currency_code_meaning + "," + db_STG_CURRENCY_CODE + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String lookup_currency_code_meaning = ",CURRENCY_CODE lookup," + db_lookup_currency_code_meaning + "," + db_STG_CURRENCY_CODE + ",Fail";
                                    section1_results.add(lookup_currency_code_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CURRENCY_CODE lookup" + "," + db_lookup_currency_code_meaning + "," + db_STG_CURRENCY_CODE + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }
                            }

                            //------------------------ SOURCE_EVENT_ID Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(BMSGLAccrual_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'GLEVENTS'" + fsh_source);
                            //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'GLEVENTS' and system = 'ECLI' and pattern = 'GLAccrual'");
                            while (SQLResultset.next()) {
                                db_lookup_source_event_id_meaning = SQLResultset.getString("MEANING");
                            }

                            if (db_lookup_source_event_id_meaning.equals("null")) {
                                String lookup_source_event_id_meaning = ",SOURCE_EVENT_ID lookup," + "LookUp value not found" + "," + db_STG_SOURCE_EVENT_ID + ",Fail";
                                section1_results.add(lookup_source_event_id_meaning);
                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SOURCE_EVENT_ID lookup" + "," + "LookUp value not found" + "," + db_STG_SOURCE_EVENT_ID + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                section2_results_tbl.add(tbl_header_id);
                                CONS_flag++;
                            } else if (db_lookup_source_event_id_meaning != null) {
                                if (db_lookup_source_event_id_meaning.equals(db_STG_SOURCE_EVENT_ID)) {
                                    String lookup_source_event_id_meaning = ",SOURCE_EVENT_ID lookup," + db_lookup_source_event_id_meaning + "," + db_STG_SOURCE_EVENT_ID + ",Pass";
                                    section1_results.add(lookup_source_event_id_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SOURCE_EVENT_ID lookup" + "," + db_lookup_source_event_id_meaning + "," + db_STG_SOURCE_EVENT_ID + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String lookup_source_event_id_meaning = ",SOURCE_EVENT_ID lookup," + db_lookup_source_event_id_meaning + "," + db_STG_SOURCE_EVENT_ID + ",Fail";
                                    section1_results.add(lookup_source_event_id_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SOURCE_EVENT_ID lookup" + "," + db_lookup_source_event_id_meaning + "," + db_STG_SOURCE_EVENT_ID + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }
                            }


                            //------------------------ BRAND Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(BMSGLAccrual_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'BRAND'" + fsh_source);
                            //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'BRAND' and system = 'ECLI' and pattern = 'GLAccrual'");
                            while (SQLResultset.next()) {
                                db_lookup_brand_meaning = SQLResultset.getString("MEANING");
                            }

                            if (db_lookup_brand_meaning.equals("null")) {
                                String lookup_brand_meaning = ",BRAND lookup," + "LookUp value not found" + "," + db_STG_BRAND + ",Fail";
                                section1_results.add(lookup_brand_meaning);
                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BRAND lookup" + "," + "LookUp value not found" + "," + db_STG_BRAND + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                section2_results_tbl.add(tbl_header_id);
                                CONS_flag++;
                            } else if (db_lookup_brand_meaning != null) {
                                if (db_lookup_brand_meaning.equals(db_STG_BRAND)) {
                                    String lookup_brand_meaning = ",BRAND lookup," + db_lookup_brand_meaning + "," + db_STG_BRAND + ",Pass";
                                    section1_results.add(lookup_brand_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BRAND lookup" + "," + db_lookup_brand_meaning + "," + db_STG_BRAND + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String lookup_brand_meaning = ",BRAND lookup," + db_lookup_brand_meaning + "," + db_STG_BRAND + ",Fail";
                                    section1_results.add(lookup_brand_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",BRAND lookup" + "," + db_lookup_brand_meaning + "," + db_STG_BRAND + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }
                            }

                            //------------------------ PRODUCT Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(BMSGLAccrual_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'PRODUCT'" + fsh_source);
                            //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'PRODUCT' and system = 'ECLI' and pattern = 'GLAccrual'");
                            while (SQLResultset.next()) {
                                db_lookup_product_meaning = SQLResultset.getString("MEANING");
                            }

                            if (db_lookup_product_meaning.equals("null")) {
                                String lookup_product_meaning = ",PRODUCT lookup," + "LookUp value not found" + "," + db_STG_PRODUCT + ",Fail";
                                section1_results.add(lookup_product_meaning);
                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT lookup" + "," + "LookUp value not found" + "," + db_STG_PRODUCT + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                section2_results_tbl.add(tbl_header_id);
                                CONS_flag++;
                            } else if (db_lookup_product_meaning != null) {
                                if (db_lookup_product_meaning.equals(db_STG_PRODUCT)) {
                                    String lookup_product_meaning = ",PRODUCT lookup," + db_lookup_product_meaning + "," + db_STG_PRODUCT + ",Pass";
                                    section1_results.add(lookup_product_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT lookup" + "," + db_lookup_product_meaning + "," + db_STG_PRODUCT + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String lookup_product_meaning = ",PRODUCT lookup," + db_lookup_product_meaning + "," + db_STG_PRODUCT + ",Fail";
                                    section1_results.add(lookup_product_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT lookup" + "," + db_lookup_product_meaning + "," + db_STG_PRODUCT + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }
                            }

                            //------------------------ PRODUCT_TYPE Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(BMSGLAccrual_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'PRODUCT_TYPE'" + fsh_source);
                            //SQLResultset = SQLstmt.executeQuery("SELECT * FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'PRODUCT_TYPE' and system = 'ECLI' and pattern = 'GLAccrual'");
                            while (SQLResultset.next()) {
                                db_lookup_product_type_meaning = SQLResultset.getString("MEANING");
                            }

                            if (db_lookup_product_type_meaning.equals("null")) {
                                String product_type_meaning = ",PRODUCT_TYPE lookup," + "LookUp value not found" + "," + db_STG_PRODUCT_TYPE + ",Fail";
                                section1_results.add(product_type_meaning);
                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT_TYPE lookup" + "," + "LookUp value not found" + "," + db_STG_PRODUCT_TYPE + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                section2_results_tbl.add(tbl_header_id);
                                CONS_flag++;
                            } else if (db_lookup_product_type_meaning != null) {
                                if (db_lookup_product_type_meaning.equals(db_STG_PRODUCT_TYPE)) {
                                    String product_type_meaning = ",PRODUCT_TYPE lookup," + db_lookup_product_type_meaning + "," + db_STG_PRODUCT_TYPE + ",Pass";
                                    section1_results.add(product_type_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT_TYPE lookup" + "," + db_lookup_product_type_meaning + "," + db_STG_PRODUCT_TYPE + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String product_type_meaning = ",PRODUCT_TYPE lookup," + db_lookup_product_type_meaning + "," + db_STG_PRODUCT_TYPE + ",Fail";
                                    section1_results.add(product_type_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT_TYPE lookup" + "," + db_lookup_product_type_meaning + "," + db_STG_PRODUCT_TYPE + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }
                            }

                            //------------------------ EXCHANGE_RATE Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(BMSGLAccrual_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'EXCHANGE_RATE'" + fsh_source);
                            //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'EXCHANGE_RATE' and system = 'ECLI' and pattern = 'GLAccrual'");
                            while (SQLResultset.next()) {
                                db_lookup_exchange_rate_meaning = SQLResultset.getString("MEANING");
                            }

                            if (db_lookup_exchange_rate_meaning.equals("null")) {
                                String lookup_exchange_rate_meaning = ",EXCHANGE_RATE lookup," + "LookUp value not found" + "," + db_STG_EXCHANGE_RATE + ",Fail";
                                section1_results.add(lookup_exchange_rate_meaning);
                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",EXCHANGE_RATE lookup" + "," + "LookUp value not found" + "," + db_STG_EXCHANGE_RATE + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                section2_results_tbl.add(tbl_header_id);
                                CONS_flag++;
                            } else if (db_lookup_exchange_rate_meaning != null) {
                                if (db_lookup_exchange_rate_meaning.equals(db_STG_EXCHANGE_RATE)) {
                                    String lookup_exchange_rate_meaning = ",EXCHANGE_RATE lookup," + db_lookup_exchange_rate_meaning + "," + db_STG_EXCHANGE_RATE + ",Pass";
                                    section1_results.add(lookup_exchange_rate_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",EXCHANGE_RATE lookup" + "," + db_lookup_exchange_rate_meaning + "," + db_STG_EXCHANGE_RATE + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String lookup_exchange_rate_meaning = ",EXCHANGE_RATE lookup," + db_lookup_exchange_rate_meaning + "," + db_STG_EXCHANGE_RATE + ",Fail";
                                    section1_results.add(lookup_exchange_rate_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",EXCHANGE_RATE lookup" + "," + db_lookup_exchange_rate_meaning + "," + db_STG_EXCHANGE_RATE + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }
                            }


                            //------------------------ EXCHANGE_RATE_TYPE Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(BMSGLAccrual_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'EXCHANGE_RATE_TYPE'" + fsh_source);
                            //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'EXCHANGE_RATE_TYPE' and system = 'ECLI' and pattern = 'GLAccrual'");
                            while (SQLResultset.next()) {
                                db_lookup_exchange_rate_type_meaning = SQLResultset.getString("MEANING");
                            }

                            if (db_lookup_exchange_rate_type_meaning.equals("null")) {
                                String lookup_exchange_rate_type_meaning = ",EXCHANGE_RATE_TYPE lookup," + "LookUp value not found" + "," + db_STG_EXCHANGE_RATE_TYPE + ",Fail";
                                section1_results.add(lookup_exchange_rate_type_meaning);
                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",EXCHANGE_RATE_TYPE lookup" + "," + "LookUp value not found" + "," + db_STG_EXCHANGE_RATE_TYPE + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                section2_results_tbl.add(tbl_header_id);
                                CONS_flag++;
                            } else if (db_lookup_exchange_rate_type_meaning != null) {
                                if (db_lookup_exchange_rate_type_meaning.equals(db_STG_EXCHANGE_RATE_TYPE)) {
                                    String lookup_exchange_rate_type_meaning = ",EXCHANGE_RATE_TYPE lookup," + db_lookup_exchange_rate_type_meaning + "," + db_STG_EXCHANGE_RATE_TYPE + ",Pass";
                                    section1_results.add(lookup_exchange_rate_type_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",EXCHANGE_RATE_TYPE lookup" + "," + db_lookup_exchange_rate_type_meaning + "," + db_STG_EXCHANGE_RATE_TYPE + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String lookup_exchange_rate_type_meaning = ",EXCHANGE_RATE_TYPE lookup," + db_lookup_exchange_rate_type_meaning + "," + db_STG_EXCHANGE_RATE_TYPE + ",Fail";
                                    section1_results.add(lookup_exchange_rate_type_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",EXCHANGE_RATE_TYPE lookup" + "," + db_lookup_exchange_rate_type_meaning + "," + db_STG_EXCHANGE_RATE_TYPE + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }
                            }

                            //------------------------ CLAIM_NUMBER Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(BMSGLAccrual_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'CLAIM_NUMBER'" + fsh_source);
                            //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'CLAIM_NUMBER' and system = 'ECLI' and pattern = 'GLAccrual'");
                            while (SQLResultset.next()) {
                                db_lookup_claim_number_meaning = SQLResultset.getString("MEANING");
                            }

                            if (db_lookup_claim_number_meaning.equals("null")) {
                                String lookup_claim_number_meaning = ",CLAIM_NUMBER lookup," + "LookUp value not found" + "," + db_STG_CLAIM_NUMBER + ",Fail";
                                section1_results.add(lookup_claim_number_meaning);
                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CLAIM_NUMBER lookup" + "," + "LookUp value not found" + "," + db_STG_CLAIM_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                section2_results_tbl.add(tbl_header_id);
                                CONS_flag++;
                            } else if (db_lookup_claim_number_meaning != null) {
                                if (db_lookup_claim_number_meaning.equals(db_STG_CLAIM_NUMBER)) {
                                    String lookup_claim_number_meaning = ",CLAIM_NUMBER lookup," + db_lookup_claim_number_meaning + "," + db_STG_CLAIM_NUMBER + ",Pass";
                                    section1_results.add(lookup_claim_number_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CLAIM_NUMBER lookup" + "," + db_lookup_claim_number_meaning + "," + db_STG_CLAIM_NUMBER + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String lookup_claim_number_meaning = ",CLAIM_NUMBER lookup," + db_lookup_claim_number_meaning + "," + db_STG_CLAIM_NUMBER + ",Fail";
                                    section1_results.add(lookup_claim_number_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",CLAIM_NUMBER lookup" + "," + db_lookup_claim_number_meaning + "," + db_STG_CLAIM_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }
                            }


                            //------------------------ RESERVES_FLAG Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(BMSGLAccrual_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'RESERVES_FLAG'" + fsh_source);
                            //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'RESERVES_FLAG' and system = 'ECLI' and pattern = 'GLAccrual'");
                            while (SQLResultset.next()) {
                                db_lookup_reserves_flag_meaning = SQLResultset.getString("MEANING");
                            }

                            if (db_lookup_reserves_flag_meaning.equals("null")) {
                                String lookup_reserves_flag_meaning = ",RESERVES_FLAG lookup," + "LookUp value not found" + "," + db_STG_RESERVES_FLAG + ",Fail";
                                section1_results.add(lookup_reserves_flag_meaning);
                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",RESERVES_FLAG lookup" + "," + "LookUp value not found" + "," + db_STG_RESERVES_FLAG + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                section2_results_tbl.add(tbl_header_id);
                                CONS_flag++;
                            } else if (db_lookup_reserves_flag_meaning != null) {
                                if (db_lookup_reserves_flag_meaning.equals(db_STG_RESERVES_FLAG)) {
                                    String lookup_reserves_flag_meaning = ",RESERVES_FLAG lookup," + db_lookup_reserves_flag_meaning + "," + db_STG_RESERVES_FLAG + ",Pass";
                                    section1_results.add(lookup_reserves_flag_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",RESERVES_FLAG lookup" + "," + db_lookup_reserves_flag_meaning + "," + db_STG_RESERVES_FLAG + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String lookup_reserves_flag_meaning = ",RESERVES_FLAG lookup," + db_lookup_reserves_flag_meaning + "," + db_STG_RESERVES_FLAG + ",Fail";
                                    section1_results.add(lookup_reserves_flag_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",RESERVES_FLAG lookup" + "," + db_lookup_reserves_flag_meaning + "," + db_STG_RESERVES_FLAG + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }
                            }


                            //------------------------ PRODUCT_KEY Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(BMSGLAccrual_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'PRODUCT_KEY'" + fsh_source);
                            //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'PRODUCT_KEY' and system = 'ECLI' and pattern = 'GLAccrual'");
                            while (SQLResultset.next()) {
                                db_lookup_product_key_meaning = SQLResultset.getString("MEANING");
                            }

                            if (db_lookup_product_key_meaning.equals("null")) {
                                String lookup_product_key_meaning = ",PRODUCT_KEY lookup," + "LookUp value not found" + "," + db_STG_PRODUCT_KEY + ",Fail";
                                section1_results.add(lookup_product_key_meaning);
                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT_KEY lookup" + "," + "LookUp value not found" + "," + db_STG_PRODUCT_KEY + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                section2_results_tbl.add(tbl_header_id);
                                CONS_flag++;
                            } else if (db_lookup_product_key_meaning != null) {
                                if (db_lookup_product_key_meaning.equals(db_STG_PRODUCT_KEY)) {
                                    String lookup_product_key_meaning = ",PRODUCT_KEY lookup," + db_lookup_product_key_meaning + "," + db_STG_PRODUCT_KEY + ",Pass";
                                    section1_results.add(lookup_product_key_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT_KEY lookup" + "," + db_lookup_product_key_meaning + "," + db_STG_PRODUCT_KEY + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String lookup_product_key_meaning = ",PRODUCT_KEY lookup," + db_lookup_product_key_meaning + "," + db_STG_PRODUCT_KEY + ",Fail";
                                    section1_results.add(lookup_product_key_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",PRODUCT_KEY lookup" + "," + db_lookup_product_key_meaning + "," + db_STG_PRODUCT_KEY + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }
                            }


                            //------------------------ SUMMARY_FLAG Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(BMSGLAccrual_fsh_lookup + " WHERE LOOKUP_CODE = 'ECLIGLAccrual' and LOOKUP_TYPE = 'SUMMARISE_DATA_FLAG'" + fsh_source);
                            //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'ECLIGLAccrual' and LOOKUP_TYPE = 'SUMMARISE_DATA_FLAG' and system = 'ECLI' and pattern = 'GLAccrual'");
                            while (SQLResultset.next()) {
                                db_lookup_summary_flag_meaning = SQLResultset.getString("MEANING");
                            }

                            if (db_lookup_summary_flag_meaning.equals("null")) {
                                String lookup_summary_flag_meaning = ",SUMMARY_FLAG lookup," + "LookUp value not found" + "," + db_STG_SUMMARY_FLAG + ",Fail";
                                section1_results.add(lookup_summary_flag_meaning);
                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SUMMARY_FLAG lookup" + "," + "LookUp value not found" + "," + db_STG_SUMMARY_FLAG + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                section2_results_tbl.add(tbl_header_id);
                                CONS_flag++;
                            } else if (db_lookup_summary_flag_meaning != null) {
                                if (db_lookup_summary_flag_meaning.equals(db_STG_SUMMARY_FLAG)) {
                                    String lookup_summary_flag_meaning = ",SUMMARY_FLAG lookup," + db_lookup_summary_flag_meaning + "," + db_STG_SUMMARY_FLAG + ",Pass";
                                    section1_results.add(lookup_summary_flag_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SUMMARY_FLAG lookup" + "," + db_lookup_summary_flag_meaning + "," + db_STG_SUMMARY_FLAG + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String lookup_summary_flag_meaning = ",SUMMARY_FLAG lookup," + db_lookup_summary_flag_meaning + "," + db_STG_SUMMARY_FLAG + ",Fail";
                                    section1_results.add(lookup_summary_flag_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",SUMMARY_FLAG lookup" + "," + db_lookup_summary_flag_meaning + "," + db_STG_SUMMARY_FLAG + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }
                            }

                            //------------------------ LINE_OF_BUSINESS Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(BMSGLAccrual_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'LINE_OF_BUSINESS'" + fsh_source);
                            //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'LINE_OF_BUSINESS' and system = 'ECLI' and pattern = 'GLAccrual'");
                            while (SQLResultset.next()) {
                                db_lookup_line_of_business_meaning = SQLResultset.getString("MEANING");
                            }

                            if (db_lookup_line_of_business_meaning.equals("null")) {
                                String lookup_line_of_business_meaning = ",LINE_OF_BUSINESS lookup," + "LookUp value not found" + "," + db_STG_LINE_OF_BUSINESS + ",Fail";
                                section1_results.add(lookup_line_of_business_meaning);
                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",LINE_OF_BUSINESS lookup" + "," + "LookUp value not found" + "," + db_STG_LINE_OF_BUSINESS + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                section2_results_tbl.add(tbl_header_id);
                                CONS_flag++;
                            } else if (db_lookup_line_of_business_meaning != null) {
                                if (db_lookup_line_of_business_meaning.equals(db_STG_LINE_OF_BUSINESS)) {
                                    String lookup_line_of_business_meaning = ",LINE_OF_BUSINESS lookup," + db_lookup_line_of_business_meaning + "," + db_STG_LINE_OF_BUSINESS + ",Pass";
                                    section1_results.add(lookup_line_of_business_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",LINE_OF_BUSINESS lookup" + "," + db_lookup_line_of_business_meaning + "," + db_STG_LINE_OF_BUSINESS + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String lookup_line_of_business_meaning = ",LINE_OF_BUSINESS lookup," + db_lookup_line_of_business_meaning + "," + db_STG_LINE_OF_BUSINESS + ",Fail";
                                    section1_results.add(lookup_line_of_business_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",LINE_OF_BUSINESS lookup" + "," + db_lookup_line_of_business_meaning + "," + db_STG_LINE_OF_BUSINESS + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }
                            }

                            //------------------------ POLICY_NUMBER Validation -----------------
                                SQLResultset = SQLstmt.executeQuery(BMSGLAccrual_fsh_lookup + " WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'POLICY_NUMBER'" + fsh_source);
                            //SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = 'Default' and LOOKUP_TYPE = 'POLICY_NUMBER' and system = 'ECLI' and pattern = 'GLAccrual'");
                            while (SQLResultset.next()) {
                                db_lookup_policy_number_meaning = SQLResultset.getString("MEANING");
                            }

                            if (db_lookup_policy_number_meaning.equals("null")) {
                                String lookup_policy_number_meaning = ",POLICY_NUMBER lookup," + "LookUp value not found" + "," + db_STG_POLICY_NUMBER + ",Fail";
                                section1_results.add(lookup_policy_number_meaning);
                                String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",POLICY_NUMBER lookup" + "," + "LookUp value not found" + "," + db_STG_POLICY_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                section2_results_tbl.add(tbl_header_id);
                                CONS_flag++;
                            } else if (db_lookup_policy_number_meaning != null) {
                                if (db_lookup_policy_number_meaning.equals(db_STG_POLICY_NUMBER)) {
                                    String lookup_policy_number_meaning = ",POLICY_NUMBER lookup," + db_lookup_policy_number_meaning + "," + db_STG_POLICY_NUMBER + ",Pass";
                                    section1_results.add(lookup_policy_number_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",POLICY_NUMBER lookup" + "," + db_lookup_policy_number_meaning + "," + db_STG_POLICY_NUMBER + ",Pass" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                } else {
                                    String lookup_policy_number_meaning = ",POLICY_NUMBER lookup," + db_lookup_policy_number_meaning + "," + db_STG_POLICY_NUMBER + ",Fail";
                                    section1_results.add(lookup_policy_number_meaning);
                                    String tbl_header_id = section2_map_row + "," + header + "," + Source + "," + pattern + ",POLICY_NUMBER lookup" + "," + db_lookup_policy_number_meaning + "," + db_STG_POLICY_NUMBER + ",Fail" + "," + load_dateFormat + "," + db_file_name+ "," + btc_BATCH_PKEY;
                                    section2_results_tbl.add(tbl_header_id);
                                    CONS_flag++;
                                }
                            }


                        }

                    }
                }
                }

                //----------------- Validate the Over all Status -------------------
                System.out.println("Looping ++  CONS_flag " + CONS_flag);
                String Overall_status = null;
                String Overall_stg_status = null;
                if (CONS_flag > 0) {
                    CONS_STATUS.add("Fail");
                    Overall_status = "Fail";
                } else {
                    CONS_STATUS.add("Pass");
                    Overall_status = "Pass";
                }


                if (CONS_flag > 0) {
                    OverAllStatus.add("Fail");
                } else {
                    OverAllStatus.add("Pass");
                }

                String tbl_summary_filelist = Source +","+ pattern + ","+file_name +","+ "CONS TO STG " + "," + load_date + ","+ OverAllStatus + "," + btc_BATCH_PKEY;
                //String tbl_summary_filelist = Source + "," + pattern + "," + file_name + "," + load_dateFormat + "," + "CONST TO STG " + "," + OverAllStatus;
                summary_results_tbl.add(tbl_summary_filelist);

                list.addAll(section1_results);
                list.addAll(section2_results);
                list.addAll(section3_results);
                list.addAll(section4_results);

                // ---------------- HTML Report generation ------------------------
                report_generation.report_Test1(section1_results, "Header", xml_file_name, "CONSOLIDATION LAYER - STAGING LAYER", "BMS_GLAccrual", "BMS_GLAccrual: CONSOLIDATION LAYER - STAGING AGG LAYER", "");
                report_generation.report_Test1(section1_results, "Section2", xml_file_name, "CONSOLIDATION LAYER - STAGING LAYER", "BMS_GLAccrual", "BMS_GLAccrual: CONSOLIDATION LAYER - STAGING AGG LAYER", "");
                report_generation.report_Test1(section2_results, "Mandatory", xml_file_name, "Mandatory_Check_CONS", "BMS_GLAccrual", "BMS_GLAccrual: CONSOLIDATION LAYER - STAGING AGG LAYER", "");
                report_generation.report_Test1(section4_results, "Mandatory", xml_file_name, "Mandatory_Check_STG", "BMS_GLAccrual", "BMS_GLAccrual: CONSOLIDATION LAYER - STAGING AGG LAYER", "");
                report_generation.report_Test1(section3_results, "Section3", xml_file_name, "STAGING TO AGGREGATE LAYER", "BMS_GLAccrual", "BMS_GLAccrual: CONSOLIDATION LAYER - STAGING AGG LAYER", "");


                table_detail_report.detail_report_tbl(section2_results_tbl);
            }
        }

        state_model.section_method(file_list, CONS_STATUS, "N/A", OverAllStatus, "BMS_GLAccrual_Summary");
        table_summary_report.summary_report_tbl(summary_results_tbl );
    }

}
