package Dashboard_Report;

import org.apache.commons.io.IOUtils;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.*;
import java.util.Properties;

public class connectDatabase {

    private Connection connection = null;
    private Statement sqlStmt = null;
    private ResultSet rs = null;
    String jsonfile = null;

    public void createConnection(String env) throws SQLException{
        String app_prop = null;
        if(env.equalsIgnoreCase("SIT1")){
            app_prop = "Application_SIT1.properties";
        }else if(env.equalsIgnoreCase("DEVTEST4")){
            app_prop = "Application_DEVTEST4.properties";
        }else if(env.equalsIgnoreCase("DEVTEST3")){
            app_prop = "Application_DEVTEST3.properties";
        }else if(env.equalsIgnoreCase("SIT2")) {
            app_prop = "Application_SIT2.properties";
        }

        System.out.println("Createconenctions starts");
        try(FileInputStream input = new FileInputStream(app_prop)) {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Properties prop = new Properties();
            prop.load(input);
            String server = prop.getProperty("Database.SIT_url");
            String username = prop.getProperty("Database.SIT_username");
            String password = prop.getProperty("Database.SIT_password");
            System.out.println("server -->"+server);
            connectDatabase(server, username, password);
        }
        catch(Exception e){

            e.printStackTrace();
        }

    }

    public void connectDatabase(String server, String username,String password) throws SQLException, IOException, JSONException {

        System.out.println("Connectdatabase starts");
        try{
            connection = DriverManager.getConnection(server,username,password);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public Statement resStatement () throws SQLException {
        sqlStmt = this.connection.createStatement();
        return sqlStmt;
    }

    public String executeQuery_DB (String jsonName1, String jsonName2,String json_file) throws SQLException, IOException, JSONException{

        if(json_file.equalsIgnoreCase("B4C")){
            jsonfile = "sqlQuery_B4C.json";
        }else if(json_file.equalsIgnoreCase("LANDSCAPE")){
            jsonfile = "sqlQuery_LANDSCAPE.json";
        }else if(json_file.equalsIgnoreCase("TRAVEL")) {
            jsonfile = "sqlQuery_TRAVEL.json";
        } else if(json_file.equalsIgnoreCase("BMS")) {
            jsonfile = "sqlQuery_BMS.json";
        } else if(json_file.equalsIgnoreCase("CCV5")) {
            jsonfile = "sqlQuery_CCV5.json";
        } else if(json_file.equalsIgnoreCase("PULSE")) {
            jsonfile = "sqlQuery_PULSE.json";
        }
        InputStream queryFiles = getClass().getClassLoader().getResourceAsStream("Resource/"+jsonfile);
        String inputValues = IOUtils.toString(queryFiles,"UTF-8");
        final JSONObject queries = new JSONObject(inputValues);
        String outSQL = queries.getJSONArray(jsonName1).getJSONObject(0).getString(jsonName2);
        return outSQL;

    }
}
