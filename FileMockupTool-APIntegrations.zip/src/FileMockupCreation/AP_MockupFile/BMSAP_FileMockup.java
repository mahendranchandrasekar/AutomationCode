package FileMockupCreation.AP_MockupFile;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class BMSAP_FileMockup {
    public static void main(String[] args){
        Map<String, String> variableMap = fillMap();
        String fshFilePath =System.getProperty("user.dir")+"\\IntegrationFiles\\APIntegrations\\BMS";
        Path path = Paths.get(fshFilePath+"\\ECLIAP2002000120200702131002_50.PL");
        Stream<String> lines = null;
        try {
            lines = Files.lines(path,Charset.forName("UTF-8"));
            List<String> replacedLines = lines.map(line -> replaceTag(line, variableMap)).collect(Collectors.toList());
            Files.write(path, replacedLines, Charset.forName("UTF-8"));
            lines.close();
            System.out.println("BMS AP file - Find and replace is done");
        } catch (IOException e) {
            e.printStackTrace();
        }

        File newFile = new File(fshFilePath+"\\ECLIAP2002000120200702131002_50.PL");
        File renamedFile = new File(fshFilePath+"\\ECLIAP2002000120200702131002_51.PL");
        if(newFile.renameTo(renamedFile)) {
            System.out.println("BMS AP file - The file has been renamed successfully!!");
        } else {
            System.out.println("BMS AP file - The file could not be renamed because its already there with the same name");
        }
    }

    public static Map<String, String> fillMap() {
        Map<String, String> map= new HashMap<String, String>();

        //update invoice_id in both HEADER and LINE
        map.put("~2054",   "~2055");

        return map;
    }

    private static String replaceTag(String str, Map<String, String> map) {
        for(Map.Entry<String, String> entry : map.entrySet()) {
            if (str.contains(entry.getKey())) {
                str = str.replace(entry.getKey(), entry.getValue());
            }
        }

            return str;
        }
}
