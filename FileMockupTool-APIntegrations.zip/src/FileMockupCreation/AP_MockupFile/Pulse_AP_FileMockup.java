package FileMockupCreation.AP_MockupFile;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Pulse_AP_FileMockup {
    public static void main(String[] args){
        Map<String, String> variableMap = fillMap();
        String fshFilePath =System.getProperty("user.dir")+"\\IntegrationFiles\\APIntegrations\\PULSE";
        Path path = Paths.get(fshFilePath+"\\PULSE_AP-InsertQuery_22071046.sql");
        Stream<String> lines = null;
        try {
            lines = Files.lines(path,Charset.forName("UTF-8"));
            List<String> replacedLines = lines.map(line -> replaceTag(line, variableMap)).collect(Collectors.toList());
            Files.write(path, replacedLines, Charset.forName("UTF-8"));
            lines.close();
            System.out.println("PULSE AP file - Find and replace is done");
        } catch (IOException e) {
            e.printStackTrace();
        }

        File newFile = new File(fshFilePath+"\\PULSE_AP-InsertQuery_22071046.sql");
        File renamedFile = new File(fshFilePath+"\\PULSE_AP-InsertQuery_22071047.sql");
        if(newFile.renameTo(renamedFile)) {
            System.out.println("PULSE AP file - The file has been renamed successfully!!");
        } else {
            System.out.println("PULSE AP file - The file could not be renamed because its already there with the same name");
        }

    }

    public static Map<String, String> fillMap() {
        Map<String, String> map= new HashMap<String, String>();

        // update HEADER_ID and LINE_ID
        map.put("values (259","values (260");

        // update invoice_id
        map.put("like '259","like '260");


        map.put("3406946/20/24967582","3416946/20/24967582");
        map.put("34047475/20/25018087","34147475/20/25018087");
        map.put("34048598/20/25018782","34148598/20/25018782");
        map.put("34046664/20/25017700","34146664/20/25017700");
        map.put("340861/20/25019040","341861/20/25019040");
        map.put("34091210","34191210");
        map.put("3408210","3418210");

        map.put(",451",",452");

        return map;
    }

    private static String replaceTag(String str, Map<String, String> map) {
        for(Map.Entry<String, String> entry : map.entrySet()) {
            if (str.contains(entry.getKey())) {
                str = str.replace(entry.getKey(), entry.getValue());
            }
        }
            return str;
        }
}
