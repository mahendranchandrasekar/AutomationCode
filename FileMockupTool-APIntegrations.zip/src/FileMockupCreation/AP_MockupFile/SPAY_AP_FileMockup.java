package FileMockupCreation.AP_MockupFile;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class SPAY_AP_FileMockup {
    public static void main(String[] args){
        Map<String, String> variableMap = fillMap();
        String fshFilePath =System.getProperty("user.dir")+"\\IntegrationFiles\\APIntegrations\\SPAY";
        Path path = Paths.get(fshFilePath+"\\SpecialPaymentsAPInvoice_20200331162059_5821_38.csv");
        Stream<String> lines = null;
        try {
            lines = Files.lines(path,Charset.forName("UTF-8"));
            List<String> replacedLines = lines.map(line -> replaceTag(line, variableMap)).collect(Collectors.toList());
            Files.write(path, replacedLines, Charset.forName("UTF-8"));
            lines.close();
            System.out.println("SPAY AP file - Find and replace is done");
        } catch (IOException e) {
            e.printStackTrace();
        }

        File newFile = new File(fshFilePath+"\\SpecialPaymentsAPInvoice_20200331162059_5821_38.csv");
        File renamedFile = new File(fshFilePath+"\\SpecialPaymentsAPInvoice_20200331162059_5821_39.csv");
        if(newFile.renameTo(renamedFile)) {
            System.out.println("SPAY AP file - The file has been renamed successfully!!");
        } else {
            System.out.println("SPAY AP file - The file could not be renamed because its already there with the same name");
        }

    }

    public static Map<String, String> fillMap() {
        Map<String, String> map= new HashMap<String, String>();

        //update invoice_id
        map.put(",4139",                 ",4140");

        //update invoice_number  ----->   number(TEST013_) and current date(2020_07_27)
        map.put(",TEST035_2021_06_18",   ",TEST036_2021_07_02");

        return map;
    }

    private static String replaceTag(String str, Map<String, String> map) {
        for(Map.Entry<String, String> entry : map.entrySet()) {
            if (str.contains(entry.getKey())) {
                str = str.replace(entry.getKey(), entry.getValue());
            }
        }

            return str;
        }
}
