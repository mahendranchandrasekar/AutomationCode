package FileMockupCreation.AP_MockupFile;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class CCV5_AP_FileMockup {
    public static void main(String[] args){
        Map<String, String> variableMap = fillMap();
        String fshFilePath =System.getProperty("user.dir")+"\\IntegrationFiles\\APIntegrations\\CCV5";
        Path path = Paths.get(fshFilePath+"\\CCV5_AP-InsertQuery_22071041.sql");
        Stream<String> lines = null;
        try {
            lines = Files.lines(path,Charset.forName("UTF-8"));
            List<String> replacedLines = lines.map(line -> replaceTag(line, variableMap)).collect(Collectors.toList());
            Files.write(path, replacedLines, Charset.forName("UTF-8"));
            lines.close();
            System.out.println("CCV5 AP file - Find and replace is done");
        } catch (IOException e) {
            e.printStackTrace();
        }

        File newFile = new File(fshFilePath+"\\CCV5_AP-InsertQuery_22071041.sql");
            File renamedFile = new File(fshFilePath+"\\CCV5_AP-InsertQuery_22071042.sql");
        if(newFile.renameTo(renamedFile)) {
            System.out.println("CCV5 AP file - The file has been renamed successfully!!");
        } else {
            System.out.println("CCV5 AP file - The file could not be renamed because its already there with the same name");
        }

    }

    public static Map<String, String> fillMap() {
        Map<String, String> map= new HashMap<String, String>();

        // update both HEADER_ID
        map.put("values (2064", "values (2065");

        //update LINE_ID
        map.put("Ins',2064",   "Ins',2065");

        //update invoice_number
        map.put("cd245:",     "cd246:");



        return map;
    }

    private static String replaceTag(String str, Map<String, String> map) {
        for(Map.Entry<String, String> entry : map.entrySet()) {
            if (str.contains(entry.getKey())) {
                str = str.replace(entry.getKey(), entry.getValue());
            }
        }
            return str;
        }
}
