package com.uk.dlgds.fusionvalidation.resources.datasource;

import com.uk.dlgds.fusionvalidation.utils.ApInvoice;

public class ErpData {

    public ApInvoice convertToApData(com.uk.dlgds.fusionvalidation.utils.pojo.fsh.Output erpData)
    {
        ApInvoice apInvoice = new ApInvoice();

        apInvoice.setInvoiceId(objectToString(erpData.getInvoiceId()));
        apInvoice.setBusinessUnit(objectToString(erpData.getOperatingUnit()));
        apInvoice.setSource(objectToString(erpData.getSource()));
        apInvoice.setInvoiceNum(objectToString(erpData.getInvoiceNum()));
        apInvoice.setInvoiceAmount(objectToString(erpData.getInvoiceAmount()));
        apInvoice.setInvoiceDate(objectToString(erpData.getInvoiceDate()));
        apInvoice.setVendorName(objectToString(erpData.getVendorName()));
        apInvoice.setVendorSiteCode(objectToString(erpData.getVendorSiteCode()));
        apInvoice.setInvoiceCurrencyCode(objectToString(erpData.getInvoiceCurrencyCode()));
        apInvoice.setDescription(objectToString(erpData.getDescription()));
        apInvoice.setInvoiceType(objectToString(erpData.getInvoiceTypeLookupCode()));
        apInvoice.setPaymentTerms(objectToString(erpData.getTermsName()));
        apInvoice.setInvoiceReceivedDate(objectToString(erpData.getInvoiceReceivedDate()));
        apInvoice.setFshTransactionDate(objectToString(erpData.getGlDate()));
        apInvoice.setPaymentMethodCode(objectToString(erpData.getPaymentMethodCode()));
        apInvoice.setPayGroupLookupCode(objectToString(erpData.getPayGroupLookupCode()));
        apInvoice.setExchangeRateType(objectToString(erpData.getExchangeRateType()));
        apInvoice.setExchangeEffectiveDate(objectToString(erpData.getExchangeDate()));
        apInvoice.setExchangeRate(objectToString(erpData.getExchangeRate()));
        apInvoice.setPaymentPriority(objectToString(erpData.getPaymentPriority()));
        apInvoice.setStationeryCode(objectToString(erpData.getPaymentReasonComments()));
        apInvoice.setCalcTaxDuringImportFlag(objectToString(erpData.getCalcTaxDuringImportFlag()));
        apInvoice.setAddTaxToInvoiceAmountFlag(objectToString(erpData.getAddTaxToInvAmtFlag()));
        apInvoice.setAttributeCategory(objectToString(erpData.getAttributeCategory()));
        apInvoice.setAttribute1(objectToString(erpData.getAttribute1()));
        apInvoice.setAttribute2(objectToString(erpData.getAttribute2()));
        apInvoice.setAttribute3(objectToString(erpData.getAttribute3()));
        apInvoice.setAttribute4(objectToString(erpData.getAttribute4()));
        apInvoice.setAttribute5(objectToString(erpData.getAttribute5()));
        apInvoice.setAttribute7(objectToString(erpData.getAttribute7()));
        apInvoice.setAttribute8(objectToString(erpData.getAttribute8()));
        apInvoice.setAttribute15(objectToString(erpData.getAttribute15()));
        apInvoice.setLineInvoiceId(objectToString(erpData.getLineInvoiceId()));
        apInvoice.setLineNumber(objectToString(erpData.getLineNumber()));
        apInvoice.setLineTypeLookupCode(objectToString(erpData.getLineTypeLookupCode()));
        apInvoice.setLineItemAmount(objectToString(erpData.getLineItemAmount()));
        apInvoice.setLineDescription(objectToString(erpData.getLineDescription()));
        apInvoice.setDistCodeConcatenated(objectToString(erpData.getDistCodeConcatenated()));
        apInvoice.setTaxClassificationCode(objectToString(erpData.getTaxClassificationCode()));
        apInvoice.setTaxRateCode(objectToString(erpData.getTaxRateCode()));
        apInvoice.setProrateAcrossFlag(objectToString(erpData.getProrateAcrossFlag()));
        apInvoice.setLineGroupNumber(objectToString(erpData.getLineGroupNumber()));
        apInvoice.setAssetsTrackingFlag(objectToString(erpData.getAssetsTrackingFlag()));

        return apInvoice;
    }

    private String objectToString(Object  obj)
    {
        if ( obj==null)
            return  "";
        else
            return  obj.toString();
    }
}
