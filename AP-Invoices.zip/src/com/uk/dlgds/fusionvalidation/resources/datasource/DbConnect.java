package com.uk.dlgds.fusionvalidation.resources.datasource;

import com.uk.dlgds.fusionvalidation.utils.ApInvoice;
import com.uk.dlgds.fusionvalidation.utils.ApInvoiceConstants;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.*;
import java.util.LinkedList;
import java.util.List;

public class DbConnect {


    public List<ApInvoice> apInvoiceFshList;

    public void getDbValues(String dbServer, String dbUserName, String dbPassword, String query) throws SQLException, IOException {


        ResultSet resultSet;
        try (Connection connection = DriverManager.getConnection(dbServer, dbUserName, dbPassword); Statement stmt = connection.createStatement();) {

            resultSet = stmt.executeQuery(query);
            fshDbOutputList(resultSet);
            writeDbValues(resultSet);

        }

    }

    private void writeDbValues(ResultSet resultSet) throws SQLException, IOException {

        ResultSetMetaData rsmd = resultSet.getMetaData();
        int columnCount = rsmd.getColumnCount();

        StringBuilder sbColumnName = new StringBuilder();

        for (int counter = 1; counter <= columnCount; counter++) {
            sbColumnName.append(rsmd.getColumnName(counter) + ",");
        }


        try (BufferedWriter writer = new BufferedWriter(new FileWriter(ApInvoiceConstants.AP_FSH_DB_OUTPUT_FILE_PATH))) {
            writer.write(sbColumnName.toString() + "\n");
            while (resultSet.next()) {
                StringBuilder sbColumnValue = new StringBuilder();

                for (int counter = 1; counter <= columnCount; counter++)
                    sbColumnValue.append(resultSet.getObject(counter) + ",");

                writer.write(sbColumnValue.toString() + "\n");
            }

        }


    }

    private void fshDbOutputList(ResultSet resultSet) throws SQLException {


        List<ApInvoice> fshData = new LinkedList<>();
        while (resultSet.next()) {
            ApInvoice apInvoice = new ApInvoice();

            apInvoice.setInvoiceId(objectToString(resultSet.getObject(ApInvoiceConstants.INVOICE_ID)));
            apInvoice.setBusinessUnit(objectToString(resultSet.getObject(ApInvoiceConstants.BUSINESS_UNIT)));
            apInvoice.setSource(objectToString(resultSet.getObject(ApInvoiceConstants.SOURCE)));
            apInvoice.setInvoiceNum(objectToString(resultSet.getObject(ApInvoiceConstants.INVOICE_NUM)));
            apInvoice.setInvoiceAmount(objectToString(resultSet.getObject(ApInvoiceConstants.INVOICE_AMOUNT)));
            apInvoice.setInvoiceDate(objectToString(resultSet.getObject(ApInvoiceConstants.INVOICE_DATE)));
            apInvoice.setVendorName(objectToString(resultSet.getObject(ApInvoiceConstants.VENDOR_NAME)));
            apInvoice.setVendorSiteCode(objectToString(resultSet.getObject(ApInvoiceConstants.VENDOR_SITE_CODE)));
            apInvoice.setInvoiceCurrencyCode(objectToString(resultSet.getObject(ApInvoiceConstants.INVOICE_CURRENCY_CODE)));
            apInvoice.setDescription(objectToString(resultSet.getObject(ApInvoiceConstants.DESCRIPTION)));
            apInvoice.setInvoiceType(objectToString(resultSet.getObject(ApInvoiceConstants.INVOICE_TYPE)));
            apInvoice.setPaymentTerms(objectToString(resultSet.getObject(ApInvoiceConstants.PAYMENT_TERMS)));
            apInvoice.setInvoiceReceivedDate(objectToString(resultSet.getObject(ApInvoiceConstants.INVOICE_RECEIVED_DATE)));
            apInvoice.setFshTransactionDate(objectToString(resultSet.getObject(ApInvoiceConstants.FSH_TRANSACTION_DATE)));
            apInvoice.setPaymentMethodCode(objectToString(resultSet.getObject(ApInvoiceConstants.PAYMENT_METHOD_CODE)));
            apInvoice.setPayGroupLookupCode(objectToString(resultSet.getObject(ApInvoiceConstants.PAY_GROUP_LOOKUP_CODE)));
            apInvoice.setExchangeRateType(objectToString(resultSet.getObject(ApInvoiceConstants.EXCHANGE_RATE_TYPE)));
            apInvoice.setExchangeEffectiveDate(objectToString(resultSet.getObject(ApInvoiceConstants.EXCHANGE_EFFECTIVE_DATE)));
            apInvoice.setExchangeRate(objectToString(resultSet.getObject(ApInvoiceConstants.EXCHANGE_RATE)));
            apInvoice.setPaymentPriority(objectToString(resultSet.getObject(ApInvoiceConstants.PAYMENT_PRIORITY)));
            apInvoice.setStationeryCode(objectToString(resultSet.getObject(ApInvoiceConstants.STATIONERY_CODE)));
            apInvoice.setCalcTaxDuringImportFlag(objectToString(resultSet.getObject(ApInvoiceConstants.CALC_TAX_DURING_IMPORT_FLAG)));
            apInvoice.setAddTaxToInvoiceAmountFlag(objectToString(resultSet.getObject(ApInvoiceConstants.ADD_TAX_TO_INVOICE_AMOUNT_FLAG)));
            apInvoice.setAttributeCategory(objectToString(resultSet.getObject(ApInvoiceConstants.ATTRIBUTE_CATEGORY)));
            apInvoice.setAttribute1(objectToString(resultSet.getObject(ApInvoiceConstants.ATTRIBUTE1)));
            apInvoice.setAttribute2(objectToString(resultSet.getObject(ApInvoiceConstants.ATTRIBUTE2)));
            apInvoice.setAttribute3(objectToString(resultSet.getObject(ApInvoiceConstants.ATTRIBUTE3)));
            apInvoice.setAttribute4(objectToString(resultSet.getObject(ApInvoiceConstants.ATTRIBUTE4)));
            apInvoice.setAttribute5(objectToString(resultSet.getObject(ApInvoiceConstants.ATTRIBUTE5)));
            apInvoice.setAttribute7(objectToString(resultSet.getObject(ApInvoiceConstants.ATTRIBUTE7)));
            apInvoice.setAttribute8(objectToString(resultSet.getObject(ApInvoiceConstants.ATTRIBUTE8)));
            apInvoice.setAttribute15(objectToString(resultSet.getObject(ApInvoiceConstants.ATTRIBUTE15)));
            apInvoice.setLineInvoiceId(objectToString(resultSet.getObject(ApInvoiceConstants.LINE_INVOICE_ID)));
            apInvoice.setLineNumber(objectToString(resultSet.getObject(ApInvoiceConstants.LINE_NUMBER)));
            apInvoice.setLineTypeLookupCode(objectToString(resultSet.getObject(ApInvoiceConstants.LINE_TYPE_LOOKUP_CODE)));
            apInvoice.setLineItemAmount(objectToString(resultSet.getObject(ApInvoiceConstants.LINE_ITEM_AMOUNT)));
            apInvoice.setLineDescription(objectToString(resultSet.getObject(ApInvoiceConstants.LINE_DESCRIPTION)));
            apInvoice.setDistCodeConcatenated(objectToString(resultSet.getObject(ApInvoiceConstants.DIST_CODE_CONCATENATED)));
            apInvoice.setTaxClassificationCode(objectToString(resultSet.getObject(ApInvoiceConstants.TAX_CLASSIFICATION_CODE)));
            apInvoice.setTaxRateCode(objectToString(resultSet.getObject(ApInvoiceConstants.TAX_RATE_CODE)));
            apInvoice.setProrateAcrossFlag(objectToString(resultSet.getObject(ApInvoiceConstants.PRORATE_ACROSS_FLAG)));
            apInvoice.setLineGroupNumber(objectToString(resultSet.getObject(ApInvoiceConstants.LINE_GROUP_NUMBER)));
            apInvoice.setAssetsTrackingFlag(objectToString(resultSet.getObject(ApInvoiceConstants.ASSETS_TRACKING_FLAG)));
            apInvoice.setFileName(objectToString(resultSet.getObject(ApInvoiceConstants.FILE_NAME)));
            apInvoice.setSource1(objectToString(resultSet.getObject(ApInvoiceConstants.SOURCE1)));
            apInvoice.setLoadDate(objectToString(resultSet.getObject(ApInvoiceConstants.LOAD_DATE)));


            fshData.add(apInvoice);
        }

        apInvoiceFshList = fshData;

    }

    private String objectToString(Object obj) {
        if (obj == null)
            return "";
        else
            return obj.toString();
    }
}
