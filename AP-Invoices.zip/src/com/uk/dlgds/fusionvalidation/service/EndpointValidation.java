package com.uk.dlgds.fusionvalidation.service;


import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.uk.dlgds.fusionvalidation.utils.pojo.reject.ROWSET;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.List;
import java.util.Objects;

import static javax.xml.parsers.DocumentBuilderFactory.newInstance;

public class EndpointValidation {

    private static int count = 0;
    private final ApplicationDetails applicationDetails = new ApplicationDetails();
    private String username;
    private String password;
    private String url;
    private String ip;
    private String port;
    private String runInDLG;


    public List<com.uk.dlgds.fusionvalidation.utils.pojo.fsh.Output> triggerEndPoint(String query) throws IOException, ParserConfigurationException, SAXException, TransformerException {
        readValues();

        HttpURLConnection con = null;
        Proxy proxy = null;
        URL obj = null;

        if (runInDLG.equalsIgnoreCase("yes")) {
            proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(ip, Integer.parseInt(port)));
            obj = new URL(url);
            con = (HttpURLConnection) obj.openConnection(proxy);
        } else {
            obj = new URL(url);
            con = (HttpURLConnection) obj.openConnection();
        }

        con.setRequestProperty("Content-Type", "application/soap+xml; charset=utf-8");
        con.setRequestProperty("Authorization", "Basic " + encodeCredentials());
        con.setDoOutput(true);
        DataOutputStream wr = new DataOutputStream(con.getOutputStream());
        wr.writeBytes(updateQuery(readInputXML(), query));
        wr.flush();
        wr.close();
        org.w3c.dom.Document document = convertStringToXMLDocument(readResponse(con).toString());
        String nodes = document.getElementsByTagName("ns2:runReportResponse").item(0).getTextContent();
        byte[] byteArray = Base64.getDecoder().decode(nodes.substring(0, nodes.length() - 8));
        String output = new String(byteArray);
        //  System.out.println("output value is"+output);
        return xmlStrToJavaObj(output);
    }

    public org.w3c.dom.Document readInputXML() throws IOException, ParserConfigurationException, SAXException {
        org.w3c.dom.Document document = null;
        try (InputStream stream = getClass().getClassLoader().getResourceAsStream("com/uk/dlgds/fusionvalidation/resources/samples/SampleRequest.xml")) {
            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
            document = docBuilder.parse(Objects.requireNonNull(stream));
        }
        return document;

    }

    public String encodeCredentials() throws IOException {

        return Base64.getEncoder().encodeToString((username + ":" + password).getBytes(StandardCharsets.UTF_8));
    }

    public String updateQuery(org.w3c.dom.Document inputXML, String values) throws TransformerException {

        inputXML.getElementsByTagName("pub:item").item(1).setTextContent(values);
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();
        transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
        DOMSource source = new DOMSource(inputXML);
        StringWriter strWriter = new StringWriter();
        StreamResult result = new StreamResult(strWriter);
        transformer.transform(source, result);
        String output = strWriter.getBuffer().toString();
        output = output.replaceAll("[\\r\\n]", "");
        return output;

    }

    public StringBuffer readResponse(HttpURLConnection con) throws IOException {

        BufferedReader in = null;
        if (con.getResponseCode() == 200) {
            System.out.println(++count + " Response code is " + con.getResponseCode());
            in = new BufferedReader(new
                    InputStreamReader(con.getInputStream()));
        } else {
            System.out.println(++count + " Response code is not 200");
            System.out.println("Response code is " + con.getResponseCode());
            in = new BufferedReader(new
                    InputStreamReader(con.getErrorStream()));
            System.exit(0);
        }
        String inputLine;
        StringBuffer response = new StringBuffer();
        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();
        return response;
    }

    public org.w3c.dom.Document convertStringToXMLDocument(String xmlString) throws ParserConfigurationException, IOException, SAXException {

        DocumentBuilderFactory docBuilderFactory = newInstance();
        DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
        return docBuilder.parse(new InputSource(new StringReader(xmlString)));
    }

    public List<com.uk.dlgds.fusionvalidation.utils.pojo.fsh.Output> xmlStrToJavaObj(String output) {
        XmlMapper xmlMapper = new XmlMapper();
        com.uk.dlgds.fusionvalidation.utils.pojo.fsh.ROWSET rowset = null;
        xmlMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);

        try {
            rowset = xmlMapper.readValue(output, com.uk.dlgds.fusionvalidation.utils.pojo.fsh.ROWSET.class);
            System.out.println(rowset.getOutput());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return rowset.getOutput();
    }

    private List<com.uk.dlgds.fusionvalidation.utils.pojo.reject.Output> xmlRjtStrToJavaObj(String output) {
        XmlMapper xmlMapper = new XmlMapper();
        com.uk.dlgds.fusionvalidation.utils.pojo.reject.ROWSET rowset =  null;
        xmlMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);

        try {
            rowset = xmlMapper.readValue(output, com.uk.dlgds.fusionvalidation.utils.pojo.reject.ROWSET.class);
            System.out.println(rowset.getOutput());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return rowset.getOutput();
    }


    private void readValues() throws IOException {

        String runner = "JENKINS";

        username = applicationDetails.readProperties("com.uk.dlgds.username").trim();
        password = applicationDetails.readProperties("com.uk.dlgds.password").trim();
        url = applicationDetails.readProperties("com.uk.dlgds.endpoint.url").trim();

        if (System.getProperty("runner.name").equals(runner))
            ip = applicationDetails.readProperties("com.uk.dlgds.proxy.ip.jenkins").trim();
        else
            ip = applicationDetails.readProperties("com.uk.dlgds.proxy.ip").trim();


        port = applicationDetails.readProperties("com.uk.dlgds.proxy.port").trim();

        runInDLG = applicationDetails.readProperties("com.uk.dlgds.run.runinDLG").trim();
    }

    public List<com.uk.dlgds.fusionvalidation.utils.pojo.reject.Output> rejectTriggerEndPoint(String query) throws IOException, ParserConfigurationException, SAXException, TransformerException {
        readValues();

        HttpURLConnection con = null;
        Proxy proxy = null;
        URL obj = null;

        if (runInDLG.equalsIgnoreCase("yes")) {
            proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(ip, Integer.parseInt(port)));
            obj = new URL(url);
            con = (HttpURLConnection) obj.openConnection(proxy);
        } else {
            obj = new URL(url);
            con = (HttpURLConnection) obj.openConnection();
        }

        con.setRequestProperty("Content-Type", "application/soap+xml; charset=utf-8");
        con.setRequestProperty("Authorization", "Basic " + encodeCredentials());
        con.setDoOutput(true);
        DataOutputStream wr = new DataOutputStream(con.getOutputStream());
        wr.writeBytes(updateQuery(readInputXML(), query));
        wr.flush();
        wr.close();
        org.w3c.dom.Document document = convertStringToXMLDocument(readResponse(con).toString());
        String nodes = document.getElementsByTagName("ns2:runReportResponse").item(0).getTextContent();
        byte[] byteArray = Base64.getDecoder().decode(nodes.substring(0, nodes.length() - 8));
        String output = new String(byteArray);
        System.out.println("output value is \n" + output);
        return xmlRjtStrToJavaObj(output);
    }
}
