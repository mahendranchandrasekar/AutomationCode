package com.uk.dlgds.fusionvalidation;

import com.uk.dlgds.fusionvalidation.resources.datasource.DbConnect;
import com.uk.dlgds.fusionvalidation.resources.datasource.ErpData;
import com.uk.dlgds.fusionvalidation.service.ApplicationDetails;
import com.uk.dlgds.fusionvalidation.service.EndpointValidation;
import com.uk.dlgds.fusionvalidation.utils.*;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

public class ApIntegrationTest {

    public static List<String> invoiceIdsError = new LinkedList<>();
    public static List<String> invoiceIdsNoError = new LinkedList<>();
    private final ApplicationDetails applicationDetails = new ApplicationDetails();
    private final EndpointValidation endpointValidation = new EndpointValidation();
    private final ApValidation apValidation = new ApValidation();
    private final int maxRecordCount = 1000;
    public TestReport testReport;
    private String actualQueryInvoiceId;
    private String actualQueryDate;
    private String fshDateQuery;
    private String fshDate;
    private String fshFile;
    private String fshFileQuery;
    private String erpQuery;
    private String fshQuery;
    private String dbServer;
    private String dbUserName;
    private String dbPassword;
    private String rejectQuery;
    private int totalRecordInFSH;
    private int totalRecordInERP;

    @Test
    public void accountPayables() throws IOException, ParserConfigurationException, SAXException, TransformerException, SQLException, ClassNotFoundException {


        DbConnect dbConnect = new DbConnect();
        ErpData erpData = new ErpData();


        readValuesFromProperties();
        dbConnect.getDbValues(dbServer, dbUserName, dbPassword, fshQuery);
        List<ApInvoice> apInvoiceFshList = dbConnect.apInvoiceFshList;
        List<ApInvoice> apInvoiceErpList;

        List<String> fileNames = apInvoiceFshList.parallelStream()
                .map(o -> o.getFileName().trim())
                .filter(o -> !o.isEmpty())
                .distinct()
                .collect(Collectors.toList());

        for (String filename : fileNames) {
            apInvoiceErpList = new LinkedList<>();
            List<com.uk.dlgds.fusionvalidation.utils.pojo.fsh.Output> erpInvoiceIds;

            String listOfInvoiceIds;
            invoiceIdsError.clear();
            invoiceIdsNoError.clear();
            testReport = new TestReport();
            testReport.initTestReport();
            testReport.setReportFileName(filename.trim());
            testReport.setReportSource(filename.trim().substring(0, 4));
            testReport.setReportProcessedOn(apInvoiceFshList.get(0).getFshTransactionDate().trim().replace("00.00.00.000000000", "").trim());

            List<String> invoiceIds = apInvoiceFshList.parallelStream()
                    .filter(o -> o.getFileName().trim().equalsIgnoreCase(filename))
                    .map(o -> o.getInvoiceId().trim())
                    .distinct()
                    .collect(Collectors.toList());

            List<String> tempInvoiceIds = invoiceIds.stream().collect(Collectors.toList());

            while (!tempInvoiceIds.isEmpty()) {
                List<String> splitIds = tempInvoiceIds.stream().limit(maxRecordCount).collect(Collectors.toList());


                listOfInvoiceIds = String.join("', '", splitIds);

                erpInvoiceIds = endpointValidation.triggerEndPoint(erpQuery.replace(ApInvoiceConstants.SQL_INVOICE_ID_STR, listOfInvoiceIds));


                List<ApInvoice> tempList = erpInvoiceIds.parallelStream()
                        .map(o -> erpData.convertToApData(o))
                        .collect(Collectors.toList());

                apInvoiceErpList.addAll(tempList);

                tempInvoiceIds.removeAll(splitIds);
            }


            Comparator<ApInvoice> apComparator = Comparator.comparing(ApInvoice::getInvoiceId).thenComparing(ApInvoice::getLineItemAmount);

            List<ApInvoice> apFilterFshList = apInvoiceFshList.parallelStream()
                    .filter(o -> o.getFileName().trim().equalsIgnoreCase(filename))
                    .sorted(apComparator)
                    .collect(Collectors.toList());
            apInvoiceErpList = apInvoiceErpList.parallelStream()
                    .sorted(apComparator)
                    .collect(Collectors.toList());

            totalRecordInFSH = (int) apFilterFshList.parallelStream().map(ApInvoice::getInvoiceId).count();
            totalRecordInERP = apInvoiceErpList.size();
            apValidation.validateApInvoice(apFilterFshList, apInvoiceErpList, testReport);

//
//
//            invoiceIdsNoError = invoiceIdsNoError.parallelStream().distinct().collect(Collectors.toList());
//            invoiceIdsError = invoiceIdsError.parallelStream()
//                    .distinct()
//                    .filter( o -> !invoiceIdsNoError.contains(o))
//                    .collect(Collectors.toList());



            testReport.setTotalRecordsInFile(Integer.toString(totalRecordInFSH));
            testReport.setTotalRecordsProcessedInErp(Integer.toString(totalRecordInERP));

            List<String> invoiceIdForRejectErp;

            List<String> invoiceIdOicsError;


            if (!invoiceIdsError.isEmpty()) {
                invoiceIdForRejectErp =invoiceIdsError;


                listOfInvoiceIds = String.join(",", invoiceIdForRejectErp.parallelStream()
                        .distinct()
                        .collect(Collectors.toList()));

                listOfInvoiceIds = listOfInvoiceIds.trim().isEmpty() ? "99999" : listOfInvoiceIds;

                List<com.uk.dlgds.fusionvalidation.utils.pojo.reject.Output> rejectOutputInvoiceIds = endpointValidation.rejectTriggerEndPoint(rejectQuery.replace(ApConstants.SQL_INVOICE_ID_STR, listOfInvoiceIds));


                long countErroredInErp = rejectOutputInvoiceIds.stream()
                        .sorted(Comparator.comparing(com.uk.dlgds.fusionvalidation.utils.pojo.reject.Output::getInvoiceId))
                        .peek(o -> testReport.replaceReject(o.getInvoiceId(), o.getInvoiceNum(), o.getRejectionMessage()))
                        .count();

                if (countErroredInErp == 0) testReport.replaceNoReject();

                testReport.setTotalRecordsErroedInErp(Long.toString(countErroredInErp));


                if (invoiceIdForRejectErp.size() != rejectOutputInvoiceIds.size()) {
                    invoiceIdOicsError = invoiceIdForRejectErp.stream()
                            .filter(o -> rejectOutputInvoiceIds.stream().map(com.uk.dlgds.fusionvalidation.utils.pojo.reject.Output::getInvoiceId).noneMatch(m -> m.equals(o)))
                            .sorted()
                            .collect(Collectors.toList());

                    String countOicsError = Integer.toString(invoiceIdOicsError.size());
                    testReport.setTotalRecordsOicsError(countOicsError);

                    List<String> countOicsErrorReport = apFilterFshList.parallelStream()
                            .filter(o -> invoiceIdOicsError.contains(o.getInvoiceId()))
                            .map(o -> o.getInvoiceId() + "," + o.getInvoiceNum())
                            .collect(Collectors.toList());
                    testReport.replaceOicsError(countOicsErrorReport);
                } else {
                    testReport.setTotalRecordsOicsError("0");
                    testReport.replaceNoOicsError();
                }
            } else {
                testReport.setTotalRecordsErroedInErp("0");
                testReport.setTotalRecordsOicsError("0");
                testReport.replaceNoReject();
                testReport.replaceNoOicsError();
            }

            testReport.publishReportFinal(filename);
        }

    }

    private void readValuesFromProperties() throws IOException {

        erpQuery = applicationDetails.readProperties("com.uk.dlgds.ap.ActualQuery").trim();
        fshQuery = applicationDetails.readProperties("com.uk.dlgds.ap.FSHQuery").trim();
        rejectQuery = applicationDetails.readProperties("com.uk.dlgds.ap.reject").trim();

        fshFile = applicationDetails.readProperties("com.uk.dlgds.ap.fsh.file").trim();
        fshFileQuery = applicationDetails.readProperties("com.uk.dlgds.ap.FSHQuery.file").trim();
        fshFileQuery = fshFileQuery.replace(ApInvoiceConstants.SQL_AP_FILE_LIST, fshFile);

        fshDateQuery = applicationDetails.readProperties("com.uk.dlgds.ap.FSHQuery.date").trim();
        fshDate = applicationDetails.readProperties("com.uk.dlgds.ap.fsh.date").trim();
        fshDateQuery = fshDateQuery.replace(ApInvoiceConstants.SQL_DATE_STR, fshDate);


        String sqlSelect = applicationDetails.readProperties("com.uk.dlgds.ap.select.FSHQuery").trim();
        if (sqlSelect.equalsIgnoreCase(ApInvoiceConstants.SQL_DATE_SELECT))
            fshQuery = fshDateQuery;
        else if (sqlSelect.equalsIgnoreCase(ApInvoiceConstants.SQL_FILE_SELECT))
            fshQuery = fshFileQuery;

        String env = applicationDetails.readProperties("com.uk.dlgds.db.evn").trim();

        dbServer = applicationDetails.readProperties(String.format("com.uk.dlgds.%s.dbServer", env)).trim();
        dbUserName = applicationDetails.readProperties(String.format("com.uk.dlgds.%s.dbUserName", env)).trim();
        dbPassword = applicationDetails.readProperties(String.format("com.uk.dlgds.%s.dbPassword", env)).trim();

    }


}