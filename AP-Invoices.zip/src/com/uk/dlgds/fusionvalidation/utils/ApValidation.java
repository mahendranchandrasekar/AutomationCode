package com.uk.dlgds.fusionvalidation.utils;

import com.uk.dlgds.fusionvalidation.ApIntegrationTest;

import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class ApValidation {

    List<String> passList = new LinkedList<>();
    Map<String, List<String>> failList = new HashMap<>();

    public void validateApInvoice(List<ApInvoice> fshData, List<ApInvoice> erpData, TestReport testReport) throws IOException {
        List<ApInvoice> erpDataMatch;
        ApInvoice erp = new ApInvoice();
        List<String> mismatchField = new LinkedList<>();
        if (fshData.size() == erpData.size())
            System.out.println(":::: Count Match ::::");
        else
            System.out.println(":::: Count Mismatch ::::");


        erpData = erpData.parallelStream()
                .map(o -> {
                    if (o.getInvoiceAmount().trim().substring(0, 1).equals("."))
                        o.setInvoiceAmount("0" + o.getInvoiceAmount().trim());
                    if (o.getLineItemAmount().trim().substring(0, 1).equals("."))
                        o.setLineItemAmount("0" + o.getLineItemAmount().trim());
                    return o;
                })
                .collect(Collectors.toList());

        for (ApInvoice fsh : fshData) {
            //mismatchField = new LinkedList<>();

            int a;
            if (fsh.getInvoiceId().equalsIgnoreCase("50345220") || fsh.getInvoiceId().equalsIgnoreCase("50345392"))
                a = 10;


            erpDataMatch = erpData.stream()
                    .filter(o -> o.getInvoiceId().trim().equalsIgnoreCase(fsh.getInvoiceId().trim()))
                    .filter(o -> o.getLineItemAmount().trim().equalsIgnoreCase(fsh.getLineItemAmount().trim()))
                    .filter(o -> o.getInvoiceAmount().trim().equalsIgnoreCase(fsh.getInvoiceAmount().trim()))
                    .collect(Collectors.toList());


            if (erpDataMatch.size() > 1) {
                System.out.println(fsh.getInvoiceId() + " :::: Duplicate Value ::::");
                ApIntegrationTest.invoiceIdsNoError.add(fsh.getInvoiceId());
            } else if (erpDataMatch.size() == 1) {
                System.out.println(fsh.getInvoiceId() + " :::: No Duplicate Value ::::");
                ApIntegrationTest.invoiceIdsNoError.add(fsh.getInvoiceId());
            } else {
                System.out.println(fsh.getInvoiceId() + " :::: No Match Value ::::");
                ApIntegrationTest.invoiceIdsError.add(fsh.getInvoiceId());
                continue;
            }

            erp = erpDataMatch.get(0);


            testReport.successfulReport.setInvoiceIdFshValue(fsh.getInvoiceId());
            testReport.successfulReport.setBusinessUnitFshValue(fsh.getBusinessUnit());
            testReport.successfulReport.setSourceFshValue(fsh.getSource());
            testReport.successfulReport.setInvoiceNumFshValue(fsh.getInvoiceNum());
            testReport.successfulReport.setInvoiceAmountFshValue(fsh.getInvoiceAmount());
            testReport.successfulReport.setInvoiceDateFshValue(fsh.getInvoiceDate());
            testReport.successfulReport.setVendorNameFshValue(fsh.getVendorName());
            testReport.successfulReport.setVendorSiteCodeFshValue(fsh.getVendorSiteCode());
            testReport.successfulReport.setInvoiceCurrencyCodeFshValue(fsh.getInvoiceCurrencyCode());
            testReport.successfulReport.setDescriptionFshValue(fsh.getDescription());
            testReport.successfulReport.setInvoiceTypeFshValue(fsh.getInvoiceType());
            testReport.successfulReport.setPaymentTermsFshValue(fsh.getPaymentTerms());
            testReport.successfulReport.setInvoiceReceivedDateFshValue(fsh.getInvoiceReceivedDate());
            testReport.successfulReport.setFshTransactionDateFshValue(fsh.getFshTransactionDate());
            testReport.successfulReport.setPaymentMethodCodeFshValue(fsh.getPaymentMethodCode());
            testReport.successfulReport.setPayGroupLookupCodeFshValue(fsh.getPayGroupLookupCode());
            testReport.successfulReport.setExchangeRateTypeFshValue(fsh.getExchangeRateType());
            testReport.successfulReport.setExchangeEffectiveDateFshValue(fsh.getExchangeEffectiveDate());
            testReport.successfulReport.setExchangeRateFshValue(fsh.getExchangeRate());
            testReport.successfulReport.setPaymentPriorityFshValue(fsh.getPaymentPriority());
            testReport.successfulReport.setStationeryCodeFshValue(fsh.getStationeryCode());
            testReport.successfulReport.setCalcTaxDuringImportFlagFshValue(fsh.getCalcTaxDuringImportFlag());
            testReport.successfulReport.setAddTaxToInvoiceAmountFlagFshValue(fsh.getAddTaxToInvoiceAmountFlag());
            testReport.successfulReport.setAttributeCategoryFshValue(fsh.getAttributeCategory());
            testReport.successfulReport.setAttribute1FshValue(fsh.getAttribute1());
            testReport.successfulReport.setAttribute2FshValue(fsh.getAttribute2());
            testReport.successfulReport.setAttribute3FshValue(fsh.getAttribute3());
            testReport.successfulReport.setAttribute4FshValue(fsh.getAttribute4());
            testReport.successfulReport.setAttribute5FshValue(fsh.getAttribute5());
            testReport.successfulReport.setAttribute7FshValue(fsh.getAttribute7());
            testReport.successfulReport.setAttribute8FshValue(fsh.getAttribute8());
            testReport.successfulReport.setAttribute15FshValue(fsh.getAttribute15());
            testReport.successfulReport.setLineInvoiceIdFshValue(fsh.getLineInvoiceId());
            testReport.successfulReport.setLineNumberFshValue(fsh.getLineNumber());
            testReport.successfulReport.setLineTypeLookupCodeFshValue(fsh.getLineTypeLookupCode());
            testReport.successfulReport.setLineItemAmountFshValue(fsh.getLineItemAmount());
            testReport.successfulReport.setLineDescriptionFshValue(fsh.getLineDescription());
            testReport.successfulReport.setDistCodeConcatenatedFshValue(fsh.getDistCodeConcatenated());
            testReport.successfulReport.setTaxClassificationCodeFshValue(fsh.getTaxClassificationCode());
            testReport.successfulReport.setTaxRateCodeFshValue(fsh.getTaxRateCode());
            testReport.successfulReport.setProrateAcrossFlagFshValue(fsh.getProrateAcrossFlag());
            testReport.successfulReport.setLineGroupNumberFshValue(fsh.getLineGroupNumber());
            testReport.successfulReport.setAssetsTrackingFlagFshValue(fsh.getAssetsTrackingFlag());


            testReport.successfulReport.setInvoiceIdErpValue(erp.getInvoiceId());
            testReport.successfulReport.setBusinessUnitErpValue(erp.getBusinessUnit());
            testReport.successfulReport.setSourceErpValue(erp.getSource());
            testReport.successfulReport.setInvoiceNumErpValue(erp.getInvoiceNum());
            testReport.successfulReport.setInvoiceAmountErpValue(erp.getInvoiceAmount());
            testReport.successfulReport.setInvoiceDateErpValue(erp.getInvoiceDate());
            testReport.successfulReport.setVendorNameErpValue(erp.getVendorName());
            testReport.successfulReport.setVendorSiteCodeErpValue(erp.getVendorSiteCode());
            testReport.successfulReport.setInvoiceCurrencyCodeErpValue(erp.getInvoiceCurrencyCode());
            testReport.successfulReport.setDescriptionErpValue(erp.getDescription());
            testReport.successfulReport.setInvoiceTypeErpValue(erp.getInvoiceType());
            testReport.successfulReport.setPaymentTermsErpValue(erp.getPaymentTerms());
            testReport.successfulReport.setInvoiceReceivedDateErpValue(erp.getInvoiceReceivedDate());
            testReport.successfulReport.setFshTransactionDateErpValue(erp.getFshTransactionDate());
            testReport.successfulReport.setPaymentMethodCodeErpValue(erp.getPaymentMethodCode());
            testReport.successfulReport.setPayGroupLookupCodeErpValue(erp.getPayGroupLookupCode());
            testReport.successfulReport.setExchangeRateTypeErpValue(erp.getExchangeRateType());
            testReport.successfulReport.setExchangeEffectiveDateErpValue(erp.getExchangeEffectiveDate());
            testReport.successfulReport.setExchangeRateErpValue(erp.getExchangeRate());
            testReport.successfulReport.setPaymentPriorityErpValue(erp.getPaymentPriority());
            testReport.successfulReport.setStationeryCodeErpValue(erp.getStationeryCode());
            testReport.successfulReport.setCalcTaxDuringImportFlagErpValue(erp.getCalcTaxDuringImportFlag());
            testReport.successfulReport.setAddTaxToInvoiceAmountFlagErpValue(erp.getAddTaxToInvoiceAmountFlag());
            testReport.successfulReport.setAttributeCategoryErpValue(erp.getAttributeCategory());
            testReport.successfulReport.setAttribute1ErpValue(erp.getAttribute1());
            testReport.successfulReport.setAttribute2ErpValue(erp.getAttribute2());
            testReport.successfulReport.setAttribute3ErpValue(erp.getAttribute3());
            testReport.successfulReport.setAttribute4ErpValue(erp.getAttribute4());
            testReport.successfulReport.setAttribute5ErpValue(erp.getAttribute5());
            testReport.successfulReport.setAttribute7ErpValue(erp.getAttribute7());
            testReport.successfulReport.setAttribute8ErpValue(erp.getAttribute8());
            testReport.successfulReport.setAttribute15ErpValue(erp.getAttribute15());
            testReport.successfulReport.setLineInvoiceIdErpValue(erp.getLineInvoiceId());
            testReport.successfulReport.setLineNumberErpValue(erp.getLineNumber());
            testReport.successfulReport.setLineTypeLookupCodeErpValue(erp.getLineTypeLookupCode());
            testReport.successfulReport.setLineItemAmountErpValue(erp.getLineItemAmount());
            testReport.successfulReport.setLineDescriptionErpValue(erp.getLineDescription());
            testReport.successfulReport.setDistCodeConcatenatedErpValue(erp.getDistCodeConcatenated());
            testReport.successfulReport.setTaxClassificationCodeErpValue(erp.getTaxClassificationCode());
            testReport.successfulReport.setTaxRateCodeErpValue(erp.getTaxRateCode());
            testReport.successfulReport.setProrateAcrossFlagErpValue(erp.getProrateAcrossFlag());
            testReport.successfulReport.setLineGroupNumberErpValue(erp.getLineGroupNumber());
            testReport.successfulReport.setAssetsTrackingFlagErpValue(erp.getAssetsTrackingFlag());

            testReport.successfulReport.setInvoiceIdResultValue(TestReport.FAIL);
            testReport.successfulReport.setBusinessUnitResultValue(TestReport.FAIL);
            testReport.successfulReport.setSourceResultValue(TestReport.FAIL);
            testReport.successfulReport.setInvoiceNumResultValue(TestReport.FAIL);
            testReport.successfulReport.setInvoiceAmountResultValue(TestReport.FAIL);
            testReport.successfulReport.setInvoiceDateResultValue(TestReport.FAIL);
            testReport.successfulReport.setVendorNameResultValue(TestReport.FAIL);
            testReport.successfulReport.setVendorSiteCodeResultValue(TestReport.FAIL);
            testReport.successfulReport.setInvoiceCurrencyCodeResultValue(TestReport.FAIL);
            testReport.successfulReport.setDescriptionResultValue(TestReport.FAIL);
            testReport.successfulReport.setInvoiceTypeResultValue(TestReport.FAIL);
            testReport.successfulReport.setPaymentTermsResultValue(TestReport.FAIL);
            testReport.successfulReport.setInvoiceReceivedDateResultValue(TestReport.FAIL);
            testReport.successfulReport.setFshTransactionDateResultValue(TestReport.FAIL);
            testReport.successfulReport.setPaymentMethodCodeResultValue(TestReport.FAIL);
            testReport.successfulReport.setPayGroupLookupCodeResultValue(TestReport.FAIL);
            testReport.successfulReport.setExchangeRateTypeResultValue(TestReport.FAIL);
            testReport.successfulReport.setExchangeEffectiveDateResultValue(TestReport.FAIL);
            testReport.successfulReport.setExchangeRateResultValue(TestReport.FAIL);
            testReport.successfulReport.setPaymentPriorityResultValue(TestReport.FAIL);
            testReport.successfulReport.setStationeryCodeResultValue(TestReport.FAIL);
            testReport.successfulReport.setCalcTaxDuringImportFlagResultValue(TestReport.FAIL);
            testReport.successfulReport.setAddTaxToInvoiceAmountFlagResultValue(TestReport.FAIL);
            testReport.successfulReport.setAttributeCategoryResultValue(TestReport.FAIL);
            testReport.successfulReport.setAttribute1ResultValue(TestReport.FAIL);
            testReport.successfulReport.setAttribute2ResultValue(TestReport.FAIL);
            testReport.successfulReport.setAttribute3ResultValue(TestReport.FAIL);
            testReport.successfulReport.setAttribute4ResultValue(TestReport.FAIL);
            testReport.successfulReport.setAttribute5ResultValue(TestReport.FAIL);
            testReport.successfulReport.setAttribute7ResultValue(TestReport.FAIL);
            testReport.successfulReport.setAttribute8ResultValue(TestReport.FAIL);
            testReport.successfulReport.setAttribute15ResultValue(TestReport.FAIL);
            testReport.successfulReport.setLineInvoiceIdResultValue(TestReport.FAIL);
            testReport.successfulReport.setLineNumberResultValue(TestReport.FAIL);
            testReport.successfulReport.setLineTypeLookupCodeResultValue(TestReport.FAIL);
            testReport.successfulReport.setLineItemAmountResultValue(TestReport.FAIL);
            testReport.successfulReport.setLineDescriptionResultValue(TestReport.FAIL);
            testReport.successfulReport.setDistCodeConcatenatedResultValue(TestReport.FAIL);
            testReport.successfulReport.setTaxClassificationCodeResultValue(TestReport.FAIL);
            testReport.successfulReport.setTaxRateCodeResultValue(TestReport.FAIL);
            testReport.successfulReport.setProrateAcrossFlagResultValue(TestReport.FAIL);
            testReport.successfulReport.setLineGroupNumberResultValue(TestReport.FAIL);
            testReport.successfulReport.setAssetsTrackingFlagResultValue(TestReport.FAIL);

            if (erp.getInvoiceId().trim().equalsIgnoreCase(fsh.getInvoiceId().trim())) {
                testReport.successfulReport.setInvoiceIdResultValue(TestReport.PASS);
            }
            if (erp.getBusinessUnit().trim().equalsIgnoreCase(fsh.getBusinessUnit().trim())) {
                testReport.successfulReport.setBusinessUnitResultValue(TestReport.PASS);
            }
            if (erp.getSource().trim().equalsIgnoreCase(fsh.getSource().trim())) {
                testReport.successfulReport.setSourceResultValue(TestReport.PASS);
            }
            if (erp.getInvoiceNum().trim().equalsIgnoreCase(fsh.getInvoiceNum().trim())) {
                testReport.successfulReport.setInvoiceNumResultValue(TestReport.PASS);
            }
            if (erp.getInvoiceAmount().trim().equalsIgnoreCase(fsh.getInvoiceAmount().trim())) {
                testReport.successfulReport.setInvoiceAmountResultValue(TestReport.PASS);
            }
            if (erp.getInvoiceDate().trim().equalsIgnoreCase(fsh.getInvoiceDate().trim())) {
                testReport.successfulReport.setInvoiceDateResultValue(TestReport.PASS);
            }
            if (erp.getVendorName().trim().equalsIgnoreCase(fsh.getVendorName().trim())) {
                testReport.successfulReport.setVendorNameResultValue(TestReport.PASS);
            }
            if (erp.getVendorSiteCode().trim().equalsIgnoreCase(fsh.getVendorSiteCode().trim())) {
                testReport.successfulReport.setVendorSiteCodeResultValue(TestReport.PASS);
            }
            if (erp.getInvoiceCurrencyCode().trim().equalsIgnoreCase(fsh.getInvoiceCurrencyCode().trim())) {
                testReport.successfulReport.setInvoiceCurrencyCodeResultValue(TestReport.PASS);
            }
            if (erp.getDescription().trim().equalsIgnoreCase(fsh.getDescription().trim())) {
                testReport.successfulReport.setDescriptionResultValue(TestReport.PASS);
            }
            if (erp.getInvoiceType().trim().equalsIgnoreCase(fsh.getInvoiceType().trim())) {
                testReport.successfulReport.setInvoiceTypeResultValue(TestReport.PASS);
            }
            if (erp.getPaymentTerms().trim().equalsIgnoreCase(fsh.getPaymentTerms().trim())) {
                testReport.successfulReport.setPaymentTermsResultValue(TestReport.PASS);
            }
            if (erp.getInvoiceReceivedDate().trim().equalsIgnoreCase(fsh.getInvoiceReceivedDate().trim())) {
                testReport.successfulReport.setInvoiceReceivedDateResultValue(TestReport.PASS);
            }
            if (erp.getFshTransactionDate().trim().equalsIgnoreCase(fsh.getFshTransactionDate().trim())) {
                testReport.successfulReport.setFshTransactionDateResultValue(TestReport.PASS);
            }
            if (erp.getPaymentMethodCode().trim().equalsIgnoreCase(fsh.getPaymentMethodCode().trim())) {
                testReport.successfulReport.setPaymentMethodCodeResultValue(TestReport.PASS);
            }
            if (erp.getPayGroupLookupCode().trim().equalsIgnoreCase(fsh.getPayGroupLookupCode().trim())) {
                testReport.successfulReport.setPayGroupLookupCodeResultValue(TestReport.PASS);
            }
            if (erp.getExchangeRateType().trim().equalsIgnoreCase(fsh.getExchangeRateType().trim())) {
                testReport.successfulReport.setExchangeRateTypeResultValue(TestReport.PASS);
            }
            if (erp.getExchangeEffectiveDate().trim().equalsIgnoreCase(fsh.getExchangeEffectiveDate().trim())) {
                testReport.successfulReport.setExchangeEffectiveDateResultValue(TestReport.PASS);
            }
            if (erp.getExchangeRate().trim().equalsIgnoreCase(fsh.getExchangeRate().trim())) {
                testReport.successfulReport.setExchangeRateResultValue(TestReport.PASS);
            }
            if (erp.getPaymentPriority().trim().equalsIgnoreCase(fsh.getPaymentPriority().trim())) {
                testReport.successfulReport.setPaymentPriorityResultValue(TestReport.PASS);
            }
            if (erp.getStationeryCode().trim().equalsIgnoreCase(fsh.getStationeryCode().trim())) {
                testReport.successfulReport.setStationeryCodeResultValue(TestReport.PASS);
            }
            if (erp.getCalcTaxDuringImportFlag().trim().equalsIgnoreCase(fsh.getCalcTaxDuringImportFlag().trim())) {
                testReport.successfulReport.setCalcTaxDuringImportFlagResultValue(TestReport.PASS);
            }
            if (erp.getAddTaxToInvoiceAmountFlag().trim().equalsIgnoreCase(fsh.getAddTaxToInvoiceAmountFlag().trim())) {
                testReport.successfulReport.setAddTaxToInvoiceAmountFlagResultValue(TestReport.PASS);
            }
            if (erp.getAttributeCategory().trim().equalsIgnoreCase(fsh.getAttributeCategory().trim())) {
                testReport.successfulReport.setAttributeCategoryResultValue(TestReport.PASS);
            }
            if (erp.getAttribute1().trim().equalsIgnoreCase(fsh.getAttribute1().trim())) {
                testReport.successfulReport.setAttribute1ResultValue(TestReport.PASS);
            }
            if (erp.getAttribute2().trim().equalsIgnoreCase(fsh.getAttribute2().trim())) {
                testReport.successfulReport.setAttribute2ResultValue(TestReport.PASS);
            }
            if (erp.getAttribute3().trim().equalsIgnoreCase(fsh.getAttribute3().trim())) {
                testReport.successfulReport.setAttribute3ResultValue(TestReport.PASS);
            }
            if (erp.getAttribute4().trim().equalsIgnoreCase(fsh.getAttribute4().trim())) {
                testReport.successfulReport.setAttribute4ResultValue(TestReport.PASS);
            }
            if (erp.getAttribute5().trim().equalsIgnoreCase(fsh.getAttribute5().trim())) {
                testReport.successfulReport.setAttribute5ResultValue(TestReport.PASS);
            }
            if (erp.getAttribute7().trim().equalsIgnoreCase(fsh.getAttribute7().trim())) {
                testReport.successfulReport.setAttribute7ResultValue(TestReport.PASS);
            }
            if (erp.getAttribute8().trim().equalsIgnoreCase(fsh.getAttribute8().trim())) {
                testReport.successfulReport.setAttribute8ResultValue(TestReport.PASS);
            }
            if (erp.getAttribute15().trim().equalsIgnoreCase(fsh.getAttribute15().trim())) {
                testReport.successfulReport.setAttribute15ResultValue(TestReport.PASS);
            }
            if (erp.getLineInvoiceId().trim().equalsIgnoreCase(fsh.getLineInvoiceId().trim())) {
                testReport.successfulReport.setLineInvoiceIdResultValue(TestReport.PASS);
            }
            if (erp.getLineNumber().trim().equalsIgnoreCase(fsh.getLineNumber().trim())) {
                testReport.successfulReport.setLineNumberResultValue(TestReport.PASS);
            }
            if (erp.getLineTypeLookupCode().trim().equalsIgnoreCase(fsh.getLineTypeLookupCode().trim())) {
                testReport.successfulReport.setLineTypeLookupCodeResultValue(TestReport.PASS);
            }
            if (erp.getLineItemAmount().trim().equalsIgnoreCase(fsh.getLineItemAmount().trim())) {
                testReport.successfulReport.setLineItemAmountResultValue(TestReport.PASS);
            }
            if (erp.getLineDescription().trim().equalsIgnoreCase(fsh.getLineDescription().trim())) {
                testReport.successfulReport.setLineDescriptionResultValue(TestReport.PASS);
            }
            if (erp.getDistCodeConcatenated().trim().equalsIgnoreCase(fsh.getDistCodeConcatenated().trim())) {
                testReport.successfulReport.setDistCodeConcatenatedResultValue(TestReport.PASS);
            }
            if (erp.getTaxClassificationCode().trim().equalsIgnoreCase(fsh.getTaxClassificationCode().trim())) {
                testReport.successfulReport.setTaxClassificationCodeResultValue(TestReport.PASS);
            }
            if (erp.getTaxRateCode().trim().equalsIgnoreCase(fsh.getTaxRateCode().trim())) {
                testReport.successfulReport.setTaxRateCodeResultValue(TestReport.PASS);
            }
            if (erp.getProrateAcrossFlag().trim().equalsIgnoreCase(fsh.getProrateAcrossFlag().trim())) {
                testReport.successfulReport.setProrateAcrossFlagResultValue(TestReport.PASS);
            }
            if (erp.getLineGroupNumber().trim().equalsIgnoreCase(fsh.getLineGroupNumber().trim())) {
                testReport.successfulReport.setLineGroupNumberResultValue(TestReport.PASS);
            }
            if (erp.getAssetsTrackingFlag().trim().equalsIgnoreCase(fsh.getAssetsTrackingFlag().trim())) {
                testReport.successfulReport.setAssetsTrackingFlagResultValue(TestReport.PASS);
            }

//
//            if (mismatchField.isEmpty()) {
//                passList.add(erp.getInvoiceId());
//                String passMsg = String.format(" %s :: Pass ", erp.getInvoiceId());
//                ApIntegrationTest.invoiceIdsError.add(erp.getInvoiceId());
//                System.out.println(passMsg);
//            } else {
//                String failMsg = String.format(" %s :: Fail due to Data mismatch in %s", erp.getInvoiceId(), String.join(", ", mismatchField));
//                System.out.println(failMsg);
//                failList.put(erp.getInvoiceId(), mismatchField);
//                ApIntegrationTest.invoiceIdsError.add(erp.getInvoiceId());
//            }

            testReport.replaceSuccessful();
        }


    }

}
