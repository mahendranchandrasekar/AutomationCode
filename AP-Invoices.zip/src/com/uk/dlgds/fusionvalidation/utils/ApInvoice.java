package com.uk.dlgds.fusionvalidation.utils;

public class ApInvoice {

    private String invoiceId;
    private String businessUnit;
    private String source;
    private String invoiceNum;
    private String invoiceAmount;
    private String invoiceDate;
    private String vendorName;
    private String vendorSiteCode;
    private String invoiceCurrencyCode;
    private String description;
    private String invoiceType;
    private String paymentTerms;
    private String invoiceReceivedDate;
    private String fshTransactionDate;
    private String paymentMethodCode;
    private String payGroupLookupCode;
    private String exchangeRateType;
    private String exchangeEffectiveDate;
    private String exchangeRate;
    private String paymentPriority;
    private String stationeryCode;
    private String calcTaxDuringImportFlag;
    private String addTaxToInvoiceAmountFlag;
    private String attributeCategory;
    private String attribute1;
    private String attribute2;
    private String attribute3;
    private String attribute4;
    private String attribute5;
    private String attribute7;
    private String attribute8;
    private String attribute15;
    private String lineInvoiceId;
    private String lineNumber;
    private String lineTypeLookupCode;
    private String lineItemAmount;
    private String lineDescription;
    private String distCodeConcatenated;
    private String taxClassificationCode;
    private String taxRateCode;
    private String prorateAcrossFlag;
    private String lineGroupNumber;
    private String assetsTrackingFlag;
    private String fileName;
    private String source1;
    private String loadDate;

    public String getInvoiceId() {
        return invoiceId;
    }

    public String getBusinessUnit() {
        return businessUnit;
    }

    public String getSource() {
        return source;
    }

    public String getInvoiceNum() {
        return invoiceNum;
    }

    public String getInvoiceAmount() {
        return invoiceAmount;
    }

    public String getInvoiceDate() {
        return invoiceDate;
    }

    public String getVendorName() {
        return vendorName;
    }

    public String getVendorSiteCode() {
        return vendorSiteCode;
    }

    public String getInvoiceCurrencyCode() {
        return invoiceCurrencyCode;
    }

    public String getDescription() {
        return description;
    }

    public String getInvoiceType() {
        return invoiceType;
    }

    public String getPaymentTerms() {
        return paymentTerms;
    }

    public String getInvoiceReceivedDate() {
        return invoiceReceivedDate;
    }

    public String getFshTransactionDate() {
        return fshTransactionDate;
    }

    public String getPaymentMethodCode() {
        return paymentMethodCode;
    }

    public String getPayGroupLookupCode() {
        return payGroupLookupCode;
    }

    public String getExchangeRateType() {
        return exchangeRateType;
    }

    public String getExchangeEffectiveDate() {
        return exchangeEffectiveDate;
    }

    public String getExchangeRate() {
        return exchangeRate;
    }

    public String getPaymentPriority() {
        return paymentPriority;
    }

    public String getStationeryCode() {
        return stationeryCode;
    }

    public String getCalcTaxDuringImportFlag() {
        return calcTaxDuringImportFlag;
    }

    public String getAddTaxToInvoiceAmountFlag() {
        return addTaxToInvoiceAmountFlag;
    }

    public String getAttributeCategory() {
        return attributeCategory;
    }

    public String getAttribute1() {
        return attribute1;
    }

    public String getAttribute2() {
        return attribute2;
    }

    public String getAttribute3() {
        return attribute3;
    }

    public String getAttribute4() {
        return attribute4;
    }

    public String getAttribute5() {
        return attribute5;
    }

    public String getAttribute7() {
        return attribute7;
    }

    public String getAttribute8() {
        return attribute8;
    }

    public String getAttribute15() {
        return attribute15;
    }

    public String getLineInvoiceId() {
        return lineInvoiceId;
    }

    public String getLineNumber() {
        return lineNumber;
    }

    public String getLineTypeLookupCode() {
        return lineTypeLookupCode;
    }

    public String getLineItemAmount() {
        return lineItemAmount;
    }

    public String getLineDescription() {
        return lineDescription;
    }

    public String getDistCodeConcatenated() {
        return distCodeConcatenated;
    }

    public String getTaxClassificationCode() {
        return taxClassificationCode;
    }

    public String getTaxRateCode() {
        return taxRateCode;
    }

    public String getProrateAcrossFlag() {
        return prorateAcrossFlag;
    }

    public String getLineGroupNumber() {
        return lineGroupNumber;
    }

    public String getAssetsTrackingFlag() {
        return assetsTrackingFlag;
    }

    public String getFileName() {
        return fileName;
    }

    public String getSource1() {
        return source1;
    }

    public String getLoadDate() {
        return loadDate;
    }

    public void setInvoiceId(String invoiceId) {
        this.invoiceId = invoiceId;
    }

    public void setBusinessUnit(String businessUnit) {
        this.businessUnit = businessUnit;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public void setInvoiceNum(String invoiceNum) {
        this.invoiceNum = invoiceNum;
    }

    public void setInvoiceAmount(String invoiceAmount) {
        this.invoiceAmount = invoiceAmount;
    }

    public void setInvoiceDate(String invoiceDate) {
        this.invoiceDate = invoiceDate;
    }

    public void setVendorName(String vendorName) {
        this.vendorName = vendorName;
    }

    public void setVendorSiteCode(String vendorSiteCode) {
        this.vendorSiteCode = vendorSiteCode;
    }

    public void setInvoiceCurrencyCode(String invoiceCurrencyCode) {
        this.invoiceCurrencyCode = invoiceCurrencyCode;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setInvoiceType(String invoiceType) {
        this.invoiceType = invoiceType;
    }

    public void setPaymentTerms(String paymentTerms) {
        this.paymentTerms = paymentTerms;
    }

    public void setInvoiceReceivedDate(String invoiceReceivedDate) {
        this.invoiceReceivedDate = invoiceReceivedDate;
    }

    public void setFshTransactionDate(String fshTransactionDate) {
        this.fshTransactionDate = fshTransactionDate;
    }

    public void setPaymentMethodCode(String paymentMethodCode) {
        this.paymentMethodCode = paymentMethodCode;
    }

    public void setPayGroupLookupCode(String payGroupLookupCode) {
        this.payGroupLookupCode = payGroupLookupCode;
    }

    public void setExchangeRateType(String exchangeRateType) {
        this.exchangeRateType = exchangeRateType;
    }

    public void setExchangeEffectiveDate(String exchangeEffectiveDate) {
        this.exchangeEffectiveDate = exchangeEffectiveDate;
    }

    public void setExchangeRate(String exchangeRate) {
        this.exchangeRate = exchangeRate;
    }

    public void setPaymentPriority(String paymentPriority) {
        this.paymentPriority = paymentPriority;
    }

    public void setStationeryCode(String stationeryCode) {
        this.stationeryCode = stationeryCode;
    }

    public void setCalcTaxDuringImportFlag(String calcTaxDuringImportFlag) {
        this.calcTaxDuringImportFlag = calcTaxDuringImportFlag;
    }

    public void setAddTaxToInvoiceAmountFlag(String addTaxToInvoiceAmountFlag) {
        this.addTaxToInvoiceAmountFlag = addTaxToInvoiceAmountFlag;
    }

    public void setAttributeCategory(String attributeCategory) {
        this.attributeCategory = attributeCategory;
    }

    public void setAttribute1(String attribute1) {
        this.attribute1 = attribute1;
    }

    public void setAttribute2(String attribute2) {
        this.attribute2 = attribute2;
    }

    public void setAttribute3(String attribute3) {
        this.attribute3 = attribute3;
    }

    public void setAttribute4(String attribute4) {
        this.attribute4 = attribute4;
    }

    public void setAttribute5(String attribute5) {
        this.attribute5 = attribute5;
    }

    public void setAttribute7(String attribute7) {
        this.attribute7 = attribute7;
    }

    public void setAttribute8(String attribute8) {
        this.attribute8 = attribute8;
    }

    public void setAttribute15(String attribute15) {
        this.attribute15 = attribute15;
    }

    public void setLineInvoiceId(String lineInvoiceId) {
        this.lineInvoiceId = lineInvoiceId;
    }

    public void setLineNumber(String lineNumber) {
        this.lineNumber = lineNumber;
    }

    public void setLineTypeLookupCode(String lineTypeLookupCode) {
        this.lineTypeLookupCode = lineTypeLookupCode;
    }

    public void setLineItemAmount(String lineItemAmount) {
        this.lineItemAmount = lineItemAmount;
    }

    public void setLineDescription(String lineDescription) {
        this.lineDescription = lineDescription;
    }

    public void setDistCodeConcatenated(String distCodeConcatenated) {
        this.distCodeConcatenated = distCodeConcatenated;
    }

    public void setTaxClassificationCode(String taxClassificationCode) {
        this.taxClassificationCode = taxClassificationCode;
    }

    public void setTaxRateCode(String taxRateCode) {
        this.taxRateCode = taxRateCode;
    }

    public void setProrateAcrossFlag(String prorateAcrossFlag) {
        this.prorateAcrossFlag = prorateAcrossFlag;
    }

    public void setLineGroupNumber(String lineGroupNumber) {
        this.lineGroupNumber = lineGroupNumber;
    }

    public void setAssetsTrackingFlag(String assetsTrackingFlag) {
        this.assetsTrackingFlag = assetsTrackingFlag;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public void setSource1(String source1) {
        this.source1 = source1;
    }

    public void setLoadDate(String loadDate) {
        this.loadDate = loadDate;
    }
}
