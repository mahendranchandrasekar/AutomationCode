package com.uk.dlgds.fusionvalidation.utils;

public class ApInvoiceConstants {

    public static final String AP_FSH_DB_OUTPUT_FILE_PATH = "./src/com/uk/dlgds/fusionvalidation/resources/files/FshDbOutputRecordSet.csv";
    public static final String SQL_TEMP_FILE = "./src/com/uk/dlgds/fusionvalidation/resources/files/temp.csv";
    public static final String SQL_DATE_STR = "##DATE##";
    public static final String SQL_INVOICE_ID_STR = "##INVOICE_ID##";
    public static final String SQL_INVOICE_ID_SELECT = "invoiceId";
    public static final String SQL_DATE_SELECT = "date";
    public static final String SQL_FILE_SELECT = "file";
    public static final String SQL_AP_FILE_LIST = "##AP_FILE_LIST##";


    public static final int INVOICE_ID = 1;
    public static final int BUSINESS_UNIT = 2;
    public static final int SOURCE = 3;
    public static final int INVOICE_NUM = 4;
    public static final int INVOICE_AMOUNT = 5;
    public static final int INVOICE_DATE = 6;
    public static final int VENDOR_NAME = 7;
    public static final int VENDOR_SITE_CODE = 8;
    public static final int INVOICE_CURRENCY_CODE = 9;
    public static final int DESCRIPTION = 10;
    public static final int INVOICE_TYPE = 11;
    public static final int PAYMENT_TERMS = 12;
    public static final int INVOICE_RECEIVED_DATE = 13;
    public static final int FSH_TRANSACTION_DATE = 14;
    public static final int PAYMENT_METHOD_CODE = 15;
    public static final int PAY_GROUP_LOOKUP_CODE = 16;
    public static final int EXCHANGE_RATE_TYPE = 17;
    public static final int EXCHANGE_EFFECTIVE_DATE = 18;
    public static final int EXCHANGE_RATE = 19;
    public static final int PAYMENT_PRIORITY = 20;
    public static final int STATIONERY_CODE = 21;
    public static final int CALC_TAX_DURING_IMPORT_FLAG = 22;
    public static final int ADD_TAX_TO_INVOICE_AMOUNT_FLAG = 23;
    public static final int ATTRIBUTE_CATEGORY = 24;
    public static final int ATTRIBUTE1 = 25;
    public static final int ATTRIBUTE2 = 26;
    public static final int ATTRIBUTE3 = 27;
    public static final int ATTRIBUTE4 = 28;
    public static final int ATTRIBUTE5 = 29;
    public static final int ATTRIBUTE7 = 30;
    public static final int ATTRIBUTE8 = 31;
    public static final int ATTRIBUTE15 = 32;
    public static final int LINE_INVOICE_ID = 33;
    public static final int LINE_NUMBER = 34;
    public static final int LINE_TYPE_LOOKUP_CODE = 35;
    public static final int LINE_ITEM_AMOUNT = 36;
    public static final int LINE_DESCRIPTION = 37;
    public static final int DIST_CODE_CONCATENATED = 38;
    public static final int TAX_CLASSIFICATION_CODE = 39;
    public static final int TAX_RATE_CODE = 40;
    public static final int PRORATE_ACROSS_FLAG = 41;
    public static final int LINE_GROUP_NUMBER = 42;
    public static final int ASSETS_TRACKING_FLAG = 43;
    public static final int FILE_NAME = 44;
    public static final int SOURCE1 = 45;
    public static final int LOAD_DATE = 46;


}
