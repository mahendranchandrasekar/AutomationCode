package com.uk.dlgds.fusionvalidation.utils;

import java.util.HashMap;
import java.util.Map;

public class SuccessfulReport {

    protected Map<String, String> replaceValueMap = new HashMap<>();
    private String invoiceIdFshValue;
    private String businessUnitFshValue;
    private String sourceFshValue;
    private String invoiceNumFshValue;
    private String invoiceAmountFshValue;
    private String invoiceDateFshValue;
    private String vendorNameFshValue;
    private String vendorSiteCodeFshValue;
    private String invoiceCurrencyCodeFshValue;
    private String descriptionFshValue;
    private String invoiceTypeFshValue;
    private String paymentTermsFshValue;
    private String invoiceReceivedDateFshValue;
    private String fshTransactionDateFshValue;
    private String paymentMethodCodeFshValue;
    private String payGroupLookupCodeFshValue;
    private String exchangeRateTypeFshValue;
    private String exchangeEffectiveDateFshValue;
    private String exchangeRateFshValue;
    private String paymentPriorityFshValue;
    private String stationeryCodeFshValue;
    private String calcTaxDuringImportFlagFshValue;
    private String addTaxToInvoiceAmountFlagFshValue;
    private String attributeCategoryFshValue;
    private String attribute1FshValue;
    private String attribute2FshValue;
    private String attribute3FshValue;
    private String attribute4FshValue;
    private String attribute5FshValue;
    private String attribute7FshValue;
    private String attribute8FshValue;
    private String attribute15FshValue;
    private String lineInvoiceIdFshValue;
    private String lineNumberFshValue;
    private String lineTypeLookupCodeFshValue;
    private String lineItemAmountFshValue;
    private String lineDescriptionFshValue;
    private String distCodeConcatenatedFshValue;
    private String taxClassificationCodeFshValue;
    private String taxRateCodeFshValue;
    private String prorateAcrossFlagFshValue;
    private String lineGroupNumberFshValue;
    private String assetsTrackingFlagFshValue;


    private String invoiceIdErpValue;
    private String businessUnitErpValue;
    private String sourceErpValue;
    private String invoiceNumErpValue;
    private String invoiceAmountErpValue;
    private String invoiceDateErpValue;
    private String vendorNameErpValue;
    private String vendorSiteCodeErpValue;
    private String invoiceCurrencyCodeErpValue;
    private String descriptionErpValue;
    private String invoiceTypeErpValue;
    private String paymentTermsErpValue;
    private String invoiceReceivedDateErpValue;
    private String fshTransactionDateErpValue;
    private String paymentMethodCodeErpValue;
    private String payGroupLookupCodeErpValue;
    private String exchangeRateTypeErpValue;
    private String exchangeEffectiveDateErpValue;
    private String exchangeRateErpValue;
    private String paymentPriorityErpValue;
    private String stationeryCodeErpValue;
    private String calcTaxDuringImportFlagErpValue;
    private String addTaxToInvoiceAmountFlagErpValue;
    private String attributeCategoryErpValue;
    private String attribute1ErpValue;
    private String attribute2ErpValue;
    private String attribute3ErpValue;
    private String attribute4ErpValue;
    private String attribute5ErpValue;
    private String attribute7ErpValue;
    private String attribute8ErpValue;
    private String attribute15ErpValue;
    private String lineInvoiceIdErpValue;
    private String lineNumberErpValue;
    private String lineTypeLookupCodeErpValue;
    private String lineItemAmountErpValue;
    private String lineDescriptionErpValue;
    private String distCodeConcatenatedErpValue;
    private String taxClassificationCodeErpValue;
    private String taxRateCodeErpValue;
    private String prorateAcrossFlagErpValue;
    private String lineGroupNumberErpValue;
    private String assetsTrackingFlagErpValue;

    private String invoiceIdResultValue;
    private String businessUnitResultValue;
    private String sourceResultValue;
    private String invoiceNumResultValue;
    private String invoiceAmountResultValue;
    private String invoiceDateResultValue;
    private String vendorNameResultValue;
    private String vendorSiteCodeResultValue;
    private String invoiceCurrencyCodeResultValue;
    private String descriptionResultValue;
    private String invoiceTypeResultValue;
    private String paymentTermsResultValue;
    private String invoiceReceivedDateResultValue;
    private String fshTransactionDateResultValue;
    private String paymentMethodCodeResultValue;
    private String payGroupLookupCodeResultValue;
    private String exchangeRateTypeResultValue;
    private String exchangeEffectiveDateResultValue;
    private String exchangeRateResultValue;
    private String paymentPriorityResultValue;
    private String stationeryCodeResultValue;
    private String calcTaxDuringImportFlagResultValue;
    private String addTaxToInvoiceAmountFlagResultValue;
    private String attributeCategoryResultValue;
    private String attribute1ResultValue;
    private String attribute2ResultValue;
    private String attribute3ResultValue;
    private String attribute4ResultValue;
    private String attribute5ResultValue;
    private String attribute7ResultValue;
    private String attribute8ResultValue;
    private String attribute15ResultValue;
    private String lineInvoiceIdResultValue;
    private String lineNumberResultValue;
    private String lineTypeLookupCodeResultValue;
    private String lineItemAmountResultValue;
    private String lineDescriptionResultValue;
    private String distCodeConcatenatedResultValue;
    private String taxClassificationCodeResultValue;
    private String taxRateCodeResultValue;
    private String prorateAcrossFlagResultValue;
    private String lineGroupNumberResultValue;
    private String assetsTrackingFlagResultValue;


    public void setInvoiceIdFshValue(String invoiceIdFshValue) {
        this.invoiceIdFshValue = invoiceIdFshValue;
        replaceValueMap.put("##SUCCESSFUL_INVOICE_ID_FSH_VALUE##", this.invoiceIdFshValue);
    }

    public void setBusinessUnitFshValue(String businessUnitFshValue) {
        this.businessUnitFshValue = businessUnitFshValue;
        replaceValueMap.put("##SUCCESSFUL_BUSINESS_UNIT_FSH_VALUE##", this.businessUnitFshValue);
    }

    public void setSourceFshValue(String sourceFshValue) {
        this.sourceFshValue = sourceFshValue;
        replaceValueMap.put("##SUCCESSFUL_SOURCE_FSH_VALUE##", this.sourceFshValue);
    }

    public void setInvoiceNumFshValue(String invoiceNumFshValue) {
        this.invoiceNumFshValue = invoiceNumFshValue;
        replaceValueMap.put("##SUCCESSFUL_INVOICE_NUM_FSH_VALUE##", this.invoiceNumFshValue);
    }

    public void setInvoiceAmountFshValue(String invoiceAmountFshValue) {
        this.invoiceAmountFshValue = invoiceAmountFshValue;
        replaceValueMap.put("##SUCCESSFUL_INVOICE_AMOUNT_FSH_VALUE##", this.invoiceAmountFshValue);
    }

    public void setInvoiceDateFshValue(String invoiceDateFshValue) {
        this.invoiceDateFshValue = invoiceDateFshValue;
        replaceValueMap.put("##SUCCESSFUL_INVOICE_DATE_FSH_VALUE##", this.invoiceDateFshValue);
    }

    public void setVendorNameFshValue(String vendorNameFshValue) {
        this.vendorNameFshValue = vendorNameFshValue;
        replaceValueMap.put("##SUCCESSFUL_VENDOR_NAME_FSH_VALUE##", this.vendorNameFshValue);
    }

    public void setVendorSiteCodeFshValue(String vendorSiteCodeFshValue) {
        this.vendorSiteCodeFshValue = vendorSiteCodeFshValue;
        replaceValueMap.put("##SUCCESSFUL_VENDOR_SITE_CODE_FSH_VALUE##", this.vendorSiteCodeFshValue);
    }

    public void setInvoiceCurrencyCodeFshValue(String invoiceCurrencyCodeFshValue) {
        this.invoiceCurrencyCodeFshValue = invoiceCurrencyCodeFshValue;
        replaceValueMap.put("##SUCCESSFUL_INVOICE_CURRENCY_CODE_FSH_VALUE##", this.invoiceCurrencyCodeFshValue);
    }

    public void setDescriptionFshValue(String descriptionFshValue) {
        this.descriptionFshValue = descriptionFshValue;
        replaceValueMap.put("##SUCCESSFUL_DESCRIPTION_FSH_VALUE##", this.descriptionFshValue);
    }

    public void setInvoiceTypeFshValue(String invoiceTypeFshValue) {
        this.invoiceTypeFshValue = invoiceTypeFshValue;
        replaceValueMap.put("##SUCCESSFUL_INVOICE_TYPE_FSH_VALUE##", this.invoiceTypeFshValue);
    }

    public void setPaymentTermsFshValue(String paymentTermsFshValue) {
        this.paymentTermsFshValue = paymentTermsFshValue;
        replaceValueMap.put("##SUCCESSFUL_PAYMENT_TERMS_FSH_VALUE##", this.paymentTermsFshValue);
    }

    public void setInvoiceReceivedDateFshValue(String invoiceReceivedDateFshValue) {
        this.invoiceReceivedDateFshValue = invoiceReceivedDateFshValue;
        replaceValueMap.put("##SUCCESSFUL_INVOICE_RECEIVED_DATE_FSH_VALUE##", this.invoiceReceivedDateFshValue);
    }

    public void setFshTransactionDateFshValue(String fshTransactionDateFshValue) {
        this.fshTransactionDateFshValue = fshTransactionDateFshValue;
        replaceValueMap.put("##SUCCESSFUL_FSH_TRANSACTION_DATE_FSH_VALUE##", this.fshTransactionDateFshValue);
    }

    public void setPaymentMethodCodeFshValue(String paymentMethodCodeFshValue) {
        this.paymentMethodCodeFshValue = paymentMethodCodeFshValue;
        replaceValueMap.put("##SUCCESSFUL_PAYMENT_METHOD_CODE_FSH_VALUE##", this.paymentMethodCodeFshValue);
    }

    public void setPayGroupLookupCodeFshValue(String payGroupLookupCodeFshValue) {
        this.payGroupLookupCodeFshValue = payGroupLookupCodeFshValue;
        replaceValueMap.put("##SUCCESSFUL_PAY_GROUP_LOOKUP_CODE_FSH_VALUE##", this.payGroupLookupCodeFshValue);
    }

    public void setExchangeRateTypeFshValue(String exchangeRateTypeFshValue) {
        this.exchangeRateTypeFshValue = exchangeRateTypeFshValue;
        replaceValueMap.put("##SUCCESSFUL_EXCHANGE_RATE_TYPE_FSH_VALUE##", this.exchangeRateTypeFshValue);
    }

    public void setExchangeEffectiveDateFshValue(String exchangeEffectiveDateFshValue) {
        this.exchangeEffectiveDateFshValue = exchangeEffectiveDateFshValue;
        replaceValueMap.put("##SUCCESSFUL_EXCHANGE_EFFECTIVE_DATE_FSH_VALUE##", this.exchangeEffectiveDateFshValue);
    }

    public void setExchangeRateFshValue(String exchangeRateFshValue) {
        this.exchangeRateFshValue = exchangeRateFshValue;
        replaceValueMap.put("##SUCCESSFUL_EXCHANGE_RATE_FSH_VALUE##", this.exchangeRateFshValue);
    }

    public void setPaymentPriorityFshValue(String paymentPriorityFshValue) {
        this.paymentPriorityFshValue = paymentPriorityFshValue;
        replaceValueMap.put("##SUCCESSFUL_PAYMENT_PRIORITY_FSH_VALUE##", this.paymentPriorityFshValue);
    }

    public void setStationeryCodeFshValue(String stationeryCodeFshValue) {
        this.stationeryCodeFshValue = stationeryCodeFshValue;
        replaceValueMap.put("##SUCCESSFUL_STATIONERY_CODE_FSH_VALUE##", this.stationeryCodeFshValue);
    }

    public void setCalcTaxDuringImportFlagFshValue(String calcTaxDuringImportFlagFshValue) {
        this.calcTaxDuringImportFlagFshValue = calcTaxDuringImportFlagFshValue;
        replaceValueMap.put("##SUCCESSFUL_CALC_TAX_DURING_IMPORT_FLAG_FSH_VALUE##", this.calcTaxDuringImportFlagFshValue);
    }

    public void setAddTaxToInvoiceAmountFlagFshValue(String addTaxToInvoiceAmountFlagFshValue) {
        this.addTaxToInvoiceAmountFlagFshValue = addTaxToInvoiceAmountFlagFshValue;
        replaceValueMap.put("##SUCCESSFUL_ADD_TAX_TO_INVOICE_AMOUNT_FLAG_FSH_VALUE##", this.addTaxToInvoiceAmountFlagFshValue);
    }

    public void setAttributeCategoryFshValue(String attributeCategoryFshValue) {
        this.attributeCategoryFshValue = attributeCategoryFshValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE_CATEGORY_FSH_VALUE##", this.attributeCategoryFshValue);
    }

    public void setAttribute1FshValue(String attribute1FshValue) {
        this.attribute1FshValue = attribute1FshValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE1_FSH_VALUE##", this.attribute1FshValue);
    }

    public void setAttribute2FshValue(String attribute2FshValue) {
        this.attribute2FshValue = attribute2FshValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE2_FSH_VALUE##", this.attribute2FshValue);
    }

    public void setAttribute3FshValue(String attribute3FshValue) {
        this.attribute3FshValue = attribute3FshValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE3_FSH_VALUE##", this.attribute3FshValue);
    }

    public void setAttribute4FshValue(String attribute4FshValue) {
        this.attribute4FshValue = attribute4FshValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE4_FSH_VALUE##", this.attribute4FshValue);
    }

    public void setAttribute5FshValue(String attribute5FshValue) {
        this.attribute5FshValue = attribute5FshValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE5_FSH_VALUE##", this.attribute5FshValue);
    }

    public void setAttribute7FshValue(String attribute7FshValue) {
        this.attribute7FshValue = attribute7FshValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE7_FSH_VALUE##", this.attribute7FshValue);
    }

    public void setAttribute8FshValue(String attribute8FshValue) {
        this.attribute8FshValue = attribute8FshValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE8_FSH_VALUE##", this.attribute8FshValue);
    }

    public void setAttribute15FshValue(String attribute15FshValue) {
        this.attribute15FshValue = attribute15FshValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE15_FSH_VALUE##", this.attribute15FshValue);
    }

    public void setLineInvoiceIdFshValue(String lineInvoiceIdFshValue) {
        this.lineInvoiceIdFshValue = lineInvoiceIdFshValue;
        replaceValueMap.put("##SUCCESSFUL_LINE_INVOICE_ID_FSH_VALUE##", this.lineInvoiceIdFshValue);
    }

    public void setLineNumberFshValue(String lineNumberFshValue) {
        this.lineNumberFshValue = lineNumberFshValue;
        replaceValueMap.put("##SUCCESSFUL_LINE_NUMBER_FSH_VALUE##", this.lineNumberFshValue);
    }

    public void setLineTypeLookupCodeFshValue(String lineTypeLookupCodeFshValue) {
        this.lineTypeLookupCodeFshValue = lineTypeLookupCodeFshValue;
        replaceValueMap.put("##SUCCESSFUL_LINE_TYPE_LOOKUP_CODE_FSH_VALUE##", this.lineTypeLookupCodeFshValue);
    }

    public void setLineItemAmountFshValue(String lineItemAmountFshValue) {
        this.lineItemAmountFshValue = lineItemAmountFshValue;
        replaceValueMap.put("##SUCCESSFUL_LINE_ITEM_AMOUNT_FSH_VALUE##", this.lineItemAmountFshValue);
    }

    public void setLineDescriptionFshValue(String lineDescriptionFshValue) {
        this.lineDescriptionFshValue = lineDescriptionFshValue;
        replaceValueMap.put("##SUCCESSFUL_LINE_DESCRIPTION_FSH_VALUE##", this.lineDescriptionFshValue);
    }

    public void setDistCodeConcatenatedFshValue(String distCodeConcatenatedFshValue) {
        this.distCodeConcatenatedFshValue = distCodeConcatenatedFshValue;
        replaceValueMap.put("##SUCCESSFUL_DIST_CODE_CONCATENATED_FSH_VALUE##", this.distCodeConcatenatedFshValue);
    }

    public void setTaxClassificationCodeFshValue(String taxClassificationCodeFshValue) {
        this.taxClassificationCodeFshValue = taxClassificationCodeFshValue;
        replaceValueMap.put("##SUCCESSFUL_TAX_CLASSIFICATION_CODE_FSH_VALUE##", this.taxClassificationCodeFshValue);
    }

    public void setTaxRateCodeFshValue(String taxRateCodeFshValue) {
        this.taxRateCodeFshValue = taxRateCodeFshValue;
        replaceValueMap.put("##SUCCESSFUL_TAX_RATE_CODE_FSH_VALUE##", this.taxRateCodeFshValue);
    }

    public void setProrateAcrossFlagFshValue(String prorateAcrossFlagFshValue) {
        this.prorateAcrossFlagFshValue = prorateAcrossFlagFshValue;
        replaceValueMap.put("##SUCCESSFUL_PRORATE_ACROSS_FLAG_FSH_VALUE##", this.prorateAcrossFlagFshValue);
    }

    public void setLineGroupNumberFshValue(String lineGroupNumberFshValue) {
        this.lineGroupNumberFshValue = lineGroupNumberFshValue;
        replaceValueMap.put("##SUCCESSFUL_LINE_GROUP_NUMBER_FSH_VALUE##", this.lineGroupNumberFshValue);
    }

    public void setAssetsTrackingFlagFshValue(String assetsTrackingFlagFshValue) {
        this.assetsTrackingFlagFshValue = assetsTrackingFlagFshValue;
        replaceValueMap.put("##SUCCESSFUL_ASSETS_TRACKING_FLAG_FSH_VALUE##", this.assetsTrackingFlagFshValue);
    }

    public void setInvoiceIdErpValue(String invoiceIdErpValue) {
        this.invoiceIdErpValue = invoiceIdErpValue;
        replaceValueMap.put("##SUCCESSFUL_INVOICE_ID_ERP_VALUE##", this.invoiceIdErpValue);
    }

    public void setBusinessUnitErpValue(String businessUnitErpValue) {
        this.businessUnitErpValue = businessUnitErpValue;
        replaceValueMap.put("##SUCCESSFUL_BUSINESS_UNIT_ERP_VALUE##", this.businessUnitErpValue);
    }

    public void setSourceErpValue(String sourceErpValue) {
        this.sourceErpValue = sourceErpValue;
        replaceValueMap.put("##SUCCESSFUL_SOURCE_ERP_VALUE##", this.sourceErpValue);
    }

    public void setInvoiceNumErpValue(String invoiceNumErpValue) {
        this.invoiceNumErpValue = invoiceNumErpValue;
        replaceValueMap.put("##SUCCESSFUL_INVOICE_NUM_ERP_VALUE##", this.invoiceNumErpValue);
    }

    public void setInvoiceAmountErpValue(String invoiceAmountErpValue) {
        this.invoiceAmountErpValue = invoiceAmountErpValue;
        replaceValueMap.put("##SUCCESSFUL_INVOICE_AMOUNT_ERP_VALUE##", this.invoiceAmountErpValue);
    }

    public void setInvoiceDateErpValue(String invoiceDateErpValue) {
        this.invoiceDateErpValue = invoiceDateErpValue;
        replaceValueMap.put("##SUCCESSFUL_INVOICE_DATE_ERP_VALUE##", this.invoiceDateErpValue);
    }

    public void setVendorNameErpValue(String vendorNameErpValue) {
        this.vendorNameErpValue = vendorNameErpValue;
        replaceValueMap.put("##SUCCESSFUL_VENDOR_NAME_ERP_VALUE##", this.vendorNameErpValue);
    }

    public void setVendorSiteCodeErpValue(String vendorSiteCodeErpValue) {
        this.vendorSiteCodeErpValue = vendorSiteCodeErpValue;
        replaceValueMap.put("##SUCCESSFUL_VENDOR_SITE_CODE_ERP_VALUE##", this.vendorSiteCodeErpValue);
    }

    public void setInvoiceCurrencyCodeErpValue(String invoiceCurrencyCodeErpValue) {
        this.invoiceCurrencyCodeErpValue = invoiceCurrencyCodeErpValue;
        replaceValueMap.put("##SUCCESSFUL_INVOICE_CURRENCY_CODE_ERP_VALUE##", this.invoiceCurrencyCodeErpValue);
    }

    public void setDescriptionErpValue(String descriptionErpValue) {
        this.descriptionErpValue = descriptionErpValue;
        replaceValueMap.put("##SUCCESSFUL_DESCRIPTION_ERP_VALUE##", this.descriptionErpValue);
    }

    public void setInvoiceTypeErpValue(String invoiceTypeErpValue) {
        this.invoiceTypeErpValue = invoiceTypeErpValue;
        replaceValueMap.put("##SUCCESSFUL_INVOICE_TYPE_ERP_VALUE##", this.invoiceTypeErpValue);
    }

    public void setPaymentTermsErpValue(String paymentTermsErpValue) {
        this.paymentTermsErpValue = paymentTermsErpValue;
        replaceValueMap.put("##SUCCESSFUL_PAYMENT_TERMS_ERP_VALUE##", this.paymentTermsErpValue);
    }

    public void setInvoiceReceivedDateErpValue(String invoiceReceivedDateErpValue) {
        this.invoiceReceivedDateErpValue = invoiceReceivedDateErpValue;
        replaceValueMap.put("##SUCCESSFUL_INVOICE_RECEIVED_DATE_ERP_VALUE##", this.invoiceReceivedDateErpValue);
    }

    public void setFshTransactionDateErpValue(String fshTransactionDateErpValue) {
        this.fshTransactionDateErpValue = fshTransactionDateErpValue;
        replaceValueMap.put("##SUCCESSFUL_FSH_TRANSACTION_DATE_ERP_VALUE##", this.fshTransactionDateErpValue);
    }

    public void setPaymentMethodCodeErpValue(String paymentMethodCodeErpValue) {
        this.paymentMethodCodeErpValue = paymentMethodCodeErpValue;
        replaceValueMap.put("##SUCCESSFUL_PAYMENT_METHOD_CODE_ERP_VALUE##", this.paymentMethodCodeErpValue);
    }

    public void setPayGroupLookupCodeErpValue(String payGroupLookupCodeErpValue) {
        this.payGroupLookupCodeErpValue = payGroupLookupCodeErpValue;
        replaceValueMap.put("##SUCCESSFUL_PAY_GROUP_LOOKUP_CODE_ERP_VALUE##", this.payGroupLookupCodeErpValue);
    }

    public void setExchangeRateTypeErpValue(String exchangeRateTypeErpValue) {
        this.exchangeRateTypeErpValue = exchangeRateTypeErpValue;
        replaceValueMap.put("##SUCCESSFUL_EXCHANGE_RATE_TYPE_ERP_VALUE##", this.exchangeRateTypeErpValue);
    }

    public void setExchangeEffectiveDateErpValue(String exchangeEffectiveDateErpValue) {
        this.exchangeEffectiveDateErpValue = exchangeEffectiveDateErpValue;
        replaceValueMap.put("##SUCCESSFUL_EXCHANGE_EFFECTIVE_DATE_ERP_VALUE##", this.exchangeEffectiveDateErpValue);
    }

    public void setExchangeRateErpValue(String exchangeRateErpValue) {
        this.exchangeRateErpValue = exchangeRateErpValue;
        replaceValueMap.put("##SUCCESSFUL_EXCHANGE_RATE_ERP_VALUE##", this.exchangeRateErpValue);
    }

    public void setPaymentPriorityErpValue(String paymentPriorityErpValue) {
        this.paymentPriorityErpValue = paymentPriorityErpValue;
        replaceValueMap.put("##SUCCESSFUL_PAYMENT_PRIORITY_ERP_VALUE##", this.paymentPriorityErpValue);
    }

    public void setStationeryCodeErpValue(String stationeryCodeErpValue) {
        this.stationeryCodeErpValue = stationeryCodeErpValue;
        replaceValueMap.put("##SUCCESSFUL_STATIONERY_CODE_ERP_VALUE##", this.stationeryCodeErpValue);
    }

    public void setCalcTaxDuringImportFlagErpValue(String calcTaxDuringImportFlagErpValue) {
        this.calcTaxDuringImportFlagErpValue = calcTaxDuringImportFlagErpValue;
        replaceValueMap.put("##SUCCESSFUL_CALC_TAX_DURING_IMPORT_FLAG_ERP_VALUE##", this.calcTaxDuringImportFlagErpValue);
    }

    public void setAddTaxToInvoiceAmountFlagErpValue(String addTaxToInvoiceAmountFlagErpValue) {
        this.addTaxToInvoiceAmountFlagErpValue = addTaxToInvoiceAmountFlagErpValue;
        replaceValueMap.put("##SUCCESSFUL_ADD_TAX_TO_INVOICE_AMOUNT_FLAG_ERP_VALUE##", this.addTaxToInvoiceAmountFlagErpValue);
    }

    public void setAttributeCategoryErpValue(String attributeCategoryErpValue) {
        this.attributeCategoryErpValue = attributeCategoryErpValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE_CATEGORY_ERP_VALUE##", this.attributeCategoryErpValue);
    }

    public void setAttribute1ErpValue(String attribute1ErpValue) {
        this.attribute1ErpValue = attribute1ErpValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE1_ERP_VALUE##", this.attribute1ErpValue);
    }

    public void setAttribute2ErpValue(String attribute2ErpValue) {
        this.attribute2ErpValue = attribute2ErpValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE2_ERP_VALUE##", this.attribute2ErpValue);
    }

    public void setAttribute3ErpValue(String attribute3ErpValue) {
        this.attribute3ErpValue = attribute3ErpValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE3_ERP_VALUE##", this.attribute3ErpValue);
    }

    public void setAttribute4ErpValue(String attribute4ErpValue) {
        this.attribute4ErpValue = attribute4ErpValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE4_ERP_VALUE##", this.attribute4ErpValue);
    }

    public void setAttribute5ErpValue(String attribute5ErpValue) {
        this.attribute5ErpValue = attribute5ErpValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE5_ERP_VALUE##", this.attribute5ErpValue);
    }

    public void setAttribute7ErpValue(String attribute7ErpValue) {
        this.attribute7ErpValue = attribute7ErpValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE7_ERP_VALUE##", this.attribute7ErpValue);
    }

    public void setAttribute8ErpValue(String attribute8ErpValue) {
        this.attribute8ErpValue = attribute8ErpValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE8_ERP_VALUE##", this.attribute8ErpValue);
    }

    public void setAttribute15ErpValue(String attribute15ErpValue) {
        this.attribute15ErpValue = attribute15ErpValue;
        replaceValueMap.put("##SUCCESSFUL_ATTRIBUTE15_ERP_VALUE##", this.attribute15ErpValue);
    }

    public void setLineInvoiceIdErpValue(String lineInvoiceIdErpValue) {
        this.lineInvoiceIdErpValue = lineInvoiceIdErpValue;
        replaceValueMap.put("##SUCCESSFUL_LINE_INVOICE_ID_ERP_VALUE##", this.lineInvoiceIdErpValue);
    }

    public void setLineNumberErpValue(String lineNumberErpValue) {
        this.lineNumberErpValue = lineNumberErpValue;
        replaceValueMap.put("##SUCCESSFUL_LINE_NUMBER_ERP_VALUE##", this.lineNumberErpValue);
    }

    public void setLineTypeLookupCodeErpValue(String lineTypeLookupCodeErpValue) {
        this.lineTypeLookupCodeErpValue = lineTypeLookupCodeErpValue;
        replaceValueMap.put("##SUCCESSFUL_LINE_TYPE_LOOKUP_CODE_ERP_VALUE##", this.lineTypeLookupCodeErpValue);
    }

    public void setLineItemAmountErpValue(String lineItemAmountErpValue) {
        this.lineItemAmountErpValue = lineItemAmountErpValue;
        replaceValueMap.put("##SUCCESSFUL_LINE_ITEM_AMOUNT_ERP_VALUE##", this.lineItemAmountErpValue);
    }

    public void setLineDescriptionErpValue(String lineDescriptionErpValue) {
        this.lineDescriptionErpValue = lineDescriptionErpValue;
        replaceValueMap.put("##SUCCESSFUL_LINE_DESCRIPTION_ERP_VALUE##", this.lineDescriptionErpValue);
    }

    public void setDistCodeConcatenatedErpValue(String distCodeConcatenatedErpValue) {
        this.distCodeConcatenatedErpValue = distCodeConcatenatedErpValue;
        replaceValueMap.put("##SUCCESSFUL_DIST_CODE_CONCATENATED_ERP_VALUE##", this.distCodeConcatenatedErpValue);
    }

    public void setTaxClassificationCodeErpValue(String taxClassificationCodeErpValue) {
        this.taxClassificationCodeErpValue = taxClassificationCodeErpValue;
        replaceValueMap.put("##SUCCESSFUL_TAX_CLASSIFICATION_CODE_ERP_VALUE##", this.taxClassificationCodeErpValue);
    }

    public void setTaxRateCodeErpValue(String taxRateCodeErpValue) {
        this.taxRateCodeErpValue = taxRateCodeErpValue;
        replaceValueMap.put("##SUCCESSFUL_TAX_RATE_CODE_ERP_VALUE##", this.taxRateCodeErpValue);
    }

    public void setProrateAcrossFlagErpValue(String prorateAcrossFlagErpValue) {
        this.prorateAcrossFlagErpValue = prorateAcrossFlagErpValue;
        replaceValueMap.put("##SUCCESSFUL_PRORATE_ACROSS_FLAG_ERP_VALUE##", this.prorateAcrossFlagErpValue);
    }

    public void setLineGroupNumberErpValue(String lineGroupNumberErpValue) {
        this.lineGroupNumberErpValue = lineGroupNumberErpValue;
        replaceValueMap.put("##SUCCESSFUL_LINE_GROUP_NUMBER_ERP_VALUE##", this.lineGroupNumberErpValue);
    }

    public void setAssetsTrackingFlagErpValue(String assetsTrackingFlagErpValue) {
        this.assetsTrackingFlagErpValue = assetsTrackingFlagErpValue;
        replaceValueMap.put("##SUCCESSFUL_ASSETS_TRACKING_FLAG_ERP_VALUE##", this.assetsTrackingFlagErpValue);
    }

    public void setInvoiceIdResultValue(String invoiceIdResultValue) {
        this.invoiceIdResultValue = invoiceIdResultValue;
        replaceValueMap.put("##RESULT_INVOICE_ID_RESULT##", this.invoiceIdResultValue);
    }

    public void setBusinessUnitResultValue(String businessUnitResultValue) {
        this.businessUnitResultValue = businessUnitResultValue;
        replaceValueMap.put("##RESULT_BUSINESS_UNIT_RESULT##", this.businessUnitResultValue);
    }

    public void setSourceResultValue(String sourceResultValue) {
        this.sourceResultValue = sourceResultValue;
        replaceValueMap.put("##RESULT_SOURCE_RESULT##", this.sourceResultValue);
    }

    public void setInvoiceNumResultValue(String invoiceNumResultValue) {
        this.invoiceNumResultValue = invoiceNumResultValue;
        replaceValueMap.put("##RESULT_INVOICE_NUM_RESULT##", this.invoiceNumResultValue);
    }

    public void setInvoiceAmountResultValue(String invoiceAmountResultValue) {
        this.invoiceAmountResultValue = invoiceAmountResultValue;
        replaceValueMap.put("##RESULT_INVOICE_AMOUNT_RESULT##", this.invoiceAmountResultValue);
    }

    public void setInvoiceDateResultValue(String invoiceDateResultValue) {
        this.invoiceDateResultValue = invoiceDateResultValue;
        replaceValueMap.put("##RESULT_INVOICE_DATE_RESULT##", this.invoiceDateResultValue);
    }

    public void setVendorNameResultValue(String vendorNameResultValue) {
        this.vendorNameResultValue = vendorNameResultValue;
        replaceValueMap.put("##RESULT_VENDOR_NAME_RESULT##", this.vendorNameResultValue);
    }

    public void setVendorSiteCodeResultValue(String vendorSiteCodeResultValue) {
        this.vendorSiteCodeResultValue = vendorSiteCodeResultValue;
        replaceValueMap.put("##RESULT_VENDOR_SITE_CODE_RESULT##", this.vendorSiteCodeResultValue);
    }

    public void setInvoiceCurrencyCodeResultValue(String invoiceCurrencyCodeResultValue) {
        this.invoiceCurrencyCodeResultValue = invoiceCurrencyCodeResultValue;
        replaceValueMap.put("##RESULT_INVOICE_CURRENCY_CODE_RESULT##", this.invoiceCurrencyCodeResultValue);
    }

    public void setDescriptionResultValue(String descriptionResultValue) {
        this.descriptionResultValue = descriptionResultValue;
        replaceValueMap.put("##RESULT_DESCRIPTION_RESULT##", this.descriptionResultValue);
    }

    public void setInvoiceTypeResultValue(String invoiceTypeResultValue) {
        this.invoiceTypeResultValue = invoiceTypeResultValue;
        replaceValueMap.put("##RESULT_INVOICE_TYPE_RESULT##", this.invoiceTypeResultValue);
    }

    public void setPaymentTermsResultValue(String paymentTermsResultValue) {
        this.paymentTermsResultValue = paymentTermsResultValue;
        replaceValueMap.put("##RESULT_PAYMENT_TERMS_RESULT##", this.paymentTermsResultValue);
    }

    public void setInvoiceReceivedDateResultValue(String invoiceReceivedDateResultValue) {
        this.invoiceReceivedDateResultValue = invoiceReceivedDateResultValue;
        replaceValueMap.put("##RESULT_INVOICE_RECEIVED_DATE_RESULT##", this.invoiceReceivedDateResultValue);
    }

    public void setFshTransactionDateResultValue(String fshTransactionDateResultValue) {
        this.fshTransactionDateResultValue = fshTransactionDateResultValue;
        replaceValueMap.put("##RESULT_FSH_TRANSACTION_DATE_RESULT##", this.fshTransactionDateResultValue);
    }

    public void setPaymentMethodCodeResultValue(String paymentMethodCodeResultValue) {
        this.paymentMethodCodeResultValue = paymentMethodCodeResultValue;
        replaceValueMap.put("##RESULT_PAYMENT_METHOD_CODE_RESULT##", this.paymentMethodCodeResultValue);
    }

    public void setPayGroupLookupCodeResultValue(String payGroupLookupCodeResultValue) {
        this.payGroupLookupCodeResultValue = payGroupLookupCodeResultValue;
        replaceValueMap.put("##RESULT_PAY_GROUP_LOOKUP_CODE_RESULT##", this.payGroupLookupCodeResultValue);
    }

    public void setExchangeRateTypeResultValue(String exchangeRateTypeResultValue) {
        this.exchangeRateTypeResultValue = exchangeRateTypeResultValue;
        replaceValueMap.put("##RESULT_EXCHANGE_RATE_TYPE_RESULT##", this.exchangeRateTypeResultValue);
    }

    public void setExchangeEffectiveDateResultValue(String exchangeEffectiveDateResultValue) {
        this.exchangeEffectiveDateResultValue = exchangeEffectiveDateResultValue;
        replaceValueMap.put("##RESULT_EXCHANGE_EFFECTIVE_DATE_RESULT##", this.exchangeEffectiveDateResultValue);
    }

    public void setExchangeRateResultValue(String exchangeRateResultValue) {
        this.exchangeRateResultValue = exchangeRateResultValue;
        replaceValueMap.put("##RESULT_EXCHANGE_RATE_RESULT##", this.exchangeRateResultValue);
    }

    public void setPaymentPriorityResultValue(String paymentPriorityResultValue) {
        this.paymentPriorityResultValue = paymentPriorityResultValue;
        replaceValueMap.put("##RESULT_PAYMENT_PRIORITY_RESULT##", this.paymentPriorityResultValue);
    }

    public void setStationeryCodeResultValue(String stationeryCodeResultValue) {
        this.stationeryCodeResultValue = stationeryCodeResultValue;
        replaceValueMap.put("##RESULT_STATIONERY_CODE_RESULT##", this.stationeryCodeResultValue);
    }

    public void setCalcTaxDuringImportFlagResultValue(String calcTaxDuringImportFlagResultValue) {
        this.calcTaxDuringImportFlagResultValue = calcTaxDuringImportFlagResultValue;
        replaceValueMap.put("##RESULT_CALC_TAX_DURING_IMPORT_FLAG_RESULT##", this.calcTaxDuringImportFlagResultValue);
    }

    public void setAddTaxToInvoiceAmountFlagResultValue(String addTaxToInvoiceAmountFlagResultValue) {
        this.addTaxToInvoiceAmountFlagResultValue = addTaxToInvoiceAmountFlagResultValue;
        replaceValueMap.put("##RESULT_ADD_TAX_TO_INVOICE_AMOUNT_FLAG_RESULT##", this.addTaxToInvoiceAmountFlagResultValue);
    }

    public void setAttributeCategoryResultValue(String attributeCategoryResultValue) {
        this.attributeCategoryResultValue = attributeCategoryResultValue;
        replaceValueMap.put("##RESULT_ATTRIBUTE_CATEGORY_RESULT##", this.attributeCategoryResultValue);
    }

    public void setAttribute1ResultValue(String attribute1ResultValue) {
        this.attribute1ResultValue = attribute1ResultValue;
        replaceValueMap.put("##RESULT_ATTRIBUTE1_RESULT##", this.attribute1ResultValue);
    }

    public void setAttribute2ResultValue(String attribute2ResultValue) {
        this.attribute2ResultValue = attribute2ResultValue;
        replaceValueMap.put("##RESULT_ATTRIBUTE2_RESULT##", this.attribute2ResultValue);
    }

    public void setAttribute3ResultValue(String attribute3ResultValue) {
        this.attribute3ResultValue = attribute3ResultValue;
        replaceValueMap.put("##RESULT_ATTRIBUTE3_RESULT##", this.attribute3ResultValue);
    }

    public void setAttribute4ResultValue(String attribute4ResultValue) {
        this.attribute4ResultValue = attribute4ResultValue;
        replaceValueMap.put("##RESULT_ATTRIBUTE4_RESULT##", this.attribute4ResultValue);
    }

    public void setAttribute5ResultValue(String attribute5ResultValue) {
        this.attribute5ResultValue = attribute5ResultValue;
        replaceValueMap.put("##RESULT_ATTRIBUTE5_RESULT##", this.attribute5ResultValue);
    }

    public void setAttribute7ResultValue(String attribute7ResultValue) {
        this.attribute7ResultValue = attribute7ResultValue;
        replaceValueMap.put("##RESULT_ATTRIBUTE7_RESULT##", this.attribute7ResultValue);
    }

    public void setAttribute8ResultValue(String attribute8ResultValue) {
        this.attribute8ResultValue = attribute8ResultValue;
        replaceValueMap.put("##RESULT_ATTRIBUTE8_RESULT##", this.attribute8ResultValue);
    }

    public void setAttribute15ResultValue(String attribute15ResultValue) {
        this.attribute15ResultValue = attribute15ResultValue;
        replaceValueMap.put("##RESULT_ATTRIBUTE15_RESULT##", this.attribute15ResultValue);
    }

    public void setLineInvoiceIdResultValue(String lineInvoiceIdResultValue) {
        this.lineInvoiceIdResultValue = lineInvoiceIdResultValue;
        replaceValueMap.put("##RESULT_LINE_INVOICE_ID_RESULT##", this.lineInvoiceIdResultValue);
    }

    public void setLineNumberResultValue(String lineNumberResultValue) {
        this.lineNumberResultValue = lineNumberResultValue;
        replaceValueMap.put("##RESULT_LINE_NUMBER_RESULT##", this.lineNumberResultValue);
    }

    public void setLineTypeLookupCodeResultValue(String lineTypeLookupCodeResultValue) {
        this.lineTypeLookupCodeResultValue = lineTypeLookupCodeResultValue;
        replaceValueMap.put("##RESULT_LINE_TYPE_LOOKUP_CODE_RESULT##", this.lineTypeLookupCodeResultValue);
    }

    public void setLineItemAmountResultValue(String lineItemAmountResultValue) {
        this.lineItemAmountResultValue = lineItemAmountResultValue;
        replaceValueMap.put("##RESULT_LINE_ITEM_AMOUNT_RESULT##", this.lineItemAmountResultValue);
    }

    public void setLineDescriptionResultValue(String lineDescriptionResultValue) {
        this.lineDescriptionResultValue = lineDescriptionResultValue;
        replaceValueMap.put("##RESULT_LINE_DESCRIPTION_RESULT##", this.lineDescriptionResultValue);
    }

    public void setDistCodeConcatenatedResultValue(String distCodeConcatenatedResultValue) {
        this.distCodeConcatenatedResultValue = distCodeConcatenatedResultValue;
        replaceValueMap.put("##RESULT_DIST_CODE_CONCATENATED_RESULT##", this.distCodeConcatenatedResultValue);
    }

    public void setTaxClassificationCodeResultValue(String taxClassificationCodeResultValue) {
        this.taxClassificationCodeResultValue = taxClassificationCodeResultValue;
        replaceValueMap.put("##RESULT_TAX_CLASSIFICATION_CODE_RESULT##", this.taxClassificationCodeResultValue);
    }

    public void setTaxRateCodeResultValue(String taxRateCodeResultValue) {
        this.taxRateCodeResultValue = taxRateCodeResultValue;
        replaceValueMap.put("##RESULT_TAX_RATE_CODE_RESULT##", this.taxRateCodeResultValue);
    }

    public void setProrateAcrossFlagResultValue(String prorateAcrossFlagResultValue) {
        this.prorateAcrossFlagResultValue = prorateAcrossFlagResultValue;
        replaceValueMap.put("##RESULT_PRORATE_ACROSS_FLAG_RESULT##", this.prorateAcrossFlagResultValue);
    }

    public void setLineGroupNumberResultValue(String lineGroupNumberResultValue) {
        this.lineGroupNumberResultValue = lineGroupNumberResultValue;
        replaceValueMap.put("##RESULT_LINE_GROUP_NUMBER_RESULT##", this.lineGroupNumberResultValue);
    }

    public void setAssetsTrackingFlagResultValue(String assetsTrackingFlagResultValue) {
        this.assetsTrackingFlagResultValue = assetsTrackingFlagResultValue;
        replaceValueMap.put("##RESULT_ASSETS_TRACKING_FLAG_RESULT##", this.assetsTrackingFlagResultValue);
    }
}
