package com.uk.dlgds.fusionvalidation.utils.pojo.reject;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor(staticName = "of")
@AllArgsConstructor(access = AccessLevel.PROTECTED)

public class Output {

    @JacksonXmlProperty(localName = "INVOICE_NUM")
    private String invoiceNum;

    @JacksonXmlProperty(localName = "PARENT_ID")
    private String invoiceId;

    @JacksonXmlProperty(localName = "REJECTION_MESSAGE")
    private String rejectionMessage;

    @JacksonXmlProperty(localName = "REJECT_LOOKUP_CODE")
    private String rejectLookupCode;

//    @JacksonXmlProperty(localName = "PARENT_ID")
//    private String parentId;

    public String getInvoiceNum() {
        return invoiceNum;
    }

    public void setInvoiceNum(String invoiceNum) {
        this.invoiceNum = invoiceNum;
    }

    public String getInvoiceId() {
        return invoiceId;
    }

    public void setInvoiceId(String invoiceId) {
        this.invoiceId = invoiceId;
    }

    public String getRejectionMessage() {
        return rejectionMessage;
    }

    public void setRejectionMessage(String rejectionMessage) {
        this.rejectionMessage = rejectionMessage;
    }

    public String getRejectLookupCode() {
        return rejectLookupCode;
    }

    public void setRejectLookupCode(String rejectLookupCode) {
        this.rejectLookupCode = rejectLookupCode;
    }

//    public String getParentId() {
//        return parentId;
//    }
//
//    public void setParentId(String parentId) {
//        this.parentId = parentId;
//    }
}