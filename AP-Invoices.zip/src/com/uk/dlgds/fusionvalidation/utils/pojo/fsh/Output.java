package com.uk.dlgds.fusionvalidation.utils.pojo.fsh;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor(staticName = "of")
@AllArgsConstructor(access = AccessLevel.PROTECTED)

public class Output {

    @JacksonXmlProperty(localName = "VENDOR_NAME")
    private String vendorName;

    @JacksonXmlProperty(localName = "DIST_CODE_CONCATENATED")
    private String distCodeConcatenated;
    @JacksonXmlProperty(localName = "INVOICE_RECEIVED_DATE")
    private String invoiceReceivedDate;
    @JacksonXmlProperty(localName = "LINE_TYPE_LOOKUP_CODE")
    private String lineTypeLookupCode;
    @JacksonXmlProperty(localName = "LINE_NUMBER")
    private String lineNumber;
    @JacksonXmlProperty(localName = "TAX_CLASSIFICATION_CODE")
    private String taxClassificationCode;
    @JacksonXmlProperty(localName = "TAX_RATE_CODE")
    private String taxRateCode;
    @JacksonXmlProperty(localName = "VENDOR_SITE_CODE")
    private String vendorSiteCode;
    @JacksonXmlProperty(localName = "TERMS_NAME")
    private String termsName;
    @JacksonXmlProperty(localName = "LINE_ITEM_AMOUNT")
    private String lineItemAmount;
    @JacksonXmlProperty(localName = "INVOICE_DATE")
    private String invoiceDate;
    @JacksonXmlProperty(localName = "PAYMENT_PRIORITY")
    private String paymentPriority;
    @JacksonXmlProperty(localName = "INVOICE_ID")
    private String invoiceId;
    @JacksonXmlProperty(localName = "INVOICE_TYPE_LOOKUP_CODE")
    private String invoiceTypeLookupCode;
    @JacksonXmlProperty(localName = "PAYMENT_METHOD_CODE")
    private String paymentMethodCode;
    @JacksonXmlProperty(localName = "DESCRIPTION")
    private String description;
    @JacksonXmlProperty(localName = "LINE_INVOICE_ID")
    private String lineInvoiceId;
    @JacksonXmlProperty(localName = "EXCHANGE_DATE")
    private String exchangeDate;
    @JacksonXmlProperty(localName = "EXCHANGE_RATE_TYPE")
    private String exchangeRateType;
    @JacksonXmlProperty(localName = "ATTRIBUTE3")
    private String attribute3;
    @JacksonXmlProperty(localName = "CALC_TAX_DURING_IMPORT_FLAG")
    private String calcTaxDuringImportFlag;
    @JacksonXmlProperty(localName = "ATTRIBUTE2")
    private String attribute2;
    @JacksonXmlProperty(localName = "ATTRIBUTE1")
    private String attribute1;
    @JacksonXmlProperty(localName = "OPERATING_UNIT")
    private String operatingUnit;
    @JacksonXmlProperty(localName = "EXCHANGE_RATE")
    private String exchangeRate;
    @JacksonXmlProperty(localName = "LINE_DESCRIPTION")
    private String lineDescription;
    @JacksonXmlProperty(localName = "ATTRIBUTE8")
    private String attribute8;
    @JacksonXmlProperty(localName = "ASSETS_TRACKING_FLAG")
    private String assetsTrackingFlag;
    @JacksonXmlProperty(localName = "ATTRIBUTE7")
    private String attribute7;
    @JacksonXmlProperty(localName = "GL_DATE")
    private String glDate;
    @JacksonXmlProperty(localName = "ATTRIBUTE5")
    private String attribute5;
    @JacksonXmlProperty(localName = "ATTRIBUTE4")
    private String attribute4;
    @JacksonXmlProperty(localName = "INVOICE_NUM")
    private String invoiceNum;
    @JacksonXmlProperty(localName = "ATTRIBUTE_CATEGORY")
    private String attributeCategory;
    @JacksonXmlProperty(localName = "PRORATE_ACROSS_FLAG")
    private String prorateAcrossFlag;
    @JacksonXmlProperty(localName = "SOURCE")
    private String source;
    @JacksonXmlProperty(localName = "ADD_TAX_TO_INV_AMT_FLAG")
    private String addTaxToInvAmtFlag;
    @JacksonXmlProperty(localName = "INVOICE_AMOUNT")
    private String invoiceAmount;
    @JacksonXmlProperty(localName = "PAYMENT_REASON_COMMENTS")
    private String paymentReasonComments;
    @JacksonXmlProperty(localName = "ATTRIBUTE15")
    private String attribute15;
    @JacksonXmlProperty(localName = "INVOICE_CURRENCY_CODE")
    private String invoiceCurrencyCode;
    @JacksonXmlProperty(localName = "PAY_GROUP_LOOKUP_CODE")
    private String payGroupLookupCode;
    @JacksonXmlProperty(localName = "LINE_GROUP_NUMBER")
    private String lineGroupNumber;

    public String getVendorName() {
        return vendorName;
    }

    public void setVendorName(String vendorName) {
        this.vendorName = vendorName;
    }

    public String getDistCodeConcatenated() {
        return distCodeConcatenated;
    }

    public void setDistCodeConcatenated(String distCodeConcatenated) {
        this.distCodeConcatenated = distCodeConcatenated;
    }

    public String getInvoiceReceivedDate() {
        return invoiceReceivedDate;
    }

    public void setInvoiceReceivedDate(String invoiceReceivedDate) {
        this.invoiceReceivedDate = invoiceReceivedDate;
    }

    public String getLineTypeLookupCode() {
        return lineTypeLookupCode;
    }

    public void setLineTypeLookupCode(String lineTypeLookupCode) {
        this.lineTypeLookupCode = lineTypeLookupCode;
    }

    public String getLineNumber() {
        return lineNumber;
    }

    public void setLineNumber(String lineNumber) {
        this.lineNumber = lineNumber;
    }

    public String getTaxClassificationCode() {
        return taxClassificationCode;
    }

    public void setTaxClassificationCode(String taxClassificationCode) {
        this.taxClassificationCode = taxClassificationCode;
    }

    public String getTaxRateCode() {
        return taxRateCode;
    }

    public void setTaxRateCode(String taxRateCode) {
        this.taxRateCode = taxRateCode;
    }

    public String getVendorSiteCode() {
        return vendorSiteCode;
    }

    public void setVendorSiteCode(String vendorSiteCode) {
        this.vendorSiteCode = vendorSiteCode;
    }

    public String getTermsName() {
        return termsName;
    }

    public void setTermsName(String termsName) {
        this.termsName = termsName;
    }

    public String getLineItemAmount() {
        return lineItemAmount;
    }

    public void setLineItemAmount(String lineItemAmount) {
        this.lineItemAmount = lineItemAmount;
    }

    public String getInvoiceDate() {
        return invoiceDate;
    }

    public void setInvoiceDate(String invoiceDate) {
        this.invoiceDate = invoiceDate;
    }

    public String getPaymentPriority() {
        return paymentPriority;
    }

    public void setPaymentPriority(String paymentPriority) {
        this.paymentPriority = paymentPriority;
    }

    public String getInvoiceId() {
        return invoiceId;
    }

    public void setInvoiceId(String invoiceId) {
        this.invoiceId = invoiceId;
    }

    public String getInvoiceTypeLookupCode() {
        return invoiceTypeLookupCode;
    }

    public void setInvoiceTypeLookupCode(String invoiceTypeLookupCode) {
        this.invoiceTypeLookupCode = invoiceTypeLookupCode;
    }

    public String getPaymentMethodCode() {
        return paymentMethodCode;
    }

    public void setPaymentMethodCode(String paymentMethodCode) {
        this.paymentMethodCode = paymentMethodCode;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLineInvoiceId() {
        return lineInvoiceId;
    }

    public void setLineInvoiceId(String lineInvoiceId) {
        this.lineInvoiceId = lineInvoiceId;
    }

    public String getExchangeDate() {
        return exchangeDate;
    }

    public void setExchangeDate(String exchangeDate) {
        this.exchangeDate = exchangeDate;
    }

    public String getExchangeRateType() {
        return exchangeRateType;
    }

    public void setExchangeRateType(String exchangeRateType) {
        this.exchangeRateType = exchangeRateType;
    }

    public String getAttribute3() {
        return attribute3;
    }

    public void setAttribute3(String attribute3) {
        this.attribute3 = attribute3;
    }

    public String getCalcTaxDuringImportFlag() {
        return calcTaxDuringImportFlag;
    }

    public void setCalcTaxDuringImportFlag(String calcTaxDuringImportFlag) {
        this.calcTaxDuringImportFlag = calcTaxDuringImportFlag;
    }

    public String getAttribute2() {
        return attribute2;
    }

    public void setAttribute2(String attribute2) {
        this.attribute2 = attribute2;
    }

    public String getAttribute1() {
        return attribute1;
    }

    public void setAttribute1(String attribute1) {
        this.attribute1 = attribute1;
    }

    public String getOperatingUnit() {
        return operatingUnit;
    }

    public void setOperatingUnit(String operatingUnit) {
        this.operatingUnit = operatingUnit;
    }

    public String getExchangeRate() {
        return exchangeRate;
    }

    public void setExchangeRate(String exchangeRate) {
        this.exchangeRate = exchangeRate;
    }

    public String getLineDescription() {
        return lineDescription;
    }

    public void setLineDescription(String lineDescription) {
        this.lineDescription = lineDescription;
    }

    public String getAttribute8() {
        return attribute8;
    }

    public void setAttribute8(String attribute8) {
        this.attribute8 = attribute8;
    }

    public String getAssetsTrackingFlag() {
        return assetsTrackingFlag;
    }

    public void setAssetsTrackingFlag(String assetsTrackingFlag) {
        this.assetsTrackingFlag = assetsTrackingFlag;
    }

    public String getAttribute7() {
        return attribute7;
    }

    public void setAttribute7(String attribute7) {
        this.attribute7 = attribute7;
    }

    public String getGlDate() {
        return glDate;
    }

    public void setGlDate(String glDate) {
        this.glDate = glDate;
    }

    public String getAttribute5() {
        return attribute5;
    }

    public void setAttribute5(String attribute5) {
        this.attribute5 = attribute5;
    }

    public String getAttribute4() {
        return attribute4;
    }

    public void setAttribute4(String attribute4) {
        this.attribute4 = attribute4;
    }

    public String getInvoiceNum() {
        return invoiceNum;
    }

    public void setInvoiceNum(String invoiceNum) {
        this.invoiceNum = invoiceNum;
    }

    public String getAttributeCategory() {
        return attributeCategory;
    }

    public void setAttributeCategory(String attributeCategory) {
        this.attributeCategory = attributeCategory;
    }

    public String getProrateAcrossFlag() {
        return prorateAcrossFlag;
    }

    public void setProrateAcrossFlag(String prorateAcrossFlag) {
        this.prorateAcrossFlag = prorateAcrossFlag;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getAddTaxToInvAmtFlag() {
        return addTaxToInvAmtFlag;
    }

    public void setAddTaxToInvAmtFlag(String addTaxToInvAmtFlag) {
        this.addTaxToInvAmtFlag = addTaxToInvAmtFlag;
    }

    public String getInvoiceAmount() {
        return invoiceAmount;
    }

    public void setInvoiceAmount(String invoiceAmount) {
        this.invoiceAmount = invoiceAmount;
    }

    public String getPaymentReasonComments() {
        return paymentReasonComments;
    }

    public void setPaymentReasonComments(String paymentReasonComments) {
        this.paymentReasonComments = paymentReasonComments;
    }

    public String getAttribute15() {
        return attribute15;
    }

    public void setAttribute15(String attribute15) {
        this.attribute15 = attribute15;
    }

    public String getInvoiceCurrencyCode() {
        return invoiceCurrencyCode;
    }

    public void setInvoiceCurrencyCode(String invoiceCurrencyCode) {
        this.invoiceCurrencyCode = invoiceCurrencyCode;
    }

    public String getPayGroupLookupCode() {
        return payGroupLookupCode;
    }

    public void setPayGroupLookupCode(String payGroupLookupCode) {
        this.payGroupLookupCode = payGroupLookupCode;
    }

    public String getLineGroupNumber() {
        return lineGroupNumber;
    }

    public void setLineGroupNumber(String lineGroupNumber) {
        this.lineGroupNumber = lineGroupNumber;
    }
}