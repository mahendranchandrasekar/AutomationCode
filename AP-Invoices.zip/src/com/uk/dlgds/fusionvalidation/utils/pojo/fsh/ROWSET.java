package com.uk.dlgds.fusionvalidation.utils.pojo.fsh;


import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@RequiredArgsConstructor(staticName = "of")
@JacksonXmlRootElement(localName = "ROWSET")
public class ROWSET {

    @JacksonXmlProperty(localName = "pQuery")
    private String pQuery;

    @JacksonXmlProperty(localName = "Output")
    @JacksonXmlElementWrapper(useWrapping = false)
    private List<com.uk.dlgds.fusionvalidation.utils.pojo.fsh.Output> Output = new ArrayList<>();

    public String getpQuery() {
        return pQuery;
    }

    public void setpQuery(String pQuery) {
        this.pQuery = pQuery;
    }

    public List<com.uk.dlgds.fusionvalidation.utils.pojo.fsh.Output> getOutput() {
        return Output;
    }

    public void setOutput(List<com.uk.dlgds.fusionvalidation.utils.pojo.fsh.Output> output) {
        Output = output;
    }
}