package com.uk.dlgds.fusionvalidation.utils.pojo.fsh;



public class ErpQueryResult {
    private ROWSET ROWSET;

    public ROWSET getROWSET ()
    {
        return ROWSET;
    }

    public void setROWSET (ROWSET ROWSET)
    {
        this.ROWSET = ROWSET;
    }


}