package com.uk.dlgds.fusionvalidation.utils.pojo.reject;


import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@RequiredArgsConstructor(staticName = "of")
@JacksonXmlRootElement(localName = "ROWSET")

public class ROWSET
{
    @JacksonXmlProperty(localName = "P_QUERY")
    private String P_QUERY;

    @JacksonXmlProperty(localName = "Output")
    @JacksonXmlElementWrapper(useWrapping = false)
    private List<Output> output =  new ArrayList<>();

    public String getP_QUERY ()
    {
        return P_QUERY;
    }

    public void setP_QUERY (String P_QUERY)
    {
        this.P_QUERY = P_QUERY;
    }

    public List<Output> getOutput() {
        return output;
    }

    public void setOutput(List<Output> output) {
        this.output = output;
    }

}
