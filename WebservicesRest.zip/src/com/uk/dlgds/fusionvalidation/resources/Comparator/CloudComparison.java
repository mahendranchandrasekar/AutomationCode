package com.uk.dlgds.fusionvalidation.resources.Comparator;

import com.uk.dlgds.fusionvalidation.Utils.Output;

import java.util.ArrayList;
import java.util.List;

public class CloudComparison {

     ArrayList<String> compareElements(List<Output> outputValues){
         ArrayList<String> concatenatedResults = new ArrayList<>();
        for(Output values : outputValues){
            concatenatedResults.add("TRX_NUMBER:"+ values.getTrxNumber());
            concatenatedResults.add("INVOICE_CURRENCY_CODE:"+ values.getInvoiceCurrencyCode());
            concatenatedResults.add("ATTRIBUTE_CATEGORY:"+ values.getAttributeCategory());
            concatenatedResults.add("ATTRIBUTE1:"+ values.getAttribute1());
            concatenatedResults.add("ATTRIBUTE2:"+ values.getAttribute2());
            concatenatedResults.add("ATTRIBUTE3:"+ values.getAttribute3());
            concatenatedResults.add("ATTRIBUTE4:"+ values.getAttribute4());
            concatenatedResults.add("ATTRIBUTE5:"+ values.getAttribute5());
            concatenatedResults.add("ATTRIBUTE6:"+ values.getAttribute6());
            concatenatedResults.add("ATTRIBUTE7:"+ values.getAttribute7());
            concatenatedResults.add("ATTRIBUTE8:"+ values.getAttribute8());
            concatenatedResults.add("ATTRIBUTE9:"+ values.getAttribute9());
            concatenatedResults.add("ATTRIBUTE10:"+ values.getAttribute10());
            concatenatedResults.add("ATTRIBUTE11:"+ values.getAttribute11());
            concatenatedResults.add("ATTRIBUTE12:"+ values.getAttribute12());
            concatenatedResults.add("ATTRIBUTE13:"+ values.getAttribute13());
            concatenatedResults.add("ATTRIBUTE14:"+ values.getAttribute14());
            concatenatedResults.add("ATTRIBUTE15:"+ values.getAttribute15());
            concatenatedResults.add("INTERFACE_HEADER_ATTRIBUTE1:"+ values.getInterfaceHeaderAttribute1());
            concatenatedResults.add("INTERFACE_HEADER_ATTRIBUTE2:"+ values.getInterfaceHeaderAttribute2());
            concatenatedResults.add("INTERFACE_HEADER_ATTRIBUTE3:"+ values.getInterfaceHeaderAttribute3());
            concatenatedResults.add("INTERFACE_HEADER_ATTRIBUTE4:"+ values.getInterfaceHeaderAttribute4());
            concatenatedResults.add("INTERFACE_HEADER_CONTEXT:"+ values.getInterfaceHeaderContext());
            concatenatedResults.add("TRX_CLASS:"+ values.getTrxClass());
        }
        return concatenatedResults;
    }

     ArrayList<String> concatenateMissed(List<Output> outputValues){
         ArrayList<String> concatenateMissedTxn = new ArrayList<>();
        for(Output values : outputValues){
            concatenateMissedTxn.add("TRX_NUMBER:"+ values.getTrxNumber());
            concatenateMissedTxn.add("MESSAGE_TEXT:"+ values.getMessageText());

        }
        return concatenateMissedTxn;
    }

}
