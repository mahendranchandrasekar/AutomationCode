package com.uk.dlgds.fusionvalidation.resources.datasource;

import com.uk.dlgds.fusionvalidation.Utils.Staging;
import com.uk.dlgds.fusionvalidation.service.ApplicationDetails;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class StgValidations {
     private final ApplicationDetails applicationDetails = new ApplicationDetails();

     List<Staging> dbToJavaObject(ResultSet resultSet) throws SQLException {
        List<Staging> stagingToList=new ArrayList<>();
        System.out.println("resultSet in Staging validations:"+resultSet);
        while(resultSet.next()){

            Staging staging = new Staging();


            staging.setTrxNumber(objectToString(resultSet.getString("TRX_NUMBER")));
            staging.setInvoiceCurrencyCode(objectToString(resultSet.getString("Currency_Code")));
            staging.setCustomerAccountNumber(objectToString(resultSet.getString("Customer_Account_Number")));
            staging.setCustomerSiteNumber(objectToString(resultSet.getString("customer_site_number")));
            staging.setAttributeCategory(objectToString(resultSet.getString("header_attribute_category")));
            staging.setAttribute1(objectToString(resultSet.getString("header_attribute1")));
            staging.setAttribute10(objectToString(resultSet.getString("header_attribute10")));
            staging.setAttribute11(objectToString(resultSet.getString("header_attribute11")));
            staging.setAttribute12(objectToString(resultSet.getString("header_attribute12")));
            staging.setAttribute13(objectToString(resultSet.getString("header_attribute13")));
            staging.setAttribute14(objectToString(resultSet.getString("header_attribute14")));
            staging.setAttribute15(objectToString(resultSet.getString("header_attribute15")));
            staging.setAttribute2(objectToString(resultSet.getString("header_attribute2")));
            staging.setAttribute3(objectToString(resultSet.getString("header_attribute3")));
            staging.setAttribute4(objectToString(resultSet.getString("header_attribute4")));
            staging.setAttribute5(objectToString(resultSet.getString("header_attribute5")));
            staging.setAttribute6(objectToString(resultSet.getString("header_attribute6")));
            staging.setAttribute7(objectToString(resultSet.getString("header_attribute7")));
            staging.setAttribute8(objectToString(resultSet.getString("header_attribute8")));
            staging.setAttribute9(objectToString(resultSet.getString("header_attribute9")));
            staging.setLineNumber(objectToString(resultSet.getString("line_number")));
            staging.setLineAmount(objectToString(resultSet.getString("Amount")));
            staging.setCusttrxtypename(objectToString(resultSet.getString("CUST_TRX_TYPE_NAME")));
            staging.setAttributeCategory(objectToString(resultSet.getString("ATTRIBUTE_CATEGORY")));
            staging.setFileName(objectToString(resultSet.getString("file_name")));
            stagingToList.add(staging);

        }
        System.out.println("Staging validation is"+ stagingToList);
        return stagingToList;
    }
    public List<String> sourceFilename(List<Staging> listStaging) {
            return listStaging.stream().map(staging -> "\'" + staging.getFileName() + "\'").distinct().collect(Collectors.toList());
    }

    public String sourceEmptyFilename() throws IOException {
        String emptyFileList=  applicationDetails.readProperties("com.uk.dlgds.proxy.ip.emptyFileList").trim();
            return emptyFileList;
    }

    private String objectToString(Object  obj) {
        if ( obj==null)
            return  "";
        else
            return  obj.toString();
    }


}
