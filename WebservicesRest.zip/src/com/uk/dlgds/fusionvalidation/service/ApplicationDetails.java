package com.uk.dlgds.fusionvalidation.service;

import org.apache.commons.io.IOUtils;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Properties;

public class ApplicationDetails {

    public JSONObject readJournalFile(String path) throws IOException {

        final InputStream readQuery = getClass().getClassLoader().getResourceAsStream(path);
        final JSONObject queryJson = new JSONObject(IOUtils.toString(readQuery,"UTF-8"));
        return queryJson;
    }

    public String readProperties(String value) throws IOException {
        Properties credentials = new Properties();
        try(InputStream stream = getClass().getClassLoader().getResourceAsStream("application.properties")) {
            credentials.load(stream);
            return  credentials.getProperty(value);
        }
    }

}
