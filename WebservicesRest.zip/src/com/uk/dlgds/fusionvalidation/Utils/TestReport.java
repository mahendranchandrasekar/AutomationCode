package com.uk.dlgds.fusionvalidation.Utils;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class TestReport {

    public static final String PASS = "PASS";
    public static final String FAIL = "FAIL";
    public static final String WARNING = "warning";
    private static final String SUCCESSFUL_PATH = "./src/com/uk/dlgds/fusionvalidation/utils/html/successful.htm";
    private static final String TABLE_PATH = "./src/com/uk/dlgds/fusionvalidation/utils/html/table.htm";
    private static final String OICS_ERROR_PATH = "./src/com/uk/dlgds/fusionvalidation/utils/html/oics-error.htm";
    private static final String NO_OICS_ERROR_PATH = "./src/com/uk/dlgds/fusionvalidation/utils/html/no-oics-error.htm";
    private static final String REJECT_PATH = "./src/com/uk/dlgds/fusionvalidation/utils/html/reject.htm";
    private static final String NO_REJECT_PATH = "./src/com/uk/dlgds/fusionvalidation/utils/html/no-reject.htm";
    private static final String REPORT_OUTPUT = "./src/com/uk/dlgds/fusionvalidation/utils/html/reportOutput.html";
    private static final String DATE_FORMAT_REPORT_NAME = "yyyy_MM_dd_HH_mm_ss";
    private static final String DATE_FORMAT_REPORT = "yyyy_MM_dd HH:mm:ss";
    private static final String PASS_HTML = "<span style=\"background-color: rgb(0, 254, 0);font-weight: bold;\">PASS</span>";
    private static final String FAIL_HTML = "<span style=\"background-color: rgb(254, 0, 0);font-weight: bold;\">FAIL</span>";
    private static int countReport = 0;
    public SuccessfulReport successfulReport = new SuccessfulReport();
    private boolean oicsErrorFlag = false;
    private boolean rejectFlag = false;

    private String reportName;
    private String dateTime;

    private String reportFileName = "";
    private String reportSource = "";
    private String reportProcessedOn = "";
    private String totalRecordsInFile = "";
    private String totalRecordsProcessedInErp = "";
    private String totalRecordsErroedInErp = "";
    private String totalRecordsOicsError = "";
    private String rejectInvoiceId = "";
    private String rejectInvoiceNum = "";
    private String rejectReason = "";


    private String successfulInvoiceIdFshValue = "";
    private String successfulInvoiceIdErpValue = "";
    private String resultInvoiceIdResult = "";

    private String successfulInvoiceNumFshValue = "";
    private String successfulInvoiceNumErpValue = "";
    private String resultInvoiceNumResult = "";

    private String successfulInvoiceCurrecyCodeFshValue = "";
    private String successfulInvoiceCurrecyCodeErpValue = "";
    private String resultInvoiceCurrecyCodeResult = "";

    private String successfulAmountFshValue = "";
    private String successfulAmountErpValue = "";
    private String resultAmountResult = "";


    private String resultSNo = "";
    private String resultFieldName = "";
    private String resultFshValue = "";
    private String resultErpValue = "";
    private String resultResul = "";

    private String oicsSNo = "";
    private String oicsInvoiceId = "";
    private String htmlReport = "";
    private String table = "";
    private String oicsErrorValue = "";
    private String noOicsErrorValue = "";
    private String rejectValue = "";
    private String noRejectValue = "";
    private String successfulValue = "";
    private Map<String, String> replaceValueMap = new HashMap<>();

    public TestReport() {
        readTable();
        readOicsError();
        readReject();
        readSuccessful();
        rejectReason = "Invalid Source Application Reference";
        DateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT_REPORT);
        Date date = new Date();
        setDateTime(dateFormat.format(date));
    }


    public void initTestReport() throws IOException {

        rejectReason = "Invalid Source Application Reference";
        DateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT_REPORT);
        Date date = new Date();
        setDateTime(dateFormat.format(date));
        setReportName("Accounts Receivable - FSH to ERP - Travel AR Integration Test Report");

        pushReport();
    }

    public void readTable() {
        try {
            List<String> content = Files.readAllLines(Paths.get(TABLE_PATH));
            table = content.stream().collect(Collectors.joining(""));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    private void readOicsError() {
        try {
            List<String> content = Files.readAllLines(Paths.get(OICS_ERROR_PATH));
            oicsErrorValue = content.stream().collect(Collectors.joining(""));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void readNoOicsError() {
        try {
            List<String> content = Files.readAllLines(Paths.get(NO_OICS_ERROR_PATH));
            noOicsErrorValue = content.stream().collect(Collectors.joining(""));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void replaceOicsError(List<String> errorInvoice) throws IOException {
        oicsErrorFlag = true;
        readOicsError();
        int counter = 0;
        for (String errId : errorInvoice) {
            String err = oicsErrorValue;
            err = err.replace("##OICS_S_NO##", Integer.toString(++counter));
            err = err.replace("##OICS_INVOICE_ID##", errId.split(",")[0]);
            err = err.replace("##OICS_INVOICE_NUM##", errId.split(",")[1]);
            table = table.replace("<!--##OICS_ERROR_ADD_NEW_ROW##-->", err);
        }
        pushReport();
    }

    public void replaceNoOicsError() throws IOException {
        readNoOicsError();
        table = table.replace("<!--##OICS_ERROR_ADD_NEW_ROW##-->", noOicsErrorValue);
        pushReport();
    }

    private void readReject() {
        try {
            List<String> content = Files.readAllLines(Paths.get(REJECT_PATH));
            rejectValue = content.stream().collect(Collectors.joining(""));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void replaceReject(String id, String num, String reason) {

        rejectFlag = true;

        try {
            readReject();

            String err = rejectValue;
            err = err.replace("##REJECT_INVOICE_ID##", id);
            err = err.replace("##REJECT_INVOICE_NUM##", num);
            err = err.replace("##REJECT_REASON##", reason);
            table = table.replace("<!--##REJECT_ADD_NEW_ROW##-->", err);

            pushReport();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }


    public void replaceNoReject() throws IOException {
        readNoReject();
        table = table.replace("<!--##REJECT_ADD_NEW_ROW##-->", noRejectValue);
        pushReport();
    }

    private void readNoReject() {
        try {
            List<String> content = Files.readAllLines(Paths.get(NO_REJECT_PATH));
            noRejectValue = content.stream().collect(Collectors.joining(""));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void readSuccessful() {
        try {
            List<String> content = Files.readAllLines(Paths.get(SUCCESSFUL_PATH));
            successfulValue = content.stream().collect(Collectors.joining(""));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void replaceSuccessful() throws IOException {
        String tmp = successfulValue;

        for (Map.Entry<String, String> map : successfulReport.replaceValueMap.entrySet()) {
            String value;
            value = map.getValue() == null ? "" : map.getValue().trim();

            if (map.getKey().trim().contains("_RESULT##") && (value.equalsIgnoreCase(PASS) || value.equalsIgnoreCase(FAIL)))
                value = passFailReplace(value);

            successfulValue = successfulValue.replace(map.getKey().trim(), value);
        }

        writeSuccessful();
        successfulValue = tmp;
        pushReport();
        successfulReport.replaceValueMap = new HashMap<>();
    }

    public void writeSuccessful() {
        table = table.replace("<!--##SUCCESSFUL_ADD_NEW_ROW##-->", successfulValue);
    }


    private String passFailReplace(String value) {
        return value.equalsIgnoreCase(PASS) ? PASS_HTML : FAIL_HTML;
    }

    private void replaceTableValues() {
        for (Map.Entry<String, String> map : replaceValueMap.entrySet())
            table = table.replace(map.getKey(), map.getValue());
    }


    public void setReportName(String reportName) {
        this.reportName = reportName;
        replaceValueMap.put("##REPORT_NAME##", this.reportName);
    }

    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
        replaceValueMap.put("##DATE_TIME##", this.dateTime);
    }

    public void setReportFileName(String reportFileName) {
        this.reportFileName = reportFileName;
        replaceValueMap.put("##REPORT_FILE_NAME##", this.reportFileName);
    }

    public void setReportSource(String reportSource) {
        this.reportSource = reportSource;
        replaceValueMap.put("##REPORT_SOURCE##", this.reportSource);
    }

    public void setReportProcessedOn(String reportProcessedOn) {
        this.reportProcessedOn = reportProcessedOn;
        replaceValueMap.put("##REPORT_PROCESSED_ON##", this.reportProcessedOn);
    }

    public void setTotalRecordsInFile(String totalRecordsInFile) {
        this.totalRecordsInFile = totalRecordsInFile;
        replaceValueMap.put("##TOTAL_RECORDS_IN_FILE##", this.totalRecordsInFile);
    }

    public void setTotalRecordsProcessedInErp(String totalRecordsProcessedInErp) {
        this.totalRecordsProcessedInErp = totalRecordsProcessedInErp;
        replaceValueMap.put("##TOTAL_RECORDS_PROCESSED_IN_ERP##", this.totalRecordsProcessedInErp);
    }

    public void setTotalRecordsErroedInErp(String totalRecordsErroedInErp) {
        this.totalRecordsErroedInErp = totalRecordsErroedInErp;
        replaceValueMap.put("##TOTAL_RECORDS_ERROED_IN_ERP##", this.totalRecordsErroedInErp);
    }

    public void setTotalRecordsOicsError(String totalRecordsOicsError) {
        this.totalRecordsOicsError = totalRecordsOicsError;
        replaceValueMap.put("##TOTAL_RECORDS_OICS_ERROR##", this.totalRecordsOicsError);
    }

    public void setRejectInvoiceId(String rejectInvoiceId) {
        this.rejectInvoiceId = rejectInvoiceId;
    }

    public void setRejectInvoiceNum(String rejectInvoiceNum) {
        this.rejectInvoiceNum = rejectInvoiceNum;
    }

    public void setRejectReason(String rejectReason) {
        this.rejectReason = rejectReason;
    }

    public void setResultSNo(String resultSNo) {
        this.resultSNo = resultSNo;
    }

    public void setResultFieldName(String resultFieldName) {
        this.resultFieldName = resultFieldName;
    }

    public void setResultFshValue(String resultFshValue) {
        this.resultFshValue = resultFshValue;
    }

    public void setResultErpValue(String resultErpValue) {
        this.resultErpValue = resultErpValue;
    }

    public void setResultResul(String resultResul) {
        this.resultResul = resultResul;
    }

    public void setOicsSNo(String oicsSNo) {
        this.oicsSNo = oicsSNo;
    }

    public void setOicsInvoiceId(String oicsInvoiceId) {
        this.oicsInvoiceId = oicsInvoiceId;
    }

    public void setOicsErrorValue(String oicsErrorValue) {
        this.oicsErrorValue = oicsErrorValue;
    }

    public void setRejectValue(String rejectValue) {
        this.rejectValue = rejectValue;
    }

    public void setSuccessfulValue(String successfulValue) {
        this.successfulValue = successfulValue;
    }

    public void setSuccessfulInvoiceIdFshValue(String successfulInvoiceIdFshValue) {
        this.successfulInvoiceIdFshValue = successfulInvoiceIdFshValue;
    }

    public void setSuccessfulInvoiceIdErpValue(String successfulInvoiceIdErpValue) {
        this.successfulInvoiceIdErpValue = successfulInvoiceIdErpValue;
    }

    public void setResultInvoiceIdResult(String resultInvoiceIdResult) {
        this.resultInvoiceIdResult = resultInvoiceIdResult;
    }

    public void setSuccessfulInvoiceNumFshValue(String successfulInvoiceNumFshValue) {
        this.successfulInvoiceNumFshValue = successfulInvoiceNumFshValue;
    }

    public void setSuccessfulInvoiceNumErpValue(String successfulInvoiceNumErpValue) {
        this.successfulInvoiceNumErpValue = successfulInvoiceNumErpValue;
    }

    public void setResultInvoiceNumResult(String resultInvoiceNumResult) {
        this.resultInvoiceNumResult = resultInvoiceNumResult;
    }

    public void setSuccessfulInvoiceCurrecyCodeFshValue(String successfulInvoiceCurrecyCodeFshValue) {
        this.successfulInvoiceCurrecyCodeFshValue = successfulInvoiceCurrecyCodeFshValue;
    }

    public void setSuccessfulInvoiceCurrecyCodeErpValue(String successfulInvoiceCurrecyCodeErpValue) {
        this.successfulInvoiceCurrecyCodeErpValue = successfulInvoiceCurrecyCodeErpValue;
    }

    public void setResultInvoiceCurrecyCodeResult(String resultInvoiceCurrecyCodeResult) {
        this.resultInvoiceCurrecyCodeResult = resultInvoiceCurrecyCodeResult;
    }

    public void setSuccessfulAmountFshValue(String successfulAmountFshValue) {
        this.successfulAmountFshValue = successfulAmountFshValue;
    }

    public void setSuccessfulAmountErpValue(String successfulAmountErpValue) {
        this.successfulAmountErpValue = successfulAmountErpValue;
    }

    public void setResultAmountResult(String resultAmountResult) {
        this.resultAmountResult = resultAmountResult;
    }

    private void pushReport() throws IOException {
        replaceTableValues();

        try (RandomAccessFile stream = new RandomAccessFile(REPORT_OUTPUT, "rw"); FileChannel channel = stream.getChannel()) {

            byte[] strBytes = table.getBytes();
            ByteBuffer buffer = ByteBuffer.allocate(strBytes.length);
            buffer.put(strBytes);
            buffer.flip();
            channel.write(buffer);
        }
    }

    public void publishReportFinal(String filename) throws IOException {

        DateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT_REPORT_NAME);
        Date date = new Date();

        if (!oicsErrorFlag) replaceNoOicsError();
        if (!rejectFlag) replaceNoReject();
        replaceTableValues();

        String reportPathDate = String.format("./AP-Invoice_%s_%s_%s.html", ++countReport, reportSource.toUpperCase(), dateFormat.format(date));

        String reportPath = "./AP-Invoice.html";
        Files.write(Paths.get(reportPathDate), table.getBytes());
        Files.write(Paths.get(reportPath), table.getBytes());

        try (RandomAccessFile stream = new RandomAccessFile(reportPathDate, "rw");

             FileChannel channel = stream.getChannel()) {

            byte[] strBytes = table.getBytes();
            ByteBuffer buffer = ByteBuffer.allocate(strBytes.length);
            buffer.put(strBytes);
            buffer.flip();
            channel.write(buffer);
        }
    }
}

