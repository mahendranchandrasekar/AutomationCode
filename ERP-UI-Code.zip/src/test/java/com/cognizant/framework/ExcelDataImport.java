package com.cognizant.framework;

public enum ExcelDataImport {;

    //DataSheet
    public static final String GeneralData = "General_Data";
    public static final String RegisterUserData = "RegisterUser_Data";

    //Selenium
    public static final String innerHTML = "innerHTML";
    public static final String value = "value";
    public static final String title = "title";


    //ARCS
    public static final String MatchType = "MatchType";
    public static final String B4c_OfPcGlVFsh= "B4C_OF_PC_GL_v_FSH";
    public static final String B4c_PcDmVFsh= "B4C PC DM V FSH";

    //AP Invoice
    public static final String SupplierSite= "SupplierSite";
    public static final String LinesAmount="LinesAmount";
    public static final String HDRAmount="HDRAmount";
    public static final String ContextValue="ContextValue";
    public static final String ReceiptCreation="ReceiptCreation";


    //GL General Ledger
    public static final String DataAccessSet= "DataAccessSet";
    public static final String JournalStatus= "JournalStatus";
    public static final String AccountingPeriod= "AccountingPeriod";
    public static final String Currency= "Currency";
    public static final String ConversionRate= "ConversionRate";
    public static final String ConversionRateType= "ConversionRateType";



}
