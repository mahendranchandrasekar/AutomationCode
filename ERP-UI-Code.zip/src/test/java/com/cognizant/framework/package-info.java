/**
 * Package containing core libraries of Cognizant CRAFT Framework Request you to
 * keep these unchanged In future, we may provide support for any bugs fixes or
 * feature addition via these files. Any customizations support with these files
 * is not under CRAFT Support purview.
 * 
 * @author Cognizant
 */
package com.cognizant.framework;