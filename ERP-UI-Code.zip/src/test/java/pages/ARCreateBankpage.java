package pages;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.ScriptHelper;
import com.cognizant.framework.Status;
import javafx.scene.control.Tab;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.Select;

import javax.swing.*;

public class ARCreateBankpage extends MasterPages {

    // Elements

    //Links for Create bank
    private final By navigator = By.xpath( "//a[@title='Navigator']" );
    private final By setupmaintenance = By.xpath( "//*[contains(@id,'nv_itemNode_tools_setup_and_maintenance')]" );
    private final By searchtasks = By.xpath( "//input[@type='text']" );
    private final By searchresults = By.xpath( "//table[@summary='Tasks']/tbody/tr[1]/td[1]" );
    private final By searchresultslink = By.xpath( "//table[@summary='Tasks']/tbody/tr[1]/td[1]/span" );
    private final By searchresultlink1 = By.xpath( "//table[@summary='Tasks']/tbody/tr[1]/td[1]/span" );
    private final By searchresultspopup = By.xpath( "//table[@summary='Search Task Results']/tbody/tr[6]/td[1]" );
    private final By country = By.xpath( "//label[text()='Country']/ancestor::tr[1]/td[2]//input" );
    private final By bankname = By.xpath( "//label[text()='Bank Name']/ancestor::tr[1]/td[2]//input" );
    private final By alternatebankname = By.xpath( "//label[text()='Alternate Bank Name']/ancestor::tr[1]/td[2]//input" );
    private final By bankcode = By.xpath( "//label[text()='Bank Code']/ancestor::tr[1]/td[2]//input" );
    private final By description = By.xpath( "//label[text()='Description']/ancestor::tr[1]/td[2]//input" );
    private final By taxpayerID = By.xpath( "//label[text()='Taxpayer ID']/ancestor::tr[1]/td[2]//input" );
    private final By taxregistrationnumber = By.xpath( "//label[text()='Tax Registration Number']/ancestor::tr[1]/td[2]//input" );
    private final By managebankheader = By.xpath( "//h1[text()='Manage Banks']" );
    private final By createbankheader = By.xpath( "//*[text()='Create Bank']" );

    //Links for Create branch
    private final By branchbank = By.xpath( "//label[text()='Bank']/ancestor::tr[1]/td[2]//input" );
    private final By branchname = By.xpath( "//label[text()='Branch Name']/ancestor::tr[1]/td[2]//input" );
    private final By branchcountry = By.xpath( "//label[text()='Country']/ancestor::tr[1]/td[2]//input" );
    private final By alternatebranchname = By.xpath( "//label[text()='Alternate Branch Name']/ancestor::tr[1]/td[2]//input" );
    private final By sortcode = By.xpath( "//label[text()='Sort Code']/ancestor::tr[1]/td[2]//input" );
    private final By descirption = By.xpath( "//label[text()='Description']/ancestor::tr[1]/td[2]//input" );
    private final By biccode = By.xpath( "//label[text()='BIC Code']/ancestor::tr[1]/td[2]//input" );
    private final By branchnumbertype = By.xpath( "//label[text()='Branch Number Type']/ancestor::tr[1]/td[2]" );
    private final By bankbranchtype = By.xpath( "//label[text()='Bank Branch Type']/ancestor::tr[1]/td[2]" );
    private final By EDIIDnumber = By.xpath( "//label[text()='EDI ID Number']/ancestor::tr[1]/td[2]//input" );
    private final By EFTnumber = By.xpath( "//label[text()='EFT Number']/ancestor::tr[1]/td[2]//input" );
    private final By EDIlocation = By.xpath( "//label[text()='EDI Location']/ancestor::tr[1]/td[2]//input" );
    private final By RFCidentifier = By.xpath( "//label[text()='RFC Identifier']/ancestor::tr[1]/td[2]" );
    private final By brancnhheader = By.xpath( "//*[contains(@id,'SPph::_afrTtxt')]/div/h3" );
    private final By createbrancnhheader = By.xpath( "//h3[text()='Create Bank Branch']" );


    //Links for Create bank account
    private final By managebankaccheader = By.xpath( "//h1[text()='Manage Bank Accounts']" );
    private final By createbankaccheader = By.xpath( "//*[contains(@id,'SPph::_afrTtxt')]/div/h3" );
    private final By bankbranch = By.xpath( "//label[text()='Bank Branch']/ancestor::tr[1]/td[2]//input" );
    private final By accountname = By.xpath( "//label[text()='Account Name']/ancestor::tr[1]/td[2]//input" );
    private final By accountnumber = By.xpath( "//label[text()='Account Number']/ancestor::tr[1]/td[2]//input" );
    private final By currency = By.xpath( "//label[text()='Currency']/ancestor::tr[1]/td[2]//select" );
    private final By legalentityname = By.xpath( "//label[text()='Legal Entity Name']/ancestor::tr[1]/td[2]//input" );
    private final By accounttype = By.xpath( "//label[text()='Account Type']/ancestor::tr[1]/td[2]//select" );
    private final By Description = By.xpath( "//label[text()='Description']/ancestor::tr[1]/td[2]//input" );
    private final By IBAN = By.xpath( "//label[text()='IBAN']/ancestor::tr[1]/td[2]//input" );
    private final By bussajaxValidate = By.xpath( "//div[contains(@class,'AFDetectExpansion')]/../tbody/tr[1]/td[1]/ul[1]/li[1]" );
    private final By checkdigit = By.xpath( "//label[text()='Check Digit']/ancestor::tr[1]/td[2]//input" );
    private final By secondaryaccountrefer = By.xpath( "//label[text()='Secondary Account Reference']/ancestor::tr[1]/td[2]//input" );
    private final By accountsuffix = By.xpath( "//label[text()='Account Suffix']/ancestor::tr[1]/td[2]//input" );
    private final By accountuse = By.xpath( "//label[text()='Account Use']/ancestor::tr[1]/td[2]" );
    private final By busunitaccess = By.xpath( "//*[contains(@id,'showDetailItem4::ti')]" );
    private final By addbusunitaccess = By.xpath( "//img[@alt='Create']" );
    private final By businessunit = By.xpath( "//label[text()='Business Unit']/ancestor::tr[1]/td[2]//input" );
    private final By businessunitdrpdwn = By.xpath( "//*[contains(@id,'bUNameId::lovIconId')]" );
    private final By businesunitselection = By.xpath( "//table[@role='grid']/tr[3]" );
    //Button for create bank & branch
    private final By btnsearch = By.xpath( "//*[contains(@alt,'Search')]" );
    private final By btncreatebank = By.xpath( "//img[@alt='Create']" );
    private final By btnsave = By.xpath( "//span[text()='Save']" );
    private final By btnsavenclose = By.xpath( "//a[@accesskey='S']" );
    private final By btncancel = By.xpath( "//a[@accesskey='C']" );
    private final By plusicon = By.xpath( "//img[@alt='Create']" );
    private final By btncreatebranch = By.xpath( "//img[@alt='Create']" );
    private final By btncreatebankaccount = By.xpath( "//img[@alt='Create']" );
    private final By btnok = By.xpath( "//button[@accesskey='K']" );
    private final By btyes = By.xpath( "//button[text()='Yes']" );
    private final By btndone = By.xpath( "//a[@accesskey='o']" );
    //bu popup
    private final By btsearchpopup = By.xpath( "//*[contains(@id,'bUNameId::_afrLovInternalQueryId::search')]" );
    private final By searchrselct = By.xpath( "//*[contains(@id,'bUNameId_afrLovInternalTableId::db')]/table/tbody/tr[1]/td[2]/div/table/tbody/tr/td" );
    private final By btnokpopup = By.xpath( "//*[contains(@id,'bUNameId::lovDialogId::ok')]" );
    // page loading time
    public static final int PAGELOADTIMEOUT = 90;
    // individual element load time
    public static final int ELEMENTTIMEOUT = 60;

    public static final int SCRIPTTIME = 5;
    public static final int QUERYRESPONSE = 15;

    /**
     * Constructor to initialize the functional library
     *
     * @param scriptHelper The {@link ScriptHelper} object passed from the
     *                     {@link DriverScript}
     */
    public ARCreateBankpage(ScriptHelper scriptHelper) {
        super( scriptHelper );
    }

    private void clickoncreatebank() {
        isElementAvailable( btncreatebank, PAGELOADTIMEOUT );
        driver.findElement( btncreatebank ).click();
        oracleObjectRender( SCRIPTTIME );
    }

    private void createbankheadervalidation() {
        isElementAvailable( createbankheader, PAGELOADTIMEOUT );
        driver.findElement( createbankheader ).isDisplayed();
        String header2 = driver.findElement( createbankheader ).getText();
        String Staticheader2 = "Create Bank";
        Assert.assertEquals( "Header : text are same", header2, Staticheader2 );
    }

    private void managebankheadervalidation() {
        //Header validation
        isElementAvailable( managebankheader, PAGELOADTIMEOUT );
        driver.findElement( managebankheader ).isDisplayed();
        String header1 = driver.findElement( managebankheader ).getText();
        String Staticheader = "Manage Banks";
        Assert.assertEquals( "Header : text are same", header1, Staticheader );
    }

    private void searchtask() {
        isElementAvailable( searchtasks, PAGELOADTIMEOUT );
        driver.findElement( searchtasks ).click();
        driver.findElement( searchtasks ).sendKeys( dataTable.getData( "General_Data", "Search Tasks" ) );
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( btnsearch, PAGELOADTIMEOUT );
        driver.findElement( btnsearch ).click();
        oracleObjectRender( SCRIPTTIME );
        while (driver.findElements( searchresultslink ).size() >= 1) {
            driver.findElement( searchresultslink ).click();
            PauseScript( 6 );
            if ( driver.findElements( plusicon ).size() >= 1 )
                break;
        }
    }

    private void clickoncreatebranch() {
        isElementAvailable( btncreatebranch, PAGELOADTIMEOUT );
        driver.findElement( btncreatebranch ).click();
        oracleObjectRender( SCRIPTTIME );
    }

    public void createbank() {
        searchtask();
        oracleObjectRender( SCRIPTTIME );
        clickoncreatebank();
        PauseScript( 3 );
        createbankheadervalidation();
        isElementAvailable( country, PAGELOADTIMEOUT );
        driver.findElement( country ).click();
        driver.findElement( country ).sendKeys( dataTable.getData( "General_Data", "Country" ) );
        driver.findElement( country ).sendKeys( Keys.TAB );
        isElementAvailable( bankname, PAGELOADTIMEOUT );
        driver.findElement( bankname ).click();
        driver.findElement( bankname ).sendKeys( dataTable.getData( "General_Data", "Bank Name" ) );
        PauseScript( 2 );
        report.updateTestLog( "Verify the entered data for Bank Name", " Data Entered for Bank Name has been completed successfully", Status.PASS );
        driver.findElement( btnsavenclose ).click();
        PauseScript( 10 );
        String bankname = (dataTable.getData( "General_Data", "Bank Name" ));
        report.updateTestLog( "Verify the Bank Name", " Bank Name- " + bankname + " has been created successfully", Status.PASS );
    }


    public void createbranch() {
        searchtask();
        oracleObjectRender( SCRIPTTIME );
        clickoncreatebranch();
        isElementAvailable( branchbank, PAGELOADTIMEOUT );
        driver.findElement( branchbank ).sendKeys( dataTable.getData( "General_Data", "Branch Bank Name" ) );
        driver.findElement( branchbank ).sendKeys( Keys.TAB );
        PauseScript( 1 );
        isElementAvailable( branchname, PAGELOADTIMEOUT );
        driver.findElement( branchname ).click();
        driver.findElement( branchname ).sendKeys( dataTable.getData( "General_Data", "Branch Name" ) );
        PauseScript( 2 );
        report.updateTestLog( "Verify the entered data for Branch Name", "Data Entered for Creating Branch Name has been completed", Status.PASS );
        driver.findElement( btnsavenclose ).click();
        PauseScript( 10 );
        String branchname = (dataTable.getData( "General_Data", "Branch Name" ));
        report.updateTestLog( "Verify the Branch Name", " Branch Name - " + branchname + " has been created successfully", Status.PASS );
    }

    public void managebankaccheadervalidation() {
        isElementAvailable( managebankaccheader, PAGELOADTIMEOUT );
        driver.findElement( managebankaccheader ).isDisplayed();
        String header1 = driver.findElement( managebankheader ).getText();
        String Staticheader = "Manage Bank Accounts";
        Assert.assertEquals( "Header : text are same", header1, Staticheader );
    }

    private void addbusinessunitaccess() {
        isElementAvailable( busunitaccess, PAGELOADTIMEOUT );
        PauseScript( 2 );
        driver.findElement( busunitaccess ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( addbusunitaccess, PAGELOADTIMEOUT );
        driver.findElement( addbusunitaccess ).click();
        oracleObjectRender( QUERYRESPONSE );
        driver.findElement( businessunit ).click();
        driver.findElement( businessunit ).sendKeys( dataTable.getData( "General_Data", "Account Business Unit" ) );
        oracleObjectRender( QUERYRESPONSE );
        driver.findElement( bussajaxValidate ).click();
        oracleObjectRender( SCRIPTTIME );
        PauseScript( 3 );
        driver.findElement( btnok ).click();
        oracleObjectRender( SCRIPTTIME );
    }

    public void createbankaccount() {
        searchtask();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( btncreatebankaccount, PAGELOADTIMEOUT );
        driver.findElement( btncreatebankaccount ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( bankbranch, PAGELOADTIMEOUT );
        driver.findElement( bankbranch ).click();
        driver.findElement( bankbranch ).sendKeys( dataTable.getData( "General_Data", "Account Bank Branch" ) );
        isElementAvailable( accountname, PAGELOADTIMEOUT );
        driver.findElement( accountname ).click();
        driver.findElement( accountname ).sendKeys( dataTable.getData( "General_Data", "Account Name" ) );
        isElementAvailable( accountnumber, PAGELOADTIMEOUT );
        driver.findElement( accountnumber ).click();
        driver.findElement( accountnumber ).sendKeys( dataTable.getData( "General_Data", "Account Number" ) );
        isElementAvailable( currency, PAGELOADTIMEOUT );
        Select drpcurrency = new Select( driver.findElement( currency ) );
        drpcurrency.selectByVisibleText( dataTable.getData( "General_Data", "Currency" ) );
        isElementAvailable( legalentityname, PAGELOADTIMEOUT );
        driver.findElement( legalentityname ).click();
        driver.findElement( legalentityname ).sendKeys( dataTable.getData( "General_Data", "Legal Entity Name" ) );
        oracleObjectRender( SCRIPTTIME );
        driver.findElement( legalentityname ).sendKeys( Keys.TAB );
        addbusinessunitaccess();
        report.updateTestLog( "Verify the Entered data for Creating the Bank Account", "Data Entered has been completed for Bank Account Creation", Status.PASS );
        driver.findElement( btnsavenclose ).click();
        oracleObjectRender( SCRIPTTIME );
        driver.findElement( btyes ).click();
        oracleObjectRender( SCRIPTTIME );
        String Accountname = (dataTable.getData( "General_Data", "Account Name" ));
        report.updateTestLog( "Verify the Create Bank Account", "Bank Account - " + Accountname + " has been created successfully", Status.PASS );
    }
}




