package pages;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.ScriptHelper;
import com.cognizant.framework.ExcelDataImport;
import com.cognizant.framework.Status;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;

/**
 * FCCS SignOnPage class

 */
public class NavigationPage extends MasterPages {

    //Page Sync Config

    // page loading time
    public static final int PAGELOADTIMEOUT = 90;
    // individual element load time
    public static final int ELEMENTTIMEOUT = 60;
    // Oracle query response
    public static final long QUERYRESPONSE = 15;
    // object render script
    public static final long SCRIPTTIME = 5;


    // UI Map object definitions

    private final By navigator= By.xpath("//a[@title='Navigator']");
    private final By notificationsBellIcon= By.xpath("//a[starts-with(@title,'Notifications')]/child::*");
    private final By notificationsSearchBox= By.xpath("//input[@id='pt1:_UISatr:0:it1::content']");
    private final By notificationsSearchButton= By.xpath("//button[@id='pt1:_UISatr:0:cb1']");
    private final By notificationsSearchRecord= By.xpath("//div[contains(@id,':psl2::c')]/child::*/child::*/child::*/td[1]/a");
    private final By approveButtonInChild= By.xpath("//*[text()='Approve']");
    private final By rejectButtonInChild= By.xpath("//*[text()='Reject']");
    private final By submitButtonInChild= By.xpath("//span[text()='Submit']");
    private final By commentBoxPlusIcon= By.xpath("//*[@id='adCmtBt::icon']");
    private final By commentBoxInChild= By.xpath("//label[text()='Comment']/following::textarea");
    private final By commentBoxOkButton= By.xpath("//label[text()='Comment']/following::textarea/../../../../../../../../../../../../../tr[3]/td[2]/table/tbody/tr/td[1]/span/button[1]");

    private final By jobsLink= By.xpath("//span[(text()='Jobs')]");
    private final By periodsLink= By.xpath("//span[(text()='Periods')]");
    private final By matchingLink= By.xpath("//span[(text()='Matching')]");
    private final By journalsLink= By.xpath("//span[text()='General Accounting']/following::div[2]/table/tbody/tr/td[3]/a");
    private final By myReceiptsLink= By.xpath("//span[text()='Procurement']/following::div[4]/table/tbody/tr/td[3]/a");
    private final By assetsLink= By.xpath("//span[text()='Fixed Assets']/following::div[1]/table/tbody/tr/td[3]/a");
    private final By invoiceLink= By.xpath("//span[text()='Payables']/following::div[2]/table/tbody/tr/td[3]/a");
    private final By transactionsLink= By.xpath("//span[text()='Intercompany Accounting']/../following-sibling::div[1]/table/tbody/tr[1]/td[3]/a");
    private final By manageLeasesLink= By.xpath("//a[text()='Manage Leases']");
    private final By manageInvoicesLink= By.xpath("//a[text()='Manage Invoices']");
    private final By createTransactionsLink= By.xpath("//a[contains(text(),'Create Transaction')]");
    private final By periodCloseLink= By.xpath("//a[contains(text(),'Period Close')]");
    private final By toolsIcon= By.xpath("//a[contains(text(),'Tools')]");
    private final By homeIcon= By.xpath("//a[contains(@id,'_FOpt1:_UIShome')]/child::*");
    private final By scheduledProcessesIcon= By.xpath("//a[contains(text(),'Scheduled Processes')]");

    private final By journalTasksMenu= By.xpath("//img[contains(@id,'JournalEntryPage_itemNode_FndTasksList::icon')]");
    private final By invoiceTasksMenu = By.xpath("//img[@title='Tasks']");
    private final By createInvoiceLink = By.xpath("//a[contains(text(),'Create Recurring Invoices')]/../../li[1]/a");
    private final By transactionTasksMenu= By.xpath("//img[contains(@id,'transactions_processing:0:_FOTsdiTransactions_itemNode_FndTasksList::icon')]");
    private final By assetsTasksMenu= By.xpath("//img[contains(@id,'AssetsDashboard_itemNode__FndTasksList::icon')]");
    private final By createJournalLink= By.xpath("//a[text()='Create Journal']");
    private final By manageIntercompanyInbound= By.xpath("//a[text()='Manage Intercompany Inbound Transactions']");
    private final By autoReverseLink= By.xpath("//a[text()='Run AutoReverse']");
    private final By manageJournalsLink= By.xpath("//a[text()='Manage Journals']");
    private final By dataAccessSetText= By.xpath("//td[contains(text(),'Data Access Set')]/../td[5]");
    //private final By changeLink= By.xpath("//a[text()='Change']");
    private final By dataAccessSetDropDown= By.xpath("//select[contains(@id,'_general_accounting_journals:0:_FOTsr2:0:soc1::content')]");
    private final By dataAccessSetOkButton= By.xpath("//button[contains(@id,'general_accounting_journals:0:_FOTsr2:0:d1::ok')]");
    //private final By dataAccessSetCancelButton= By.xpath("//button[contains(@id,'general_accounting_journals:0:_FOTsr2:0:d1::cancel')]");
    private final By cancelButton= By.xpath("//span[text()='ancel']");
    private final By journalSignOutDropdown= By.xpath("//*[contains(@id,'UIScmil1u::icon')]");
    private final By signOutLink= By.xpath("//a[text()='Sign Out']");
    private final By journalConfirmButton= By.xpath("//button[text()=' Confirm']");
    private final By arcsSignOutDropdown= By.xpath("//*[contains(@id,'cil12::icon')]");
    private final By arcsSignOutOkButton= By.xpath("//button[@id='pt_d1::ok']");


    /**
     * Constructor to initialize the page
     *
     * @param scriptHelper
     *            The {@link ScriptHelper} object passed from the
     *            {@link DriverScript}
     */
    public NavigationPage(ScriptHelper scriptHelper) {
        super(scriptHelper);
        isElementAvailable(navigator,ELEMENTTIMEOUT);
    }

    public void changeDataSetAccess() {
        if (driver.findElement(dataAccessSetText).getText().equalsIgnoreCase(dataTable.getData(ExcelDataImport.GeneralData, ExcelDataImport.DataAccessSet))) {
            Assert.assertEquals(driver.findElement(dataAccessSetText).getText(), (dataTable.getData(ExcelDataImport.GeneralData, ExcelDataImport.DataAccessSet)));
        } else {
            oracleObjectRender(SCRIPTTIME);
            isElementAvailable(dataAccessSetDropDown, ELEMENTTIMEOUT);
            Select selectDropDown = new Select(driver.findElement(dataAccessSetDropDown));
            selectDropDown.selectByVisibleText(dataTable.getData(ExcelDataImport.GeneralData, "DataAccessSet"));
            isElementAvailable(dataAccessSetOkButton, ELEMENTTIMEOUT);
            driver.findElement(dataAccessSetOkButton).click();
            oracleObjectRender(QUERYRESPONSE);
        }
    }


    public void menuNavigation() {
        isElementAvailable(navigator, ELEMENTTIMEOUT);
        driver.findElement(navigator).click();
    }

    public void clickOnMainMyReceiptsLink() {
        isElementAvailable(myReceiptsLink, ELEMENTTIMEOUT);
        driver.findElement(myReceiptsLink).click();
    }


    public void clickOnMainJournalLink() {
        isElementAvailable(journalsLink, ELEMENTTIMEOUT);
        driver.findElement(journalsLink).click();
    }


    public void clickOnMainJobsLink() {
        isElementAvailable(jobsLink, PAGELOADTIMEOUT);
        driver.findElement(jobsLink).click();
    }

    public void clickOnMainMatchingLink() {
        isElementAvailable(matchingLink, ELEMENTTIMEOUT);
        driver.findElement(matchingLink).click();
    }

    public void clickOnMainPeriodLink() {
        isElementAvailable(periodsLink, ELEMENTTIMEOUT);
        driver.findElement(periodsLink).click();
    }

    public void clickOnMainTransactionsLink() {
        isElementAvailable(transactionsLink, ELEMENTTIMEOUT);
        driver.findElement(transactionsLink).click();
    }

    public void clickOnMainPeriodCloseLink() {
        isElementAvailable(periodCloseLink, ELEMENTTIMEOUT);
        driver.findElement(periodCloseLink).click();
        report.updateTestLog("Period Close page is opened", "The user is able to view the navigation link and the Period Close page is opened", Status.PASS);
    }

    public void clickOnMainAssetsLink() {
        isElementAvailable(assetsLink, ELEMENTTIMEOUT);
        driver.findElement(assetsLink).click();
    }

    public void clickOnMainInvoiceLink() {
        isElementAvailable(invoiceLink, ELEMENTTIMEOUT);
        scrollPageDown();
        driver.findElement(invoiceLink).click();
        //jsClick(invoiceLink);
    }

    public void clickOnJournalTaskMenu() {
        isElementAvailable(journalTasksMenu,ELEMENTTIMEOUT);
        driver.findElement(journalTasksMenu).click();
    }

    public void clickOnInvoiceTaskMenu() {
        oracleObjectRender(SCRIPTTIME);
        isElementAvailable(invoiceTasksMenu,ELEMENTTIMEOUT);
        driver.findElement(invoiceTasksMenu).click();
        PauseScript( 2 );
    }

    public void clickOnCreateInvoiceLink() {
        isElementAvailable(createInvoiceLink,PAGELOADTIMEOUT);
        driver.findElement(createInvoiceLink).click();
    }

    public void clickOnTransactionTaskMenu() {
        isElementAvailable(transactionTasksMenu,ELEMENTTIMEOUT);
        driver.findElement(transactionTasksMenu).click();
    }

    public void clickOnAssetsTaskMenu() {
        isElementAvailable(assetsTasksMenu,ELEMENTTIMEOUT);
        driver.findElement(assetsTasksMenu).click();
    }

    public void clickOnHomeIcon() {
        isElementAvailable(homeIcon,PAGELOADTIMEOUT);
        driver.findElement(homeIcon).click();
    }

    public void clickOntoolsIcon() {
        oracleObjectRender(QUERYRESPONSE);
        isElementAvailable(toolsIcon,PAGELOADTIMEOUT);
        driver.findElement(toolsIcon).click();
    }

    public void verifyTheScheduledProcessesIcon(String processNumber) {
        isElementAvailable(scheduledProcessesIcon,PAGELOADTIMEOUT);
        driver.findElement(scheduledProcessesIcon).click();
        String autoReverseStatus="//span[contains(text(),'" + processNumber + "')]/../../../tr[1]/td[3]/span/a";
        By ddgenericXpathForSelection = By.xpath(autoReverseStatus);
        isElementAvailable(ddgenericXpathForSelection,ELEMENTTIMEOUT);
        try{Assert.assertEquals(driver.findElement(ddgenericXpathForSelection).getAttribute("innerHTML"), (dataTable.getData(ExcelDataImport.GeneralData, "AutoReversalStatus")));
            report.updateTestLog("Tools - Scheduled Processes page", "verify AutoReversal Process Number is Succeeded", Status.PASS);
        } catch(Exception e) {
            report.updateTestLog("Tools - Scheduled Processes page", "verify AutoReversal Process Number is not Succeeded", Status.FAIL);
        }
    }


    public void approveInvoiceRequest() {
        String approvalData= dataTable.getData(ExcelDataImport.GeneralData, "InvoiceApprovalFlag");
        isElementAvailable(notificationsBellIcon, ELEMENTTIMEOUT);
        driver.findElement(notificationsBellIcon).click();
        oracleObjectRender(SCRIPTTIME);
        report.updateTestLog("Oracle Homepage", "The landing page is Oracle Homepage", Status.PASS);
        isElementAvailable(notificationsSearchBox, PAGELOADTIMEOUT);
        driver.findElement(notificationsSearchBox).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "InvoiceNumber"));
        oracleObjectRender(SCRIPTTIME);
        isElementAvailable(notificationsSearchButton, ELEMENTTIMEOUT);
        driver.findElement(notificationsSearchButton).click();
        oracleObjectRender(QUERYRESPONSE);
        report.updateTestLog("Searching the invoice from Pending Notification", "Team leader should be able to search the invoice request from Pendng Notification", Status.PASS);
        isElementAvailable(notificationsSearchRecord, ELEMENTTIMEOUT);
        driver.findElement(notificationsSearchRecord).click();
        oracleObjectRender(QUERYRESPONSE);

        Set<String> handler = driver.getWindowHandles();
        Iterator<String> itr = handler.iterator();
        String parentWindowId = itr.next();
        String childWindowId = itr.next();
        driver.switchTo().window(childWindowId);
        oracleObjectRender(SCRIPTTIME);
        this.approvalProcess(approvalData);
        driver.switchTo().window(parentWindowId);
        oracleObjectRender(SCRIPTTIME);
        isElementAvailable(notificationsBellIcon, ELEMENTTIMEOUT);
        driver.findElement(notificationsBellIcon).click();
        report.updateTestLog("Oracle Homepage", "The user should be able to switch back to Oracle Homepage successfully", Status.PASS);
        oracleObjectRender(QUERYRESPONSE);
    }

    public void approvalProcess(String approvalData) {
        try {
            switch(approvalData.toLowerCase()){
                case "approve":
                    report.updateTestLog("Approval of Invoice in Child Window", "Team leader should be able to approve the invoice request for the corresponding Supplier", Status.PASS);
                    isElementAvailable(approveButtonInChild, ELEMENTTIMEOUT);
                    driver.findElement(approveButtonInChild).click();
                    oracleObjectRender(SCRIPTTIME);
                    isElementAvailable(commentBoxInChild, PAGELOADTIMEOUT);
                    driver.findElement(commentBoxInChild).sendKeys(dataTable.getData(ExcelDataImport.GeneralData,"ReasonForRejection"));
                    oracleObjectRender(SCRIPTTIME);
                    isElementAvailable(submitButtonInChild, ELEMENTTIMEOUT);
                    driver.findElement(submitButtonInChild).click();
                    oracleObjectRender(SCRIPTTIME);
                    break;
                case "reject":
                    report.updateTestLog("Rejection of Invoice in Child Window", "Team leader should be able to reject the invoice request for the corresponding Supplier", Status.PASS);
                    isElementAvailable(rejectButtonInChild, ELEMENTTIMEOUT);
                    driver.findElement(rejectButtonInChild).click();
                    oracleObjectRender(SCRIPTTIME);
                    /*isElementAvailable(commentBoxPlusIcon, PAGELOADTIMEOUT);
                    driver.findElement(commentBoxPlusIcon).click();*/
                    isElementAvailable(commentBoxInChild, PAGELOADTIMEOUT);
                    driver.findElement(commentBoxInChild).sendKeys(dataTable.getData(ExcelDataImport.GeneralData,"ReasonForRejection"));
                    isElementAvailable(submitButtonInChild, ELEMENTTIMEOUT);
                    driver.findElement(submitButtonInChild).click();

                    //oracleObjectRender(SCRIPTTIME);
                    /*isElementAvailable(submitButtonInChild, ELEMENTTIMEOUT);
                    driver.findElement(submitButtonInChild).click();*/
                    //oracleObjectRender(SCRIPTTIME);
                    break;
                default :
                    break;

            }
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    public void clickOnCreateJournalLink() {
        oracleObjectRender(SCRIPTTIME);
        isElementAvailable(createJournalLink,PAGELOADTIMEOUT);
        driver.findElement(createJournalLink).click();
    }

    public void clickOnManageIntercompanyInboundTransactionLink() {
        isElementAvailable(manageIntercompanyInbound,PAGELOADTIMEOUT);
        driver.findElement(manageIntercompanyInbound).click();
    }

    public void clickOnCreateTransactionLink() {
        oracleObjectRender(SCRIPTTIME);
        isElementAvailable(createTransactionsLink,PAGELOADTIMEOUT);
        driver.findElement(createTransactionsLink).click();
    }

    public void clickOnManageLeasesLink() {
        oracleObjectRender(SCRIPTTIME);
        isElementAvailable(manageLeasesLink,PAGELOADTIMEOUT);
        driver.findElement(manageLeasesLink).click();
    }


    public void clickOnManageInvoiceLink() {
        oracleObjectRender(SCRIPTTIME);
        isElementAvailable(manageInvoicesLink,PAGELOADTIMEOUT);
        driver.findElement(manageInvoicesLink).click();
    }

    public void clickOnRunAutoReverseLink() {
        isElementAvailable(autoReverseLink,PAGELOADTIMEOUT);
        driver.findElement(autoReverseLink).click();
    }
    public void clickOnCancelButton() {
        isElementAvailable(cancelButton, ELEMENTTIMEOUT);
        driver.findElement(cancelButton).click();
        oracleObjectRender(QUERYRESPONSE);
    }

    public void clickOnManageJournalsLink() {
        oracleObjectRender(SCRIPTTIME);
        isElementAvailable(manageJournalsLink,PAGELOADTIMEOUT);
        driver.findElement(manageJournalsLink).click();
    }

    public void signoutFromApplication() {
        oracleObjectRender(SCRIPTTIME);
        isElementAvailable(journalSignOutDropdown,ELEMENTTIMEOUT);
        driver.findElement(journalSignOutDropdown).click();

        isElementAvailable(signOutLink,ELEMENTTIMEOUT);
        driver.findElement(signOutLink).click();

        isElementAvailable(journalConfirmButton,ELEMENTTIMEOUT);
        driver.findElement(journalConfirmButton).click();
        oracleObjectRender(SCRIPTTIME);oracleObjectRender(SCRIPTTIME);
    }

    public void signoutAndCloseApplication() {
        oracleObjectRender(SCRIPTTIME);
        isElementAvailable(journalSignOutDropdown,ELEMENTTIMEOUT);
        driver.findElement(journalSignOutDropdown).click();

        isElementAvailable(signOutLink,ELEMENTTIMEOUT);
        driver.findElement(signOutLink).click();

        isElementAvailable(journalConfirmButton,ELEMENTTIMEOUT);
        driver.findElement(journalConfirmButton).click();
        oracleObjectRender(SCRIPTTIME);oracleObjectRender(SCRIPTTIME);
        driver.close();
    }

    public void arcsSignout() {
        isElementAvailable(arcsSignOutDropdown,ELEMENTTIMEOUT);
        driver.findElement(arcsSignOutDropdown).click();

        isElementAvailable(signOutLink,ELEMENTTIMEOUT);
        driver.findElement(signOutLink).click();

        isElementAvailable(arcsSignOutOkButton,PAGELOADTIMEOUT);
        driver.findElement(arcsSignOutOkButton).click();
    }
}