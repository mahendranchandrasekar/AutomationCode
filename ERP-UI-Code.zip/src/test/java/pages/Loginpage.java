package pages;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.ScriptHelper;
import com.cognizant.framework.Status;
import org.openqa.selenium.By;

public class Loginpage extends MasterPages {

        //Page Sync Config

        // page loading time
        public  static  final int PAGELOADTIMEOUT = 90;
        // individual element load time
        public static final int ELEMENTTIMEOUT = 60;
        // slowdown script
        public static final int SCRIPTTIME = 5;

        // Text boxes
        private final By ARtxtUsername = By.id("userid");
        private final By ARtxtPassword = By.id("password");

        // Buttons
        private final By ARbtnLogin = By.id("btnActive");

    /**
     * Constructor to initialize the functional library
     *
     * @param scriptHelper The {@link ScriptHelper} object passed from the
     *                     {@link DriverScript}
     */
    public Loginpage(ScriptHelper scriptHelper) {
        super(scriptHelper);
        isElementAvailable(ARtxtUsername,ELEMENTTIMEOUT);
        if (!driver.getTitle().contains("Sign In")) {
            report.updateTestLog("Verify page title", "Sign-in page displayed!", Status.PASS);
        }
    }

    public void loginAsValidUser() {
        login();
        //return new ARLoginpage(scriptHelper);
    }

    private void login() {
        isElementAvailable(ARtxtUsername,PAGELOADTIMEOUT);
        String userNameData = dataTable.getData("General_Data", "Username");
        String passwordData = dataTable.getData("General_Data", "Password");
        driver.findElement(ARtxtUsername).sendKeys(userNameData);
        driver.findElement(ARtxtPassword).sendKeys(passwordData);
        report.updateTestLog(" Login",
                "Enter login credentials: ", Status.DONE);
        driver.findElement(ARbtnLogin).click();
    }

    public Loginpage loginAsInvalidUser() {
        login();
        return new Loginpage(scriptHelper); // Return new object to indicate an
        // actual page navigation
    }

}
