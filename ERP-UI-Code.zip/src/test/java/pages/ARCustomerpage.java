package pages;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.ScriptHelper;
import com.cognizant.framework.Status;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import java.text.DateFormat;
import java.util.Date;
import java.text.SimpleDateFormat;

public class ARCustomerpage extends MasterPages {

    // Elements

    //Links
    private final By navigator = By.xpath("//a[@title='Navigator']");
    private final By taskmenu = By.xpath( "//*[contains(@id,'TransactionsWorkArea_itemNode__FndTasksList::icon')]" );
    private final By managecustomers = By.xpath( "//a[text()='Manage Customers']" );
    private final By createcustomer = By.xpath( "//*[text()='Create Customer']" );
    private final By managecustomerheader = By.xpath( "//*[text()='Manage Customers']" );
    private final By customertypedrpdwn = By.xpath( "//*[contains(@id,'cuCustomerTypeSelectOneChoice::content')]" );
    private final By customertypelabel = By.xpath( "//label[text()='Customer Type']/ancestor::td[1]");
    private final By accountnumbertext = By.xpath("//*[contains(@id,':value60::content')]");
    private final By orgname = By.xpath( "//label[text()=' Organization Name']/ancestor::td[1]//input" );
    private final By orgnameselect = By.xpath("//table[@summary='Organizations']/tbody/tr[11]/td[3]");
    private final By accnumberselect = By.xpath( "//table[@summary='Accounts']/tbody/tr[1]/td[3]");
    private final By accnumberlink = By.xpath( "//*[contains(@id,'commandLink1')]/a/span");
    private final By accountdescripttions = By.xpath( "//*[contains(@id,'commandLink2')]/a/span");
    private final By accnumberenddate = By.xpath( "//*[contains(@id,':inputDate3::content')]");
    private final By name = By.xpath( "//label[text()='Name']/ancestor::tr[1]/td[2]//input");
    private final By accnumbertxt = By.xpath( "//label[text()='Account Number']/ancestor::tr[1]/td[2]//input");
    private final By dunsnumber = By.xpath( "//label[text()='D-U-N-S Number']/ancestor::tr[1]/td[2]//input");
    private final By taxpayerident = By.xpath( "//label[text()='Taxpayer Identification Number']/ancestor::tr[1]/td[2]//input");
    private final By acctdesc = By.xpath( "//label[text()='Account Description']/ancestor::tr[1]/td[2]//input");
    private final By accttype = By.xpath( "//label[text()='Account Type']/ancestor::tr[1]/td[2]//select");
    private final By customerclass = By.xpath( "//label[text()='Customer Class']/ancestor::tr[1]/td[2]//select");
    private final By customeracctinfo = By.xpath( "//label[text()='Enter Customer Account Information']/ancestor::tr[1]/td[2]//select");
    private final By acctaddresssettxt = By.xpath( "//label[text()='Account Address Set']/ancestor::tr[1]/td[2]//input");
    private final By acctaddressetdrpdwn = By.xpath( "//*[contains(@id,'setIdLovId::cntnrSpan')]");
    private final By acctaddressetdrpdwnsel = By.xpath( "//*[contains(@id,'setIdLovId::dropdownPopup::dropDownContent::db')]/table/tbody/tr[1]/td[1]");
    private final By sitenumber = By.xpath( "//label[text()='Site Number']/ancestor::tr[1]/td[2]//input");
    private final By addressline1 = By.xpath( "//label[text()='Address Line 1']/ancestor::tr[1]/td[2]//input");
    private final By city = By.xpath( "//label[text()='City or Town']/ancestor::tr[1]/td[2]//input");


    //Button
    private final By btnsearch = By.xpath( "//*[contains(@id,'ManF:0:AP1:q1::search')]" );
    private final By btnsavenclose = By.xpath( "//*[@accesskey='S']");
    private final By btndone = By.xpath( "//*[@accesskey='o']");

    // page loading time
    public static final int PAGELOADTIMEOUT = 90;
    // individual element load time
    public static final int ELEMENTTIMEOUT = 60;

    public static final int SCRIPTTIME = 5;

    public static final int QUERYRESPONSE = 15;

    /**
     * Constructor to initialize the functional library
     *
     * @param scriptHelper The {@link ScriptHelper} object passed from the
     *                     {@link DriverScript}
     */
    public ARCustomerpage(ScriptHelper scriptHelper) {
        super( scriptHelper );
    }

    public void managecustomernav() {
        PauseScript( 2 );
        isElementAvailable( taskmenu, ELEMENTTIMEOUT );
        driver.findElement( taskmenu ).click();

        isElementAvailable( managecustomers, ELEMENTTIMEOUT );
        driver.findElement( managecustomers ).click();
    }


    private void searchcustomerdata() {
        String customername = (dataTable.getData("General_Data", "Name"));
        isElementAvailable( customertypelabel, ELEMENTTIMEOUT );
        isElementAvailable( orgname, ELEMENTTIMEOUT );
        driver.findElement( orgname ).sendKeys(customername);
        driver.findElement( orgname ).sendKeys( Keys.ENTER );
        report.updateTestLog( "Verify the data on the search criteria", " Data - " + customername + "  used for searching the customer.", Status.PASS );
        oracleObjectRender( SCRIPTTIME );
    }
    public void searchcustomer() {
        searchcustomerdata();
        isElementAvailable( btndone, ELEMENTTIMEOUT );
        driver.findElement( btndone ).click();
        report.updateTestLog( "Verify the Search Customer", "User has successfully searched the Customer results.",
                Status.PASS );
    }

    public void deactivateCustomer() {
        String customername = (dataTable.getData("General_Data", "Name"));
        isElementAvailable( customertypelabel, ELEMENTTIMEOUT );
        //driver.findElement( customertypedrpdwn ).click();
        isElementAvailable( orgname, ELEMENTTIMEOUT );
        driver.findElement( orgname ).sendKeys(customername);
        driver.findElement( accountnumbertext ).sendKeys( Keys.ENTER );
        //driver.findElement( btnsearch ).click();
        oracleObjectRender( SCRIPTTIME );
        driver.findElement( accnumberlink ).click();
        oracleObjectRender( QUERYRESPONSE );
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        Date date = new Date();
        driver.findElement( accnumberenddate ).sendKeys(formatter.format(date));
        driver.findElement( accnumberenddate ).sendKeys( Keys.TAB );
        report.updateTestLog( "Verify the data", "Account End date updated for customer deactivation ", Status.PASS );
        driver.findElement( btnsavenclose ).click();
        oracleObjectRender( SCRIPTTIME );
        report.updateTestLog( "Verify the user is able to deactivate the customer", "User - " + customername + "   deactivated the customers successfully", Status.PASS );
    }
    public void createcustomernav() {
        PauseScript( 2 );
        isElementAvailable( taskmenu, ELEMENTTIMEOUT );
        driver.findElement( taskmenu ).click();

        isElementAvailable( createcustomer, ELEMENTTIMEOUT );
        driver.findElement( createcustomer ).click();
    }


    public void createCustomer() {
        isElementAvailable(name, ELEMENTTIMEOUT);
        driver.findElement( name ).click();
        driver.findElement(name).sendKeys( (dataTable.getData("General_Data", "Name")) );
        driver.findElement( name ).sendKeys( Keys.ENTER );
        isElementAvailable(acctdesc, ELEMENTTIMEOUT);
        driver.findElement( acctdesc ).click();
        driver.findElement(acctdesc).sendKeys((dataTable.getData("General_Data", "Account Desctiption")) );
        driver.findElement( acctdesc ).sendKeys( Keys.ENTER );
        isElementAvailable(accnumbertxt, ELEMENTTIMEOUT);
        String accountNumber = driver.findElement(accnumbertxt).getAttribute("value");
        report.updateTestLog( "Verify the Account Number creation", " Account Number - " +accountNumber + " has been successfully created", Status.PASS );
        isElementAvailable(acctaddresssettxt, ELEMENTTIMEOUT);
        driver.findElement( acctaddresssettxt ).click();
        driver.findElement(acctaddresssettxt).sendKeys( (dataTable.getData("General_Data", "Account Address Set")) );
        driver.findElement( acctaddresssettxt ).sendKeys( Keys.ENTER );
        oracleObjectRender( SCRIPTTIME );
        driver.findElement(acctaddressetdrpdwn).click();
        driver.findElement(acctaddressetdrpdwnsel).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable(addressline1, ELEMENTTIMEOUT);
        driver.findElement( addressline1 ).click();
        driver.findElement(addressline1).sendKeys( (dataTable.getData("General_Data", "Address Line1")) );
        driver.findElement( addressline1 ).sendKeys( Keys.ENTER );
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable(city, ELEMENTTIMEOUT);
        driver.findElement(city).sendKeys( (dataTable.getData("General_Data", "City")) );
        driver.findElement( city ).sendKeys( Keys.ENTER );
        oracleObjectRender( SCRIPTTIME );
        report.updateTestLog( "Verify the data", "Data used for creating the customer", Status.PASS );
        isElementAvailable(btnsavenclose, ELEMENTTIMEOUT);
        driver.findElement( btnsavenclose ).click();
        oracleObjectRender( SCRIPTTIME );
        String customername = (dataTable.getData("General_Data", "Name"));
        report.updateTestLog( "Verify the customer creation", " Customer - " + customername + " has been successfully created", Status.PASS );
        oracleObjectRender( SCRIPTTIME );

    }
}
