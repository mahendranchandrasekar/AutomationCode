package pages;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.ScriptHelper;
import com.cognizant.framework.ExcelDataImport;
import com.cognizant.framework.Status;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

/**
 * FCCS SignOnPage class

 */
public class CreateRequisitionPage extends MasterPages {

	//Page Sync Config

	// page loading time
	public static final int PAGELOADTIMEOUT = 90;
	// individual element load time
	public static final int ELEMENTTIMEOUT = 60;
	// Oracle query response
	public static final long QUERYRESPONSE = 15;
	// object render script
	public static final long SCRIPTTIME = 5;
	// Requisition Number
	public static String reqNumber = "";
	public static String purchaseOrderNumber = "";

	// UI Map object definitions

	// Text boxes
	private final By navigator= By.xpath("//a[@title='Navigator']");
	private final By procurementIconLink= By.xpath("//span[text()='Procurement']/following::div[2]/table/tbody/tr/td[3]/a");
	private final By procurementLink = By.xpath("//a[contains(@id,'groupNode_procurement')]");
	private final By purchaseReqLink = By.xpath("//a[contains(@id,'itemNode_my_information_purchase_requisitions')]");
	//private final By myReceiptsLink = By.xpath("//a[contains(@id,'itemNode_my_information_self_service_receipts')]");
	private final By purchaseRequistionLink = By.xpath("//span[text()='Procurement']/following::div[1]/table/tbody/tr/td[3]/a");
	private final By manageRequisitionsLink = By.xpath("//a[text()='Manage Requisitions']");
	private final By requisitionTextField = By.xpath("//label[text()='Requisition']/following::td[1]/table/tbody/tr/td[2]/table/tbody/tr/td/span/input");
	private final By searchButton = By.xpath("//button[text()='Search']");
	private final By requistionNumberLink = By.xpath("//table[@summary='Search Results']/tbody/tr[1]/td[2]/div/table/tbody/tr[1]/td[2]/child::*/child::*/child::*/child::*/td/a");


	private final By shopByCat = By.xpath("//*[@title='Shop by Category']");
	private final By categorySearch = By.xpath("//*[@class='x25'][@placeholder='Search']");
	private final By catSearchButton = By.xpath("//a[@title='Search']");
	private final By addToCartBtn = By.xpath("//span[text()='Add to Cart']");
	private final By shoppingCartBtn = By.xpath("//img[@alt='Shopping Cart']");
	private final By submitBtn = By.xpath("//button[text()='Submit']");
	private final By submitBtn_EditScreen = By.xpath("//span[contains(text(),'Sub')]/parent::a[1]");
	private final By confirmationTxt = By.xpath("//div[contains(text(),'was submitted')]");
	private final By okBtn_ConfirmPopup = By.xpath("//button[text()='View PDF']/following-sibling::button[starts-with(text(),'O')]");
	//private final By approvedTxt = By.xpath("//table[@summary='Requisition Lines']/descendant::span[text()='Approved']");
	private final By doneBtn_EditScreen = By.xpath("//span[text()='D' and child::span[text()='o'] and text()='ne']/parent::a");
	private final By getPONumber = By.xpath("//table[@summary='Requisition Lines']/tbody/tr[1]/td[2]/div[1]/table/tbody/tr/td[11]/span/a");
	private final By getRequisitionStatus = By.xpath("//table[@summary='Requisition Lines']/tbody/tr[1]/td[2]/div[1]/table/tbody/tr/td[10]/span");
	private final By HomeBtn = By.xpath("//a[@title='Home'][1]");
	private final By navigationPane = By.xpath("//div[@id='app-navigation']");

	private final By receiveItemsHdr = By.xpath("//h1[text()='Receive Items']");
	private final By requisition_SearchFld = By.xpath("//label[text()=' Requisition']/preceding-sibling::input");
	private final By itemsDue_SearchFld = By.xpath("//label[text()=' Items Due']/preceding-sibling::select");
	private final By anyTime_Option = By.xpath("//label[text()=' Items Due']/preceding-sibling::select/child::option[@title='Any time']");
	private final By searchBtn_RcvScreen = By.xpath("//button[text()='Search']");
	private final By receiveBtn_RcvScreen = By.xpath("//button[text()='Receive']");

	//private final By getPurchaseOrderNumber = By.xpath("//table[@summary='Create Receipts']/tbody/tr[1]/td[2]/div[1]/child::*/tbody/tr[1]/td[10]/child::*/child::*/child::*/child::*/child::*/a");
	private final By submitBtn_RcvScreen = By.xpath("//span[contains(text(),'Sub')]/parent::a[1]");
	private final By receiptConfirmTxt = By.xpath("//span[contains(text(),'You created the following receipt numbers')]");
	private final By okBtn_RcvConfirmPopup = By.xpath("//button[starts-with(text(),'O') and child::span[text()='K']]");
	//private final By txtPassword = By.id("password");
	//private final By btnLogin = By.xpath("//*[@id='btnActive']");

	/**
	 * Constructor to initialize the page
	 *
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	public CreateRequisitionPage(ScriptHelper scriptHelper) {
		super(scriptHelper);

	}

    public void navigateToRequisitionPage(){
		isElementAvailable(procurementLink,PAGELOADTIMEOUT);
		driver.findElement(procurementLink).click();
		report.updateTestLog("",
				"Click Procurement Link", Status.PASS);

		isElementAvailable(purchaseReqLink,ELEMENTTIMEOUT);
		driver.findElement(purchaseReqLink).click();
	}

	public void navigateToCategory(String reqCategoryStr){
		isElementAvailable(navigator, ELEMENTTIMEOUT);
		driver.findElement(navigator).click();
		isElementAvailable(procurementIconLink, ELEMENTTIMEOUT);
		driver.findElement(procurementIconLink).click();
		report.updateTestLog("Select Procurement",
				"Click Procurement Link", Status.PASS);

		isElementAvailable(purchaseReqLink,ELEMENTTIMEOUT);
		driver.findElement(purchaseReqLink).click();
		//pageWait.until(craftDriver -> driver.executeScript("return document.readyState").equals("complete"));
		isElementAvailable(shopByCat,PAGELOADTIMEOUT);
		report.updateTestLog("Select Purchase Requisition",
				"Click Purchase Requisition Link", Status.PASS);

		driver.findElement(categorySearch).sendKeys(reqCategoryStr);
		driver.findElement(catSearchButton).click();

		By relatedRequests = By.xpath("//span[text()='Related Requests']");
		By categorylink = By.xpath("//span[text()='"+ reqCategoryStr  + "']");
		isElementAvailable(relatedRequests,ELEMENTTIMEOUT);
		isElementAvailable(categorylink,ELEMENTTIMEOUT);
		driver.findElement(categorylink).click();
		report.updateTestLog("Select Requisition Category",
				"Click Requisition Category", Status.PASS);

		isElementAvailable(addToCartBtn,PAGELOADTIMEOUT);
		if (driver.findElements(addToCartBtn).size() > 0){
			report.updateTestLog("Create Requisition Page",
					"Verify Create Requisition Page", Status.PASS);
		}else{
			report.updateTestLog("Create Requisition Page",
					"Verify Create Requisition Page", Status.FAIL);
		}


	}

	public void enterRequisitionHdrDetails(String requisitionDetailsStr){
		String[] reqDetailsArr = requisitionDetailsStr.split(";");

		for (String fieldDetails : reqDetailsArr)
		{
			String[] fieldVal = fieldDetails.split(",");
			String labelTxt = fieldVal[0];
			String inputType = fieldVal[1];
			String inputVal = fieldVal[2];
			By inputObj = By.xpath("//label[text()='"+ labelTxt +"']/following::"+ inputType +"[1]");
			isElementAvailable(inputObj,ELEMENTTIMEOUT);
			WebElement elt = driver.findElement(inputObj);
			elt.sendKeys(inputVal);
			elt.sendKeys(Keys.TAB);
		}

		report.updateTestLog("Enter requisition header details",
				"Requisition header details entered successfully", Status.PASS);

		isElementAvailable(addToCartBtn,ELEMENTTIMEOUT);
		driver.findElement(addToCartBtn).click();

		By cartQty = By.xpath("//img[@alt='Shopping Cart']/following::span[text()='1']");
		isElementAvailable(cartQty,ELEMENTTIMEOUT);
		driver.findElement(shoppingCartBtn ).click();

		isElementAvailable(submitBtn,ELEMENTTIMEOUT);
		driver.findElement(submitBtn).click();
	}


	public void verifyPurchaseOrder() {
        isElementAvailable(navigator, ELEMENTTIMEOUT);
        driver.findElement(navigator).click();
        isElementAvailable(purchaseRequistionLink, ELEMENTTIMEOUT);
        driver.findElement(purchaseRequistionLink).click();
		isElementAvailable(manageRequisitionsLink,PAGELOADTIMEOUT);
		driver.findElement(manageRequisitionsLink).click();
		isElementAvailable(requisitionTextField,PAGELOADTIMEOUT);
		driver.findElement(requisitionTextField).sendKeys(reqNumber);
		isElementAvailable(searchButton,ELEMENTTIMEOUT);
		driver.findElement(searchButton).click();
		isElementAvailable(requistionNumberLink,PAGELOADTIMEOUT);
		driver.findElement(requistionNumberLink).click();
		for(int i=0; i<=5; i++) {
                oracleObjectRender(SCRIPTTIME);
                if(driver.findElements(getPONumber).size() > 0) {
                	break;
				}
				oracleObjectRender(SCRIPTTIME);
				isElementAvailable(doneBtn_EditScreen, ELEMENTTIMEOUT);
				driver.findElement(doneBtn_EditScreen).click();
				oracleObjectRender(SCRIPTTIME);
				isElementAvailable(requistionNumberLink, PAGELOADTIMEOUT);
				driver.findElement(requistionNumberLink).click();
				oracleObjectRender(SCRIPTTIME);
			}
		oracleObjectRender(SCRIPTTIME);
		isElementAvailable(getPONumber, PAGELOADTIMEOUT);
		Assert.assertEquals(driver.findElement(getRequisitionStatus).getAttribute("innerHTML"), (dataTable.getData(ExcelDataImport.RegisterUserData, "RequisitionStatus")));
		purchaseOrderNumber = driver.findElement(getPONumber).getAttribute("innerHTML");
		report.updateTestLog("Verify Requisition Approval","Purchase Order:"+ purchaseOrderNumber   +" is Approved successfully", Status.PASS);
}


	public void enterRequisitionLineDetails(String reqLineDetailsStr) {
		String[] reqLineDetailsArr = reqLineDetailsStr.split(";");

		for (String fieldDetails : reqLineDetailsArr)
		{
			String[] fieldVal = fieldDetails.split("=");
			String labelTxt = fieldVal[0];
			String inputVal = fieldVal[1];

			By inputObj = By.xpath("//label[text()='"+ labelTxt +"']/preceding::input[1][contains(@id, 'edAT')]");
			isElementAvailable(inputObj,ELEMENTTIMEOUT);
			WebElement elt = driver.findElement(inputObj);
			elt.sendKeys(inputVal);
			elt.sendKeys(Keys.TAB);
		}

		report.updateTestLog("Enter requisition line details",
				"Requisition line details entered successfully", Status.PASS);

		isElementAvailable(submitBtn_EditScreen,ELEMENTTIMEOUT);
		driver.findElement(submitBtn_EditScreen).click();

		isElementAvailable(confirmationTxt,ELEMENTTIMEOUT);
		String reqSubmitConfirmStr = driver.findElement(confirmationTxt).getText();
		String[] confirmStrArr = reqSubmitConfirmStr.split(" ");
		reqNumber = confirmStrArr[1];
		if (driver.findElements(confirmationTxt).size() > 0){
			report.updateTestLog("Submit requisition",
					" Requisition:"+ reqNumber   +" submitted successfully", Status.PASS);
		}else{
			report.updateTestLog("Submit requisition",
					"Requisition :"+  reqNumber  +" not submitted; please check", Status.FAIL);
		}

		driver.findElement(okBtn_ConfirmPopup).click();
	}

	public void clickHome(){
		oracleObjectRender(SCRIPTTIME);oracleObjectRender(SCRIPTTIME);
		isElementAvailable(HomeBtn, PAGELOADTIMEOUT);
		driver.findElement(HomeBtn).click();
		oracleObjectRender(SCRIPTTIME);
		isElementAvailable(navigationPane, ELEMENTTIMEOUT);
	}


	public void createReceipt(String rNum){
		NavigationPage navigationPage = new NavigationPage(scriptHelper);
		navigationPage.menuNavigation();
		report.updateTestLog("Select Receipts","Click on My Receipts Link", Status.PASS);
		navigationPage.clickOnMainMyReceiptsLink();


		isElementAvailable(receiveItemsHdr,PAGELOADTIMEOUT);

		driver.findElement(requisition_SearchFld).sendKeys(rNum);

		driver.findElement(itemsDue_SearchFld).click();
		isElementAvailable(anyTime_Option,ELEMENTTIMEOUT);
		driver.findElement(anyTime_Option).click();
		oracleObjectRender(SCRIPTTIME);
		driver.findElement(searchBtn_RcvScreen).click();

		By requisitionLink = By.xpath("//a[text()='"+ rNum + "']");
		By tableRow= By.xpath("//table[@summary='Search Results']/tbody/tr[1]");
		isElementAvailable(requisitionLink,PAGELOADTIMEOUT);
		if (driver.findElements(requisitionLink).size() > 0){
			report.updateTestLog("Search requisition",
					"Requisition:"+ rNum   +" found", Status.PASS);
			
			oracleObjectRender(SCRIPTTIME);
			driver.findElement(tableRow).click();
			driver.findElement(receiveBtn_RcvScreen).click();
			oracleObjectRender(SCRIPTTIME);


			oracleObjectRender(SCRIPTTIME);
			isElementAvailable(submitBtn_RcvScreen,PAGELOADTIMEOUT);
			driver.findElement(submitBtn_RcvScreen).click();

			isElementAvailable(receiptConfirmTxt,ELEMENTTIMEOUT);

			if (driver.findElements(receiptConfirmTxt).size() > 0){

				String receiptConfirmStr = driver.findElement(receiptConfirmTxt).getText();
				String receiptNumber = receiptConfirmStr.split(":")[1].trim().replace(" ","");
				report.updateTestLog("Receipt Creation",
						"Receipt:"+ receiptNumber   +" created", Status.PASS);

				driver.findElement(okBtn_RcvConfirmPopup).click();
			}else{
				report.updateTestLog("Receipt Creation",
						"Receipt not created; please check", Status.FAIL);
			}

		}else{
			report.updateTestLog("Submit  requisition",
					"Requisition:"+  rNum +" not found; please check search criteria", Status.FAIL);
		}


	}
}