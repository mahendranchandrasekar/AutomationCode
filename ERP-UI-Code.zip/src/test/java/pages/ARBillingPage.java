package pages;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.ScriptHelper;
import com.cognizant.framework.Status;
import org.bouncycastle.jcajce.provider.symmetric.HC256;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import javax.swing.text.Element;
import javax.swing.text.TabableView;
import java.util.List;
import java.util.Queue;

public class ARBillingPage extends MasterPages {
    //Links for create invoice and manage invoice
    private final By navigator = By.xpath( "//a[@title='Navigator']" );
    private final By billinghomepage = By.xpath( "//h1[text()='Billing']" );
    private final By billingtask = By.xpath( "//*[contains(@id,'TransactionsWorkArea_itemNode__FndTasksList::icon')]" );
    private final By createtransaction = By.xpath( "//a[text()='Create Transaction']" );
    private final By managetransheader = By.xpath( "//*[text()='Manage Transactions']/ancestor::td[1]" );
    private final By btnsearch = By.xpath( "//*[contains(@id,':MAnt2:3:pt1:MTF1:0:ap1:q1')][text()='Search']" );
    private final By search = By.xpath( "//*[contains(@id,':MAnt2:1:pt1:MTF1:0:ap1:q1')]" );
    private final By managetransaction = By.xpath( "//a[text()='Manage Transactions']" );
    private final By invoiceheader = By.xpath( "//div[@title='Create Transaction: Invoice']" );
    private final By btnsave = By.xpath( "//span[text()='Save']" );
    private final By btnadvanced = By.xpath( "//button[contains(@id,':MAnt2:3:pt1:MTF1:0:ap1:q1::mode')]" );
    //private final By businessunit = By.xpath("//label[text()='Business Unit']/ancestor::td[1]/following-sibling::td[1]//input");
    private final By transactionnumber = By.xpath( "//label[text()='Transaction Number']/ancestor::tr[1]/td[2]//input" );
    private final By editTransactionNumber = By.xpath( "//label[text()='Transaction Number']/ancestor::tr[1]/td[2]/span/span" );
    private final By bussajaxValidate = By.xpath( "//div[contains(@class,'AFDetectExpansion')]/../tbody/tr/td/div/div/div/table/tr[1]" );
    private final By tnsrcajaxValidate = By.xpath( "//div[contains(@class,'AFDetectExpansion')]/../tbody/tr[1]/td[1]/ul[1]/li[1]" );
    private final By salespersontext = By.xpath( "//*[contains(@id,'salesPersonId::content')]" );
    private final By salespersonsrch = By.xpath( "//*[@title='Search: Salesperson']" );

    private final By busunitsel = By.xpath( "//table[@role='grid']/tr[3]" );
    private final By transnumblink1 = By.xpath( "//*[contains(@id,'MAnt2:3:pt1:MTF1:0:ap1:AT2:_ATp:table2:0:ot1')]" );
    private final By transnumblink = By.xpath( "//table[@summary='Search Results']/tbody/tr[1]/td[3]/span" );
    //private final By businessunit = By.xpath( "//*[contains(@class,'x1y7')]" );
    //private final By businessunit = By.xpath("//label[text()='Business Unit']/../input[1]");
    private final By businessunit = By.xpath("//label[text()='Business Unit']/../../td[2]/span/span/span[1]/input");
    private final By busunitdrpdwn = By.xpath( "//*[contains(@id,'ap1:fcslov1:sis1:is1::btn')]" );
    private final By transactionsource = By.xpath( "//label[text()='Transaction Source']/ancestor::td[1]/following-sibling::td[1]//input" );
    private final By transactionsrcvalues = By.xpath( "//*[contains(@id,'batchSourceId::dropdownPopup::dropDownContent::db')]/table/tbody/tr[3]/td[1]/span" );
    private final By transactionsrdrpdwn = By.xpath( "//*[contains(@id,'batchSourceId::lovIconId')]" );
    private final By transactiontype = By.xpath( "//label[text()='Transaction Type']/ancestor::td[1]/following-sibling::td[1]//input" );
    private final By transactiontypedrpdwn = By.xpath( "//a[contains(@id,'transactionTypeId::lovIconId')]");
    private final By transactiontypesearchlink = By.xpath("//a[contains(@id,'transactionTypeId::dropdownPopup::popupsearch')]");
    private final By transactiontypename = By.xpath("//tr[contains(@id,'transactionTypeId::_afrLovInternalQueryId:criterion0')]/td[2]/table/tbody/tr[1]/td[2]/table/tbody/tr[1]/td[1]/span/input");
    private final By transactiontypepopupsearchbutton = By.xpath("//button[contains(@id,'transactionTypeId::_afrLovInternalQueryId::search')]");
    private final By transactiontypepopupselection = By.xpath("//div[contains(@id,'transactionTypeId_afrLovInternalTableId::db')]");
    private final By transactiontypepopupOkbutton = By.xpath("//td[contains(@id,':transactionTypeId::lovDialogId::_fcc')]/button[1]");
    

    private final By itemsearch1 = By.xpath( "//*[contains(@class,'_afrImageNotLoadedInTime xi8')][contains(@id,'ATp:table1:0:ip1:searchIcoId::icon')]" );
    private final By item = By.xpath( "//label[text()='Item']/ancestor::td[1]//input" );
    private final By description = By.xpath( "//label[text()='Description']//ancestor::td[1]//input" );
    private final By quantity = By.xpath( "//label[text()='Quantity']//ancestor::td[1]//input" );
    private final By unitprice = By.xpath( "//input[contains(@id,'sellingPrice::content')]" );
    private final By billtoname = By.xpath( "//label[text()='Bill-to Name']//ancestor::td[1]//input" );
    private final By taxclassification = By.xpath( "//label[text()='Tax Classification']//ancestor::td[1]//input" );
    private final By taxclassificationselect = By.xpath( "//*[contains(@class,'AFAutoSuggestItemsContainer')]/li[1]" );

    private final By transactionbusscategory = By.xpath( "//label[text()='Transaction Business Category']//ancestor::td[1]//input" );
    private final By transactionbusscategoryselect = By.xpath( "//*[contains(@class,'AFAutoSuggestItemsContainer')]/li[1]" );
    private final By addattachments = By.xpath( "//*[contains(@id,'clLAdds::icon')]" );
    private final By choosefileonattachopoup = By.xpath( "//input[contains(@id,'popApplicationsTable:_ATp:popAttachmentTable:0:ifPopup::content')]" );
    private final By btnokattpopup = By.xpath( "//span[text()='K']" );
    private final By filetypesel = By.xpath( "//select[contains(@id,'popDatatypeCodeChoiceListIDNew::content')]" );
    private final By filepath = By.xpath( "//input[contains(@id,'popRepositoryFilePath::content')]" );
    private final By btncompleteandcreateanother = By.xpath( "//*[@id='pt1:_FOr1:1:_FOSritemNode_receivables_billing:0:MAnt2:1:pt1:TCF:0:ap1:newTrx']/table/tbody/tr/td[1]/a/span" );
    private final By reviewtrans = By.xpath( "//*[contains(@id,':MAnt2:0:pt1:MTF1:1:pt1:Trans1:0:ap110:SPph::_afrTtxt')]/div/h1" );

    private final By transstatus = By.xpath( "//label[text()='Status']/ancestor::tr[1]" );
    private final By viewimage = By.xpath( "//*[text()='View Image']/ancestor::td[1]" );
    private final By popupclose = By.xpath( "//*[contains(@id,'printInvoiceDialog::close')]" );
    private final By btnsavedrpdwn = By.xpath( "//*[contains(@id,'saveMenu::popEl')]" );
    private final By btnsavenclose = By.xpath( "//*[@accesskey='S']" );

    private final By completedrpdwn = By.xpath( "//*[contains(@id,'MAnt2:2:pt1:Trans1:0:ap110:newTrx::popEl')]" );
    private final By shiptoname = By.xpath( "//*[contains(@id,'shipToNameId::content')]" );
    private final By searchshiptoname = By.xpath( "//*[@title='Search: Ship-to Name']" );
    private final By paymentterms = By.xpath( "//*[contains(@id,'paymentTermId::desc')]" );
    private final By paymenttermsdrpdwn = By.xpath( "//*[@title='Search: Payment Terms']" );
    private final By paymenttermselect = By.xpath( "//*[contains(@id,'paymentTermId::dropdownPopup::dropDownContent::db')]/table/tbody/tr[1]/td[1]" );

    private final By taxlink = By.xpath( "//*[contains(@id,':commandImageLink1111::icon')]" );
    private final By btnsavenclosetaxlinepopup = By.xpath( "//button[@accesskey='S']" );
    private final By btncanceltaxlinepopup = By.xpath( "//button[@accesskey='C']" );

    private final By completenreview = By.xpath( "//*[text()='Complete and Review']" );
    private final By completenclose = By.xpath( "//*[text()='Complete and Close']" );

    private final By editdistributions = By.xpath( "//*[text()='Edit Distributions']" );
    private final By Warningpopupyes = By.xpath( "//button[@accesskey='Y']" );
    private final By btncanceldistributionpopup = By.xpath( "//button[@accesskey='C']" );
    private final By infomsg = By.id( "_FOd1::msgDlg::_cnt" );
    private final By actions = By.xpath( "//*[contains(@id,'MAnt2:2:pt1:Trans1:0:ap110:m1')]/div/table/tbody/tr/td[3]/div" );
    private final By infocancel = By.xpath( "//*[@id='_FOd1::msgDlg::cancel']" );

    //Distribution
    private final By receivable = By.xpath( "//label[text()='Distribution']//ancestor::table/tbody/tr[1]/td[6]/span/span/div/table/tbody/tr/td[1]/span/input" );
    private final By revenue = By.xpath( "//label[text()='Distribution']//ancestor::table/tbody/tr[2]/td[6]/span/span/div/table/tbody/tr/td[1]/span/input" );
    private final By btnsaveandclose = By.xpath( "//button[@accesskey='S']" );
    //Cancel
    private final By btncanceltransaction = By.xpath( "//*[contains(@id,'commandToolbarButton2')]/a/span" );
    // Link for credit memo
    private final By transactionclass = By.xpath( "//label[text()='Transaction Class']//ancestor::td[1]//select" );
    private final By creditmemoheader = By.xpath( "//div[@title='Create Transaction: Credit Memo']" );
    private final By creditmemolinedrpdwn = By.xpath( "//a[contains(@id,'memoLineNameId::lovIconId')]" );
    private final By creditmemolinesel = By.xpath( "//*[contains(@id,'memoLineNameId::dropdownPopup::dropDownContent::db')]/table/tbody/tr[1]/td[1]" );
    private final By creditreason = By.xpath( "//label[text()='Credit Reason']//ancestor::td[1]//select" );
    private final By creditmemolinetxt = By.xpath( "//input[contains(@id,':memoLineNameId::content')]" );

    //Credit Transcation
    private final By credittransaction = By.xpath( "//*[text()='Credit Transaction']" );
    private final By transnumber = By.xpath( "//*[contains(@id,'trxNumber1Id::content')]" );
    private final By btncreditentirebal = By.xpath( "//button[text()='Credit Entire Balance']" );
    private final By btneditdistributions = By.xpath( "//button[text()='Edit Distributions']" );
    private final By creditpercentage = By.xpath( "//*[contains(@id,'PercentageVCEvent::content')]" );
    private final By btnnowarn = By.xpath( "//*[contains(@id,'commandButton2')]" );
    private final By btncompletenclosedrp = By.xpath( "//*[contains(@id,'CompleteandClose::popEl')]" );
    private final By btncompletenclosedrpmemo = By.xpath( "//*[contains(@id,'MAnt2:2:pt1:Trans1:0:ap110:newTrx::popE')]" );
    private final By btncompletenreview = By.xpath( "//*[text()='Complete and Review']" );
    private final By btncompletenClose = By.xpath( "//*[text()='Complete and Close']" );

    // page loading time
    public static final int PAGELOADTIMEOUT = 90;
    // individual element load time
    public static final int ELEMENTTIMEOUT = 60;

    public static final int SCRIPTTIME = 5;

    public static final int QUERYRESPONSE = 15;


    /**
     * Constructor to initialize the functional library
     *
     * @param scriptHelper The {@link ScriptHelper} object passed from the
     *                     {@link DriverScript}
     */
    public ARBillingPage(ScriptHelper scriptHelper) {
        super( scriptHelper );
    }

    public void createTransactionnav() {
        isElementAvailable( billingtask, ELEMENTTIMEOUT );
        driver.findElement( billingtask ).click();

        isElementAvailable( createtransaction, ELEMENTTIMEOUT );
        driver.findElement( createtransaction ).click();
    }

    private void transactiontypepopup(){
        isElementAvailable( transactiontypename, ELEMENTTIMEOUT );
        driver.findElement( transactiontypename ).click();
        driver.findElement( transactiontypename ).sendKeys( dataTable.getData( "General_Data", "Transaction Type" ) );
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( transactiontypepopupsearchbutton, ELEMENTTIMEOUT );
        driver.findElement( transactiontypepopupsearchbutton ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( transactiontypepopupselection, ELEMENTTIMEOUT );
        driver.findElement( transactiontypepopupselection ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( transactiontypepopupOkbutton, ELEMENTTIMEOUT );
        driver.findElement( transactiontypepopupOkbutton ).click();
        oracleObjectRender( SCRIPTTIME );
    }


    private void generalinfo() {
        isElementAvailable( businessunit, PAGELOADTIMEOUT);
        driver.findElement( businessunit ).click();
        driver.findElement( businessunit ).sendKeys( dataTable.getData( "General_Data", "Business Unit" ) );
        oracleObjectRender( QUERYRESPONSE );
        driver.findElement( bussajaxValidate ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( transactionsource, ELEMENTTIMEOUT );
        driver.findElement( transactionsource ).sendKeys( dataTable.getData( "General_Data", "Transaction Source" ) );
        oracleObjectRender( QUERYRESPONSE );oracleObjectRender( SCRIPTTIME );
        driver.findElement( tnsrcajaxValidate ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( transactiontype, ELEMENTTIMEOUT );
        driver.findElement( transactiontype ).click();
        driver.findElement( transactiontype ).sendKeys( dataTable.getData( "General_Data", "Transaction Type" ) );
    }

    private void customerinfo() {
        isElementAvailable( billtoname, ELEMENTTIMEOUT );
        driver.findElement( billtoname ).click();
        driver.findElement( billtoname ).sendKeys( dataTable.getData( "General_Data", "Bill to Name" ) );
        driver.findElement( billtoname ).sendKeys( Keys.ARROW_DOWN, Keys.ENTER );
        oracleObjectRender( SCRIPTTIME );
    }

    private void invoicelineinfo() {
        isElementAvailable( item, ELEMENTTIMEOUT );
        driver.findElement( item ).click();
        driver.findElement( item ).sendKeys( dataTable.getData( "General_Data", "Item" ) );
        isElementAvailable( description, ELEMENTTIMEOUT );
        driver.findElement( description ).click();
        driver.findElement( description ).sendKeys( dataTable.getData( "General_Data", "Description" ) );
        oracleObjectRender( SCRIPTTIME );
        driver.findElement( description ).sendKeys( Keys.TAB );
        isElementAvailable( quantity, ELEMENTTIMEOUT );
        driver.findElement( quantity ).click();
        driver.findElement( quantity ).sendKeys( dataTable.getData( "General_Data", "Quantity" ) );
        PauseScript( 2 );
        driver.findElement( quantity ).sendKeys( Keys.TAB );
        isElementAvailable( unitprice, ELEMENTTIMEOUT );
        driver.findElement( unitprice ).click();
        driver.findElement( unitprice ).sendKeys( dataTable.getData( "General_Data", "Unit Price" ) );
        PauseScript( 2 );
        driver.findElement( unitprice ).sendKeys( Keys.TAB );
        PauseScript( 2 );
    }

    private void reviewdistirbution() {
        //Reveiw Distribution lines
        isElementAvailable( actions, ELEMENTTIMEOUT );
        driver.findElement( actions ).click();
        PauseScript( 3 );
        driver.findElement( editdistributions ).click();
        oracleObjectRender( SCRIPTTIME );
        driver.findElement( Warningpopupyes ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( receivable, ELEMENTTIMEOUT );
        driver.findElement( receivable ).clear();
        driver.findElement( receivable ).click();
        PauseScript( 3);
        driver.findElement( receivable ).sendKeys( dataTable.getData( "General_Data", "Receivable" ) );
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( revenue, ELEMENTTIMEOUT );
        driver.findElement( revenue ).clear();
        driver.findElement( revenue ).click();
        PauseScript( 3 );
        driver.findElement( revenue ).sendKeys( dataTable.getData( "General_Data", "Revenue" ) );
        oracleObjectRender( SCRIPTTIME );
        driver.findElement( btnsaveandclose ).click();
        oracleObjectRender( SCRIPTTIME );
    }

    private void clickontaxlink() {
        isElementAvailable( taxlink, ELEMENTTIMEOUT );
        driver.findElement( taxlink ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( btncanceltaxlinepopup, ELEMENTTIMEOUT );
        driver.findElement( btncanceltaxlinepopup ).click();
        oracleObjectRender( SCRIPTTIME );
    }

    private void viewimage() {
        isElementAvailable( viewimage, ELEMENTTIMEOUT );
        driver.findElement( viewimage ).click();
        oracleObjectRender( QUERYRESPONSE );
        isElementAvailable( popupclose, ELEMENTTIMEOUT );
        driver.findElement( popupclose ).click();
        oracleObjectRender( SCRIPTTIME );
    }

    public String invoicecreation() {
        generalinfo();
        customerinfo();
        invoicelineinfo();
        isElementAvailable( btnsave, ELEMENTTIMEOUT );
        driver.findElement( btnsave ).click();
        oracleObjectRender( QUERYRESPONSE );
        reviewdistirbution();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( completedrpdwn, ELEMENTTIMEOUT );
        driver.findElement( completedrpdwn ).click();
        PauseScript( 3 );
        isElementAvailable( completenreview, ELEMENTTIMEOUT );
        driver.findElement( completenreview ).click();
        PauseScript( 6 );
        String transactionNumber = driver.findElement(editTransactionNumber).getAttribute("innerHTML");
        report.updateTestLog("Verify Invoice Creation for Account Receivables","Transaction Number:"+ transactionNumber   +" is created successfully", Status.PASS);
        PauseScript( 6 );
        isElementAvailable( btncanceltransaction, ELEMENTTIMEOUT );
        driver.findElement( btncanceltransaction ).click();
        oracleObjectRender( SCRIPTTIME );
        return transactionNumber;
    }

    public void managetransactionnav() {
        isElementAvailable( billingtask, ELEMENTTIMEOUT );
        driver.findElement( billingtask ).click();

        isElementAvailable( managetransaction, ELEMENTTIMEOUT );
        driver.findElement( managetransaction ).click();
    }

    public void managetransaction(String transactionNumber) {
        isElementAvailable( btnadvanced, ELEMENTTIMEOUT );
        driver.findElement( btnadvanced ).isDisplayed();
        PauseScript( 2 );
        driver.findElement(transactionnumber).sendKeys(transactionNumber);
        driver.findElement( btnsearch ).click();
        oracleObjectRender( SCRIPTTIME );
        report.updateTestLog( "Verify Transaction Number", "Transaction Number " + transactionNumber + " from Search Results", Status.PASS );
        isElementAvailable( transnumblink, ELEMENTTIMEOUT );
        PauseScript( 2 );
        driver.findElement( transnumblink ).isDisplayed();
        driver.findElement( transnumblink ).click();
        oracleObjectRender( QUERYRESPONSE );
        driver.findElement( btnsavedrpdwn ).click();
        PauseScript( 2 );
        driver.findElement( btnsavenclose ).click();
        PauseScript( 2 );
        report.updateTestLog( "Verify the Updated Transaction Number", "Transaction Number " + transactionNumber + " Updated Successfully", Status.PASS );
        isElementAvailable( infocancel, ELEMENTTIMEOUT );
        driver.findElement( infocancel ).click();
        PauseScript( 2 );
        driver.switchTo().defaultContent();
        PauseScript( 2 );
    }

    private void creditmemoheadervalidation() {
        isElementAvailable( creditmemoheader, ELEMENTTIMEOUT );
        if ( !driver.findElement( creditmemoheader ).isDisplayed() ) {
            String cmemoheader = driver.findElement( creditmemoheader ).getText();
            String staticcmheader = "Create Transaction: Credit Memo";
            Assert.assertEquals( "Header text validation", cmemoheader, staticcmheader );
        }
    }

    private void addattachments() {
        isElementAvailable( addattachments, ELEMENTTIMEOUT );
        driver.findElement( addattachments ).click();
        PauseScript( 3 );
        isElementAvailable( filetypesel, ELEMENTTIMEOUT );
        Select drpfiletype = new Select( driver.findElement( filetypesel ) );
        drpfiletype.selectByIndex( 2 );
        PauseScript( 2 );
        isElementAvailable( filepath, ELEMENTTIMEOUT );
        driver.findElement( filepath ).click();
        driver.findElement( filepath ).sendKeys( "\\dcn4pfsh204cdot\\home_6\\KTAC\\Desktop\\70834047_Survey.pdf" );
        driver.findElement( btnokattpopup ).click();
        oracleObjectRender( SCRIPTTIME );
    }

    private void enteredthedatafortaxclassificationandcategory() {
        isElementAvailable( taxclassification, ELEMENTTIMEOUT );
        driver.findElement( taxclassification ).click();
        driver.findElement( taxclassification ).sendKeys( dataTable.getData( "General_Data", "Tax Classification" ) );
        driver.findElement( taxclassification ).sendKeys( Keys.ARROW_DOWN, Keys.ENTER );
        PauseScript( 2 );
        driver.findElement( taxclassification ).sendKeys( Keys.TAB );
        isElementAvailable( transactionbusscategory, ELEMENTTIMEOUT );
        driver.findElement( transactionbusscategory ).click();
        PauseScript( 2 );
        driver.findElement( transactionbusscategory ).sendKeys( dataTable.getData( "General_Data", "Transaction Business Category" ) );
        driver.findElement( transactionbusscategory ).sendKeys( Keys.ARROW_DOWN, Keys.ENTER );
        PauseScript( 2 );
    }

    private void creditmemolineinfo() {
        isElementAvailable( creditmemolinetxt, ELEMENTTIMEOUT );
        driver.findElement( creditmemolinetxt ).sendKeys( dataTable.getData( "General_Data", "Memo Line" ) );
        driver.findElement( creditmemolinetxt ).sendKeys( Keys.TAB );
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( quantity, ELEMENTTIMEOUT );
        driver.findElement( quantity ).click();
        PauseScript( 2 );
        driver.findElement( quantity ).sendKeys( dataTable.getData( "General_Data", "Quantity" ) );
        driver.findElement( quantity ).sendKeys( Keys.TAB );
        PauseScript( 3 );
        isElementAvailable( unitprice, ELEMENTTIMEOUT );
        driver.findElement( unitprice ).click();
        PauseScript( 2 );
        driver.findElement( unitprice ).sendKeys( dataTable.getData( "General_Data", "Unit Price" ) );
        oracleObjectRender( SCRIPTTIME );
    }

    private void generalinfoCreditmemo() {
        isElementAvailable( businessunit, ELEMENTTIMEOUT );
        driver.findElement( businessunit ).click();
        driver.findElement( businessunit ).sendKeys( dataTable.getData( "General_Data", "Business Unit" ) );
        oracleObjectRender( QUERYRESPONSE );
        driver.findElement( bussajaxValidate ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( transactionsource, ELEMENTTIMEOUT );
        driver.findElement( transactionsource ).sendKeys( dataTable.getData( "General_Data", "Transaction Source" ) );oracleObjectRender( QUERYRESPONSE );
        driver.findElement( tnsrcajaxValidate ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( transactiontype, ELEMENTTIMEOUT );
        driver.findElement( transactiontype ).click();
        PauseScript( 3 );
        isElementAvailable( transactiontypedrpdwn, ELEMENTTIMEOUT );
        driver.findElement( transactiontypedrpdwn ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( transactiontypesearchlink, ELEMENTTIMEOUT );
        driver.findElement( transactiontypesearchlink ).click();
        oracleObjectRender( SCRIPTTIME );
        transactiontypepopup();
        oracleObjectRender(SCRIPTTIME);oracleObjectRender(SCRIPTTIME);
        //credit reason
        isElementAvailable( creditreason, ELEMENTTIMEOUT );
        Select drpcreditreason = new Select( driver.findElement( creditreason ) );
        drpcreditreason.selectByVisibleText( dataTable.getData( "General_Data", "Credit Reason" ) );
    }


    public void standalonecreditmemo() {
        isElementAvailable( transactionclass, ELEMENTTIMEOUT );
        Select drptransclass = new Select( driver.findElement( transactionclass ) );
        drptransclass.selectByVisibleText( dataTable.getData( "General_Data", "Transaction Class" ) );
        oracleObjectRender( QUERYRESPONSE );
        generalinfoCreditmemo();
        customerinfo();
        creditmemolineinfo();
        report.updateTestLog( "Verify the Entered Data", " Data Captured for credit memo", Status.PASS );
        isElementAvailable( btnsave, ELEMENTTIMEOUT );
        driver.findElement( btnsave ).click();
        oracleObjectRender( QUERYRESPONSE );
        reviewdistirbution();
        isElementAvailable( btnsave, ELEMENTTIMEOUT );
        driver.findElement( btnsave ).click();
        PauseScript( 3 );
        driver.findElement( btncompletenclosedrpmemo ).click();
        PauseScript( 2 );
        driver.findElement( btncompletenreview ).click();
        oracleObjectRender( SCRIPTTIME );
        report.updateTestLog( "Verify the credit memo creation", "Credit Memo has been created successfully!", Status.PASS );
    }

    public void createcreditTransactionnav() {
        isElementAvailable( billingtask, ELEMENTTIMEOUT );
        driver.findElement( billingtask ).click();

        isElementAvailable( credittransaction, ELEMENTTIMEOUT );
        driver.findElement( credittransaction ).click();
        PauseScript( 4 );
    }

    public void creditTransaction(String transactionNumber) {
        isElementAvailable( transnumber, PAGELOADTIMEOUT );
        driver.findElement( transnumber ).sendKeys(transactionNumber);
        driver.findElement( transnumber ).sendKeys( Keys.TAB );
        oracleObjectRender( SCRIPTTIME );
        driver.findElement( transactiontype ).sendKeys( dataTable.getData( "General_Data", "Transaction Type1" ) );
        driver.findElement( transactiontype ).sendKeys( Keys.TAB );
        oracleObjectRender( SCRIPTTIME );
        report.updateTestLog( "Verify the Entered Transaction number and its Type", " Transaction Number and Type updated Successfully ", Status.PASS );
        isElementAvailable( btncreditentirebal, ELEMENTTIMEOUT );
        driver.findElement( btncreditentirebal ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( btneditdistributions, ELEMENTTIMEOUT );
        driver.findElement( btneditdistributions ).click();
        PauseScript( 3 );
        driver.findElement( btnnowarn ).click();
        PauseScript( 3 );
        driver.findElement( btnsave ).click();
        oracleObjectRender( QUERYRESPONSE );
        driver.findElement( btncompletenclosedrp ).click();
        PauseScript( 3 );
        isElementAvailable( btncompletenreview, ELEMENTTIMEOUT );
        driver.findElement( btncompletenreview ).click();
        oracleObjectRender( QUERYRESPONSE );
        report.updateTestLog( "Verify the credit Transaction", " Credit Transaction created successfully", Status.PASS );
    }
}

