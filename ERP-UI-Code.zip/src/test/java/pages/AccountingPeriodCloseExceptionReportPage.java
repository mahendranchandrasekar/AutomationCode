package pages;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.ScriptHelper;
import com.cognizant.framework.Status;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.Select;

public class AccountingPeriodCloseExceptionReportPage extends MasterPages {

    // Elements

    //Links
    private final By taskmenu = By.xpath( "//img[@title='Tasks']" );
    private final By accountingperiodcloseexceptionreport = By.xpath( "//a[text()='Accounting Period Close Exceptions Report'] [@class='xmg']" );
    private final By managingaccountingperiods = By.xpath( "//a[text()='Manage Accounting Periods']");
    private final By ledger = By.xpath( "//label[text()='Ledger']/ancestor::tr[1]/td[2]//input" );
    private final By period = By.xpath( "//label[text()='Period']/ancestor::tr[1]/td[2]//input" );
    private final By reportstyle = By.xpath( "//label[text()='Report Style']/ancestor::tr[1]/td[2]//select" );
    private final By overviewheader = By.xpath( "//h1[text()='Overview']" );
    private final By expandprocessmonitor = By.xpath( "//a[@title='Expand Process Monitor']" );
    private final By processrefreshicon = By.xpath( "//*[contains(@id,'processRefreshId::icon')]" );
    private final By processmontiorview = By.xpath( "//*[contains(text(),'Hierarchy')]");
    private final By processoutputicon = By.xpath( "//*[contains(@id,'pc1:resultsTable:0:imglinkid::icon')]" );
    private final By btnrepublish = By.xpath( "//button[text()='Republish']" );
    private final By processoutoutopoupclosebutton = By.xpath( "//*[contains(@id,'projects_costs:0:MAt1:0:cwap:r3:0:dlg1::close')]" );

    //report
    private final By reportsettings = By.xpath( "//*[@id='reportViewMenu']/img" );
    private final By reportexport = By.xpath( "//*[@id='_xdoFMenu0']/div/div/ul/li[1]/div/a" );
    private final By reporttype = By.xpath( "//*[text()='PDF']" );
    //Close period
    private final By mngaccpdactiondrpdwn = By.xpath( "//*[contains(@id,'ATp:ATm')]/div/table/tbody/tr/td[3]/div" );
    private final By closecurrentperiod = By.xpath( "//*[contains(@id,'ATp:cmi7')]/td[2]" );
    private final By opencurrentperiod = By.xpath( "//*[contains(@id,'ATp:cmi1')]/td[2]" );
    private final By btncloseperiod = By.xpath( "//span[text()='Close Period']" );
    private final By btndone = By.xpath( "//*[@accesskey='o']" );
    private final By accountingperiodresults = By.xpath( "//table[@summary='Accounting Period Status']/tbody/tr[1]" );
    private final By accountingperiodresultsselection = By.xpath( "//table[@summary='Accounting Period Status']/tbody/tr[1]/td[1]/span[1]/a/span[1]" );
    private final By status = By.xpath( "//select[contains(@id,'ATp:selectStatus::content')]" );
    private final By warningpopup = By.xpath( "//div[contains(@id,'projects_costs:0:MApgl4')]" );
    private final By warningpopupyesbutton = By.xpath( "//button[contains(text(),'Yes')]");

    // Open the project period
    private final By btnopenperiod = By.xpath( "//span[text()='Open Period']" );
    private final By filtericon = By.xpath( "//img[@alt='Query By Example']" );
    private final By refreshicon = By.xpath( "//img[@alt='Refresh']" );
    private final By filterledgerentry = By.xpath( "//input[contains(@id,'ATp_afr_table1_afr_column1::content')]" );
    private final By filterperiodname = By.xpath( "//input[contains(@id,'ATp_afr_table1_afr_idPeriodName::content')]" );

    private final By ledgerlink = By.xpath( "//*[contains(@id,'p:table1::db')]/table/tbody/tr[3]/td[1]/span" );

    private final By btnsubmit = By.xpath( "//*[@accesskey='m']" );
    private final By btnpopupok = By.xpath( "//*[contains(@id,'requestBtns:confirmationPopup:confirmSubmitDialog::ok')]" );
    private final By btncancel = By.xpath( "//a[@accesskey='C']" );
    private final By warningpopupokbutton = By.xpath( "//td[contains(@id,'projects_costs:0:MAwd::_fcc')]/span/button[1]" );
    private final By openperiodwarningpopupokbutton = By.xpath( "//td[contains(@id,'projects_costs:0:MAt2:1:ap1:d134::_fcc')]/button[1]" );


    // page loading time
    public static final int PAGELOADTIMEOUT = 90;
    // individual element load time
    public static final int ELEMENTTIMEOUT = 60;
    // Oracle query response
    public static final long QUERYRESPONSE = 15;
    // object render script
    public static final int SCRIPTTIME = 5;

    /**
     * Constructor to initialize the functional library
     *
     * @param scriptHelper The {@link ScriptHelper} object passed from the
     *                     {@link DriverScript}
     */
    public AccountingPeriodCloseExceptionReportPage(ScriptHelper scriptHelper) {
        super( scriptHelper );
    }

    public void accountingperiodcloseexceptionreportnav() {
        isElementAvailable( taskmenu, ELEMENTTIMEOUT );
        driver.findElement( taskmenu ).click();
        PauseScript( 3 );
        isElementAvailable( accountingperiodcloseexceptionreport, ELEMENTTIMEOUT );
        driver.findElement( accountingperiodcloseexceptionreport ).click();
    }

    public void Manageaccountingperiodsnav() {
        isElementAvailable( taskmenu, ELEMENTTIMEOUT );
        driver.findElement( taskmenu ).click();
        PauseScript( 3 );
        isElementAvailable( managingaccountingperiods, ELEMENTTIMEOUT );
        driver.findElement( managingaccountingperiods ).click();
    }

    private void entertheRequiredetailsonparameter() {
        isElementAvailable( ledger, ELEMENTTIMEOUT );
        driver.findElement( ledger ).click();
        driver.findElement( ledger ).sendKeys( dataTable.getData( "General_Data", "Ledger" ) );
        isElementAvailable( period, ELEMENTTIMEOUT );
        driver.findElement( period ).click();
        driver.findElement( period ).sendKeys( dataTable.getData( "General_Data", "Period" ) );
        isElementAvailable( reportstyle, ELEMENTTIMEOUT );
        Select drpreportstyle = new Select( driver.findElement( reportstyle ) );
        drpreportstyle.selectByVisibleText( dataTable.getData( "General_Data", "Report Style" ) );
        report.updateTestLog( "Verify the required data", " Data captured Successfully", Status.PASS );
        isElementAvailable( btnsubmit, ELEMENTTIMEOUT );
        driver.findElement( btnsubmit ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( btnpopupok, ELEMENTTIMEOUT );
        driver.findElement( btnpopupok ).click();
        oracleObjectRender( SCRIPTTIME );
    }

    private void overviewheadercheck() {
        isElementAvailable( overviewheader, ELEMENTTIMEOUT );
        driver.findElement( overviewheader ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( expandprocessmonitor, ELEMENTTIMEOUT );
        driver.findElement( expandprocessmonitor ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( processmontiorview, ELEMENTTIMEOUT );
        driver.findElement( processmontiorview ).click();
        oracleObjectRender( QUERYRESPONSE );
        isElementAvailable( processrefreshicon, ELEMENTTIMEOUT );
        driver.findElement( processrefreshicon ).click();
        oracleObjectRender( QUERYRESPONSE );
        driver.findElement( processrefreshicon ).click();
        oracleObjectRender( SCRIPTTIME );
        report.updateTestLog( "Verify the process data", " Processed Successfully", Status.PASS );
    }

    private void exportreport() {
        isElementAvailable( processoutputicon, ELEMENTTIMEOUT );
        driver.findElement( processoutputicon ).click();
        oracleObjectRender( QUERYRESPONSE );
        isElementAvailable( processoutoutopoupclosebutton, ELEMENTTIMEOUT );
        driver.findElement( processoutoutopoupclosebutton ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( btnrepublish, ELEMENTTIMEOUT );
        driver.findElement( btnrepublish ).click();
        oracleObjectRender( QUERYRESPONSE );
        isElementAvailable( reportsettings, ELEMENTTIMEOUT );
        driver.findElement( reportsettings ).click();
        PauseScript( 3 );
        isElementAvailable( reportexport, ELEMENTTIMEOUT );
        driver.findElement( reportexport ).click();
        PauseScript( 3 );
        isElementAvailable( reporttype, ELEMENTTIMEOUT );
        driver.findElement( reporttype ).click();
        report.updateTestLog( "Verify the Report", " Report generated Successfully", Status.PASS );
        oracleObjectRender( QUERYRESPONSE );
    }

    private void selecttheledgerfromaccountingperiod() {
        isElementAvailable( filtericon, ELEMENTTIMEOUT );
        driver.findElement( filtericon ).click();
        PauseScript( 3 );
        while (driver.findElements( filtericon ).size() >= 1) {
            driver.findElement( filtericon ).click();
            oracleObjectRender( SCRIPTTIME );
            if ( driver.findElements( filterledgerentry ).size() >= 1 )
                break;
        }
        driver.findElement( filterledgerentry ).sendKeys( dataTable.getData( "General_Data", "Ledger" ) );
        PauseScript( 3 );
        driver.findElement( filterledgerentry ).sendKeys( Keys.ENTER );
        oracleObjectRender( SCRIPTTIME );
        //Filtering the accounting period data with status
        isElementAvailable( accountingperiodresults, ELEMENTTIMEOUT );
        driver.findElement( accountingperiodresults ).click();
        report.updateTestLog( "Verify the accounting Period selection", " Accounting Period selected Successfully", Status.PASS );
        oracleObjectRender( SCRIPTTIME );
    }

    private void selecttheledgertoopentheperiod() {
        isElementAvailable( filtericon, ELEMENTTIMEOUT );
        driver.findElement( filtericon ).click();
        PauseScript( 3 );
        while (driver.findElements( filtericon ).size() >= 1) {
            driver.findElement( filtericon ).click();
            oracleObjectRender( SCRIPTTIME );
            if ( driver.findElements( filterledgerentry ).size() >= 1 )
                break;
        }
        driver.findElement( filterledgerentry ).sendKeys( dataTable.getData( "General_Data", "Ledger" ) );
        PauseScript( 3 );
        driver.findElement( filterledgerentry ).sendKeys( Keys.ENTER );
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( accountingperiodresults, ELEMENTTIMEOUT );
        driver.findElement( accountingperiodresults ).click();
        PauseScript( 3 );
        isElementAvailable( accountingperiodresultsselection, ELEMENTTIMEOUT );
        driver.findElement( accountingperiodresultsselection ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( filterperiodname, ELEMENTTIMEOUT );
        driver.findElement( filterperiodname ).sendKeys( dataTable.getData( "General_Data", "Period" ) );
        PauseScript( 3 );
        driver.findElement( filterperiodname ).sendKeys( Keys.ENTER );
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( accountingperiodresults, ELEMENTTIMEOUT );
        driver.findElement( accountingperiodresults ).click();
        oracleObjectRender( SCRIPTTIME );
        report.updateTestLog( "Verify the accounting Period selection", " Accounting Period selected Successfully", Status.PASS );
    }

    private void closetheperiod() {
        isElementAvailable( mngaccpdactiondrpdwn, ELEMENTTIMEOUT );
        driver.findElement( mngaccpdactiondrpdwn ).click();
        PauseScript( 3 );
        isElementAvailable( closecurrentperiod, ELEMENTTIMEOUT );
        driver.findElement( closecurrentperiod ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( warningpopupyesbutton, ELEMENTTIMEOUT );
        driver.findElement( warningpopupyesbutton ).click();
        report.updateTestLog( "Verify the project Period", " Project Period Closed Successfully", Status.PASS );
        PauseScript( 3 );
    }

    private void Opentheperiod() {
        isElementAvailable( mngaccpdactiondrpdwn, ELEMENTTIMEOUT );
        driver.findElement( mngaccpdactiondrpdwn ).click();
        PauseScript( 3 );
        isElementAvailable( opencurrentperiod, ELEMENTTIMEOUT );
        driver.findElement( opencurrentperiod ).click();
        PauseScript( 3 );
        report.updateTestLog( "Verify the project Period", " Project Period Opened Successfully", Status.PASS );
        PauseScript( 3 );
        if ( driver.findElements( openperiodwarningpopupokbutton ).size() > 0 ) {
            isElementAvailable( openperiodwarningpopupokbutton, ELEMENTTIMEOUT );
            driver.findElement( openperiodwarningpopupokbutton ).click();
            PauseScript( 3 );
            isElementAvailable( btndone, ELEMENTTIMEOUT );
            driver.findElement( btndone ).click();
            PauseScript( 3 );
        } else {
            isElementAvailable( btndone, ELEMENTTIMEOUT );
            driver.findElement( btndone ).click();
            PauseScript( 3 );
        }
    }


    //Close the project period
    public void closetheProjectperiod() {
        accountingperiodcloseexceptionreportnav();
        entertheRequiredetailsonparameter();
        overviewheadercheck();
        Manageaccountingperiodsnav();
        selecttheledgerfromaccountingperiod();
        closetheperiod();
    }

    //Open the Project Period (for adjustments)

    public void OpentheProjectperiod() {
        Manageaccountingperiodsnav();
        selecttheledgertoopentheperiod();
        Opentheperiod();
    }
}
