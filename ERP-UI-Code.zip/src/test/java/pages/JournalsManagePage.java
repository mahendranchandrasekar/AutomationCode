package pages;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.ScriptHelper;
import com.cognizant.framework.ExcelDataImport;
import com.cognizant.framework.Status;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

/**
 * Journals Page class
 */
public class JournalsManagePage extends MasterPages {
	// UI Map object definitions

	// Elements
	private final By journalBatchTxtbox= By.xpath("//label[text()='Journal Batch']/following::input[1]");
    private final By accountingPeriodDrpdown= By.xpath("//label[text()='Accounting Period']/following::input[1]");
	private final By searchButton= By.xpath("//button[text()='Search']");
	private final By verifyThePostedJournalRecord= By.xpath("//table[(@summary='Search Results')]/tbody/tr[1]");
	private final By verifyThePostedJournalRecordStatus= By.xpath("//table[(@summary='Search Results')]/tbody/tr[1]/td[10]/child::*");
	private final By batchStatusDrpdown= By.xpath("//label[text()='Batch Status']/following::select[2]");
    private final By postBatchButton= By.xpath("//span[text()='Post Batch']");
    private final By selectFirstRecord= By.xpath("//table[(@summary='Search Results')]/tbody/tr[1]/td[5]");
    private final By clickOnFirstRecord= By.xpath("//table[(@summary='Search Results')]/tbody/tr[1]/td[4]/span/a");

    private final By popUpOkButton= By.xpath("//button[contains(@id,'userResponsePopupDialogButtonOk')]");
    private final By popUpConfirmationText= By.xpath("//span[contains(@id,'general_accounting_journals:0:MAnt2:2:pt1:ap1:userRes:1:ot1')]");

    private final By popUpConfirmationTextForPostBatch= By.xpath("//div[contains(text(),'Your journal approval request has been submitted')]");

    //Page Sync Config

	// page loading time
	public static final int PAGELOADTIMEOUT = 90;
	// individual element load time
	public static final int ELEMENTTIMEOUT = 60;
	// Oracle query response
	public static final long QUERYRESPONSE = 15;
	// object render script
	public static final long SCRIPTTIME = 5;

	String journalBatchData = dataTable.getData(ExcelDataImport.GeneralData, "JournalBatch").trim();
	String journalRecordStatus = dataTable.getData(ExcelDataImport.GeneralData, "JournalStatus").trim();
	/**
	 * Constructor to initialize the page
	 *
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}b  n '/fg .+
	 */
	public JournalsManagePage(ScriptHelper scriptHelper) {
		super(scriptHelper);
		isElementAvailable(journalBatchTxtbox, PAGELOADTIMEOUT);
	}


	public void searchAndVerifyPostedJournal() {
		isElementAvailable(journalBatchTxtbox, ELEMENTTIMEOUT);
        driver.findElement(journalBatchTxtbox).sendKeys(journalBatchData);
        isElementAvailable(accountingPeriodDrpdown, ELEMENTTIMEOUT);
        driver.findElement(accountingPeriodDrpdown).clear();
        isElementAvailable(accountingPeriodDrpdown, ELEMENTTIMEOUT);
        driver.findElement(accountingPeriodDrpdown).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, ExcelDataImport.AccountingPeriod));
		isElementAvailable(searchButton, ELEMENTTIMEOUT);
		driver.findElement(searchButton).click();
		isElementAvailable(verifyThePostedJournalRecord, ELEMENTTIMEOUT);
		Assert.assertTrue(driver.findElement(verifyThePostedJournalRecord).isDisplayed());
		Assert.assertEquals(driver.findElement(verifyThePostedJournalRecordStatus).getText(),journalRecordStatus);

	}

    public void searchVerifyUnPostedJournal() {
        isElementAvailable(journalBatchTxtbox, ELEMENTTIMEOUT);
        driver.findElement(journalBatchTxtbox).sendKeys(journalBatchData);
        isElementAvailable(accountingPeriodDrpdown, ELEMENTTIMEOUT);
        driver.findElement(accountingPeriodDrpdown).clear();
        isElementAvailable(accountingPeriodDrpdown, ELEMENTTIMEOUT);
        driver.findElement(accountingPeriodDrpdown).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, ExcelDataImport.AccountingPeriod));
        isElementAvailable(searchButton, ELEMENTTIMEOUT);
        driver.findElement(searchButton).click();
        isElementAvailable(verifyThePostedJournalRecord, ELEMENTTIMEOUT);
        Assert.assertTrue(driver.findElement(verifyThePostedJournalRecord).isDisplayed());
        isElementAvailable(clickOnFirstRecord, ELEMENTTIMEOUT);
        driver.findElement(clickOnFirstRecord).click();
    }

    public void searchTheUnPostedJournal() {
        isElementAvailable(journalBatchTxtbox, ELEMENTTIMEOUT);
        driver.findElement(journalBatchTxtbox).sendKeys(journalBatchData);
        isElementAvailable(accountingPeriodDrpdown, ELEMENTTIMEOUT);
        driver.findElement(accountingPeriodDrpdown).clear();
        oracleObjectRender(QUERYRESPONSE);
        driver.findElement(accountingPeriodDrpdown).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, ExcelDataImport.AccountingPeriod));
        isElementAvailable(batchStatusDrpdown, ELEMENTTIMEOUT);
        Select selectDropDown = new Select(driver.findElement(batchStatusDrpdown));
        selectDropDown.selectByVisibleText(dataTable.getData(ExcelDataImport.GeneralData, ExcelDataImport.JournalStatus));
        isElementAvailable(searchButton, ELEMENTTIMEOUT);
        driver.findElement(searchButton).click();
        isElementAvailable(verifyThePostedJournalRecord, ELEMENTTIMEOUT);
        Assert.assertTrue(driver.findElement(verifyThePostedJournalRecord).isDisplayed());
        report.updateTestLog("Verify Journal", "Complete Journal is available", Status.PASS);
        isElementAvailable(selectFirstRecord, ELEMENTTIMEOUT);
        driver.findElement(selectFirstRecord).click();
        // TODO START - removing POSTBATCH button
        oracleObjectRender(QUERYRESPONSE);
        Assert.assertTrue(driver.findElement(postBatchButton).isEnabled());
        isElementAvailable(postBatchButton, ELEMENTTIMEOUT);
        driver.findElement(postBatchButton).click();
        try {
            isElementAvailable(popUpConfirmationTextForPostBatch, PAGELOADTIMEOUT);
            driver.findElement(popUpConfirmationTextForPostBatch).isDisplayed();
            String innerText = driver.findElement(popUpConfirmationTextForPostBatch).getAttribute("innerHTML");
            driver.findElement(popUpOkButton).click();
            oracleObjectRender(QUERYRESPONSE);
            report.updateTestLog("Journal Approval request submitted", "Unposted Journal Approval request has been submitted", Status.PASS);
        } catch (Exception e) {
            report.updateTestLog("Journal Approval request submitted", "Unposted Journal Approval request has not been submitted", Status.FAIL);
        }
    }

    public void searchPostedAndUnPostedJournal() {
        oracleObjectRender(QUERYRESPONSE);oracleObjectRender(SCRIPTTIME);
        isElementAvailable(accountingPeriodDrpdown, ELEMENTTIMEOUT);
        driver.findElement(accountingPeriodDrpdown).clear();
        driver.findElement(accountingPeriodDrpdown).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "AccountingPeriod"));
        isElementAvailable(batchStatusDrpdown, ELEMENTTIMEOUT);
        Select selectDropDown = new Select(driver.findElement(batchStatusDrpdown));
        selectDropDown.selectByVisibleText(dataTable.getData(ExcelDataImport.GeneralData, "JournalStatus"));
        isElementAvailable(searchButton, ELEMENTTIMEOUT);
        driver.findElement(searchButton).click();
        isElementAvailable(verifyThePostedJournalRecord, ELEMENTTIMEOUT);
        Assert.assertTrue(driver.findElement(verifyThePostedJournalRecord).isDisplayed());
        isElementAvailable(clickOnFirstRecord, ELEMENTTIMEOUT);
        driver.findElement(clickOnFirstRecord).click();
    }



}