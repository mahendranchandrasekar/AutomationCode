package pages;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.ScriptHelper;
import com.cognizant.framework.ExcelDataImport;
import com.cognizant.framework.Status;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

public class AssetRetirement extends AssetsPage {

    private class Constant {

        private static final String Searchassetnumber = "Search Asset Number";
    }

    // Elements

    //Links
    private final By navigator = By.xpath( "//a[@title='Navigator']" );
    private final By taskmenu = By.xpath( "//*[@alt='Tasks']" );
    private final By retireassets = By.xpath( "//*[text()='Retire Assets']" );
    private final By reinstateassets = By.xpath( "//*[text()='Reinstate Assets']" );
    private final By assetinquiry = By.xpath( "//*[contains(@id,'nv_itemNode_fixed_assets_inquiry')]" );
    private final By assets = By.xpath( "//div[contains(@id,'fixed_assets_inquiry:1:_FOTsr1:0:AP4:r1:0:pt2::tabh')]/div/div/div[1]/div/a");

    // searchcriteria elements
    private final By assetnumber = By.xpath( "//label[text()='Asset Number']/ancestor::tr[1]/td[2]//input" );
    private final By searchresults = By.xpath( "//table[@summary='Search Results']/tbody/tr/td/div/table/tbody/tr[1]" );


    //retirecost
    private final By costretired = By.xpath( "//label[text()='Cost Retired']/ancestor::tr[1]/td[2]//input" );
    private final By retirementreason = By.xpath( "//label[text()='Retirement Reason']/ancestor::tr[1]/td[2]//select" );
    private final By assetretired = By.xpath( "//table[@summary='Search Results']/tbody/tr[1]/td/div/table/tbody/tr[1]/td[1]" );
    private final By recentreirementstab = By.xpath( "//a[text()='Recent Retirements']" );
    private final By reinstatetransactiontab = By.xpath( "//a[text()='Transactions']" );
    private final By collapsesearch = By.xpath( "//a[@title='Collapse Search']" );
    private final By expandsearch = By.xpath( "//a[@title='Expand Search']" );


    //button
    private final By btnsearch = By.xpath( "//button[text()='Search']" );
    private final By btnretirecost = By.xpath( "//button[text()='Retire Cost']" );
    private final By btnsubmit = By.xpath( "//*[@accesskey='m']" );
    private final By btnsaveanclosedrpdwn = By.xpath( "//a[@title='Save and Close']" );
    private final By btnsave = By.xpath( "//*[text()='Save']" );
    private final By btnDone = By.xpath( "//button[@accesskey='o']" );
    private final By btnreinstate = By.xpath( "//*[text()='Reinstate']" );
    private final By btnwarnningYes = By.xpath( "//button[@accesskey='Y']" );


    // page loading time
    public static final int PAGELOADTIMEOUT = 90;
    // individual element load time
    public static final int ELEMENTTIMEOUT = 60;
    // Oracle query response
    public static final long QUERYRESPONSE = 15;
    // object render script
    public static final int SCRIPTTIME = 5;

    /**
     * Constructor to initialize the functional library
     *
     * @param scriptHelper The {@link ScriptHelper} object passed from the
     *                     {@link DriverScript}
     */
    public AssetRetirement(ScriptHelper scriptHelper) {
        super( scriptHelper );
    }


    public void retireAssetsnav() {
        isElementAvailable( taskmenu, ELEMENTTIMEOUT );
        driver.findElement( taskmenu ).click();

        isElementAvailable( retireassets, ELEMENTTIMEOUT );
        driver.findElement( retireassets ).click();
    }

    public void assetinquirynav() {
        isElementAvailable( navigator, ELEMENTTIMEOUT );
        driver.findElement( navigator ).click();

        isElementAvailable( assetinquiry, ELEMENTTIMEOUT );
        driver.findElement( assetinquiry ).click();
    }

    private void searchassetforretire() {
        isElementAvailable( assetnumber, ELEMENTTIMEOUT );
        driver.findElement( assetnumber ).click();
        String assetnumb = (dataTable.getData( "General_Data", "Asset Number" ));
        driver.findElement( assetnumber ).sendKeys( assetnumb);
        PauseScript( 2 );
        isElementAvailable( btnsearch, ELEMENTTIMEOUT );
        driver.findElement( btnsearch ).click();
        oracleObjectRender( SCRIPTTIME );
        String assetNumber = (dataTable.getData( ExcelDataImport.GeneralData, Constant.Searchassetnumber  ));
        report.updateTestLog( "Search the Asset Number ", " Asset Number -" + assetNumber + " found on the search Results ", Status.PASS );

    }

    private void searchassetforreinstate() {
        isElementAvailable( assetnumber, ELEMENTTIMEOUT );
        driver.findElement( assetnumber ).click();
        driver.findElement( assetnumber ).sendKeys( dataTable.getData( ExcelDataImport.GeneralData,Constant.Searchassetnumber ) );
        PauseScript( 2 );
        isElementAvailable( btnsearch, ELEMENTTIMEOUT );
        driver.findElement( btnsearch ).click();
        oracleObjectRender( SCRIPTTIME );
        String assetNumber = (dataTable.getData( ExcelDataImport.GeneralData, Constant.Searchassetnumber  ));
        report.updateTestLog( "Search the Asset Number ", " Asset Number -" + assetNumber + " found on the search Results ", Status.PASS );

    }

    private void clickonsearchresult() {
        isElementAvailable( searchresults, ELEMENTTIMEOUT );
        driver.findElement( searchresults ).click();
        oracleObjectRender( SCRIPTTIME );
    }


    private void clickonretirecost() {
        isElementAvailable( btnretirecost, ELEMENTTIMEOUT );
        driver.findElement( btnretirecost ).click();
        oracleObjectRender( SCRIPTTIME );
    }

    private void entertherequireddetails() {
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( costretired, PAGELOADTIMEOUT);
        driver.findElement( costretired ).sendKeys(dataTable.getData( ExcelDataImport.GeneralData, "Cost Retired" ) );
        PauseScript( 2 );
        isElementAvailable( retirementreason, ELEMENTTIMEOUT );
        Select drpretirementreason = new Select( driver.findElement( retirementreason ) );
        drpretirementreason.selectByVisibleText( dataTable.getData( ExcelDataImport.GeneralData, "Retirement Reason" ) );
        PauseScript( 2 );
        report.updateTestLog( "Verify the Retired Cost and Retirement Reason", " Retired Cost and Retirement Reason updated Successfully ", Status.PASS );
    }

    private void clickonsaveandclose() {
        isElementAvailable( btnsaveanclosedrpdwn, ELEMENTTIMEOUT );
        driver.findElement( btnsaveanclosedrpdwn ).click();
        PauseScript( 1 );
        isElementAvailable( btnsave, ELEMENTTIMEOUT );
        driver.findElement( btnsave ).click();
        PauseScript( 2 );
    }

    private void clickonsubmit() {
        isElementAvailable( btnsubmit, ELEMENTTIMEOUT );
        driver.findElement( btnsubmit ).click();
        PauseScript( 4 );
    }

    private void clickondonebutton() {
        isElementAvailable( btnDone, ELEMENTTIMEOUT );
        driver.findElement( btnDone ).click();
        PauseScript( 3 );
    }

    private void clikconAssets() {
        isElementAvailable( assets, ELEMENTTIMEOUT );
        driver.findElement( assets ).click();
        PauseScript( 4 );
    }


    private void clickonrecentreirementstab() {
        isElementAvailable( recentreirementstab, ELEMENTTIMEOUT );
        driver.findElement( recentreirementstab ).click();
        oracleObjectRender( SCRIPTTIME );
        report.updateTestLog( "Verify the Recent Retirement", " Data updated Successfully on Recent Retirement ", Status.PASS );
    }

    private void checktheassetretiredisdisplayed() {
        isElementAvailable( assetretired, ELEMENTTIMEOUT );
        PauseScript( 2 );
        driver.findElement( assetretired ).isDisplayed();
    }


    public void retirementofAsset() {
        searchassetforretire();
        clickonsearchresult();
        clickonretirecost();
        entertherequireddetails();
        clickonsaveandclose();
        clickonsubmit();
        clickondonebutton();
        assetinquirynav();
        clikconAssets();
        searchassetforretire();
        clickonrecentreirementstab();
        checktheassetretiredisdisplayed();
        report.updateTestLog( "Verify the Asset Retirement", " Asset Retirement Successfully Completed", Status.PASS );
    }

    //Reinstatement of Asset
    public void reinstateassetnav() {
        isElementAvailable( taskmenu, ELEMENTTIMEOUT );
        driver.findElement( taskmenu ).click();

        isElementAvailable( reinstateassets, ELEMENTTIMEOUT );
        driver.findElement( reinstateassets ).click();
    }


    private void clickonreinstate() {
        isElementAvailable( btnreinstate, ELEMENTTIMEOUT );
        driver.findElement( btnreinstate ).click();
        PauseScript( 2 );
        isElementAvailable( btnwarnningYes, ELEMENTTIMEOUT );
        driver.findElement( btnwarnningYes ).click();
        oracleObjectRender( SCRIPTTIME );
    }

    public void clickoncollapseorexpandsearch() {
        if ( driver.findElement( expandsearch ).isDisplayed() ) {
            isElementAvailable( btnsearch, ELEMENTTIMEOUT );
            driver.findElement( btnsearch ).click();
        } else
            isElementAvailable( collapsesearch, ELEMENTTIMEOUT );
        driver.findElement( collapsesearch ).click();
        isElementAvailable( btnsearch, ELEMENTTIMEOUT );
        driver.findElement( btnsearch ).click();
    }

    private void clickontransactiontab() {
        isElementAvailable( reinstatetransactiontab, ELEMENTTIMEOUT );
        driver.findElement( reinstatetransactiontab ).click();
        oracleObjectRender( QUERYRESPONSE );
        driver.findElement( btnsearch ).click();
        oracleObjectRender( QUERYRESPONSE );
        String assetnumb = dataTable.getData(ExcelDataImport.GeneralData, Constant.Searchassetnumber );
        report.updateTestLog( "Verify the Reinstate asset - " + assetnumb + " on the Transaction tab ", "  Reinstated has been updated on the Transaction tab ", Status.PASS );
    }

    public void reinstatementofAsset() {
        searchassetforreinstate();
        clickonsearchresult();
        clickonreinstate();
        clickondonebutton();
        assetinquirynav();
        searchassetforreinstate();
        clickontransactiontab();
        report.updateTestLog( "Verify the Reinstate asset ", "  Asset has been Reinstated Successfully", Status.PASS );
    }
}