package pages;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.ScriptHelper;
import com.cognizant.framework.Status;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.Select;

public class AssetsPage extends MasterPages {

    // Elements

    //Links
    private final By navigator = By.xpath( "//a[@title='Navigator']" );
    private final By taskmenu = By.xpath( "//*[contains(@class,'x1mp')][contains(@title,'Tasks')]" );
    private final By Fixed_assets = By.xpath( "//*[contains(@id,'nv_itemNode_fixed_assets_additions')]" );
    private final By assetinquiry = By.xpath( "//*[contains(@id,'nv_itemNode_fixed_assets_inquiry')]" );
    private final By FAtask = By.xpath( "//img[contains(@title,'Tasks')]" );

    private final By incompleteasset = By.xpath( "//*[contains(@id,'itInPro:0:ot2')]" );
    private final By results = By.xpath( "//table[@summary='Source Lines']/tbody/tr[2]/td[2]//span" );
    private final By actiondrpdwn = By.xpath( "//*[contains(@id,'ATp:ATm')]/div/table/tbody/tr/td[3]/div" );
    private final By addasset = By.xpath( "//a[text()='Add Asset']" );
    private final By majorCategoryDropdown = By.xpath( "//tr[contains(@id,'fixed_assets_additions:0:_FOTRaT:0:dynam1:0:kf1SPOP_query:criterion0')]/td[2]/table/tbody/tr/td[1]/span/span/input" );
    private final By minorCategoryDropdown = By.xpath( "//tr[contains(@id,'fixed_assets_additions:0:_FOTRaT:0:dynam1:0:kf1SPOP_query:criterion1')]/td[2]/table/tbody/tr/td[1]/span/span/input" );
    private final By categoryOkButton = By.xpath( "//td[contains(@id,'fixed_assets_additions:0:_FOTRaT:0:dynam1:0:kf1_kffSearchDialog::_fcc')]/span/button[3]" );
    private final By categoryIcon = By.xpath( "//img[@title='Select: Category']" );
    private final By book = By.xpath( "//label[text()='Book']/ancestor::tr[1]/td[2]//select" );
    private final By assettype = By.xpath( "//label[text()='Asset Type']/ancestor::tr[1]/td[2]//select" );
    private final By category = By.xpath( "//label[text()='Category']/ancestor::tr[1]/td[2]//input" );
    private final By description = By.xpath( "//label[text()='Description']/ancestor::tr[1]/td[2]//input" );
    private final By cost = By.xpath( "//label[text()='Cost']/ancestor::tr[1]/td[2]//input" );
    private final By units = By.xpath( "//label[text()='Units']/ancestor::tr[1]/td[2]//input" );
    private final By expenseaccount = By.xpath( "//label[text()='Expense Account']/ancestor::tr[1]/td[2]//input" );

    private final By location = By.xpath( "//label[text()='Location']/ancestor::tr[1]/td[2]//input" );
    private final By locationIcon = By.xpath(  "//img[@title='Select: Location']" );
    private final By country = By.xpath( "//tr[contains(@id,'fixed_assets_additions:0:_FOTRaT:0:dynam1:0:kf3SPOP_query:criterion0')]/td[2]/table/tbody/tr[1]/td[1]/span/span/input[1]" );
    private final By city = By.xpath( "//tr[contains(@id,'fixed_assets_additions:0:_FOTRaT:0:dynam1:0:kf3SPOP_query:criterion1')]/td[2]/table/tbody/tr[1]/td[1]/span/span/input[1]" );
    private final By building = By.xpath( "//tr[contains(@id,'fixed_assets_additions:0:_FOTRaT:0:dynam1:0:kf3SPOP_query:criterion2')]/td[2]/table/tbody/tr[1]/td[1]/span/span/input[1]" );
    private final By floor = By.xpath( "//tr[contains(@id,'fixed_assets_additions:0:_FOTRaT:0:dynam1:0:kf3SPOP_query:criterion3')]/td[2]/table/tbody/tr[1]/td[1]/span/span/input[1]" );
    private final By phase = By.xpath( "//tr[contains(@id,'fixed_assets_additions:0:_FOTRaT:0:dynam1:0:kf3SPOP_query:criterion4')]/td[2]/table/tbody/tr[1]/td[1]/span/span/input[1]" );
    private final By locationOkButton = By.xpath( "//td[contains(@id,'fixed_assets_additions:0:_FOTRaT:0:dynam1:0:kf3_kffSearchDialog::_fcc')]/span/button[3]" );
    
    private final By company = By.xpath( "//*[contains(@id,'query:value00::content')]" );
    private final By costcentre = By.xpath( "//*[contains(@id,'query:value10::content')]" );
    private final By account = By.xpath( "//label[text()='Account']/ancestor::tr[1]/td[2]//input" );
    private final By product = By.xpath( "//*[contains(@id,'query:value30::content')]" );
    private final By ajaxValidate = By.xpath( "//div[contains(@class,'AFDetectExpansion')]/../tbody/tr/td/div/../div/div/div/table/tbody/tr[1]/td[1]" );
    private final By brand = By.xpath( "//*[contains(@id,'query:value40::content')]" );
    private final By channel = By.xpath( "//*[contains(@id,'query:value50::content')]" );
    private final By interco = By.xpath( "//*[contains(@id,'query:value60::content')]" );
    private final By origin = By.xpath( "//*[contains(@id,'query:value70::content')]" );
    private final By assetnumber = By.xpath( "//label[text()='Asset Number']/ancestor::tr[1]/td[2]//input" );
    private final By recentadditions = By.xpath( "//*[contains(@id,'assets_inquiry:1:_FOTsr1:0:AP4:r1:0:sdi1::ti')]" );
    private final By recentadditionsresults = By.xpath( "//table[@summary='Search Results']/tbody/tr[1]/td[2]/div/table/tbody/tr[1]/td[1]/span/a" );
    private final By assetkey = By.xpath( "//label[text()='Asset Key']/ancestor::tr[1]/td[2]//input" );
    private final By assetadditionaldesc = By.xpath( "//label[text()='Asset Additional Description']/ancestor::tr[1]/td[2]//input" );
    //Log off
    private final By userarrow = By.xpath( "//*[contains(@id,'FOpt1:_UIScmil1u::icon')]" );
    private final By signout = By.xpath( "//*[text()='Sign Out']" );


    //button
    private final By btnnext = By.xpath( "//*[@accesskey='x']" );
    private final By btnsubmit = By.xpath( "//*[@accesskey='m']" );
    private final By btncancel = By.xpath( "//*[@accesskey='C']" );
    private final By btnok = By.xpath( "//*[@accesskey='k']" );
    private final By btnsearch = By.xpath( "//*[@accesskey='r']" );
    private final By btnreset = By.xpath( "//button[text()='Reset']" );
    private final By btnsaveanclose = By.xpath( "//*[@accesskey='S']" );
    private final By btnsaveanclosedrpdwn = By.xpath( "//*[contains(@id,'saveButton::popEl')]" );
    private final By btnsave = By.xpath( "//*[text()='Save']" );
    // Asser Addition
    private final By assetaddtionmsg = By.xpath( "//*[text()='Prepare Additions was submitted.']" );
    private final By additonsincompletelink = By.xpath( "//img[@title='Selected : Additions']" );

    private final By assetselectionfromtable = By.xpath( "//table[@summary='Source Lines']/tbody/tr[4]/td[3]" );
    private final By actions = By.xpath( "//*[text()='Actions']" );
    private final By assetactiondrpdwn = By.xpath( "//*[contains(@id,'region1:0:ITPdtl:0:r1:0:AT2:_ATp:ATm')]/div/table/tbody/tr/td[3]/div" );
    private final By prepareadditionautomatically = By.xpath( "//*[text()='Prepare Additions Automatically']" );

    // page loading time
    public static final int PAGELOADTIMEOUT = 90;
    // individual element load time
    public static final int ELEMENTTIMEOUT = 60;
    // Oracle query response
    public static final long QUERYRESPONSE = 15;
    // object render script
    public static final int SCRIPTTIME = 5;

    /**
     * Constructor to initialize the functional library
     *
     * @param scriptHelper The {@link ScriptHelper} object passed from the
     *                     {@link DriverScript}
     */
    public AssetsPage(ScriptHelper scriptHelper) {
        super( scriptHelper );
    }

    public void addAssetnav() {
        isElementAvailable( FAtask, ELEMENTTIMEOUT );
        driver.findElement( FAtask ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( addasset, ELEMENTTIMEOUT );
        driver.findElement( addasset ).click();
    }

    public void assetinquirynav() {
        isElementAvailable( navigator, ELEMENTTIMEOUT);
        driver.findElement( navigator ).click();

        isElementAvailable( assetinquiry, ELEMENTTIMEOUT );
        driver.findElement( assetinquiry ).click();
    }

    private void Enterthecategorydetails() {
        isElementAvailable( category, ELEMENTTIMEOUT );
        driver.findElement( category ).click();
        driver.findElement( category ).sendKeys( dataTable.getData( "General_Data", "Category" ) );
        oracleObjectRender( SCRIPTTIME );
    }
    private void EntertMajorandminorcategorydetails() {
        isElementAvailable( categoryIcon, ELEMENTTIMEOUT );
        driver.findElement( categoryIcon ).click();
        oracleObjectRender( QUERYRESPONSE );
        isElementAvailable( majorCategoryDropdown, PAGELOADTIMEOUT );
        driver.findElement( majorCategoryDropdown ).sendKeys( dataTable.getData( "General_Data", "MajorCategory" ) );
        driver.findElement( majorCategoryDropdown ).sendKeys( Keys.TAB );
        oracleObjectRender( QUERYRESPONSE );
        isElementAvailable( minorCategoryDropdown, ELEMENTTIMEOUT );
        driver.findElement( minorCategoryDropdown ).sendKeys( dataTable.getData( "General_Data", "MinorCategory" ) );
        driver.findElement( majorCategoryDropdown ).sendKeys( Keys.TAB );
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( categoryOkButton, ELEMENTTIMEOUT );
        driver.findElement( categoryOkButton ).click();
        oracleObjectRender( SCRIPTTIME );
    }

    private void EntertheDescriptiondetails() {
        isElementAvailable( description, ELEMENTTIMEOUT );
        driver.findElement( description ).click();
        driver.findElement( description ).sendKeys( dataTable.getData( "General_Data", "Asset Description" ) );
        oracleObjectRender( SCRIPTTIME );
    }

    private void EntertheCostdetails() {
        isElementAvailable( cost, ELEMENTTIMEOUT );
        driver.findElement( cost ).click();
        driver.findElement( cost ).sendKeys( dataTable.getData( "General_Data", "Cost" ) );
        oracleObjectRender( SCRIPTTIME );
        driver.findElement( cost ).sendKeys( Keys.TAB);
    }


    private void Enterthelocationdetailsassingledata() {
        isElementAvailable( location, ELEMENTTIMEOUT );
        driver.findElement( location ).click();
        driver.findElement( location ).sendKeys( dataTable.getData( "General_Data", "Location" ) );
        oracleObjectRender( SCRIPTTIME );
    }

    private void Enterlocationdetails() {
        isElementAvailable( location, ELEMENTTIMEOUT );
        driver.findElement( location ).click();
       PauseScript( 3 );
        isElementAvailable( locationIcon, ELEMENTTIMEOUT );
        driver.findElement( locationIcon ).click();
        oracleObjectRender( QUERYRESPONSE );
        isElementAvailable( country, ELEMENTTIMEOUT );
        driver.findElement( country ).click();
        driver.findElement( country ).sendKeys( dataTable.getData( "General_Data", "Country" ) );
        oracleObjectRender( QUERYRESPONSE );
        driver.findElement( country ).sendKeys( Keys.ENTER );
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( city, ELEMENTTIMEOUT );
        driver.findElement( city ).click();
        driver.findElement( city ).sendKeys( dataTable.getData( "General_Data", "City" ) );
        oracleObjectRender( QUERYRESPONSE );
        driver.findElement( city ).sendKeys( Keys.ENTER );
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( building, ELEMENTTIMEOUT );
        driver.findElement( building ).click();
        driver.findElement( building ).sendKeys( dataTable.getData( "General_Data", "Building" ) );
        oracleObjectRender( QUERYRESPONSE );
        driver.findElement( building ).sendKeys( Keys.ENTER );
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( floor, ELEMENTTIMEOUT );
        driver.findElement( floor ).click();
        driver.findElement( floor ).sendKeys( dataTable.getData( "General_Data", "Floor" ) );
        oracleObjectRender( QUERYRESPONSE );
        driver.findElement( floor ).sendKeys( Keys.ENTER );
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( phase, ELEMENTTIMEOUT );
        driver.findElement( phase ).click();
        driver.findElement( phase ).sendKeys( dataTable.getData( "General_Data", "Phase" ) );
        oracleObjectRender( QUERYRESPONSE );
        driver.findElement( phase ).sendKeys( Keys.ENTER );
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( locationOkButton, ELEMENTTIMEOUT );
        driver.findElement( locationOkButton ).click();
        oracleObjectRender( SCRIPTTIME );
    }

    private void clickonNextbutton() {
        driver.findElement( btnnext ).click();
        oracleObjectRender( QUERYRESPONSE );
    }

    private void Enterthecompanydetails() {
        isElementAvailable( company, ELEMENTTIMEOUT );
        driver.findElement( company ).click();
        driver.findElement( company ).sendKeys( dataTable.getData( "General_Data", "Company" ) );
        oracleObjectRender( QUERYRESPONSE );
        driver.findElement( company ).sendKeys( Keys.ENTER );
        oracleObjectRender( SCRIPTTIME );
    }

    private void Enterthecostcentredetails() {
        isElementAvailable( costcentre, ELEMENTTIMEOUT );
        driver.findElement( costcentre ).click();
        driver.findElement( costcentre ).sendKeys( dataTable.getData( "General_Data", "Cost Centre" ) );
        oracleObjectRender( QUERYRESPONSE );
        driver.findElement( costcentre ).sendKeys( Keys.ENTER );
        oracleObjectRender( SCRIPTTIME );


    }

    private void Entertheproductdetails() {
        isElementAvailable( product, ELEMENTTIMEOUT );
        driver.findElement( product ).click();
        driver.findElement( product ).sendKeys( dataTable.getData( "General_Data", "Product" ) );
        oracleObjectRender( QUERYRESPONSE );
        driver.findElement( product ).sendKeys( Keys.ENTER );
        oracleObjectRender( SCRIPTTIME );
    }

    private void Enterthebranddetails() {
        isElementAvailable( brand, ELEMENTTIMEOUT );
        driver.findElement( brand ).click();
        driver.findElement( brand ).sendKeys( dataTable.getData( "General_Data", "Brand" ) );
        oracleObjectRender( QUERYRESPONSE );
        driver.findElement( brand ).sendKeys( Keys.ENTER );
        oracleObjectRender( SCRIPTTIME );
    }

    private void Enterthechanneldetails() {
        isElementAvailable( channel, ELEMENTTIMEOUT );
        driver.findElement( channel ).click();
        driver.findElement( channel ).sendKeys( dataTable.getData( "General_Data", "Channel" ) );
        oracleObjectRender( QUERYRESPONSE );
        driver.findElement( channel ).sendKeys( Keys.ENTER );
        oracleObjectRender( SCRIPTTIME );
    }

    private void Entertheintercodetails() {
        isElementAvailable( interco, ELEMENTTIMEOUT );
        driver.findElement( interco ).click();
        driver.findElement( interco ).sendKeys( dataTable.getData( "General_Data", "Interco" ) );
        oracleObjectRender( QUERYRESPONSE );
        driver.findElement( interco ).sendKeys( Keys.ENTER );
        oracleObjectRender( SCRIPTTIME );
    }

    private void EntertheOrigindetails() {
        isElementAvailable( origin, ELEMENTTIMEOUT );
        driver.findElement( origin ).click();
        driver.findElement( origin ).sendKeys( dataTable.getData( "General_Data", "Origin" ) );
        oracleObjectRender( QUERYRESPONSE );
        driver.findElement( origin ).sendKeys( Keys.ENTER );
        oracleObjectRender( SCRIPTTIME );
    }

    private void Clickonokbutton() {
        driver.findElement( btnok ).click();
        oracleObjectRender( QUERYRESPONSE );
    }

    private void ClickonNextbutton() {
        driver.findElement( btnnext ).click();
        oracleObjectRender( QUERYRESPONSE );
    }


    private void EntertheAssetnumber() {
        isElementAvailable( assetnumber, ELEMENTTIMEOUT );
        driver.findElement( assetnumber ).click();
        driver.findElement( assetnumber ).sendKeys( dataTable.getData( "General_Data", "Asset Number" ) );
        driver.findElement( assetnumber ).sendKeys( Keys.ENTER );
        oracleObjectRender( SCRIPTTIME );
    }


    private void EntertheAssetkey() {
        isElementAvailable( assetkey, ELEMENTTIMEOUT );
        driver.findElement( assetkey ).click();
        driver.findElement( assetkey ).sendKeys( dataTable.getData( "General_Data", "Asset Key" ) );
        driver.findElement( assetkey ).sendKeys( Keys.ENTER );
        oracleObjectRender( SCRIPTTIME );
    }


    private void Entertheassetadditionaldescription() {
        //Asset Additional desc - added as part of UAT
        isElementAvailable( assetadditionaldesc, ELEMENTTIMEOUT );
        driver.findElement( assetadditionaldesc ).click();
        driver.findElement( assetadditionaldesc ).sendKeys( dataTable.getData( "General_Data", "Asset Additional Description" ) );
        driver.findElement( assetadditionaldesc ).sendKeys( Keys.ENTER );
        report.updateTestLog( "Verify Asset Number and Asset key", " Asset Number and Asset Key data updated successfully", Status.PASS );
        oracleObjectRender( SCRIPTTIME );
    }


    private void Clikconsavebutton() {
        isElementAvailable( btnsaveanclosedrpdwn, ELEMENTTIMEOUT );
        driver.findElement( btnsaveanclosedrpdwn ).click();
        PauseScript( 2 );
        isElementAvailable( btnsave, ELEMENTTIMEOUT );
        driver.findElement( btnsave ).click();
        oracleObjectRender( QUERYRESPONSE );
    }

    private void ClikconSubmitbutton() {
        isElementAvailable( btnsubmit, ELEMENTTIMEOUT );
        driver.findElement( btnsubmit ).click();
        report.updateTestLog( "Verify Asset Creation", " Asset Created successfully", Status.PASS );
        oracleObjectRender( SCRIPTTIME );
    }

    private void checkthecreatedassetdetails() {
        oracleObjectRender( QUERYRESPONSE );
        isElementAvailable( recentadditions, ELEMENTTIMEOUT );
        driver.findElement( recentadditions ).click();
        oracleObjectRender( QUERYRESPONSE );
        driver.findElement( recentadditionsresults ).isDisplayed();
        String Assetnumb = (dataTable.getData( "General_Data", "Asset Number" ));
        report.updateTestLog( "Verify the Created Asset on the Recent Addition tab", "  Created Asset " + Assetnumb + " displayed", Status.PASS );
    }

    //Asset Creations
    public void createAsset() {
        isElementAvailable( book, ELEMENTTIMEOUT );
        isElementAvailable( assettype, ELEMENTTIMEOUT );
        Select drpassettype = new Select( driver.findElement( assettype ) );
        drpassettype.selectByVisibleText( dataTable.getData( "General_Data", "Asset Type" ) );
        PauseScript( 2 );
        Enterthecategorydetails();
        EntertheDescriptiondetails();
        EntertheCostdetails();
        Enterthelocationdetailsassingledata();
        report.updateTestLog( "Verify the Asset Type, Category, Description and Cost", " Data entered successfully ", Status.PASS );
        clickonNextbutton();
        Enterthecompanydetails();
        Enterthecostcentredetails();
        Entertheproductdetails();
        Enterthebranddetails();
        Enterthechanneldetails();
        Entertheintercodetails();
        EntertheOrigindetails();
        report.updateTestLog( "Verify the Company, Cost Centre, Channel Interco and Origin", " Data entered successfully", Status.PASS );
        Clickonokbutton();
        ClickonNextbutton();
        EntertheAssetnumber();
        EntertheAssetkey();
        Entertheassetadditionaldescription();
        Clikconsavebutton();
        ClikconSubmitbutton();
        assetinquirynav();
        checkthecreatedassetdetails();
    }

    private void signout() {
        isElementAvailable( userarrow, ELEMENTTIMEOUT );
        driver.findElement( userarrow ).click();
        PauseScript( 2 );
        isElementAvailable( signout, ELEMENTTIMEOUT );
        driver.findElement( signout ).click();
    }


    public void assetaddition() {
        PauseScript( 2 );
        isElementAvailable( additonsincompletelink, ELEMENTTIMEOUT );
        driver.findElement( additonsincompletelink ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( assetselectionfromtable, ELEMENTTIMEOUT );
        driver.findElement( assetselectionfromtable ).click();
        report.updateTestLog( "Verify the Asset selection", "Asset selected successfully", Status.PASS );
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( actions, ELEMENTTIMEOUT );
        driver.findElement( assetactiondrpdwn ).click();
        isElementAvailable( prepareadditionautomatically, ELEMENTTIMEOUT );
        driver.findElement( prepareadditionautomatically ).click();
        oracleObjectRender( SCRIPTTIME );
        driver.findElement( assetaddtionmsg ).isDisplayed();
        report.updateTestLog( "Verify the Asset addition", "Asset Addition completed successfully", Status.PASS );
        oracleObjectRender( SCRIPTTIME );
        signout();
    }


}
