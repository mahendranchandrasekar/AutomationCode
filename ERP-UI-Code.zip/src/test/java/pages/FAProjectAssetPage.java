package pages;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.ScriptHelper;
import com.cognizant.framework.Status;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

public class FAProjectAssetPage extends MasterPages {

    // Elements

    //Links
    private final By taskmenu = By.xpath( "//*[contains(@class,'x1mp')][contains(@title,'Tasks')]" );
    private final By createprojectfromtemplate = By.xpath( "//*[text()='Create Project from Template']" );
    private final By createproject = By.xpath( "//a[text()='Create Project']" );
    private final By headercreateprojectfromtemplate = By.xpath( "//h1[text()='Create Project from Template']" );
    private final By templatename = By.xpath( "//label[text()='Template Name']/ancestor::tr[1]/td[2]//select" );
    private final By templatenumber = By.xpath( "//label[text()='Template Number']/ancestor::tr[1]/td[2]//select" );
    private final By organization = By.xpath( "//label[text()='Organization']/ancestor::tr[1]/td[2]//select" );
    private final By businessunit = By.xpath( "//label[text()='Business Unit']/ancestor::tr[1]/td[2]//select" );
    private final By templateselect = By.xpath( "//table[@summary='Search Results: Project Templates']/tbody/tr[1]/td[1]/span" );
    private final By btncreatefromtemplate = By.xpath( "//*[contains(@id,'ResultsTableId:_ATp:commandToolbarButton1')]" );
    private final By projectname = By.xpath( "//label[text()='Project Name']/ancestor::tr[1]/td[2]//input" );
    private final By projectnumber = By.xpath( "//label[text()='Project Number']/ancestor::tr[1]/td[2]//input" );
    //button
    private final By btnadvancesearch = By.xpath( "//*[@accesskey='d']" );
    private final By btnbasicsearch = By.xpath( "//*[@accesskey='B']" );
    private final By btnsearch = By.xpath( "//*[text()='Search']" );
    private final By btnsaveandclose = By.xpath( "//span[text()='Save and Continue']" );
    private final By btncancel = By.xpath( "//*[@accesskey='C']" );

    //Source template UI change
    private final By sourcetemplate = By.xpath( "//label[text()='Source Template']/ancestor::tr[1]/td[2]//input" );
    private final By templatenumb = By.xpath( "//label[text()='Template Number']/ancestor::tr[1]/td[2]//select" );
    private final By organ = By.xpath( "//label[text()='Organization']/ancestor::tr[1]/td[2]//select" );
    private final By bussunit = By.xpath( "//label[text()='Business Unit']/ancestor::tr[1]/td[2]//select" );
    private final By templateselt = By.xpath( "//table[@summary='Search Results: Project Templates']/tbody/tr[1]/td[1]/span" );
    private final By btncreatefromtemp = By.xpath( "//*[contains(@id,'ResultsTableId:_ATp:commandToolbarButton1')]" );
    private final By projectName = By.xpath( "//label[text()='Project Name']/ancestor::tr[1]/td[2]//input" );
    private final By projectNumber = By.xpath( "//label[text()='Project Number']/ancestor::tr[1]/td[2]//input" );

    private final By sourcetemplateajaxValidate = By.xpath( "//div[contains(@class,'AFDetectExpansion')]/../tbody/tr[1]/td[1]/ul[1]/li[1]" );

    private final By btnsaveandcontinue = By.xpath( "//button[text()='Save and Continue']" );
    private final By btnsavenclose = By.xpath( "//*[@accesskey='S']" );

    private final By btndone = By.xpath( "//*[@accesskey='o']" );

    // page loading time
    public static final int PAGELOADTIMEOUT = 90;
    // individual element load time
    public static final int ELEMENTTIMEOUT = 60;
    // Oracle query response
    public static final long QUERYRESPONSE = 15;
    // object render script
    public static final int SCRIPTTIME = 5;

    /**
     * Constructor to initialize the functional library
     *
     * @param scriptHelper The {@link ScriptHelper} object passed from the
     *                     {@link DriverScript}
     */
    public FAProjectAssetPage(ScriptHelper scriptHelper) {
        super( scriptHelper );
    }


    public void projectAssetnav() {
        isElementAvailable( taskmenu, ELEMENTTIMEOUT );
        driver.findElement( taskmenu ).click();

        isElementAvailable( createprojectfromtemplate, ELEMENTTIMEOUT );
        driver.findElement( createprojectfromtemplate ).click();
    }

    public void projectnav() {
        isElementAvailable( taskmenu, ELEMENTTIMEOUT );
        driver.findElement( taskmenu ).click();

        isElementAvailable( createproject, ELEMENTTIMEOUT );
        driver.findElement( createproject ).click();
    }

    public void createProjectfromTemplate() {
        isElementAvailable( btnadvancesearch, PAGELOADTIMEOUT );
        driver.findElement( btnadvancesearch ).isDisplayed();
        oracleObjectRender( SCRIPTTIME );
        driver.findElement( btnadvancesearch ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( templatename, PAGELOADTIMEOUT );
        Select drtemplatename = new Select( driver.findElement( templatename ) );
        drtemplatename.selectByVisibleText( dataTable.getData( "General_Data", "Search Value" ) );
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( templatenumber, PAGELOADTIMEOUT );
        Select drtemplatenumber = new Select( driver.findElement( templatenumber ) );
        drtemplatenumber.selectByVisibleText( dataTable.getData( "General_Data", "Search Value" ) );
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( organization, PAGELOADTIMEOUT );
        Select drporganization = new Select( driver.findElement( organization ) );
        drporganization.selectByVisibleText( dataTable.getData( "General_Data", "Search Value" ) );
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( businessunit, PAGELOADTIMEOUT );
        Select drpbussunit = new Select( driver.findElement( businessunit ) );
        drpbussunit.selectByVisibleText( dataTable.getData( "General_Data", "Search Value" ) );
        oracleObjectRender( SCRIPTTIME );
        driver.findElement( btnsearch ).click();
        oracleObjectRender( SCRIPTTIME );
        driver.findElement( templateselect ).click();
        oracleObjectRender( SCRIPTTIME );
        report.updateTestLog( "Verify the Template", "  Template has been selected successfully", Status.PASS );
        driver.findElement( btncreatefromtemplate ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( projectname, ELEMENTTIMEOUT );
        driver.findElement( projectname ).click();
        driver.findElement( projectname ).sendKeys( dataTable.getData( "General_Data", "Project Name" ) );
        isElementAvailable( projectnumber, ELEMENTTIMEOUT );
        driver.findElement( projectnumber ).click();
        driver.findElement( projectnumber ).sendKeys( dataTable.getData( "General_Data", "Project Number" ) );
        oracleObjectRender( SCRIPTTIME );
        report.updateTestLog( "Verify the Project name and Project number", " Project Name and Number updated successfully", Status.PASS );
        driver.findElement( btnsaveandclose ).click();
        oracleObjectRender( QUERYRESPONSE );
        String projectname = (dataTable.getData( "General_Data", "Project Name" ));
        report.updateTestLog( "Verify the project creation from Template", " Project created " + projectname + " from Template successfully", Status.PASS );
    }


    public void createProjectfromsourceTemplate() {
        isElementAvailable( sourcetemplate, PAGELOADTIMEOUT );
        driver.findElement( sourcetemplate ).sendKeys( dataTable.getData( "General_Data", "Source Template" ) );
        oracleObjectRender( QUERYRESPONSE );
        driver.findElement( sourcetemplateajaxValidate ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( projectName, PAGELOADTIMEOUT );
        driver.findElement( projectName ).click();
        driver.findElement( projectname ).sendKeys( dataTable.getData( "General_Data", "Project Name" ) );
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( projectNumber, ELEMENTTIMEOUT );
        driver.findElement( projectNumber ).click();
        driver.findElement( projectNumber ).sendKeys( dataTable.getData( "General_Data", "Project Number" ) );
        oracleObjectRender( SCRIPTTIME );
        report.updateTestLog( "Verify the Project name and Project number", " Project Name and Number updated successfully", Status.PASS );
        isElementAvailable( btnsaveandcontinue, ELEMENTTIMEOUT );
        driver.findElement( btnsaveandcontinue ).click();
        oracleObjectRender( QUERYRESPONSE );
        isElementAvailable( btnsavenclose, ELEMENTTIMEOUT );
        driver.findElement( btnsavenclose ).click();
        oracleObjectRender( QUERYRESPONSE );
        isElementAvailable( btndone, ELEMENTTIMEOUT );
        driver.findElement( btndone ).click();
        oracleObjectRender( SCRIPTTIME );
        String projectname = (dataTable.getData( "General_Data", "Project Name" ));
        report.updateTestLog( "Verify the project creation from Template", " Project created " + projectname + " from Template successfully", Status.PASS );
    }


}
