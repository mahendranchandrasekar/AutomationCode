package pages;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.ScriptHelper;
import com.cognizant.framework.ExcelDataImport;
import com.cognizant.framework.Status;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.Select;

/**
 * Journals Page class
 */
public class CreateInvoicePage extends MasterPages {
	// UI Map object definitions

	// Elements

	private final By navigator = By.xpath("//a[@title='Navigator']");
	private final By invoiceLink = By.xpath("//a[contains(text(),'Invoices')]");
	private final By tasksMenu = By.xpath("//img[@title='Tasks']");
	private final By identifyingPOTextBox = By.xpath("//label[contains(text(),'Identifying PO')]/../../td[2]/input[1]");
	private final By businessUnitDrpdown = By.xpath("//label[contains(text(),'Business Unit')]/../../td[2]/span/input");
	private final By popupClose = By.xpath("//a[@title='Close']");
	private final By businessUnitDrpdownValidate = By.xpath("//li[contains(@id,'payables_invoices:0:MAnt2:1:pm1:r1:0:ap1:r2:0:ic2::su0')]");
	private final By supplierDrpdown = By.xpath("//label[contains(text(),'Supplier')]/../../td[2]/input");
	private final By supplierDrpdownValidate = By.xpath("//li[contains(@id,'payables_invoices:0:MAnt2:1:pm1:r1:0:ap1:r2:0:ic3::su0')]");
	//private final By supplierNumberText = By.xpath("//label[contains(text(),'Supplier Number')]/../../td[2]");
	private final By supplierSiteDrpdown = By.xpath("//label[contains(text(),'Supplier Site')]/../../td[2]/span/input");
	private final By supplierSiteDrpdownValidate = By.xpath("//li[contains(@id,'payables_invoices:0:MAnt2:1:pm1:r1:0:ap1:r2:0:ic4::su0')]");
	private final By identifyingPODrpdownValidate = By.xpath("//li[contains(@id,'payables_payables_invoices:0:MAnt2:1:pm1:r1:0:ap1:r2:0:ic1::su0')]");
	private final By legalEntityDrpdown = By.xpath("//label[contains(text(),'Legal Entity')]/../../td[2]/span/input");
	private final By legalEntityDrpdownValidate = By.xpath("//li[contains(@id,'payables_invoices:0:MAnt2:1:pm1:r1:0:ap1:r2:0:legalEntityNameId::su0')]");
	private final By numberTextBox = By.xpath("//label[contains(text(),'Type')]/../../../tr[2]/td/input");
	private final By amountTextBox = By.xpath("//label[contains(text(),'Type')]/../../../tr[3]/td[2]/child::*/child::*/tr[1]/td[3]/child::*/child::*/child::*/td[2]/span/input");
	//private final By dateInvoiceHeader = By.xpath("//label[contains(text(),'Payment Terms')]/../../../tr[2]/td[2]/input[1]");
	//private final By paymentTerms = By.xpath("//label[contains(text(),'Payment Terms')]/following::td[1]/span/input");
	//private final By termsDate = By.xpath("//label[contains(text(),'Terms Date')]/following::td[1]/input[1]");
	//private final By typeInvoiceHeader = By.xpath("//label[text()='Type']/following::td[1]/select");
	private final By descriptionInvoiceHeader = By.xpath("//label[text()='Description']/following::td[1]/textarea");

	private final By matchInvoiceLinesCheckBox = By.xpath("//table[@summary='Search Results']/tbody/tr[1]/td[2]/child::*/child::*/child::*/tr[1]/td[1]/child::*/child::*/child::*/input[1]");
	//private final By matchInvoiceLinesCheckBox = By.xpath("//input[contains(@id,'payables_invoices:0:MAnt2:1:pm1:r1:0:ap1:r11:1:at1:_ATp:ta1:0:sb1::content')]");
	private final By matchInvoiceLinesAmount = By.xpath("//table[@summary='Search Results']/tbody/tr[1]/td[5]/child::*/child::*/input[1]");
	private final By matchInvoiceLinesOrderedAmount = By.xpath("//table[contains(@id,'payables_payables_invoices:0:MAnt2:1:pm1:r1:0:ap1:r11:1:pgl4')]/tbody/tr[1]/td[1]/child::*/child::*/child::*/child::*/child::*/child::*/child::*/tr[2]/td[2]/child::*/child::*/child::*/td[2]");
	//private final By matchInvoiceLinesAvailableAmount = By.xpath("//table[contains(@id,'payables_payables_invoices:0:MAnt2:1:pm1:r1:0:ap1:r11:1:pgl4')]/tbody/tr[1]/td[1]/child::*/child::*/child::*/child::*/child::*/child::*/child::*/tr[3]/td[2]/child::*/child::*/child::*/td[2]");
	private final By matchInvoiceLinesApplyButton = By.xpath("//button[text()='App']");
	private final By matchInvoiceLinesOKButton = By.xpath("//button[text()='App']/following::button[1]");
	private final By linesDistributionsButton = By.xpath("//img[@title='Export to Excel']/following::tr[2]/td[1]/table/tbody/tr/td[3]/child::*/child::*/span");
	private final By linesAddDistributions = By.xpath("//div[text()='Manage Distributions']/following::tr[2]/td[2]/div/div[1]/div[1]/table/tbody/tr/td[1]");
	private final By linesAmountDistributions = By.xpath("//table[@summary='Manage Distributions']/tbody/tr/td[5]/span/span/input");
	private final By linesCombinationDistributions = By.xpath("//table[@summary='Manage Distributions']/tbody/tr/td[6]/div/table/tbody/tr/td[1]/span/span/div/table/tbody/tr/td[1]/span/input");
	private final By linesDistributionsSaveAndCloseButton = By.xpath("//button[contains(text(),'Save and Close')]");

	private final By matchInvoiceReceiptType = By.xpath("//label[text()='Charge Amount']/../../../tr[2]/td[2]/select");
	private final By matchInvoiceReceiptChargeAmount = By.xpath("//label[text()='Charge Amount']/following::td[1]/input");
	private final By matchInvoiceReceiptChargeDistribution = By.xpath("//label[text()='Charge Distribution']/following::td[1]/table/tbody/tr[1]/td[1]/span/input");
	private final By matchInvoiceReceiptSupplier = By.xpath("//label[text()='Purchase Order Line']/../../../tr[1]/td[2]/table/tbody/tr/td[2]/child::*/child::*/tr[1]/td[1]/child::*/span[1]/input");
	private final By matchInvoiceReceiptSupplierSite = By.xpath("//label[text()='Purchase Order Line']/../../../tr[2]/td[2]/table/tbody/tr/td[2]/child::*/child::*/tr[1]/td[1]/child::*/span[1]/input");
	private final By matchInvoiceReceiptSupplierSiteArrow = By.xpath("//label[text()='Purchase Order Line']/../../../tr[2]/td[2]/table/tbody/tr/td[2]/child::*/child::*/tr[1]/td[1]/child::*/span/span/span/a");
	private final By matchInvoiceReceiptSupplierSiteValidate = By.xpath("//span[contains(text(),'DIRECSO529DF')]");
	private final By matchInvoiceReceiptPurchaseOrder = By.xpath("//label[text()='Purchase Order Line']/../../../tr[3]/td[2]/table/tbody/tr/td[2]/child::*/child::*/tr[1]/td[1]/child::*/span[1]/input");
	private final By searchButton= By.xpath("//button[text()='Search']");
    private final By matchInvoiceReceiptCheckBox = By.xpath("//table[@summary='Match Invoice to Receipt Charges']/tbody/tr[1]/td[2]/child::*/child::*/span[1]/span[1]/span[1]/input");
    private final By matchInvoiceReceiptAmount = By.xpath("//table[@summary='Match Invoice to Receipt Charges']/tbody/tr[1]/td[3]/child::*/child::*/input[1]");


	private final By showMoreLink = By.xpath("//h1[text()='Invoice Header']/../../../../../child::*/tr[1]/td[4]/table/child::*/child::*/td[2]/a");
	private final By additionalInfoTab = By.xpath("//h1[text()='Invoice Header']/../../../../../../following-sibling::div/child::*/div[2]/div[1]/div[2]/child::*/child::*/div[4]/div[1]/a");
	private final By generalTab = By.xpath("//h1[text()='Invoice Header']/../../../../../../following-sibling::div/child::*/div[2]/div[1]/div[2]/child::*/child::*/div[1]/div[1]/a");
	private final By contextValueDropdown = By.xpath("//label[text()='Context Value']/following::td[1]/select");
	private final By brandDropdown = By.xpath("//label[text()='Brand']/following::td[1]/select");
	private final By stationeryCodeDropdown = By.xpath("//label[text()='Stationery Code']/following::td[1]/select");
	private final By payeeTextBox = By.xpath("//label[text()='Payee']/following::td[1]/input");
	private final By addressLine1TextBox = By.xpath("//label[text()='Address Line 1']/following::td[1]/input");
	private final By townTextBox = By.xpath("//label[text()='Town']/following::td[1]/input");
	private final By postalCodeTextBox = By.xpath("//label[text()='Postal Code']/following::td[1]/input");


	private final By linesNavigateArrow = By.xpath("//a[@title='Expand Lines']");
	private final By linesSectionDropDown = By.xpath("//a[@title='Expand Lines']/../../td[4]/child::*/child::*/tr[1]/td[3]/child::*/select");
	private final By linesSectionNextButton = By.xpath("//a[@title='Expand Lines']/../../td[4]/child::*/child::*/tr[1]/td[5]/child::*/div[2]/a");
	private final By taxNavigateArrow = By.xpath("//a[@title='Expand Taxes']");
	//private final By totalsNavigateArrow = By.xpath("//a[@title='Expand Totals']");
	private final By warningMessageForHold = By.xpath("//span[contains(text(),'invoice amount exceeds the invoice limit')]");
	private final By warningMessageForOverbill = By.xpath("//span[contains(text(),'Completing this match will result in an overbill')]");
	private final By popupOKButton = By.xpath("//button[contains(@id,'msgDlg::cancel')]");
	//private final By taxRateName = By.xpath("//table[@summary='Transaction Tax']/tbody/tr[1]/td[2]/span");
	private final By taxRate = By.xpath("//table[@summary='Transaction Tax']/tbody/tr[1]/td[3]/span");
	//private final By taxAmount = By.xpath("//table[@summary='Transaction Tax']/tbody/tr[1]/td[4]/span");
	//private final By taxTotalAmount = By.xpath("//table[@summary='Transaction Tax']/../../div[3]/child::*/tbody/tr[2]/td[4]/table/tbody/tr[1]/td[2]/span");
	private final By validatedLink = By.xpath("//a[contains(text(),'Validated')]");
	//private final By saveButton = By.xpath("//span[text()='Save']");
	private final By saveAndCloseButton = By.xpath("//span[text()='ave and Close']");
	private final By saveAndCloseButtonOnhold = By.xpath("//button[text()='Save and Close']");

	//private final By saveAndCreateNextButton = By.xpath("//span[text()='Save and Create Next']");
	//private final By cancelButton = By.xpath("//span[text()='ancel']");
	private final By totalsSectionItems = By.xpath("//a[@title='Collapse Totals']/../../../../../../div[2]/child::*/child::*/child::*/child::*/child::*/child::*/child::*/child::*/child::*/td[1]/child::*/child::*/tr[1]/td[1]/div/div[2]");
	private final By totalsSectionTax = By.xpath("//a[@title='Collapse Totals']/../../../../../../div[2]/child::*/child::*/child::*/child::*/child::*/child::*/child::*/child::*/child::*/td[4]/child::*/child::*/tr[1]/td[1]/div/div[2]");
	private final By totalsSectionTotal = By.xpath("//a[@title='Collapse Totals']/../../../../../../div[2]/child::*/child::*/child::*/child::*/child::*/child::*/child::*/child::*/child::*/td[6]/child::*/child::*/tr[1]/td[1]/div/div[2]/child::*/child::*/tr[1]/td[3]/span");
	private final By totalsSectionTotalBalanceValIcon = By.xpath("//a[@title='Collapse Totals']/../../../../../../div[2]/child::*/child::*/child::*/child::*/child::*/child::*/child::*/child::*/child::*/td[6]/child::*/child::*/tr[1]/td[1]/div/div[2]/child::*/child::*/tr[1]/td[2]/img");
	private final By totalsSectionDue = By.xpath("//a[@title='Collapse Totals']/../../../../../../div[2]/child::*/child::*/child::*/child::*/child::*/child::*/child::*/child::*/child::*/td[6]/child::*/child::*/child::*/child::*/child::*/div[5]/span");

	private final By commonErrorMessage = By.xpath("//td[text()='Error: A value is required.']");
	private final By commonWarningMessage = By.xpath("//div[contains(text(),'Example format')]");
	private final By commonErrorMessageClose = By.xpath("//div[@class='AFNoteWindowConeBL']");
	private final By commonErrorInvalidMessage = By.xpath("//td[contains(text(),'Error: Invalid value:')]");


	private final By invoiceActionsDrpdown = By.xpath("//a[text()='Invoice Actions']");
	private final By calculateTaxActionField = By.xpath("//td[text()='Calculate Tax']");
	private final By validateActionField = By.xpath("//td[text()='Validate']");
	private final By approvalActionField = By.xpath("//td[text()='Approval']");
	private final By viewApprovalNotificationField = By.xpath("//td[text()='View Approval and Notification History']");
	private final By approvalNotificationTitle = By.xpath("//div[text()='Approval and Notification History']");
	private final By approvalNotificationView = By.xpath("//div[@title='View' and contains(@id,'payables_invoices:0:MAnt2:1:pm1:r1:0:ap1:r1:1:at1:_ATp:_vw')]/child::*/table/child::*/tr[1]");
	private final By approvalNotificationViewSort = By.xpath("//table[contains(@id,'payables_invoices:0:MAnt2:1:pm1:r1:0:ap1:r1:1:at1:_ATp:_vw::ScrollContent')]/tbody/tr[9]/td[2]");
	private final By approvalNotificationViewSortAdvanced = By.xpath("//tr[contains(@id,'payables_invoices:0:MAnt2:1:pm1:r1:0:ap1:r1:1:at1:_ATp:_srtAvd')]/td[2]");
	private final By approvalNotificationViewSortBy = By.xpath("//table[contains(@id,'payables_invoices:0:MAnt2:1:pm1:r1:0:ap1:r1:1:at1:_ATp:_srtDlgC0')]/tbody/tr[2]/td[1]/select");
	private final By approvalNotificationViewOKButton = By.xpath("//td[contains(@id,'payables_invoices:0:MAnt2:1:pm1:r1:0:ap1:r1:1:at1:_ATp:sortDlg::_fcc')]/button[1]");
	private final By approvalNotificationViewSortByDescending = By.xpath("//table[contains(@id,'payables_invoices:0:MAnt2:1:pm1:r1:0:ap1:r1:1:at1:_ATp:_srtDlgC0')]/../../../../../../../../../../../td[2]/child::*/child::*/tr[1]/td[2]/child::*/div[2]/child::*/input");

    private final By approvalNotificationViewFirstRecord = By.xpath("//table[@summary='Approval and Notification History']/tbody/tr[1]");
    //private final By approvalNotificationViewAction = By.xpath("//table[@summary='Approval and Notification History']/tbody/tr[1]/td[3]/child::*");
    private final By approvalNotificationDoneButton = By.xpath("//button[contains(@id,'payables_invoices:0:MAnt2:1:pm1:r1:0:ap1:cb13')]");

	private final By approvalInitiateActionField = By.xpath("//td[text()='Initiate']");
	private final By revalidationField = By.xpath("//a[text()='Needs revalidation']");
	//private final By invoiceSummaryTableHdr = By.xpath("//div[text()='Invoice Summary']");
	private final By invoiceSummaryApprovalValidation = By.xpath("//table[@summary='Status']/tbody/tr[2]/td[2]/child::*/child::*/img[1]");
	private final By invoiceSummaryOnholdValidation = By.xpath("//table[@summary='Holds']/tbody/tr[5]/td[2]/child::*/child::*/img[1]");
	private final By invoiceSummaryOnholdNumber = By.xpath("//table[@summary='Holds']/tbody/tr[5]/td[2]/child::*/child::*/a");
	private final By invoiceSummaryOnholdNameDropdwn = By.xpath("//table[@summary='Manage Holds']/tbody/tr[1]/td[7]/child::*/child::*/select");
	//private final By invoiceSummaryPaymentsValidation = By.xpath("//table[@summary='Status']/tbody/tr[4]/td[2]/child::*/child::*/img[2]");
	private final By invoiceSummaryPopupClose = By.xpath("//a[@title='Close' and contains(@id,'invoices:0:MAnt2:1:pm1:r1:0:ap1:d37::close')]");


	private final By amountLine1 = By.xpath("//table[@summary='Invoice Lines']/tbody/tr[1]/td[4]/child::*/child::*/input");
	private final By distributionSetLine1 = By.xpath("//table[@summary='Invoice Lines']/tbody/tr[1]/td[5]/child::*/child::*/tbody/tr/td[1]/child::*/child::*/child::*/input");
	//private final By shiptoLocationLine1 = By.xpath("//table[@summary='Invoice Lines']/tbody/tr[1]/td[5]/child::*/child::*/tbody/tr/td[7]/child::*/span/span/input");
	//private final By accountingDateLine1 = By.xpath("//table[@summary='Invoice Lines']/tbody/tr[1]/td[5]/child::*/child::*/tbody/tr/td[3]/child::*/span/input[1]");
	private final By distributionSetLine1Validate = By.xpath("//li[contains(@id,'invoices:0:MAnt2:1:pm1:r1:0:ap1:at2:_ATp:ta2:0:so13::su0')]");
	//private final By projectLink = By.xpath("//a[contains(text(),'Project')]");
	//private final By projectNumberLine1 = By.xpath("//table[@summary='Invoice Lines']/tbody/tr[1]/td[5]/child::*/child::*/tbody/tr/td[12]/child::*/child::*/input");
	//private final By taskNumberLine1 = By.xpath("//table[@summary='Invoice Lines']/tbody/tr[1]/td[5]/child::*/child::*/tbody/tr/td[13]/child::*/child::*/span/input");
	//private final By expenditureTypeLine1 = By.xpath("//table[@summary='Invoice Lines']/tbody/tr[1]/td[5]/child::*/child::*/tbody/tr/td[15]/child::*/child::*/span/input");
	//private final By expenditureOrganizationLine1 = By.xpath("//table[@summary='Invoice Lines']/tbody/tr[1]/td[5]/child::*/child::*/tbody/tr/td[16]/child::*/child::*/span/input");


	String invoiceLinesDropdownData = dataTable.getData(ExcelDataImport.GeneralData, "InvoiceLinesDropdown");
	String V42InvoiceFlagData = dataTable.getData(ExcelDataImport.GeneralData, "V42InvoiceFlag");

	private static String invoiceNumber = "";
	public static String businessUnit = "";
	public static String supplierName = "";

	//Page Sync Config

	// page loading time
	public static final int PAGELOADTIMEOUT = 90;
	// individual element load time
	public static final int ELEMENTTIMEOUT = 60;
	// Oracle query response
	public static final long QUERYRESPONSE = 15;
	// object render script
	public static final long SCRIPTTIME = 5;

	/**
	 * Constructor to initialize the page
	 *
	 * @param scriptHelper The {@link ScriptHelper} object passed from the
	 *                     {@link DriverScript}b  n '/fg .+
	 */
	public CreateInvoicePage(ScriptHelper scriptHelper) {
		super(scriptHelper);
		isElementAvailable(navigator, ELEMENTTIMEOUT);
	}


	public void journalNavigation() {
		isElementAvailable(navigator, ELEMENTTIMEOUT);
		driver.findElement(navigator).click();
	}

	public void clickOnMainInvoiceLink() {
		isElementAvailable(invoiceLink, ELEMENTTIMEOUT);
		driver.findElement(invoiceLink).click();
	}

	public void clickOnTaskMenu() {
		isElementAvailable(tasksMenu, ELEMENTTIMEOUT);
		driver.findElement(tasksMenu).click();
	}


	public void EnterNonPODetailsForCreateInvoiceHeader() {
		this.enterNonPOValues();
		oracleObjectRender(SCRIPTTIME);
		isElementAvailable(supplierSiteDrpdown, ELEMENTTIMEOUT);
		driver.findElement(supplierSiteDrpdown).clear();
		oracleObjectRender(SCRIPTTIME);
		driver.findElement(supplierSiteDrpdown).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, ExcelDataImport.SupplierSite));
		isElementAvailable(supplierSiteDrpdownValidate, ELEMENTTIMEOUT);
		driver.findElement(supplierSiteDrpdownValidate).click();
		oracleObjectRender(QUERYRESPONSE);
		isElementAvailable(legalEntityDrpdown, ELEMENTTIMEOUT);
		driver.findElement(legalEntityDrpdown).clear();
		oracleObjectRender(SCRIPTTIME);
		driver.findElement(legalEntityDrpdown).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "LegalEntity"));
		isElementAvailable(legalEntityDrpdownValidate, ELEMENTTIMEOUT);
		driver.findElement(legalEntityDrpdownValidate).click();
		oracleObjectRender(QUERYRESPONSE);
		this.V42InvoiceFlag(dataTable.getData(ExcelDataImport.GeneralData, "V42InvoiceFlag"));
		CreateInvoicePage.invoiceNumber = driver.findElement(numberTextBox).getAttribute(ExcelDataImport.value);
		CreateInvoicePage.businessUnit = driver.findElement(businessUnitDrpdown).getAttribute(ExcelDataImport.value);
		CreateInvoicePage.supplierName = driver.findElement(supplierDrpdown).getAttribute(ExcelDataImport.value);
	}

	public void enterPODetailsForCreateInvoiceHeader(String purchaseOrderNumber) {
		isElementAvailable(identifyingPOTextBox, PAGELOADTIMEOUT);
		driver.findElement(identifyingPOTextBox).sendKeys(purchaseOrderNumber);
		isElementAvailable(identifyingPODrpdownValidate, ELEMENTTIMEOUT);
		driver.findElement(identifyingPODrpdownValidate).click();
		oracleObjectRender(QUERYRESPONSE);
		isElementAvailable(supplierSiteDrpdown, ELEMENTTIMEOUT);
		driver.findElement(supplierSiteDrpdown).clear();
		oracleObjectRender(QUERYRESPONSE);
		driver.findElement(supplierSiteDrpdown).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "SupplierSite"));
		isElementAvailable(supplierSiteDrpdownValidate, ELEMENTTIMEOUT);
		driver.findElement(supplierSiteDrpdownValidate).click();
		this.V42InvoiceFlag(V42InvoiceFlagData);
		CreateInvoicePage.invoiceNumber = driver.findElement(numberTextBox).getAttribute(ExcelDataImport.value);
		CreateInvoicePage.businessUnit = driver.findElement(businessUnitDrpdown).getAttribute(ExcelDataImport.value);
		CreateInvoicePage.supplierName = driver.findElement(supplierDrpdown).getAttribute(ExcelDataImport.value);
		oracleObjectRender(SCRIPTTIME);
		this.invoiceLineMatching(invoiceLinesDropdownData);
	}

	public void EnterDetailsForCreateInvoiceLines() {
		isElementAvailable(linesNavigateArrow, ELEMENTTIMEOUT);
		driver.findElement(linesNavigateArrow).click();
		oracleObjectRender(QUERYRESPONSE);
		isElementAvailable(amountLine1, ELEMENTTIMEOUT);
		driver.findElement(amountLine1).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, ExcelDataImport.LinesAmount));
		this.distributionsFlow(dataTable.getData(ExcelDataImport.GeneralData, "BusinessUnit"));
	}

	private void distributionsFlow(String fieldValue) {
		try {
			switch (fieldValue.toLowerCase()) {
				case "dlg uk":
					isElementAvailable(linesDistributionsButton, ELEMENTTIMEOUT);
					driver.findElement(linesDistributionsButton).click();
					isElementAvailable(linesAddDistributions, PAGELOADTIMEOUT);
					driver.findElement(linesAddDistributions).click();
					isElementAvailable(linesAmountDistributions, PAGELOADTIMEOUT);
					driver.findElement(linesAmountDistributions).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, ExcelDataImport.LinesAmount));
					isElementAvailable(linesCombinationDistributions, ELEMENTTIMEOUT);
					driver.findElement(linesCombinationDistributions).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "ManageDistributionCombination"));
					oracleObjectRender(SCRIPTTIME);
					report.updateTestLog("Invoice Lines Section for Business unit as DLG UK", "The user should be able to provide valid data in Invoice Lines Section", Status.PASS);
					isElementAvailable(linesDistributionsSaveAndCloseButton, ELEMENTTIMEOUT);
					driver.findElement(linesDistributionsSaveAndCloseButton).click();
					oracleObjectRender(SCRIPTTIME); oracleObjectRender(SCRIPTTIME);
					break;

				case "dlg uk cid":
					isElementAvailable(distributionSetLine1, ELEMENTTIMEOUT);
					driver.findElement(distributionSetLine1).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "DistributionSet"));
					oracleObjectRender(SCRIPTTIME);
					isElementAvailable(distributionSetLine1Validate, ELEMENTTIMEOUT);
					driver.findElement(distributionSetLine1Validate).click();
					oracleObjectRender(QUERYRESPONSE);
					report.updateTestLog("Invoice Lines Section for Business unit as DLG UK CID", "The user should be able to provide valid data in Invoice Lines Section", Status.PASS);
					break;

				default:
					break;
			}
		} catch (Exception e) {
			report.updateTestLog("Invoice Lines Section", "The user is not able to provide valid data in Invoice Lines Section", Status.FAIL);
		}
	}

	public void EnterDetailsForCreateInvoiceTaxes() {
        oracleObjectRender(SCRIPTTIME);oracleObjectRender(SCRIPTTIME);
		isElementAvailable(taxNavigateArrow, ELEMENTTIMEOUT);
		driver.findElement(taxNavigateArrow).click();
		oracleObjectRender(QUERYRESPONSE);
		try {
			if (driver.findElement(warningMessageForHold).isDisplayed()) {
				report.updateTestLog("Warning  Message to OnHold", "This  Supplier has exceeded the limit as against the Total amount in Invoice Header", Status.PASS);
				oracleObjectRender(SCRIPTTIME);
                isElementAvailable(popupOKButton, ELEMENTTIMEOUT);
				driver.findElement(popupOKButton).click();
				oracleObjectRender(QUERYRESPONSE);
			}
		} catch (Exception e) {
			report.updateTestLog("No  Warning Message to OnHold", "The  user has calculated the taxes and provided total Amount in Invoice Header", Status.PASS);
		}
		oracleObjectRender(QUERYRESPONSE);
		Assert.assertEquals(driver.findElement(taxRate).getAttribute(ExcelDataImport.innerHTML), (dataTable.getData(ExcelDataImport.GeneralData, "TaxRate")));
		report.updateTestLog("Invoice Taxes Section", "The user should be able to verify the Tax Rate and Tax amount in this section", Status.PASS);
	}

	public void EnterDetailsForCreateInvoiceTotals() {
		oracleObjectRender(QUERYRESPONSE);
		scrollPageDown();
		oracleObjectRender(SCRIPTTIME);
		if (driver.findElement(totalsSectionTotalBalanceValIcon).getAttribute(ExcelDataImport.title).equals("In Balance ")) {
			Assert.assertEquals(driver.findElement(totalsSectionItems).getAttribute(ExcelDataImport.innerHTML), (dataTable.getData(ExcelDataImport.GeneralData, "LinesAmount")));
			Assert.assertEquals(driver.findElement(totalsSectionTax).getAttribute(ExcelDataImport.innerHTML), (dataTable.getData(ExcelDataImport.GeneralData, "TotalTaxAmount")));
			Assert.assertEquals(driver.findElement(totalsSectionTotal).getAttribute(ExcelDataImport.innerHTML), (dataTable.getData(ExcelDataImport.GeneralData, ExcelDataImport.HDRAmount)));
			Assert.assertEquals(driver.findElement(totalsSectionDue).getAttribute(ExcelDataImport.innerHTML), (dataTable.getData(ExcelDataImport.GeneralData, ExcelDataImport.HDRAmount)));
			Assert.assertEquals(driver.findElement(totalsSectionTotalBalanceValIcon).getAttribute(ExcelDataImport.title), (dataTable.getData(ExcelDataImport.GeneralData, "TaxCalcualateValidation")));
			report.updateTestLog("Invoice  Totals Section", "The user should be able to verify the Items, Tax, Total amount and Due Amount in this section", Status.PASS);
		} else if (driver.findElement(totalsSectionTotalBalanceValIcon).getAttribute(ExcelDataImport.title).equals("Out of Balance ")) {
			report.updateTestLog("Invoice  Totals Section", "ReValidation is required for tax and total amount", Status.PASS);
		}
		oracleObjectRender(SCRIPTTIME);
		isElementAvailable(invoiceActionsDrpdown, ELEMENTTIMEOUT);
		driver.findElement(invoiceActionsDrpdown).click();
		oracleObjectRender(SCRIPTTIME);
		isElementAvailable(calculateTaxActionField, ELEMENTTIMEOUT);
		driver.findElement(calculateTaxActionField).click();
		oracleObjectRender(QUERYRESPONSE);
		isElementAvailable(invoiceActionsDrpdown, PAGELOADTIMEOUT);
		driver.findElement(invoiceActionsDrpdown).click();
		oracleObjectRender(SCRIPTTIME);
		isElementAvailable(validateActionField, ELEMENTTIMEOUT);
		driver.findElement(validateActionField).click();
		oracleObjectRender(QUERYRESPONSE);
	}

	public void EnterDetailsForPOCreateInvoiceTotals() {
		oracleObjectRender(QUERYRESPONSE);
		scrollPageDown();
		oracleObjectRender(SCRIPTTIME);
		if (driver.findElement(totalsSectionTotalBalanceValIcon).getAttribute(ExcelDataImport.title).equals("In Balance ")) {
			Assert.assertEquals(driver.findElement(totalsSectionItems).getAttribute(ExcelDataImport.innerHTML), (dataTable.getData(ExcelDataImport.GeneralData, "LinesAmount")));
			Assert.assertEquals(driver.findElement(totalsSectionTax).getAttribute(ExcelDataImport.innerHTML), (dataTable.getData(ExcelDataImport.GeneralData, "TotalTaxAmount")));
			Assert.assertEquals(driver.findElement(totalsSectionTotal).getAttribute(ExcelDataImport.innerHTML), (dataTable.getData(ExcelDataImport.GeneralData, ExcelDataImport.HDRAmount)));
			Assert.assertEquals(driver.findElement(totalsSectionDue).getAttribute(ExcelDataImport.innerHTML), (dataTable.getData(ExcelDataImport.GeneralData, ExcelDataImport.HDRAmount)));
			Assert.assertEquals(driver.findElement(totalsSectionTotalBalanceValIcon).getAttribute(ExcelDataImport.title), (dataTable.getData(ExcelDataImport.GeneralData, "TaxCalcualateValidation")));
			report.updateTestLog("Invoice Totals Section", "The user should be able to verify the Items, Tax, Total amount and Due Amount in this section", Status.PASS);
		} else if (driver.findElement(totalsSectionTotalBalanceValIcon).getAttribute(ExcelDataImport.title).equals("Out of Balance ")) {
			report.updateTestLog("Invoice Totals Section", "ReValidation is required for tax and total amount", Status.PASS);
		}
		oracleObjectRender(SCRIPTTIME);
		String TotalAmountData = driver.findElement(totalsSectionTotal).getAttribute(ExcelDataImport.innerHTML);
		oracleObjectRender(SCRIPTTIME);
		isElementAvailable(amountTextBox, ELEMENTTIMEOUT);
		driver.findElement(amountTextBox).clear();
		oracleObjectRender(SCRIPTTIME);
		driver.findElement(amountTextBox).sendKeys(Keys.TAB);
		driver.findElement(amountTextBox).click();

		try {
			if (driver.findElement(commonErrorMessage).isDisplayed()) {
				report.updateTestLog("Common Error Dialog box", "The user able to verify Common Error Dialog is opened", Status.PASS);
				isElementAvailable(commonErrorMessageClose, ELEMENTTIMEOUT);
				driver.findElement(commonErrorMessageClose).click();
				oracleObjectRender(SCRIPTTIME);
				driver.findElement(amountTextBox).sendKeys(TotalAmountData);
			} else if (driver.findElement(commonWarningMessage).isDisplayed()) {
				report.updateTestLog("Common Warning Dialog box", "The user able to verify Common Warning Dialog is opened", Status.PASS);
				isElementAvailable(commonErrorMessageClose, ELEMENTTIMEOUT);
				driver.findElement(commonErrorMessageClose).click();
				oracleObjectRender(SCRIPTTIME);
				driver.findElement(amountTextBox).sendKeys(TotalAmountData);
			}
		} catch (Exception e) {
			report.updateTestLog("No Common Error Dialog box", "No Common Error Dialog box is displayed", Status.PASS);
		}

		oracleObjectRender(SCRIPTTIME);
		driver.findElement(amountTextBox).sendKeys(Keys.TAB);
		oracleObjectRender(SCRIPTTIME);
		isElementAvailable(invoiceActionsDrpdown, ELEMENTTIMEOUT);
		driver.findElement(invoiceActionsDrpdown).click();
		oracleObjectRender(SCRIPTTIME);
		isElementAvailable(calculateTaxActionField, ELEMENTTIMEOUT);
		driver.findElement(calculateTaxActionField).click();
		oracleObjectRender(QUERYRESPONSE);
		try {
			if (driver.findElement(warningMessageForHold).isDisplayed()) {
				report.updateTestLog("Warning Message to OnHold", "This Supplier has exceeded the limit as against the Total amount in Invoice Header", Status.PASS);
				oracleObjectRender(SCRIPTTIME);
                isElementAvailable(popupOKButton, ELEMENTTIMEOUT);
				driver.findElement(popupOKButton).click();
				oracleObjectRender(QUERYRESPONSE);
			}
		} catch (Exception e) {
			report.updateTestLog("No Warning Message to OnHold", "The user has calculated the taxes and provided total Amount in Invoice Header", Status.PASS);
		}

		oracleObjectRender(SCRIPTTIME);
		isElementAvailable(invoiceActionsDrpdown, PAGELOADTIMEOUT);
		driver.findElement(invoiceActionsDrpdown).click();
		oracleObjectRender(SCRIPTTIME);
		isElementAvailable(validateActionField, ELEMENTTIMEOUT);
		driver.findElement(validateActionField).click();
		oracleObjectRender(QUERYRESPONSE);
	}

	public void valdidateInvoiceSummary() {

		try {
			if (driver.findElement(revalidationField).isDisplayed()) {
				report.updateTestLog("Calculated Tax - Validation", "The user should be able to verify the Re-Validated Link is displayed in the application due to OnHold", Status.PASS);
				oracleObjectRender(QUERYRESPONSE);
				isElementAvailable(revalidationField, ELEMENTTIMEOUT);
				driver.findElement(revalidationField).click();
				oracleObjectRender(SCRIPTTIME);oracleObjectRender(SCRIPTTIME);
				isElementAvailable(invoiceSummaryOnholdValidation, PAGELOADTIMEOUT);
				if (driver.findElement(invoiceSummaryOnholdValidation).getAttribute("title").equals("Holds")) {
					report.updateTestLog("Invoice Onhold Process", "The Supplier has exceeded the limit as against the Total amount in Invoice Header", Status.PASS);
					isElementAvailable(invoiceSummaryOnholdNumber, ELEMENTTIMEOUT);
					driver.findElement(invoiceSummaryOnholdNumber).click();
					oracleObjectRender(SCRIPTTIME);
					isElementAvailable(invoiceSummaryOnholdNameDropdwn, PAGELOADTIMEOUT);
					Select selectDropDown = new Select(driver.findElement(invoiceSummaryOnholdNameDropdwn));
					selectDropDown.selectByVisibleText(dataTable.getData(ExcelDataImport.GeneralData, "InvoiceStatus"));
					isElementAvailable(saveAndCloseButtonOnhold, ELEMENTTIMEOUT);
					driver.findElement(saveAndCloseButtonOnhold).click();
					oracleObjectRender(SCRIPTTIME);
					isElementAvailable(validatedLink, PAGELOADTIMEOUT);
					Assert.assertEquals(driver.findElement(validatedLink).getAttribute("innerHTML"), (dataTable.getData(ExcelDataImport.GeneralData, "InvoiceStatus")));
				} else {
				    report.updateTestLog("Invoice Onhold Process", "The Supplier has available limit and it is not required for onhold release", Status.PASS);
                }
			}
		} catch (Exception e) {
			report.updateTestLog("Calculated Tax - Validation", "The user should be able to verify the Validated Link is displayed in the application", Status.PASS);
		}
        oracleObjectRender(QUERYRESPONSE);
		driver.findElement(validatedLink).isDisplayed();
		isElementAvailable(validatedLink, ELEMENTTIMEOUT);
		driver.findElement(validatedLink).click();
		oracleObjectRender(QUERYRESPONSE);
		if (driver.findElement(invoiceSummaryApprovalValidation).getAttribute("title").equals("Status")) {
			report.updateTestLog("Invoice Approval Process", "The user does not have Approval Rights for completing this transaction", Status.PASS);
			isElementAvailable(invoiceSummaryPopupClose, ELEMENTTIMEOUT);
			driver.findElement(invoiceSummaryPopupClose).click();
			oracleObjectRender(QUERYRESPONSE);
			isElementAvailable(invoiceActionsDrpdown, PAGELOADTIMEOUT);
			driver.findElement(invoiceActionsDrpdown).click();
			oracleObjectRender(SCRIPTTIME);
			isElementAvailable(approvalActionField, ELEMENTTIMEOUT);
			driver.findElement(approvalActionField).click();
			oracleObjectRender(SCRIPTTIME);
			isElementAvailable(approvalInitiateActionField, ELEMENTTIMEOUT);
			driver.findElement(approvalInitiateActionField).click();
			oracleObjectRender(SCRIPTTIME);
			isElementAvailable(invoiceActionsDrpdown, ELEMENTTIMEOUT);
			driver.findElement(invoiceActionsDrpdown).click();
			oracleObjectRender(SCRIPTTIME);
			isElementAvailable(viewApprovalNotificationField, ELEMENTTIMEOUT);
			driver.findElement(viewApprovalNotificationField).click();
			oracleObjectRender(QUERYRESPONSE);
			try{
				isElementAvailable(approvalNotificationTitle, PAGELOADTIMEOUT);
				driver.findElement(approvalNotificationTitle).isDisplayed();
				isElementAvailable(approvalNotificationView, ELEMENTTIMEOUT);
				driver.findElement(approvalNotificationView).click();
				oracleObjectRender(SCRIPTTIME);
				isElementAvailable(approvalNotificationViewSort, ELEMENTTIMEOUT);
				driver.findElement(approvalNotificationViewSort).click();
				oracleObjectRender(SCRIPTTIME);
				isElementAvailable(approvalNotificationViewSortAdvanced, ELEMENTTIMEOUT);
				driver.findElement(approvalNotificationViewSortAdvanced).click();
				oracleObjectRender(SCRIPTTIME);
				isElementAvailable(approvalNotificationViewSortBy, PAGELOADTIMEOUT);
				Select selectDropDown = new Select(driver.findElement(approvalNotificationViewSortBy));
				selectDropDown.selectByVisibleText(dataTable.getData(ExcelDataImport.GeneralData, "SortBy"));
				oracleObjectRender(QUERYRESPONSE);
				isElementAvailable(approvalNotificationViewSortByDescending, ELEMENTTIMEOUT);
				mouseOverAndClick(approvalNotificationViewSortByDescending);
				//driver.findElement(approvalNotificationViewSortByDescending).click();
				oracleObjectRender(SCRIPTTIME);
				isElementAvailable(approvalNotificationViewOKButton, ELEMENTTIMEOUT);
				driver.findElement(approvalNotificationViewOKButton).click();
                oracleObjectRender(SCRIPTTIME);
                isElementAvailable(approvalNotificationViewFirstRecord, ELEMENTTIMEOUT);
                driver.findElement(approvalNotificationViewFirstRecord).isDisplayed();
				report.updateTestLog( "Approval and Notification History", "Invoice Number - " + invoiceNumber + " displayed Successfully", Status.PASS );
				oracleObjectRender(SCRIPTTIME);
				isElementAvailable(approvalNotificationDoneButton, ELEMENTTIMEOUT);
                driver.findElement(approvalNotificationDoneButton).click();
                oracleObjectRender(SCRIPTTIME);

			} catch(Exception e) {
				report.updateTestLog("Approval and Notification History", "The user is not able to verify the Approval and Notification History", Status.FAIL);
			}
			oracleObjectRender(SCRIPTTIME);
			isElementAvailable(saveAndCloseButton, PAGELOADTIMEOUT);
			driver.findElement(saveAndCloseButton).click();
		}
	}


	private void V42InvoiceFlag(String V42InvoiceFlagData) {
		try {
			switch (V42InvoiceFlagData.toLowerCase()) {
				case "yes":
					isElementAvailable(showMoreLink, ELEMENTTIMEOUT);
					driver.findElement(showMoreLink).click();
					isElementAvailable(additionalInfoTab, PAGELOADTIMEOUT);
					driver.findElement(additionalInfoTab).click();
					if (dataTable.getData(ExcelDataImport.GeneralData, ExcelDataImport.ContextValue).equals("V42 One Off Cheque")) {
						isElementAvailable(contextValueDropdown, ELEMENTTIMEOUT);
						Select selectDropDownContextValue = new Select(driver.findElement(contextValueDropdown));
						selectDropDownContextValue.selectByVisibleText(dataTable.getData(ExcelDataImport.GeneralData, ExcelDataImport.ContextValue));
						oracleObjectRender(SCRIPTTIME);
						isElementAvailable(brandDropdown, ELEMENTTIMEOUT);
						Select selectDropDownBrand = new Select(driver.findElement(brandDropdown));
						selectDropDownBrand.selectByVisibleText(dataTable.getData(ExcelDataImport.GeneralData, "Brand"));
						oracleObjectRender(SCRIPTTIME);
						isElementAvailable(stationeryCodeDropdown, ELEMENTTIMEOUT);
						Select selectDropDownStationery = new Select(driver.findElement(stationeryCodeDropdown));
						selectDropDownStationery.selectByVisibleText(dataTable.getData(ExcelDataImport.GeneralData, "StationeryCode"));
						oracleObjectRender(SCRIPTTIME);
						isElementAvailable(payeeTextBox, ELEMENTTIMEOUT);
						driver.findElement(payeeTextBox).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "Payee"));
						isElementAvailable(addressLine1TextBox, ELEMENTTIMEOUT);
						driver.findElement(addressLine1TextBox).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "AddressLine1"));
						isElementAvailable(townTextBox, ELEMENTTIMEOUT);
						driver.findElement(townTextBox).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "Town"));
						isElementAvailable(postalCodeTextBox, ELEMENTTIMEOUT);
						driver.findElement(postalCodeTextBox).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "PostalCode"));
						report.updateTestLog("Invoice Creation Additonal Info Tab - V42 One OFf Cheque", "The user is required to provide an additional Information for V42 Invoice Creation", Status.PASS);
					} else if (dataTable.getData(ExcelDataImport.GeneralData, "ContextValue").equals("V42 Preferred")) {
						isElementAvailable(contextValueDropdown, ELEMENTTIMEOUT);
						Select selectDropDownContextValue = new Select(driver.findElement(contextValueDropdown));
						selectDropDownContextValue.selectByVisibleText(dataTable.getData(ExcelDataImport.GeneralData, "ContextValue"));
						oracleObjectRender(SCRIPTTIME);
						isElementAvailable(brandDropdown, ELEMENTTIMEOUT);
						Select selectDropDownBrand = new Select(driver.findElement(brandDropdown));
						selectDropDownBrand.selectByVisibleText(dataTable.getData(ExcelDataImport.GeneralData, "Brand"));
						oracleObjectRender(SCRIPTTIME);
						isElementAvailable(stationeryCodeDropdown, ELEMENTTIMEOUT);
						Select selectDropDownStationery = new Select(driver.findElement(stationeryCodeDropdown));
						selectDropDownStationery.selectByVisibleText(dataTable.getData(ExcelDataImport.GeneralData, "StationeryCode"));
						report.updateTestLog("Invoice Creation Additonal Info Tab - V42 Preferred", "The user is required to provide an additional Information for V42 Invoice Creation", Status.PASS);
					}
					oracleObjectRender(QUERYRESPONSE);
					isElementAvailable(generalTab, PAGELOADTIMEOUT);
					driver.findElement(generalTab).click();
					oracleObjectRender(QUERYRESPONSE);
					isElementAvailable(numberTextBox, ELEMENTTIMEOUT);
					driver.findElement(numberTextBox).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "InvoiceNumber"));
					isElementAvailable(amountTextBox, ELEMENTTIMEOUT);
					driver.findElement(amountTextBox).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "HDRAmount"));
					isElementAvailable(descriptionInvoiceHeader, ELEMENTTIMEOUT);
					driver.findElement(descriptionInvoiceHeader).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "InvoiceHeaderDescription"));
					oracleObjectRender(QUERYRESPONSE);
					report.updateTestLog("Invoice Creation General Tab - V42", "The user is able to view all the details in General info Tab", Status.PASS);
					break;

				case "no":
					isElementAvailable(numberTextBox, ELEMENTTIMEOUT);
					driver.findElement(numberTextBox).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "InvoiceNumber"));
					isElementAvailable(amountTextBox, ELEMENTTIMEOUT);
					driver.findElement(amountTextBox).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "HDRAmount"));
					isElementAvailable(descriptionInvoiceHeader, ELEMENTTIMEOUT);
					driver.findElement(descriptionInvoiceHeader).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "InvoiceHeaderDescription"));
					oracleObjectRender(QUERYRESPONSE);
					report.updateTestLog("Standard Invoice Creation", "The user is not required to provide an additional Information for Standard Invoice Creation", Status.PASS);
					break;
				default:

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void invoiceLineMatching(String invoiceLinesDropdownData) {
		isElementAvailable(linesSectionDropDown, ELEMENTTIMEOUT);
		Select selectDropDown = new Select(driver.findElement(linesSectionDropDown));
		selectDropDown.selectByVisibleText(dataTable.getData(ExcelDataImport.GeneralData, "InvoiceLinesDropdown"));
		isElementAvailable(linesSectionNextButton, ELEMENTTIMEOUT);
		driver.findElement(linesSectionNextButton).click();
		oracleObjectRender(SCRIPTTIME);
		try {
			if (driver.findElement(warningMessageForHold).isDisplayed()) {
				report.updateTestLog("Warning Message to OnHold", "This Supplier has exceeded the limit as against the Total amount in Invoice Header", Status.PASS);
				oracleObjectRender(SCRIPTTIME);oracleObjectRender(SCRIPTTIME);
                isElementAvailable(popupOKButton, ELEMENTTIMEOUT);
				driver.findElement(popupOKButton).click();
				oracleObjectRender(QUERYRESPONSE);
			}
		} catch (Exception e) {
			report.updateTestLog("No Warning Message to OnHold", "The user has calculated the taxes and provided total Amount in Invoice Header", Status.PASS);
		}
        oracleObjectRender(SCRIPTTIME);
		isElementAvailable(linesSectionNextButton, ELEMENTTIMEOUT);
		driver.findElement(linesSectionNextButton).click();
		oracleObjectRender(SCRIPTTIME);

	switch(invoiceLinesDropdownData.toLowerCase()) {
		case "match invoice lines":
			isElementAvailable(matchInvoiceLinesCheckBox, PAGELOADTIMEOUT);
			if (!driver.findElement(matchInvoiceLinesCheckBox).isSelected()) {
				mouseOverAndClick(matchInvoiceLinesCheckBox);
			} else {
				report.updateTestLog("Match Invoice lines", "Match Invoice lines - checkbox is checked already", Status.PASS);
			}

			isElementAvailable(matchInvoiceLinesAmount, ELEMENTTIMEOUT);
			driver.findElement(matchInvoiceLinesAmount).clear();
			oracleObjectRender(SCRIPTTIME);
			driver.findElement(matchInvoiceLinesAmount).sendKeys(driver.findElement(matchInvoiceLinesOrderedAmount).getAttribute("innerHTML"));
			report.updateTestLog("2 Ways matching PO Invoice Creation", "PO Invoice Creation for 2 Ways matching", Status.PASS);
			isElementAvailable(matchInvoiceLinesApplyButton, ELEMENTTIMEOUT);
			driver.findElement(matchInvoiceLinesApplyButton).click();
            oracleObjectRender(SCRIPTTIME);
			isElementAvailable(matchInvoiceLinesOKButton, ELEMENTTIMEOUT);
			driver.findElement(matchInvoiceLinesOKButton).click();
			oracleObjectRender(QUERYRESPONSE);
			try {
				if (driver.findElement(warningMessageForOverbill).isDisplayed()) {
					report.updateTestLog("Warning Message to OverBill", "Warning message for Completing this match will result in overbill", Status.PASS);
					oracleObjectRender(SCRIPTTIME);
                    isElementAvailable(popupOKButton, ELEMENTTIMEOUT);
					driver.findElement(popupOKButton).click();
					oracleObjectRender(QUERYRESPONSE);
				}
			} catch (Exception e) {
				report.updateTestLog("No Warning Message to OverBill", "No Warning message for Completing this match will result in overbill", Status.PASS);
			}
			break;


		case "match to receipt charges":
			oracleObjectRender(SCRIPTTIME);
			isElementAvailable(matchInvoiceReceiptType, PAGELOADTIMEOUT);
			driver.findElement(matchInvoiceReceiptType).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "MatchInvoiceReceiptType"));
			oracleObjectRender(SCRIPTTIME);
            isElementAvailable(matchInvoiceReceiptChargeAmount, ELEMENTTIMEOUT);
            driver.findElement(matchInvoiceReceiptChargeAmount).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "MatchInvoiceReceiptChargeAmount"));
            oracleObjectRender(SCRIPTTIME);
            isElementAvailable(matchInvoiceReceiptChargeDistribution, ELEMENTTIMEOUT);
            driver.findElement(matchInvoiceReceiptChargeDistribution).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "MatchInvoiceReceiptChargeDistb"));
            oracleObjectRender(SCRIPTTIME);
            isElementAvailable(matchInvoiceReceiptSupplier, ELEMENTTIMEOUT);
            driver.findElement(matchInvoiceReceiptSupplier).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "Supplier"));
            oracleObjectRender(SCRIPTTIME);
			isElementAvailable(matchInvoiceReceiptSupplierSite, ELEMENTTIMEOUT);
			driver.findElement(matchInvoiceReceiptSupplierSite).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "SupplierSite"));
			isElementAvailable(matchInvoiceReceiptSupplierSiteArrow, ELEMENTTIMEOUT);
			driver.findElement(matchInvoiceReceiptSupplierSiteArrow).click();
			oracleObjectRender(SCRIPTTIME);
			isElementAvailable(matchInvoiceReceiptSupplierSiteValidate, ELEMENTTIMEOUT);
			driver.findElement(matchInvoiceReceiptSupplierSiteValidate).click();
			oracleObjectRender(SCRIPTTIME);oracleObjectRender(SCRIPTTIME);
			try {
				if (driver.findElement(commonErrorInvalidMessage).isDisplayed()) {
					report.updateTestLog("Common Error Dialog box", "The user able to verify Common Error Dialog is opened", Status.PASS);
					isElementAvailable(commonErrorMessageClose, ELEMENTTIMEOUT);
					driver.findElement(commonErrorMessageClose).click();
					oracleObjectRender(SCRIPTTIME);
				}
			} catch (Exception e) {
				report.updateTestLog("No Common Error Dialog box", "No Common Error Dialog box is displayed", Status.PASS);

			}
            isElementAvailable(matchInvoiceReceiptPurchaseOrder, ELEMENTTIMEOUT);
            driver.findElement(matchInvoiceReceiptPurchaseOrder).sendKeys(driver.findElement(identifyingPOTextBox).getAttribute("value"));
			oracleObjectRender(SCRIPTTIME);
			isElementAvailable(searchButton, ELEMENTTIMEOUT);
			driver.findElement(searchButton).click();
			oracleObjectRender(QUERYRESPONSE);
            isElementAvailable(matchInvoiceReceiptCheckBox, ELEMENTTIMEOUT);
            if (!driver.findElement(matchInvoiceReceiptCheckBox).isSelected()) {
                mouseOverAndClick(matchInvoiceReceiptCheckBox);
            } else {
				report.updateTestLog("Match Invoice Receipt", "Match Invoice Receipt - checkbox is checked already", Status.PASS);
            }
            isElementAvailable(matchInvoiceReceiptAmount, ELEMENTTIMEOUT);
            driver.findElement(matchInvoiceReceiptAmount).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "MatchInvoiceReceiptAmount"));
			report.updateTestLog("3 Ways matching PO Invoice Creation", "PO Invoice Creation for 3 Ways matching", Status.PASS);
            isElementAvailable(matchInvoiceLinesApplyButton, ELEMENTTIMEOUT);
            driver.findElement(matchInvoiceLinesApplyButton).click();
            oracleObjectRender(QUERYRESPONSE);
			isElementAvailable(matchInvoiceLinesOKButton, ELEMENTTIMEOUT);
			driver.findElement(matchInvoiceLinesOKButton).click();
			oracleObjectRender(QUERYRESPONSE);
			try {
				if (driver.findElement(warningMessageForOverbill).isDisplayed()) {
					report.updateTestLog("Warning Message to OverBill", "Warning message for Completing this match will result in overbill", Status.PASS);
					oracleObjectRender(SCRIPTTIME);
					isElementAvailable(popupOKButton, ELEMENTTIMEOUT);
					driver.findElement(popupOKButton).click();
					oracleObjectRender(QUERYRESPONSE);
					isElementAvailable(matchInvoiceLinesOKButton, ELEMENTTIMEOUT);
					driver.findElement(matchInvoiceLinesOKButton).click();
					oracleObjectRender(QUERYRESPONSE);
				}
			} catch (Exception e) {
				report.updateTestLog("No Warning Message to OverBill", "No Warning message for Completing this match will result in overbill", Status.PASS);
			}
			break;

		default :
			break;
	}
}


	private void enterNonPOValues() {
		isElementAvailable(businessUnitDrpdown, PAGELOADTIMEOUT);
		driver.findElement(businessUnitDrpdown).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "BusinessUnit"));
		if (driver.findElement(popupClose).isDisplayed()) {
			isElementAvailable(popupClose, ELEMENTTIMEOUT);
			driver.findElement(popupClose).click();
		}
        driver.findElement(businessUnitDrpdown).clear();
        isElementAvailable(businessUnitDrpdown, ELEMENTTIMEOUT);
		driver.findElement(businessUnitDrpdown).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "BusinessUnit"));
		//mouseOverAndEnter(businessUnitDrpdown, (dataTable.getData(ExcelDataImport.GeneralData, "BusinessUnit")));
		isElementAvailable(businessUnitDrpdownValidate, ELEMENTTIMEOUT);
		driver.findElement(businessUnitDrpdownValidate).click();
		oracleObjectRender(QUERYRESPONSE);
		report.updateTestLog("Navigation to Create Invoice screen", "The Landing page is Create Invoice Screen", Status.PASS);
		isElementAvailable(supplierDrpdown, ELEMENTTIMEOUT);
		driver.findElement(supplierDrpdown).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "Supplier"));
		isElementAvailable(supplierDrpdownValidate, ELEMENTTIMEOUT);
		driver.findElement(supplierDrpdownValidate).click();
		oracleObjectRender(QUERYRESPONSE);
	}
	}
