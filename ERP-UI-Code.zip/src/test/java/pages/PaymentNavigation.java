package pages;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.ScriptHelper;
import org.openqa.selenium.By;

public class PaymentNavigation extends MasterPages {

    //Page Sync Config

    // page loading time
    public static final int PAGELOADTIMEOUT = 90;
    // individual element load time
    public static final int ELEMENTTIMEOUT = 60;
    // Oracle query response
    public static final long QUERYRESPONSE = 15;
    // object render script
    public static final long SCRIPTTIME = 5;


    /**
     * Constructor to initialize the page
     *
     * @param scriptHelper The {@link ScriptHelper} object passed from the
     *                     {@link DriverScript}
     */
    public PaymentNavigation(ScriptHelper scriptHelper) {
        super( scriptHelper );
    }


    // UI Map object definitions

    private final By navigator = By.xpath( "//a[@title='Navigator']" );

    private final By payments = By.xpath( "//*[text()='Payments']/ancestor::div/table/tbody/tr[1]/td[3]/a" );


    public void paymentNav() {
        driver.navigate().refresh();
        isElementAvailable( navigator, ELEMENTTIMEOUT );
        driver.findElement( navigator ).click();
        scrollPageDown();
        isElementAvailable( payments, ELEMENTTIMEOUT );
        driver.findElement( payments ).click();
    }


}
