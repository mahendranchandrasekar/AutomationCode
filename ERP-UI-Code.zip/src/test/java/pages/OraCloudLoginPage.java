package pages;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.ScriptHelper;
import com.cognizant.framework.Status;
import org.openqa.selenium.By;

/**
 * FCCS SignOnPage class

 */
public class OraCloudLoginPage extends MasterPages {

	//Page Sync Config

	// page loading time
	public static final int PAGELOADTIMEOUT = 90;
	// individual element load time
	public static final int ELEMENTTIMEOUT = 60;
	// Oracle query response
	public static final long QUERYRESPONSE = 15;
	// object render script
	public static final long SCRIPTTIME = 5;


	// UI Map object definitions

	// Text boxes
	private final By txtUsername = By.id("userid");
	private final By txtPassword = By.id("password");

	// Buttons
	private final By btnLogin = By.xpath("//*[@id='btnActive']");
	private final By signOutDropdown= By.xpath("//*[contains(@id,'UIScmil1u::icon')]");
	private final By signOutLink= By.xpath("//a[text()='Sign Out']");
	private final By signOutConfirmButton= By.xpath("//button[text()=' Confirm']");


	/**
	 * Constructor to initialize the page
	 *
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	public OraCloudLoginPage(ScriptHelper scriptHelper) {
		super(scriptHelper);

	}


	public void login(String userNameData, String passwordData) {
		isElementAvailable(txtUsername,PAGELOADTIMEOUT);
		driver.findElement(txtUsername).sendKeys(userNameData);
		isElementAvailable(txtPassword,PAGELOADTIMEOUT);
		driver.findElement(txtPassword).sendKeys(passwordData);

		report.updateTestLog("Login",
				"Enter login credentials: " + "Username = " + userNameData ,
				Status.DONE);

		 driver.findElement(btnLogin).click();

		isElementAvailable(signOutDropdown,PAGELOADTIMEOUT);
		if (driver.findElements(signOutDropdown).size() > 0){
			report.updateTestLog("Verify Home Page",
					"Home Page launched successfully", Status.PASS);
		}else{
			report.updateTestLog("Verify Home Page",
					"Home Page not launched", Status.FAIL);
		}


	}


	public void logout(){
		isElementAvailable(signOutDropdown,ELEMENTTIMEOUT);
		driver.findElement(signOutDropdown).click();

		isElementAvailable(signOutLink,ELEMENTTIMEOUT);
		driver.findElement(signOutLink).click();

		isElementAvailable(signOutConfirmButton,ELEMENTTIMEOUT);
		driver.findElement(signOutConfirmButton).click();
		oracleObjectRender(SCRIPTTIME);
	}

}