package pages;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.ScriptHelper;
import com.cognizant.framework.Status;
import com.cognizant.framework.selenium.CraftDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

public class ARHomePage extends MasterPages {

    // Elements

    //Links
    private final By navigator = By.xpath( "//a[@title='Navigator']" );
    private final By welcomepage = By.xpath( "//*[contains(@class,'xnr')]" );
    private final By billingnav = By.xpath( "//a[@title='Billing']" );
    private final By homeIconBtn = By.xpath( "//a[starts-with(@title,'Home')]/child::*" );
    private final By projectIconBtn = By.xpath("//a[contains(text(),'Projects')]");
    private final By projectFinancialIconBtn = By.xpath("//a[starts-with(@id,'itemNode_projects_projects')]");
    private final By accreceivablenav = By.xpath( "//*[text()='Accounts Receivable']/ancestor::div[1]/table/tbody/tr/td[3]/a" );
    private final By cashbalancenav = By.xpath( "//a[contains(@id,'nv_itemNode_cash_management_cash_balances')]" );
    private final By setupmaintenance = By.xpath( "//a[contains(text(),'Setup and Maintenance')]" );
    private final By setupmaintenanceicon = By.xpath( "//img[contains(@id,'nvi_itemNode_tools_setup_and_maintenance::icon')]" );
    private final By homeicon = By.xpath( "//a[@id='pt1:_UIScil1u']" );
    private final By setupmaintenanceiconhomepage = By.xpath( "//*[@id='itemNode_tools_setup_and_maintenance_19']" );
    private final By belliconhomepage = By.xpath( "//*[@id='pt1:_UISatr:0:cil1::icon']" );


    private final By morelink = By.xpath( "//a[contains(text(),'More')]" );
    private final By btnsearch = By.xpath( "//*[contains(@alt,'Search')]" );
    private final By Fixedassets = By.xpath( "//*[contains(@id,'nv_itemNode_fixed_assets_additions')]" );
    private final By projectfinancialmanagement = By.xpath( "//*[contains(@id,'nv_itemNode_projects_projects')]" );
    private final By projectassets = By.xpath( "//a[contains(@id,':nv_itemNode_projects_assets')]" );
    private final By projectcosts = By.xpath( "//*[contains(@id,':nv_itemNode_projects_costs')]" );


    // page loading time
    public static final int PAGELOADTIMEOUT = 90;
    // individual element load time
    public static final int ELEMENTTIMEOUT = 60;
    public static final int SCRIPTTIME = 5;

    public static final int QUERYRESPONSE = 15;

    /**
     * Constructor to initialize the functional library
     *
     * @param scriptHelper The {@link ScriptHelper} object passed from the
     *                     {@link DriverScript}
     */
    public ARHomePage(ScriptHelper scriptHelper) {
        super( scriptHelper );
        oracleObjectRender( QUERYRESPONSE );
        isElementAvailable( navigator, ELEMENTTIMEOUT );
        report.updateTestLog( "Verify page", "AR Welcome page displayed successfully", Status.PASS );
    }


    public void billingNav() {
        isElementAvailable( navigator, ELEMENTTIMEOUT);
        driver.findElement( navigator ).click();

        isElementAvailable( billingnav, ELEMENTTIMEOUT );
        driver.findElement( billingnav ).click();
    }

    public void accReceivableNav() {
        isElementAvailable( navigator, ELEMENTTIMEOUT);
        driver.findElement( navigator ).click();

        isElementAvailable( accreceivablenav, ELEMENTTIMEOUT );
        driver.findElement( accreceivablenav ).click();
    }

    public void cashbalanceNav() {
        isElementAvailable( navigator, ELEMENTTIMEOUT);

        driver.findElement( navigator ).click();

        isElementAvailable( cashbalancenav, ELEMENTTIMEOUT );
        driver.findElement( cashbalancenav ).click();
    }


    public void setupmaintenanceNav() {
        isElementAvailable( navigator, ELEMENTTIMEOUT);
        driver.findElement( navigator ).click();
        PauseScript( 6 );
        if ( driver.findElements( setupmaintenance ).size() > 0 ) {
            isElementAvailable( setupmaintenance, ELEMENTTIMEOUT );
            driver.findElement( setupmaintenance ).click();
        } else {
            isElementAvailable( homeicon, ELEMENTTIMEOUT );
            driver.findElement( homeicon ).click();
            PauseScript( 6 );
            isElementAvailable( setupmaintenanceiconhomepage, ELEMENTTIMEOUT );
            driver.findElement( setupmaintenanceiconhomepage ).click();
                PauseScript( 3 );
            }

    }


    public void assetNavigation() {
        isElementAvailable( navigator, ELEMENTTIMEOUT);
        driver.findElement( navigator ).click();

        isElementAvailable( Fixedassets, ELEMENTTIMEOUT );
        driver.findElement( Fixedassets ).click();
    }


    public void projectfinancialmanagementNav() {
        isElementAvailable( navigator, ELEMENTTIMEOUT );
        driver.findElement( navigator ).click();

        isElementAvailable( projectfinancialmanagement, ELEMENTTIMEOUT );
        driver.findElement( projectfinancialmanagement ).click();
        oracleObjectRender( SCRIPTTIME );
    }


    public void projectAssetNavigation() {
        isElementAvailable( navigator, ELEMENTTIMEOUT );
        driver.findElement( navigator ).click();
        isElementAvailable( projectassets, ELEMENTTIMEOUT );
        driver.findElement( projectassets ).click();
        /*isElementAvailable( homeIconBtn, ELEMENTTIMEOUT );
        driver.findElement( homeIconBtn ).click();
        isElementAvailable( homeIconBtn, ELEMENTTIMEOUT );
        driver.findElement( homeIconBtn ).click();
        oracleObjectRender( SCRIPTTIME );*/
    }

    public void projectCosttNavigation() {
        isElementAvailable( navigator, ELEMENTTIMEOUT );
        driver.findElement( navigator ).click();

        isElementAvailable( projectcosts, ELEMENTTIMEOUT );
        driver.findElement( projectcosts ).click();
        oracleObjectRender( SCRIPTTIME );
    }


}
