package pages;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.ScriptHelper;
import com.cognizant.framework.Status;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class ManageProjectCostPage extends MasterPages {

    // Elements

    //Links
    private final By navigator = By.xpath("//a[@title='Navigator']");
    private final By taskmenu = By.xpath("//img[@title='Tasks']");
    private final By manageprojectcost = By.xpath("//a[text()='Manage Project Costs']");
    private final By capturecost = By.xpath("//a[text()='Capture Costs']");
    private final By projectcosts = By.xpath("//*[contains(@id,':nv_itemNode_projects_costs')]");


    private final By expenditurebusinessunit = By.xpath("//label[text()='Expenditure Business Unit']/ancestor::tr[1]/td[2]//input");
    private final By projectname = By.xpath("//label[text()='Project Name']/ancestor::tr[1]/td[2]//input");
    private final By projectnumber = By.xpath("//label[text()='Project Number']/ancestor::tr[1]/td[2]//input");

    private final By searchheader = By.xpath("//h1[text()='Search']");
    private final By expandsearch = By.xpath("//*[@title='Expand Search']");
    private final By collapsesearch = By.xpath("//*[@title='Collapse Search']");

    //advanced search
    private final By expenditurecategoryfilter = By.xpath("//select[contains(@id,'mei_panel1:qPanel:operator19::content')]");
    private final By expenditurecategoryvalue = By.xpath("//input[contains(@id,'mei_panel1:qPanel:value190::content')]");
    private final By capitalizablefilter = By.xpath("//select[contains(@id,'mei_panel1:qPanel:operator15::content')]");
    private final By capitalizablevalue = By.xpath("//select[contains(@id,'mei_panel1:qPanel:value150::content')]");


    //create mass adjustment pop up
    private final By adjustmenttype = By.xpath("//label[text()='Adjustment Type']/ancestor::tr[1]/td[2]//select");
    private final By massadjustmnettransactionsubtotalheader = By.xpath("//h1[text()='Mass Adjustment Transactions Subtotal']");
    private final By expandmassadjustmenttransactions = By.xpath("//a[@title='Expand Mass Adjustment Transactions Subtotal']");
    private final By collapsemassadjustmenttransactions = By.xpath("//a[@title='Collapse Mass Adjustment Transactions Subtotal']");
    private final By justification = By.xpath("//*[contains(@id,'mei_panel1:it1::content')]");
    private final By tasknumber = By.xpath("//label[text()='Task Number']/ancestor::tr[1]/td[2]//input");

    private final By warningmessage = By.xpath("//*[contains(@id,'dialMassAdjustWarning::contentContainer')]");

    private final By overviewheader = By.xpath("//h1[text()='Overview']");
    private final By overviewheadertab = By.xpath("//*[contains(@id,'FOSritemNode_projects_costs:1:MainAreaTab1::ti')]/div/a");
    //private final By expandprocessmonitor = By.xpath("//a[@title='Expand Process Monitor']");
    private final By expandprocessmonitor = By.xpath("//*[text()='Process Monitor']/../../../../child::tr/child::td[1]/child::a");
    private final By processrefreshicon = By.xpath("//*[contains(@id,'processRefreshId::icon')]");
    private final By processoutputicon = By.xpath("//*[contains(@id,'pc1:resultsTable:0:imglinkid::icon')]");

    private final By manageprojectcosttab = By.xpath("//*[contains(@id,'FOSritemNode_projects_costs:1:MainAreaTab2::ti')]/div/a[1]");
    private final By manageprojectcostheader = By.xpath("//h1[text()='Manage Project Costs']");


    private final By generaltab = By.xpath("//*[contains(@id,'projects_costs:0:MAt2:1:eidet_panel1:panelTabbed1::tabh::cbc')]/div[1]/div/a");
    private final By costingtab = By.xpath("//*[contains(@id,'projects_costs:0:MAt2:1:eidet_panel1:panelTabbed1::tabh::cbc')]/div[2]/div/a");
    private final By adjustmenthistorytab = By.xpath("//*[contains(@id,'projects_costs:0:MAt2:1:eidet_panel1:panelTabbed1::tabh::cbc')]/div[6]/div/a");


    private final By transactionnumber = By.xpath("//table[@summary='Search Results']/tbody/tr[1]/td[3]/span");

    //Amend the Project Cost using the ADFDI
    private final By createnonlaborcosts = By.xpath("//a[text()='Create Nonlabor Costs']");


    //button
    private final By btnsearch = By.xpath("//button[text()='Search']");
    private final By btnadvancedsearch = By.xpath("//button[@accesskey='d']");
    private final By btncreatemassadjustment = By.xpath("//button[text()='Create Mass Adjustment']");
    private final By btnsubmit = By.xpath("//*[@accesskey='m']");
    private final By btnokwarningpopup = By.xpath("//*[@accesskey='Y']");
    private final By btnDone = By.xpath("//*[@accesskey='o']");

    // page loading time
    public static final int PAGELOADTIMEOUT = 90;
    // individual element load time
    public static final int ELEMENTTIMEOUT = 60;
    // Oracle query response
    public static final long QUERYRESPONSE = 15;
    // object render script
    public static final int SCRIPTTIME = 5;

    /**
     * Constructor to initialize the functional library
     *
     * @param scriptHelper The {@link ScriptHelper} object passed from the
     *                     {@link DriverScript}
     */
    public ManageProjectCostPage(ScriptHelper scriptHelper) {
        super(scriptHelper);
    }

    //Navigations

    public void projectCosttNavigation() {
        isElementAvailable(navigator, ELEMENTTIMEOUT);
        driver.findElement(navigator).click();

        isElementAvailable(projectcosts, ELEMENTTIMEOUT);
        driver.findElement(projectcosts).click();
        oracleObjectRender(SCRIPTTIME);
    }

    public void manageprojectcostnav() {
        isElementAvailable(taskmenu, ELEMENTTIMEOUT);
        driver.findElement(taskmenu).click();

        isElementAvailable(manageprojectcost, ELEMENTTIMEOUT);
        driver.findElement(manageprojectcost).click();
    }

    public void Capturecostnav() {
        isElementAvailable(taskmenu, ELEMENTTIMEOUT);
        driver.findElement(taskmenu).click();

        isElementAvailable(capturecost, ELEMENTTIMEOUT);
        driver.findElement(capturecost).click();
    }


    //used string for the filtervalues
    private String[] filtervalues = new String[]{"Starts with", "Equals"};
    String Expenditurefiltervalue = filtervalues[0];
    String Capitalizablefiltervalue = filtervalues[1];

    private void Entertheprojectnameonsearchfield() {
        isElementAvailable(projectname, PAGELOADTIMEOUT);
        driver.findElement(projectname).click();
        driver.findElement(projectname).sendKeys(dataTable.getData("General_Data", "Project Name"));
        oracleObjectRender(SCRIPTTIME);
    }

    private void clickonsearchbutton() {
        isElementAvailable(btnsearch, ELEMENTTIMEOUT);
        driver.findElement(btnsearch).click();
        oracleObjectRender(SCRIPTTIME);
    }

    private void Clickonadvancedsearch() {
        isElementAvailable(btnadvancedsearch, ELEMENTTIMEOUT);
        if (driver.findElement(btnadvancedsearch).isDisplayed()) {
            driver.findElement(btnadvancedsearch).click();
            oracleObjectRender(SCRIPTTIME);
        } else {
            driver.findElement(btnadvancedsearch).click();
            oracleObjectRender(SCRIPTTIME);
        }
    }

    private void Entertheparametersforadvancesearch() {
        isElementAvailable(expenditurecategoryfilter, ELEMENTTIMEOUT);
        Select drpexpenditurecategoryfilter = new Select(driver.findElement(expenditurecategoryfilter));
        drpexpenditurecategoryfilter.selectByVisibleText(Expenditurefiltervalue);
        oracleObjectRender(SCRIPTTIME);
        isElementAvailable(expenditurecategoryvalue, ELEMENTTIMEOUT);
        driver.findElement(expenditurecategoryvalue).click();
        driver.findElement(expenditurecategoryvalue).sendKeys(dataTable.getData("General_Data", "Expenditure Category"));
        oracleObjectRender(SCRIPTTIME);
        isElementAvailable(capitalizablefilter, ELEMENTTIMEOUT);
        Select drpcapitalizablefilter = new Select(driver.findElement(capitalizablefilter));
        drpcapitalizablefilter.selectByVisibleText(Capitalizablefiltervalue);
        oracleObjectRender(SCRIPTTIME);
        isElementAvailable(capitalizablevalue, ELEMENTTIMEOUT);
        Select drpcapitalizablevalue = new Select(driver.findElement(capitalizablevalue));
        drpcapitalizablevalue.selectByVisibleText(dataTable.getData("General_Data", "Capitalizable"));
        oracleObjectRender(SCRIPTTIME);
        report.updateTestLog("Verify the Project Name, Expenditure Category", " Search parameters Updated", Status.PASS);
        isElementAvailable(btnsearch, ELEMENTTIMEOUT);
        driver.findElement(btnsearch).click();
        oracleObjectRender(SCRIPTTIME);
    }

    private void Clickoncreatemassadjustment() {
        report.updateTestLog("Verify Search Results  ", " Search Results displayed", Status.PASS);
        isElementAvailable(btncreatemassadjustment, ELEMENTTIMEOUT);
        driver.findElement(btncreatemassadjustment).click();
        oracleObjectRender(QUERYRESPONSE);
    }

    private void Selecttheadjustmenttype() {
        isElementAvailable(adjustmenttype, PAGELOADTIMEOUT);
        Select drpcadjustmenttype = new Select(driver.findElement(adjustmenttype));
        drpcadjustmenttype.selectByVisibleText(dataTable.getData("General_Data", "Adjustment Type"));
        oracleObjectRender(SCRIPTTIME);
    }

    private void Verifythemassddjustmenttransactionssubtotal() {
        isElementAvailable(massadjustmnettransactionsubtotalheader, ELEMENTTIMEOUT);
        if (driver.findElement(expandmassadjustmenttransactions).isDisplayed()) {
            driver.findElement(expandmassadjustmenttransactions).click();
            oracleObjectRender(SCRIPTTIME);
        } else {
            driver.findElement(expandmassadjustmenttransactions).click();
            oracleObjectRender(SCRIPTTIME);
        }
        report.updateTestLog("Verify number of transactions & cost value", " Number of Transactions & cost value displayed", Status.PASS);
    }

    private void EntertheJustification() {
        isElementAvailable(justification, ELEMENTTIMEOUT);
        driver.findElement(justification).click();
        driver.findElement(justification).sendKeys(dataTable.getData("General_Data", "Justification"));
        oracleObjectRender(SCRIPTTIME);
    }

    private void EntertheProjectandTasknumber() {
        isElementAvailable(projectnumber, ELEMENTTIMEOUT);
        driver.findElement(projectnumber).click();
        driver.findElement(projectnumber).sendKeys(dataTable.getData("General_Data", "Project Number"));
        oracleObjectRender(SCRIPTTIME);
        isElementAvailable(tasknumber, ELEMENTTIMEOUT);
        driver.findElement(tasknumber).click();
        PauseScript(3);
        driver.findElement(tasknumber).sendKeys(dataTable.getData("General_Data", "TaskNumber"));
        oracleObjectRender(SCRIPTTIME);
    }

    private void Clickonsubmit() {
        isElementAvailable(btnsubmit, ELEMENTTIMEOUT);
        driver.findElement(btnsubmit).click();
        oracleObjectRender(SCRIPTTIME);
    }

    private void warningmessagecheck() {
        isElementAvailable(warningmessage, ELEMENTTIMEOUT);
        if (driver.findElement(warningmessage).isDisplayed()) {
            driver.findElement(btnokwarningpopup).click();
            PauseScript(3);
            report.updateTestLog("Verify the confirmation message", " Confirmation message displayed", Status.PASS);
            oracleObjectRender(SCRIPTTIME);
        } else {
            //Skip
            oracleObjectRender(SCRIPTTIME);
        }
    }

    private void backtomanageprojectcosttab() {
        driver.switchTo().defaultContent();
        isElementAvailable(btnDone, ELEMENTTIMEOUT);
        driver.findElement(btnDone).click();
        oracleObjectRender(SCRIPTTIME);
    }

    private void verifyontheoverviewtab() {
        isElementAvailable(overviewheader, ELEMENTTIMEOUT);
        driver.findElement(overviewheader).isDisplayed();
        /*isElementAvailable(expandprocessmonitor, ELEMENTTIMEOUT);
        driver.findElement(expandprocessmonitor).click();*/
        oracleObjectRender(SCRIPTTIME);
        isElementAvailable(processrefreshicon, ELEMENTTIMEOUT);
        driver.findElement(processrefreshicon).click();
        report.updateTestLog("Verify the status mass adjustment request ", " Mass adjustment request displayed successfully", Status.PASS);
        oracleObjectRender(SCRIPTTIME);
    }

    private void Checktheadjustedtransactiononmanageprojectcosttab() {
        isElementAvailable(manageprojectcostheader, ELEMENTTIMEOUT);
        PauseScript(3);
        driver.findElement(manageprojectcostheader).isDisplayed();
        oracleObjectRender(SCRIPTTIME);
        report.updateTestLog("Review the adjusted transaction ", "Adjusted transaction displayed", Status.PASS);
        isElementAvailable(transactionnumber, ELEMENTTIMEOUT);
        PauseScript(3);
        driver.findElement(transactionnumber).click();
        oracleObjectRender(QUERYRESPONSE);
    }

    private void Clickoncostingtab() {
        isElementAvailable(costingtab, PAGELOADTIMEOUT);
        PauseScript(3);
        driver.findElement(costingtab).click();
        oracleObjectRender(SCRIPTTIME);
        report.updateTestLog("Verify Negative and Positive transactions  ", "Adjustment entry displayed for both transactions", Status.PASS);

    }

    private void Clickoncadjustmenthistory() {
        isElementAvailable(adjustmenthistorytab, PAGELOADTIMEOUT);
        PauseScript(2);
        driver.findElement(adjustmenthistorytab).click();
        oracleObjectRender(SCRIPTTIME);
        report.updateTestLog("Verify the mass adjustment details  ", "Adjusted by, Adjustment type, source & status, Justification displayed", Status.PASS);
    }

    private void ClickonCreatenonlaborcosts() {
        oracleObjectRender(SCRIPTTIME);
        isElementAvailable(createnonlaborcosts, ELEMENTTIMEOUT);
        driver.findElement(createnonlaborcosts).click();
        oracleObjectRender(SCRIPTTIME);
        report.updateTestLog("Verify create non labour costs navigation ", " Create Non labour Costs navigated successfully", Status.PASS);
    }


    //Amend the Project Cost - Mass Adjustments - adjustment of transaction from capitalizable to non-capitalizable
    public void MassadjusmentofTransactionfromcapitalizabletononcappitalizable() {
        Entertheprojectnameonsearchfield();
        Clickonadvancedsearch();
        Entertheparametersforadvancesearch();
        Clickoncreatemassadjustment();
        Selecttheadjustmenttype();
        EntertheJustification();
        Verifythemassddjustmenttransactionssubtotal();
        Clickonsubmit();
        warningmessagecheck();
        backtomanageprojectcosttab();
        verifyontheoverviewtab();
        projectCosttNavigation();
        oracleObjectRender(SCRIPTTIME);
        manageprojectcostnav();
        oracleObjectRender(SCRIPTTIME);
        Entertheprojectnameonsearchfield();
        clickonsearchbutton();
        Checktheadjustedtransactiononmanageprojectcosttab();
        Clickoncostingtab();
        Clickoncadjustmenthistory();
    }


    //Amend the Project Cost - Mass Adjustments - Project to Project cost movement for Transfers or Reversals
    public void MassadjusmentofprojecttoProjectcostmovementforTransfers() {
        Entertheprojectnameonsearchfield();
        clickonsearchbutton();
        Clickoncreatemassadjustment();
        Selecttheadjustmenttype();
        EntertheProjectandTasknumber();
        EntertheJustification();
        Verifythemassddjustmenttransactionssubtotal();
        Clickonsubmit();
        warningmessagecheck();
        backtomanageprojectcosttab();
        verifyontheoverviewtab();
        projectCosttNavigation();
        oracleObjectRender(SCRIPTTIME);
        manageprojectcostnav();
        oracleObjectRender(SCRIPTTIME);
        Entertheprojectnameonsearchfield();
        clickonsearchbutton();
        Checktheadjustedtransactiononmanageprojectcosttab();
        Clickoncostingtab();
        Clickoncadjustmenthistory();
    }

}
