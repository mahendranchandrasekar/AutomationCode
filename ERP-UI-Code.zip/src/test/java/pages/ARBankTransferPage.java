package pages;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.ScriptHelper;
import com.cognizant.framework.Status;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

public class ARBankTransferPage extends MasterPages {

    // page loading time
    public static final int PAGELOADTIMEOUT = 90;
    // individual element load time
    public static final int ELEMENTTIMEOUT = 60;
    // Oracle query response
    public static final long QUERYRESPONSE = 15;
    // object render script
    public static final long SCRIPTTIME = 5;


    // UI Map object definitions
//Create Bank Account transfer Elements
    private final By taskmenu = By.xpath( "//img[contains(@title,'Tasks')]" );
    private final By cashbalancenav = By.xpath( "//a[contains(@id,'nv_itemNode_cash_management_cash_balances')]" );
    private final By createbanktransfer = By.xpath( "//*[text()='Create Bank Account Transfer']" );
    private final By header = By.xpath( "//*[@title='Create Bank Account Transfer']" );
    private final By fromaccount = By.xpath( "//label[text()='From Account']/ancestor::tr[1]/td[2]//input" );
    private final By fromaccountdrpdwn = By.xpath( "//*[@title='Search: From Account']" );
    private final By toaccount = By.xpath( "//label[text()='To Account']/ancestor::tr[1]/td[2]//input" );
    private final By toaccountdrpdwn = By.xpath( "//*[@title='Search: To Account']" );
    private final By transferamount = By.xpath( "//label[text()='Transfer Amount']/ancestor::tr[1]/td[2]//input" );
    private final By transferdate = By.xpath( "//label[text()='Transfer Date']/ancestor::tr[1]/td[2]//input" );
    private final By paymentmethod = By.xpath( "//label[text()='Payment Method']/ancestor::tr[1]/td[2]//input" );
    private final By paymentprofile = By.xpath( "//label[text()='Payment Profile']/ancestor::tr[1]/td[2]//input" );
    private final By memo = By.xpath( "//label[text()='Memo']/ancestor::tr[1]/td[2]" );
    private final By btnsubmit = By.xpath( "//button[@accesskey='S']" );
    private final By btncancel = By.xpath( "//a[@accesskey='C']" );
    private final By settletrans = By.xpath( "//*[@type='checkbox']" );
    private final By fromaccsel = By.xpath( "//*[contains(@id,'dropdownPopup::dropDownContent:0:j_id49')]" );
    private final By toaccsel = By.xpath( "//*[contains(@id,'dropdownPopup::dropDownContent:0:j_id52')]" );
    private final By businessunit = By.xpath( "//label[text()='Business Unit']/ancestor::tr[1]/td[2]//input" );
    private final By btnyes = By.xpath( "//button[text()='Yes']" );
    private final By btnno = By.xpath( "//button[text()='No']" );

    //adhocpayment
    private final By createadhocpayment = By.xpath( "//a[text()='Create Ad Hoc Payment']" );
    private final By fromacct = By.xpath( "//label[text()='From Account']/ancestor::tr[1]/td[2]//input" );
    private final By payee = By.xpath( "//label[text()='Payee']/ancestor::tr[1]/td[2]//input" );
    private final By payeeacct = By.xpath( "//label[text()='Payee Account']/ancestor::tr[1]/td[2]//input" );
    private final By paymentamt = By.xpath( "//label[text()='Payment Amount']/ancestor::tr[1]/td[2]//input" );
    private final By offseacct = By.xpath( "//label[text()='Offset Account']/ancestor::tr[1]/td[2]//input" );
    private final By cashacct = By.xpath( "//label[text()='Cash Account']/ancestor::tr[1]/td[2]//input]" );
    private final By bussunit = By.xpath( "//label[text()='Business Unit']/ancestor::tr[1]/td[2]//input" );
    private final By paymentmthd = By.xpath( "//label[text()='Payment Method']/ancestor::tr[1]/td[2]//input" );
    private final By paymtprof = By.xpath( "//label[text()='Payment Profile']/ancestor::tr[1]/td[2]//input" );
    private final By memo1 = By.xpath( "//label[text()='Memo']/ancestor::tr[1]/td[2]" );
    private final By btnSubmit = By.xpath( "//span[text()='S']" );
    private final By btnCancel = By.xpath( "//a[@accesskey='C']" );
    private final By srchpayeeaccountselect = By.xpath( "//*[contains(@id,'afrLovInternalTableId::db')]/table/tbody/tr[1]/td[2]/div" );
    private final By srchpayeepopupok = By.xpath( "//*[contains(@id,'lovDialogId::ok')]" );
    private final By ajaxValidate = By.xpath( "//div[contains(@class,'AFDetectExpansion')]/../tbody/tr[1]/td[1]/ul[1]/li[1]" );


    /**
     * Constructor to initialize the page
     *
     * @param scriptHelper The {@link ScriptHelper} object passed from the
     *                     {@link DriverScript}
     */
    public ARBankTransferPage(ScriptHelper scriptHelper) {
        super( scriptHelper );
    }


    public void createbankaccounttransfernav() {
        isElementAvailable( taskmenu, ELEMENTTIMEOUT );
        driver.findElement( taskmenu ).click();

        isElementAvailable( createbanktransfer, ELEMENTTIMEOUT );
        driver.findElement( createbanktransfer ).click();
    }

    public void createbankacctransfer() {
        isElementAvailable( header, ELEMENTTIMEOUT );
        if ( !driver.findElement( header ).isDisplayed() ) {
            String stheader = driver.findElement( header ).getText();
            String staticheader = "Create Bank Account Transfer";
            Assert.assertEquals( "Header text validation", stheader, staticheader );
        }
        isElementAvailable( fromaccount, ELEMENTTIMEOUT );
        driver.findElement( fromaccount ).click();
        driver.findElement( fromaccount ).sendKeys( dataTable.getData( "General_Data", "From Account" ) );
        oracleObjectRender( QUERYRESPONSE );
        driver.findElement( ajaxValidate ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( toaccount, ELEMENTTIMEOUT );
        driver.findElement( toaccount ).click();
        driver.findElement( toaccount ).sendKeys( dataTable.getData( "General_Data", "To Account" ) );
        oracleObjectRender( QUERYRESPONSE );
        driver.findElement( ajaxValidate ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( businessunit, ELEMENTTIMEOUT );
        driver.findElement( businessunit ).click();
        PauseScript( 2 );
        driver.findElement( businessunit ).sendKeys( dataTable.getData( "General_Data", "Bank Business Unit" ) );
        driver.findElement( businessunit ).sendKeys( Keys.TAB );
        isElementAvailable( paymentmethod, ELEMENTTIMEOUT );
        driver.findElement( paymentmethod ).click();
        driver.findElement( paymentmethod ).sendKeys( dataTable.getData( "General_Data", "Payment Method" ) );
        driver.findElement( paymentmethod ).sendKeys( Keys.TAB );
        isElementAvailable( paymentprofile, ELEMENTTIMEOUT );
        driver.findElement( paymentprofile ).click();
        driver.findElement( paymentprofile ).sendKeys( dataTable.getData( "General_Data", "Payment Profile" ) );
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( transferamount, ELEMENTTIMEOUT );
        driver.findElement( transferamount ).click();
        driver.findElement( transferamount ).sendKeys( dataTable.getData( "General_Data", "Transfer Amount" ) );
        PauseScript( 2 );
        report.updateTestLog( "Verify the entered data for Bank Account Transfer", "Data entered has been completed for Bank Account Transfer", Status.PASS );
        isElementAvailable( btnsubmit, ELEMENTTIMEOUT );
        driver.findElement( btnsubmit ).click();
        oracleObjectRender( SCRIPTTIME );
        report.updateTestLog( "Verify the Bank Account Transfer", "Bank Account Transfer has been completed successfully", Status.PASS );
        isElementAvailable( btnyes, ELEMENTTIMEOUT );
        driver.findElement( btnyes ).click();
        oracleObjectRender( SCRIPTTIME );
    }


    public void createadhocpaymentnav() {
        isElementAvailable( taskmenu, ELEMENTTIMEOUT );
        driver.findElement( taskmenu ).click();

        isElementAvailable( createadhocpayment, ELEMENTTIMEOUT );
        driver.findElement( createadhocpayment ).click();
    }

    public void adhocpayment() {
        isElementAvailable( fromacct, ELEMENTTIMEOUT );
        driver.findElement( fromacct ).click();
        driver.findElement( fromacct ).sendKeys( dataTable.getData( "General_Data", "From Account" ) );
        driver.findElement( fromacct ).sendKeys( Keys.TAB );
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( payee, ELEMENTTIMEOUT );
        driver.findElement( payee ).click();
        driver.findElement( payee ).sendKeys( dataTable.getData( "General_Data", "Payee" ) );
        oracleObjectRender( SCRIPTTIME );
        driver.findElement( payee ).sendKeys( Keys.ENTER );
        oracleObjectRender(QUERYRESPONSE);
        isElementAvailable( payeeacct, ELEMENTTIMEOUT );
        driver.findElement( payeeacct ).click();
        driver.findElement( payeeacct ).sendKeys( dataTable.getData( "General_Data", "Payee Account" ) );
        PauseScript( 3 );
        driver.findElement( payeeacct ).sendKeys( Keys.ENTER );
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( paymentamt, ELEMENTTIMEOUT );
        driver.findElement( paymentamt ).sendKeys( dataTable.getData( "General_Data", "Payment Amount" ) );
        driver.findElement( paymentamt ).sendKeys( Keys.TAB );
        isElementAvailable( bussunit, ELEMENTTIMEOUT );
        driver.findElement( bussunit ).click();
        PauseScript( 2 );
        driver.findElement( bussunit ).sendKeys( dataTable.getData( "General_Data", "Bank Business Unit" ) );
        driver.findElement( bussunit ).sendKeys( Keys.TAB );
        isElementAvailable( paymentmthd, ELEMENTTIMEOUT );
        driver.findElement( paymentmthd ).click();
        driver.findElement( paymentmthd ).sendKeys( dataTable.getData( "General_Data", "Payment Method" ) );
        driver.findElement( paymentmthd ).sendKeys( Keys.TAB );
        isElementAvailable( paymtprof, ELEMENTTIMEOUT );
        driver.findElement( paymtprof ).click();
        driver.findElement( paymtprof ).sendKeys( dataTable.getData( "General_Data", "Payment Profile" ) );
        driver.findElement( paymtprof ).sendKeys( Keys.TAB );
        oracleObjectRender( SCRIPTTIME );
        report.updateTestLog( "Verify the entered data for Adhoc payment", "Data entered has been completed for Adhoc payment ", Status.PASS );
        isElementAvailable( btnSubmit, ELEMENTTIMEOUT );
        driver.findElement( btnSubmit ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( btnyes, ELEMENTTIMEOUT );
        driver.findElement( btnyes ).click();
        report.updateTestLog( "Verify the Adhoc payment", "Adhoc Payment has been completed successfully", Status.PASS );
        oracleObjectRender( SCRIPTTIME );
    }

}
