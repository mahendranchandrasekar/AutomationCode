package pages;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.ScriptHelper;
import com.cognizant.framework.Status;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.Select;

/**
 * Journals Page class
 */
public class LeaseCreatePage extends MasterPages {
    // UI Map object definitions

    // Elements
    private final By refreshButton = By.xpath( "//span[text()='Generate Invoices']/../../../../td[3]" );
    private final By CreateLeasePlusIcon = By.xpath( "//span[text()='Generate Invoices']/../../../../td[1]" );
    private final By leaseNumber = By.xpath( "//label[text()='Lease Number']/following::input[1]" );
    private final By leaseDescription = By.xpath( "//label[text()='Lease Description']/following::input[1]" );
    private final By categoryIcon = By.xpath( "//label[text()='Lease Description']/following::input[2]/../../following-sibling::td[2]/a/img" );
    private final By categoryDropdown = By.xpath( "//label[text()='Lease Description']/following::input[2]" );
    private final By paymentFrequencyDropdown = By.xpath( "//label[text()='Payment Frequency']/following::input[2]" );
    private final By paymentOptionDropdown = By.xpath( "//label[text()='Payment Option']/following::td[1]/span[1]/select[1]" );

    private final By majorCategoryDropdown = By.xpath( "//tr[contains(@id,'fixed_assets_additions:0:MAnt2:1:r1:1:AP2:kf1SPOP_query:criterion0')]/td[2]/table/tbody/tr[1]/td[1]/span/span/input" );
    private final By minorCategoryDropdown = By.xpath( "//tr[contains(@id,'fixed_assets_additions:0:MAnt2:1:r1:1:AP2:kf1SPOP_query:criterion1')]/td[2]/table/tbody/tr[1]/td[1]/span/span/input" );
    private final By categoryOkButton = By.xpath( "//td[contains(@id,'fixed_assets_additions:0:MAnt2:1:r1:1:AP2:kf1_kffSearchDialog::_fcc')]/span/button[3]" );
    private final By payableBusinessUnit = By.xpath( "//label[text()='Payables Business Unit']/following::input[1]" );
    private final By ajaxValidate = By.xpath( "//div[contains(@class,'AFDetectExpansion')]/../tbody/tr[1]/td[1]/ul[1]/li[1]" );
    private final By lessorDropdown = By.xpath( "//label[text()='Lessor']/following::input[1]" );
    private final By lessorSiteDropdown = By.xpath( "//label[text()='Lessor Site']/following::input[1]" );
    private final By lessorStartDate = By.xpath( "//label[text()='Lease Start Date']/following::input[1]" );
    private final By generatePaymentInvoice = By.xpath( "//label[text()='Generate Payment Invoices']/following::select[1]" );
    private final By bookDropdown = By.xpath( "//label[text()='Book']/following::select[1]" );
    private final By nonCancelableTerm = By.xpath( "//label[text()='Noncancelable Term']/following::input[1]" );
    private final By leaseClassification = By.xpath( "//label[text()='Lease Classification']/following::select[1]" );
    private final By oneTimePayments = By.xpath( "//a[text()='One Time Payments' and @id='_FOpt1:_FOr1:0:_FOSritemNode_fixed_assets_additions:0:MAnt2:1:r1:1:AP2:sdi2::disAcr']" );
    private final By recurringPayments = By.xpath( "//a[text()='Recurring Payments' and @id='_FOpt1:_FOr1:0:_FOSritemNode_fixed_assets_additions:0:MAnt2:1:r1:1:AP2:sdi1::disAcr']" );
    private final By paymentType = By.xpath( "//label[text()='Payment Type']/../select[1]" );
    private final By paymentDate = By.xpath( "//label[text()='Payment Date']/../input[1]" );
    private final By amount = By.xpath( "//label[text()='Amount']/../input[1]" );
    private final By recurrInterestRate = By.xpath( "//label[text()='Interest Rate']/../input[1]" );
    private final By recurrInterestDueDate = By.xpath( "//label[text()='Interest Due Date']/../input[1]" );
    private final By excludeFromLiability = By.xpath( "//input[contains(@id,'MAnt2:1:r1:1:AP2:TAB2:_ATp:t4:0:sbc11')]" );
    private final By generateSchedules = By.xpath( "//span[text()='enerate Schedules']" );
    private final By pendingTransactions = By.xpath( "//div[contains(@id,'fixed_assets_additions:0:MAnt2:1:r1:0:ap1:pt1::tabh::cbc')]/div[3]/div[1]/a" );
    private final By LeasesTab = By.xpath( "//div[contains(@id,'fixed_assets_additions:0:MAnt2:1:r1:0:ap1:pt1::tabh::cbc')]/div[1]/div[1]/a" );
    private final By searchTextBox = By.xpath( "//a[text()='Show Filters']/../../../../../../td[1]/table/tbody/tr/td[2]/input" );
    private final By searchIcon = By.xpath( "//a[text()='Show Filters']/../../../../../../td[4]/button" );

    private final By validatePendingTrxRecord = By.xpath("//div[contains(@id,'fixed_assets_additions:0:MAnt2:1:r1:0:ap1:ls2:lv4:0:li3')]");
    private final By validateLeaseNumberPendingTrx = By.xpath( "//*[contains(@id,'fixed_assets_additions:0:MAnt2:1:r1:0:ap1:ls2:lv4:0:cl5')]/span");
    private final By validateTimePeriodPendingTrx = By.xpath( "//div[contains(@id,'fixed_assets_additions:0:MAnt2:1:r1:0:ap1:ls2:lv4:0:li3')]/table/tbody/tr[1]/td[2]/div[1]/div[1]/table/tbody/tr" );
    private final By validateStatusPendingTrx = By.xpath( "//div[contains(@id,'fixed_assets_additions:0:MAnt2:1:r1:0:ap1:ls2:lv4:1:li3')]/table/tbody/tr[1]/td[4]/div[1]/div[1]/div[1]/child::*/child::*/child::*/child::*/child::*/child::*/tr[3]/td[2]/span" );
    private final By amortizationScheduleButton = By.xpath( "//button[text()='Amortization Schedule']" );
    private final By amortizationScheduleTable = By.xpath( "//div[contains(@id,'fixed_assets_additions:0:MAnt2:1:r1:1:AP2:dialog1::_ccntr')]" );
    private final By amortizationScheduleTableOKButton = By.xpath( "//td[contains(@id,'fixed_assets_additions:0:MAnt2:1:r1:1:AP2:dialog1::_fcc')]/button" );
    private final By submitButton = By.xpath( "//div[contains(@id,'fixed_assets_additions:0:MAnt2:1:r1:1:AP2:ctb2')]/a/span" );

    private final By amortizationScheduleTableLeaseAdv = By.xpath( "//table[@summary='Amortization Schedule']/tbody/tr[2]/td[4]/span" );
    private final By amortizationScheduleTableLeaseRecurr = By.xpath( "//table[@summary='Amortization Schedule']/tbody/tr[3]/td[4]/span" );

    private final By validateLeasesRecord = By.xpath( "//div[contains(@id,'fixed_assets_additions:0:MAnt2:0:r1:1:ap1:ls4:lv1:0:li1')]" );
    private final By validateLeaseNumberLeases = By.xpath( "//div[contains(@id,'fixed_assets_additions:0:MAnt2:0:r1:1:ap1:ls4:lv1:0:li1')]/table/tbody/tr[1]/td[1]/div[1]/div[1]/a/span" );
    private final By validateFromDateLeases = By.xpath( "//div[contains(@id,'fixed_assets_additions:0:MAnt2:0:r1:1:ap1:ls4:lv1:0:li1')]/table/tbody/tr[1]/td[2]/div[1]/div[1]/table/tbody/tr/td[3]/span" );
    private final By validateToDateLeases = By.xpath( "//div[contains(@id,'fixed_assets_additions:0:MAnt2:1:r1:0:ap1:ls4:lv1:2:li1')]/table/tbody/tr[1]/td[2]/div[1]/div[1]/table/tbody/tr/td[7]/span" );
    private final By validateLessorLeases = By.xpath( "//div[contains(@id,'fixed_assets_additions:0:MAnt2:0:r1:1:ap1:ls4:lv1:0:li1')]/table/tbody/tr[1]/td[2]/child::*/div[3]/child::*/child::*/child::*/child::*/child::*/table/tbody/tr[2]/td[2]" );
    private final By validateCostLeases = By.xpath( "//div[contains(@id,'fixed_assets_additions:0:MAnt2:0:r1:1:ap1:ls4:lv1:0:li1')]/table/tbody/tr[1]/td[3]/child::*/child::*/child::*/table/child::*/child::*/child::*/child::*/child::*/tr[2]/td[2]/span" );
    private final By validateLiabilityLeases = By.xpath( "//div[contains(@id,'fixed_assets_additions:0:MAnt2:0:r1:1:ap1:ls4:lv1:0:li1')]/table/tbody/tr[1]/td[3]/child::*/child::*/child::*/table/child::*/child::*/child::*/child::*/child::*/tr[3]/td[2]/span" );


    //Page Sync Config
    // page loading time
    public static final int PAGELOADTIMEOUT = 90;
    // individual element load time
    public static final int ELEMENTTIMEOUT = 60;
    // Oracle query response
    public static final long QUERYRESPONSE = 15;
    // object render script
    public static final long SCRIPTTIME = 5;


    /**
     * Constructor to initialize the page
     *
     * @param scriptHelper The {@link ScriptHelper} object passed from the
     *                     {@link DriverScript}b  n '/fg .+
     */

    public LeaseCreatePage(ScriptHelper scriptHelper) {
        super( scriptHelper );
        isElementAvailable( refreshButton, PAGELOADTIMEOUT );

    }


    public void createLeases() {
        isElementAvailable( refreshButton, PAGELOADTIMEOUT );
        driver.findElement( refreshButton ).click();
        report.updateTestLog( "Manage Leases page", "The Landing page is Manage Leases page", Status.PASS );
        isElementAvailable( CreateLeasePlusIcon, ELEMENTTIMEOUT );
        driver.findElement( CreateLeasePlusIcon ).click();
        isElementAvailable( leaseNumber, PAGELOADTIMEOUT );
        driver.findElement( leaseNumber ).sendKeys( dataTable.getData( "General_Data", "LeaseNumber" ) );
        report.updateTestLog( "Create Leases page", "The Landing page is Create Leases page", Status.PASS );
        isElementAvailable( leaseDescription, ELEMENTTIMEOUT );
        driver.findElement( leaseDescription ).sendKeys( dataTable.getData( "General_Data", "LeaseDescription" ) );
        isElementAvailable( categoryIcon, ELEMENTTIMEOUT );
        driver.findElement( categoryIcon ).click();
        oracleObjectRender( QUERYRESPONSE );
        isElementAvailable( majorCategoryDropdown, PAGELOADTIMEOUT );
        driver.findElement( majorCategoryDropdown ).sendKeys( dataTable.getData( "General_Data", "MajorCategory" ) );
        driver.findElement( majorCategoryDropdown ).sendKeys( Keys.TAB );
        oracleObjectRender( QUERYRESPONSE );
        isElementAvailable( minorCategoryDropdown, ELEMENTTIMEOUT );
        driver.findElement( minorCategoryDropdown ).sendKeys( dataTable.getData( "General_Data", "MinorCategory" ) );
        driver.findElement( majorCategoryDropdown ).sendKeys( Keys.TAB );
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( categoryOkButton, ELEMENTTIMEOUT );
        driver.findElement( categoryOkButton ).click();
        oracleObjectRender( QUERYRESPONSE );
        isElementAvailable( payableBusinessUnit, ELEMENTTIMEOUT );
        driver.findElement( payableBusinessUnit ).sendKeys( dataTable.getData( "General_Data", "PayablesBuisnessUnit" ) );
        oracleObjectRender( QUERYRESPONSE );
        driver.findElement( ajaxValidate ).click();
        oracleObjectRender( SCRIPTTIME );

        isElementAvailable( lessorDropdown, ELEMENTTIMEOUT );
        driver.findElement( lessorDropdown ).sendKeys( dataTable.getData( "General_Data", "Lessor" ) );
        oracleObjectRender( QUERYRESPONSE );
        driver.findElement( ajaxValidate ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( lessorSiteDropdown, ELEMENTTIMEOUT );
        driver.findElement( lessorSiteDropdown ).sendKeys( dataTable.getData( "General_Data", "LessorSite" ) );
        oracleObjectRender( QUERYRESPONSE );
        driver.findElement( ajaxValidate ).click();
        isElementAvailable( lessorStartDate, ELEMENTTIMEOUT );
        driver.findElement( lessorStartDate ).sendKeys( dataTable.getData( "General_Data", "LeaseStartDate" ) );
        isElementAvailable( generatePaymentInvoice, ELEMENTTIMEOUT );
        Select selectDropDownGeneratePayInvoice = new Select( driver.findElement( generatePaymentInvoice ) );
        selectDropDownGeneratePayInvoice.selectByVisibleText( dataTable.getData( "General_Data", "GeneratePaymentInvoices" ) );
        report.updateTestLog( "Create Leases Section", "The user should be able to enter the valid for create Leases Section ", Status.PASS );

        isElementAvailable( bookDropdown, ELEMENTTIMEOUT );
        Select selectDropDownBook = new Select( driver.findElement( bookDropdown ) );
        selectDropDownBook.selectByVisibleText( dataTable.getData( "General_Data", "Book" ) );
        isElementAvailable( nonCancelableTerm, ELEMENTTIMEOUT );
        oracleObjectRender( QUERYRESPONSE );
        driver.findElement( nonCancelableTerm ).sendKeys( dataTable.getData( "General_Data", "NonCancelableTerm" ) );
        oracleObjectRender( QUERYRESPONSE );
        isElementAvailable( leaseClassification, ELEMENTTIMEOUT );
        Select selectDropDownLeaseClassified = new Select( driver.findElement( leaseClassification ) );
        selectDropDownLeaseClassified.selectByVisibleText( dataTable.getData( "General_Data", "LeaseClassification" ) );
        report.updateTestLog( "Financial Term Section", "The user should be able to enter the valid for Financial Term Section", Status.PASS );

        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( oneTimePayments, ELEMENTTIMEOUT );
        driver.findElement( oneTimePayments ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( paymentType, ELEMENTTIMEOUT );
        Select selectDropDownPaymentType = new Select( driver.findElement( paymentType ) );
        selectDropDownPaymentType.selectByVisibleText( dataTable.getData( "General_Data", "OneTimePaymentType" ) );
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( paymentDate, ELEMENTTIMEOUT );
        driver.findElement( paymentDate ).clear();
        driver.findElement( paymentDate ).sendKeys( dataTable.getData( "General_Data", "OneTimePaymentDate" ) );
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( amount, ELEMENTTIMEOUT );
        driver.findElement( amount ).clear();
        oracleObjectRender( SCRIPTTIME );
        driver.findElement( amount ).sendKeys( dataTable.getData( "General_Data", "OneTimeAmount" ) );
        oracleObjectRender( QUERYRESPONSE );
        report.updateTestLog( "Financial Term - One Time Payments", "The user should be able to enter the valid for Financial Term  - One Time Payments", Status.PASS );

        isElementAvailable( recurringPayments, ELEMENTTIMEOUT );
        driver.findElement( recurringPayments ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( paymentType, ELEMENTTIMEOUT );
        Select selectDropDownRecurringPaymentType = new Select( driver.findElement( paymentType ) );
        String RecurringPaymentTypeData = dataTable.getData( "General_Data", "RecurringPaymentType" );
        selectDropDownRecurringPaymentType.selectByVisibleText( RecurringPaymentTypeData );
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( amount, ELEMENTTIMEOUT );
        driver.findElement( amount ).clear();
        oracleObjectRender( SCRIPTTIME );
        driver.findElement( amount ).sendKeys( dataTable.getData( "General_Data", "RecurringAmount" ) );
        isElementAvailable( recurrInterestRate, ELEMENTTIMEOUT );
        driver.findElement( recurrInterestRate ).clear();
        driver.findElement( recurrInterestRate ).sendKeys( dataTable.getData( "General_Data", "RecurringInterestDate" ) );
        oracleObjectRender( QUERYRESPONSE );
        report.updateTestLog( "Financial Term - Recurring Payments", "The user should be able to enter the valid for Financial Term  - Recurring Payments", Status.PASS );

        isElementAvailable( generateSchedules, ELEMENTTIMEOUT );
        driver.findElement( generateSchedules ).click();
        report.updateTestLog( "Generate Schedules", "The user should be able to Generate Schedules", Status.PASS );
        oracleObjectRender( QUERYRESPONSE );
        isElementAvailable( refreshButton, PAGELOADTIMEOUT );
        driver.findElement( refreshButton ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( pendingTransactions, ELEMENTTIMEOUT );
        driver.findElement( pendingTransactions ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( searchTextBox, PAGELOADTIMEOUT );
        driver.findElement( searchTextBox ).clear();
        oracleObjectRender( SCRIPTTIME );
        driver.findElement( searchTextBox ).sendKeys( dataTable.getData( "General_Data", "LeaseNumber" ) );
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( searchIcon, ELEMENTTIMEOUT );
        driver.findElement( searchIcon ).click();
        oracleObjectRender( QUERYRESPONSE );

        try {
            if ( driver.findElement( validatePendingTrxRecord ).isDisplayed() ) {
                oracleObjectRender( QUERYRESPONSE );
                report.updateTestLog( "Pending Transactions", "The user should be able to view the Lease record in Pending Transaction", Status.PASS );
            }
        } catch (Exception e) {
            report.updateTestLog( "Pending Transactions", "The user is not able to view the Lease record in Pending Transaction", Status.FAIL );
        }
        oracleObjectRender( QUERYRESPONSE );
        isElementAvailable(validateLeaseNumberPendingTrx, ELEMENTTIMEOUT );
        driver.findElement(validateLeaseNumberPendingTrx).click();
        oracleObjectRender(QUERYRESPONSE); oracleObjectRender(SCRIPTTIME);
        isElementAvailable(amortizationScheduleButton, PAGELOADTIMEOUT );
        driver.findElement(amortizationScheduleButton).click();
        oracleObjectRender(QUERYRESPONSE); oracleObjectRender(SCRIPTTIME);
        try {
            if ( driver.findElement( amortizationScheduleTable ).isDisplayed() ) {
                oracleObjectRender( QUERYRESPONSE );
                Assert.assertEquals( driver.findElement( amortizationScheduleTableLeaseAdv ).getAttribute( "innerHTML" ), (dataTable.getData( "General_Data", "OneTimeAmount" )) );
                Assert.assertEquals( driver.findElement( amortizationScheduleTableLeaseRecurr ).getAttribute( "innerHTML" ), (dataTable.getData( "General_Data", "RecurringAmount" )) );
                isElementAvailable( amortizationScheduleTableOKButton, ELEMENTTIMEOUT );
                driver.findElement( amortizationScheduleTableOKButton ).click();
                report.updateTestLog( "Verify the Amortization Schedule Advance & Recurring Amount", " Amortization Schedule Advance and Recurring Amount has been verified", Status.PASS );
            }
        } catch (Exception e) {
            report.updateTestLog( "Verify the Amortization Schedule Advance & Recurring Amount", " Amortization Schedule Advance and Recurring Amount has not verified", Status.FAIL );
        }
        oracleObjectRender( QUERYRESPONSE );
        isElementAvailable( submitButton, ELEMENTTIMEOUT );
        driver.findElement( submitButton ).click();
        oracleObjectRender( QUERYRESPONSE );
        isElementAvailable( LeasesTab, PAGELOADTIMEOUT );
        driver.findElement( LeasesTab ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( searchTextBox, PAGELOADTIMEOUT );
        driver.findElement( searchTextBox ).clear();
        oracleObjectRender( SCRIPTTIME );
        driver.findElement( searchTextBox ).sendKeys( dataTable.getData( "General_Data", "LeaseNumber" ) );
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( searchIcon, ELEMENTTIMEOUT );
        driver.findElement( searchIcon ).click();
        oracleObjectRender( SCRIPTTIME );
        report.updateTestLog( "Leases Transactions", "The user should be able to verify the Leases transaction successfully", Status.PASS );

    }
}