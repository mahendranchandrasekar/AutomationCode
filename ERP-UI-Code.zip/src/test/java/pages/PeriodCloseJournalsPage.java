package pages;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.ScriptHelper;
import com.cognizant.framework.ExcelDataImport;
import com.cognizant.framework.Status;
import org.openqa.selenium.By;

/**
 * Journals Page class
 */
public class PeriodCloseJournalsPage extends MasterPages {
	// UI Map object definitions

	// Elements


	private final By generalLedgerLink = By.xpath("//div[contains(@id,'close:0:_FOTsr1:0:pt1:r1:0:ph1:r2:0:pgl12')]/div[2]/span");
	private final By openPeriodButton = By.xpath("//span[contains(text(),'Open Period')]");
	private final By closePeriodButton = By.xpath("//span[contains(text(),'Close Period')]");
	private final By popUpYesButton = By.xpath("//button[contains(@id,'close:0:_FOTsr1:0:pt1:r1:1:ap1:d1341::yes')]");
    private final By popUpWarningForClosePeriod = By.xpath("//td[contains(text(),'The application Payables, Receivables period isn')]");
	private final By doneButton = By.xpath("//div[contains(@id,'accounting_period_close:0:_FOTsr1:0:pt1:r1:1:ap1:SPb')]/a");


	//Page Sync Config

	// page loading time
	public static final int PAGELOADTIMEOUT = 90;
	// individual element load time
	public static final int ELEMENTTIMEOUT = 60;
	// Oracle query response
	public static final long QUERYRESPONSE = 15;
	// object render script
	public static final long SCRIPTTIME = 5;

	/**
	 * Constructor to initialize the page
	 *
	 * @param scriptHelper The {@link ScriptHelper} object passed from the
	 *                     {@link DriverScript}b  n '/fg .+
	 */
	public PeriodCloseJournalsPage(ScriptHelper scriptHelper) {
		super(scriptHelper);
		isElementAvailable(generalLedgerLink, PAGELOADTIMEOUT);
	}


	public void openPeriodForJournal() {
		isElementAvailable(generalLedgerLink, PAGELOADTIMEOUT);
		driver.findElement(generalLedgerLink).click();
		report.updateTestLog("The  Accounting Period Status page is opened", "The Accounting  Period Status page is opened", Status.PASS);
		String journalBatchData = dataTable.getData(ExcelDataImport.GeneralData, "OpenPeriod");
		String openPeriod = "//span[contains(text(),'" + journalBatchData + "')]";
		By ddgenericXpathForSelection = By.xpath(openPeriod);
		isElementAvailable(ddgenericXpathForSelection, PAGELOADTIMEOUT);
		driver.findElement(ddgenericXpathForSelection).click();
		oracleObjectRender(QUERYRESPONSE);
		report.updateTestLog("The Open Period button is enabled", "The Open Period button is enabled", Status.PASS);
		driver.findElement(openPeriodButton).click();
		oracleObjectRender(QUERYRESPONSE);
		report.updateTestLog("The Open Period Confirmation window", "The Open Period Confirmation window is displayed", Status.PASS);
		try {
			if(driver.findElement(popUpYesButton).isDisplayed()) {
				oracleObjectRender(QUERYRESPONSE);
				isElementAvailable(popUpYesButton, ELEMENTTIMEOUT);
				driver.findElement(popUpYesButton).click();
			}
		} catch(Exception e){
			report.updateTestLog("Open Period Confirmation", "The Open Period Confirmation window is displayed", Status.PASS);
		}
		isElementAvailable(doneButton, ELEMENTTIMEOUT);
		driver.findElement(doneButton).click();
	}

	public void closePeriodForJournal() {
		isElementAvailable(generalLedgerLink, PAGELOADTIMEOUT);
		driver.findElement(generalLedgerLink).click();
		report.updateTestLog("The Accounting Period Status page is opened", "The Accounting Period Status page is opened", Status.PASS);
		String journalBatchData = dataTable.getData(ExcelDataImport.GeneralData, "ClosePeriod");
		String closePeriod = "//span[contains(text(),'" + journalBatchData + "')]";
		By ddgenericXpathForSelection = By.xpath(closePeriod);
		isElementAvailable(ddgenericXpathForSelection, PAGELOADTIMEOUT);
		driver.findElement(ddgenericXpathForSelection).click();
		oracleObjectRender(QUERYRESPONSE);
		report.updateTestLog("The Close Period button is enabled", "The Close Period button is enabled", Status.PASS);
		isElementAvailable(closePeriodButton, ELEMENTTIMEOUT);
		driver.findElement(closePeriodButton).click();
		oracleObjectRender(QUERYRESPONSE);
		try {
			if(driver.findElement(popUpWarningForClosePeriod).isDisplayed()) {
				isElementAvailable(popUpYesButton, ELEMENTTIMEOUT);
				driver.findElement(popUpYesButton).click();
			}
		} catch(Exception e){
			report.updateTestLog("Close Period Confirmation", "The Close Period Confirmation window is not displayed", Status.PASS);
		}
		report.updateTestLog("The Close Period Confirmation window", "The Close Period Confirmation window is displayed", Status.PASS);
		isElementAvailable(doneButton, ELEMENTTIMEOUT);
		driver.findElement(doneButton).click();

	}

	}




