package pages;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.ScriptHelper;
import com.cognizant.framework.Status;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.util.List;

public class AssetCaptilisationPage extends MasterPages {

    // Elements

    //Links
    private final By navigator = By.xpath( "//a[@title='Navigator']" );
    private final By taskmenu = By.xpath( "//img[@title='Tasks']" );
    //private final By managecapitalprojects = By.xpath( "//a[text()='Manage Capital Projects'] [@class='xmg']" );
    private final By managecapitalprojects = By.xpath("//a[text()='Manage Capital Projects']");
    private final By transferassetstooraclefusionassets = By.xpath( "//a[text()='Transfer Assets to Oracle Fusion Assets']" );
    private final By scheduleprocess = By.xpath( "//a[contains(@id,'Node_tools_scheduled_processes_fuse_plus')] [@class='xnt xms']" );
    private final By homeicon = By.xpath( "//a[@id='_FOpt1:_UIScil1u']" );
    private final By projecticon = By.xpath( "//div[contains(@id,'projects_projects::disAcr')]");
    private final By toolsicon = By.xpath( "//*[contains(@id,'groupNode_tools_20')]" );
    private final By scheduleprocessicon = By.xpath( "//a[@id='itemNode_tools_scheduled_processes_fuse_plus_5']" );

    private final By businessunit = By.xpath( "//label[text()='Business Unit']/ancestor::tr[1]/td[2]//input" );
    private final By projectname = By.xpath( "//label[text()='Project Name']/ancestor::tr[1]/td[2]//input" );
    private final By projectnumber = By.xpath( "//label[text()='Project Number']/ancestor::tr[1]/td[2]//input" );

    private final By manageprojectsearchresultselect = By.xpath( "//table[@summary='Manage Capital Projects']/tbody/tr[1]" );
    private final By actiondrpdwn = By.xpath( "//*[contains(@id,'ATp:ATm')]/div/table/tbody/tr/td[3]/div" );
    private final By managecaptialevents = By.xpath( "//*[text()='Manage Capital Events']" );
    private final By eventname = By.xpath( "//input[contains(@id,'it5::content')]" );
    private final By manageeventassets = By.xpath( "//*[text()='Manage Event Assets']" );
    private final By managecapitalassets = By.xpath( "//*[text()='Manage Capital Assets']" );
    private final By manageeventcosts = By.xpath( "//*[text()='Manage Event Costs']" );
    private final By generateassetlines = By.xpath( "//*[text()='Generate Asset Lines']" );
    private final By manageassetlines = By.xpath( "//*[text()='Manage Asset Lines']" );


    private final By assetname = By.xpath( "//input[contains(@id,':inputText1::content')]" );
    private final By assettype = By.xpath( "//*[contains(@id,'projectAssetTypeId')]//select" );
    private final By servicedate = By.xpath( "//*[contains(@id,'inputDate2::content')]" );
    private final By assetdescription = By.xpath( "//*[contains(@id,':assetDescriptionId::content')]" );
    private final By assetbook = By.xpath( "//*[contains(@id,':bookTypeNameId::content')]" );
    private final By assetcategory = By.xpath( "//*[contains(@id,':0:kf1CS::content')]" );
    private final By assetkey = By.xpath( "//*[contains(@id,'p:t1:0:kf3CS::content')]" );
    private final By assetnumber = By.xpath( "//*[contains(@id,'inputText8::content')]" );
    private final By actualunits = By.xpath( "//*[contains(@id,':inputText9::content')]" );
    private final By assetdetailslink = By.xpath( "//*[contains(@id,'np1:AssetDetailsLinkId')]" );
    private final By capitalizationDetailsLink = By.xpath( "//*[contains(@id,'CapitalizationDetailsLinkId')]" );

    //Warning pop up
    private final By warnmessage = By.xpath( "//*[contains(@id,'projects_assets:0:MAt2:0:pt1:Capit1:1:AP1:AT1:pgl3')]/div" );
    private final By warnbtnOk = By.xpath( "//button[contains(@id,'projects_assets:0:MAt2:0:pt1:Capit1:1:AP1:AT1:cb7')]" );
    private final By warnmessagerejected = By.xpath( "//*[contains(@id,'FOd1::msgDlg::_cnt')]/div/table/tbody/tr/td/table/tbody/tr/td[2]/div/span" );
    private final By warnmessagerejectedbtnOk = By.xpath( "//*[contains(@id,'msgDlg::cancel')]" );
    //Manageevent
    private final By searchresultsforassets = By.xpath( "//table[@summary='Select and Add: Assets']/tbody/tr[1]" );
    private final By searchresultsforcosts = By.xpath( "//table[@summary='Select and Add: Costs']/tbody/tr[1]" );
    //Transfer Assets
    private final By fromprojectnumber = By.xpath( "//label[text()='From Project Number']/ancestor::tr[1]/td[2]//input" );
    private final By toprojectnumber = By.xpath( "//label[text()='To Project Number']/ancestor::tr[1]/td[2]//input" );
    private final By btnsubmit = By.xpath( "//*[@accesskey='m']" );
    //Schedule process
    private final By processID = By.xpath( "//label[text()='Process ID']/ancestor::tr[1]/td[2]//input" );
    private final By processIDSearchresults = By.xpath( "//table[@summary='List of Processes Meeting Search Criteria']/tbody/tr[1]/td[2]" );
    private final By processmessage = By.xpath( "//span[contains(@id,'1:requestBtns:confirmationPopup:pt_ol1')]" );
    private final By processpopupbtnOk = By.xpath( "//button[contains(@id,'requestBtns:confirmationPopup:confirmSubmitDialog::ok')]" );
    private final By searchheader = By.xpath( "//h1[text()='Search']" );
    private final By expandsearch = By.xpath( "//*[@title='Expand Search']" );
    private final By collapsesearch = By.xpath( "//*[@title='Collapse Search']" );
    //Assets Selection
    private final By filterIcon = By.xpath( "//img[@title='Query By Example']" );
    private final By assetnamefilter = By.xpath( "//*[contains(@id,'ATp_afr_t1_afr_column2::content')]" );

    //Updateassetsfromoracle
    private final By updateAssetsInformationfromOracleFusionAssets = By.xpath( "//a[text()='Update Assets Information from Oracle Fusion Assets']" );

    //button
    private final By btnassignassets = By.xpath( "//span[text()='Assign Assets']" );
    private final By assetsselectionforassigningtoproject = By.xpath( "//table[@summary='Manage Capital Assets: Oracle Phase 3 ']/tbody/tr[1]/td[1]" );
    private final By btnradioproject = By.xpath( "//label[text()='Project']" );
    private final By btnadvancesearch = By.xpath( "//*[@accesskey='d']" );
    private final By btnbasicsearch = By.xpath( "//*[@accesskey='B']" );
    private final By btnsearch = By.xpath( "//button[text()='Search']" );
    private final By btncancel = By.xpath( "//*[@accesskey='C']" );
    private final By btnplusicon = By.xpath( "//*[contains(@id,'ATp:create::icon')]" );
    private final By btnsavenclose = By.xpath( "//*[@accesskey='S']" );
    private final By btnsave = By.xpath( "//span[text()='Save']" );
    private final By btndone = By.xpath( "//*[@accesskey='o']" );
    private final By btnoK = By.xpath( "//*[@accesskey='K']" );
    private final By manageeventassetplusicon = By.xpath( "//img[@alt='Select and Add']" );

    // page loading time
    public static final int PAGELOADTIMEOUT = 90;
    // individual element load time
    public static final int ELEMENTTIMEOUT = 60;
    // Oracle query response
    public static final long QUERYRESPONSE = 15;
    // object render script
    public static final int SCRIPTTIME = 5;

    /**
     * Constructor to initialize the functional library
     *
     * @param scriptHelper The {@link ScriptHelper} object passed from the
     *                     {@link DriverScript}
     */
    public AssetCaptilisationPage(ScriptHelper scriptHelper) {
        super( scriptHelper );
    }

    //Navigations
    public void managecapitalprojectsnav() {
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( taskmenu, ELEMENTTIMEOUT );
        driver.findElement( taskmenu ).click();

        isElementAvailable( managecapitalprojects, ELEMENTTIMEOUT );
        driver.findElement( managecapitalprojects ).click();
    }

    public void transferassetstooraclefusionassetsnav() {
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( taskmenu, ELEMENTTIMEOUT );
        driver.findElement( taskmenu ).click();

        isElementAvailable( transferassetstooraclefusionassets, ELEMENTTIMEOUT );
        driver.findElement( transferassetstooraclefusionassets ).click();
    }

    private void scheduleprocessnav() {
        isElementAvailable( homeicon, ELEMENTTIMEOUT );
        driver.findElement( homeicon ).click();
        PauseScript( 6 );
        isElementAvailable( toolsicon, ELEMENTTIMEOUT );
        driver.findElement( toolsicon ).click();
        PauseScript( 3 );
        isElementAvailable( scheduleprocessicon, ELEMENTTIMEOUT );
        driver.findElement( scheduleprocessicon ).click();
    }



    public void updateAssetsInformationfromOracleFusionAssetsnav() {
        isElementAvailable( taskmenu, ELEMENTTIMEOUT );
        driver.findElement( taskmenu ).click();

        isElementAvailable( updateAssetsInformationfromOracleFusionAssets, ELEMENTTIMEOUT );
        driver.findElement( updateAssetsInformationfromOracleFusionAssets ).click();
    }


    //Method to re-use
    private void clickonsearch() {
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( searchheader, ELEMENTTIMEOUT );
        if ( driver.findElement( expandsearch ).isDisplayed() ) {
            driver.findElement( expandsearch ).click();
            oracleObjectRender( SCRIPTTIME );
        } else {
            driver.findElement( expandsearch ).click();
        }
    }

    private void searchprojects() {
        isElementAvailable( projectname, ELEMENTTIMEOUT );
        driver.findElement( projectname ).click();
        driver.findElement( projectname ).clear();
        driver.findElement( projectname ).sendKeys( dataTable.getData( "General_Data", "Project Name" ) );
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( btnsearch, ELEMENTTIMEOUT );
        driver.findElement( btnsearch ).click();
        oracleObjectRender( SCRIPTTIME );
    }

    private void selecttheprojectfromsearchresultss() {
        isElementAvailable( manageprojectsearchresultselect, ELEMENTTIMEOUT );
        driver.findElement( manageprojectsearchresultselect ).click();
        oracleObjectRender( SCRIPTTIME );
        report.updateTestLog( "Verify the project number", " Project number displayed from search results", Status.PASS );
    }

    private void clickonaction() {
        isElementAvailable( actiondrpdwn, ELEMENTTIMEOUT );
        driver.findElement( actiondrpdwn ).click();
        PauseScript( 2 );
    }

    private void clickonManagecaptialassets() {
        isElementAvailable( managecapitalassets, ELEMENTTIMEOUT );
        driver.findElement( managecapitalassets ).click();
        report.updateTestLog( "Verify the Manage Capital Asset", " Manage Capital Asset selected Successfully", Status.PASS );
        oracleObjectRender( SCRIPTTIME );
    }

    private void clickonManagecaptialevents() {
        isElementAvailable( managecaptialevents, ELEMENTTIMEOUT );
        driver.findElement( managecaptialevents ).click();
        report.updateTestLog( "Verify the Manage Capital Events", " Manage Capital Event selected Successfully", Status.PASS );
        oracleObjectRender( SCRIPTTIME );
    }

    private void clickonplusicontocreate() {
        isElementAvailable( btnplusicon, ELEMENTTIMEOUT );
        driver.findElement( btnplusicon ).click();
        oracleObjectRender( QUERYRESPONSE );
    }

    private void clickonplusiconformanageEventasset() {
        isElementAvailable( manageeventassetplusicon, ELEMENTTIMEOUT );
        driver.findElement( manageeventassetplusicon ).click();
        oracleObjectRender( QUERYRESPONSE );
    }


    private void entertheAssetshellinformation() {
        isElementAvailable( assetname, ELEMENTTIMEOUT );
        driver.findElement( assetname ).click();
        driver.findElement( assetname ).sendKeys( dataTable.getData( "General_Data", "AssetName" ) );
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( assettype, ELEMENTTIMEOUT );
        Select drpassettype = new Select( driver.findElement( assettype ) );
        drpassettype.selectByVisibleText( dataTable.getData( "General_Data", "Project Asset Type" ) );
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( servicedate, ELEMENTTIMEOUT );
        driver.findElement( servicedate ).click();
        driver.findElement( servicedate ).sendKeys( dataTable.getData( "General_Data", "Service Date" ) );
        PauseScript( 3 );
        driver.findElement( servicedate ).sendKeys( Keys.TAB );
        isElementAvailable( assetdescription, ELEMENTTIMEOUT );
        driver.findElement( assetdescription ).click();
        driver.findElement( assetdescription ).sendKeys( dataTable.getData( "General_Data", "Asset Description" ) );
        PauseScript( 3 );
        report.updateTestLog( "Data Captured on Asset shell info", " Data updated succcessfully", Status.PASS );
        driver.findElement( assetdetailslink ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( actualunits, ELEMENTTIMEOUT );
        driver.findElement( actualunits ).sendKeys( dataTable.getData( "General_Data", "Actual Units" ) );
        oracleObjectRender(QUERYRESPONSE); oracleObjectRender( SCRIPTTIME );
        isElementAvailable( btnsave, ELEMENTTIMEOUT );
        driver.findElement( btnsave ).click();
        oracleObjectRender(QUERYRESPONSE);
        if ( driver.findElement(warnmessage).isDisplayed() ) {
            driver.findElement( warnbtnOk ).click();
            oracleObjectRender(QUERYRESPONSE);
            isElementAvailable( btnsave, ELEMENTTIMEOUT );
            driver.findElement( btnsave ).click();
            oracleObjectRender( SCRIPTTIME );
        } else {
            oracleObjectRender( SCRIPTTIME );
            System.out.println( "Warn : Rejected messsage not displayed" );
        }
    }

    private void backtocaptilizationlinkandselecttheaddedasset() {
        isElementAvailable( capitalizationDetailsLink, ELEMENTTIMEOUT );
        driver.findElement( capitalizationDetailsLink ).click();
        oracleObjectRender(SCRIPTTIME);
        isElementAvailable(filterIcon, ELEMENTTIMEOUT );
        driver.findElement(filterIcon).click();

        oracleObjectRender(QUERYRESPONSE);
        while (driver.findElements( filterIcon ).size() >= 1) {
            driver.findElement( filterIcon ).click();
            oracleObjectRender( SCRIPTTIME );
            if ( driver.findElements( assetnamefilter ).size() >= 1 )
                break;
        }
        oracleObjectRender(QUERYRESPONSE);
        isElementAvailable( assetnamefilter, ELEMENTTIMEOUT );
        driver.findElement( assetnamefilter ).click();
        driver.findElement( assetnamefilter ).sendKeys( dataTable.getData( "General_Data", "AssetName" ) );
        driver.findElement( assetnamefilter ).sendKeys( Keys.ENTER );
        oracleObjectRender( SCRIPTTIME );
    }

    private void clickonsaveNclose() {
        isElementAvailable( btnsavenclose, ELEMENTTIMEOUT );
        driver.findElement( btnsavenclose ).click();
        oracleObjectRender( QUERYRESPONSE );
    }

    private void warningmessage() {
        if ( driver.findElement( warnmessagerejectedbtnOk ).isDisplayed() ) {
            driver.findElement( warnmessagerejectedbtnOk ).click();
            oracleObjectRender( SCRIPTTIME );
            isElementAvailable( btnsavenclose, ELEMENTTIMEOUT );
            driver.findElement( btnsavenclose ).click();
            oracleObjectRender( QUERYRESPONSE );
        } else {
            System.out.println( "Warning Message not displayed" );
        }
    }

    private void assigntheassetonprojectlevel() {
        isElementAvailable( btnassignassets, ELEMENTTIMEOUT );
        driver.findElement( btnassignassets ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( btnradioproject, ELEMENTTIMEOUT );
        driver.findElement( btnradioproject ).click();
        report.updateTestLog( "Verify the asset on Project Level", " Asset Assigned to Project level", Status.PASS );
        oracleObjectRender( SCRIPTTIME );
        clickonsaveNclose();
    }

    private void entertheEventname() {
        isElementAvailable( eventname, ELEMENTTIMEOUT );
        driver.findElement( eventname ).click();
        driver.findElement( eventname ).sendKeys( dataTable.getData( "General_Data", "Event Name" ) );
        oracleObjectRender( SCRIPTTIME );
        report.updateTestLog( "Data Captured foe Event name", " Data updated succcessfully", Status.PASS );
        isElementAvailable( btnsave, ELEMENTTIMEOUT );
        driver.findElement( btnsave ).click();
        oracleObjectRender( SCRIPTTIME );
    }

    private void clickonManageEventassets() {
        isElementAvailable( manageeventassets, ELEMENTTIMEOUT );
        driver.findElement( manageeventassets ).click();
        report.updateTestLog( "Verify the Manage Event Asset", " Manage Event Asset selected Successfully", Status.PASS );
        oracleObjectRender( SCRIPTTIME );
    }

    private void searchandaddassets() {
        isElementAvailable( btnsearch, ELEMENTTIMEOUT );
        driver.findElement( btnsearch ).click();
        oracleObjectRender( SCRIPTTIME );
        if ( driver.findElement( searchresultsforassets ).isDisplayed() ) {
            driver.findElement( searchresultsforassets ).click();
            report.updateTestLog( "Verify the Search", "  Asset displayed Successfully", Status.PASS );
            oracleObjectRender( SCRIPTTIME );
            driver.findElement( btnoK ).click();
            oracleObjectRender( SCRIPTTIME );
        } else {
            //Search Assets
            System.out.println( "Data not found" );
        }

    }

    private void searchandaddcosts() {
        isElementAvailable( btnsearch, ELEMENTTIMEOUT );
        driver.findElement( btnsearch ).click();
        oracleObjectRender( SCRIPTTIME );
        if ( driver.findElement( searchresultsforcosts ).isDisplayed() ) {
            driver.findElement( searchresultsforcosts ).click();
            report.updateTestLog( "Verify the Search", "Cost displayed Successfully", Status.PASS );
            oracleObjectRender( SCRIPTTIME );
            driver.findElement( btnoK ).click();
            oracleObjectRender( SCRIPTTIME );
        } else {
            //Search Assets
            System.out.println( "Data not found" );
        }

    }

    private void clickonManageEventcost() {
        isElementAvailable( manageeventcosts, ELEMENTTIMEOUT );
        driver.findElement( manageeventcosts ).click();
        report.updateTestLog( "Verify the Manage Event Cost", " Manage Event Cost Selected", Status.PASS );
        oracleObjectRender( SCRIPTTIME );
    }

    private void clickonGenerateassetines() {
        isElementAvailable( generateassetlines, ELEMENTTIMEOUT );
        driver.findElement( generateassetlines ).click();
        report.updateTestLog( "Verify the Generate Asset line", "Asset Lines generated Successfully", Status.PASS );
        oracleObjectRender( SCRIPTTIME );
    }

    private void clickonManageAssetlines() {
        isElementAvailable( manageassetlines, ELEMENTTIMEOUT );
        driver.findElement( manageassetlines ).click();
        oracleObjectRender( SCRIPTTIME );
    }


    private void entertherequireddetailsonparameter() {
        oracleObjectRender( QUERYRESPONSE );
        isElementAvailable( businessunit, ELEMENTTIMEOUT );
        driver.findElement( businessunit ).click();
        driver.findElement( businessunit ).sendKeys( dataTable.getData( "General_Data", "Business Unit" ) );
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( fromprojectnumber, ELEMENTTIMEOUT );
        driver.findElement( fromprojectnumber ).click();
        driver.findElement( fromprojectnumber ).sendKeys( dataTable.getData( "General_Data", "From Project Number" ) );
        isElementAvailable( toprojectnumber, ELEMENTTIMEOUT );
        driver.findElement( toprojectnumber ).click();
        driver.findElement( toprojectnumber ).sendKeys( dataTable.getData( "General_Data", "To Project Number" ) );
        report.updateTestLog( "Verify the Data", "Data Captured Successfully", Status.PASS );
        oracleObjectRender( SCRIPTTIME );
    }

    private void clickonsubmit() {
        isElementAvailable( btnsubmit, ELEMENTTIMEOUT );
        driver.findElement( btnsubmit ).click();
        oracleObjectRender( SCRIPTTIME );
    }

    private void verifytheprocessmessageandsearchtheprocessID() {
        isElementAvailable( processmessage, ELEMENTTIMEOUT );
        String procesmessage = driver.findElement( processmessage ).getText();
        //Process 230208 was submitted.
        String[] processmsg = procesmessage.split( " " );
        String processmsg2 = processmsg[1]; // 230208
        report.updateTestLog( "Verify the Process", "Process " + processmsg2 + " Completed Successfully", Status.PASS );
        PauseScript( 3 );
        isElementAvailable( processpopupbtnOk, ELEMENTTIMEOUT );
        driver.findElement( processpopupbtnOk ).click();
        PauseScript( 6 );
        scheduleprocessnav();
        oracleObjectRender( QUERYRESPONSE );
        //Search Process ID on Schedule process Screen
        clickonsearch();
        isElementAvailable( processID, ELEMENTTIMEOUT );
        driver.findElement( processID ).click();
        driver.findElement( processID ).sendKeys( processmsg2 );
        report.updateTestLog( "Verify the process ID", "Process ID Mached Successfully", Status.PASS );
        oracleObjectRender( SCRIPTTIME );
        driver.findElement( btnsearch ).click();
        oracleObjectRender( SCRIPTTIME );
    }

    private void scheduleprocesssearchresults() {
        isElementAvailable( processIDSearchresults, ELEMENTTIMEOUT );
        driver.findElement( processIDSearchresults ).isDisplayed();
        report.updateTestLog( "Verify the Schedule process", " Schedule Process completed Successfully", Status.PASS );
    }


    private void updateAssetdetails() {
        oracleObjectRender( SCRIPTTIME );
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( btnsavenclose, ELEMENTTIMEOUT );
        driver.findElement( btnsavenclose ).click();
        report.updateTestLog( "Verify the updated Asset details", " Asset details updated Successfully", Status.PASS );
        oracleObjectRender( QUERYRESPONSE );
    }

    //Create Asset Shell
    public void createAssetshell() {
        clickonsearch();
        searchprojects();
        selecttheprojectfromsearchresultss();
        clickonaction();
        clickonManagecaptialassets();
        clickonplusicontocreate();
        entertheAssetshellinformation();
        backtocaptilizationlinkandselecttheaddedasset();
        //Warning handled - Need to check
        assigntheassetonprojectlevel();
        clickonsaveNclose();
        report.updateTestLog( "Verify the Asset shell", " Asset shell created Sucessfully", Status.PASS );
        }

    //create Manual captial event
    public void createManualcaptialevent() {
        createAssetshell();
        oracleObjectRender( SCRIPTTIME );
        clickonsearch();
        searchprojects();
        selecttheprojectfromsearchresultss();
        clickonaction();
        clickonManagecaptialevents();
        clickonplusicontocreate();
        entertheEventname();
        clickonaction();
        clickonManageEventassets();
        clickonplusiconformanageEventasset();
        searchandaddassets();  //Asset displayed late
        clickonsaveNclose();
        //Warning handled - Need to check
        //warningmessage();
        clickonaction();
        clickonManageEventcost();
        clickonplusiconformanageEventasset();
        searchandaddcosts();
        clickonsaveNclose();
        clickonaction();
        clickonGenerateassetines();
    }

    //Generate Asset Lines
    public void generateAssetlines() {
        clickonsearch();
        searchprojects();
        selecttheprojectfromsearchresultss();
        clickonaction();
        clickonManagecaptialevents();
        clickonaction();
        clickonGenerateassetines();
        clickonsaveNclose();
        selecttheprojectfromsearchresultss();
        clickonaction();
        clickonManageAssetlines();
        //Step 3.7 - depends upon asset line and currently the dropdown list select the appropriate asset
    }

    //Transfer Capitalised Assets to Oracle Fusion Assets Module

    public void transferCapitalAssetstooracleFusionassets() {
        entertherequireddetailsonparameter();
        clickonsubmit();
        verifytheprocessmessageandsearchtheprocessID();
        scheduleprocesssearchresults();
    }

    // Update Asset Information for the Capital Assets Created in Fixed Assets

    public void UpdateAssetsInformationforCapitalassets() {
        //Review and validate the asset created through projects module are Added to the Asset Book
        clickonsubmit();
        isElementAvailable( processmessage, ELEMENTTIMEOUT );
        String procesmessage = driver.findElement( processmessage ).getText();
        //Process 230208 was submitted.
        String[] processmsg = procesmessage.split( " " );
        String processmsg2 = processmsg[1]; // 230208
        report.updateTestLog( "Verify the Process", "Process " + processmsg2 + " Completed Successfully", Status.PASS );
        PauseScript( 3 );
        isElementAvailable( processpopupbtnOk, ELEMENTTIMEOUT );
        driver.findElement( processpopupbtnOk ).click();
        oracleObjectRender( SCRIPTTIME );
        managecapitalprojectsnav();
        oracleObjectRender( SCRIPTTIME );
        clickonsearch();
        searchprojects();
        selecttheprojectfromsearchresultss();
        clickonaction();
        clickonManagecaptialassets();
        updateAssetdetails();
    }


}
