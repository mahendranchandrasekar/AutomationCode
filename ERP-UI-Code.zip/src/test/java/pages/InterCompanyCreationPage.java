package pages;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.ScriptHelper;
import com.cognizant.framework.ExcelDataImport;
import com.cognizant.framework.Status;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

/**
 * Journals Page class
 */
public class InterCompanyCreationPage extends MasterPages {
    // UI Map object definitions

    // Elements


    private final By batchNumberText = By.xpath("//label[contains(text(),'Batch Number')]/../../td[2]/span");
    private final By providerDrpdown = By.xpath("//label[contains(text(),'Provider')]/../../td[2]/child::*/child::*/span/input");
    private final By providerDrpdownValidate = By.xpath("//table[contains(@id,'processing:0:MAnt2:1:AP2:fcslov4:sis1:is1::sgstnBdy')]/tr[1]/td");
    private final By transactionTypeNameDrpdown = By.xpath("//label[contains(text(),'Transaction Type Name')]/../../td[2]/child::*/child::*/span/input[2]");
    private final By transactionTypeNameDrpdownValidate = By.xpath("//table[contains(@id,'processing:0:MAnt2:1:AP2:fcslov1:sis1:is1::sgstnBdy')]/tr[1]/td[1]");
    private final By batchDateField = By.xpath("//label[contains(text(),'Batch Date')]/../../td[2]/input[1]");
    private final By accountingDateField = By.xpath("//label[contains(text(),'Accounting Date')]/../../td[2]/input[1]");
    private final By batchDescriptionText = By.xpath("//label[contains(text(),'Batch Description')]/../../td[2]/textarea");

    private final By legalEntityText = By.xpath("//label[contains(text(),'Legal Entity')]/../../td[2]");
    private final By currencyDrpdown = By.xpath("//label[contains(text(),'Currency')]/../../td[2]/child::*/child::*/span[1]/input[2]");
    private final By currencyDrpdownValidate = By.xpath("//table[contains(@id,'processing:0:MAnt2:1:AP2:fcslov3:sis1:is1::sgstnBdy')]/tr[1]");
    private final By dummyMethodForFailureAnalysis = By.xpath("//h1[(text()='Transactions')]");

    private final By transactionPlusIcon = By.xpath("//button[contains(text(),'Generate Distributions')]/../../../../../../../../../td[2]/child::*/child::*/child::*/child::*/tbody/tr/td[1]");
    //private final By transactionReceiverDrpdownLine1 = By.xpath("//table[@summary='Transactions']/tbody/tr[1]/td[4]/child::*/child::*/child::*/input");
    private final By transactionReceiverDrpdownLine1 = By.xpath("//table[@summary='Transactions']/tbody/tr[1]/td[4]/child::*/child::*/child::*/span[1]/input");
    private final By transactionDebitAmountLine1 = By.xpath("//table[@summary='Transactions']/tbody/tr[1]/td[6]/child::*/child::*/input");
    private final By transactionCreditAmountLine1 = By.xpath("//table[@summary='Transactions']/tbody/tr[1]/td[7]/child::*/child::*/input");
    private final By transactionDesciptionLine1 = By.xpath("//table[@summary='Transactions']/tbody/tr[1]/td[8]/child::*/child::*/input");

    private final By dstProviderTabButton = By.xpath("//h1[contains(text(),'Transaction : Distributions')]/../../../../../../../div[2]/child::*/child::*/div[1]/div[2]/child::*/div[2]/div[1]/div/a");
    private final By dstReceiverTabButton = By.xpath("//h1[contains(text(),'Transaction : Distributions')]/../../../../../../../div[2]/child::*/child::*/div[1]/div[2]/child::*/div[2]/div[2]/div/a");
    private final By distributionProviderPlusIcon = By.xpath("//img[contains(@id,'processing:0:MAnt2:1:AP2:AT6:_ATp:create::icon')]");
    private final By distributionReceiverPlusIcon = By.xpath("//img[contains(@id,'processing:0:MAnt2:1:AP2:AT7:_ATp:create::icon')]");
    private final By dstProviderAccountNumberLine1 = By.xpath("//table[@summary='Transactions 1: Distributions - Provider']/tbody/tr[1]/td[4]/child::*/child::*/child::*/table/tbody/tr[1]/td[1]/span/input");
    private final By dstProviderDebitLine1 = By.xpath("//table[@summary='Transactions 1: Distributions - Provider']/tbody/tr[1]/td[5]/child::*/child::*/input");
    private final By dstProviderCreditLine1 = By.xpath("//table[@summary='Transactions 1: Distributions - Provider']/tbody/tr[1]/td[6]/child::*/child::*/input");
    private final By dstProviderDescriptionLine1 = By.xpath("//table[@summary='Transactions 1: Distributions - Provider']/tbody/tr[1]/td[7]/child::*/child::*/input");

    private final By dstReceiverAccountNumberLine1 = By.xpath("//table[@summary='Transactions 1: Distributions - Receiver']/tbody/tr[1]/td[4]/child::*/child::*/child::*/table/tbody/tr[1]/td[1]/span/input");
    private final By dstReceiverDebitLine1 = By.xpath("//table[@summary='Transactions 1: Distributions - Receiver']/tbody/tr[1]/td[5]/child::*/child::*/input");
    private final By dstReceiverCreditLine1 = By.xpath("//table[@summary='Transactions 1: Distributions - Receiver']/tbody/tr[1]/td[6]/child::*/child::*/input");
    private final By dstReceiverDescriptionLine1 = By.xpath("//table[@summary='Transactions 1: Distributions - Receiver']/tbody/tr[1]/td[7]/child::*/child::*/input");

    private final By confirmMsgForSave = By.xpath("//div[contains(text(),'Updates to the batch')]");
    private final By confirmMsgForSubmit = By.xpath("//div[contains(text(),'has been submitted')]");
    private final By popUpOkButton = By.xpath("//button[contains(@id,'_FOd1::msgDlg::cancel')]");
    private final By saveButton = By.xpath("//span[contains(text(),'Save')]");
    private final By submitButton = By.xpath("//span[contains(text(),'Sub')]");
    private final By cancelButton = By.xpath("//span[contains(text(),'ancel')]");


    //Page Sync Config

    // page loading time
    public static final int PAGELOADTIMEOUT = 90;
    // individual element load time
    public static final int ELEMENTTIMEOUT = 60;
    // Oracle query response
    public static final long QUERYRESPONSE = 15;
    // object render script
    public static final long SCRIPTTIME = 5;

    /**
     * Constructor to initialize the page
     *
     * @param scriptHelper The {@link ScriptHelper} object passed from the
     *                     {@link DriverScript}b  n '/fg .+
     */
    public InterCompanyCreationPage(ScriptHelper scriptHelper) {
        super(scriptHelper);
        isElementAvailable(providerDrpdown, PAGELOADTIMEOUT);
		/*if (!driver.findElement(welcomePage).isDisplayed()) {
			report.updateTestLog("Verify page title", "FCCS Home page expected, but not displayed!",
					Status.WARNING);
		}*/
    }


    public String enterInterCompanyDetails() {
        isElementAvailable(providerDrpdown, PAGELOADTIMEOUT);
        report.updateTestLog("Create Intercomapny transaction Page", "The user is able to view the navigation link and the Create Intercomapny transaction page is opened", Status.PASS);
        driver.findElement(providerDrpdown).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "Provider"));
        oracleObjectRender(SCRIPTTIME);
        isElementAvailable(providerDrpdownValidate, ELEMENTTIMEOUT);
        driver.findElement(providerDrpdownValidate).click();
        oracleObjectRender(SCRIPTTIME);
        String batchNumberTxt = driver.findElement(batchNumberText).getAttribute("innerHTML");
        try {
            isElementAvailable(transactionTypeNameDrpdown, ELEMENTTIMEOUT);
            driver.findElement(transactionTypeNameDrpdown).clear();
            driver.findElement(transactionTypeNameDrpdown).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "TransactionTypeName"));
            oracleObjectRender(SCRIPTTIME);
            isElementAvailable(transactionTypeNameDrpdownValidate, ELEMENTTIMEOUT);
            driver.findElement(transactionTypeNameDrpdownValidate).click();
        } catch (Exception e) {
            report.updateTestLog("Error occurred at Transaction Type Name", "Except Recharge, none of the list values are available in the Dropdown", Status.FAIL);
        }
        oracleObjectRender(SCRIPTTIME);
        isElementAvailable(batchDateField, ELEMENTTIMEOUT);
        driver.findElement(batchDateField).clear();
        driver.findElement(batchDateField).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "BatchDate"));
        isElementAvailable(accountingDateField, ELEMENTTIMEOUT);
        driver.findElement(accountingDateField).clear();
        driver.findElement(accountingDateField).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "IntercompanyAccountingDate"));
        isElementAvailable(batchDescriptionText, ELEMENTTIMEOUT);
        driver.findElement(batchDescriptionText).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "BatchDescription"));
        report.updateTestLog("Intercompany Batch Section", "Intercompany Batch Section", Status.PASS);

        isElementAvailable(currencyDrpdown, ELEMENTTIMEOUT);
        driver.findElement(currencyDrpdown).clear();
        driver.findElement(currencyDrpdown).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "Currency"));
        oracleObjectRender(QUERYRESPONSE);
        isElementAvailable(currencyDrpdownValidate, ELEMENTTIMEOUT);
        driver.findElement(currencyDrpdownValidate).click();
        oracleObjectRender(QUERYRESPONSE);
        //TODO START Delete - transaction type name
        isElementAvailable(dummyMethodForFailureAnalysis, ELEMENTTIMEOUT);
        driver.findElement(dummyMethodForFailureAnalysis).click();
        //TODO END
        isElementAvailable(transactionPlusIcon, ELEMENTTIMEOUT);
        driver.findElement(transactionPlusIcon).click();
        isElementAvailable(transactionReceiverDrpdownLine1, PAGELOADTIMEOUT);
        driver.findElement(transactionReceiverDrpdownLine1).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "ReceiverLine1"));
        oracleObjectRender(QUERYRESPONSE);

        if (dataTable.getData(ExcelDataImport.GeneralData, "TransactionDebitLine1").equals("0")) {
            isElementAvailable(transactionCreditAmountLine1, ELEMENTTIMEOUT);
            driver.findElement(transactionCreditAmountLine1).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "TransactionCreditLine1"));
            driver.findElement(transactionCreditAmountLine1).sendKeys(Keys.TAB);
            oracleObjectRender(QUERYRESPONSE);
        } else {
            isElementAvailable(transactionDebitAmountLine1, ELEMENTTIMEOUT);
            driver.findElement(transactionDebitAmountLine1).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "TransactionDebitLine1"));
            driver.findElement(transactionDebitAmountLine1).sendKeys(Keys.TAB);
            oracleObjectRender(QUERYRESPONSE);
        }
        isElementAvailable(transactionDesciptionLine1, ELEMENTTIMEOUT);
        driver.findElement(transactionDesciptionLine1).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "TransactionDescriptionLine1"));
        oracleObjectRender(QUERYRESPONSE);
        report.updateTestLog("Intercompany Transactions Section", "Intercompany Transactions Section", Status.PASS);

        //Receiver Tab
        isElementAvailable(dstReceiverTabButton, ELEMENTTIMEOUT);
        driver.findElement(dstReceiverTabButton).click();
        isElementAvailable(distributionReceiverPlusIcon, ELEMENTTIMEOUT);
        driver.findElement(distributionReceiverPlusIcon).click();
        isElementAvailable(dstReceiverAccountNumberLine1, PAGELOADTIMEOUT);
        driver.findElement(dstReceiverAccountNumberLine1).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "DstReceiverAccountLine1"));
        if (dataTable.getData(ExcelDataImport.GeneralData, "DstReceiverDebitLine1").equals("0")) {
            isElementAvailable(dstReceiverCreditLine1, ELEMENTTIMEOUT);
            driver.findElement(dstReceiverCreditLine1).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "DstReceiverCreditLine1"));
            driver.findElement(dstReceiverCreditLine1).sendKeys(Keys.TAB);
            oracleObjectRender(QUERYRESPONSE);
        } else {
            isElementAvailable(dstReceiverDebitLine1, ELEMENTTIMEOUT);
            driver.findElement(dstReceiverDebitLine1).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "DstReceiverDebitLine1"));
            driver.findElement(dstReceiverDebitLine1).sendKeys(Keys.TAB);
            oracleObjectRender(QUERYRESPONSE);
        }
        isElementAvailable(dstReceiverDescriptionLine1, ELEMENTTIMEOUT);
        driver.findElement(dstReceiverDescriptionLine1).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "DstReceiverDescriptionLine1"));
        oracleObjectRender(QUERYRESPONSE);
        report.updateTestLog("Intercompany Transaction Distributions - Receiver Tab", "Intercompany Transaction Distributions - Receiver Tab", Status.PASS);

        //Provider Tab
        isElementAvailable(dstProviderTabButton, ELEMENTTIMEOUT);
        driver.findElement(dstProviderTabButton).click();
        isElementAvailable(distributionProviderPlusIcon, ELEMENTTIMEOUT);
        driver.findElement(distributionProviderPlusIcon).click();
        isElementAvailable(dstProviderAccountNumberLine1, PAGELOADTIMEOUT);
        driver.findElement(dstProviderAccountNumberLine1).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "DstProviderAccountLine1"));
        if (dataTable.getData(ExcelDataImport.GeneralData, "DstProviderDebitLine1").equals("0")) {
            isElementAvailable(dstProviderCreditLine1, ELEMENTTIMEOUT);
            driver.findElement(dstProviderCreditLine1).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "DstProviderCreditLine1"));
            driver.findElement(dstProviderCreditLine1).sendKeys(Keys.TAB);
            oracleObjectRender(QUERYRESPONSE);
        } else {
            isElementAvailable(dstProviderDebitLine1, ELEMENTTIMEOUT);
            driver.findElement(dstProviderDebitLine1).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "DstProviderDebitLine1"));
            driver.findElement(dstProviderDebitLine1).sendKeys(Keys.TAB);
            oracleObjectRender(QUERYRESPONSE);
        }
        isElementAvailable(dstProviderDescriptionLine1, ELEMENTTIMEOUT);
        driver.findElement(dstProviderDescriptionLine1).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "DstProviderDescriptionLine1"));
        oracleObjectRender(QUERYRESPONSE);
        report.updateTestLog("Transaction Distributions - Provider Tab", "Transaction Distributions - Provider Tab", Status.PASS);
        return batchNumberTxt;
    }/**/

    public void saveInterCompanyDetails() {
        isElementAvailable(saveButton, ELEMENTTIMEOUT);
        driver.findElement(saveButton).click();
        oracleObjectRender(SCRIPTTIME);
        try {
            if (driver.findElement(confirmMsgForSave).isDisplayed()) {
                String innerTextDelete = driver.findElement(confirmMsgForSave).getAttribute("innerHTML");
                report.updateTestLog("Confirmation message to Save Intercompany Batch transaction", "Confirmation message to Save Intercompany Batch transaction", Status.PASS);
                oracleObjectRender(SCRIPTTIME);
                driver.findElement(popUpOkButton).click();
                oracleObjectRender(QUERYRESPONSE);
            }
        } catch (Exception e) {
            report.updateTestLog("UnExpected Error occured at Batch Section", "Unable to Save Intercompany details due to UnExpected Error occured at Batch - Transaction Type Name", Status.FAIL);
        }
    }

    public void submitInterCompanyDetails() {
        isElementAvailable(submitButton, ELEMENTTIMEOUT);
        driver.findElement(submitButton).click();
        oracleObjectRender(SCRIPTTIME);
        try {
            if (driver.findElement(confirmMsgForSubmit).isDisplayed()) {
                String innerTextDelete = driver.findElement(confirmMsgForSubmit).getAttribute("innerHTML");
                report.updateTestLog("Confirmation message to Submit Intercompany Batch transaction", "Confirmation message to Submit Intercompany Batch transaction", Status.PASS);
                driver.findElement(popUpOkButton).click();
                oracleObjectRender(QUERYRESPONSE);
                report.updateTestLog("The Landing Page is Intercompany Transaction Homepage", "The Landing Page is Intercompany Transaction Homepage", Status.PASS);
            }
        } catch (Exception e) {
            report.updateTestLog("UnExpected Pop-up message", "UnExpected Pop-up message has occurred during Execution", Status.FAIL);
        }
    }

}
