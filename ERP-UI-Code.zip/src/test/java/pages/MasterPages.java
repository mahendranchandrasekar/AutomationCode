package pages;


import com.cognizant.framework.selenium.WebDriverUtil;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.ReusableLibrary;
import com.cognizant.craft.ScriptHelper;

import java.io.File;


/**
 * MasterPage  class contains reusable methods
 *
 */
abstract class MasterPages extends ReusableLibrary {
	// UI Map object definitions
	// Links

	//Page Sync Config

	// page loading time
	public static final int PAGELOADTIMEOUT = 90;
	// individual element load time
	public static final int ELEMENTTIMEOUT = 60;
	// Oracle query response
	public static final long QUERYRESPONSE = 15;
	// object render script
	public static final long SCRIPTTIME = 2;


	/**
	 * Constructor to initialize the functional library
	 *
	 * @param scriptHelper The {@link ScriptHelper} object passed from the
	 *                     {@link DriverScript}
	 */
	protected MasterPages(ScriptHelper scriptHelper) {
		super(scriptHelper);

		PageFactory.initElements(driver.getWebDriver(), this);
	}

	// handle element present and page load time
	public void isElementAvailable(By locatorType, long time) {
		for (int counter = 0; counter < time; counter++) {
			if((driver.findElements(locatorType).size() > 0)||(counter==time)){
				break;
			}else{
				oracleObjectRender(SCRIPTTIME);
			}
		}
	}

	// handle element present and page load time
	public void isElementAvailableOld(By locatorType, long time) {
		try {
			WebDriverUtil waitElement=new WebDriverUtil(this.driver);
			waitElement.waitUntilPageReadyStateComplete(time);
			waitElement.waitUntilElementEnabled(locatorType,time);
		} catch (Exception e) { e.printStackTrace();
		}
	}

	public void mouseOverAndClick(By locatorType) {
		try {
			WebDriverUtil waitElement=new WebDriverUtil(this.driver);
			waitElement.mouseOverAndClick(locatorType);
		} catch (Exception e) { e.printStackTrace();
		}
	}



	public void jsClick(By locatorType) {
		try {
			WebDriverUtil waitElement=new WebDriverUtil(this.driver);
			waitElement.jsClick(locatorType);
		} catch (Exception e) { e.printStackTrace();
		}
	}

	public void mouseOverAndEnter(By locatorType, String value) {
		try {
			WebDriverUtil waitElement=new WebDriverUtil(this.driver);
			waitElement.mouseOverAndEnter(locatorType, value);
		} catch (Exception e) { e.printStackTrace();
		}
	}

	public void scrollPageDown() {
		try {
			WebDriverUtil waitElement=new WebDriverUtil(this.driver);
			waitElement.scrollDown();
		} catch (Exception e) { e.printStackTrace();
		}
	}

}
