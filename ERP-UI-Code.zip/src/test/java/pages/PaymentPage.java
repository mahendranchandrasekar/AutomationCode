package pages;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.ScriptHelper;
import com.cognizant.framework.ExcelDataImport;
import com.cognizant.framework.Status;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

public class PaymentPage extends MasterPages {

    // Elements

    //Links
    private final By taskmenu = By.xpath( "//img[contains(@title,'Tasks')]" );
    private final By createpayment = By.xpath( "//a[text()='Create Payment']" );
    private final By managepayment = By.xpath( "//a[text()='Manage Payments']" );
    private final By businessunit = By.xpath("//label[text()='Business Unit']/following::input[1]");
    private final By supplierorparty = By.xpath( "//label[text()='Supplier or Party']/following::input[1]" );
    private final By disbursementbankaccount = By.xpath( "//label[text()='Disbursement Bank Account']/following::input[1]" );
    private final By paymentprocessprofile = By.xpath( "//label[text()='Payment Process Profile']/following::input[1]" );
    private final By ajaxValidate = By.xpath( "//div[contains(@class,'AFDetectExpansion')]/../tbody/tr[1]/td[1]/ul[1]/li[1]" );
    private final By invoicenumber = By.xpath( "//label[text()='Invoice Number']/following::input[1]" );
    private final By searchresults = By.xpath( "//table[@summary='Search Results']/tbody/tr[1]/td/../td/div/table/tbody/tr/td[2]" );
    private final By paymentmessage = By.xpath( "//*[contains(@id,'msgDlg::_cnt')]/div/table/tbody/tr/td/table/tbody/tr/td[2]/div" );
    private final By btnOKpymtmsg = By.xpath( "//*[contains(@id,'msgDlg::cancel')]" );
    //Managepayment search
    private final By paymentnubmer = By.xpath( "//label[text()='Payment Number']/following::input[1]" );
    private final By paymentnubmerresults = By.xpath( "//table[@summary='Search Results']/tbody/tr/td[2]/div/table/tbody/tr/td[1]");
    //button
    private final By btnselectandadd = By.xpath( "//img[@alt='Select and Add']" );
    private final By btnOK = By.xpath( "//button[@accesskey='K']" );
    private final By btnsearch = By.xpath( "//button[text()='Search']" );
    private final By btnsaveandclose = By.xpath( "//button[@accesskey='S']" );


    // page loading time
    public static final int PAGELOADTIMEOUT = 90;
    // individual element load time
    public static final int ELEMENTTIMEOUT = 60;
    // Oracle query response
    public static final long QUERYRESPONSE = 15;
    // object render script
    public static final int SCRIPTTIME = 5;

    /**
     * Constructor to initialize the functional library
     *
     * @param scriptHelper The {@link ScriptHelper} object passed from the
     *                     {@link DriverScript}
     */
    public PaymentPage(ScriptHelper scriptHelper) {
        super( scriptHelper );
    }


    public void createPaymentnav() {
        isElementAvailable( taskmenu, ELEMENTTIMEOUT );
        driver.findElement( taskmenu ).click();

        isElementAvailable( createpayment, PAGELOADTIMEOUT );
        driver.findElement( createpayment ).click();
        oracleObjectRender(SCRIPTTIME);
    }

    public void managePaymentnav() {
        isElementAvailable( taskmenu, ELEMENTTIMEOUT );
        driver.findElement( taskmenu ).click();

        isElementAvailable( managepayment, ELEMENTTIMEOUT );
        driver.findElement( managepayment ).click();
    }


    private void clickonselectandaddbutton() {
        isElementAvailable( btnselectandadd, PAGELOADTIMEOUT );
        driver.findElement( btnselectandadd ).click();
        oracleObjectRender( QUERYRESPONSE );
    }


    private  void searchinvoicenumber() {
        isElementAvailable( invoicenumber, PAGELOADTIMEOUT );
        driver.findElement( invoicenumber ).click();
        driver.findElement( invoicenumber ).sendKeys( dataTable.getData(ExcelDataImport.GeneralData, "InvoiceNumber" ) );
        oracleObjectRender( SCRIPTTIME );
        driver.findElement( btnsearch ).click();
        oracleObjectRender( QUERYRESPONSE );
    }

    private void selectthedatafromresult() {
        isElementAvailable( searchresults, PAGELOADTIMEOUT );
        driver.findElement( searchresults ).click();
        report.updateTestLog( "Verify the Invoice number", "Invoice Number displayed", Status.PASS );
    }

    private void clickonapplyandok() {
        isElementAvailable( btnOK, PAGELOADTIMEOUT );
        driver.findElement( btnOK ).click();
        oracleObjectRender( SCRIPTTIME );
    }

    private void clickonsaveandclose() {
        isElementAvailable( btnsaveandclose, PAGELOADTIMEOUT );
        driver.findElement( btnsaveandclose ).click();
        oracleObjectRender( QUERYRESPONSE );

    }

    private void paymentmessagecheck() {
        isElementAvailable( paymentmessage, PAGELOADTIMEOUT );
        driver.findElement( paymentmessage ).isDisplayed();
        report.updateTestLog( "Verify the Payment creation", "Payment created Successully ", Status.PASS );
        oracleObjectRender( SCRIPTTIME );
        String paymtmsg = driver.findElement( paymentmessage ).getText();
        String[] parts = paymtmsg.split(" ");
        String part2 = parts[1]; // 9859
        isElementAvailable( btnOKpymtmsg, PAGELOADTIMEOUT );
        driver.findElement( btnOKpymtmsg ).click();
        oracleObjectRender( SCRIPTTIME );
        managePaymentnav();
        oracleObjectRender( QUERYRESPONSE );
        isElementAvailable( paymentnubmer, PAGELOADTIMEOUT );
        driver.findElement( paymentnubmer ).click();
        driver.findElement( paymentnubmer ).sendKeys(part2);
        oracleObjectRender( SCRIPTTIME );
        driver.findElement( btnsearch ).click();
        oracleObjectRender(QUERYRESPONSE);
        driver.findElement( paymentnubmerresults ).isDisplayed();
        report.updateTestLog( "Verify the Payment number on Manage payment", "Payment Number - " + part2 + " displayed Successfully", Status.PASS );
        oracleObjectRender( SCRIPTTIME );
    }


    public void createPayment() {
        isElementAvailable(businessunit, PAGELOADTIMEOUT );
        driver.findElement(businessunit).sendKeys(Keys.TAB);
        driver.findElement(businessunit).click();
        oracleObjectRender(SCRIPTTIME);
        CreateInvoicePage createInvoicePage = new CreateInvoicePage(scriptHelper);
        /*driver.findElement(businessunit).sendKeys(createInvoicePage.businessUnit);
        driver.findElement(businessunit).clear();
        oracleObjectRender(SCRIPTTIME);*/
        driver.findElement(businessunit).sendKeys(createInvoicePage.businessUnit);
        oracleObjectRender(QUERYRESPONSE);
        driver.findElement( ajaxValidate ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( supplierorparty, PAGELOADTIMEOUT );
        driver.findElement( supplierorparty ).click();
        driver.findElement( supplierorparty ).sendKeys(createInvoicePage.supplierName);
        oracleObjectRender( QUERYRESPONSE );
        driver.findElement( ajaxValidate ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( disbursementbankaccount, PAGELOADTIMEOUT );
        driver.findElement( disbursementbankaccount ).click();
        driver.findElement( disbursementbankaccount ).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "DisbursementBankAccount"));
        oracleObjectRender( QUERYRESPONSE );
        driver.findElement( ajaxValidate ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( paymentprocessprofile, PAGELOADTIMEOUT );
        driver.findElement( paymentprocessprofile ).click();
        driver.findElement( paymentprocessprofile ).sendKeys( dataTable.getData(ExcelDataImport.GeneralData, "PaymentProcessProfile" ) );
        oracleObjectRender( QUERYRESPONSE );
        driver.findElement( ajaxValidate ).click();
        oracleObjectRender( SCRIPTTIME );
        report.updateTestLog( "Verify the data captured for payment", "Data captured Successfully", Status.PASS );
        this.clickonselectandaddbutton();
        this.searchinvoicenumber();
        this.selectthedatafromresult();
        this.clickonapplyandok();
        this.clickonsaveandclose();
        this.paymentmessagecheck();
    }


    public void createPaymentForSpecifiedInvoice() {
        isElementAvailable(businessunit, PAGELOADTIMEOUT );
        driver.findElement(businessunit).sendKeys(Keys.TAB);
        driver.findElement(businessunit).click();
        oracleObjectRender(SCRIPTTIME);
        driver.findElement(businessunit).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "BusinessUnit"));
        oracleObjectRender(QUERYRESPONSE);
        driver.findElement( ajaxValidate ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( supplierorparty, PAGELOADTIMEOUT );
        driver.findElement( supplierorparty ).click();
        driver.findElement( supplierorparty ).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "Supplier"));
        oracleObjectRender( QUERYRESPONSE );
        driver.findElement( ajaxValidate ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( disbursementbankaccount, PAGELOADTIMEOUT );
        driver.findElement( disbursementbankaccount ).click();
        driver.findElement( disbursementbankaccount ).sendKeys( dataTable.getData(ExcelDataImport.GeneralData, "DisbursementBankAccount" ) );
        oracleObjectRender( QUERYRESPONSE );
        driver.findElement( ajaxValidate ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( paymentprocessprofile, PAGELOADTIMEOUT );
        driver.findElement( paymentprocessprofile ).click();
        driver.findElement( paymentprocessprofile ).sendKeys( dataTable.getData(ExcelDataImport.GeneralData, "PaymentProcessProfile" ) );
        oracleObjectRender( QUERYRESPONSE );
        driver.findElement( ajaxValidate ).click();
        oracleObjectRender( SCRIPTTIME );
        report.updateTestLog( "Verify the data captured for payment", "Data captured Successfully", Status.PASS );
        oracleObjectRender( QUERYRESPONSE );
        this.clickonselectandaddbutton();
        this.searchinvoicenumber();
        this.selectthedatafromresult();
        this.clickonapplyandok();
        this.clickonsaveandclose();
        this.paymentmessagecheck();
    }
}












