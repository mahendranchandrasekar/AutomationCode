package pages;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.ScriptHelper;
import com.cognizant.framework.ExcelDataImport;
import com.cognizant.framework.Status;
import org.openqa.selenium.By;


/**
 * FCCS SignOnPage class

 */
public class SignOnPage extends MasterPages {

	//Page Sync Config

	// page loading time
	public static final int PAGELOADTIMEOUT = 90;
	// individual element load time
	public static final int ELEMENTTIMEOUT = 60;
	// Oracle query response
	public static final long QUERYRESPONSE = 15;
	// object render script
	public static final long SCRIPTTIME = 5;


	// UI Map object definitions

	// Text boxes
	private final By txtUsername = By.xpath("//input[@id='userid']");
	private final By txtPassword = By.xpath("//input[@id='password']");
	private final By btnLogin = By.xpath("//button[@id='btnActive']");


	/**
	 * Constructor to initialize the page
	 *
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */


	public SignOnPage(ScriptHelper scriptHelper) {
		super(scriptHelper);
		isElementAvailable(txtUsername,ELEMENTTIMEOUT);
	}

	public NavigationPage loginAsValidJournalUser() {
		login();
		return new NavigationPage(scriptHelper);
	}

	public NavigationPage loginAsTeamMemberUser() {
		teamMemberLogin();
		return new NavigationPage(scriptHelper);
	}

	public NavigationPage loginAsTeamLeaderUserTwice() {
		teamLeaderLoginTwice();
		return new NavigationPage(scriptHelper);
	}

	public NavigationPage loginAsTeamLeaderUser() {
		teamLeaderLoginOnce();
		return new NavigationPage(scriptHelper);
	}

	private void teamMemberLogin() {
		isElementAvailable(txtUsername,PAGELOADTIMEOUT);
		String userNameData = dataTable.getData(ExcelDataImport.GeneralData, "UsernameForTeamMember");
		String passwordData = dataTable.getData(ExcelDataImport.GeneralData, "PasswordForTeamMember");

		driver.findElement(txtUsername).sendKeys(userNameData);
		driver.findElement(txtPassword).sendKeys(passwordData);

		report.updateTestLog("Team Member Login",
				"Enter Team Member login credentials: " + "Username =" + userNameData ,
				Status.DONE);
		driver.findElement(btnLogin).click();
}

	private void teamLeaderLoginTwice() {
		isElementAvailable(txtUsername,PAGELOADTIMEOUT);
		String userNameData = dataTable.getData(ExcelDataImport.GeneralData, "UsernameForTeamLeader");
		String passwordData = dataTable.getData(ExcelDataImport.GeneralData, "PasswordForTeamLeader");

		driver.navigate().refresh();
		oracleObjectRender(SCRIPTTIME);
		driver.findElement(txtUsername).sendKeys(userNameData);
		driver.findElement(txtPassword).sendKeys(passwordData);
		driver.findElement(txtUsername).sendKeys(userNameData);

		report.updateTestLog("Team Leader Login",
				"Enter Team Leader login credentials: " + "Username = " + userNameData ,
				Status.DONE);
		driver.findElement(btnLogin).click();
	}

	private void teamLeaderLoginOnce() {
		isElementAvailable(txtUsername,PAGELOADTIMEOUT);
		String userNameData = dataTable.getData(ExcelDataImport.GeneralData, "UsernameForTeamLeader");
		String passwordData = dataTable.getData(ExcelDataImport.GeneralData, "PasswordForTeamLeader");

		driver.navigate().refresh();
		oracleObjectRender(SCRIPTTIME);
		driver.findElement(txtUsername).sendKeys(userNameData);
		driver.findElement(txtPassword).sendKeys(passwordData);
		report.updateTestLog("Team Leader Login","Enter Team Leader login credentials: " + "Username= " + userNameData , Status.DONE);
		driver.findElement(btnLogin).click();
	}

	private void login() {
		isElementAvailable(txtUsername,PAGELOADTIMEOUT);
		String userNameData = dataTable.getData(ExcelDataImport.GeneralData, "Username");
		String passwordData = dataTable.getData(ExcelDataImport.GeneralData, "Password");

		driver.findElement(txtUsername).sendKeys(userNameData);
		driver.findElement(txtPassword).sendKeys(passwordData);

		report.updateTestLog("Journal Login",
				"Enter Journal login credentials: " + " Username = " + userNameData ,
				Status.DONE);
		driver.findElement(btnLogin).click();
	}


	public SignOnPage loginAsInvalidUser() {
		login();
		return new SignOnPage(scriptHelper); // Return new object to indicate an
												// actual page navigation
	}
}