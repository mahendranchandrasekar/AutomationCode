package pages;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.ScriptHelper;
import com.cognizant.framework.ExcelDataImport;
import com.cognizant.framework.Status;
import org.openqa.selenium.By;


/**
 * Journals Page class
 */
public class ArcsJobsPage extends MasterPages {
	// UI Map object definitions

	// Elements
	private final By transactionMatchingTab= By.xpath("//a[(text()='Reconciliation Compliance')]/../../../div[2]/div/a");
    private final By actionDropdown= By.xpath("//span[(text()='Actions')]");
    private final By refreshButton= By.xpath("//span[(text()='Refresh')]");
	private final By runAutoMatchDropdownValidate= By.xpath("//ul[(@id='actionMenu')]/li[2]/a");
	//private final By runAutoMatchTxt= By.xpath("//h1[(text()='Run Auto Match')]");
    private final By matchTypeDropdown= By.xpath("//h1[(text()='Run Auto Match')]/../../../div[3]/div[1]/div[2]/div[1]/div[1]/span");
    //private final By matchTypeSearchField= By.xpath("//div[@class='oj-listbox-drop oj-listbox-drop-above']/div[1]/div[1]/input");
    private final By matchTypeDropdownValidate1= By.xpath("//ul[contains(@id,'oj-listbox-results-rt_prop_recontypes')]/li[1]/div");
    private final By matchTypeDropdownValidate2= By.xpath("//ul[contains(@id,'oj-listbox-results-rt_prop_recontypes')]/li[2]/div");
	private final By matchTypeDropdownValidate3= By.xpath("//ul[contains(@id,'oj-listbox-results-rt_prop_recontypes')]/li[3]/div");
    private final By matchTypeDropdownValidate4= By.xpath("//ul[contains(@id,'oj-listbox-results-rt_prop_recontypes')]/li[4]/div");
	private final By submitButton= By.xpath("//span[(text()='Submit')]");
	private final By jobsubmissionPopup= By.xpath("//div[contains(text(),'Job submitted successfully')]");
	private final By popupOKButton= By.xpath("//div[@class='oj-dialog-header oj-dialog-header-close ui-draggable-handle']/../div[3]/button");
	private final By jobsubmissionPopup1= By.xpath("//div[contains(text(),'Job Submitted Successfully')]");
	private final By popupOKButton1= By.xpath("//div[@class='oj-dialog oj-component oj-component-initnode oj-draggable oj-resizable']/div[3]/button");
	private final By importTransactionsRecord= By.xpath("//b[(text()='Import Transactions')]");
	private final By importTransactionsNavigator= By.xpath("//b[(text()='Import Transactions')]/../../../../../div[3]/a");
	private final By deleteTransaction= By.xpath("//div[(text()='Delete Transactions')]");
	private final By confirmationPopupDeleteImportTransaction= By.xpath("//span[contains(text(),'Deleting the transactions imported through this job')]");
	private final By popupYesButton= By.xpath("//span[contains(@id,'ui-id-12')]");
	//private final By popupNoButton= By.xpath("//span[contains(@id,'ui-id-13')]");
    private final By filterForName= By.xpath("//div[@id='tile-Name']/div/div[2]");
    private final By removeFilterForName= By.xpath("//a[contains(@class,'oj-component-icon oj-clickable-icon-nocontext oj-select-clear-entry-icon')]");
    private final By operatorDropdown= By.xpath("//span[@id='ojChoiceId_epm-filter-conds-Name_selected']");
    private final By operatorEqualsDropdownValidate= By.xpath("//ul[@id='oj-listbox-results-epm-filter-conds-Name']/li[1]/div");
    private final By valueDropdown= By.xpath("//div[@id='ojChoiceId_epm-filter-list-Name']");
    private final By valueDropdownList= By.xpath("//div[@id='ojChoiceId_epm-filter-list-Name']/ul/li");
    private final By valueDropdownImportTransactionValidate= By.xpath("//div[@class='oj-listbox-drop-layer']/div/ul/li[2]");

    //private final By autoMatchJobValidate= By.xpath("//ul[contains(@id,'jhlistview')]/li[1]/div/div/div[2]/div[2]/div[1]/span/span");
    private final By autoMatchTypeValidate= By.xpath("//ul[contains(@id,'jhlistview')]/li[1]/div/div/div[2]/div[2]/div[3]/span/span");
    //private final By autoMatchResultValidate= By.xpath("//ul[contains(@id,'jhlistview')]/li[1]/div/div/div[2]/div[2]/div[4]/span/a/span");

    //Page Sync Config
	// page loading time
	public static final int PAGELOADTIMEOUT = 90;
	// individual element load time
	public static final int ELEMENTTIMEOUT = 60;
	// Oracle query response
	public static final long QUERYRESPONSE = 15;
	// object render script
	public static final long SCRIPTTIME = 5;


	/**
	 * Constructor to initialize the page
	 *
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}b  n '/fg .+
	 */

	public ArcsJobsPage(ScriptHelper scriptHelper) {
		super(scriptHelper);
		isElementAvailable(transactionMatchingTab, PAGELOADTIMEOUT);

	}



	public void runAutoMatch() {
		isElementAvailable(transactionMatchingTab, ELEMENTTIMEOUT);
		driver.findElement(transactionMatchingTab).click();
		isElementAvailable(actionDropdown, ELEMENTTIMEOUT);
		driver.findElement(actionDropdown).click();
		oracleObjectRender(SCRIPTTIME);
		report.updateTestLog("Run Auto Match", "The Selected option is Run Auto Match", Status.PASS);
		isElementAvailable(runAutoMatchDropdownValidate, ELEMENTTIMEOUT);
		driver.findElement(runAutoMatchDropdownValidate).click();
		isElementAvailable(matchTypeDropdown, PAGELOADTIMEOUT);
        driver.findElement(matchTypeDropdown).click();
        if(dataTable.getData(ExcelDataImport.GeneralData, ExcelDataImport.MatchType).equals("B4C PC DM V FSH (B4C_PC_DM_V_FSH)")){
            isElementAvailable(matchTypeDropdownValidate3, ELEMENTTIMEOUT);
            driver.findElement(matchTypeDropdownValidate3).click();
        } else if(dataTable.getData(ExcelDataImport.GeneralData, ExcelDataImport.MatchType).equals("B4C BC DM v FSH AP (B4C_BC_DM_v_FSH_AP)")){
            isElementAvailable(matchTypeDropdownValidate1, ELEMENTTIMEOUT);
            driver.findElement(matchTypeDropdownValidate1).click();
        } else if(dataTable.getData(ExcelDataImport.GeneralData, ExcelDataImport.MatchType).equals("B4C OF PC GL v FSH (B4C_OF_PC_GL_v_FSH)")) {
            isElementAvailable(matchTypeDropdownValidate2, ELEMENTTIMEOUT);
            driver.findElement(matchTypeDropdownValidate2).click();
        } else if(dataTable.getData(ExcelDataImport.GeneralData, ExcelDataImport.MatchType).equals("MT940 Vs Oracle GLiM (MT940 Vs Oracle GLiM)")) {
            isElementAvailable(matchTypeDropdownValidate4, ELEMENTTIMEOUT);
            driver.findElement(matchTypeDropdownValidate4).click();
        }
        report.updateTestLog("Run Auto Match - Match Type", "The Selected option is displayed from the dropdown", Status.PASS);
        isElementAvailable(submitButton, ELEMENTTIMEOUT);
        driver.findElement(submitButton).click();
		isElementAvailable(jobsubmissionPopup, PAGELOADTIMEOUT);

		try {
			if(driver.findElement(jobsubmissionPopup).isDisplayed()) {
				report.updateTestLog("Confirmation message for Jobs Submission", "Confirmation message for Job Submission is successfully created", Status.PASS);
				isElementAvailable(popupOKButton, ELEMENTTIMEOUT);
				driver.findElement(popupOKButton).click();
				oracleObjectRender(QUERYRESPONSE);
				report.updateTestLog("Jobs Homepage", "The Landing page is Homepage - Jobs", Status.PASS);
			}
		} catch(Exception e) {
			report.updateTestLog("Confirmation Text for Job Submission", "Confirmation Text for Job Submission is not successfully created", Status.FAIL);
		}
		isElementAvailable(refreshButton, PAGELOADTIMEOUT);
        driver.findElement(refreshButton).click();
        oracleObjectRender(QUERYRESPONSE);

		if(driver.findElement(autoMatchTypeValidate).getAttribute(ExcelDataImport.innerHTML).equals(dataTable.getData(ExcelDataImport.GeneralData, "MatchType"))) {
			report.updateTestLog("Auto Match process is created", "Auto Match process is created successfully", Status.PASS);
		} else {
			report.updateTestLog("Auto Match process is not created", "Auto Match process is not created successfully", Status.FAIL);
		}

	}

	public void deportImportTransaction() {
		isElementAvailable(transactionMatchingTab, ELEMENTTIMEOUT);
		driver.findElement(transactionMatchingTab).click();
        isElementAvailable(filterForName, ELEMENTTIMEOUT);
        driver.findElement(filterForName).click();
        isElementAvailable(operatorDropdown, PAGELOADTIMEOUT);
        driver.findElement(operatorDropdown).click();
        oracleObjectRender(SCRIPTTIME);
        isElementAvailable(operatorEqualsDropdownValidate, ELEMENTTIMEOUT);
        driver.findElement(operatorEqualsDropdownValidate).click();
        oracleObjectRender(QUERYRESPONSE);

        try {
			if (driver.findElement(valueDropdown).isDisplayed()) {
				report.updateTestLog("Filter By Name Option", "By default value is available for Name Filter", Status.PASS);
				String innerText = driver.findElement(valueDropdownList).getAttribute("valuetext");

					if (innerText.contentEquals(dataTable.getData(ExcelDataImport.GeneralData, "FilterBy"))) {
						report.updateTestLog("Filter By Name value", "Expected Filter option is available in the application", Status.PASS);
					}
			}
		} catch(Exception e) {
                isElementAvailable(valueDropdown, ELEMENTTIMEOUT);
                driver.findElement(valueDropdown).click();
                oracleObjectRender(SCRIPTTIME);
                isElementAvailable(valueDropdownImportTransactionValidate, ELEMENTTIMEOUT);
                driver.findElement(valueDropdownImportTransactionValidate).click();
                oracleObjectRender(SCRIPTTIME);
            }

		isElementAvailable(refreshButton, ELEMENTTIMEOUT);
		driver.findElement(refreshButton).click();
		isElementAvailable(importTransactionsRecord, ELEMENTTIMEOUT);
		driver.findElement(importTransactionsRecord).click();
		oracleObjectRender(SCRIPTTIME);
		isElementAvailable(importTransactionsNavigator, ELEMENTTIMEOUT);
		driver.findElement(importTransactionsNavigator).click();
		report.updateTestLog("Delete Inport Transactions", "Delete Inport Transactions", Status.PASS);
		isElementAvailable(deleteTransaction, ELEMENTTIMEOUT);
		driver.findElement(deleteTransaction).click();
		try {
			if(driver.findElement(confirmationPopupDeleteImportTransaction).isDisplayed()) {
				report.updateTestLog("confirmation message for import transaction", "confirmation message for import transaction", Status.PASS);
				driver.findElement(popupYesButton).click();
				oracleObjectRender(QUERYRESPONSE);
				report.updateTestLog("Confirmation Info for Job Submission", "Confirmation is required for Deleting Import Transaction", Status.PASS);
			}
		} catch(Exception e) {
			report.updateTestLog("Confirmation Information for Job Submission", "Confirmation message for Job Submission is not successfully created", Status.FAIL);
		}

		isElementAvailable(jobsubmissionPopup1, PAGELOADTIMEOUT);
		try {
			if(driver.findElement(jobsubmissionPopup1).isDisplayed()) {
				report.updateTestLog("Confirmation message - Jobs Submission", "Confirmation message for Job Submission", Status.PASS);
				isElementAvailable(popupOKButton1, ELEMENTTIMEOUT);
				driver.findElement(popupOKButton1).click();
				oracleObjectRender(QUERYRESPONSE);
				report.updateTestLog("The Landing page is Jobs Homepage", "The Landing page is Jobs Homepage", Status.PASS);
			}
		} catch(Exception e) {
			report.updateTestLog("Confirmation message for Job Submission", "Confirmation message for Job Submission is not successfully created", Status.FAIL);
		}

        isElementAvailable(filterForName, ELEMENTTIMEOUT);
        driver.findElement(filterForName).click();
        oracleObjectRender(SCRIPTTIME);
        isElementAvailable(removeFilterForName, PAGELOADTIMEOUT);
        driver.findElement(removeFilterForName).click();
        oracleObjectRender(SCRIPTTIME);
		isElementAvailable(refreshButton, PAGELOADTIMEOUT);
		driver.findElement(refreshButton).click();
		oracleObjectRender(QUERYRESPONSE);

		if(driver.findElement(autoMatchTypeValidate).getAttribute("innerHTML").equals(dataTable.getData(ExcelDataImport.GeneralData, "MatchType"))) {
			report.updateTestLog("Delete Transactions process is created", "Delete Transactions process is created successfully", Status.PASS);
		} else {
			report.updateTestLog("Delete Transactions process is not created", "Delete Transactions process is not created successfully", Status.FAIL);
		}

	}

}