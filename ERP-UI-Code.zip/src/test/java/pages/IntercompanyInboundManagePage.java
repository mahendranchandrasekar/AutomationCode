package pages;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.ScriptHelper;
import com.cognizant.framework.ExcelDataImport;
import com.cognizant.framework.Status;
import org.junit.Assert;
import org.openqa.selenium.By;


/**
 * Journals Page class
 */
public class IntercompanyInboundManagePage extends MasterPages {
	// UI Map object definitions

	// Elements
	private final By batchNumberTxtbox= By.xpath("//label[text()='Batch Number']/following::input[1]");
    private final By accountingDateDrpdown= By.xpath("//label[text()='Accounting Date']/following::input[1]");
	private final By searchButton= By.xpath("//button[text()='Search']");
    private final By verifyIntercompanyTransactionRecord= By.xpath("//table[(@summary='Manage Intercompany Inbound Transactions - Search Results')]/tbody/tr[1]");
    private final By verifyIntercompanyTransactionRecordStatus= By.xpath("//table[(@summary='Manage Intercompany Inbound Transactions - Search Results')]/tbody/tr[1]/td[8]/child::*/child::*/span");

    //Page Sync Config
	// page loading time
	public static final int PAGELOADTIMEOUT = 90;
	// individual element load time
	public static final int ELEMENTTIMEOUT = 60;
	// Oracle query response
	public static final long QUERYRESPONSE = 15;
	// object render script
	public static final long SCRIPTTIME = 5;


	/**
	 * Constructor to initialize the page
	 *
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}b  n '/fg .+
	 */
	public IntercompanyInboundManagePage(ScriptHelper scriptHelper) {
		super(scriptHelper);
		isElementAvailable(batchNumberTxtbox, PAGELOADTIMEOUT);

	}

	public void searchAndVerifyIntercompanyTransaction(String batchNumber) {
		isElementAvailable(batchNumberTxtbox, ELEMENTTIMEOUT);
        driver.findElement(batchNumberTxtbox).sendKeys(batchNumber);
        isElementAvailable(accountingDateDrpdown, ELEMENTTIMEOUT);
        driver.findElement(accountingDateDrpdown).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "AccountingDate"));
		isElementAvailable(searchButton, ELEMENTTIMEOUT);
		driver.findElement(searchButton).click();
		isElementAvailable(verifyIntercompanyTransactionRecord, ELEMENTTIMEOUT);
		try {
			Assert.assertTrue(driver.findElement(verifyIntercompanyTransactionRecord).isDisplayed());
			report.updateTestLog("Search and verify Intercompany Transactions", "Intercompany Transactions record is created succesfully", Status.PASS);
			Assert.assertEquals(driver.findElement(verifyIntercompanyTransactionRecordStatus).getText(), dataTable.getData(ExcelDataImport.GeneralData, "IntercompanyTransactionStatus"));
		}catch(Exception e) {
			report.updateTestLog("Search and verify Intercompany Transactions", "Intercompany Transactions record is not created succesfully", Status.FAIL);
		}
	}

}