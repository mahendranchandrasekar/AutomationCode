package pages;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.ScriptHelper;
import com.cognizant.framework.ExcelDataImport;
import com.cognizant.framework.Status;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

/**
 * Journals Page class
 */
public class ArcsMatchingPage extends MasterPages {
	// UI Map object definitions

	// Elements
	private final By refreshIcon = By.xpath("//img[contains(@id,'zr2:0:zt0:0:psDash:0:btnRefresh::icon')]");
	private final By matchedTransactionTab = By.xpath("//span[(@title='Matches')]");
	private final By unMatchedTransactionTab = By.xpath("//span[(@title='Unmatched Transactions')]");
	private final By durationCalendar = By.xpath("//span[(text()='Duration')]");
	private final By durationDropdown = By.xpath("//span[contains(@id,'ojChoiceId_duration_filter_selected')]");

	private final By customDurationClick = By.xpath("//div[(@class='oj-listbox-drop-layer')]/div/ul/li[3]/div");
	private final By lastTwoFourHourClick = By.xpath("//div[(@class='oj-listbox-drop-layer')]/div/ul/li[1]/div");
	private final By lastOneWeekClick = By.xpath("//div[(@class='oj-listbox-drop-layer')]/div/ul/li[2]/div");
	private final By durationFromDate = By.xpath("//label[(text()='From')]/../../../../div[2]/div/div/input");
	private final By durationToDate = By.xpath("//label[(text()='To')]/../../../../div[2]/div/div/input");
	private final By matchStatusDropdown = By.xpath("//label[(text()='Match Status')]/../../../../div[2]/div[1]/div[1]/span");

	private final By confirmedMatchClick = By.xpath("//div[(@id='oj-listbox-drop')]/ul/li[1]/div");
	private final By suggestedMatchClick = By.xpath("//div[(@id='oj-listbox-drop')]/ul/li[2]/div");
	private final By confirmedAdjustClick = By.xpath("//div[(@id='oj-listbox-drop')]/ul/li[3]/div");
	private final By allmatch = By.xpath("//div[(@id='oj-listbox-drop')]/ul/li[5]/div");
	private final By applyButton = By.xpath("//span[(text()='Apply')]");

	private final By selectfirstRecordForMatched = By.xpath("//tbody[(@class='oj-table-body')]/tr[1]/td[3]/div");
	private final By clickonActionFirstRecordMatched = By.xpath("//tbody[(@class='oj-table-body')]/tr[1]/div/a");
	private final By clickonUnMatchButton = By.xpath("//ul[contains(@class,'oj-component-initnode oj-menu-dropdown')]/li[1]/a/div");
	private final By confirmationPopUpforMatched = By.xpath("//div[contains(text(),'This action will remove the match and any associated adjustment')]");
	private final By confirmationPopUpYesButton = By.xpath("//button[@id='yesButtonDelRC']");
	private final By closeButton = By.xpath("//button[@id='okButtonReconDetails']");

	private final By selectfirstRecordForUnMatched = By.xpath("//div[(@id='um_src_grid:databody')]/div[1]/div[2]");
	private final By exportCsvIcon = By.xpath("//span[@class='tmcs_icon_export oj-button-icon oj-start']");
	private final By confirmMessageForExportCsv = By.xpath("//div[contains(text(),'has been completed successfully.')]");
	private final By downloadLink = By.xpath("//a[(text()='Download')]");


	//Page Sync Config
	// page loading time
	public static final int PAGELOADTIMEOUT = 90;
	// individual element load time
	public static final int ELEMENTTIMEOUT = 60;
	// Oracle query response
	public static final long QUERYRESPONSE = 15;
	// object render script
	public static final long SCRIPTTIME = 5;


	/**
	 * Constructor to initialize the page
	 *
	 * @param scriptHelper The {@link ScriptHelper} object passed from the
	 *                     {@link DriverScript}b  n '/fg .+
	 */

	public ArcsMatchingPage(ScriptHelper scriptHelper) {
		super(scriptHelper);
		isElementAvailable(refreshIcon, PAGELOADTIMEOUT);

	}


	public void manuallyUnmatchTransaction() {
		isElementAvailable(refreshIcon, ELEMENTTIMEOUT);
		driver.findElement(refreshIcon).click();
		String MatchTypeData = dataTable.getData(ExcelDataImport.GeneralData, ExcelDataImport.MatchType);
		String genericXpathForSelection = "//a[(text()='" + MatchTypeData + "')]";
		if (MatchTypeData.equals(ExcelDataImport.B4c_OfPcGlVFsh)) {
			By ddgenericXpathForSelection = By.xpath(genericXpathForSelection);
			isElementAvailable(ddgenericXpathForSelection, ELEMENTTIMEOUT);
			driver.findElement(ddgenericXpathForSelection).click();
		} else if (MatchTypeData.equals("B4C OF BC GL vs FSH")) {
			By ddgenericXpathForSelection = By.xpath(genericXpathForSelection);
			oracleObjectRender(SCRIPTTIME);
			isElementAvailable(ddgenericXpathForSelection, ELEMENTTIMEOUT);
			driver.findElement(ddgenericXpathForSelection).click();
		}
		isElementAvailable(matchedTransactionTab, PAGELOADTIMEOUT);
		driver.findElement(matchedTransactionTab).click();
		oracleObjectRender(SCRIPTTIME);
		isElementAvailable(durationCalendar, PAGELOADTIMEOUT);
		driver.findElement(durationCalendar).click();
		isElementAvailable(durationDropdown, PAGELOADTIMEOUT);
		driver.findElement(durationDropdown).click();
		String durationData = dataTable.getData(ExcelDataImport.GeneralData, "Duration").trim();
		if (durationData.equals("Custom Duration")) {
			isElementAvailable(customDurationClick, ELEMENTTIMEOUT);
			driver.findElement(customDurationClick).click();
		} else if (durationData.equals("Last One Week")) {
			isElementAvailable(lastOneWeekClick, ELEMENTTIMEOUT);
			driver.findElement(lastOneWeekClick).click();
		} else if (durationData.equals("Last 24 hours")) {
			isElementAvailable(lastTwoFourHourClick, ELEMENTTIMEOUT);
			driver.findElement(lastTwoFourHourClick).click();
		}
		isElementAvailable(durationFromDate, PAGELOADTIMEOUT);
		driver.findElement(durationFromDate).clear();
		driver.findElement(durationFromDate).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "DurationFromDate"));
        driver.findElement(durationFromDate).sendKeys(Keys.TAB);
		isElementAvailable(durationToDate, ELEMENTTIMEOUT);
		driver.findElement(durationToDate).clear();
		driver.findElement(durationToDate).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "DurationToDate"));
        driver.findElement(durationToDate).sendKeys(Keys.TAB);
		String durationMatchStatusData = dataTable.getData(ExcelDataImport.GeneralData, "DurationMatchStatus").trim();
		if (durationMatchStatusData.equals("Confirmed Match")) {
            isElementAvailable(matchStatusDropdown, ELEMENTTIMEOUT);
            driver.findElement(matchStatusDropdown).click();
		    oracleObjectRender(SCRIPTTIME);
			isElementAvailable(confirmedMatchClick, ELEMENTTIMEOUT);
			driver.findElement(confirmedMatchClick).click();
		} else if (durationMatchStatusData.equals("Suggested Match")) {
			isElementAvailable(suggestedMatchClick, ELEMENTTIMEOUT);
			driver.findElement(suggestedMatchClick).click();
		} else if (durationMatchStatusData.equals("Confirmed Adjust")) {
			isElementAvailable(confirmedAdjustClick, ELEMENTTIMEOUT);
			driver.findElement(confirmedAdjustClick).click();
		} else if (durationMatchStatusData.equals("All")) {
			isElementAvailable(allmatch, ELEMENTTIMEOUT);
			driver.findElement(allmatch).click();
		}
		report.updateTestLog("Filtering the Records", "Filtering the Records from the Corresponding Duration and match status", Status.PASS);
		isElementAvailable(applyButton, ELEMENTTIMEOUT);
		driver.findElement(applyButton).click();
		isElementAvailable(selectfirstRecordForMatched, PAGELOADTIMEOUT);
		driver.findElement(selectfirstRecordForMatched).click();
		isElementAvailable(clickonActionFirstRecordMatched, ELEMENTTIMEOUT);
		driver.findElement(clickonActionFirstRecordMatched).click();
		oracleObjectRender(SCRIPTTIME);
		isElementAvailable(clickonUnMatchButton, ELEMENTTIMEOUT);
		driver.findElement(clickonUnMatchButton).click();
		try {
			if (driver.findElement(confirmationPopUpforMatched).isDisplayed()) {
				report.updateTestLog("Confirmation message for Job Submission", "Confirmation message for Job Submission is successfully created", Status.PASS);
				isElementAvailable(confirmationPopUpYesButton, ELEMENTTIMEOUT);
				driver.findElement(confirmationPopUpYesButton).click();
				oracleObjectRender(QUERYRESPONSE);
				report.updateTestLog("The Landing page is Jobs Homepage", "The Landing page is Jobs Homepage", Status.PASS);
			}
		} catch (Exception e) {
			report.updateTestLog("Confirmation message for Job Submission", "Confirmation message for Job Submission is not successfully created", Status.FAIL);
		}
		isElementAvailable(closeButton, PAGELOADTIMEOUT);
		driver.findElement(closeButton).click();
	}

	public void runManualMatch() {
		isElementAvailable(refreshIcon, ELEMENTTIMEOUT);
		driver.findElement(refreshIcon).click();
		oracleObjectRender(SCRIPTTIME);
		String MatchTypeData = dataTable.getData(ExcelDataImport.GeneralData, "MatchType");
		String genericXpathForSelection = "//a[(text()='" + MatchTypeData + "')]";
		if (MatchTypeData.equals(ExcelDataImport.B4c_OfPcGlVFsh)) {
			By ddgenericXpathForSelection = By.xpath(genericXpathForSelection);
			oracleObjectRender(SCRIPTTIME);
					report.updateTestLog("Source system", "Selection of  Source system  based on datatables", Status.PASS);
			isElementAvailable(ddgenericXpathForSelection, ELEMENTTIMEOUT);
			driver.findElement(ddgenericXpathForSelection).click();
		} else if (MatchTypeData.equals("B4C PC DM V FSH")) {
			By ddgenericXpathForSelection = By.xpath(genericXpathForSelection);
			oracleObjectRender(SCRIPTTIME);
			report.updateTestLog("Source systems", "Selection of  Source system based  on datatables", Status.PASS);
			isElementAvailable(ddgenericXpathForSelection, ELEMENTTIMEOUT);
			driver.findElement(ddgenericXpathForSelection).click();
		}
		isElementAvailable(unMatchedTransactionTab, PAGELOADTIMEOUT);
		driver.findElement(unMatchedTransactionTab).click();
		oracleObjectRender(SCRIPTTIME);
        report.updateTestLog("Application behaviour", "For Unmatched Transaction - No data available in FSH table", Status.FAIL);
        isElementAvailable(closeButton, ELEMENTTIMEOUT);
        driver.findElement(closeButton).click();
        oracleObjectRender(SCRIPTTIME);
	}


	public void exportUnmatchedTransaction() {
		isElementAvailable(refreshIcon, ELEMENTTIMEOUT);
		driver.findElement(refreshIcon).click();
		String MatchTypeData = dataTable.getData(ExcelDataImport.GeneralData, "MatchType");
		String genericXpathForSelection = "//a[(text()='" + MatchTypeData + "')]";
        if (MatchTypeData.equals(ExcelDataImport.B4c_OfPcGlVFsh)) {
            By ddgenericXpathForSelection = By.xpath(genericXpathForSelection);
			oracleObjectRender(SCRIPTTIME);
			report.updateTestLog("Selection of Source system", "Selection  of Source system based on datatables", Status.PASS);
            isElementAvailable(ddgenericXpathForSelection, ELEMENTTIMEOUT);
            driver.findElement(ddgenericXpathForSelection).click();
        } else if(MatchTypeData.equals(ExcelDataImport.B4c_PcDmVFsh)) {
            By ddgenericXpathForSelection = By.xpath(genericXpathForSelection);
            oracleObjectRender(SCRIPTTIME);
			report.updateTestLog("Selection of Source system", "Selection of  Source system based on datatables", Status.PASS);
            isElementAvailable(ddgenericXpathForSelection, ELEMENTTIMEOUT);
            driver.findElement(ddgenericXpathForSelection).click();
        }
		isElementAvailable(unMatchedTransactionTab, PAGELOADTIMEOUT);
		driver.findElement(unMatchedTransactionTab).click();
        oracleObjectRender(SCRIPTTIME);
		isElementAvailable(selectfirstRecordForUnMatched, ELEMENTTIMEOUT);
		driver.findElement(selectfirstRecordForUnMatched).click();
		isElementAvailable(exportCsvIcon, ELEMENTTIMEOUT);
		driver.findElement(exportCsvIcon).click();
		oracleObjectRender(QUERYRESPONSE);
		try {
			if(driver.findElement(confirmMessageForExportCsv).isDisplayed()) {
				report.updateTestLog("Confirmation message for download", "Confirmation message for Exporting the selected Source", Status.PASS);
			}
		} catch(Exception e) {
			report.updateTestLog("Confirmation message for download", "Confirmation message is not displayed for Exporting the selected Source", Status.FAIL);
		}
        oracleObjectRender(SCRIPTTIME);
		isElementAvailable(downloadLink, ELEMENTTIMEOUT);
		driver.findElement(downloadLink).click();
		isElementAvailable(closeButton, PAGELOADTIMEOUT);
		driver.findElement(closeButton).click();
	}
}