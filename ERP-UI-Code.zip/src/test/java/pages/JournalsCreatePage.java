package pages;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.ScriptHelper;
import com.cognizant.framework.ExcelDataImport;
import com.cognizant.framework.Status;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;


/**
 * Journals Page class
 */
public class JournalsCreatePage extends MasterPages {
	// UI Map object definitions

	// Elements
	private final By journalBatchTxtbox= By.xpath("//label[text()='Journal Batch']/following::input[1]");
    private final By descriptionTxtbox1= By.xpath("//textarea[contains(@id,'showLessBatchDescription::content')]");
	private final By accountingPeriodDrpdown= By.xpath("//label[text()='Accounting Period']/following::input[2]");
	private final By accountingPeriodDrpdownValidate= By.xpath("//tr[contains(@id,'showLessPeriodNameCLOV:sis1:is1::item0')]/td[1]");
	private final By journalTxtbox= By.xpath("//label[text()='Journal']/following::input[1]");
	private final By descriptionTxtbox2= By.xpath("//textarea[contains(@id,'showLessJournalDescription::content')]");
	private final By ledgerDrpdown= By.xpath("//label[text()='Ledger']/following::input[2]");
    private final By accountingDateField= By.xpath("//label[text()='Accounting Date']/following::input[1]");
	private final By categoryDrpdown= By.xpath("//label[text()='Accounting Date']/../../following-sibling::tr[1]/td[2]/span/span/span/input");
	private final By categoryDrpdownListValidate= By.xpath("//table[contains(@id,'userJeCategoryNameInputSearch1::sgstnBdy')]/tr[1]/td[1]");

	private final By currencyDrpdown= By.xpath("//label[text()='Currency']/following::input[2]");
	private final By currencyDrpdownValidate= By.xpath("//table[contains(@id,'headerCurrencyCodeCLOV1:sis1:is1::sgstnBdy')]/tr[1]");
	private final By conversionRateTextBox= By.xpath("//label[text()='Conversion Rate']/following::input[1]");
	private final By conversionRateTypeDrpdown= By.xpath("//label[text()='Conversion Rate Type']/following::input[2]");
	private final By conversionRateTypeDrpdownValidate= By.xpath("//table[contains(@id,'headerConversionTypeCLOV1:sis1:is1::sgstnBdy')]/tr[1]/td[1]");

	private final By journalLine1Account= By.xpath("//table[contains(@summary,'Journal Lines')]/tbody/tr[1]/td[4]/child::*/child::*/child::*/child::*/child::*/child::*/child::*/child::*/input");
	private final By accountCostCenterDrpDown= By.xpath("//input[contains(@id,'accountSPOP_query:value10::content')]");
	private final By accountOKButton= By.xpath("//button[contains(@id,'LineAppTable:_ATp:t3:0:accountSEl')]");
	private final By accountCancelButton= By.xpath("//button[contains(@id,'LineAppTable:_ATp:t3:0:accountCNL')]");
	private final By journalLine1Debit= By.xpath("//table[contains(@summary,'Journal Lines')]/tbody/tr[1]/td[5]/child::*/child::*/input");
	private final By journalLine1DebitConversion= By.xpath("//table[contains(@summary,'Journal Lines')]/tbody/tr[1]/td[7]/child::*/child::*/input");
	private final By journalLine1Credit= By.xpath("//table[contains(@summary,'Journal Lines')]/tbody/tr[1]/td[6]/child::*/child::*/input");
	private final By journalLine1Description= By.xpath("//table[contains(@summary,'Journal Lines')]/tbody/tr[1]/td[9]/child::*/child::*/input");
	private final By journalLine1DescriptionOther= By.xpath("//table[contains(@summary,'Journal Lines')]/tbody/tr[1]/td[11]/child::*/child::*/input");

	private final By journalLine2Account= By.xpath("//table[contains(@summary,'Journal Lines')]/tbody/tr[2]/td[4]/child::*/child::*/child::*/child::*/child::*/child::*/child::*/child::*/input");
	private final By journalLine2Debit= By.xpath("//table[contains(@summary,'Journal Lines')]/tbody/tr[2]/td[5]/child::*/child::*/input");
	private final By journalLine2DebitConversion= By.xpath("//table[contains(@summary,'Journal Lines')]/tbody/tr[2]/td[7]/child::*/child::*/input");
	private final By journalLine2Credit= By.xpath("//table[contains(@summary,'Journal Lines')]/tbody/tr[2]/td[6]/child::*/child::*/input");
	private final By journalLine2Description= By.xpath("//table[contains(@summary,'Journal Lines')]/tbody/tr[2]/td[9]/child::*/child::*/input");
	private final By journalLine2DescriptionOther= By.xpath("//table[contains(@summary,'Journal Lines')]/tbody/tr[2]/td[11]/child::*/child::*/input");

	private final By saveButton= By.xpath("//span[text()='Save']");
	private final By completeButton= By.xpath("//span[text()='Complete']");
	private final By postButton= By.xpath("//span[text()='Post']");
    private final By batchActionsDrpdown= By.xpath("//a[text()='Batch Actions']");
    private final By copyDrpdownText= By.xpath("//td[text()='Copy']");
	private final By deleteDrpdownText= By.xpath("//td[text()='Copy']/../../tr[2]/td[2]");
    private final By editJournalBatchText= By.xpath("//input[contains(@id,'general_accounting_journals:0:MAnt2:2:pt1:ap1:it3::content')]");

	private final By warningMsgAccountingPeriod= By.xpath("//div[text()='Please select an item from suggestions']");
	private final By componentErrorForAccountingPeriod= By.xpath("//a[text()='Component']");

	//private final By iFrameTag= By.xpath("//iframe");
	//private final By popUpTitle= By.xpath("//div[text()='Confirmation']");
	//private final By popUpOkButton= By.xpath("//button[contains(@id,'_FOd1::msgDlg::cancel')]");

	//private final By popUpConfirmationText= By.xpath("//span[contains(@id,'general_accounting_journals:0:MAnt2:1:pt1:ap1:userRes:1:ot1')]");
	private final By popUpYesButton= By.xpath("//button[contains(@id,'userResponsePopupDialogButtonYes')]");
	private final By popUpDeleteText= By.xpath("//*[text()='The journal batch will be deleted. Do you want to continue?']");
    private final By journalApprovalPopupOkButton= By.xpath("//button[contains(@id,'userResponsePopupDialogButtonOk')]");

	private final By popUpWarningTextForUnEqualCrAndDr= By.xpath("//div[contains(text(),'The total accounted debit and credit for this journal batch aren')]");


	//Page Sync Config

	// page loading time
	public static final int PAGELOADTIMEOUT = 90;
	// individual element load time
	public static final int ELEMENTTIMEOUT = 60;
	// Oracle query response
	public static final long QUERYRESPONSE = 15;
	// object render script
	public static final long SCRIPTTIME = 5;


	//Variables from Excel sheet
	String journalBatchData = dataTable.getData(ExcelDataImport.GeneralData, "JournalBatch");
	String description1Data = dataTable.getData(ExcelDataImport.GeneralData, "Description1");
	String accountPeriodData = dataTable.getData(ExcelDataImport.GeneralData, "AccountingPeriod");
	String journalData = dataTable.getData(ExcelDataImport.GeneralData, "journal");
	String description2Data = dataTable.getData(ExcelDataImport.GeneralData, "Description2");
	String accountingDateData = dataTable.getData(ExcelDataImport.GeneralData, "AccountingDate");
	String categoryData = dataTable.getData(ExcelDataImport.GeneralData, "Category");
	String currencyData = dataTable.getData(ExcelDataImport.GeneralData, ExcelDataImport.Currency);

	String journalLine1AccountData = dataTable.getData(ExcelDataImport.GeneralData, "JournalLine1Account");
	String journalLine1DebitData = dataTable.getData(ExcelDataImport.GeneralData, "JournalLine1Debit");
	String journalLine1CreditData = dataTable.getData(ExcelDataImport.GeneralData, "JournalLine1Credit");
	String journalLine1DescriptionData = dataTable.getData(ExcelDataImport.GeneralData, "JournalLine1Description");

	String journalLine2AccountData = dataTable.getData(ExcelDataImport.GeneralData, "JournalLine2Account");
	String journalLine2DebitData = dataTable.getData(ExcelDataImport.GeneralData, "JournalLine2Debit");
	String journalLine2CreditData = dataTable.getData(ExcelDataImport.GeneralData, "JournalLine2Credit");
	String journalLine2DescriptionData = dataTable.getData(ExcelDataImport.GeneralData, "JournalLine2Description");


	/**
	 * Constructor to initialize the page
	 *
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}b  n '/fg .+
	 */

	public JournalsCreatePage(ScriptHelper scriptHelper) {
		super(scriptHelper);
		isElementAvailable(journalBatchTxtbox, PAGELOADTIMEOUT);
	}


    public void autoCopyForCreateJournal() {
		isElementAvailable(batchActionsDrpdown, PAGELOADTIMEOUT);
		driver.findElement(batchActionsDrpdown).click();
		report.updateTestLog("Autocopy Journals", "To Select copy from BATCH ACTION dropdown", Status.PASS);
		isElementAvailable(copyDrpdownText, ELEMENTTIMEOUT);
		driver.findElement(copyDrpdownText).click();
		isElementAvailable(editJournalBatchText, PAGELOADTIMEOUT);
		driver.findElement(editJournalBatchText).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "JournalBatch"));
		isElementAvailable(journalApprovalPopupOkButton, ELEMENTTIMEOUT);
		driver.findElement(journalApprovalPopupOkButton).click();
		oracleObjectRender(QUERYRESPONSE);
		isElementAvailable(descriptionTxtbox1, ELEMENTTIMEOUT);
		driver.findElement(descriptionTxtbox1).clear();
		oracleObjectRender(SCRIPTTIME);
		driver.findElement(descriptionTxtbox1).sendKeys(description1Data);
		isElementAvailable(journalBatchTxtbox, ELEMENTTIMEOUT);
		driver.findElement(journalBatchTxtbox).isDisplayed();
		report.updateTestLog("Modified Journal Batch Name", "A modified Journal Batch name is updated", Status.PASS);
		isElementAvailable(descriptionTxtbox1, ELEMENTTIMEOUT);
		driver.findElement(descriptionTxtbox1).isDisplayed();
		report.updateTestLog("Modified Journal Description", "A modified Journal Description is updated", Status.PASS);
	}

	public void deleteForCreateJournal() {
		isElementAvailable(batchActionsDrpdown, PAGELOADTIMEOUT);
		driver.findElement(batchActionsDrpdown).click();
		report.updateTestLog("Delete Journals", "To Delete the Journal from BATCH ACTION dropdown", Status.PASS);
		isElementAvailable(deleteDrpdownText, ELEMENTTIMEOUT);
		driver.findElement(deleteDrpdownText).click();
		isElementAvailable(popUpDeleteText, PAGELOADTIMEOUT);
		try {
			if(driver.findElement(popUpDeleteText).isDisplayed()) {
				report.updateTestLog("Warning message for Deleting the Journal", "Warning message for Deleting the Journal", Status.PASS);
				driver.findElement(popUpYesButton).click();
				oracleObjectRender(QUERYRESPONSE);
				report.updateTestLog("Verify the Manage journal page", "The Landing page is Manage Journal", Status.PASS);
			}
		} catch(Exception e) {
			report.updateTestLog("Verify the Manage journal page", "The Landing page is not moved to Manage Journal", Status.FAIL);
		}
        Assert.assertTrue(driver.getTitle().contains(dataTable.getData(ExcelDataImport.GeneralData, "Comments")));
	}


	public void EnterBasicDetailsForCreateJournal() {
		isElementAvailable(journalBatchTxtbox, PAGELOADTIMEOUT);
		driver.findElement(journalBatchTxtbox).sendKeys(journalBatchData);
		isElementAvailable(descriptionTxtbox1, ELEMENTTIMEOUT);
		driver.findElement(descriptionTxtbox1).sendKeys(description1Data);
		isElementAvailable(accountingPeriodDrpdown, ELEMENTTIMEOUT);
		driver.findElement(accountingPeriodDrpdown).clear();
		driver.findElement(accountingPeriodDrpdown).sendKeys(accountPeriodData);
		isElementAvailable(accountingPeriodDrpdownValidate, ELEMENTTIMEOUT);
		driver.findElement(accountingPeriodDrpdownValidate).click();
		driver.findElement(journalTxtbox).sendKeys(journalData);
		driver.findElement(descriptionTxtbox2).sendKeys(description2Data);
		Assert.assertEquals(driver.findElement(ledgerDrpdown).getAttribute(ExcelDataImport.value), (dataTable.getData(ExcelDataImport.GeneralData, ExcelDataImport.DataAccessSet)));
		/*isElementAvailable(accountingDateField, ELEMENTTIMEOUT);
		driver.findElement(accountingDateField).clear();
		driver.findElement(accountingDateField).sendKeys(accountingDateData);*/
		driver.findElement(accountingDateField).sendKeys(Keys.TAB);
		oracleObjectRender(QUERYRESPONSE);
        isElementAvailable(categoryDrpdown, ELEMENTTIMEOUT);
		driver.findElement(categoryDrpdown).sendKeys(categoryData);
		oracleObjectRender(QUERYRESPONSE);
        oracleObjectRender(SCRIPTTIME);
		isElementAvailable(categoryDrpdownListValidate, ELEMENTTIMEOUT);
			driver.findElement(categoryDrpdownListValidate).click();
			oracleObjectRender(QUERYRESPONSE);
		if ((dataTable.getData(ExcelDataImport.GeneralData, ExcelDataImport.Currency)).equals("GBP")) {
			report.updateTestLog("Journal Section", "To verify Journal Information", Status.PASS);
		} else {
			isElementAvailable(currencyDrpdown, ELEMENTTIMEOUT);
			driver.findElement(currencyDrpdown).clear();
			driver.findElement(currencyDrpdown).sendKeys(currencyData);
			oracleObjectRender(QUERYRESPONSE);
			isElementAvailable(currencyDrpdownValidate, ELEMENTTIMEOUT);
			driver.findElement(currencyDrpdownValidate).click();
			oracleObjectRender(QUERYRESPONSE);
			isElementAvailable(conversionRateTypeDrpdown, ELEMENTTIMEOUT);
			driver.findElement(conversionRateTypeDrpdown).clear();
			driver.findElement(conversionRateTypeDrpdown).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, ExcelDataImport.ConversionRateType));
			oracleObjectRender(QUERYRESPONSE);
			isElementAvailable(conversionRateTypeDrpdownValidate, ELEMENTTIMEOUT);
			driver.findElement(conversionRateTypeDrpdownValidate).click();
			isElementAvailable(conversionRateTextBox, ELEMENTTIMEOUT);
			driver.findElement(conversionRateTextBox).clear();
			driver.findElement(conversionRateTextBox).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, ExcelDataImport.ConversionRate));
			driver.findElement(conversionRateTextBox).sendKeys(Keys.TAB);
			oracleObjectRender(QUERYRESPONSE);
			report.updateTestLog("Journal Section", "To verify Journal Information along with Foreign Currency Conversion data", Status.PASS);
		}
	}

		public void enterBankDetailsForForiegnCurrency() {
		isElementAvailable(journalLine1Account, PAGELOADTIMEOUT);
		driver.findElement(journalLine1Account).click();
		driver.findElement(journalLine1Account).sendKeys(journalLine1AccountData);

		if (journalLine1DebitData.equals("0")) {
			isElementAvailable(journalLine1Credit, ELEMENTTIMEOUT);
			driver.findElement(journalLine1Credit).sendKeys(journalLine1CreditData);
			driver.findElement(journalLine1Credit).sendKeys(Keys.TAB);
			oracleObjectRender(QUERYRESPONSE);
		} else {
			isElementAvailable(journalLine1Debit, ELEMENTTIMEOUT);
			driver.findElement(journalLine1Debit).sendKeys(journalLine1DebitData);
			driver.findElement(journalLine1Debit).sendKeys(Keys.TAB);
			oracleObjectRender(QUERYRESPONSE);
			isElementAvailable(journalLine1DebitConversion, ELEMENTTIMEOUT);
			driver.findElement(journalLine1DebitConversion).sendKeys(Keys.TAB);
			oracleObjectRender(QUERYRESPONSE);
		}
			isElementAvailable(journalLine1DescriptionOther, ELEMENTTIMEOUT);
			driver.findElement(journalLine1DescriptionOther).sendKeys(journalLine1DescriptionData);
			driver.findElement(journalLine1DescriptionOther).sendKeys(Keys.ENTER);

		oracleObjectRender(QUERYRESPONSE);
		isElementAvailable(journalLine2Account, ELEMENTTIMEOUT);
		driver.findElement(journalLine2Account).click();
		oracleObjectRender(QUERYRESPONSE);
		isElementAvailable(journalLine2Account, ELEMENTTIMEOUT);
		driver.findElement(journalLine2Account).sendKeys(journalLine2AccountData);
		oracleObjectRender(QUERYRESPONSE);

		if (journalLine2DebitData.equals("0")) {
			isElementAvailable(journalLine2Credit, ELEMENTTIMEOUT);
			driver.findElement(journalLine2Credit).sendKeys(journalLine2CreditData);
			driver.findElement(journalLine2Credit).sendKeys(Keys.TAB);
			oracleObjectRender(QUERYRESPONSE);

		} else {
			isElementAvailable(journalLine2Debit, ELEMENTTIMEOUT);
			driver.findElement(journalLine2Debit).sendKeys(journalLine2DebitData);
			driver.findElement(journalLine2Debit).sendKeys(Keys.TAB);
			oracleObjectRender(QUERYRESPONSE);
			isElementAvailable(journalLine2DebitConversion, ELEMENTTIMEOUT);
			driver.findElement(journalLine2DebitConversion).sendKeys(Keys.TAB);
			oracleObjectRender(QUERYRESPONSE);
		}
			isElementAvailable(journalLine2DescriptionOther, ELEMENTTIMEOUT);
			driver.findElement(journalLine2DescriptionOther).sendKeys(journalLine2DescriptionData);
			driver.findElement(journalLine2DescriptionOther).sendKeys(Keys.ENTER);
			isElementAvailable(journalLine2DescriptionOther, ELEMENTTIMEOUT);
			oracleObjectRender(QUERYRESPONSE);
			report.updateTestLog("Journal Lines Section", "To verify Journal Information data along with Foreign Currency Conversion data", Status.PASS);

	}

	public void enterBankDetailsForGBPCurrency() {
		isElementAvailable(journalLine1Account, PAGELOADTIMEOUT);
		driver.findElement(journalLine1Account).click();
		driver.findElement(journalLine1Account).sendKeys(journalLine1AccountData);

		if (journalLine1DebitData.equals("0")) {
			isElementAvailable(journalLine1Credit, ELEMENTTIMEOUT);
			driver.findElement(journalLine1Credit).sendKeys(journalLine1CreditData);
			driver.findElement(journalLine1Credit).sendKeys(Keys.TAB);
			oracleObjectRender(QUERYRESPONSE);
		} else {
			isElementAvailable(journalLine1Debit, ELEMENTTIMEOUT);
			driver.findElement(journalLine1Debit).sendKeys(journalLine1DebitData);
			driver.findElement(journalLine1Debit).sendKeys(Keys.TAB);
			oracleObjectRender(QUERYRESPONSE);
		}
			isElementAvailable(journalLine1Description, ELEMENTTIMEOUT);
			driver.findElement(journalLine1Description).sendKeys(journalLine1DescriptionData);
			driver.findElement(journalLine1Description).sendKeys(Keys.ENTER);
		oracleObjectRender(QUERYRESPONSE);
		isElementAvailable(journalLine2Account, ELEMENTTIMEOUT);
		driver.findElement(journalLine2Account).click();
		oracleObjectRender(QUERYRESPONSE);
		isElementAvailable(journalLine2Account, ELEMENTTIMEOUT);
		driver.findElement(journalLine2Account).sendKeys(journalLine2AccountData);
		oracleObjectRender(QUERYRESPONSE);

		if (journalLine2DebitData.equals("0")) {
			isElementAvailable(journalLine2Credit, ELEMENTTIMEOUT);
			driver.findElement(journalLine2Credit).sendKeys(journalLine2CreditData);
			driver.findElement(journalLine2Credit).sendKeys(Keys.TAB);
			oracleObjectRender(QUERYRESPONSE);

		} else {
			isElementAvailable(journalLine2Debit, ELEMENTTIMEOUT);
			driver.findElement(journalLine2Debit).sendKeys(journalLine2DebitData);
			driver.findElement(journalLine2Debit).sendKeys(Keys.TAB);
			oracleObjectRender(QUERYRESPONSE);
		}
		isElementAvailable(journalLine2Description, ELEMENTTIMEOUT);
			driver.findElement(journalLine2Description).sendKeys(journalLine2DescriptionData);
			driver.findElement(journalLine2Description).sendKeys(Keys.ENTER);
			isElementAvailable(journalLine2Description, ELEMENTTIMEOUT);
			oracleObjectRender(QUERYRESPONSE);
	}

	public void saveTheDetailsForCreateJournal() {
		isElementAvailable(saveButton, ELEMENTTIMEOUT);
		driver.findElement(saveButton).click();
		report.updateTestLog("To Save the details", "The user is able to save the details for Create Journal", Status.PASS);
	}

	public void completeTheDetailsForCreateJournal() {
		isElementAvailable(completeButton, PAGELOADTIMEOUT);
		driver.findElement(completeButton).click();
		oracleObjectRender(QUERYRESPONSE);
		report.updateTestLog("To Complete the details", "The user is able to complete the details for Create Journal", Status.PASS);
	}

	public void postTheDetailsForCreateJournal() {
			isElementAvailable(postButton, PAGELOADTIMEOUT);
			driver.findElement(postButton).click();
			oracleObjectRender(QUERYRESPONSE);
			isElementAvailable(postButton, PAGELOADTIMEOUT);

			try {
				isElementAvailable(journalApprovalPopupOkButton, ELEMENTTIMEOUT);
				driver.findElement(journalApprovalPopupOkButton).isDisplayed();
				oracleObjectRender(SCRIPTTIME);
				driver.findElement(journalApprovalPopupOkButton).click();
				oracleObjectRender(QUERYRESPONSE);
				report.updateTestLog("Verify Journal Approval", "The user requires approval  ", Status.PASS);
			} catch (Exception e) {
				report.updateTestLog("Verify Journal Approval", "The user already have approval rights  ", Status.PASS);
			}
	}


		public void saveTheDetailsForCreateJournalForUnEqualCRAndDR() {
			isElementAvailable(saveButton, ELEMENTTIMEOUT);
			driver.findElement(saveButton).click();
			try {
				isElementAvailable(popUpWarningTextForUnEqualCrAndDr, ELEMENTTIMEOUT);
				driver.findElement(popUpWarningTextForUnEqualCrAndDr).isDisplayed();
				report.updateTestLog("Verify  total Accounted Debit and Credit are unequal", "Accounted Debit and Credit are unequal for clicking on Save Button", Status.PASS);
				driver.findElement(popUpYesButton).click();
				oracleObjectRender(QUERYRESPONSE);
			} catch (Exception e) {
				report.updateTestLog("To Save the details", "The System should not allow to Save the details without warning message for Creating a Journal", Status.FAIL);
			}
		}

		public void verifyAccountInJournalLines() {
			report.updateTestLog("To Enter the details for Create Journal", "The user is able to Enter the details for Create Journal", Status.PASS);
			isElementAvailable(journalBatchTxtbox, PAGELOADTIMEOUT);
			driver.findElement(journalBatchTxtbox).sendKeys(journalBatchData);
			isElementAvailable(descriptionTxtbox1, ELEMENTTIMEOUT);
			driver.findElement(descriptionTxtbox1).sendKeys(description1Data);
			/*isElementAvailable(accountingPeriodDrpdown, ELEMENTTIMEOUT);
			driver.findElement(accountingPeriodDrpdown).clear();
			driver.findElement(accountingPeriodDrpdown).sendKeys(accountPeriodData);
			isElementAvailable(accountingPeriodDrpdownValidate, ELEMENTTIMEOUT);
			driver.findElement(accountingPeriodDrpdownValidate).click();*/
			driver.findElement(journalTxtbox).sendKeys(journalData);
			driver.findElement(descriptionTxtbox2).sendKeys(description2Data);
			Assert.assertEquals(driver.findElement(ledgerDrpdown).getAttribute("value"), (dataTable.getData(ExcelDataImport.GeneralData, "DataAccessSet")));
			/*isElementAvailable(accountingDateField, ELEMENTTIMEOUT);
			driver.findElement(accountingDateField).clear();
			driver.findElement(accountingDateField).sendKeys(accountingDateData);*/
			driver.findElement(accountingDateField).sendKeys(Keys.TAB);
			oracleObjectRender(QUERYRESPONSE);
			isElementAvailable(categoryDrpdown, ELEMENTTIMEOUT);
			driver.findElement(categoryDrpdown).sendKeys(categoryData);
			oracleObjectRender(QUERYRESPONSE);
			isElementAvailable(categoryDrpdownListValidate, ELEMENTTIMEOUT);
			driver.findElement(categoryDrpdownListValidate).click();
			oracleObjectRender(QUERYRESPONSE);
			if ((dataTable.getData(ExcelDataImport.GeneralData, ExcelDataImport.Currency)).equals("GBP")) {
				report.updateTestLog("Default selected Currency", "verify the default selected Currency is GBP", Status.PASS);
			} else {
				isElementAvailable(currencyDrpdown, ELEMENTTIMEOUT);
				driver.findElement(currencyDrpdown).clear();
				driver.findElement(currencyDrpdown).sendKeys(currencyData);
				oracleObjectRender(QUERYRESPONSE);
				isElementAvailable(currencyDrpdownValidate, ELEMENTTIMEOUT);
				driver.findElement(currencyDrpdownValidate).click();
				oracleObjectRender(QUERYRESPONSE);
				isElementAvailable(conversionRateTypeDrpdown, ELEMENTTIMEOUT);
				driver.findElement(conversionRateTypeDrpdown).clear();
				driver.findElement(conversionRateTypeDrpdown).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "ConversionRateType"));
				oracleObjectRender(QUERYRESPONSE);
				isElementAvailable(conversionRateTypeDrpdownValidate, ELEMENTTIMEOUT);
				driver.findElement(conversionRateTypeDrpdownValidate).click();
				isElementAvailable(conversionRateTextBox, ELEMENTTIMEOUT);
				driver.findElement(conversionRateTextBox).clear();
				driver.findElement(conversionRateTextBox).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "ConversionRate"));
				driver.findElement(conversionRateTextBox).sendKeys(Keys.TAB);
				oracleObjectRender(QUERYRESPONSE);
			}
			isElementAvailable(journalLine1Account, PAGELOADTIMEOUT);
			driver.findElement(journalLine1Account).click();
			driver.findElement(journalLine1Account).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "InvalidJournalLine1Account"));
			driver.findElement(journalLine1Account).sendKeys(Keys.TAB);
			oracleObjectRender(QUERYRESPONSE);
			isElementAvailable(accountCostCenterDrpDown, PAGELOADTIMEOUT);
			driver.findElement(accountCostCenterDrpDown).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "InvalidAccountCostCenter"));
			driver.findElement(accountOKButton).click();
			oracleObjectRender(QUERYRESPONSE);
			report.updateTestLog("Verify inCorrect Combination for Account", "inCorrect Combination for Account for Journal Lines", Status.PASS);
			isElementAvailable(accountCancelButton, ELEMENTTIMEOUT);
			driver.findElement(accountCancelButton).click();
			isElementAvailable(journalLine1Account, PAGELOADTIMEOUT);
			driver.findElement(journalLine1Account).clear();


			//Account Number, Credit and Debit details
			isElementAvailable(journalLine1Account, ELEMENTTIMEOUT);
			driver.findElement(journalLine1Account).sendKeys(journalLine1AccountData);
			if (journalLine1DebitData.equals("0")) {
				oracleObjectRender(QUERYRESPONSE);
				isElementAvailable(journalLine1Credit, ELEMENTTIMEOUT);
				driver.findElement(journalLine1Credit).sendKeys(journalLine1CreditData);
				driver.findElement(journalLine1Credit).sendKeys(Keys.TAB);
				oracleObjectRender(QUERYRESPONSE);
			} else {
				oracleObjectRender(QUERYRESPONSE);
				isElementAvailable(journalLine1Debit, ELEMENTTIMEOUT);
				driver.findElement(journalLine1Debit).sendKeys(journalLine1DebitData);
				driver.findElement(journalLine1Debit).sendKeys(Keys.TAB);
				oracleObjectRender(QUERYRESPONSE);
			}
			if ((dataTable.getData(ExcelDataImport.GeneralData, ExcelDataImport.Currency)).equals("GBP")) {
				isElementAvailable(journalLine1Description, ELEMENTTIMEOUT);
				driver.findElement(journalLine1Description).sendKeys(journalLine1DescriptionData);
				driver.findElement(journalLine1Description).sendKeys(Keys.ENTER);
			} else {
				isElementAvailable(journalLine1DescriptionOther, ELEMENTTIMEOUT);
				driver.findElement(journalLine1DescriptionOther).sendKeys(journalLine1DescriptionData);
				driver.findElement(journalLine1DescriptionOther).sendKeys(Keys.ENTER);
			}
			oracleObjectRender(QUERYRESPONSE);
			isElementAvailable(journalLine2Account, ELEMENTTIMEOUT);
			driver.findElement(journalLine2Account).click();
			oracleObjectRender(QUERYRESPONSE);
			isElementAvailable(journalLine2Account, ELEMENTTIMEOUT);
			driver.findElement(journalLine2Account).sendKeys(journalLine2AccountData);
			oracleObjectRender(QUERYRESPONSE);
			if (journalLine2DebitData.equals("0")) {
				isElementAvailable(journalLine2Credit, ELEMENTTIMEOUT);
				driver.findElement(journalLine2Credit).sendKeys(journalLine2CreditData);
				driver.findElement(journalLine2Credit).sendKeys(Keys.TAB);
				oracleObjectRender(QUERYRESPONSE);
			} else {
				isElementAvailable(journalLine2Debit, ELEMENTTIMEOUT);
				driver.findElement(journalLine2Debit).sendKeys(journalLine2DebitData);
				driver.findElement(journalLine2Debit).sendKeys(Keys.TAB);
				oracleObjectRender(QUERYRESPONSE);
			}

			if ((dataTable.getData(ExcelDataImport.GeneralData, ExcelDataImport.Currency)).equals("GBP")) {
				isElementAvailable(journalLine2Description, ELEMENTTIMEOUT);
				driver.findElement(journalLine2Description).sendKeys(journalLine2DescriptionData);
				driver.findElement(journalLine2Description).sendKeys(Keys.ENTER);
				isElementAvailable(journalLine2Description, ELEMENTTIMEOUT);
				oracleObjectRender(QUERYRESPONSE);
			} else {
				isElementAvailable(journalLine2DescriptionOther, ELEMENTTIMEOUT);
				driver.findElement(journalLine2DescriptionOther).sendKeys(journalLine2DescriptionData);
				driver.findElement(journalLine2DescriptionOther).sendKeys(Keys.ENTER);
				isElementAvailable(journalLine2DescriptionOther, ELEMENTTIMEOUT);
				oracleObjectRender(QUERYRESPONSE);
				report.updateTestLog("Verify Correct Combination for Account", "Correct Combination for Account for Journal Lines", Status.PASS);
			}
		}

	public void verifyAccountingPeriod() {
		isElementAvailable(journalBatchTxtbox, PAGELOADTIMEOUT);
		driver.findElement(journalBatchTxtbox).sendKeys(journalBatchData);
		isElementAvailable(descriptionTxtbox1, ELEMENTTIMEOUT);
		driver.findElement(descriptionTxtbox1).sendKeys(description1Data);

		isElementAvailable(accountingPeriodDrpdown, ELEMENTTIMEOUT);
		driver.findElement(accountingPeriodDrpdown).clear();
		driver.findElement(accountingPeriodDrpdown).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "FutureAccountingPeriod"));
		//oracleObjectRender(QUERYRESPONSE);
		driver.findElement(accountingPeriodDrpdown).sendKeys(Keys.TAB);
		//isElementAvailable(componentErrorForAccountingPeriod, ELEMENTTIMEOUT);

		report.updateTestLog("Verify Future Accounting period", "Warning message captured for Future Accounting period", Status.PASS);
		driver.findElement(warningMsgAccountingPeriod).isDisplayed();
		isElementAvailable(warningMsgAccountingPeriod, ELEMENTTIMEOUT);
		driver.findElement(warningMsgAccountingPeriod).isDisplayed();
		isElementAvailable(accountingPeriodDrpdown, ELEMENTTIMEOUT);
		driver.findElement(accountingPeriodDrpdown).clear();
		driver.findElement(accountingPeriodDrpdown).sendKeys(accountPeriodData);
		isElementAvailable(accountingPeriodDrpdownValidate, ELEMENTTIMEOUT);
		driver.findElement(accountingPeriodDrpdownValidate).click();
		driver.findElement(journalTxtbox).sendKeys(journalData);
		driver.findElement(descriptionTxtbox2).sendKeys(description2Data);
		Assert.assertEquals(driver.findElement(ledgerDrpdown).getAttribute("value"), (dataTable.getData(ExcelDataImport.GeneralData, "DataAccessSet")));
		isElementAvailable(accountingDateField, ELEMENTTIMEOUT);
		driver.findElement(accountingDateField).clear();
		driver.findElement(accountingDateField).sendKeys(accountingDateData);
		driver.findElement(accountingDateField).sendKeys(Keys.TAB);
		oracleObjectRender(QUERYRESPONSE);
		isElementAvailable(categoryDrpdown, ELEMENTTIMEOUT);
		driver.findElement(categoryDrpdown).sendKeys(categoryData);
		oracleObjectRender(QUERYRESPONSE);
		isElementAvailable(categoryDrpdownListValidate, ELEMENTTIMEOUT);
		driver.findElement(categoryDrpdownListValidate).click();
		oracleObjectRender(QUERYRESPONSE);

		if ((dataTable.getData(ExcelDataImport.GeneralData, ExcelDataImport.Currency)).equals("GBP")) {
			report.updateTestLog("Default selected Currency", "verify the default selected Currency is GBP", Status.PASS);
		} else {
			isElementAvailable(currencyDrpdown, ELEMENTTIMEOUT);
			driver.findElement(currencyDrpdown).clear();
			driver.findElement(currencyDrpdown).sendKeys(currencyData);
			oracleObjectRender(QUERYRESPONSE);
			isElementAvailable(currencyDrpdownValidate, ELEMENTTIMEOUT);
			driver.findElement(currencyDrpdownValidate).click();
			oracleObjectRender(QUERYRESPONSE);
			isElementAvailable(conversionRateTypeDrpdown, ELEMENTTIMEOUT);
			driver.findElement(conversionRateTypeDrpdown).clear();
			driver.findElement(conversionRateTypeDrpdown).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "ConversionRateType"));
			oracleObjectRender(QUERYRESPONSE);
			isElementAvailable(conversionRateTypeDrpdownValidate, ELEMENTTIMEOUT);
			driver.findElement(conversionRateTypeDrpdownValidate).click();
			isElementAvailable(conversionRateTextBox, ELEMENTTIMEOUT);
			driver.findElement(conversionRateTextBox).clear();
			driver.findElement(conversionRateTextBox).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "ConversionRate"));
			driver.findElement(conversionRateTextBox).sendKeys(Keys.TAB);
			oracleObjectRender(QUERYRESPONSE);
		}
		isElementAvailable(journalLine1Account, PAGELOADTIMEOUT);
		driver.findElement(journalLine1Account).click();
		driver.findElement(journalLine1Account).sendKeys(journalLine1AccountData);

		if (journalLine1DebitData.equals("0")) {
			isElementAvailable(journalLine1Credit, ELEMENTTIMEOUT);
			driver.findElement(journalLine1Credit).sendKeys(journalLine1CreditData);
			driver.findElement(journalLine1Credit).sendKeys(Keys.TAB);
			oracleObjectRender(QUERYRESPONSE);

		} else {
			isElementAvailable(journalLine1Debit, ELEMENTTIMEOUT);
			driver.findElement(journalLine1Debit).sendKeys(journalLine1DebitData);
			driver.findElement(journalLine1Debit).sendKeys(Keys.TAB);
			oracleObjectRender(QUERYRESPONSE);
		}
		if ((dataTable.getData(ExcelDataImport.GeneralData, "Currency")).equals("GBP")) {
			isElementAvailable(journalLine1Description, ELEMENTTIMEOUT);
			driver.findElement(journalLine1Description).sendKeys(journalLine1DescriptionData);
			driver.findElement(journalLine1Description).sendKeys(Keys.ENTER);
		} else {
			isElementAvailable(journalLine1DescriptionOther, ELEMENTTIMEOUT);
			driver.findElement(journalLine1DescriptionOther).sendKeys(journalLine1DescriptionData);
			driver.findElement(journalLine1DescriptionOther).sendKeys(Keys.ENTER);
		}

		oracleObjectRender(QUERYRESPONSE);
		isElementAvailable(journalLine2Account, ELEMENTTIMEOUT);
		driver.findElement(journalLine2Account).click();
		oracleObjectRender(QUERYRESPONSE);
		isElementAvailable(journalLine2Account, ELEMENTTIMEOUT);
		driver.findElement(journalLine2Account).sendKeys(journalLine2AccountData);
		oracleObjectRender(QUERYRESPONSE);

		if (journalLine2DebitData.equals("0")) {
			isElementAvailable(journalLine2Credit, ELEMENTTIMEOUT);
			driver.findElement(journalLine2Credit).sendKeys(journalLine2CreditData);
			driver.findElement(journalLine2Credit).sendKeys(Keys.TAB);
			oracleObjectRender(QUERYRESPONSE);

		} else {
			isElementAvailable(journalLine2Debit, ELEMENTTIMEOUT);
			driver.findElement(journalLine2Debit).sendKeys(journalLine2DebitData);
			driver.findElement(journalLine2Debit).sendKeys(Keys.TAB);
			oracleObjectRender(QUERYRESPONSE);
		}

		if ((dataTable.getData(ExcelDataImport.GeneralData, "Currency")).equals("GBP")) {
			isElementAvailable(journalLine2Description, ELEMENTTIMEOUT);
			driver.findElement(journalLine2Description).sendKeys(journalLine2DescriptionData);
			driver.findElement(journalLine2Description).sendKeys(Keys.ENTER);
			isElementAvailable(journalLine2Description, ELEMENTTIMEOUT);
			oracleObjectRender(QUERYRESPONSE);
		} else {
			isElementAvailable(journalLine2DescriptionOther, ELEMENTTIMEOUT);
			driver.findElement(journalLine2DescriptionOther).sendKeys(journalLine2DescriptionData);
			driver.findElement(journalLine2DescriptionOther).sendKeys(Keys.ENTER);
			isElementAvailable(journalLine2DescriptionOther, ELEMENTTIMEOUT);
			oracleObjectRender(QUERYRESPONSE);
		}

	}

		public void completeTheDetailsForCreateJournalForUnEqualCRAndDR() {
			isElementAvailable(completeButton, PAGELOADTIMEOUT);
			driver.findElement(completeButton).click();

			try {
				isElementAvailable(popUpWarningTextForUnEqualCrAndDr, ELEMENTTIMEOUT);
				driver.findElement(popUpWarningTextForUnEqualCrAndDr).isDisplayed();
				report.updateTestLog("Verify total  Accounted Debit and Credit are unequal", "Accounted Debit and Credit are unequal for clicking on Complete Button  ", Status.PASS);
				driver.findElement(popUpYesButton).click();
				oracleObjectRender(QUERYRESPONSE);
			} catch (Exception e) {
				report.updateTestLog("To Complete the details", "The System should not allow to complete the details without warning message for Creating a Journal", Status.FAIL);
			}
		}

		public void postTheDetailsForCreateJournalForUnEqualCRAndDR() {
			//Defect to be raised- hence added this below one line reporting log for failing this test case. If the defect is fixed, we can remove the below log failure.
			report.updateTestLog("To post the Journal Entry", "Post button is active and clickable for Credit and Debit are un-equal  ", Status.FAIL);
			oracleObjectRender(QUERYRESPONSE);
			isElementAvailable(postButton, PAGELOADTIMEOUT);
			driver.findElement(postButton).click();
				/*oracleObjectRender(QUERYRESPONSE);
				isElementAvailable(postButton, PAGELOADTIMEOUT);*/

			try {
				isElementAvailable(popUpWarningTextForUnEqualCrAndDr, ELEMENTTIMEOUT);
				driver.findElement(popUpWarningTextForUnEqualCrAndDr).isDisplayed();
				driver.findElement(popUpYesButton).click();
				report.updateTestLog("Verify total Accounted Debit and Credit are unequal", "Accounted Debit and Credit are unequal for clicking on Post Button  ", Status.PASS);
			} catch (Exception e) {
				report.updateTestLog("Verify total Accounted Debit and Credit are unequal", "Accounted Debit and Credit are unequal for clicking on Post Button  ", Status.PASS);
			}
            try {
                isElementAvailable(journalApprovalPopupOkButton, ELEMENTTIMEOUT);
                driver.findElement(journalApprovalPopupOkButton).isDisplayed();
                oracleObjectRender(SCRIPTTIME);
                driver.findElement(journalApprovalPopupOkButton).click();
				oracleObjectRender(QUERYRESPONSE);
                report.updateTestLog("Verify Journal Approval", "The user requires approval  ", Status.PASS);
            } catch (Exception e) {
                report.updateTestLog("Verify Journal Approval", "The user already have approval rights  ", Status.PASS);
            }
		}



	}



