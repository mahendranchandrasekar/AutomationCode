package pages;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.ScriptHelper;
import com.cognizant.framework.ExcelDataImport;
import com.cognizant.framework.Status;
import org.openqa.selenium.By;

/**
 * Journals Page class
 */
public class ArcsPeriodsPage extends MasterPages {
	// UI Map object definitions

	// Elements
	private final By refreshButton = By.xpath("//button[text()='Refresh']");
	private final By setStatusOption = By.xpath("//table[contains(@id,'Actions::ScrollContent')]/tbody/tr[1]/td[2]");
	private final By openSetStatus = By.xpath("//table[contains(@id,'SetPerStatus::ScrollContent')]/tbody/tr[1]/td[2]");

	//Page Sync Config
	// page loading time
	public static final int PAGELOADTIMEOUT = 90;
	// individual element load time
	public static final int ELEMENTTIMEOUT = 60;
	// Oracle query response
	public static final long QUERYRESPONSE = 15;
	// object render script
	public static final long SCRIPTTIME = 5;


	/**
	 * Constructor to initialize the page
	 *
	 * @param scriptHelper The {@link ScriptHelper} object passed from the
	 *                     {@link DriverScript}b  n '/fg .+
	 */

	public ArcsPeriodsPage(ScriptHelper scriptHelper) {
		super(scriptHelper);
		isElementAvailable(refreshButton, PAGELOADTIMEOUT);

	}


	public void OpenNewPeriod() {
		isElementAvailable(refreshButton, ELEMENTTIMEOUT);
		driver.findElement(refreshButton).click();
		String openPeriodMonthData = dataTable.getData(ExcelDataImport.GeneralData, "OpenPeriodMonth");
			String genericXpathForSelection = "//span[text()='" + openPeriodMonthData + "']/../following-sibling::td[2]/span";
			By ddgenericXpathForSelection = By.xpath(genericXpathForSelection);
			isElementAvailable(ddgenericXpathForSelection, ELEMENTTIMEOUT);
			driver.findElement(ddgenericXpathForSelection).click();
		report.updateTestLog("Selecting the Months", "Selecting the months to setup the status", Status.PASS);
		isElementAvailable(setStatusOption, ELEMENTTIMEOUT);
		driver.findElement(setStatusOption).click();
		oracleObjectRender(SCRIPTTIME);
		report.updateTestLog("Set Status as Open", "Set Status as Open for the corresponding month", Status.PASS);
		isElementAvailable(openSetStatus, ELEMENTTIMEOUT);
		driver.findElement(openSetStatus).click();
		oracleObjectRender(SCRIPTTIME);
		isElementAvailable(refreshButton, ELEMENTTIMEOUT);
		driver.findElement(refreshButton).click();
		report.updateTestLog("Verify Set Status is displayed as Open in home page", "Verify Set Status is displayed as Open in home page", Status.PASS);

	}
}