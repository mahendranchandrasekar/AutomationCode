package pages;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.ScriptHelper;
import com.cognizant.framework.ExcelDataImport;
import com.cognizant.framework.Status;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

/**
 * Journals Page class
 */
public class InvoicesManagePage extends MasterPages {
	// UI Map object definitions

	// Elements
	private final By invoiceNumberTxtbox= By.xpath("//label[text()='Invoice Number']/following::input[1]");
	private final By searchButton= By.xpath("//button[text()='Search']");
	private final By verifyInvoiceRecord= By.xpath("//table[(@summary='Search Results')]/tbody/tr[1]");
    private final By clickOnInvoiceLink= By.xpath("//table[(@summary='Search Results')]/tbody/tr[1]/td[2]/span/a");
    private final By verifyInvoiceStatus= By.xpath("//table[(@summary='Search Results')]/tbody/tr[1]/td[3]/child::*/child::*/tbody/child::*/td[10]/child::*/child::*");
    private final By verifyInvoiceApprovalStatus = By.xpath("//table[(@summary='Search Results')]/tbody/tr[1]/td[3]/child::*/child::*/tbody/child::*/td[11]/child::*");
    private final By validatedLink = By.xpath("//a[contains(text(),'Validated')]");
    //private final By invoiceSummaryApprovalValidation = By.xpath("//table[@summary='Status']/tbody/tr[2]/td[2]/child::*/child::*/img[2]");
    //private final By invoiceSummaryApprovalStatus = By.xpath("//table[@summary='Status']/tbody/tr[2]/td[2]/child::*/span");
    private final By invoiceSummaryAccountingStatus = By.xpath("//table[@summary='Status']/tbody/tr[3]/td[2]/child::*/child::*/a");
    private final By invoiceSummaryPopupClose = By.xpath("//a[@title='Close' and contains(@id,'d37::close')]");
    private final By saveAndCloseButton = By.xpath("//span[text()='ave and Close']");
    private final By actionsDrpdown = By.xpath("//a[text()='Actions']");
    private final By postToLedger = By.xpath("//td[text()='Post to Ledger']");
    private final By accountingConfirmMessage = By.xpath("//td[text()='Accounting is complete.']");
    private final By accountingOkButton = By.xpath("//button[text()='View Accounting']/following::button[1]");

	//private final By verifyThePostedJournalRecordStatus= By.xpath("//table[(@summary='Search Results')]/tbody/tr[1]/td[10]/child::*");
	//private final By batchStatusDrpdown= By.xpath("//label[text()='Batch Status']/following::select[2]");
    //private final By postBatchButton= By.xpath("//span[text()='Post Batch']");
    //private final By selectFirstRecord= By.xpath("//table[(@summary='Search Results')]/tbody/tr[1]/td[5]");
    //private final By clickOnFirstRecord= By.xpath("//table[(@summary='Search Results')]/tbody/tr[1]/td[4]/span/a");

    //private final By popUpOkButton= By.xpath("//button[contains(@id,'userResponsePopupDialogButtonOk')]");
    //private final By popUpConfirmationText= By.xpath("//span[contains(@id,'general_accounting_journals:0:MAnt2:2:pt1:ap1:userRes:1:ot1')]");

    //private final By popUpConfirmationTextForPostBatch= By.xpath("//div[contains(text(),'Your journal approval request has been submitted')]");

    //Page Sync Config

	// page loading time
	public static final int PAGELOADTIMEOUT = 90;
	// individual element load time
	public static final int ELEMENTTIMEOUT = 60;
	// Oracle query response
	public static final long QUERYRESPONSE = 15;
	// object render script
	public static final long SCRIPTTIME = 5;

	/**
	 * Constructor to initialize the page
	 *
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}b  n '/fg .+
	 */
	public InvoicesManagePage(ScriptHelper scriptHelper) {
		super(scriptHelper);
		isElementAvailable(invoiceNumberTxtbox, PAGELOADTIMEOUT);
	}


	public void searchAndVerifyInvoice() {
        isElementAvailable(invoiceNumberTxtbox, PAGELOADTIMEOUT );
        driver.findElement(invoiceNumberTxtbox).sendKeys(Keys.TAB);
        driver.findElement(invoiceNumberTxtbox).click();
        oracleObjectRender(SCRIPTTIME);

        isElementAvailable(invoiceNumberTxtbox, ELEMENTTIMEOUT);
        driver.findElement(invoiceNumberTxtbox).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "InvoiceNumber"));
        driver.findElement(invoiceNumberTxtbox).clear();
        isElementAvailable(searchButton, ELEMENTTIMEOUT);
        driver.navigate().refresh();
        isElementAvailable(searchButton, ELEMENTTIMEOUT);
        driver.findElement(invoiceNumberTxtbox).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "InvoiceNumber"));
        isElementAvailable(searchButton, ELEMENTTIMEOUT);
        driver.findElement(searchButton).click();
        oracleObjectRender(QUERYRESPONSE);

        try {
            if (driver.findElement(verifyInvoiceRecord).isDisplayed()) {
                Assert.assertEquals(driver.findElement(verifyInvoiceStatus).getAttribute(ExcelDataImport.innerHTML), (dataTable.getData(ExcelDataImport.GeneralData, "InvoiceStatus")));
                Assert.assertEquals(driver.findElement(verifyInvoiceApprovalStatus).getAttribute(ExcelDataImport.innerHTML), (dataTable.getData(ExcelDataImport.GeneralData, "InvoiceSummaryApprovalStatus")));
                report.updateTestLog("Search the Invoice Number in Manage invoice page", "Invoice Number is available in Manage Invoice", Status.PASS);
                oracleObjectRender(SCRIPTTIME);
                isElementAvailable(clickOnInvoiceLink, ELEMENTTIMEOUT);
                driver.findElement(clickOnInvoiceLink).click();
                oracleObjectRender(QUERYRESPONSE);
            }
        } catch (Exception e) {
            report.updateTestLog("Search the Invoice Number in Manage invoice page", "Invoice Number is not available in Manage Invoice", Status.FAIL);
        }

        try {
            if (driver.findElement(validatedLink).isDisplayed()) {
                report.updateTestLog("Manage Invoices Page", "The Landing Page is Manage Invoices Page", Status.PASS);
                isElementAvailable(validatedLink, ELEMENTTIMEOUT);
                driver.findElement(validatedLink).click();
                oracleObjectRender(SCRIPTTIME);
                report.updateTestLog("Invoice  Approval Process", "Invoice Approval Process is completed for this Invoice transaction", Status.PASS);
                isElementAvailable(invoiceSummaryPopupClose, ELEMENTTIMEOUT);
                driver.findElement(invoiceSummaryPopupClose).click();

                if(driver.findElement(invoiceSummaryAccountingStatus).getAttribute(ExcelDataImport.innerHTML).equals("Unaccounted")) {
                    oracleObjectRender(SCRIPTTIME);
                    isElementAvailable(actionsDrpdown, PAGELOADTIMEOUT);
                    driver.findElement(actionsDrpdown).click();
                    oracleObjectRender(SCRIPTTIME);
                    isElementAvailable(postToLedger, ELEMENTTIMEOUT);
                    driver.findElement(postToLedger).click();
                    oracleObjectRender(QUERYRESPONSE);oracleObjectRender(SCRIPTTIME);
                    //TODO as a separate method
                    try {
                        if (driver.findElement(accountingConfirmMessage).isDisplayed()) {
                            report.updateTestLog("Accounting Confirmation popup message", "The user able to verify Accounting Confirmation popup message", Status.PASS);
                            oracleObjectRender(QUERYRESPONSE);
                            isElementAvailable(accountingOkButton, ELEMENTTIMEOUT);
                            driver.findElement(accountingOkButton).click();
                            oracleObjectRender(QUERYRESPONSE);
                            isElementAvailable(validatedLink, PAGELOADTIMEOUT);
                            driver.findElement(validatedLink).click();
                            oracleObjectRender(SCRIPTTIME);
                            Assert.assertEquals(driver.findElement(invoiceSummaryAccountingStatus).getAttribute("innerHTML"), (dataTable.getData(ExcelDataImport.GeneralData, "InvoiceSummaryAccountingStatus")));
                            report.updateTestLog("Invoice Accounting  Process", "Invoice Accounting Process is completed for this Invoice transaction", Status.PASS);
                        }
                    } catch (Exception e) {
                        report.updateTestLog("Invoice Accounting Process", "Invoice Accounting Process is not completed for this Invoice transaction", Status.FAIL);
                    }

                } else {
                    Assert.assertEquals(driver.findElement(invoiceSummaryAccountingStatus).getAttribute("innerHTML"), (dataTable.getData(ExcelDataImport.GeneralData, "InvoiceSummaryAccountingStatus")));
                    report.updateTestLog("Invoice Accounting Process", "Invoice Accounting Process is completed for this Invoice transaction", Status.PASS);
                }


                report.updateTestLog("Invoice Approval Process", "Invoice Approval Process is completed for this Invoice transaction", Status.PASS);
                isElementAvailable(invoiceSummaryPopupClose, ELEMENTTIMEOUT);
                driver.findElement(invoiceSummaryPopupClose).click();
            }
        } catch (Exception e) {
            report.updateTestLog("Invoice Approval Process", "Invoice Approval Process is not completed for this Invoice transaction", Status.PASS);
        }
        oracleObjectRender(SCRIPTTIME);
        isElementAvailable(saveAndCloseButton, PAGELOADTIMEOUT);
        driver.findElement(saveAndCloseButton).click();
    }
}