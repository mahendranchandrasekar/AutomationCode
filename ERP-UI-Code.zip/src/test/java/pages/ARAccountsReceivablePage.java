package pages;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.ScriptHelper;
import com.cognizant.framework.Status;
import com.cognizant.framework.selenium.CraftDriver;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class ARAccountsReceivablePage extends MasterPages {
    //Links

    private final By receivableheader = By.xpath( "//*[contains(@title,'Accounts Receivable')]/ancestor::td[1]" );
    private final By createreceipt = By.xpath( "//a[text()='Create Receipt']" );
    private final By managereceipts = By.xpath( "//a[text()='Manage Receipts']" );
    private final By taskmenu = By.xpath("//img[@title='Tasks']");
    private final By receiptheader = By.xpath( "//*[text()='Create Receipt']/ancestor::div/h1" );
    private final By manreceiptheader = By.xpath( "//*[text()=' Manage Receipts']/ancestor::div/h1" );
    private final By bussajaxValidate = By.xpath( "//div[contains(@class,'AFDetectExpansion')]/../tbody/tr/td/div/div/div/table/tr[1]" );
    private final By searchrecnumber = By.xpath( "//label[text()=' Receipt Number']/ancestor::tr[1]/td[1]//input" );
    private final By addattachments = By.xpath( "//*[contains(@id,'clLAdds::icon')]" );
    private final By businessunit = By.xpath( "//label[text()='Business Unit']/ancestor::tr[1]/td[2]//input" );
    private final By busunitdrpdwn = By.xpath( "//*[contains(@id,'ap1:fcslov1:sis1:is1::btn')]" );
    private final By receiptmethod = By.xpath( "//label[text()='Receipt Method']/ancestor::tr[1]/td[2]//input" );
    private final By receiptmetdrpdwn = By.xpath( "//*[contains(@id,'receiptMethodId::lovIconId')]" );
    private final By receiptmetselect = By.xpath( "//*[contains(@class,'xep p_AFSelected')]/../tr[2]/td[1]" );
    private final By recpajaxValidate = By.xpath("//div[contains(@class,'AFDetectExpansion')]/../tbody/tr[1]/td[1]/ul[1]/li[1]");
    //receipt method search link
    private final By recieptmethodsearchlink = By.xpath("//a[contains(@id,'receiptMethodId::dropdownPopup::popupsearch')]");
    private final By searchrecieptmethod = By.xpath("//tr[contains(@id,'receiptMethodId::_afrLovInternalQueryId:criterion0')]/td[2]/table/tbody/tr[1]/td[2]/table/tbody/tr[1]/td[1]/span/input");
    private final By recieptmethodpopupsearchbutton = By.xpath("//*[contains(@id,'receiptMethodId::_afrLovInternalQueryId::search')]");
    private final By recieptmethodpopupselection = By.xpath("//div[contains(@id,'receiptMethodId_afrLovInternalTableId::db')]");
    private final By recieptmethodpopupOkbutton = By.xpath("//td[contains(@id,':receiptMethodId::lovDialogId::_fcc')]/button[1]");

    private final By amount = By.xpath( "//label[text()='Entered Amount']/ancestor::tr[1]/td[2]//input" );
    private final By receiptnumber = By.xpath( "//label[text()='Receipt Number']/ancestor::tr[1]/td[2]//input" );
    private final By submitdropdwn = By.xpath( "//*[contains(@id,'MAnt2:1:pt1:RCF1:0:ap1:commandButton2::popEl')]" );
    private final By customername = By.xpath( "//*[contains(@id,'customerNameId')]/ancestor::td[1]//input" );
    private final By namesearch = By.xpath( "//*[contains(@id,'customerNameId::lovIconId')]" );
    private final By receiptmethodajaxValidate = By.xpath( "//div[contains(@class,'AFDetectExpansion')]/../tbody/tr[1]/td[1]/ul[1]/li[1]" );
    private final By btnsearchpopup = By.xpath( "//*[contains(@id,'customerNameId::_afrLovInternalQueryId::search')]" );
    private final By srchresultsdataselect = By.xpath( "//*[contains(@id,'customerNameId_afrLovInternalTableId::db')]/table/tbody/tr[1]" );
    private final By btnokcustomernamepopup = By.xpath( "//*[contains(@id,'customerNameId::lovDialogId::ok')]" );
    private final By btnsubmit = By.xpath( "//*[@role='menuitem'][@accesskey='m']" );
    private final By btnsubmitdrpdwn = By.xpath( "//*[contains(@id,'commandButton2::popEl')]" );
    private final By btnsubmitmanually = By.xpath( "//*[contains(@id,'MAnt2:1:pt1:RCF1:0:ap1:cmi2')]" );
    private final By btnsubmitautoapply = By.xpath( "//*[contains(@id,'MAnt2:1:pt1:RCF1:0:ap1:cmi3')]" );
    private final By receipttype = By.xpath( "//label[text()='Receipt Type']/ancestor::tr[1]/td[2]" );
    private final By businesunitselection = By.xpath( "//table[@role='grid']/tr[3]" );
    private final By receiptmthdselection = By.xpath( "//*[contains(@id,'receiptMethodId::su0')]" );
    private final By popupmsg = By.xpath( "//*[@id='_FOd1::msgDlg::_ccntr']" );
    private final By popupcancel = By.xpath( "//*[@id='_FOd1::msgDlg::cancel']" );
    private final By receiptNumberText = By.xpath( "//*[contains(@class,'p_AFResizable x1o')]/div/div/div/table/tbody/tr/td/table/tbody/tr/td[2]/div");
    private final By btnmanrecsearch = By.xpath( "//button[text()='Search']" );
    private final By customernamesrch = By.xpath( "//*[contains(@title,'Search:  Customer Name')]" );
    //private final By searchdone = By.xpath( "//button[text()='Done']" );
    private final By searchdone = By.xpath("//button[contains(@id,'MAnt2:2:pt1:RMF:0:ap1:commandButton1')]");
    private final By searchresutselection = By.xpath( "//table[@summary='Search Results']/tbody/tr[1]" );

    private final By searchreceiptnumlink = By.xpath( "//table[@summary='Search Results']/tbody/tr[1]/td[3]/span" );
    private final By receiptnumlink = By.xpath( "//table[@summary='Search Results']/tbody/tr[1]/td[3]/span/a" );
    private final By receiptnumEditbutton = By.xpath( "//img[@title='Edit']" );

    private final By srchrecpnumberlink = By.xpath( "//*[@id='_FOpt1:_FOr1:0:_FOSritemNode_receivables_receivables_balances:0:MAnt2:1:pt1:RMF:0:ap1:appTable:_ATp:t1::db']/table/tbody/tr[1]/td[3]" );
    private final By submitselect = By.xpath( "//*[contains(@id,'MAnt2:1:pt1:RCF1:0:ap1:cmi1')]/td[2]" );
    private final By taxratecode = By.xpath( "//label[text()='Tax Rate Code']/ancestor::td[1]/following-sibling::td[1]//input" );
    private final By taxratecodelist = By.xpath( "//*[contains(@id,'TaxCode::dropdownPopup::content')]//div[2]/table/tbody/tr[1]/td[1]far" );
    private final By receivablespecialist = By.xpath( "//label[text()='Receivables Specialist']/ancestor::td[1]/following-sibling::td[1]//input" );
    private final By site = By.xpath( "//label[text()='Site']/ancestor::tr[1]/td[2]//input" );
    private final By bank = By.xpath( "//label[text()='Bank']/ancestor::tr[1]/td[2]//input" );
    private final By bankbranch = By.xpath( "//label[text()='Bank Branch']/ancestor::tr[1]/td[2]//input" );
    private final By bankaccount = By.xpath( "//label[text()='Bank Account']/ancestor::tr[1]/td[2]//input" );
    private final By taxpayerident = By.xpath( "//label[text()='Taxpayer Identification Number']/ancestor::tr[1]/td[2]//input" );
    private final By comments = By.xpath( "//*[contains(@id,'comment1::content')]" );
    private final By structpaymentrefer = By.xpath( "//label[text()='Structured Payment Reference']/ancestor::tr[1]/td[2]/span/textarea" );
    private final By srchcustomername = By.xpath( "//label[text()='Customer Name']/ancestor::td[1]/following-sibling::td[1]//input" );
    private final By btnsave = By.xpath( "//button[text()='Save']" );
    private final By btnsaveandclose = By.xpath( "//button[text()='ave and Close']" );
    private final By receiptdetailsheader = By.xpath( "//*[text()='Receipt Details']/ancestor::div/h1" );
    private final By btnaddapplication = By.xpath( "//*[contains(@id,'MAnt2:1:pt1:RMF:1:pt1:REF:0:ap1:AT1:_ATp:cb6')]" );
    //Elements for add application
    private final By appliedamt = By.xpath( "//*[contains(@id,'AmtApplied::content')]" );

    //elments for add open receivables
    private final By receiptreferencenumber = By.xpath( "//label[text()='Receipt Reference Number']/ancestor::tr[1]/td[2]//input" );
    private final By transbusniessunit = By.xpath( "//label[text()='Transaction Business Unit']/ancestor::tr[1]/td[2]//input" );
    private final By transtransactiontype = By.xpath( "//label[text()='Transaction Type']/ancestor::tr[1]/td[2]//input" );
    private final By transcustomername = By.xpath( "//label[text()='Transaction Customer Name']/ancestor::tr[1]/td[2]//input" );
    private final By addopenreceivables = By.xpath( "//button[text()='Add Open Receivables']" );
    private final By btnaddopensearch = By.xpath( "//button[text()='Search']" );
    private final By addopenresultsel = By.xpath( "//table[@summary='Search Results']/tbody/tr[1]/td[2]" );
    private final By addselected = By.xpath( "//button[text()='Add']" );
    private final By adddone = By.xpath( "//button[@accesskey='o']" );
    private final By transactionreference = By.xpath( "//*[contains(@id,'trxNumberList::content')]" );
    private final By application = By.xpath( "//h1[text()='Receipt Details']/../../../../../../../div[2]/div/div/div[1]/div/div/div[2]/div[1]/div/a" );
    private final By srchselectcustname = By.xpath( "//*[contains(@id,'_afrLovInternalQueryId::search')]" );
    private final By selectcustnamefrmresults = By.xpath( "//*[contains(@id,'afrLovInternalTableId::db')]/table/tbody/tr[1]/td[2]/div/table/tbody/tr/td[1]" );
    private final By btnokfosrchresults = By.xpath( "//*[contains(@id,'lovDialogId::ok')]" );


    //Elements for account receipt
    private final By actiondrpdwn = By.xpath( "//*[contains(@id,'ATp:ATm')]/div/table/tbody/tr/td[3]/div" );
    private final By morelink = By.xpath( "//*[text()='More']" );
    private final By createonaccountappl = By.xpath( "//*[text()='Create On-Account Application']" );
    private final By applicationamount = By.xpath( "//label[text()='Application Amount']/ancestor::tr[1]/td[2]//input" );
    private final By applicationdate = By.xpath( "//input[contains(@id,'id14::content')]" );
    private final By accountingdate = By.xpath( "//input[contains(@id,'id15::content')]" );
    private final By accountok = By.xpath( "//*[contains(@id,'ap1:cb22')]" );
    private final By exceptionreason = By.xpath( "//select[contains(@id,'soc2::content')]" );

    //Elements for Close AR
    private final By mngaccountingperiods = By.xpath( "//a[text()='Manage Accounting Periods']" );
    private final By filtericon = By.xpath( "//img[@alt='Query By Example']" );
    private final By refreshicon = By.xpath( "//img[@alt='Refresh']" );
    private final By filterledgerentry = By.xpath( "//input[contains(@id,'ATp_afr_table1_afr_column1::content')]" );
    private final By ledgerselect = By.xpath( "//table[@summary='Accounting Period Status']/tbody/tr[1]" );
    private final By mngaccountingperiodheader = By.xpath( "//h1[text()='Manage Accounting Periods']" );
    private final By mngaccpdactiondrpdwn = By.xpath( "//*[contains(@id,'ATp:ATm')]/div/table/tbody/tr/td[3]/div" );
    private final By closecurrentperiod = By.xpath( "//*[contains(@id,'ATp:cmi7')]/td[2]" );
    private final By mngaccperdone = By.xpath( "//*[@accesskey='o']" );


    //reverse receipt
    private final By editactiondrpdwn = By.xpath( "//*[contains(@id,'ap1:menu1')]/div/table/tbody/tr/td[3]/div" );
    private final By reverse = By.xpath( "//td[text()='Reverse']" );
    private final By category = By.xpath( "//label[text()='Category']/ancestor::tr[1]/td[2]//select" );
    private final By reason = By.xpath( "//label[text()='Reason']/ancestor::tr[1]/td[2]//select" );
    private final By reversecomments = By.xpath( "//label[text()='Comments']/ancestor::tr[1]/td[2]" );
    private final By contextvalue = By.xpath( "//label[text()='Context Value']/ancestor::tr[1]/td[2]//select" );
    private final By btnreverse = By.xpath( "//button[text()='Reverse']" );
    private final By apapplication = By.xpath( "//label[text()='Application']/ancestor::tr[1]/td[2]//select" );

    // page loading time
    public static final int PAGELOADTIMEOUT = 90;
    // individual element load time
    public static final int ELEMENTTIMEOUT = 60;
    // Oracle query response
    public static final long QUERYRESPONSE = 15;
    // object render script
    public static final long SCRIPTTIME = 5;

    /**
     * Constructor to initialize the functional library
     *
     * @param scriptHelper The {@link ScriptHelper} object passed from the
     *                     {@link DriverScript}
     */
    public ARAccountsReceivablePage(ScriptHelper scriptHelper) {
        super( scriptHelper );
    }

    public void createReceiptnnav() {
        isElementAvailable( taskmenu, ELEMENTTIMEOUT );
        driver.findElement( taskmenu ).click();

        isElementAvailable( createreceipt, ELEMENTTIMEOUT );
        driver.findElement( createreceipt ).click();
    }

    private void customerdetails() {
        isElementAvailable( customername, ELEMENTTIMEOUT );
        driver.findElement( customername ).click();
        driver.findElement( customername ).sendKeys( dataTable.getData( "General_Data", "Customer Name" ) );
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( namesearch, ELEMENTTIMEOUT );
        driver.findElement( namesearch ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( btnsearchpopup, ELEMENTTIMEOUT );
        driver.findElement( btnsearchpopup ).click();
        oracleObjectRender( SCRIPTTIME );
        driver.findElement( srchresultsdataselect ).click();
        oracleObjectRender( SCRIPTTIME );
        driver.findElement( btnokcustomernamepopup ).click();
        oracleObjectRender( SCRIPTTIME );
    }

    private void sumbittheentereddetails() {
        isElementAvailable( btnsubmitdrpdwn, ELEMENTTIMEOUT );
        PauseScript( 2 );
        driver.findElement( btnsubmitdrpdwn ).click();
        PauseScript( 4 );
        driver.findElement( submitselect ).click();
        PauseScript( 10 );
    }

    private void receipthdeadervalidation() {
        isElementAvailable( receiptheader, ELEMENTTIMEOUT );
        driver.findElement( receiptheader ).isDisplayed();
        String header = driver.findElement( receiptheader ).getText();
        String staticheader = "Create Receipt";
        Assert.assertEquals( "Header text validation", header, staticheader );
        PauseScript( 2 );
    }

    private void recieptmethodpopup(){
        isElementAvailable( searchrecieptmethod, ELEMENTTIMEOUT );
        driver.findElement( searchrecieptmethod ).click();
        driver.findElement( searchrecieptmethod ).sendKeys( dataTable.getData( "General_Data", "Receipt Method" ) );
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( recieptmethodpopupsearchbutton, ELEMENTTIMEOUT );
        driver.findElement( recieptmethodpopupsearchbutton ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( recieptmethodpopupselection, ELEMENTTIMEOUT );
        driver.findElement( recieptmethodpopupselection ).click();
        oracleObjectRender( SCRIPTTIME ); oracleObjectRender( SCRIPTTIME );
        isElementAvailable( recieptmethodpopupOkbutton, ELEMENTTIMEOUT );
        driver.findElement( recieptmethodpopupOkbutton ).click();
        oracleObjectRender( SCRIPTTIME );

    }


    private void generaldetails() {
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable(businessunit, PAGELOADTIMEOUT);
        driver.findElement( businessunit ).click();
        driver.findElement( businessunit ).sendKeys( dataTable.getData( "General_Data", "Business Unit" ) );
        oracleObjectRender( QUERYRESPONSE );
        driver.findElement( bussajaxValidate ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( receiptmethod, PAGELOADTIMEOUT);
        driver.findElement( receiptmethod ).click();
        PauseScript( 3 );
        driver.findElement( receiptmetdrpdwn ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( recieptmethodsearchlink, ELEMENTTIMEOUT );
        driver.findElement( recieptmethodsearchlink ).click();
        oracleObjectRender( SCRIPTTIME );
        recieptmethodpopup();
        driver.findElement( receiptnumber ).sendKeys( dataTable.getData( "General_Data", "Receipt Number" ) );
        oracleObjectRender( SCRIPTTIME );
        driver.findElement( amount ).sendKeys( dataTable.getData( "General_Data", "Amount" ) );
        oracleObjectRender( SCRIPTTIME );
    }

    //Create Receipt
    public String recieptCreation() {
        generaldetails();
        customerdetails();
        report.updateTestLog( "Verify the data on General details and customer details", "Data on General and Customer details section ", Status.PASS );
        sumbittheentereddetails();
        String receiptMessage[] = driver.findElement(receiptNumberText).getAttribute("innerHTML").split(" ");
        String receiptNumber = receiptMessage[2];
        report.updateTestLog( "Verify the Receipt creation process", "Receipt " + receiptNumber + " has been successfully created ", Status.PASS );
        driver.findElement( popupcancel ).click();
        return receiptNumber;
    }

    public void manageReceiptsnnav() {
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( taskmenu, ELEMENTTIMEOUT );
        driver.findElement( taskmenu ).click();

        isElementAvailable( managereceipts, ELEMENTTIMEOUT );
        driver.findElement( managereceipts ).click();
    }

    //Reveiw Receipt
    public void reviewReceipts(String receiptNumber) {
        isElementAvailable( manreceiptheader, ELEMENTTIMEOUT );
        driver.findElement( manreceiptheader ).isDisplayed();
        searchwithReceiptnumber(receiptNumber);
        clickonreceipteditbutton();
        isElementAvailable( comments, ELEMENTTIMEOUT );
        driver.findElement( comments ).clear();
        driver.findElement( comments ).click();
        PauseScript( 2 );
        driver.findElement( comments ).sendKeys( (dataTable.getData( "General_Data", "Receipt Comments" )) );
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( btnsaveandclose, ELEMENTTIMEOUT );
        driver.findElement( btnsaveandclose ).click();
        report.updateTestLog( "Verify the Receipt", " Receipt updated successfully", Status.PASS );
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( searchdone, ELEMENTTIMEOUT);
        driver.findElement( searchdone ).click();
    }

    //Search customer
    public void searchcustomername() {
        //customer name search
        isElementAvailable( srchcustomername, ELEMENTTIMEOUT );
        driver.findElement( srchcustomername ).click();
        driver.findElement( srchcustomername ).sendKeys( dataTable.getData( "General_Data", "Search Customer Name" ) );
        PauseScript( 3 );
        driver.findElement( customernamesrch ).click();
        oracleObjectRender( SCRIPTTIME );
        driver.findElement( srchselectcustname ).click();
        PauseScript( 3 );
        driver.findElement( selectcustnamefrmresults ).click();
        PauseScript( 2 );
        driver.findElement( btnokfosrchresults ).click();
        PauseScript( 2 );
        driver.findElement( btnmanrecsearch ).click();
        PauseScript( 2 );
    }

    //Search Receipt number
    private void searchwithReceiptnumber(String receiptNumber) {
        //customer name search
        isElementAvailable( receiptnumber, ELEMENTTIMEOUT );
        driver.findElement( receiptnumber ).click();
        driver.findElement( receiptnumber ).sendKeys(receiptNumber);
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( btnmanrecsearch, ELEMENTTIMEOUT );
        driver.findElement( btnmanrecsearch ).click();
        oracleObjectRender( QUERYRESPONSE );
        //String receiptnumber = (dataTable.getData( "General_Data", "Receipt Number" ));
        report.updateTestLog( "Verify the Receipt Number", " Reciept Number " + receiptNumber + " from Search Results", Status.PASS );
    }

    private void clickonreceipteditbutton() {
        isElementAvailable(searchresutselection, ELEMENTTIMEOUT );
        driver.findElement( searchresutselection ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( receiptnumEditbutton, ELEMENTTIMEOUT );
        driver.findElement( receiptnumEditbutton ).click();
        oracleObjectRender( QUERYRESPONSE );
    }
    private void clickonreceiptnumber() {
        isElementAvailable(searchresutselection, ELEMENTTIMEOUT );
        driver.findElement( searchresutselection ).click();
        oracleObjectRender( SCRIPTTIME );
        driver.findElement( receiptnumlink ).click();
        PauseScript( 2 );
        while (driver.findElements( receiptnumlink ).size() >= 1) {
            driver.findElement( receiptnumlink ).click();
            PauseScript( 6 );
            if ( driver.findElements( comments ).size() >= 1 )
                break;
        }
        oracleObjectRender( QUERYRESPONSE );
    }


    //Apply Invoice to Receipt
    public void applyInvoicetoReceipt(String transactionNumber, String receiptNumber) {
        searchwithReceiptnumber(receiptNumber);
        clickonreceiptnumber();
        //add Open receivable
        isElementAvailable( receiptdetailsheader, ELEMENTTIMEOUT );
        driver.findElement( receiptdetailsheader ).isDisplayed();
        PauseScript( 2 );
        isElementAvailable( application, ELEMENTTIMEOUT );
        driver.findElement( application ).isDisplayed();
        PauseScript( 2 );
        isElementAvailable( addopenreceivables, ELEMENTTIMEOUT );
        Assert.assertTrue( driver.findElement( addopenreceivables ).isDisplayed() );
        driver.findElement( addopenreceivables ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( receiptreferencenumber, ELEMENTTIMEOUT );
        driver.findElement( receiptreferencenumber ).click();
        driver.findElement( receiptreferencenumber ).sendKeys(transactionNumber);
        oracleObjectRender( SCRIPTTIME );
        driver.findElement( btnaddopensearch ).click();
        oracleObjectRender( QUERYRESPONSE );
        driver.findElement( addopenresultsel ).click();
        PauseScript( 3 );
        report.updateTestLog( "Verify the Invoice number", "Invoice number found from the search results", Status.PASS );
        driver.findElement( addselected ).click();
        PauseScript( 3 );
        driver.findElement( adddone ).click();
        oracleObjectRender( SCRIPTTIME );
        driver.findElement( btnsave ).click();
        oracleObjectRender( SCRIPTTIME );
        driver.findElement( btnsaveandclose ).click();
        oracleObjectRender( SCRIPTTIME );
        report.updateTestLog( "Verify the Applied details", "Invoice -  " + transactionNumber + " Applied to Receipt -  " + receiptNumber + " successfully", Status.PASS );
    }

    //Apply Account on Receipt
    public void applyaccountonReceipt(String receiptNumber) {
        searchwithReceiptnumber(receiptNumber);
        clickonreceiptnumber();
        isElementAvailable( receiptdetailsheader, ELEMENTTIMEOUT );
        driver.findElement( receiptdetailsheader ).isDisplayed();
        PauseScript( 2 );
        isElementAvailable( application, ELEMENTTIMEOUT );
        driver.findElement( application ).isDisplayed();
        PauseScript( 2 );
        isElementAvailable( actiondrpdwn, ELEMENTTIMEOUT );
        driver.findElement( actiondrpdwn ).click();
        PauseScript( 2 );
        isElementAvailable( morelink, ELEMENTTIMEOUT );
        driver.findElement( morelink ).click();
        PauseScript( 2 );
        isElementAvailable( createonaccountappl, ELEMENTTIMEOUT );
        driver.findElement( createonaccountappl ).click();
        PauseScript( 3 );
        isElementAvailable( applicationamount, ELEMENTTIMEOUT );
        driver.findElement( applicationamount ).click();
        driver.findElement( applicationamount ).clear();
        driver.findElement( applicationamount ).click();
        PauseScript( 2 );
        driver.findElement( applicationamount ).sendKeys( dataTable.getData( "General_Data", "Application Amount" ) );
        driver.findElement( applicationamount ).sendKeys( Keys.ENTER );
        oracleObjectRender( SCRIPTTIME );
        driver.findElement( accountok ).click();
        oracleObjectRender( QUERYRESPONSE );
        Select drpexcepreason = new Select( driver.findElement( exceptionreason ) );
        drpexcepreason.selectByVisibleText( dataTable.getData( "General_Data", "Exception Reason" ) );
        report.updateTestLog( "Verify the Applied Amount and Exception Reason", "Applied Amount and Exception Reason are updated successfully ", Status.PASS );
        PauseScript( 2 );
        driver.findElement( btnsaveandclose ).click();
        oracleObjectRender( QUERYRESPONSE );

        report.updateTestLog( "Verify the Apply Accoount on Receipt", "Account has been Applied to Receipt -  " + receiptNumber + " successfully", Status.PASS );
    }


    public void manageAccountingperiodnnav() {
        PauseScript( 2 );
        isElementAvailable( taskmenu, ELEMENTTIMEOUT );
        driver.findElement( taskmenu ).click();

        isElementAvailable( mngaccountingperiods, ELEMENTTIMEOUT );
        driver.findElement( mngaccountingperiods ).click();
    }

    //Close AR
    public void closeARperiod() {
        isElementAvailable( refreshicon, ELEMENTTIMEOUT );
        isElementAvailable( filtericon, ELEMENTTIMEOUT );
        driver.findElement( filtericon ).click();
        PauseScript( 3 );
        while (driver.findElements( filtericon ).size() >= 1) {
            driver.findElement( filtericon ).click();
            oracleObjectRender( SCRIPTTIME );
            if ( driver.findElements( filterledgerentry ).size() >= 1 )
                break;
        }
        driver.findElement( filterledgerentry ).sendKeys( dataTable.getData( "General_Data", "Ledger" ) );
        PauseScript( 3 );
        driver.findElement( filterledgerentry ).sendKeys( Keys.ENTER );
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( ledgerselect, ELEMENTTIMEOUT );
        driver.findElement( ledgerselect ).click();
        PauseScript( 2 );
        report.updateTestLog( "Verify the Ledger selection", " Ledger selection completed successfully", Status.PASS );
        isElementAvailable( mngaccpdactiondrpdwn, ELEMENTTIMEOUT );
        driver.findElement( mngaccpdactiondrpdwn ).click();
        PauseScript( 2 );
        isElementAvailable( closecurrentperiod, ELEMENTTIMEOUT );
        driver.findElement( closecurrentperiod ).click();
        oracleObjectRender( SCRIPTTIME );
        isElementAvailable( mngaccperdone, ELEMENTTIMEOUT );
        driver.findElement( mngaccperdone ).click();
        report.updateTestLog( "Verify the Close AR period", " Close AR period Updated successfully", Status.PASS );
    }

    //Reverse Receipt
    public void reversereceipt(String receiptNumber) {
        searchwithReceiptnumber(receiptNumber);
        clickonreceiptnumber();
        isElementAvailable( editactiondrpdwn, ELEMENTTIMEOUT );
        driver.findElement( editactiondrpdwn ).click();
        driver.findElement( reverse ).click();
        oracleObjectRender( SCRIPTTIME );
        Select drpcategory = new Select( driver.findElement( category ) );
        drpcategory.selectByVisibleText( dataTable.getData( "General_Data", "Reverse Category" ) );
        oracleObjectRender( SCRIPTTIME );
        Select drpreason = new Select( driver.findElement( reason ) );
        drpreason.selectByVisibleText( dataTable.getData( "General_Data", "Reason" ) );
        PauseScript( 3 );
        report.updateTestLog( "Verify the Reverse Category and Reason", "Reverse Category and Reason are updated Successfully ", Status.PASS );
        driver.findElement( btnreverse ).click();
        oracleObjectRender( SCRIPTTIME );
        //TODO START - ignored the saveAndClose button, becasue save button got disabled
        //driver.findElement( btnsaveandclose ).click();
        oracleObjectRender( SCRIPTTIME );
        report.updateTestLog( "Verify the Reverse Receipt", " Receipt -  " + receiptNumber + " has been Reversed successfully", Status.PASS );
    }

    public void addapplication() {
        isElementAvailable( application, ELEMENTTIMEOUT );
        driver.findElement( application ).isDisplayed();
        PauseScript( 2 );
        isElementAvailable( btnaddapplication, ELEMENTTIMEOUT );
        Assert.assertTrue( driver.findElement( btnaddapplication ).isDisplayed() );
        driver.findElement( btnaddapplication ).click();
        PauseScript( 3 );
        isElementAvailable( transactionreference, ELEMENTTIMEOUT );
        driver.findElement( transactionreference ).click();
        driver.findElement( transactionreference ).sendKeys( "1012000274" );
        isElementAvailable( appliedamt, ELEMENTTIMEOUT );
        driver.findElement( appliedamt ).click();
        driver.findElement( transactionreference ).sendKeys( "100" );
        isElementAvailable( exceptionreason, ELEMENTTIMEOUT );
        Select drpexcepreason = new Select( driver.findElement( exceptionreason ) );
        drpexcepreason.selectByIndex( 1 );
        isElementAvailable( applicationdate, ELEMENTTIMEOUT );
        driver.findElement( applicationdate ).sendKeys( "30/04/2020" );
        isElementAvailable( accountingdate, ELEMENTTIMEOUT );
        driver.findElement( accountingdate ).sendKeys( "30/04/2020" );
        PauseScript( 2 );
        driver.findElement( btnsave ).click();
        PauseScript( 2 );
        isElementAvailable( actiondrpdwn, ELEMENTTIMEOUT );
        driver.findElement( actiondrpdwn ).click();
        PauseScript( 2 );
    }

}
