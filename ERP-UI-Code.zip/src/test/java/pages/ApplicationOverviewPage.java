package pages;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.ScriptHelper;
import com.cognizant.framework.Status;
import org.openqa.selenium.By;

/**
 * Update Page details here class

 */
public class ApplicationOverviewPage extends MasterPages {

	//Page Sync Config

	// page loading time
	public  static  final int PAGELOADTIMEOUT = 90;
	// individual element load time
	public static final int ELEMENTTIMEOUT = 60;
	// slowdown script
	public static final int SCRIPTTIME = 5;


	// UI Map object definitions

	// Text boxes


	// Buttons
	private final By btnImport = By.xpath("//button[text()='mport']");
	private final By btnApplicationExport = By.xpath("//button[text()='port']");
	private final By btnCreate = By.xpath("//button[@title='Create']");
	private final By btnExport = By.id("zr0:0:zt0:0:tab:1:r4:1:pt1:da:1:cb4");
	private final By btnChooseAccountFile = By.xpath("//*[text()='Account']/ancestor::td[1]/following-sibling::td//label[text()='Choose File']/preceding-sibling::input");
	private final By btnImportMetadata = By.id("zr0:0:zt0:0:tab:1:r4:1:pt1:me:1:cb4");
	private final By btnAccountSelection = By.xpath("//input[@id='zr0:0:zt0:0:tab:1:r4:1:pt1:da:1:t1:0:sbc1::content']");




	// Element
	private final By pageIdentifier = By.xpath("//*[contains(@class,'panelHeader')]/parent::tr/td[contains(@id,'Title')]/*[@title='Application']");
	private final By dimensions = By.id("zr0:0:zt0:0:ctb2");
	private final By dimensionsIdentifier = By.xpath("//*[text()='Dimension Type']");
	private final By importMetadataIdentifier = By.xpath("//*[contains(@class,'panelHeader')]/parent::tr//*[@title='Import Metadata']");
	private final By exportMetadataIdentifier = By.xpath("//*[contains(@class,'panelHeader')]/parent::tr//*[@title='Export Metadata']");
	private final By exportMetadataIdentifierJob = By.xpath("//button[text()='Save as Job']");
	private final By accountMetadataCheckbox = By.xpath("//input[@id='zr0:0:zt0:0:tab:1:r4:1:pt1:da:1:t1:0:sbc1::content']");
	private final By fileUploadIdentifier = By.xpath("//*[text()='Import File'][contains(@class,'column_label-text')]");
	private final By iFrameTag = By.xpath("//iframe");

	/**
	 * Constructor to initialize the page
	 *
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	public ApplicationOverviewPage(ScriptHelper scriptHelper) {
		super(scriptHelper);
		isElementAvailable(pageIdentifier,ELEMENTTIMEOUT);
		PauseScript(SCRIPTTIME);
		driver.findElements(pageIdentifier).size();
		if (driver.findElements(pageIdentifier).size()==0) {
			report.updateTestLog("Verify Business Rules", "Business Rules page expected, but not displayed!", Status.WARNING);
		}
	}

	public void ImportMetadata() {
		String importFilePath = dataTable.getData("RegisterUser_Data", "ImportFilePath").trim();
		isElementAvailable(dimensions,ELEMENTTIMEOUT);
		driver.findElement(dimensions).click();
		isElementAvailable(dimensionsIdentifier,ELEMENTTIMEOUT);
		driver.findElement(btnImport).click();
		isElementAvailable(importMetadataIdentifier,ELEMENTTIMEOUT);
		driver.findElement(btnCreate).click();
		isElementAvailable(fileUploadIdentifier,ELEMENTTIMEOUT);
		try {
			driver.findElement(By.xpath("//*[text()='Account']/")).click();

		driver.findElement(btnChooseAccountFile).sendKeys(importFilePath);
		}catch (Exception e) {
			driver.findElement(By.xpath("//input[@id='zr0:0:zt0:0:tab:1:r4:1:pt1:me:1:t1:0:if1::content']")).sendKeys(importFilePath);

		}



		int numberOfIframe = driver.findElements(iFrameTag).size();
		for (int i = 0; i < numberOfIframe; i++) {
			driver.switchTo().frame(i);
			int numberOfIframes = driver.findElements(iFrameTag).size();
			try {

				driver.findElement(btnChooseAccountFile).sendKeys(importFilePath);
				report.updateTestLog("Verify Import Metadata File Upload", "Import Metadata upload is in-progress  ", Status.SCREENSHOT);
				PauseScript(SCRIPTTIME * 3);
				driver.findElement(btnImportMetadata).click();
				break;
			}catch (Exception e) {
			} finally {
				driver.switchTo().defaultContent();
			}

		}
		driver.switchTo().defaultContent();

	}

	public void ExportMetadataDownload() {
		isElementAvailable(dimensions,ELEMENTTIMEOUT);
		driver.findElement(dimensions).click();
		report.updateTestLog("Verify Export Metadata", "Dimensions is available for exporting the account  ", Status.PASS);
		isElementAvailable(dimensionsIdentifier,ELEMENTTIMEOUT);
		driver.findElement(btnApplicationExport).click();
		isElementAvailable(exportMetadataIdentifier,ELEMENTTIMEOUT);
		driver.findElement(btnCreate).click();
		isElementAvailable(exportMetadataIdentifierJob,ELEMENTTIMEOUT);
		driver.findElement(	btnAccountSelection).click();
		report.updateTestLog("Verify Export Metadata", "Account is selected for exporting the metadata  ", Status.PASS);
		PauseScript(5);
		driver.findElement(btnExport).click();
		PauseScript(20);
		report.updateTestLog("Verify Export Metadata", "Metadata is exported successfully for the account  ", Status.PASS);



	}


}