package pages;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.ScriptHelper;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

public class ARNotificationiconPage extends MasterPages {

    // Elements

    //Links
    private final By navigator = By.id( "pt1:_UISmmLink::icon" );
    private final By notificationbell = By.xpath( "//*[contains(@id,'t1:_UISatr:0:cil1::icon')]" );
    private final By moredetails = By.xpath( "//*[text()='More Details']" );


    private final By linkmanagebank = By.xpath( "//*[text()='Manage Bank Branches']" );

    private final By orgname = By.xpath( "//label[text()=' Organization Name']/ancestor::td[1]" );
    private final By accnumber = By.xpath( "//*[contains(@id,'table1:0:commandLink1')]/a/span" );
    private final By accnumberenddate = By.xpath( "//*[contains(@id,':inputDate3::glyph')]" );
    //Button
    private final By btnsearch = By.xpath( "//*[contains(@alt,'Search')]" );


    // page loading time
    public static final int PAGELOADTIMEOUT = 90;
    // individual element load time
    public static final int ELEMENTTIMEOUT = 60;

    public static final int SCRIPTTIME = 5;

    /**
     * Constructor to initialize the functional library
     *
     * @param scriptHelper The {@link ScriptHelper} object passed from the
     *                     {@link DriverScript}
     */
    public ARNotificationiconPage(ScriptHelper scriptHelper) {
        super( scriptHelper );
    }

    public void createbank() {
        isElementAvailable( notificationbell, PAGELOADTIMEOUT );
        driver.findElement( notificationbell ).click();
        PauseScript( 2 );
        driver.findElement( moredetails ).click();
        PauseScript( 5 );

    }
}