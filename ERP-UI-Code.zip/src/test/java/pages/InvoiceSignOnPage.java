package pages;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.ScriptHelper;
import com.cognizant.framework.ExcelDataImport;
import com.cognizant.framework.Status;
import org.openqa.selenium.By;

/**
 * FCCS SignOnPage class

 */
public class InvoiceSignOnPage extends MasterPages {

	//Page Sync Config

	// page loading time
	public static final int PAGELOADTIMEOUT = 90;
	// individual element load time
	public static final int ELEMENTTIMEOUT = 60;
	// Oracle query response
	public static final long QUERYRESPONSE = 15;
	// object render script
	public static final long SCRIPTTIME = 5;


	// UI Map object definitions

	// Text boxes
	private final By txtUsername = By.id("userid");
	private final By txtPassword = By.id("password");

	// Buttons
	private final By btnLogin = By.id("btnActive");




	/**
	 * Constructor to initialize the page
	 *
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	public InvoiceSignOnPage(ScriptHelper scriptHelper) {
		super(scriptHelper);
		isElementAvailable(txtUsername,ELEMENTTIMEOUT);
	}

	public CreateInvoicePage loginAsValidInvoiceUser() {
		login();
		return new CreateInvoicePage(scriptHelper);
	}

	private void login() {
		isElementAvailable(txtUsername,PAGELOADTIMEOUT);
		String userNameData = dataTable.getData(ExcelDataImport.GeneralData, "Username");
		String passwordData = dataTable.getData(ExcelDataImport.GeneralData, "Password");

		driver.findElement(txtUsername).sendKeys(userNameData);
		driver.findElement(txtPassword).sendKeys(passwordData);

		report.updateTestLog("Journal Login",
				"Enter Journal login credentials: " + "Username = " + userNameData ,
				Status.DONE);
		driver.findElement(btnLogin).click();
	}

	public InvoiceSignOnPage loginAsInvalidUser() {
		login();
		return new InvoiceSignOnPage(scriptHelper); // Return new object to indicate an
												// actual page navigation
	}
}