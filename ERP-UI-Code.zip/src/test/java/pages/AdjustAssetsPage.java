package pages;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.ScriptHelper;
import com.cognizant.framework.ExcelDataImport;
import com.cognizant.framework.Status;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;


public class AdjustAssetsPage extends  AssetsPage {

    // Elements

    //Links
    private final By navigator = By.xpath( "//a[@title='Navigator']" );
    private final By taskmenu = By.xpath( "//*[@alt='Tasks']" );
    private final By adjustassetsnav = By.xpath( "//*[text()='Adjust Assets']" );
    private final By assetinquiry = By.xpath( "//*[contains(@id,'nv_itemNode_fixed_assets_inquiry')]" );


    // searchcriteria elements
    private final By assetnumber = By.xpath( "//label[text()='Asset Number']/ancestor::tr[1]/td[2]//input" );
    private final By searchresults = By.xpath( "//table[@summary='Search Results']/tbody/tr/td/div/table/tbody/tr[1]" );

    //changedfinancialdetails
    private final By cost = By.xpath( "//label[text()='Cost']/ancestor::tr[1]/td[2]//input" );
    private final By lifeinyears = By.xpath( "//label[text()='Life in Years']/ancestor::tr[1]/td[2]//select" );
    private final By general = By.xpath( "//a[text()='General']" );


    //assertinquiry
    private final By currentcost = By.xpath( "//*[contains(@id,'panelGroupLayout17')]/tbody/tr/td[2]" );
    private final By updatedlifeinyears = By.xpath( "//*[contains(@id,'panelGroupLayout16')]/tbody/tr/td[2]" );
    private final By assets = By.xpath( "//div[contains(@id,'fixed_assets_inquiry:1:_FOTsr1:0:AP4:r1:0:pt2::tabh')]/div/div/div[1]/div/a");
    //*[contains(@id,'assets_inquiry:0:_FOTsr1:0:AP4:r1:0:sdi3::disAcr')]


    //button
    private final By btnsearch = By.xpath( "//button[text()='Search']" );
    private final By btnchangefinancialdetails = By.xpath( "//button[text()='Change Financial Details']" );
    private final By btnsubmit = By.xpath( "//button[@accesskey='m']" );
    private final By btnDone = By.xpath( "//button[@accesskey='o']" );
    private final By btnOK = By.xpath( "//button[contains(@id,'region1:0:ITPdtl:1:d7::ok')]" );

    private final By fixedassets = By.xpath( "//*[contains(@id,'nv_itemNode_fixed_assets_additions')]" );

    //Log off
    private final By userarrow = By.xpath( "//*[contains(@id,'FOpt1:_UIScmil1u::icon')]" );
    private final By signout = By.xpath( "//*[text()='Sign Out']" );

    //depreciation
    private final By depreciation = By.xpath( "//a[@title='Select : Depreciation']" );
    private final By calculatedepreciation = By.xpath( "//*[text()='Calculate Depreciation']" );
    private final By calculatedepreciationdrpdwn = By.xpath( "//*[text()='Calculate Depreciation']/ancestor::tr[1]/td[2]" );
    private final By calculateleaseexpense = By.xpath( "//*[text()='Calculate Lease Expenses']" );
    private final By calculateleaseexpmsg = By.xpath( "//*[text()='Calculate Lease Expense was submitted.']" );

    //close period
    private final By closeperiod = By.xpath( "//*[text()='Close Period']" );
    private final By warningmsg = By.xpath( "//*[text()='The depreciation program will close the period and you cannot reopen it. Do you want to continue?']" );
    private final By btnyes = By.xpath( "//button[@accesskey='Y']" );



    // page loading time
    public static final int PAGELOADTIMEOUT = 90;
    // individual element load time
    public static final int ELEMENTTIMEOUT = 60;
    // Oracle query response
    public static final long QUERYRESPONSE = 15;
    // object render script
    public static final int SCRIPTTIME = 5;

    /**
     * Constructor to initialize the functional library
     *
     * @param scriptHelper The {@link ScriptHelper} object passed from the
     *                     {@link DriverScript}
     */
    public AdjustAssetsPage(ScriptHelper scriptHelper) {
        super( scriptHelper );
    }

    public void adjustAssetnav() {
        isElementAvailable( taskmenu, ELEMENTTIMEOUT );
        driver.findElement( taskmenu ).click();

        isElementAvailable( adjustassetsnav, ELEMENTTIMEOUT );
        driver.findElement( adjustassetsnav ).click();
    }

    private void assetinquirynavi() {
        isElementAvailable( navigator, ELEMENTTIMEOUT );
        driver.findElement( navigator ).click();

        isElementAvailable( assetinquiry, ELEMENTTIMEOUT );
        driver.findElement( assetinquiry ).click();
    }

    private void assetnav() {
        isElementAvailable( navigator, ELEMENTTIMEOUT );
        driver.findElement( navigator ).click();

        isElementAvailable( fixedassets, ELEMENTTIMEOUT );
        driver.findElement( fixedassets ).click();
    }

    private void searchasset() {
        isElementAvailable( assetnumber, PAGELOADTIMEOUT );
        driver.findElement( assetnumber ).click();
        PauseScript( 3 );
        String assetnumb = (dataTable.getData( "General_Data", "Asset Number" ));
        driver.findElement( assetnumber ).sendKeys( assetnumb);
        PauseScript( 3 );
        isElementAvailable( btnsearch, ELEMENTTIMEOUT );
        driver.findElement( btnsearch ).click();
        PauseScript( 2 );
        report.updateTestLog( "Verify the Asset Number", "Asset number displayed on the Search Results", Status.PASS );
        oracleObjectRender( SCRIPTTIME );
    }

    private void clickonsearchresult() {
        isElementAvailable( searchresults, ELEMENTTIMEOUT );
        driver.findElement( searchresults ).click();
        PauseScript( 2 );
    }

    private void clickonchangefinancialdetailsbutton() {
        isElementAvailable( btnchangefinancialdetails, ELEMENTTIMEOUT );
        driver.findElement( btnchangefinancialdetails ).click();
        PauseScript( 3 );
    }

    private void signout() {
        isElementAvailable( userarrow, ELEMENTTIMEOUT );
        driver.findElement( userarrow ).click();
        PauseScript( 1 );
        isElementAvailable( signout, ELEMENTTIMEOUT );
        driver.findElement( signout ).click();
    }

    private void clickongeneraltab() {
        isElementAvailable( general, ELEMENTTIMEOUT );
        driver.findElement( general ).click();
        PauseScript( 2 );
        report.updateTestLog( "Verify the updated data on generat tab", " Data Updated successfully", Status.PASS );
        oracleObjectRender( SCRIPTTIME );
    }

    private void changetheenteredcost() {
        isElementAvailable( cost, ELEMENTTIMEOUT );
        driver.findElement( cost ).clear();
        driver.findElement( cost ).click();
        driver.findElement( cost ).sendKeys( dataTable.getData( "General_Data", "Adjust Cost" ) );
        PauseScript( 2 );
        report.updateTestLog( "Verify the Cost", " Cost Updated successfully", Status.PASS );
    }

    private void clickonsubmit() {
        isElementAvailable( btnsubmit, ELEMENTTIMEOUT );
        driver.findElement( btnsubmit ).click();
        PauseScript( 4 );
    }

    private void clickondonebutton() {
        isElementAvailable( btnDone, ELEMENTTIMEOUT );
        driver.findElement( btnDone ).click();
        PauseScript( 3 );
    }

    private void checktheupdatedcost() {
        isElementAvailable( currentcost, ELEMENTTIMEOUT );
        Assert.assertTrue( driver.findElement( currentcost ).isDisplayed() );
        oracleObjectRender( SCRIPTTIME );
    }
    private void clikconAssets() {
        isElementAvailable( assets, ELEMENTTIMEOUT );
        driver.findElement( assets ).click();
        PauseScript( 4 );
    }

    public void adjustAssetReclassification() {
        searchasset();
        clickonsearchresult();
        clickonchangefinancialdetailsbutton();
        clickongeneraltab();
        changetheenteredcost();
        clickonsubmit();
        clickondonebutton();
        PauseScript( 3 );
        assetinquirynavi();
        clikconAssets();
        searchasset();
        checktheupdatedcost();
        report.updateTestLog( "Verify Adjust Asset Reclassification", " Adjusted the Asset successfully", Status.PASS );
    }

    private void clickondepreciation() {
        isElementAvailable( depreciation, ELEMENTTIMEOUT );
        driver.findElement( depreciation ).click();
        PauseScript( 3 );
        report.updateTestLog( "Verify the Depreciation Click", " Depreciation clicked successfully", Status.PASS );
    }

    private void clickoncalculatedepreciation() {
        isElementAvailable( calculatedepreciation, ELEMENTTIMEOUT );
        driver.findElement( calculatedepreciation ).click();
        oracleObjectRender( SCRIPTTIME );
        report.updateTestLog( "Verify the Depreciation", " Depreciation calculated successfully", Status.PASS );
        PauseScript( 2 );
        signout();
    }

    private void clickonCalculateleaseexpenses() {
        isElementAvailable( calculatedepreciationdrpdwn, ELEMENTTIMEOUT );
        driver.findElement( calculatedepreciationdrpdwn ).click();
        PauseScript( 2 );
        report.updateTestLog( "Verify the Calculate Lease Expense", " Calculate Lease Expense Selected successfully", Status.PASS );
        isElementAvailable( calculateleaseexpense, ELEMENTTIMEOUT );
        driver.findElement( calculateleaseexpense ).click();
        oracleObjectRender( SCRIPTTIME );
        driver.findElement( calculateleaseexpmsg ).isDisplayed();
        PauseScript( 2 );
        driver.findElement( btnOK ).click();
        PauseScript( 2 );
        report.updateTestLog( "Verify the Lease Expense", " Lease Expense calculated successfully", Status.PASS );
        PauseScript( 2 );
        signout();
    }

    public void depreciationcalculation() {
        clickondepreciation();
        clickoncalculatedepreciation();
    }

    public void CalculateperiodicInterest() {
        clickondepreciation();
        clickonCalculateleaseexpenses();
    }

    private void checktheupdatedlifeinyears() {
        isElementAvailable( updatedlifeinyears, ELEMENTTIMEOUT );
        Assert.assertTrue( driver.findElement( updatedlifeinyears ).isDisplayed() );
        oracleObjectRender( SCRIPTTIME );
        report.updateTestLog( "Verify the Adjust Life for Created Asset", " Adjusted the Life for the Asset successfully", Status.PASS );
    }

    private void updatethelife() {
        isElementAvailable( lifeinyears, ELEMENTTIMEOUT );
        Select drplifeinyears = new Select( driver.findElement( lifeinyears ) );
        drplifeinyears.selectByValue( dataTable.getData(ExcelDataImport.GeneralData, "Adjust Life" ) );
        PauseScript( 3 );
        report.updateTestLog( "Verify the Life in years", " Updated the Life in Years successfully", Status.PASS );
    }

    //Adjust Asset Life
    public void adjustassetlife() {
        searchasset();
        clickonsearchresult();
        clickonchangefinancialdetailsbutton();
        clickongeneraltab();
        updatethelife();
        clickonsubmit();
        clickondonebutton();
        assetinquirynavi();
        clikconAssets();
        searchasset();
        checktheupdatedlifeinyears();
    }

    //Close Period
    public void closePeriod() {
        isElementAvailable( calculatedepreciationdrpdwn, ELEMENTTIMEOUT );
        driver.findElement( calculatedepreciationdrpdwn ).click();
        PauseScript( 2 );
        isElementAvailable( closeperiod, ELEMENTTIMEOUT );
        driver.findElement( closeperiod ).click();
        oracleObjectRender( SCRIPTTIME );
        driver.findElement( warningmsg ).isDisplayed();
        PauseScript( 2 );
        driver.findElement( btnyes ).click();
        PauseScript( 2 );
        report.updateTestLog( "Verify the close period", " Close period Completed Successfully", Status.PASS );
        PauseScript( 3 );
        signout();
    }
}

