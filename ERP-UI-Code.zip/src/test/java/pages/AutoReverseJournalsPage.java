package pages;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.ScriptHelper;
import com.cognizant.framework.ExcelDataImport;
import com.cognizant.framework.Status;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

/**
 * Journals Page class
 */
public class AutoReverseJournalsPage extends MasterPages {
	// UI Map object definitions

	// Elements


	private final By dataAccessSetDrpdown = By.xpath("//label[contains(text(),'Data Access Set')]/../following-sibling::td[1]/select");
	private final By ledgerDrpdown = By.xpath("//label[contains(text(),'Ledger')]/../following-sibling::td[1]/select");
	private final By reversalPeriodDrpdown = By.xpath("//label[contains(text(),'Reversal Period')]/../following-sibling::td[1]/select");
	private final By submissionNotesText = By.xpath("//label[contains(text(),'Submission Notes')]/../../following-sibling::td[1]/span/input");
	private final By submitButton = By.xpath("//span[contains(text(),'Advanced')]/../../../following-sibling::td[2]");
	private final By submitConfirmationText = By.xpath("//span[contains(@id,'requestBtns:confirmationPopup:pt_ol1')]/label");
	private final By okButton = By.xpath("//td[contains(@id,'confirmationPopup:confirmSubmitDialog::_fcc')]/button");

	//Page Sync Config

	// page loading time
	public static final int PAGELOADTIMEOUT = 90;
	// individual element load time
	public static final int ELEMENTTIMEOUT = 60;
	// Oracle query response
	public static final long QUERYRESPONSE = 15;
	// object render script
	public static final long SCRIPTTIME = 5;

	/**
	 * Constructor to initialize the page
	 *
	 * @param scriptHelper The {@link ScriptHelper} object passed from the
	 *                     {@link DriverScript}b  n '/fg .+
	 */
	public AutoReverseJournalsPage(ScriptHelper scriptHelper) {
		super(scriptHelper);
		isElementAvailable(dataAccessSetDrpdown, PAGELOADTIMEOUT);
	}


	public String EnterDetailsToAutoReverseJournal() {
		oracleObjectRender(SCRIPTTIME);
		isElementAvailable(dataAccessSetDrpdown, PAGELOADTIMEOUT);
		Assert.assertEquals(driver.findElement(dataAccessSetDrpdown).getAttribute("title"), (dataTable.getData(ExcelDataImport.GeneralData, "DataAccessSet")));
		isElementAvailable(ledgerDrpdown, ELEMENTTIMEOUT);
		Assert.assertEquals(driver.findElement(ledgerDrpdown).getAttribute("title"), (dataTable.getData(ExcelDataImport.GeneralData, "DataAccessSet")));
        report.updateTestLog("Auto  Reversal Journal Page ", "The user is able to Enter the criteria condition for Auto Reversal Journal", Status.PASS);
		isElementAvailable(reversalPeriodDrpdown, ELEMENTTIMEOUT);
		Select selectDropDown = new Select(driver.findElement(reversalPeriodDrpdown));
		selectDropDown.selectByVisibleText(dataTable.getData(ExcelDataImport.GeneralData, "ReversalPeriod"));
		isElementAvailable(submissionNotesText, ELEMENTTIMEOUT);
		driver.findElement(submissionNotesText).sendKeys(dataTable.getData(ExcelDataImport.GeneralData, "Comments"));
		isElementAvailable(submitButton, ELEMENTTIMEOUT);
		driver.findElement(submitButton).click();
		//TODO START Regression failure added more wait time
		oracleObjectRender(SCRIPTTIME);
		//TODO END
		isElementAvailable(submitConfirmationText, ELEMENTTIMEOUT);
		try {
			driver.findElement(submitConfirmationText).isDisplayed();
			report.updateTestLog("Auto Reversal  Journal Page ", "Auto Reversal Journal Page", Status.PASS);
		} catch (Exception e) {
			report.updateTestLog("Auto Reversal Journal Page ", "Auto Reversal Journal Page", Status.FAIL);
		}
			String innerTextValue = driver.findElement(submitConfirmationText).getAttribute("innerHTML");
			String innerText[] = innerTextValue.split(" ");
			isElementAvailable(okButton, ELEMENTTIMEOUT);
			driver.findElement(okButton).click();
		oracleObjectRender(QUERYRESPONSE);
		return innerText[1];

	}

	}




