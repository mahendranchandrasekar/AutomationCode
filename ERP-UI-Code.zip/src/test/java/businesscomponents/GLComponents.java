package businesscomponents;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.ReusableLibrary;
import com.cognizant.craft.ScriptHelper;
import com.cognizant.framework.Status;
import pages.*;


/**
 * Class for storing general purpose business components
 */
public class GLComponents extends ReusableLibrary {

	/**
	 * Constructor to initialize the component library
	 *
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	public GLComponents(ScriptHelper scriptHelper) {
		super(scriptHelper);
	}



	public void createJournalForGBP()  {
		NavigationPage navigationPage= new NavigationPage(scriptHelper);
		navigationPage.menuNavigation();
		navigationPage.clickOnMainJournalLink();
		navigationPage.changeDataSetAccess();
		navigationPage.clickOnJournalTaskMenu();
		report.updateTestLog("Verify Journal Navigation", "Journal Navigation is present for the user", Status.PASS);
		navigationPage.clickOnCreateJournalLink();
		JournalsCreatePage journalsCreatePage= new JournalsCreatePage(scriptHelper);
		journalsCreatePage.EnterBasicDetailsForCreateJournal();
		journalsCreatePage.enterBankDetailsForGBPCurrency();
		report.updateTestLog("Verify Create Journal", "The user is able to Create Journal successfully", Status.PASS);
		journalsCreatePage.saveTheDetailsForCreateJournal();
		journalsCreatePage.completeTheDetailsForCreateJournal();
		journalsCreatePage.postTheDetailsForCreateJournal();
		navigationPage.clickOnCancelButton();
	}


	public void createJournalForForeignCurrency()  {
		NavigationPage navigationPage= new NavigationPage(scriptHelper);
		navigationPage.menuNavigation();
		navigationPage.clickOnMainJournalLink();
		navigationPage.changeDataSetAccess();
		navigationPage.clickOnJournalTaskMenu();
		report.updateTestLog("Verify Journal Navigation", "Journal Navigation is present for the user", Status.PASS);
		navigationPage.clickOnCreateJournalLink();
		JournalsCreatePage journalsCreatePage= new JournalsCreatePage(scriptHelper);
		journalsCreatePage.EnterBasicDetailsForCreateJournal();
		journalsCreatePage.enterBankDetailsForForiegnCurrency();
		report.updateTestLog("Verify Create Journal", "The user is able to Create Journal successfully", Status.PASS);
		journalsCreatePage.saveTheDetailsForCreateJournal();
		journalsCreatePage.completeTheDetailsForCreateJournal();
		journalsCreatePage.postTheDetailsForCreateJournal();
		navigationPage.clickOnCancelButton();
	}

	public void autoReverseJournal()  {
		NavigationPage navigationPage= new NavigationPage(scriptHelper);
		navigationPage.menuNavigation();
		navigationPage.clickOnMainJournalLink();
		navigationPage.changeDataSetAccess();
		navigationPage.clickOnJournalTaskMenu();
		report.updateTestLog("Verify Journal Navigation", "Journal Navigation is present for the user", Status.PASS);
		navigationPage.clickOnRunAutoReverseLink();
		AutoReverseJournalsPage autoReverseJournalsPage = new AutoReverseJournalsPage(scriptHelper);
		String processNumber = autoReverseJournalsPage.EnterDetailsToAutoReverseJournal();
		navigationPage.clickOnHomeIcon();
		navigationPage.clickOntoolsIcon();
		navigationPage.verifyTheScheduledProcessesIcon(processNumber);
	}

	public void createJournalForUnequalCRAndDR()  {
		NavigationPage navigationPage= new NavigationPage(scriptHelper);
		navigationPage.menuNavigation();
		navigationPage.clickOnMainJournalLink();
		navigationPage.changeDataSetAccess();
		navigationPage.clickOnJournalTaskMenu();
		navigationPage.clickOnCreateJournalLink();
		report.updateTestLog("Verify Journal Navigation", "Journal Navigation is present for the user", Status.PASS);
		JournalsCreatePage journalsCreatePage= new JournalsCreatePage(scriptHelper);
		journalsCreatePage.EnterBasicDetailsForCreateJournal();
		journalsCreatePage.enterBankDetailsForGBPCurrency();
		report.updateTestLog("Unequal Credit and Debit in Journal lines", "Unequal Credit and Debit in Journal lines", Status.PASS);
		journalsCreatePage.saveTheDetailsForCreateJournalForUnEqualCRAndDR();
		journalsCreatePage.completeTheDetailsForCreateJournalForUnEqualCRAndDR();
		journalsCreatePage.postTheDetailsForCreateJournalForUnEqualCRAndDR();
		navigationPage.clickOnCancelButton();
	}

	public void verifyJournalIsPosted()  {
		NavigationPage navigationPage= new NavigationPage(scriptHelper);
		navigationPage.clickOnJournalTaskMenu();
		navigationPage.clickOnManageJournalsLink();
		JournalsManagePage journalsManagePage = new JournalsManagePage(scriptHelper);
		journalsManagePage.searchAndVerifyPostedJournal();
		report.updateTestLog("Verify the status of Journal", "The user is able to search and verify the Posted Journal successfully", Status.PASS);
	}

    public void openPeriodForJournal()  {
		NavigationPage navigationPage= new NavigationPage(scriptHelper);
		navigationPage.menuNavigation();
		navigationPage.clickOnMainPeriodCloseLink();
        PeriodCloseJournalsPage periodCloseJournalsPage= new PeriodCloseJournalsPage(scriptHelper);
        periodCloseJournalsPage.openPeriodForJournal();
    }

    public void closePeriodForJournal()  {
		NavigationPage navigationPage= new NavigationPage(scriptHelper);
		navigationPage.menuNavigation();
		navigationPage.clickOnMainPeriodCloseLink();
        PeriodCloseJournalsPage periodCloseJournalsPage= new PeriodCloseJournalsPage(scriptHelper);
        periodCloseJournalsPage.closePeriodForJournal();
    }

	public void verifyUnpostedJournal()  {
		NavigationPage navigationPage= new NavigationPage(scriptHelper);
		navigationPage.clickOnJournalTaskMenu();
		navigationPage.clickOnManageJournalsLink();
		report.updateTestLog("Verify Un-posted Journal", "Un-posted Journal", Status.PASS);
		JournalsManagePage journalsManagePage = new JournalsManagePage(scriptHelper);
		journalsManagePage.searchTheUnPostedJournal();
	}

	public void validateAccountingPeriod()  {
		NavigationPage navigationPage= new NavigationPage(scriptHelper);
		navigationPage.menuNavigation();
		navigationPage.clickOnMainJournalLink();
		navigationPage.changeDataSetAccess();
		navigationPage.clickOnJournalTaskMenu();
		navigationPage.clickOnCreateJournalLink();
		report.updateTestLog("Verify Journal Navigation", "Journal Navigation is present for the user", Status.PASS);
		JournalsCreatePage journalsCreatePage= new JournalsCreatePage(scriptHelper);
		journalsCreatePage.verifyAccountingPeriod();
		journalsCreatePage.saveTheDetailsForCreateJournal();
	}


	public void validateAccountInJournalLines()  {
		NavigationPage navigationPage= new NavigationPage(scriptHelper);
		navigationPage.menuNavigation();
		navigationPage.clickOnMainJournalLink();
		navigationPage.changeDataSetAccess();
		navigationPage.clickOnJournalTaskMenu();
		navigationPage.clickOnCreateJournalLink();
		report.updateTestLog("Verify Journal Navigation", "Journal Navigation is present for the user", Status.PASS);
		JournalsCreatePage journalsCreatePage= new JournalsCreatePage(scriptHelper);
		journalsCreatePage.verifyAccountInJournalLines();
		journalsCreatePage.saveTheDetailsForCreateJournal();
	}

    public void deleteUnpostedJournal()  {
		NavigationPage navigationPage= new NavigationPage(scriptHelper);
        report.updateTestLog("Journal Page", "The user is able to view the navigation link and the Journals page is opened", Status.PASS);
		navigationPage.clickOnJournalTaskMenu();
		navigationPage.clickOnManageJournalsLink();
        report.updateTestLog("Manage Journal Page", "The user is able to view the navigation link and the Manage Journals page is opened", Status.PASS);
		JournalsManagePage journalsManagePage = new JournalsManagePage(scriptHelper);
        journalsManagePage.searchVerifyUnPostedJournal();
		JournalsCreatePage journalsCreatePage= new JournalsCreatePage(scriptHelper);
		journalsCreatePage.deleteForCreateJournal();
    }

	public void verifyPostedJournal()  {
		NavigationPage navigationPage= new NavigationPage(scriptHelper);
		navigationPage.menuNavigation();
		navigationPage.clickOnMainJournalLink();
		navigationPage.clickOnJournalTaskMenu();
		navigationPage.clickOnManageJournalsLink();
		JournalsManagePage journalsManagePage = new JournalsManagePage(scriptHelper);
		journalsManagePage.searchPostedAndUnPostedJournal();
		report.updateTestLog("Search the Posted Journal in Manage Journal", "Search the Posted Journal and review", Status.PASS);
		JournalsCreatePage journalsCreatePage= new JournalsCreatePage(scriptHelper);
		journalsCreatePage.autoCopyForCreateJournal();
		journalsCreatePage.saveTheDetailsForCreateJournal();
		journalsCreatePage.completeTheDetailsForCreateJournal();
		journalsCreatePage.postTheDetailsForCreateJournal();
		navigationPage.clickOnCancelButton();
	}

	public void intercompanyTransactionProcessForRecharge()  {
		NavigationPage navigationPage= new NavigationPage(scriptHelper);
		navigationPage.menuNavigation();
		navigationPage.clickOnMainTransactionsLink();
		navigationPage.clickOnTransactionTaskMenu();
		navigationPage.clickOnCreateTransactionLink();
		InterCompanyCreationPage interCompanyCreationPage = new InterCompanyCreationPage(scriptHelper);
		String batchNumber = interCompanyCreationPage.enterInterCompanyDetails();
		interCompanyCreationPage.saveInterCompanyDetails();
		interCompanyCreationPage.submitInterCompanyDetails();
		/*navigationPage.clickOnTransactionTaskMenu();
		navigationPage.clickOnManageIntercompanyInboundTransactionLink();
		IntercompanyInboundManagePage intercompanyInboundManagePage= new IntercompanyInboundManagePage(scriptHelper);
		intercompanyInboundManagePage.searchAndVerifyIntercompanyTransaction(batchNumber);*/
	}

	public void intercompanyTransactionProcess()  {
		NavigationPage navigationPage= new NavigationPage(scriptHelper);
		navigationPage.menuNavigation();
		navigationPage.clickOnMainTransactionsLink();
		navigationPage.clickOnTransactionTaskMenu();
		navigationPage.clickOnCreateTransactionLink();
		InterCompanyCreationPage interCompanyCreationPage = new InterCompanyCreationPage(scriptHelper);
		String batchNumber = interCompanyCreationPage.enterInterCompanyDetails();
		interCompanyCreationPage.saveInterCompanyDetails();
	}


    public void signoutFromApplication()  {
		NavigationPage navigationPage= new NavigationPage(scriptHelper);
		navigationPage.signoutFromApplication();
        report.updateTestLog("Verify SignOut", "The user is able to sign out the application successfully", Status.PASS);

    }


	public void signoutAndCloseTheApplication()  {
		NavigationPage navigationPage= new NavigationPage(scriptHelper);
		navigationPage.signoutAndCloseApplication();
		report.updateTestLog("Verify SignOut", "The user is able to sign out the application successfully", Status.PASS);

	}


    public void arcsSignout()  {
        NavigationPage navigationPage= new NavigationPage(scriptHelper);
        navigationPage.arcsSignout();
        report.updateTestLog("Verify SignOut", "The user is able to sign out the application successfully", Status.PASS);

    }

}