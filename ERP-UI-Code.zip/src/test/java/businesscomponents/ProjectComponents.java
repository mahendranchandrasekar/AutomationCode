package businesscomponents;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.ReusableLibrary;
import com.cognizant.craft.ScriptHelper;
import com.cognizant.framework.Status;
import pages.*;

public class ProjectComponents extends ReusableLibrary {

    /**
     * Constructor to initialize the component library
     *
     * @param scriptHelper The {@link ScriptHelper} object passed from the
     *                     {@link DriverScript}
     */
    public ProjectComponents(ScriptHelper scriptHelper) {
        super( scriptHelper );
    }

    public void projectfinancialmanagementNavigation() {
        ARHomePage arHomePage = new ARHomePage( scriptHelper );
        arHomePage.projectfinancialmanagementNav();
        report.updateTestLog( "Verify the Project Financial management navigation", " User navigated to Project Financial Management successfully", Status.PASS );
    }

    public void projectassetnavigation() {
        ARHomePage arHomePage = new ARHomePage( scriptHelper );
        arHomePage.projectAssetNavigation();
        report.updateTestLog( "Verify the Project Asset navigation", " User navigated to Project Asset successfully", Status.PASS );
    }

    public void projectnavigation() {
        FAProjectAssetPage FAProjectAssetPage = new FAProjectAssetPage( scriptHelper );
        FAProjectAssetPage.projectnav();
        report.updateTestLog( "Verify the Project", " User navigated to Project section successfully", Status.PASS );
    }


    public void projectassetnav() {
        FAProjectAssetPage FAProjectAssetPage = new FAProjectAssetPage( scriptHelper );
        FAProjectAssetPage.projectAssetnav();
        report.updateTestLog( "Verify the Project Assets section", " User navigated to Project Assets section successfully", Status.PASS );
    }

    public void createprojectfromtemplate() {
        FAProjectAssetPage FAProjectAssetPage = new FAProjectAssetPage( scriptHelper );
        FAProjectAssetPage.createProjectfromTemplate();

    }

    public void createprojectfromsourcetemplate() {
        FAProjectAssetPage FAProjectAssetPage = new FAProjectAssetPage( scriptHelper );
        FAProjectAssetPage.createProjectfromsourceTemplate();

    }


    public void managecapitalProjectsnav() {
        AssetCaptilisationPage assetCaptilisationPage = new AssetCaptilisationPage( scriptHelper );
        assetCaptilisationPage.managecapitalprojectsnav();
        report.updateTestLog( "Verify the Manage Captial Projects navigation", " Manage Capital Project present for the user", Status.PASS );
    }

    public void createassetShell() {
        AssetCaptilisationPage assetCaptilisationPage = new AssetCaptilisationPage( scriptHelper );
        assetCaptilisationPage.createAssetshell();

    }

    public void createManualCapitalevent() {
        AssetCaptilisationPage assetCaptilisationPage = new AssetCaptilisationPage( scriptHelper );
        assetCaptilisationPage.createManualcaptialevent();

    }

    public void generateassetLines() {
        AssetCaptilisationPage assetCaptilisationPage = new AssetCaptilisationPage( scriptHelper );
        assetCaptilisationPage.generateAssetlines();
    }

    public void transferassetstoOraclefusionassetsNav() {
        AssetCaptilisationPage assetCaptilisationPage = new AssetCaptilisationPage( scriptHelper );
        assetCaptilisationPage.transferassetstooraclefusionassetsnav();
        report.updateTestLog( "Verify the Transfer Assets navigation", " Transfer Assets to Oracle Fusion Asset present for user", Status.PASS );
    }

    public void transferassetstoOraclefusionassets() {
        AssetCaptilisationPage assetCaptilisationPage = new AssetCaptilisationPage( scriptHelper );
        assetCaptilisationPage.transferCapitalAssetstooracleFusionassets();
    }

    public void updateassetsInformationforCapitalassetsnav() {
        AssetCaptilisationPage assetCaptilisationPage = new AssetCaptilisationPage( scriptHelper );
        assetCaptilisationPage.updateAssetsInformationfromOracleFusionAssetsnav();
        report.updateTestLog( "Verify Update assets navigation", " Update Assets Information from Oracle Fusion Asset present for the user", Status.PASS );
    }


    public void updateassetsInformationforCapitalassets() {
        AssetCaptilisationPage assetCaptilisationPage = new AssetCaptilisationPage( scriptHelper );
        assetCaptilisationPage.UpdateAssetsInformationforCapitalassets();
    }


    public void projectcostsnav() {
        ARHomePage arHomePage = new ARHomePage( scriptHelper );
        arHomePage.projectCosttNavigation();
        report.updateTestLog( "Verify Project Costs Navigation", " Project Cost present for the user", Status.PASS );
    }

    public void accountingPeriodcloseexceptionReportnav() {
        AccountingPeriodCloseExceptionReportPage accountingPeriodCloseExceptionReportPage = new AccountingPeriodCloseExceptionReportPage( scriptHelper );
        accountingPeriodCloseExceptionReportPage.accountingperiodcloseexceptionreportnav();
        report.updateTestLog( "Verify Project Costs Navigation", " Project Cost present for the user", Status.PASS );
    }

    public void closeprojectperiod() {
        AccountingPeriodCloseExceptionReportPage accountingPeriodCloseExceptionReportPage = new AccountingPeriodCloseExceptionReportPage( scriptHelper );
        accountingPeriodCloseExceptionReportPage.closetheProjectperiod();
    }

    public void manageAccountingperiodsNav() {
        AccountingPeriodCloseExceptionReportPage accountingPeriodCloseExceptionReportPage = new AccountingPeriodCloseExceptionReportPage( scriptHelper );
        accountingPeriodCloseExceptionReportPage.Manageaccountingperiodsnav();
        report.updateTestLog( "Verify Manage Accounting Periods Navigation", " Manage Accounting Periods present for the user", Status.PASS );
    }

    public void opentheprojectperiod() {
        AccountingPeriodCloseExceptionReportPage accountingPeriodCloseExceptionReportPage = new AccountingPeriodCloseExceptionReportPage( scriptHelper );
        accountingPeriodCloseExceptionReportPage.OpentheProjectperiod();
    }

    public void manageProjectcostNav() {
        ManageProjectCostPage manageProjectCostPage = new ManageProjectCostPage( scriptHelper );
        manageProjectCostPage.manageprojectcostnav();
        report.updateTestLog( "Verify Manage Project Cost Navigation", " Manage Project Cost present for the user", Status.PASS );
    }

    public void massAdjusmentofTransactionfromcapitalizable() {
        ManageProjectCostPage manageProjectCostPage = new ManageProjectCostPage( scriptHelper );
        manageProjectCostPage.MassadjusmentofTransactionfromcapitalizabletononcappitalizable();
    }


    public void massadjusmentofProjecttoProjectcostmovement() {
        ManageProjectCostPage manageProjectCostPage = new ManageProjectCostPage( scriptHelper );
        manageProjectCostPage.MassadjusmentofprojecttoProjectcostmovementforTransfers();
    }

    public void capturecostsNav() {
        ManageProjectCostPage manageProjectCostPage = new ManageProjectCostPage( scriptHelper );
        manageProjectCostPage.Capturecostnav();
        report.updateTestLog( "Verify Capture Costs Navigation", " Capture Costs present for the user", Status.PASS );
    }



}
