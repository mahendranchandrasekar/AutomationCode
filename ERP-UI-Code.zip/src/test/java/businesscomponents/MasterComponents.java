package businesscomponents;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.ReusableLibrary;
import com.cognizant.craft.ScriptHelper;
import com.cognizant.framework.ExcelDataImport;
import com.cognizant.framework.Status;
import pages.ArcsSignOnPage;
import pages.InvoiceSignOnPage;
import pages.Loginpage;
import pages.SignOnPage;

public class MasterComponents extends ReusableLibrary {

    /**
     * Constructor to initialize the component library
     *
     * @param scriptHelper The {@link ScriptHelper} object passed from the
     *                     {@link DriverScript}
     */
    public MasterComponents(ScriptHelper scriptHelper) {
        super(scriptHelper);
    }

    public void invokeARTestApplication() {
        report.updateTestLog("Invoke Application",
                "Invoke the application under test @ " + properties.getProperty("ARTestApplicationUrl"), Status.DONE);
        driver.manage().deleteAllCookies();
        driver.get(properties.getProperty("ARTestApplicationUrl"));
    }

    public void invokeARUATApplication() {
        report.updateTestLog("Invoke Application",
                "Invoke the application under test @ " + properties.getProperty("ARTestApplicationUATUrl"), Status.DONE);

        driver.get(properties.getProperty("ARTestApplicationUATUrl"));
    }
    //Login validuser
    public void loginAsValidARUser() {
        Loginpage loginpage = new Loginpage(scriptHelper);
        loginpage.loginAsValidUser();
        // The login succeeds if the AR login page is displayed
        // Hence no further verification is required
        report.updateTestLog("Verify Login", "Login succeeded for valid user", Status.PASS);
    }

    public void invokeTestApplication() {
        String applicationURL = dataTable.getData(ExcelDataImport.GeneralData, "Url");
        report.updateTestLog("Invoke Application",
                "Invoke the application under test @ " + applicationURL, Status.DONE);

        driver.get(applicationURL);
    }


    public void loginAsValidJournalUser() {
        SignOnPage signOnPage = new SignOnPage(scriptHelper);
        signOnPage.loginAsValidJournalUser();
        report.updateTestLog("Verify Journal Login", "Journal Login succeeded for valid user", Status.PASS);
    }

    public void loginAsTeamMemberUser() {
        SignOnPage signOnPage = new SignOnPage(scriptHelper);
        signOnPage.loginAsTeamMemberUser();
        report.updateTestLog("Verify Team Member Login", "Team Member Login succeeded for valid user", Status.PASS);
    }

    public void loginAsTeamLeaderUser() {
        SignOnPage signOnPage = new SignOnPage(scriptHelper);
        signOnPage.loginAsTeamLeaderUser();
        report.updateTestLog("Verify Team Leader Login", "Team Leader Login succeeded for valid user", Status.PASS);
    }


    public void loginAsTeamLeaderUserTwice() {
        SignOnPage signOnPage = new SignOnPage(scriptHelper);
        signOnPage.loginAsTeamLeaderUserTwice();
        report.updateTestLog("Verify Team Leader Login", "Team Leader Login succeeded for valid user", Status.PASS);
    }

    public void loginAsValidArcsUser() {
        ArcsSignOnPage signOnPage = new ArcsSignOnPage(scriptHelper);
        signOnPage.loginAsValidArcsUser();
        report.updateTestLog("Verify ARCS Login", "ARCS Login succeeded for valid user", Status.PASS);
    }

    public void loginAsValidInvoiceUser() {
        InvoiceSignOnPage signOnPage = new InvoiceSignOnPage(scriptHelper);
        signOnPage.loginAsValidInvoiceUser();
        report.updateTestLog("Verify Create Invoice Login", "Create Invoice Login succeeded for valid user", Status.PASS);
    }


}






