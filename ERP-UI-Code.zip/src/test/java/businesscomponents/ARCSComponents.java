package businesscomponents;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.ReusableLibrary;
import com.cognizant.craft.ScriptHelper;
import com.cognizant.framework.Status;
import pages.ArcsJobsPage;
import pages.ArcsMatchingPage;
import pages.ArcsPeriodsPage;
import pages.NavigationPage;


/**
 * Class for storing general purpose business components
 */
public class ARCSComponents extends ReusableLibrary {

	/**
	 * Constructor to initialize the component library
	 *
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	public ARCSComponents(ScriptHelper scriptHelper) {
		super(scriptHelper);
	}



	public void runAutoMatchProcess()  {
		NavigationPage navigationPage= new NavigationPage(scriptHelper);
		navigationPage.menuNavigation();
		navigationPage.clickOnMainJobsLink();
		report.updateTestLog("ARCS Jobs Homepage", "The Landing page is ARCS Jobs Homepage", Status.PASS);
		ArcsJobsPage arcsJobsPage= new ArcsJobsPage(scriptHelper);
		arcsJobsPage.runAutoMatch();
	}

	public void deportImportTransactionProcess()  {
		NavigationPage navigationPage= new NavigationPage(scriptHelper);
		navigationPage.menuNavigation();
		navigationPage.clickOnMainJobsLink();
		report.updateTestLog("ARCS Jobs Homepage", "The Landing page is ARCS Jobs Homepage", Status.PASS);
		ArcsJobsPage arcsJobsPage= new ArcsJobsPage(scriptHelper);
		arcsJobsPage.deportImportTransaction();
	}

	public void manuallyUnmatchTransactionProcess()  {
		NavigationPage navigationPage= new NavigationPage(scriptHelper);
		navigationPage.menuNavigation();
		navigationPage.clickOnMainMatchingLink();
		report.updateTestLog("ARCS Matching Homepage", "The Landing page is ARCS Matching Homepage", Status.PASS);
		ArcsMatchingPage arcsMatchingPage= new ArcsMatchingPage(scriptHelper);
		arcsMatchingPage.manuallyUnmatchTransaction();
	}

    public void runManualMatchProcess()  {
        NavigationPage navigationPage= new NavigationPage(scriptHelper);
        navigationPage.menuNavigation();
        navigationPage.clickOnMainMatchingLink();
        report.updateTestLog("ARCS Matching Homepage", "The Landing page is ARCS Matching Homepage", Status.PASS);
        ArcsMatchingPage arcsMatchingPage= new ArcsMatchingPage(scriptHelper);
        arcsMatchingPage.runManualMatch();
    }

    public void exportUnmatchedTransactionProcess()  {
        NavigationPage navigationPage= new NavigationPage(scriptHelper);
        navigationPage.menuNavigation();
        navigationPage.clickOnMainMatchingLink();
        report.updateTestLog("ARCS Matching Homepage", "The Landing page is ARCS Matching Homepage", Status.PASS);
        ArcsMatchingPage arcsMatchingPage= new ArcsMatchingPage(scriptHelper);
        arcsMatchingPage.exportUnmatchedTransaction();
    }

    public void openNewPeriodProcess()  {
        NavigationPage navigationPage= new NavigationPage(scriptHelper);
        navigationPage.menuNavigation();
        navigationPage.clickOnMainPeriodLink();
        report.updateTestLog("ARCS Periods Homepage", "The Landing page is ARCS Periods Homepage", Status.PASS);
        ArcsPeriodsPage arcsPeriodsPage= new ArcsPeriodsPage(scriptHelper);
        arcsPeriodsPage.OpenNewPeriod();
    }

}