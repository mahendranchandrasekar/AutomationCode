package businesscomponents;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.ReusableLibrary;
import com.cognizant.craft.ScriptHelper;
import com.cognizant.framework.Status;
import pages.*;
import pages.AdjustAssetsPage;

public class AssetComponents extends ReusableLibrary {

    /**
     * Constructor to initialize the component library
     *
     * @param scriptHelper The {@link ScriptHelper} object passed from the
     *                     {@faslink DriverScript}
     */
    public AssetComponents(ScriptHelper scriptHelper) {
        super( scriptHelper );
    }

    public void assetnavigation() {
        ARHomePage arHomePage = new ARHomePage( scriptHelper );
        arHomePage.assetNavigation();
        report.updateTestLog( "Verify the user is able to navigate to Asset section", " User navigated to Asset section successfully", Status.PASS );
    }

    public void addassetnav() {
        AssetsPage assetsPage = new AssetsPage( scriptHelper );
        assetsPage.addAssetnav();
        report.updateTestLog( "Verify the user is able to navigate to Add Asset section", " User navigated to Add Asset section successfully", Status.PASS );
    }

    public void assetCreation() {
        AssetsPage assetsPage = new AssetsPage( scriptHelper );
        assetsPage.createAsset();

    }


    public void aadjustassetnav() {
        AdjustAssetsPage adjustAssetsPage = new AdjustAssetsPage( scriptHelper );
        adjustAssetsPage.adjustAssetnav();
        report.updateTestLog( "Verify the Adjust Asset section", " User navigated to Adjust Asset section successfully", Status.PASS );
    }

    public void addjustAsset() {
        AdjustAssetsPage adjustAssetsPage = new AdjustAssetsPage( scriptHelper );
        adjustAssetsPage.adjustAssetReclassification();

    }

    public void addjustAssetlife() {
        AdjustAssetsPage adjustAssetsPage = new AdjustAssetsPage( scriptHelper );
        adjustAssetsPage.adjustassetlife();

    }

    public void depreciationCalculation() {
        AdjustAssetsPage adjustAssetsPage = new AdjustAssetsPage( scriptHelper );
        adjustAssetsPage.depreciationcalculation();

    }

    public void assetAddition() {
        AssetsPage assetsPage = new AssetsPage( scriptHelper );
        assetsPage.assetaddition();

    }

    public void calculatePeriodicInterest() {
        AdjustAssetsPage adjustAssetsPage = new AdjustAssetsPage( scriptHelper );
        adjustAssetsPage.CalculateperiodicInterest();

    }


    public void retireassetsNav() {
        AssetRetirement assetRetirement = new AssetRetirement( scriptHelper );
        assetRetirement.retireAssetsnav();
        report.updateTestLog( "Verify the user is able to navigate to Asset Retirement", " User navigated to Asset Retirement Successfully", Status.PASS );
    }

    public void retirementofAsset() {
        AssetRetirement assetRetirement = new AssetRetirement( scriptHelper );
        assetRetirement.retirementofAsset();

    }

    public void reinstateassetNav() {
        AssetRetirement assetRetirement = new AssetRetirement( scriptHelper );
        assetRetirement.reinstateassetnav();
        report.updateTestLog( "Verify the user is able to navigate to Reinsatate Asset", " User navigated to Reinstate Asset  Successfully", Status.PASS );
    }


    public void assetresintatement() {
        AssetRetirement assetRetirement = new AssetRetirement( scriptHelper );
        assetRetirement.reinstatementofAsset();

    }


}

