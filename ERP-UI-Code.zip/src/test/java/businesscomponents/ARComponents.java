package businesscomponents;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.ReusableLibrary;
import com.cognizant.craft.ScriptHelper;
import com.cognizant.framework.Status;
import pages.*;

public class ARComponents extends ReusableLibrary {

    /**
     * Constructor to initialize the component library
     *
     * @param scriptHelper The {@link ScriptHelper} object passed from the
     *                     {@link DriverScript}
     */
    public ARComponents(ScriptHelper scriptHelper) {
        super( scriptHelper );
    }

    public void billingNavigation() {
        ARHomePage arHomePage = new ARHomePage( scriptHelper );
        arHomePage.billingNav();
        report.updateTestLog( "Verify user navigation on the billing section", "User navigated to Billing section successfully", Status.PASS );
    }

    public void managecustomersnav() {
        ARCustomerpage arCustomerpage = new ARCustomerpage( scriptHelper );
        arCustomerpage.managecustomernav();
        report.updateTestLog( "Verify the Manage customers", "Manage Customers navigation present for the user", Status.PASS );
    }

    public void createCustomernav() {
        ARCustomerpage arCustomerpage = new ARCustomerpage( scriptHelper );
        arCustomerpage.createcustomernav();
        report.updateTestLog( "Verify Create Customer", " Create customer navigation present for the user", Status.PASS );
    }

    public void createCustomer() {
        ARCustomerpage arCustomerpage = new ARCustomerpage( scriptHelper );
        arCustomerpage.createCustomer();
    }

    public void managecustomers() {
        ARCustomerpage arCustomerpage = new ARCustomerpage( scriptHelper );
        this.createCustomer();
        arCustomerpage.searchcustomer();
    }

    public void deactivatecustomer() {
        ARCustomerpage arCustomerpage = new ARCustomerpage( scriptHelper );
        this.createCustomer();
        arCustomerpage.deactivateCustomer();
    }


    public void creditTransactionnav() {
        ARBillingPage arBillingPage = new ARBillingPage( scriptHelper );
        arBillingPage.createcreditTransactionnav();
        report.updateTestLog( "Verify the Credit Specific Invoice navigation", " User navigated to Credit Specific Invoice", Status.PASS );
    }

    public void creditTransaction() {
        ARBillingPage arBillingPage = new ARBillingPage( scriptHelper );
        arBillingPage.createTransactionnav();
        String transactionNumber = arBillingPage.invoicecreation();
        arBillingPage.createcreditTransactionnav();
        arBillingPage.creditTransaction(transactionNumber);
    }

    public void createTransactionnav() {
        ARBillingPage arBillingPage = new ARBillingPage( scriptHelper );
        arBillingPage.createTransactionnav();
        report.updateTestLog( "Verify User navigation on the create Transaction section", "User is able to navigated to Transaction section successfully", Status.PASS );
    }

    public void createInvoice() {
        ARBillingPage arBillingPage = new ARBillingPage( scriptHelper );
        arBillingPage.invoicecreation();
    }

    public void createstandalonecreditMemo() {
        ARBillingPage arBillingPage = new ARBillingPage( scriptHelper );
        arBillingPage.standalonecreditmemo();

    }

    public void managetransnav() {
        ARBillingPage arBillingPage = new ARBillingPage( scriptHelper );
        arBillingPage.managetransactionnav();
        report.updateTestLog( "Verify Manage Transaction", "User navigated to Manage Transaction", Status.PASS );
    }

    public void managetransactions() {
        ARBillingPage arBillingPage = new ARBillingPage( scriptHelper );
        arBillingPage.createTransactionnav();
        String transactionNumber = arBillingPage.invoicecreation();
        arBillingPage.managetransactionnav();
        arBillingPage.managetransaction(transactionNumber);
    }

    public void accReceivableNavigation() {
        ARHomePage arHomePage = new ARHomePage( scriptHelper );
        arHomePage.accReceivableNav();
        report.updateTestLog( "Verify user navigation on the Account Receivable section", "User navigated to Account Receivable section successfully", Status.PASS );
    }

    public void receiptnavigation() {
        ARAccountsReceivablePage arAccountsReceivablePage = new ARAccountsReceivablePage( scriptHelper );
        arAccountsReceivablePage.createReceiptnnav();
        report.updateTestLog( "Verify the Create Receipt", "Created Receipt navigation is present for the user", Status.PASS );
    }

    public void reverseReceipt() {
        ARAccountsReceivablePage arAccountsReceivablePage = new ARAccountsReceivablePage( scriptHelper );
        arAccountsReceivablePage.createReceiptnnav();
        String receiptNumber = arAccountsReceivablePage.recieptCreation();
        this.managereceipttnavigation();
        arAccountsReceivablePage.reversereceipt(receiptNumber);
    }


    public void createreciept() {
        ARAccountsReceivablePage arAccountsReceivablePage = new ARAccountsReceivablePage( scriptHelper );
        arAccountsReceivablePage.recieptCreation();
    }


    public void managereceipttnavigation() {
        ARAccountsReceivablePage arAccountsReceivablePage = new ARAccountsReceivablePage( scriptHelper );
        arAccountsReceivablePage.manageReceiptsnnav();
        report.updateTestLog( "Verify the Manage Receipts navigation", " Manage Receipts navigation is present for the user", Status.PASS );
    }

    public void managereciepts() {
        ARAccountsReceivablePage arAccountsReceivablePage = new ARAccountsReceivablePage( scriptHelper );
        arAccountsReceivablePage.createReceiptnnav();
        String receiptNumber = arAccountsReceivablePage.recieptCreation();
        arAccountsReceivablePage.manageReceiptsnnav();
        report.updateTestLog( "Verify the Manage Receipts navigation", " Manage Receipts navigation is present for the user", Status.PASS );
        arAccountsReceivablePage.reviewReceipts(receiptNumber);
    }

    public void applyinvoicetoReceipt() {
        ARBillingPage arBillingPage = new ARBillingPage( scriptHelper );
        arBillingPage.createTransactionnav();
        String transactionNumber = arBillingPage.invoicecreation();
        accReceivableNavigation();
        ARAccountsReceivablePage arAccountsReceivablePage = new ARAccountsReceivablePage( scriptHelper );
        arAccountsReceivablePage.createReceiptnnav();
        String receiptNumber = arAccountsReceivablePage.recieptCreation();
        arAccountsReceivablePage.manageReceiptsnnav();
        arAccountsReceivablePage.applyInvoicetoReceipt(transactionNumber, receiptNumber);

    }

    public void applyAccountonReceipt() {
        ARAccountsReceivablePage arAccountsReceivablePage = new ARAccountsReceivablePage( scriptHelper );
        arAccountsReceivablePage.createReceiptnnav();
         String receiptNumber = arAccountsReceivablePage.recieptCreation();
        this.managereceipttnavigation();
        arAccountsReceivablePage.applyaccountonReceipt(receiptNumber);

    }

    public void manageaccountingPeriodnav() {
        ARAccountsReceivablePage arAccountsReceivablePage = new ARAccountsReceivablePage( scriptHelper );
        arAccountsReceivablePage.manageAccountingperiodnnav();
        report.updateTestLog( "Verify User is able to navigate to Accounting period section", "User navigated to Accounting period section successfully", Status.PASS );
    }


    public void closeARPeriod() {
        ARAccountsReceivablePage arAccountsReceivablePage = new ARAccountsReceivablePage( scriptHelper );
        arAccountsReceivablePage.closeARperiod();
    }


    public void cashbalancenavigate() {
        ARHomePage arHomePage = new ARHomePage( scriptHelper );
        arHomePage.cashbalanceNav();
        report.updateTestLog( "Verify User is able to navigate to Cash balance", "User navigated to Cash balance successfully", Status.PASS );
    }

    public void createbanknavigation() {
        ARBankTransferPage arBankTransferPage = new ARBankTransferPage( scriptHelper );
        arBankTransferPage.createbankaccounttransfernav();
        report.updateTestLog( "Verify the Create Bank Account Transfer", "User navigated to the Create Bank Account Transfer successfully", Status.PASS );
    }

    public void createbankaccounttransfer() {
        ARBankTransferPage arBankTransferPage = new ARBankTransferPage( scriptHelper );
        arBankTransferPage.createbankacctransfer();
    }

    public void createAdhocpaymtnav() {
        ARBankTransferPage arBankTransferPage = new ARBankTransferPage( scriptHelper );
        arBankTransferPage.createadhocpaymentnav();
        report.updateTestLog( "Verify User is able to navigate to the Create Adhoc payment", "User navigated to Create Adhoc payment successfully", Status.PASS );
    }

    public void createAdhocpayment() {
        ARBankTransferPage arBankTransferPage = new ARBankTransferPage( scriptHelper );
        arBankTransferPage.adhocpayment();
    }

    public void setupandmaintenancenavi() {
        ARHomePage arHomePage = new ARHomePage( scriptHelper );
        arHomePage.setupmaintenanceNav();
        report.updateTestLog( "Verify User is able to navigate to Set up and Maintenance", "User navigated to Set up & Maintenance successfully", Status.PASS );
    }

    public void createBank() {
        ARCreateBankpage arCreateBankpage = new ARCreateBankpage( scriptHelper );
        arCreateBankpage.createbank();
    }

    public void createBranchname() {
        ARCreateBankpage arCreateBankpage = new ARCreateBankpage( scriptHelper );
        arCreateBankpage.createbranch();
    }

    public void createBankaccount() {
        ARCreateBankpage arCreateBankpage = new ARCreateBankpage( scriptHelper );
        arCreateBankpage.createbankaccount();
    }



}
