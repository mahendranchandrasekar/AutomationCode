package businesscomponents;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.ReusableLibrary;
import com.cognizant.craft.ScriptHelper;
import com.cognizant.framework.ExcelDataImport;
import com.cognizant.framework.Status;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import pages.*;

import java.util.Set;


/**
 * Class for storing general purpose business components
 */
public class APComponents extends ReusableLibrary {

    // page loading time
    public static final int PAGELOADTIMEOUT = 90;
    // individual element load time
    public static final int ELEMENTTIMEOUT = 60;
    // Oracle query response
    public static final long QUERYRESPONSE = 15;
    // object render script
    public static final long SCRIPTTIME = 5;

	/**
	 * Constructor to initialize the component library
	 *
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */


	public APComponents(ScriptHelper scriptHelper) {
		super(scriptHelper);
	}



	public void createNonPOForInvoice()  {
        this.navigationalFlowForInvoice();
		CreateInvoicePage createInvoicePage= new CreateInvoicePage(scriptHelper);
		createInvoicePage.EnterNonPODetailsForCreateInvoiceHeader();
		createInvoicePage.EnterDetailsForCreateInvoiceLines();
		createInvoicePage.EnterDetailsForCreateInvoiceTaxes();
		createInvoicePage.EnterDetailsForCreateInvoiceTotals();
		createInvoicePage.valdidateInvoiceSummary();
	}


	public void createPOForInvoice() {
        CreateRequisitionPage requisitionPage = new CreateRequisitionPage(scriptHelper);
        this.createRequisition();
        NavigationPage navigationPage = new NavigationPage(scriptHelper);
        navigationPage.menuNavigation();
		navigationPage.clickOnMainInvoiceLink();
		report.updateTestLog("Invoice Home page", "The  Landing Page is Invoice Homepage", Status.PASS);
		navigationPage.clickOnInvoiceTaskMenu();
		navigationPage.clickOnCreateInvoiceLink();
		CreateInvoicePage createInvoicePage = new CreateInvoicePage(scriptHelper);
		createInvoicePage.enterPODetailsForCreateInvoiceHeader(requisitionPage.purchaseOrderNumber);
		createInvoicePage.EnterDetailsForCreateInvoiceTaxes();
		createInvoicePage.EnterDetailsForPOCreateInvoiceTotals();
		createInvoicePage.valdidateInvoiceSummary();
	}

	public void approveInvoiceRequest()  {
		NavigationPage navigationPage= new NavigationPage(scriptHelper);
		navigationPage.approveInvoiceRequest();
	}

    private void navigationalFlowForInvoice() {
        NavigationPage navigationPage = new NavigationPage(scriptHelper);
        navigationPage.menuNavigation();
        navigationPage.clickOnMainInvoiceLink();
        report.updateTestLog("Invoices Home page screen", "The Landing Page is Invoice Homepage", Status.PASS);
        navigationPage.clickOnInvoiceTaskMenu();
        navigationPage.clickOnCreateInvoiceLink();
    }

    public void verifyTheApprovedInvoiceRequest()  {
        NavigationPage navigationPage = new NavigationPage(scriptHelper);
        navigationPage.menuNavigation();
        navigationPage.clickOnMainInvoiceLink();
        report.updateTestLog("Invoices Home page screen", "The Landing Page is Invoice Homepage", Status.PASS);
        navigationPage.clickOnInvoiceTaskMenu();
        navigationPage.clickOnManageInvoiceLink();
        InvoicesManagePage invoicesManagePage= new InvoicesManagePage(scriptHelper);
        invoicesManagePage.searchAndVerifyInvoice();
		report.updateTestLog("Manage Invoice Homepage", "The Landing Page is Manage Invoice Homepage", Status.PASS);
    }


    //--------------------------------------------Requistion Operations ----------------------------------------------------------//

    OraCloudLoginPage signOnPage = new OraCloudLoginPage(scriptHelper);


    public void loginAsValidUser() {
        String userName = dataTable.getData(ExcelDataImport.GeneralData, "UsernameForTeamMember");
        String password = dataTable.getData(ExcelDataImport.GeneralData, "PasswordForTeamMember");
        signOnPage.login(userName, password);
    }



    public void createRequisition() {
        String reqCategory = dataTable.getData(ExcelDataImport.RegisterUserData, "reqCategory");
        String reqDetails = dataTable.getData(ExcelDataImport.RegisterUserData, "reqHdrDetails");
        String reqLineDetails = dataTable.getData(ExcelDataImport.RegisterUserData, "reqLineDetails");

        String apprvFlag = dataTable.getData(ExcelDataImport.RegisterUserData, "approvalRequired");
        String apprvUId = dataTable.getData(ExcelDataImport.RegisterUserData, "approverUIdArr");
        String apprvPwd = dataTable.getData(ExcelDataImport.RegisterUserData, "approverPwdArr");

        CreateRequisitionPage requisitionPage = new CreateRequisitionPage(scriptHelper);

        requisitionPage.navigateToCategory(reqCategory);
        requisitionPage.enterRequisitionHdrDetails(reqDetails);
        requisitionPage.enterRequisitionLineDetails(reqLineDetails);
        if (apprvFlag.toUpperCase().equals("YES")) {
                signOnPage.logout();
                String[] apprvUIdArr = apprvUId.split(";");
                String[] apprvPwdArr = apprvPwd.split(";");

                for (int i = 0; i < apprvUIdArr.length; i++) {
                    approve(requisitionPage.reqNumber, apprvUIdArr[0], apprvPwdArr[0]);
                }
                ;

                loginAsValidUser();
                //requisitionPage.navigateToRequisitionPage();
            requisitionPage.verifyPurchaseOrder();
            if (dataTable.getData(ExcelDataImport.RegisterUserData, "ReceiptCreation").equals("Yes")) {
                requisitionPage.createReceipt(requisitionPage.reqNumber);
                report.updateTestLog("Receipt Creation","Receipt Creation is required for 3 ways matching PO Invoice Creation", Status.PASS);
            } else if (dataTable.getData(ExcelDataImport.RegisterUserData, "ReceiptCreation").equals("No")) {
                report.updateTestLog("Receipt Creation","Receipt Creation is not required for 2 ways matching PO Invoice Creation", Status.PASS);
            }

        } else if (apprvFlag.toUpperCase().equals("NO")) {
            requisitionPage.clickHome();
            requisitionPage.verifyPurchaseOrder();

            if (dataTable.getData(ExcelDataImport.RegisterUserData, "ReceiptCreation").equals("Yes")) {
                requisitionPage.createReceipt(requisitionPage.reqNumber);
                        report.updateTestLog("Receipt Creation","Receipt Creation is required for 3 ways matching PO Invoice Creation", Status.PASS);
            } else if (dataTable.getData(ExcelDataImport.RegisterUserData, "ReceiptCreation").equals("No")) {
                report.updateTestLog("Receipt Creation", "Receipt Creation is not required for 2 ways matching PO Invoice Creation", Status.PASS);

            }
            }
        }




    private void approve(String matchVal, String aUId, String aPwd) {

        By bellButton = By.xpath("//a[contains(@title,'Notifications')]");

        CreateRequisitionPage reqPage = new CreateRequisitionPage(scriptHelper);

        signOnPage.login(aUId, aPwd);

        //Approve Notification
        By approvalNotification = By.xpath("//a[contains(text(),'" + matchVal+ "')]");
        By notificationHdr = By.xpath("//h1[text()='Pending Notifications']");
        By apprvBtn = By.xpath("//*[text()='Approve']");
        By submitBtn = By.xpath("//*[text()='Submit']");
        reqPage.isElementAvailable(bellButton,reqPage.PAGELOADTIMEOUT);


        Integer notificationFoundFlag =0;
        do {
            driver.findElement(bellButton).click();
            reqPage.isElementAvailable(notificationHdr,10);

            // do nothing for few seconds inside the loop instead of clicking the done button incessantly
            oracleObjectRender(SCRIPTTIME);

            notificationFoundFlag = driver.findElements(approvalNotification).size();
            if(notificationFoundFlag>0){
                report.updateTestLog("Verify Notification",
                        "Notification for "+ matchVal  +" found successfully", Status.PASS);

            }else{
                //Actions action = new Actions(driver);
                driver.findElement(By.tagName("body")).sendKeys(Keys.ESCAPE);
            }

        } while (notificationFoundFlag ==0);



        if(notificationFoundFlag ==0){
            report.updateTestLog("Verify Notification",
                    "Notification for "+ matchVal  +"was not found", Status.FAIL);

        }else{
            //click and approve notification
            driver.findElement(approvalNotification).click();
            driver.findElement(By.tagName("body")).sendKeys(Keys.ESCAPE);
            Set<String> winHandles;
            String parentWinHandle = driver.getWindowHandle();

            do {

                // do nothing for few seconds inside the loop instead of clicking the done button incessantly
                oracleObjectRender(QUERYRESPONSE); oracleObjectRender(SCRIPTTIME);
                winHandles = driver.getWindowHandles();
            } while (winHandles.size() == 1);

            for(String handle: winHandles){
                if(!handle.equals(parentWinHandle)){
                    driver.switchTo().window(handle);
                    oracleObjectRender(SCRIPTTIME); oracleObjectRender(SCRIPTTIME);
                    reqPage.isElementAvailable(apprvBtn,90);
                    driver.findElement(apprvBtn).click();
                    oracleObjectRender(SCRIPTTIME);
                    driver.switchTo().window(parentWinHandle);
                    signOnPage.logout();

                }
            }

        };

    }


//----------------------------------------Payment Method -------------------------------------------------//
    public void paymentProcess() {
        PaymentNavigation paymentNavigation = new PaymentNavigation( scriptHelper );
        paymentNavigation.paymentNav();
        report.updateTestLog( "Verify the Payment Navigation", " User navigated to Payment successfully", Status.PASS );
        PaymentPage paymentPage = new PaymentPage( scriptHelper );
        paymentPage.createPaymentnav();
        report.updateTestLog( "Verify the Create Payment", " User navigated to Create Payment successfully", Status.PASS );
        paymentPage.createPayment();
    }

    public void paymentProcessForSpecifiedInvoice() {
        PaymentNavigation paymentNavigation = new PaymentNavigation( scriptHelper );
        paymentNavigation.paymentNav();
        report.updateTestLog( "Verify the Payment Navigation", " User navigated to Payment successfully", Status.PASS );
        PaymentPage paymentPage = new PaymentPage( scriptHelper );
        paymentPage.createPaymentnav();
        report.updateTestLog( "Verify the Create Payment", " User navigated to Create Payment successfully", Status.PASS );
        paymentPage.createPaymentForSpecifiedInvoice();
    }

}