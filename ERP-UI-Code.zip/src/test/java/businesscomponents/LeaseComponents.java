package businesscomponents;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.ReusableLibrary;
import com.cognizant.craft.ScriptHelper;
import com.cognizant.framework.Status;
import pages.LeaseCreatePage;
import pages.NavigationPage;
/**
 * Class for storing general purpose business components
 */
public class LeaseComponents extends ReusableLibrary {

	/**
	 * Constructor to initialize the component library
	 *
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	public LeaseComponents(ScriptHelper scriptHelper) {
		super(scriptHelper);
	}



	public void createLeaseProcess()  {
		NavigationPage navigationPage= new NavigationPage(scriptHelper);
		navigationPage.menuNavigation();
		navigationPage.clickOnMainAssetsLink();
		report.updateTestLog("Assets Homepage", "The Landing page is Assets Homepage", Status.PASS);
		navigationPage.clickOnAssetsTaskMenu();
		navigationPage.clickOnManageLeasesLink();
		LeaseCreatePage leaseCreatePage= new LeaseCreatePage(scriptHelper);
		leaseCreatePage.createLeases();
	}


}