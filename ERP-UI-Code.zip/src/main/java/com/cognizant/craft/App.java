package com.cognizant.craft;


public class App
{
    /**
     * yet to be build
     *
     */
    public static void main( String[] args )
    {
// yet to be build
    }
}
